#ifndef SHADER_DEFINITION_H_
#define SHADER_DEFINITION_H_

#pragma once

#include <string>
#include <vector>
#include <map>

#include <bgfx/bgfx.h>

#include "ShaderEnums.h"
#include "ShaderComponents.h"
#include "ShaderEnums.h"
#include "ShaderParameters.h"

namespace onyx {
namespace Shaders {

	struct ShaderDefinition
	{
	public:
		ShaderDefinition() { }

		ShaderDefinition(std::string const& signature);

		~ShaderDefinition();

		void cleanup();

		std::string mSignature;
		std::vector<IShaderComponent::shared_ptr_t> components;
		bgfx::ProgramHandle programHandle = BGFX_INVALID_HANDLE,
							mInstancedHandle = BGFX_INVALID_HANDLE;

		std::map<std::string, bgfx::UniformHandle> uniforms;
		std::map<std::string, ShaderParam*> parameters;
		onyx::Shaders::ValueBag config;

		const std::string mainOpen = "void main()\n{\n";
		const std::string mainClose = "\n}\n";

		int samplerCount = 0;

		template <typename... Args>
		inline void setParameter(std::string const& name, Args... value)
		{
			auto p = parameters.find(name);
			if (p != parameters.end())
			{
				(p->second)->setValue(value...);
			}
		}

		std::string assembleShader(ShaderEnums::ShaderType type) const;
		std::string assembleShader(ShaderEnums::ShaderType shaderType, onyx::Shaders::ValueBag const& params) const;

		void assignSamplers(bool setUniforms = false);

		struct ShaderExtensions
		{
			static constexpr char Vertex[4] = ".vs";
			static constexpr char Fragment[4] = ".fs";
			static constexpr char Instance[6] = ".inst";
		};

		bool hasShader(ShaderEnums::ShaderType shaderType) const;
		bool hasInstancing() const;
		std::string getFileName(ShaderEnums::ShaderType shaderType, bool isSource = false) const;

		static std::shared_ptr<ShaderDefinition> LoadActive(std::string const& signature);
		static std::string GetFileName(std::string const & signature, ShaderEnums::ShaderType shaderType, bool isSource = false);

	};

} }

#endif
