#ifndef CONFIGURABLE_SHADER_H_
#define CONFIGURABLE_SHADER_H_

#pragma once

#include <memory>
#include <string>
#include <vector>
#include <map>
#include <unordered_set>

#include "ShaderDefinition.h"

namespace onyx {
namespace Shaders {

	class ConfigurableShader
	{
	public:

		inline size_t count() { return mActiveShaders.size(); }

		void cleanup();
		ShaderParam* getParameter(const std::string& name, int subset = 0);
		std::vector<ShaderParam*> getActiveParameters(int subset);
		std::shared_ptr<ShaderDefinition> getShader(int subset);
		void toggleComponent(std::string const& component, bool enabled);
		void loadSignature(std::string sig);
		void setCurrentShaderByParams(std::vector<ShaderParam*>& params, ValueBag const& configuration);
		~ConfigurableShader();

		template <typename T>
		void setParameter(std::string const& name, T const& value, int subset = 0)
		{
			auto sp = getParameter(name, subset);
			if (sp != nullptr)
			{
				sp->setValue(value);
			}
		}

	private:
		std::map<int, std::shared_ptr<ShaderDefinition>> mActiveShaders;
		std::unordered_set<std::string> mActiveComponents;

	};

} }

#endif
