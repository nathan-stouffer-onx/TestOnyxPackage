#pragma once

#include <string>
#include <map>

namespace onyx {
namespace Shaders {

	struct BaseShaderRequirements
	{
		bool position = false;
		bool transformPosition = false;
		bool positionOutput = false;
		bool normal = false;
		bool tangent = false;
		bool uv0 = false;
		bool color0 = false;
		int addUV = 0;
		int addColor = 0;

		void enablePosition(bool b);
		void enableTransformPosition(bool b);
		void enablePositionOutput(bool b);
		void enableNormal(bool b);
		void enableTangent(bool b);
		void enableUV0(bool b);
		void enableColor0(bool b);

		bool hasPosition() const;
		bool hasTransformPosition() const;
		bool hasPositionOutput() const;
		bool hasNormal() const;
		bool hasTangent() const;
		bool hasUV0() const;
		bool hasColor0() const;

		void enableAnotherUV();
		void enableAnotherColor();

		int getUVCount() const;
		int getColorCount() const;

		void mergeRequirements(BaseShaderRequirements const& other);
	};

	class ValueBag
	{
	private:
		std::map<std::string, bool> mBoolParams;
		std::map<std::string, int> mIntParams;
	public:
		ValueBag() {};
		ValueBag(ValueBag const& source);
		ValueBag(BaseShaderRequirements const& source);
		ValueBag& operator=(ValueBag const& source);

		void addBaseRequirements(BaseShaderRequirements const& source);
		void merge(ValueBag const& other);
		__inline bool hasBool(std::string const& name)		const { return mBoolParams.find(name) != mBoolParams.end(); }
		__inline bool hasInt(std::string const& name)		const { return mIntParams.find(name) != mIntParams.end(); }
		__inline bool getBool(std::string const& name)		const { return mBoolParams.at(name); }
		__inline int getInt(std::string const& name)		const { return mIntParams.at(name); }

		__inline void setParam(std::string const& name, bool value) { mBoolParams[name] = value; }
		__inline void setParam(std::string const& name, int value) { mIntParams[name] = value; }
		void setParams(std::map<std::string, bool> const& values);
		void setParams(std::map<std::string, int> const& values);

		__inline int getColorCount()				const { return getInt("ColorCount"); };
		__inline int getUvCount()					const { return getInt("UVCount"); };
		__inline size_t size()						const { return mBoolParams.size() + mIntParams.size(); }

		std::map<std::string, bool> const& bools() const { return mBoolParams; }
		std::map<std::string, int> const& ints()	const { return mIntParams; }
	};

} }