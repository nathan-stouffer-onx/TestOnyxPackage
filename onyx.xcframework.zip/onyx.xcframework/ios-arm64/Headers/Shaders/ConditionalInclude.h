#pragma once

#if !defined(CONDITIONAL_INCLUDE_H_INCLUDED)
#define CONDITIONAL_INCLUDE_H_INCLUDED

#include <string>
#include "BaseShaderRequirements.h"

namespace onyx {
namespace Shaders {
	struct ConditionalInclude
	{
		std::string ifThisBoolTrue = "";
		std::string ifThisBoolFalse = "";
		std::string ifThisIntEqualsValue = "";
		int targetIntValue = 0;
		std::string forThisIntTimes = "";
		std::string loopReplaceValue = "%i";

		bool hasConditional() const
		{
			return ifThisBoolFalse != "" || ifThisBoolTrue != "" || ifThisIntEqualsValue != "" || forThisIntTimes != "";
		}

		bool passes(onyx::Shaders::ValueBag const& reqs) const
		{
			if (!hasConditional())
			{
				return true;
			}

			bool boolPass = true;
			bool intPass = true;

			if (ifThisBoolFalse != "")
			{
				boolPass &= reqs.hasBool(ifThisBoolFalse)
					&& !reqs.getBool(ifThisBoolFalse);
			}

			if (ifThisBoolTrue != "")
			{
				boolPass &= reqs.hasBool(ifThisBoolTrue)
					&& reqs.getBool(ifThisBoolTrue);
			}

			if (ifThisIntEqualsValue != "")
			{
				intPass &= reqs.hasInt(ifThisIntEqualsValue)
					&& reqs.getInt(ifThisIntEqualsValue) == targetIntValue;
			}

			if (forThisIntTimes != "")
			{
				intPass &= reqs.hasInt(forThisIntTimes)
					&& reqs.getInt(forThisIntTimes) > 0;
			}

			return boolPass && intPass;
		}


	};
} }

#endif