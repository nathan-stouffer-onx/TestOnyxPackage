#pragma once
#if !defined(__SHADER_COMBINATION_INCLUDED)
#define __SHADER_COMBINATION_INCLUDED

#include <vector>

#include "ShaderManager.h"

namespace ShaderGenerator
{

	struct ShaderCombination
	{
		std::vector<ShaderManager::CombinerSegment> segments;
		
		static ShaderCombination LoadJson(ShaderCombination& dest, std::string const& json);
		static ShaderCombination LoadFile(ShaderCombination& dest, std::string const& fileName);
	};

	void LoadShaderCombination(ShaderCombination& dest, std::string fileName);

}
#endif