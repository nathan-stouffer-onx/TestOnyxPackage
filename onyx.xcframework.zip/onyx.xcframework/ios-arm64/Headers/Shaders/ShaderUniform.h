#pragma once

#if !defined(UNIFORM_H_INCLUDED)
#define UNIFORM_H_INCLUDED

#include <string>
#include <json/jsonParsing.h>

#include "ShaderEnums.h"
#include "ConditionalInclude.h"

using nlohmann::json;

namespace onyx {
namespace Shaders {
    struct Uniform
    {
        enum class Types
        {
            UNKNOWN = -1,
            VEC2 = 0,
            VEC3 = 1,
            VEC4 = 2,
            FLOAT = 3,
            SAMPLER2D = 4,
            COLOR = 5

        };


        void parse(const json& j);
        static Types typeFromString(std::string const& typeName);
        static std::string getTypeName(Types value);
        std::string to_string();

        std::string mName;
        Types mType;
        ShaderEnums::ShaderType mShaderType;
        ConditionalInclude mConditional;
    };

    void to_json(json& j, const onyx::Shaders::Uniform& uniform);

    void from_json(const json& j, onyx::Shaders::Uniform& uniform);

} }

namespace ShaderEnums
{
    template<>
    __inline
    onyx::Shaders::Uniform::Types fromString(std::string const& name)
    {
        return onyx::Shaders::Uniform::typeFromString(name);
    }

    __inline std::string toString(onyx::Shaders::Uniform::Types const value)
    {
        return onyx::Shaders::Uniform::getTypeName(value);
    }
}

#endif // UNIFORM_H_INCLUDED