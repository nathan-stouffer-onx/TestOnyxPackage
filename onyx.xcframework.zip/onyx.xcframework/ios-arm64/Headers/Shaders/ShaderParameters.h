#ifndef SHADERPARAMETERS_H_
#define SHADERPARAMETERS_H_

#include <string>
#include <vector>
#include <map>
#include <bgfx/bgfx.h>
#include <bx/math.h>
#include <lucid/gal/Types.h>
#include <3rdParty/nlohmann/json.hpp>
#include <System/FileSystem.h>
#include <Logging/LogManager.h>

#include "ShaderEnums.h"
#include "Component/ShaderChunk.h"

enum class ShaderParamType
{
	isBool,
	isInt,
	isFloat,
	isVec2,
	isVec3,
	isVec4,
	isMat4,
	isTexture,
	isCubeSampler,
	isColor,
	NotSet
};

//represents one variable in a shader
class ShaderParam
{
public:
	ShaderParam() 
	{
	}

	ShaderParam(const ShaderParam& p)
	{
		mComponentName = p.mComponentName;
		mName = p.mName;
		isRealtimeUniform = p.isRealtimeUniform;
		mMin = p.mMin;
		mMax = p.mMax;
		mImguiRate = p.mImguiRate;
		mType = p.mType;
		setValue(p);
		mSamplerUnit = p.mSamplerUnit;
		mIsAnisoFilter = p.mIsAnisoFilter;
		mInstanced = p.mInstanced;
		mConditional = p.mConditional;
		mUniformId = p.mUniformId;
		mTexResId = p.mTexResId;
		xTexRes = p.xTexRes;
		yTexRes = p.yTexRes;
	}

	~ShaderParam()
	{

		//not sure why but it doesnt like doing this...
		if (bgfx::isValid(mUniformId))
		{
			bgfx::destroy(mUniformId);
		}
		if (bgfx::isValid(mTexResId))
		{
			bgfx::destroy(mTexResId);
		}
	}

	std::string mComponentName;
	std::string mName;
	bool isRealtimeUniform = true; //when false, means changing this value would swap to a new shader sig
	bool mInstanced = false;
	//ranges for int/float ui controls
	float mMin = -1;
	float mMax = -1;
	float mImguiRate = 0.01f;

		bool mBool = false;
		int mInt = 0;
		float mFloat = 0;
		bgfx::TextureHandle mTexId = BGFX_INVALID_HANDLE;
		lgal::gpu::Vector2 mVec2 = { 0, 0 };
		lgal::gpu::Vector3 mVec3 = { 0, 0, 0 };
		lgal::gpu::Vector4 mVec4 = { 0, 0, 0, 0 };
		lgal::Color mColor = { 0.f, 0, 0, 0 };
		float mMat4[16] = { 0 };

	uint8_t mSamplerUnit = 0;
	bool mIsAnisoFilter = false;
	uint32_t mSamplerFlags = 0;
	ShaderParamType mType = ShaderParamType::NotSet;
	onyx::Shaders::ConditionalInclude mConditional;

	ShaderEnums::ShaderType mShaderType = ShaderEnums::ShaderType::Vertex_and_Pixel;

	inline ShaderParamType getDataType() { return mType; }
	inline std::string getName() { return mName; }

	bool setValue(const ShaderParam& p)
	{
		if (mType != p.mType)
		{
			return false;
		}
		switch(mType)
		{
			case ShaderParamType::isBool:
				mBool = p.mBool;
				break;
			case ShaderParamType::isInt:
				mInt = p.mInt;
				break;
			case ShaderParamType::isFloat:
				mFloat = p.mFloat;
				break;
			case ShaderParamType::isTexture:
			case ShaderParamType::isCubeSampler:
				mTexId = p.mTexId;
				xTexRes = p.xTexRes;
				yTexRes = p.yTexRes;
				mSamplerFlags = p.mSamplerFlags;
				break;
			case ShaderParamType::isVec2:
				mVec2 = p.mVec2;
				break;
			case ShaderParamType::isVec3:
				mVec3 = p.mVec3;
				break;
			case ShaderParamType::isVec4:
				mVec4 = p.mVec4;
				break;
			case ShaderParamType::isMat4:
				std::copy(&p.mMat4[0], &p.mMat4[16], mMat4);
				break;
			case ShaderParamType::isColor:
				mColor = p.mColor;
				break;
			default:
				MAP3D_THROW("Unrecognized shader parameter type!");
		}
		return true;
	}

	bool setValue(bool b)
	{
		if (mType != ShaderParamType::isBool)
			return false;

		mBool = b;
		setUniform();
		return true;
	}

	bool setValue(int i)
	{
		if (mType != ShaderParamType::isInt)
			return false;

		mInt = i;
		setUniform();
		return true;
	}

	bool setValue(float f)
	{
		if (mType != ShaderParamType::isFloat)
			return false;

		mFloat = f;
		setUniform();
		return true;
	}

	bool setValue(world_float_t value)
	{
		if (mType != ShaderParamType::isFloat)
			return false;

		mFloat = float(value);
		setUniform();
		return true;
	}

	bool setValue(bgfx::TextureHandle t)
	{
		if (mType != ShaderParamType::isTexture && mType != ShaderParamType::isCubeSampler)
			return false;

		mTexId = t;
		xTexRes = 1;
		yTexRes = 1;
		setUniform();
		return true;
	}

	bool setValue(float m[16])
	{
		if(mType != ShaderParamType::isMat4)
			return false;

		std::copy(&m[0], &m[16], mMat4);
		setUniform();
		return true;
	}

	bool setValue(bgfx::TextureHandle t, int xRes, int yRes)
	{
		if (mType != ShaderParamType::isTexture && mType != ShaderParamType::isCubeSampler)
			return false;

		mTexId = t;
		xTexRes = xRes;
		yTexRes = yRes;
		setUniform();
		return true;
	}

	bool setValue(lgal::gpu::Vector2 v)
	{
		if (mType != ShaderParamType::isVec2)
			return false;

		mVec2 = v;
		setUniform();
		return true;
	}

	bool setValue(lgal::world::Vector2 v)
	{
		return setValue(lgal::toGPU(v));
	}

	bool setValue(lgal::gpu::Vector3 v)
	{
		if (mType != ShaderParamType::isVec3)
			return false;

		mVec3 = v;
		setUniform();
		return true;
	}

	bool setValue(lgal::world::Vector3 v)
	{
		return setValue(lgal::toGPU(v));
	}

	bool setValue(bx::Vec3 v)
	{
		if (mType != ShaderParamType::isVec3)
			return false;

		mVec3 = lgal::gpu::Vector3(v.x, v.y, v.z);
		setUniform();
		return true;
	}

	bool setValue(lgal::gpu::Vector4 v)
	{
		if (mType != ShaderParamType::isVec4)
			return false;

		mVec4 = v;
		setUniform();
		return true;
	}

	bool setValue(lgal::world::Vector4 v)
	{
		return setValue(lgal::toGPU(v));
	}

	bool setValue(lgal::world::Quaternion q)
	{
		return setValue(lgal::world::Vector4{ q.x, q.y, q.z, q.w });
	}

	bool setValue(lgal::Color const& color)
	{
		if (mType != ShaderParamType::isColor)
			return false;

		mColor = color;
		setUniform();
		return true;
	}

	void setUniform()
	{
		if (mUniformId.idx == bgfx::kInvalidHandle)
		{
			getUniformHandle();
			if (mUniformId.idx == bgfx::kInvalidHandle)
			{
				logE("uniform %s could not be acquired", mName.c_str());
				return;
			}
		}

		switch (mType)
		{
		case ShaderParamType::isBool:
			{
				float b = mBool ? 1.0f : 0.0f; //no int/bool uniforms, have to convert to float
				bgfx::setUniform(mUniformId, &b, 1);
			}
			break;
		case ShaderParamType::isInt:
			bgfx::setUniform(mUniformId, &mInt, 1);
			break;
		case ShaderParamType::isFloat:
			bgfx::setUniform(mUniformId, &mFloat, 1);
			break;
		case ShaderParamType::isVec2:
			bgfx::setUniform(mUniformId, &mVec2, 1);
			break;
		case ShaderParamType::isVec3:
			bgfx::setUniform(mUniformId, &mVec3, 1);
			break;
		case ShaderParamType::isVec4:
			bgfx::setUniform(mUniformId, &mVec4, 1);
			break;
		case ShaderParamType::isColor:
			bgfx::setUniform(mUniformId, &mColor, 1);
			break;
		case ShaderParamType::isMat4:
			bgfx::setUniform(mUniformId, &mMat4, 1);
			break;
		case ShaderParamType::isTexture:
		case ShaderParamType::isCubeSampler:
			if (mTexId.idx != bgfx::kInvalidHandle)
			{
				uint32_t flags = mSamplerFlags;
				if (flags == 0)
				{
					flags = BGFX_SAMPLER_UVW_CLAMP;
					if (mIsAnisoFilter)
						flags |= BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC;
					else
						flags |= BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT;
				}
				bgfx::setTexture(mSamplerUnit, mUniformId, mTexId, flags);
				lgal::gpu::Vector4 res((float)xTexRes, (float)yTexRes, 1.f / (float) xTexRes, 1.f / (float)yTexRes);
				bgfx::setUniform(mTexResId, &res, 1);
			}
			break;
		default:
				MAP3D_THROW(std::string("Unrecognized shader parameter type specified: ") + std::to_string(int(mType)));
		}
	}

	bgfx::UniformHandle getUniformHandle()
	{
		if (mUniformId.idx == bgfx::kInvalidHandle)
		{
			switch (mType)
			{
			case ShaderParamType::isBool:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4);
				break;
			case ShaderParamType::isInt:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			case ShaderParamType::isFloat:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			case ShaderParamType::isVec2:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			case ShaderParamType::isVec3:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			case ShaderParamType::isVec4:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			case ShaderParamType::isColor:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			case ShaderParamType::isMat4:
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Mat4, 1);
				break;
			case ShaderParamType::isTexture:
			case ShaderParamType::isCubeSampler:
			{
				mUniformId = bgfx::createUniform(mName.c_str(), bgfx::UniformType::Sampler);
				std::string resName = mName + "_Res";
				mTexResId = bgfx::createUniform(resName.c_str(), bgfx::UniformType::Vec4, 1);
				break;
			}
			default:
				MAP3D_THROW("Unrecognized uniform type: " + std::to_string(std::int32_t(mType)));
			}
		}

		return mUniformId;
	}

private:
	bgfx::UniformHandle mUniformId = BGFX_INVALID_HANDLE;
	bgfx::UniformHandle mTexResId = BGFX_INVALID_HANDLE; //if using a texture, pass in its resolution too
	int xTexRes = 0;
	int yTexRes = 0;
};

#endif