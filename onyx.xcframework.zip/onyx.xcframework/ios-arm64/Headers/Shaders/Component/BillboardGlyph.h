#ifndef BILLBOARDGLYPH_H_
#define BILLBOARDGLYPH_H_

#include "IShaderComponent.h"

/**
* Uses glyph texture as mask values. The texture mask is a PNG that uses its RGBA value as follows
*	- R: 1.0 blocks color0 and lets in color2. 0.0 blocks color2 and lets in color0.
*		0.5 disallows both color0 and color2
*	- G: 1.0 blocks color1 and lets in color3. 0.0 blocks color3 and lets in color1.
*		0.5 disallows both color1 and color3
*	- B: No effect currently
*	- A: [0.0, 1.0] is the end color's alpha value and rgb linear scale
* 
* Bools: none
* Requirements: 
*	- Sets addUV to 1
*	- Sets +GlyphCount to ColorCount if GlyphCount was set
* Ints:
*	- GlyphCount (number of textures/glyphs) Default: 1
* Inputs:
*	- vec4 texcoord0 (hardcoded to one)
*	- vec4 color0-3. Set by Int ColorCount
* Uniforms:
*	- texture s_texture0-7 set by Int GlyphCount
*	- vec4 u_ScaleOffsetTex0-7 set by Int GlyphCount
*/
class BillboardGlyph : public IShaderComponent
{
public:
	static constexpr char ComponentName[] = "BillboardGlyph";
	static constexpr int RequiredTextures = 1;
	BillboardGlyph();
	void assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const & reqs) override;
	int getSortOrder() const override { return 5; }

	// Forces reqs.addUV to be 1, reqs.addColor to be equal to GlyphCount
	void addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& reqs, onyx::Shaders::ValueBag& params) override;

	std::vector<ShaderParam*> getShaderParams(onyx::Shaders::ValueBag const& config, bool getCurrentUniform = false) override;
};
#endif