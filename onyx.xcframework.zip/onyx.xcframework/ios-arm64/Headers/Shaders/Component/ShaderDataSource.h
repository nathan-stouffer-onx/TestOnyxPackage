#ifndef SHADER_DATA_SOURCE_H_
#define SHADER_DATA_SOURCE_H_

#include <string>
#include <vector>

#include "Shaders/ConditionalInclude.h"
#include "Shaders/ShaderParameters.h"

namespace onyx {
namespace Shaders {
namespace Components {

	struct ShaderDataSource
	{
		std::string alias;
		ShaderParamType dataType;
		std::string swizzle;
		bool instanced = false;
		onyx::Shaders::ConditionalInclude conditional;
	};

} } }


#endif