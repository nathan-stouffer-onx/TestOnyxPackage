#ifndef TEXTURELAYER_H_
#define TEXTURELAYER_H_

#include "IShaderComponent.h"
#include <string>

class TextureLayer : public IShaderComponent
{
public:
	static constexpr char ComponentName[] = "TextureLayer";
	TextureLayer();
	void assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const & reqs) override;
	int getSortOrder() const override { return 1; }
	void addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& reqs, onyx::Shaders::ValueBag& params) override;
	void setTextureCount(onyx::Shaders::ValueBag& config, int t);
	std::vector<ShaderParam*> getShaderParams(onyx::Shaders::ValueBag const& config, bool getCurrentUniform = false) override;
	std::string getSignature(onyx::Shaders::ValueBag const& params) override;
};
#endif