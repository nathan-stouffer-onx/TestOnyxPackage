#ifndef SHADERCHUNK_H_
#define SHADERCHUNK_H_

#include <string>
#include <vector>

#include "Shaders/ShaderEnums.h"
#include "Shaders/ConditionalInclude.h"

struct ShaderComponentJson
{
	std::string componentName;
	std::string filename;
};

struct ShaderChunk
{
	std::string mData = "";
	ShaderEnums::ShaderInsertPosition mPosition = ShaderEnums::ShaderInsertPosition::INVALID;
	int mPositionOffset = 0;
	ShaderEnums::ShaderType mType = ShaderEnums::ShaderType::Vertex_and_Pixel;

	onyx::Shaders::ConditionalInclude mConditional; //used by json processor setup to know when this chunk is active in the component

	ShaderChunk() {}
	ShaderChunk(const ShaderChunk& chunk)
		: mData(chunk.mData)
		, mPosition(chunk.mPosition)
		, mPositionOffset(chunk.mPositionOffset)
		, mType(chunk.mType)
		, mConditional(chunk.mConditional)
	{
	}

	ShaderChunk& operator=(const ShaderChunk& chunk)
	{
		this->mData = chunk.mData;
		this->mPosition = chunk.mPosition;
		this->mPositionOffset = chunk.mPositionOffset;
		this->mType = chunk.mType;
		this->mConditional = chunk.mConditional;
		return *this;
	}

	ShaderChunk(ShaderEnums::ShaderType type, ShaderEnums::ShaderInsertPosition pos, int positionOffset, std::string data) : mData(data),  mPosition(pos), mPositionOffset(positionOffset), mType(type) { }
	ShaderChunk(ShaderEnums::ShaderType type, ShaderEnums::ShaderInsertPosition pos, std::string data) : mData(data), mPosition(pos), mType(type) { }

	bool operator<(ShaderChunk const& rhs) const
	{
		if (int(mPosition) != int(rhs.mPosition))
		{
			return int(mPosition) < int(rhs.mPosition);
		}
		return mPositionOffset < rhs.mPositionOffset;
	}

	bool operator>=(ShaderChunk const& rhs) const
	{
		return !(*this < rhs);
	}

};
#endif