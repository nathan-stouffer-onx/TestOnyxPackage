#include "IShaderComponent.h"

#include <3rdParty/nlohmann/json.hpp>
#include <System/Map3DException.h>
#include <Utils/StringUtils.h>

#include "Shaders/ShaderManager.h"

void IShaderComponent::assembleFromJson(std::string jsonString)
{
	nlohmann::json j = nlohmann::json::parse(jsonString);
}

void IShaderComponent::setConfigFromSignature(std::string sig, onyx::Shaders::ValueBag& config)
{
	auto boolSize = mBoolConfigurations.size();
	auto intSize = mIntConfigurations.size();

	if (boolSize + intSize < 1)
		return; //nothing to do

	auto params = onyx::Utils::splitString(sig, sVarDelimiter);
	params.erase(params.begin()); //remove the name, we dont need it offsetting things

	size_t n = 0;
	if (params.size() >= boolSize)
	{
		for (auto& b : mBoolConfigurations)
		{
			auto c = std::toupper(params[n++][0]);
			config.setParam(b, c == 'T' || c == '1');
		}
	}
	if (params.size() >= mIntConfigurations.size())
	{
		for (auto& i : mIntConfigurations)
		{
			MAP3D_TRY
				int val = std::stoi(params[n++]);
				config.setParam(i, val);
			MAP3D_CATCH_ALL
				MAP3D_CUSTOM_THROW(ShaderManagerException, std::string("Unable to parse parameter '") + i + "' value '" + params[n - 1] + "'");
			MAP3D_END_CATCH
		}
	}
	for (auto& [b, v] : mDefaultConfiguration.bools())
		if (!config.hasBool(b))
			config.setParam(b, v);

	for (auto& [i, v] : mDefaultConfiguration.ints())
		if (!config.hasInt(i))
			config.setParam(i, v);
}

