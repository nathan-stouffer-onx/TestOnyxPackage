#include "JsonShaderComponent.h"

JsonShaderComponent::JsonShaderComponent()
{
	
}

void JsonShaderComponent::addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& requirements, onyx::Shaders::ValueBag&)
{
	requirements.mergeRequirements(mBaseShaderRequirements);
}

void JsonShaderComponent::assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const & reqs)
{
	for (auto &chunk : mShaderChunks)
	{
		if (!chunk.mConditional.hasConditional())
		{
			chunks.push_back(chunk);
			continue;
		}

		if (!chunk.mConditional.passes(reqs))
			continue;

		//we need to add it at least once, but may want to do so multiple times
		int count = 1;
		if (reqs.hasInt(chunk.mConditional.forThisIntTimes))
		{
			count = bx::max(count, reqs.getInt(chunk.mConditional.forThisIntTimes));
		}

		//add it proper number of times, replacing any instance of %i with this iterator number, ie uv%i becomes uv0, uv1, uv2...
		for (int j = 0; j < count; j++)
		{
			auto replacedChunk = chunk;
			std::string s = chunk.mData;
			std::string num = std::to_string(j);
			size_t n = s.find(chunk.mConditional.loopReplaceValue);
			while (n != std::string::npos)
			{
				s.replace(n, chunk.mConditional.loopReplaceValue.length(), num);
				n = s.find(chunk.mConditional.loopReplaceValue);
			}
			replacedChunk.mData = s;
			chunks.push_back(replacedChunk);
		}
	}
}

std::vector<ShaderParam*> JsonShaderComponent::getShaderParams(onyx::Shaders::ValueBag const&, bool)
{
	std::vector<ShaderParam*> p;
	for (size_t i = 0; i < mShaderParams.size(); i++)
	{
		p.push_back(new ShaderParam(mShaderParams[i]));
	}
	return p;
}
