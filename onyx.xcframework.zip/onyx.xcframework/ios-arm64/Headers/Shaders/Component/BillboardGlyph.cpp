#include "BillboardGlyph.h"
#include "../ShaderEnums.h"
#include "../ShaderManager.h"

BillboardGlyph::BillboardGlyph()
{
	mShaderName = BillboardGlyph::ComponentName;
	mIntConfigurations.push_back("GlyphCount");

	mDefaultConfiguration.setParam("GlyphCount", RequiredTextures);
}

void BillboardGlyph::addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& reqs, onyx::Shaders::ValueBag &params)
{
	reqs.addUV = 1;
	if (params.hasInt("GlyphCount"))
	{
		reqs.addColor = params.getInt("GlyphCount");
	}
}

void BillboardGlyph::assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const & config)
{
	int firstTexCoord = 0,
		lastTexCoord = RequiredTextures - 1;

	int colorCount = config.getColorCount();

	mInputs.clear();
	mOutputs.clear();

	for (int i = 0; i < RequiredTextures; i++)
	{
		onyx::Shaders::Components::ShaderDataSource input, output;

		input.alias = "texcoord" + std::to_string(i);
		input.dataType = ShaderParamType::isVec4;
		mInputs.push_back(input);

		output.alias = "texcoord" + std::to_string(i);
		output.dataType = ShaderParamType::isVec4;
		mOutputs.push_back(output);
	}
	
	for (int i = 0; i < colorCount; ++i)
	{
		onyx::Shaders::Components::ShaderDataSource input, output;

		input.alias = "color" + std::to_string(i);
		input.dataType = ShaderParamType::isVec4;
		mInputs.push_back(input);

		output.alias = "color" + std::to_string(i);
		output.dataType = ShaderParamType::isVec4;
		mOutputs.push_back(output);
	}

	std::string blendFunc = R"(vec4 BlendTextures(vec4 color0)";
	for (int i = 1; i < config.getColorCount(); i++)
	{
		blendFunc += ", vec4 color" + std::to_string(i);
	}

	blendFunc += ", vec2 uv0";
	for (int i = 1; i <= lastTexCoord; i++)
	{
		blendFunc += ", vec2 uv" + std::to_string(i);
	}
	
	blendFunc += ")";

	blendFunc += "\n{\n  vec4 tex = vec4(0.0, 0.0, 0.0, 0.0);\n";
	blendFunc += "  vec4 color = vec4(0.0, 0.0, 0.0, 0.0);\n";
	
	for (int texI = 0; texI < RequiredTextures; texI++)
	{
		std::string var = "u_ScaleOffsetTex" + std::to_string(texI);

		blendFunc += "  {\n  vec2 modUV = " + var + ".xy + uv" + std::to_string(texI) + " * " + var + ".zw; \n";

		blendFunc += "  tex = texture2D(s_texture" + std::to_string(texI) + ", modUV);\n";

		blendFunc += "  vec3 expanded = tex.xyz * 2.0 - 1.0;\n";
		for (int i = 0; i < colorCount; i++)
		{
			switch (i)
			{
				case 0:		blendFunc += "  float control0 = abs(min(expanded.x, 0.0));\n";		break;	// color 0, black in R
				case 1:		blendFunc += "  float control1 = abs(min(expanded.y, 0.0));\n";		break;	// color 1, black in G
				case 2:		blendFunc += "  float control2 = max(expanded.x, 0.0);\n";			break;	// color 2, white in R
				case 3:		blendFunc += "  float control3 = max(expanded.y, 0.0);\n";			break;  // color 3, white in G
			}
		}
			
		//lerp the colors together
		for (int i = 0; i < colorCount; i++)
		{
			switch (i)
			{
				case 0:		blendFunc += "  vec4 mixed = color0 * control0;\n";					break;
				case 1:		blendFunc += "  mixed = mix(mixed, color1, control1);\n";			break;
				case 2:		blendFunc += "  mixed = mix(mixed, color2, control2);\n";			break;
				case 3:		blendFunc += "  mixed = mix(mixed, color3, control3);\n";			break;
			}
		}
			
		blendFunc += "  float alpha = min(tex.a, mixed.a);\n";
		blendFunc += "  color.xyz = mix(color.xyz, mixed.xyz, alpha);\n";
		blendFunc += "  color.a += alpha;\n";

		blendFunc += "  }\n";
	}
	blendFunc += "  color.a = min(1.0, color.a);\n";
	blendFunc += "  return color;\n}\n\n";
	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Functions, blendFunc));

	std::string blendCall = R"(fragColor = BlendTextures()";
	blendCall += "color0";
	for (int i = 1; i < colorCount; i++)
	{
		blendCall += ", color" + std::to_string(i);
	}

	for (int i = firstTexCoord; i <= lastTexCoord; i++)
	{
		blendCall += ", texcoord" + std::to_string(i) + ".xy";
	}
	blendCall += ");";
	
	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Main, blendCall));
}

std::vector<ShaderParam*> BillboardGlyph::getShaderParams(onyx::Shaders::ValueBag const& config, bool getCurrentUniform)
{
	std::vector<ShaderParam*> params = IShaderComponent::getShaderParams(config, getCurrentUniform);
	
	for (int i = 0; i < config.getInt("GlyphCount"); i++)
	{
		ShaderParam* p = new ShaderParam();
		p->mName = "s_texture" + std::to_string(i);
		p->mType = ShaderParamType::isTexture;
		p->mComponentName = mShaderName;
		params.push_back(p);

		ShaderParam* p2 = new ShaderParam();
		p2->mName = "u_ScaleOffsetTex" + std::to_string(i);
		p2->mType = ShaderParamType::isVec4;
		p2->mComponentName = mShaderName;
		params.push_back(p2);
	}

	return params;
}