#ifndef JSONSHADERCOMPONENT_H_
#define JSONSHADERCOMPONENT_H_

#include <string>
#include <bx/math.h>

#include "IShaderComponent.h"
#include "Shaders/ShaderUniform.h"

class JsonShaderComponent : public IShaderComponent
{
public:
	JsonShaderComponent();
	void assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const & reqs) override;
	std::vector<ShaderParam*> getShaderParams(onyx::Shaders::ValueBag const& config, bool getCurrentUniform) override;
	void addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& requirements, onyx::Shaders::ValueBag& params) override;
};
#endif
