#ifndef ISHADERCOMPONENT_H_
#define ISHADERCOMPONENT_H_

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <Warnings.h>

#include "Shaders/ShaderEnums.h"
#include "Shaders/ShaderParameters.h"
#include "ShaderChunk.h"
#include "Shaders/ShaderUniform.h"
#include "Shaders/BaseShaderRequirements.h"
#include "ShaderDataSource.h"

class BaseShader;

class IShaderComponent
{
public:
	typedef std::shared_ptr<IShaderComponent> shared_ptr_t;

	IShaderComponent() {}

	virtual void assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const & reqs) = 0;
	virtual void assembleFromJson(std::string jsonString);

	virtual int getSortOrder() const { return mSortOrder; };
	virtual void setSortOrder(uint32_t sortOrder) { mSortOrder = sortOrder; }

	std::string mShaderName;	// NOTE: misnamed -- should be mComponentName
	static const char sVarDelimiter = '-';
	static const char sComponentDelimiter = '_';

	//non changing parameters set by the signature. Note, updates to what the class expects here will break old signatures and require a rebuild of shaders
	virtual void addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& requirements, onyx::Shaders::ValueBag& params) = 0;
	virtual ~IShaderComponent() {}

	std::vector<ShaderParam> mShaderParams;

DISABLE_WARNING_PUSH
DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
	virtual std::vector<ShaderParam*> getShaderParams(onyx::Shaders::ValueBag const& config, bool getCurrentUniform = false)
	{
		std::vector<ShaderParam*> params;

		for (auto& b : mBoolConfigurations)
		{
			ShaderParam* p = new ShaderParam();
			p->mName = b;
			p->isRealtimeUniform = false;
			p->mType = ShaderParamType::isBool;
			
			if (config.hasBool(b))
				p->mBool = config.getBool(b);
			else
				p->mBool = mDefaultConfiguration.getBool(b);

			p->mComponentName = mShaderName;
			params.push_back(p);
		}

		for (auto& i : mIntConfigurations)
		{
			ShaderParam* p = new ShaderParam();
			p->mName = i;
			p->isRealtimeUniform = false;
			p->mType = ShaderParamType::isInt;
			
			if (config.hasInt(i))
				p->mInt = config.getInt(i);
			else
				p->mInt = mDefaultConfiguration.getInt(i);

			p->mComponentName = mShaderName;
			params.push_back(p);
		}

		return params;
	}
DISABLE_WARNING_POP

	virtual std::string getSignature(onyx::Shaders::ValueBag const &params)
	{
		std::string s = mShaderName;
		for (const auto &b : mBoolConfigurations)
		{
			bool value = false;
			if (params.hasBool(b))
				value = params.getBool(b);
			else
				value = mDefaultConfiguration.getBool(b);

			std::string r = (value ? "T" : "F");
			s += sVarDelimiter + r;
		}

		for (const auto &i : mIntConfigurations)
		{
			int value = 0;
			if (params.hasInt(i))
				value = params.getInt(i);
			else
				value = mDefaultConfiguration.getInt(i);

			s += sVarDelimiter + std::to_string(value);
		}

		return s;
	}

	virtual void setConfigFromSignature(std::string sig, onyx::Shaders::ValueBag & paramBag);

	virtual onyx::Shaders::ValueBag getParamsFromSignature(std::string sig)
	{
		onyx::Shaders::ValueBag result;
		
		setConfigFromSignature(sig, result);
		
		return result;
	}

	static std::string getSigFromComponents(std::vector<shared_ptr_t> const& components, onyx::Shaders::ValueBag const &baseConfig)
	{
		onyx::Shaders::BaseShaderRequirements reqs;
		std::string result;

		onyx::Shaders::ValueBag config;
		config.merge(baseConfig);

		for (auto const & component : components)
		{
			component->addToBaseRequirements(reqs, config);
		}

		config.addBaseRequirements(reqs);

		for (auto const & component : components)
		{
			if (result.size() != 0)
				result += sComponentDelimiter;
			result += component->getSignature(config);
		}

		return result;
	}

	bool operator <(const IShaderComponent& comp) const
	{
		return getSortOrder() < comp.getSortOrder();
	}

public:
	
	std::vector<ShaderChunk> mShaderChunks;
	std::vector<std::string> mBoolConfigurations;
	std::vector<std::string> mIntConfigurations;
	std::vector<onyx::Shaders::Components::ShaderDataSource> mInputs,
		mOutputs;

	onyx::Shaders::ValueBag mDefaultConfiguration;

	onyx::Shaders::BaseShaderRequirements mBaseShaderRequirements;

	bool firstInit = true;

private:
	uint32_t	mSortOrder = 1;
};

#endif