#include "TextureLayer.h"
#include "../ShaderEnums.h"

TextureLayer::TextureLayer()
{
	mShaderName = "TextureLayer";
	mIntConfigurations.push_back("TextureCount");
	mDefaultConfiguration.setParam("TextureCount", 1);

	mBaseShaderRequirements.uv0 = true;
}

void TextureLayer::addToBaseRequirements(onyx::Shaders::BaseShaderRequirements& reqs, onyx::Shaders::ValueBag& /*params*/)
{
	reqs.enableUV0(true);
}

void TextureLayer::assembleChunks(std::vector<ShaderChunk>& chunks, onyx::Shaders::ValueBag const& config)
{
	auto texCount = config.getInt("TextureCount");

	mInputs.clear();
	mOutputs.clear();

	onyx::Shaders::Components::ShaderDataSource input, output;

	std::string blendFunc = R"(vec4 BlendTextures(vec4 color, vec2 uv))"
							"\n{\n"
							"	vec4 tex = vec4(0.0, 0.0, 0.0, 0.0);\n";
	
	//by doing the for loop here, we can avoid loops actually in the shader to be unrolled
	for (int i = 0; i < texCount; i++)
	{
		std::string var = "u_ScaleOffsetTex" + std::to_string(i);
		blendFunc += "\t{\nvec2 modUV = " + var + ".xy + uv * " + var + ".zw;\n";
		blendFunc += "\ttex = texture2D(s_texture" + std::to_string(i) + ", modUV);\n";
		blendFunc += "\tcolor.xyz = mix(color.xyz, tex.xyz, tex.a);\n";
		blendFunc += "\tcolor.a += tex.a;\n\t}\n";
	}
	blendFunc += "	return color;\n}\n\n";

	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Functions, blendFunc));
	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Main, "fragColor = BlendTextures(fragColor, texcoords.xy);")); //need to consider if we need a flag for adding/multiplying instead of just setting here maybe

	// handy way to draw tile boundaries
	//if (texCount > 1)
	//{
	//	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Compose, "float uStrength = levelSets(texcoords.x, 1.0, 0.0, 0.0, 1.0, 2.0);"));
	//	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Compose, "float vStrength = levelSets(texcoords.y, 1.0, 0.0, 0.0, 1.0, 2.0);"));
	//	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Compose, "float lineStrength = max(uStrength, vStrength);"));
	//	chunks.push_back(ShaderChunk(ShaderEnums::ShaderType::Pixel, ShaderEnums::ShaderInsertPosition::Compose, "gl_FragData[0].xyz = mix(gl_FragData[0].xyz, vec3(1.0, 0.0, 0.0), lineStrength);"));
	//}
}

void TextureLayer::setTextureCount(onyx::Shaders::ValueBag& config, int t)
{
	mBaseShaderRequirements.uv0 = t > 0;

	config.setParam("TextureCount", t);
}

std::vector<ShaderParam*> TextureLayer::getShaderParams(onyx::Shaders::ValueBag const& config, bool getCurrentUniform)
{
	std::vector<ShaderParam*> params = IShaderComponent::getShaderParams(config, getCurrentUniform);

	for (int i = 0; i < config.getInt("TextureCount"); i++)
	{
		ShaderParam* p = new ShaderParam();
		p->mName = "s_texture" + std::to_string(i);
		p->mType = ShaderParamType::isTexture;
		p->mComponentName = mShaderName;
		p->mIsAnisoFilter = true;
		params.push_back(p);

		ShaderParam* p2 = new ShaderParam();
		p2->mName = "u_ScaleOffsetTex" + std::to_string(i);
		p2->mType = ShaderParamType::isVec4;
		p2->mComponentName = mShaderName;
		params.push_back(p2);
	}

	return params;
}

std::string TextureLayer::getSignature(onyx::Shaders::ValueBag const& params)
{
	return IShaderComponent::getSignature(params);
}