#ifndef SHADERCOMPONENTS_H_
#define SHADERCOMPONENTS_H_
//list all shader components here for an easy way to include everything elsewhere
#include "Component/IShaderComponent.h"
#include "Component/JsonShaderComponent.h"
#include "Component/TextureLayer.h"
#include "Component/BillboardGlyph.h"
#endif