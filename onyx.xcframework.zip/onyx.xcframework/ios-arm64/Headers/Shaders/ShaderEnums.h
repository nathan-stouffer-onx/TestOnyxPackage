#ifndef SHADERENUMS_H_
#define SHADERENUMS_H_

#include <string>
#include <algorithm>
#include <unordered_map>
#include <System/Map3DException.h>
#include <Utils/EnumUtils.h>

namespace ShaderEnums
{
	enum class ShaderType
	{
		Invalid = 0x0,
		Vertex = 0x1,
		Pixel = 0x2,
		Instanced = 0x04 | Vertex,
		Vertex_and_Pixel = Vertex | Pixel,
		Instanced_and_Pixel = Instanced | Pixel
	};

	enum class ShaderInsertPosition
	{
		INVALID = -1,
		Includes = 100, //at the top for file includes
		Samplers = 200, //we have to make sure they're set to the right registers
		CubeSamplers = 300,
		Definitions = 400, //right after includes
		Functions = 500, //functions, before main
		Main = 600, //at the start of the main
		Lighting = 700, //after composition, apply lighting effects
		Compose = 800 //at the end of main where we calculate the final outputs
	};

	enum class ConfigurableShaders //todo - better name?
	{
		Terrain,
		SimpleTexture,
		DebugColor,
		TerrainDepth,
		Billboard,
		BillboardFixedSize,
		Picking,
		Line,
		FontSDF,
		TerrainCubemapDepth,
		TerrainVSMDepth,
		Vector,
		Skydome,
		VectorLine,
		TerrainLine,
		TerrainVector,
		TrackerPuck,
		GaussianBlur,
		Icon,
		Count
	};

	static const char* ConfigurableShaderNames[] =
	{
		"Terrain",
		"SimpleTexture",
		"DebugColor",
		"TerrainDepth",
		"Billboard",
		"BillboardFixedSize",
		"Picking",
		"Line",
		"FontSDF",
		"TerrainCubemapDepth",
		"TerrainVSMDepth",
		"Vector",
		"Skydome",
		"VectorLine",
		"TerrainLine",
		"TerrainVector",
		"TrackerPuck",
		"GaussianBlur",
		"Icon"
	};

	template <typename T>
	__inline
	T fromString(std::string const &/* name */)
	{

	}

	inline std::string toString(ShaderInsertPosition const value)
	{
		switch (value)
		{
		case ShaderInsertPosition::Includes:
			return "Includes";
		case ShaderInsertPosition::Samplers:
			return "Samplers";
		case ShaderInsertPosition::CubeSamplers:
			return "CubeSamplers";
		case ShaderInsertPosition::Definitions:
			return "Definitions";
		case ShaderInsertPosition::Functions:
			return "Functions";
		case ShaderInsertPosition::Main:
			return "Main";
		case ShaderInsertPosition::Lighting:
			return "Lighting";
		case ShaderInsertPosition::Compose:
			return "Compose";
		default:
			return "INVALID";
		}
	}

	static std::unordered_map<std::string, ShaderType> sShaderTypeNameMap =
	{
		{ "vertex",					ShaderType::Vertex },
		{ "pixel",					ShaderType::Pixel },
		{ "instanced",				ShaderType::Instanced },
		{ "vertex_and_pixel",		ShaderType::Vertex_and_Pixel },
		{ "instanced_and_pixel",	ShaderType::Instanced_and_Pixel },
	};

	template<>
	__inline
	ShaderType fromString(std::string const& name)
	{
		return onyx::Utils::typeFromMap(name, sShaderTypeNameMap, "enum ShaderEnums::ShaderType");
	}

	static std::unordered_map<std::string, ShaderInsertPosition> sComponentNameMap =
	{
		{ "compose", ShaderInsertPosition::Compose },
		{ "lighting", ShaderInsertPosition::Lighting },
		{ "main", ShaderInsertPosition::Main },
		{ "functions", ShaderInsertPosition::Functions },
		{ "definitions", ShaderInsertPosition::Definitions },
		{ "cubesamplers", ShaderInsertPosition::CubeSamplers },
		{ "samplers", ShaderInsertPosition::Samplers },
		{ "includes", ShaderInsertPosition::Includes }
	};

	template<>
	__inline
	ShaderInsertPosition fromString(std::string const &name)
	{
		return onyx::Utils::typeFromMap(name, sComponentNameMap, "enum ShaderEnums::ShaderInsertPosition");
	}

}
#endif
