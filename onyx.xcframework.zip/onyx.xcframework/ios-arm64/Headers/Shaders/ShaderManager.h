#ifndef SHADERBUILDER_H_
#define SHADERBUILDER_H_

#include <string>
#include <vector>
#include <map>
#include <3rdParty/nlohmann/json.hpp>
#include <System/Map3DException.h>
#include <System/FileSystem.h>

#include "ShaderComponents.h"
#include "ShaderEnums.h"
#include "ShaderParameters.h"
#include "ConfigurableShader.h"
#include "ShaderDefinition.h"

MAP3D_EXCEPTION_TYPE(ShaderManagerException)

class ShaderManager
{
public:

	struct Defaults
	{
		static constexpr char Terrain[] = "BaseShader-T-T-T-F-T-0-1_TextureLayer-N_Fog_VertHeight";
		static constexpr char SimpleTexture[] = "BaseShader-T-T-T-F-T-0-1_TextureLayer-N";
		static constexpr char DebugColor[] = "BaseShader-F-T-F-F-T-1-0_VertColor-0";
		static constexpr char TerrainDepth[] = "BaseShader-F-T-F-F-T-0-1_VertHeight";
		static constexpr char BillboardFixedSize[] = "ColorOnlyQuatBase-F-T-T-T-F-4-1_Billboard-T-T-F-F_BillboardGlyph";
		static constexpr char Picking[] = "BaseShader-F-T-F-F-T-0-1_VertColor-1";
		static constexpr char Line[] = "BaseShader-T-T-T-F-T-1-1_Fog_Line";
		static constexpr char FontSDF[] = "BillboardBase-F-T-F-F-T-3-3_SDF-F-F";
		static constexpr char TerrainCubemapDepth[] = "BaseShader-F-T-F-F-T-0-1_VertHeight_DepthWrite-F";
		static constexpr char TerrainVSMDepth[] = "BaseShader-F-T-F-F-T-0-1_VertHeight_DepthWrite-T";
		static constexpr char Vector[] = "BaseShader-F-T-T-F-T-0-1_Fog_TextureLayer-1_Vector-T_VectorHeight";
		static constexpr char Skydome[] = "Skydome"; 
		static constexpr char VectorLine[] = "LineBase-T-F-F-F-F-0-0";
		static constexpr char TerrainLine[] = "TileLineBase-T-T-F-F_TerrainHeight";
		static constexpr char TerrainVector[] = "TileVectorBase-F_TerrainHeight";
		static constexpr char TrackerPuck[] = "ColorOnlyQuatBase-F-F-T-T-T-3-1_FixedSize-T_DepthBias_BillboardGlyph";
		static constexpr char GaussianBlur[] = "BaseShader-F-T-F-F-T-0-1_GaussBlur";
		static constexpr char Icon[] = "IconBase-T-T-F-0-1_TextureLayer-1_FixedSize-F_IconBillboard_DepthBias_TerrainHeight";
		//static constexpr char IconBillboard[] = "IconBase-T-T-F-0-1_TextureLayer-1_IconBillboard_FixedSize-F_DepthBias_TerrainHeight";
		//static constexpr char IconOrient[] = "IconBase-T-T-T-0-1_TextureLayer-1_FixedSize-F_DepthBias_TerrainHeight";
	};

	struct CombinerSegment
	{
		struct ComponentConfiguration {
			IShaderComponent::shared_ptr_t component;
			onyx::Shaders::ValueBag configuration;
		};
		enum class CombinationType
		{
			Combinations, // for example: calculate all combinations from a given set of 5, ie factorial of 5 total results 
			PickOne, //only one of the group used per variation
			Unknown
		};
		std::vector<CombinerSegment> pickFromSegments; //if this has entries, we generate with one of each of these segments generated, not all of them
		std::vector<ComponentConfiguration> componentConfigurations;
		CombinationType comboType = CombinationType::Unknown;
		bool includeNone = false; //have a variation that has none of these options
	};


	typedef CombinerSegment::ComponentConfiguration component_config_t;

	~ShaderManager();

	std::vector<std::string> loadSignatures(std::string const& path = "assets/shaders/signatures.txt");
	void addShaderSignatures(std::vector<std::string> const &signatures);
	void loadShaders();
	onyx::Shaders::ValueBag getParamsFromSig(std::string sig);
	std::vector<IShaderComponent::shared_ptr_t> getComponentsFromSig(std::string sig);
	std::string buildShaderFromSig(std::string sig, ShaderEnums::ShaderType type);
	std::vector<std::string> calculateVariations(std::vector<CombinerSegment>& combos); //calculates all the possible signatures from a given set of ruled components
	std::vector<ShaderParam*> collectAllPossibleParameters();

	void toggleComponent(ShaderEnums::ConfigurableShaders shader, std::string const& component, bool on);
	void setCurrentShaderByParams(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*> &params, onyx::Shaders::ValueBag const& configuration);
	void loadShaderBySig(ShaderEnums::ConfigurableShaders shader, std::string sig);
	void setParameter(ShaderParam* param);

	template <class T>
	void setAllShaderUniforms(std::string uniformName, T value)
	{
		for (int i = 0; i < (int)ShaderEnums::ConfigurableShaders::Count; i++)
		{
			ShaderParam* sp = ShaderManager::Instance()->getParameter((ShaderEnums::ConfigurableShaders)i, uniformName);
			if (sp != nullptr)
			{
				sp->setValue(value);
			}
		}
	}

	ShaderParam* getParameter(ShaderEnums::ConfigurableShaders shader, const std::string& name, int subset = 0);
	std::vector<ShaderParam*> getActiveParameters(ShaderEnums::ConfigurableShaders shader, int subset = 0);
	std::shared_ptr<onyx::Shaders::ShaderDefinition> getShader(ShaderEnums::ConfigurableShaders shader, int subset);
	bgfx::ProgramHandle getShaderHandle(ShaderEnums::ConfigurableShaders shader, int subset = 0);
	//bgfx::UniformHandle getUniform(ShaderEnums::ConfigurableShaders shader, std::string name, int subset = 0);
	
	static ShaderManager* Instance();

	void getVariationsFromSig(std::vector<std::string>& target, std::string const& sig, int maxCount = 3);
	size_t getSubsetCount(ShaderEnums::ConfigurableShaders shader);
	std::vector<std::string> getComponentList();
	std::vector<IShaderComponent::shared_ptr_t> getComponents();
	IShaderComponent::shared_ptr_t getComponent(std::string name);
	std::vector<ShaderComponentJson> readJsonComponents(std::string const &componentListPath);
	void loadJsonComponents(std::string const &componentListPath = "assets/shaders/json/componentList.json", std::string const &componentPath = "assets/shaders/json/");
	void loadJsonComponents(std::vector<ShaderComponentJson> const& components, std::string const& componentPath);
	void loadJsonComponent(IShaderComponent::shared_ptr_t const& component);
	void loadJsonComponent(std::string const &name, std::string const& componentJson);
	void clearJsonComponents();

	std::vector<ShaderEnums::ConfigurableShaders> getConfiguredShaders();
	std::string getDefaultConfiguration(ShaderEnums::ConfigurableShaders const& shaderType);
	void setDefaultConfiguration(ShaderEnums::ConfigurableShaders const& shaderType, std::string const& shaderSignature);
	IShaderComponent::shared_ptr_t getComponentFromSig(std::string sig);

	nlohmann::json getDebugJson() const;
private:
	ShaderManager();

	bgfx::UniformHandle kInvalidUniform;

	std::vector<std::vector<std::string>> mComponentStrings;

	std::string assembleShader(std::vector<IShaderComponent::shared_ptr_t> components, ShaderEnums::ShaderType shaderType, onyx::Shaders::ValueBag const& params);
	
	std::vector<std::string> mSignaturesRequested; //collects all signatures that we try to use, so we can save a list of which to generate/build
	std::vector<std::string> mAvailableSignatures;  //list of all signatures we have shaders for

	//should find a way to automatically calculate the required ones, rather than just wait until needed
	//needs saved to file

	const std::string mainOpen = "void main()\n{\n";
	const std::string mainClose =	"\n}\n";

	void appendCombos(std::vector<std::vector<CombinerSegment>>& results, std::vector<CombinerSegment> current, std::vector<CombinerSegment>& combos, int id);
	void appendVariations(std::vector<std::string> &results, std::vector<CombinerSegment> &combos, std::vector<component_config_t> const &baseComponents, int id);

	std::map<ShaderEnums::ConfigurableShaders, onyx::Shaders::ConfigurableShader> mActiveShaders;
	std::vector<ShaderParam*> mAllShaderParams;

	std::map<std::string, IShaderComponent::shared_ptr_t> mShaderComponents;
	std::map<ShaderEnums::ConfigurableShaders, std::string> mShaderConfigurations;

protected:
	static ShaderManager* sSingleton;
};

#endif
