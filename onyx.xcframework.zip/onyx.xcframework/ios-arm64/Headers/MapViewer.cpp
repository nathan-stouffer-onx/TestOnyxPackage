#include "MapViewer.h"

#include <cstdlib>
#include <iostream>
#include <functional>

#include <bx/timer.h>
#include <bgfx/bgfx.h>
#include <bgfx/platform.h>
#include <bx/bx.h>
#include <bx/file.h>
#include <bx/string.h>

#include <Utils/UUID.h>
#include <Logging/LogManager.h>
#include <System/Threading.h>

#include <Styling/Parse/StyleJson.h>
#include <Styling/Parse/Factory/LayerFactory.h>
#include <Styling/Parse/Factory/SourceFactory.h>

#include "Caching/Tiles/TileCache.h"
#include "Caching/Tiles/TileRequester.h"
#include "Atlases/TextureAtlas.h"
#include "Height/HeightManager.h"
#include "Tiles/TileMesh.h"
#include "Events/Events.h"
#include "Font/FontManager.h"
#include "Config/ConfigManager.h"
#include "DataObjects/SymbolManager.h"
#include "DataObjects/DashStyleManager.h"
#include "Rendering/VertStructs.h"
#include "Drawers/Drawers.h"
#include "Shaders/ShaderParameters.h"
#include "Shaders/ShaderManager.h"
#include "Utils/jsonConversion.h"
#include "Utils/TextUtils.h"
#include "Utils/Timer.h"
#include "General/RenderTargetManager.h"
#include "Viewport/ViewportManager.h"
#include "Experimental/ParticleSystem.h"

#include <json/ShaderLib.h>

#define VIEWER_TAG "[onyx viewer]"

#if defined(PLATFORM_WINDOWS)
char const* sPlatform = "Windows";
#elif defined(PLATFORM_OSX)
char const* sPlatform = "OSX";
#elif defined(PLATFORM_ANDROID)
char const* sPlatform = "Android";
#elif defined(PLATFORM_IOS)
char const* sPlatform = "iOS";
#elif defined(PLATFORM_EMSCRIPTEN)
char const* sPlatform = "Emscripten";
#else
char const* sPlatform = "Unknown";
#endif

#define ASSERT_INITIALIZED ONYX_DEBUG_ASSERT(mBgfxInitialized, VIEWER_TAG " BGFX is not initialized");

#if !defined(SINGLE_THREAD)

constexpr time_float_t MaxDispatchWaitMS = 100;

#define ASSERT_RENDER_THREAD ONYX_ASSERT(onyx::core::Threading::CurrentThreadId() == mRenderThreadId, "Function must only be called from render thread");

// Macro to wait for the dispatch queue to clear before returning
#define WAIT_DISPATCH_QUEUE \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) { \
	auto waitEndMS = onyx::Utils::Timer::nowMS() + MaxDispatchWaitMS; \
	while (!mPreRenderTasks.empty()) { \
		ONYX_ASSERT(waitEndMS > onyx::Utils::Timer::nowMS(), "Wait for render thread timed out"); \
		std::this_thread::sleep_for(std::chrono::milliseconds(10)); \
} }

// TODO (scott) at some point we might want to just change all of the API function
//				signatures to take a single FuncFooArgs parameter so that the extra
//				argument macros aren't necessary, but this is the cleanest change
//				to make for now.
#define DISPATCH_TASK(FUN) \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) {\
	std::lock_guard lock(mRenderMtx);\
	mPreRenderTasks.push([=]() { this->FUN(); });\
	return; }

#define DISPATCH_TASK1(FUN, param1) \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) {\
	std::lock_guard lock(mRenderMtx);\
	mPreRenderTasks.push([=]() { this->FUN(param1); });\
	return; }

#define DISPATCH_TASK2(FUN, param1, param2) \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) {\
	std::lock_guard lock(mRenderMtx);\
	mPreRenderTasks.push([=]() { this->FUN(param1, param2); });\
	return; }

#define DISPATCH_TASK3(FUN, param1, param2, param3) \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) {\
	std::lock_guard lock(mRenderMtx);\
	mPreRenderTasks.push([=]() { this->FUN(param1, param2, param3); });\
	return; }

#define DISPATCH_VIEWPORT_TASK(FUN, param) \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) {\
	std::lock_guard lock(mRenderMtx);\
	mPreRenderTasks.push([=]() { this->FUN(viewportId, param); });\
	return; }

#define DISPATCH_VIEWPORT_TASK2(FUN, param1, param2) \
if (onyx::core::Threading::CurrentThreadId() != mRenderThreadId) {\
	std::lock_guard lock(mRenderMtx);\
	mPreRenderTasks.push([=]() { this->FUN(viewportId, param1, param2); });\
	return; }

#else
#define WAIT_DISPATCH_QUEUE
#define ASSERT_RENDER_THREAD
#define DISPATCH_TASK(fun)
#define DISPATCH_TASK1(fun, param1)
#define DISPATCH_TASK2(fun, p1, p2)
#define DISPATCH_TASK3(fun, p1, p2, p3)
#define DISPATCH_VIEWPORT_TASK(fun, param)
#define DISPATCH_VIEWPORT_TASK2(fun, param1, param2)

#endif

//TODO scott These ultimately should probably live somewhere else but will work
//			 here as a proof of concept for now.

extern const uint8_t s_robotoRegularTtf[];
extern const size_t s_robotoRegularTtf_size;

extern const uint8_t s_robotoMonoRegularTtf[];
extern const size_t s_robotoMonoRegularTtf_size;

namespace onyx {

int MapViewer::sCurrentFrame = -1;

#define wayptMgr WaypointManager::Instance()
// TODO find a cleaner way to signal that something went wrong. this define just gives us
// an easy way to make sure we always return the same thing. but I think we need to change
// the architecture a bit to use some other signaling method
template<typename T>
static lmath::Vector<T, 3> badVec3() { return lmath::Vector<T, 3>(T(0.0), T(0.0), T(MapMath::cBadHeight)); }
template<typename T>
static lmath::Vector<T, 2> badVec2() { return lmath::Vector<T, 2>(T(-1000.0), T(-1000.0)); }

MapViewer::MapViewer()
{
	logI(VIEWER_TAG " MapViewer starting up.  Build date: %s %s", __DATE__, __TIME__);
#if _DEBUG
	logI(VIEWER_TAG " DEBUG build");
#else
	logI(VIEWER_TAG " RELEASE build");
#endif
	logI(VIEWER_TAG " Handle: 0x%x", (void*) this);
	onyx::Utils::Timer::initialize();
}

MapViewer::~MapViewer()
{
}

int MapViewer::init(lgal::screen::Vector2 const& windowRes, void* window, bgfx::RendererType::Enum rendererType, void* device, bool enableMSAA)
{
	mWindowResolution = windowRes;
	mWindow = window;
	mRendererType = rendererType;
	mDevice = device;
	
	// Initialize bgfx using the native window handle and window resolution.
	mBgfxInit.platformData.nwh = mWindow;
	mBgfxInit.resolution.width = windowRes.x;
	mBgfxInit.resolution.height = windowRes.y;

	mBgfxInit.resolution.reset = enableMSAA ? BGFX_RESET_MSAA_X4 : BGFX_RESET_NONE;
	mBgfxInit.platformData.context = mDevice;
	mBgfxInit.type = mRendererType;
	mBgfxInit.callback = onyx::core::FileSystem::getDefaultCallback();

	bgfx::setPlatformData(mBgfxInit.platformData);

#if defined(SINGLE_THREAD)
	return startup();
#else
	return 0;
#endif
}

int MapViewer::startup()
{
	auto width = mWindowResolution.x;
	auto height = mWindowResolution.y;
	logI(VIEWER_TAG " Starting Up (%s); %d x %d", sPlatform, width, height);

	if (!bgfx::init(mBgfxInit))
	{
		return 1;
	}

	mBgfxInitialized = true;

	DataObjects::DashStyleManager::add("solid", { 0xFF });
	DataObjects::DashStyleManager::add("dotted", { 64 + 16 + 4 + 1 });
	DataObjects::DashStyleManager::add("dashed", { 0x0F });

	Rendering::VertStructs::initialize();
	Utils::Timer::initialize();
	lucid::core::Profiler::initialize();

	mPrevTimeMS = Utils::Timer::nowMS();

	logI(VIEWER_TAG " initializing fonts");

	FontManager::FontConfiguration config;

	config.fileName = "roboto regular";
	config.fontBytes = s_robotoRegularTtf;
	config.fontDataSize = s_robotoRegularTtf_size;

	config.typefaceIndex = 0;
	config.pixelSize = 12;
	config.fontType = FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE;
	config.glyphWidthPadding = (6 + 2);
	config.glyphHeightPadding = (6 + 2);

	Font::M3DFontManager::initialize(config);
	Font::M3DFontManager::addFontConfig({ "topoLabel", FONT_TYPE_DISTANCE_OUTLINE, 9 }, "default");
	Font::M3DFontManager::addTTF("roboto mono", s_robotoMonoRegularTtf, s_robotoMonoRegularTtf_size);

	logI(VIEWER_TAG " initializing default viewports");
	// TODO maybe move to platform?
	mViewportManager.init(width, height);
	mViewportManager.addViewport(ViewportManager::sMainViewportId, 1.0f, 1.0f, -1);

	mInitialized = true;

	logI(VIEWER_TAG " initialization complete");

	return 0;
}

void MapViewer::resize(uint32_t width, uint32_t height)
{
	bgfx::reset(width, height, mBgfxInit.resolution.reset);
	mViewportManager.setScreenSize(width, height);
}

void MapViewer::setWindowResolution(lgal::screen::Vector2 const& res)
{
	if (res == mWindowResolution)
	{
		return;
	}
	ONYX_ASSERT(res.x > 0 && res.y > 0
		&& res.x <= 16384 && res.y <= 16384, "Invalid resolution requested") // 16k should be enough for anybody
	mWindowResolution = res;
	mResolutionChanged = true;
}

lucid::math::Vector<uint32_t, 2> MapViewer::getScreenSize() const
{
	return mViewportManager.getScreenSize();
}

void MapViewer::setController(viewportId_t viewportId, std::shared_ptr<Camera::CameraController> controller)
{
	DISPATCH_VIEWPORT_TASK(setController, controller);

	mViewportManager[viewportId]->setController(controller);
}

void MapViewer::render()
{
	if (!mInitialized)
	{
		logE(VIEWER_TAG " render API is not initialized; init() has not been called");
		return;
	}

	LUCID_PROFILER_FRAME();

	{
		LUCID_PROFILE_SCOPE("render");

		auto timeMS = Utils::Timer::nowMS();
		auto timeStepMS = timeMS - mPrevTimeMS;
		mPrevTimeMS = timeMS;

		lgal::gpu::Vector3 timeVec((float)timeMS, (float)timeStepMS, 0);

		ShaderManager::Instance()->setAllShaderUniforms("u_time", timeVec);

		// reset view ids for render passes
		Rendering::ViewId::reset();
		// reset the blit count in all atlases
		Atlases::BlitCap::Reset();

		{
			LUCID_PROFILE_SCOPE("cache update");
			Caching::TileCache::Instance()->update();
		}

		{
			LUCID_PROFILE_SCOPE("input update");
			mInput->update(timeMS, mViewportManager);
			WaypointManager::Instance()->update();
		}

		{
			LUCID_PROFILE_SCOPE("viewport update");
			mViewportManager.update(timeMS);
			mViewportManager.drawViewportsToScreen();
		}

		{
			LUCID_PROFILE_SCOPE("rtt update");
			RenderTargetManager::Instance()->update();
		}

		{
			LUCID_PROFILE_SCOPE("ParticleSystem update");
			Experimental::ParticleSystem::update(timeStepMS);
		}
	}

	bgfx::dbgTextClear();
	uint16_t lineNum = 2;
	if (mShowDebugInfo)
	{
		lineNum = writeDebugInfo(0, lineNum);
	}

	if (mShowProfiling)
	{
		bgfx::dbgTextPrintf(0, lineNum++, 0x4F, "Profiling:");
		auto prof = lucid::core::Profiler::instance();
		auto sample = prof->samples();

		bool log = false;
		if (mFrameTimeHistorySeconds.primed())
		{
			auto avg = mFrameTimeHistorySeconds.avg();
			bgfx::dbgTextPrintf(20, lineNum++, 0x4F, "%0.3fms avg frame time", avg * 1000);

			if (sample->timeTotal > avg * 2.0 && sample->timeTotal > 0.01666) // If we get a frame hitch, report the profile statistics
			{
				logI(VIEWER_TAG " Long-running frame detected; %0.3fms (running avg %0.3fms) ", sample->timeTotal * 1000, avg * 1000);
				log = true;
			}
		}

		writeProfiling(2, lineNum, sample, log);
	}
}

uint16_t MapViewer::writeDebugInfo(uint16_t x, uint16_t y)
{
	// Enable stats or debug text.
	bgfx::setDebug(mShowStats ? BGFX_DEBUG_STATS : BGFX_DEBUG_TEXT);

	// general bgfx info
	const bgfx::Stats* stats = bgfx::getStats();
	bgfx::dbgTextPrintf(x, y++, 0x2f, "Press F1 to toggle stats");
	bgfx::dbgTextPrintf(x, y++, 0x2f, "Backbuffer %dW x %dH in pixels, debug text %dW x %dH in characters", stats->width, stats->height, stats->textWidth, stats->textHeight);
	bgfx::dbgTextPrintf(x, y++, 0x2f, "avg frame time (ms): %f", mFrameTimeHistorySeconds.avg() * 1000.0);
	bgfx::dbgTextPrintf(x, y++, 0x2f, "avg fps: %f", 1.0 / mFrameTimeHistorySeconds.avg());

	return y;
}

uint16_t MapViewer::writeProfiling(uint16_t x, uint16_t y, const lucid::core::Profiler::Sample* sample, bool log)
{
	auto callTime = sample->onlyParent->timeTotal;
	uint16_t result = 0;
	if (sample->count > 0)
	{
		uint8_t color = 0x3a;
		if (callTime == 0) { color = 0x3f; }
		else if (callTime * 0.75 < sample->timeTotal) { color = 0x3c; }
		else if (callTime * 0.5 < sample->timeTotal) { color = 0x3e; }
		else if (callTime * 0.25 < sample->timeTotal) { color = 0x3a; }
		++result;

		auto totalMs = sample->timeTotal * 1000;
		auto pct = sample->onlyParent->timeTotal > 0 ? (sample->timeTotal / sample->onlyParent->timeTotal) * 100.0 : 100;
		if (log)
		{
			std::stringstream tabBuilder;

			for (int i = 0; i < x / 2; ++i)
			{
				tabBuilder << '\t';
			}

			auto tabs = tabBuilder.str();
			logI(VIEWER_TAG  "%s%s: %0.5fms\t(%d)\t%0.2f%%", tabs.c_str(), sample->name, totalMs, sample->count, pct);
		}

		bgfx::dbgTextPrintf(x, y, 0x3F, "%s:", sample->name);
		bgfx::dbgTextPrintf(x + 32, y, color, "%0.5fms (%d)", totalMs, sample->count);
		bgfx::dbgTextPrintf(x + 50, y, color, "%0.2f%%", pct);

		if (sample->firstChild != nullptr && sample->firstChild->count > 0)
		{
			result += writeProfiling(x + 2, y + 1, sample->firstChild, log);
		}
	}
	if (sample->nextSibling != nullptr)
	{
		result += writeProfiling(x, y + result, sample->nextSibling, log);
	}
	return result;
}

void MapViewer::finishFrame()
{
	// Advance to next frame. Process submitted rendering primitives.
	sCurrentFrame = bgfx::frame();

	// compute frame time
	// QUESTION: do we need to rework this for the multithreaded render?
	auto endMS = Utils::Timer::nowMS();
	auto durationSeconds = (endMS - mPrevTimeMS) / 1000.0;

	mFrameTimeHistorySeconds.insert(durationSeconds);

	Events::trigger(Events::EventType::FRAME);

	if (mFrameTimeHistorySeconds.primed())
	{
		// if we are well above the average and above 25 ms, trigger a long frame event
		if (durationSeconds > 2.0 * mFrameTimeHistorySeconds.avg() && durationSeconds > 0.025)
		{
			Events::trigger(Events::EventType::LONG_FRAME);
		}
	}
}

void MapViewer::startRenderThread()
{
	logI("Initializing render thread");
	ONYX_ASSERT(mRenderThread == nullptr, "Render thread is already running");

	mRenderThread = std::make_unique<std::thread>(RenderThreadFunc, this);
	std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	
	ONYX_ASSERT(mIsRenderThreadRunning, "Render thread did not start running!");
	mRenderThreadState = RenderThreadStates::RUNNING;
}

void MapViewer::killRenderThread()
{
	if (mRenderThread != nullptr)
	{
		mIsRenderThreadRunning = false;
		mRenderThread->join();
		mRenderThread.reset();
	}
}

bool MapViewer::renderFrame()
{
	bool result = true;
	ONYX_TRY
		if (!mPreRenderTasks.empty())
		{
			std::lock_guard lock(mRenderMtx);
			while (!mPreRenderTasks.empty())
			{
				// TODO (scott) Should we try/catch each of these independently?  Add time budget here?
				ThreadSafeTaskT task = std::move(mPreRenderTasks.front());
				mPreRenderTasks.pop();
				task();
			}
		}

		ONYX_FINALLY([&]() {
			result = INVOKE(mFrameEndCallback);
		});

		if (mResolutionChanged)
		{
			resize(mWindowResolution.x, mWindowResolution.y);
			mResolutionChanged = false;
		}

		if (!INVOKE(mFrameStartCallback))
		{
			return false;
		}

		if (INVOKE(mFrameStartCallback))
		{
			render();
		}

		if (mShowDebugUI)
		{
			INVOKE(mRenderDebugUICallback);
		}

		finishFrame();

	// TODO (scott) Add error signaling here?
	ONYX_CATCH
		logE(VIEWER_TAG + ex.summarize());
		return true;
	ONYX_CUSTOM_CATCH(std::exception)
		logE(std::string(VIEWER_TAG) + ex.what());
		return true;
	ONYX_CATCH_ALL
		logE(VIEWER_TAG " unrecognized exception caught");
		return true;
	ONYX_END_CATCH
	return result;
}

int32_t MapViewer::RenderThreadFunc(MapViewer* self)
{
	ONYX_FINALLY([&]() {
		self->mRenderThreadState = RenderThreadStates::TERMINATED;
		});

	onyx::core::Threading::setPriority(onyx::core::Threading::Priority::HIGH);
	onyx::core::Threading::setThreadName(VIEWER_TAG " render thread");
	self->mRenderThreadId = onyx::core::Threading::CurrentThreadId();

	self->mIsRenderThreadRunning = true;

	self->startup();

	logI(VIEWER_TAG " loading shaders");
	self->loadShaders();

	ONYX_TRY

		self->INVOKE(self->mInitDebugUICallback);

		while (self->mIsRenderThreadRunning)
		{
			if (self->mRenderThreadState != RenderThreadStates::RUNNING)
			{
				std::this_thread::sleep_for(std::chrono::milliseconds(100));
			}

			if (!self->renderFrame())
			{
				break;
			}
		}

		// call frame one last time synchronize the bgfx render thread
		bgfx::frame();

		self->INVOKE(self->mShutdownDebugUICallback);

		self->shutdown();

	ONYX_CATCH
		logE(VIEWER_TAG + ex.summarize());
		return 0xBADDEAD0;
	ONYX_CUSTOM_CATCH(std::exception)
		logE(std::string(VIEWER_TAG ) + ex.what());
		return 0xBADDEAD1;
	ONYX_CATCH_ALL
		logE(VIEWER_TAG " unrecognized exception caught");
		return 0xBADDEAD2;
	ONYX_END_CATCH

	logI(VIEWER_TAG " render thread shut down cleanly");

	return 0x600DDEAD;
}

void MapViewer::shutdown()
{
	// clean up singletons

	logI(VIEWER_TAG " --- Shutting down MapViewer ---");
	logI(VIEWER_TAG " Shutting down TileCache");
	Caching::TileCache::Shutdown();

	logI(VIEWER_TAG " Shutting down ShaderManager");
	delete ShaderManager::Instance();

	logI(VIEWER_TAG " Shutting down TileMesh");
	Tiles::TileMesh::Shutdown();

	logI(VIEWER_TAG " Shutting down WaypointManager");
	WaypointManager::Shutdown();

	logI(VIEWER_TAG " Shutting down ParticleSystem");
	Experimental::ParticleSystem::shutdown();

	logI(VIEWER_TAG " Shutting down HeightManager");
	HeightManager::Shutdown();

	logI(VIEWER_TAG " Shutting down DashStyleManager");
	DataObjects::DashStyleManager::Shutdown();

	logI(VIEWER_TAG " Shutting down TextStyleManager");
	Style::TextStyleManager::Shutdown();

	logI(VIEWER_TAG " Shutting down FontManager");
	Font::M3DFontManager::Shutdown();

	logI(VIEWER_TAG " Shutting down RenderTargetManager");
	delete RenderTargetManager::Instance();

	logI(VIEWER_TAG " Shutting down ViewportManager");
	mViewportManager.shutdown();

	logI(VIEWER_TAG " Shutting down FrustumDrawer");
	Drawers::FrustumDrawer::shutdown();

	logI(VIEWER_TAG " Shutting down AABoxDrawer");
	Drawers::AABoxDrawer::shutdown();

	logI(VIEWER_TAG " Shutting down ViewId");
	Rendering::ViewId::shutdown();

	logI(VIEWER_TAG " Shutting down ::events");
	Events::shutdown();

	logI(VIEWER_TAG " Shutting down ConfigManager");
	ConfigManager::Shutdown();

	logI(VIEWER_TAG " Shutting down ::FileSystem");
	core::FileSystem::cleanup();

	logI(VIEWER_TAG " Shutting down ::BgfxUtils");
	BgfxUtils::cleanup();

	logI(VIEWER_TAG " Shutting down ::bgfx");
	bgfx::shutdown();

	logI(VIEWER_TAG " Shutting down Profiler");
	lucid::core::Profiler::shutdown();

	logI(VIEWER_TAG " Shutting down LogManager");
	core::LogManager::Shutdown();
	
	mBgfxInitialized = false;
}

void MapViewer::toggleCulling(viewportId_t viewportId, bool on)
{
	DISPATCH_VIEWPORT_TASK(toggleCulling, on);

	mViewportManager[viewportId]->getState()->setCullingEnabled(on);
}

void MapViewer::setShowStats(bool b)
{
	mShowStats = b;
}

void MapViewer::setStyle(viewportId_t viewportId, std::shared_ptr<Styling::Style> style)
{
	DISPATCH_VIEWPORT_TASK(setStyle, style);

	mViewportManager[viewportId]->setStyle(style);
}

void MapViewer::setStyle(viewportId_t viewportId, std::string const& style)
{
	DISPATCH_VIEWPORT_TASK(setStyle, style);

	std::shared_ptr<Styling::Style> parsed = std::make_shared<Styling::Style>();
	*parsed = nlohmann::json::parse(style);
	mViewportManager[viewportId]->setStyle(parsed);
}

void MapViewer::addSource(viewportId_t viewportId, std::string const& id, std::string const& source)
{
	DISPATCH_VIEWPORT_TASK2(addSource, id, source);
	
	Styling::Style& style = *mViewportManager[viewportId]->getStyle();
	style.addSource(id, Styling::Factory::source(nlohmann::json::parse(source)));
}

void MapViewer::removeSource(viewportId_t viewportId, std::string const& id)
{
	DISPATCH_VIEWPORT_TASK(removeSource, id);

	mViewportManager[viewportId]->getStyle()->removeSource(id);
}

void MapViewer::addLayer(viewportId_t viewportId, std::string const& layer)
{
	DISPATCH_VIEWPORT_TASK(addLayer, layer);

	Styling::Style& style = *mViewportManager[viewportId]->getStyle();
	style.addLayer(Styling::Factory::layer(nlohmann::json::parse(layer)));
}

void MapViewer::addLayer(viewportId_t viewportId, std::string const& layer, std::string const& beforeId)
{
	DISPATCH_VIEWPORT_TASK2(addLayer, layer, beforeId);

	Styling::Style& style = *mViewportManager[viewportId]->getStyle();
	style.addLayer(Styling::Factory::layer(nlohmann::json::parse(layer)), beforeId);
}

void MapViewer::removeLayer(viewportId_t viewportId, std::string const& id)
{
	DISPATCH_VIEWPORT_TASK(removeLayer, id);

	mViewportManager[viewportId]->getStyle()->removeLayer(id);
}

void MapViewer::toggleLayer(viewportId_t viewportId, std::string const& id, std::string const& visibility)
{
	DISPATCH_VIEWPORT_TASK2(toggleLayer, id, visibility);

	Styling::LayoutBase::Visibility parsed = std::fromStringView<Styling::LayoutBase::Visibility>(visibility);
	mViewportManager[viewportId]->getStyle()->toggle(id, parsed);
}

void MapViewer::toggleLayerGroup(viewportId_t viewportId, std::string const& group, std::string const& visibility)
{
	DISPATCH_VIEWPORT_TASK2(toggleLayerGroup, group, visibility);

	Styling::LayoutBase::Visibility parsed = std::fromStringView<Styling::LayoutBase::Visibility>(visibility);
	mViewportManager[viewportId]->getStyle()->toggleGroup(group, parsed);
}


void MapViewer::loadShaders(std::string const& path)
{
	ASSERT_INITIALIZED
	ASSERT_RENDER_THREAD

	logI(VIEWER_TAG " loading shader signatures");
	auto signatures = ShaderManager::Instance()->loadSignatures(path);
	logI(VIEWER_TAG " adding shader %d signatures", signatures.size());
	ShaderManager::Instance()->addShaderSignatures(signatures);
	logI(VIEWER_TAG " loading shaders");
	ShaderManager::Instance()->loadShaders();
	logI(VIEWER_TAG " shaders loaded");
}

std::vector<ShaderParam*> MapViewer::getAllShaderParameters() const
{
	WAIT_DISPATCH_QUEUE

	return ShaderManager::Instance()->collectAllPossibleParameters();
}

void MapViewer::setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*> const& params, Shaders::ValueBag const& configuration)
{
	DISPATCH_TASK3(setShaderParameters, shader, params, configuration);

	ShaderManager::Instance()->setCurrentShaderByParams(shader, params, configuration);
}

std::vector<ShaderParam*> MapViewer::getActiveShaderParameters(ShaderEnums::ConfigurableShaders shader) const
{
	WAIT_DISPATCH_QUEUE

	return ShaderManager::Instance()->getActiveParameters(shader);
}

lgal::world::Vector3 MapViewer::unproject(viewportId_t viewportId, int clickX, int clickY)
{
	return mViewportManager[viewportId]->unprojectPixel(clickX, clickY);
}

lgal::world::Vector3 MapViewer::unproject(viewportId_t viewportId, lgal::world::Vector2 const& pos)
{
	return mViewportManager[viewportId]->unprojectNormalized(2.0 * pos - lgal::world::Vector2{ 1, 1 });
}

lgal::world::Vector2 MapViewer::project(viewportId_t viewportId, lgal::world::Vector2 const& pos)
{
	auto vp = mViewportManager[viewportId];
	if (vp == NULL)
		return badVec2<world_float_t>();

	return vp->project(pos).xy;
}

lgal::world::Vector2 MapViewer::project(viewportId_t viewportId, lgal::world::Vector3 const& pos)
{
	auto vp = mViewportManager[viewportId];
	if (vp == NULL)
		return badVec2<world_float_t>();

	auto normalizedScreenCoords = vp->project(pos);
	return { normalizedScreenCoords.x, normalizedScreenCoords.y };
}

WaypointManager::sharedWaypoint_t MapViewer::addWaypoint(std::string uuidStr, lgal::world::Vector3 const & worldPos, lgal::Color const& color)
{
	Utils::UUID uuid = Utils::uuid(uuidStr);
	return addWaypoint(uuid, worldPos, color);
}

WaypointManager::sharedWaypoint_t MapViewer::addWaypoint(Utils::UUID const& id, lgal::world::Vector3 const & worldPos, lgal::Color const& color)
{
	auto result = WaypointManager::Instance()->addWaypoint(id, worldPos, color);
	mViewportManager.invalidate();
	return result;
}

void MapViewer::moveWaypointTo(viewportId_t viewportId, std::string uuidStr, int pixX, int pixY)
{
	Utils::UUID uuid = Utils::uuid(uuidStr);
	auto pos = mViewportManager[viewportId]->unprojectPixel(pixX, pixY);
	WaypointManager::Instance()->moveWaypointTo(uuid, pos);
	mViewportManager.invalidate();
}

void MapViewer::moveWaypointTo(std::string uuidStr, lgal::world::Vector3 const & pos)
{
	moveWaypointTo(Utils::uuid(uuidStr), pos);
}

void MapViewer::moveWaypointTo(Utils::UUID const& uuid, lgal::world::Vector3 const& pos)
{
	WaypointManager::Instance()->moveWaypointTo(uuid, pos);
	mViewportManager.invalidate();
}

void MapViewer::deleteWaypoint(std::string uuidStr)
{
	Utils::UUID uuid = Utils::uuid(uuidStr);
	deleteWaypoint(uuid);
}

void MapViewer::deleteWaypoint(Utils::UUID const& uuid)
{
	WaypointManager::Instance()->deleteWaypoint(uuid);
	mViewportManager.invalidate();
}

void MapViewer::generateRandomWaypoints(int count)
{
	DISPATCH_TASK1(generateRandomWaypoints, count);

	for (int i = 0; i < count; i++)
	{
		auto uuid = i;
		auto x = float((rand() & 0x7FFF) - 0x3FFF) / float(0x7FFF);
		auto y = float((rand() & 0x7FFF) - 0x3FFF) / float(0x7FFF);
		auto pos = lgal::world::Vector3(x * Tiles::cMaxExtent, y * Tiles::cMaxExtent, 0);
		addWaypoint(uuid, pos, 0xFFFF3300);
	}
}

void MapViewer::setMaxConcurrentTileRequests(size_t maximum)
{
	DISPATCH_TASK1(setMaxConcurrentTileRequests, maximum);

	Caching::TileRequester::Instance()->setMaxInFlight(maximum);
}

void MapViewer::setTileLod(viewportId_t viewportId, float lod)
{
	DISPATCH_VIEWPORT_TASK(setTileLod, lod);

	mViewportManager[viewportId]->getState()->setLODScaler(lod);
}

double MapViewer::tileLoadTimeMS(viewportId_t viewportId) const
{
	auto vp = mViewportManager[viewportId];
	return vp->tileLoadTimeMS();
}

std::vector<Tiles::TileId> MapViewer::recentTiles(double windowMS) const
{
	return Caching::TileCache::Instance()->recentTiles(windowMS);
}

float MapViewer::elevationAt(lgal::world::Vector2 const& pos) const
{
	return HeightManager::Instance()->heightAt(pos, false);
}

void MapViewer::addLabel(lgal::world::Vector3 const & /*pos*/, std::string /*text*/)
{
	//SymbolManager::Instance()->addLabel(pos, text);
}

//gathers a lot of information about the state of everything, and returns it as a big json file - pretty much anything that might be useful to know, we should probably add in here
nlohmann::json MapViewer::getDebugState(viewportId_t viewportId, bool includeTiles, bool /*includeAtlas*/, bool /*includeWaypoints*/, bool includeShaders)
{
	auto* vp = mViewportManager[viewportId];
	auto const& features = vp->getVisibleFeatures();
	auto const& cullRes = features.cullState;
	nlohmann::json j;
	j["Initialized"] = mInitialized;
	j["averageFPS"] = 1.0 / mFrameTimeHistorySeconds.avg();
	j["CurrentFrame"] = sCurrentFrame;
	j["RenderWidth"] = vp->getWidthPixel();
	j["RenderHeight"] = vp->getHeightPixel();
	j["TileTouchedCount"] = cullRes.touched;
	j["TileRenderCount"] = cullRes.tileIds.size();
	j["TileMinVisLevel"] = cullRes.minLevel;
	j["TileMaxVisLevel"] = cullRes.maxLevel;
	j["TileMaxExtents"] = Tiles::cMaxExtent;

	if (includeTiles)
	{
		// TODO Fix json serialization for Tiles::LayerInfo
//		j["tileLayers"] = mTileLayers;
	}

	//TODO hook this back up
	//if (includeAtlas)
	//{
	//	for (const auto& [texType, atlas] : mTexAtlases)
	//	{
	//		int i = static_cast<int>(texType);
	//		j["textureAtlas_" + std::to_string(i)] = *atlas;
	//	}
	//	for (const auto& [vecType, atlas] : mVecAtlases)
	//	{
	//		int i = static_cast<int>(vecType);
	//		j["vectorAtlas_" + std::to_string(i)] = *atlas;
	//	}
	//}

	if (includeShaders)
	{
		j["shaderManager"] = ShaderManager::Instance();
	}
	return j;
}

double MapViewer::getInputSensitivity() const
{
	return mInput->getSensitivity();
}

void MapViewer::setInputSensitivity(double value) const
{
	mInput->setSensitivity(value);
}

void MapViewer::setCameraState(viewportId_t viewportId, Camera::CameraState const& state)
{
	DISPATCH_VIEWPORT_TASK(setCameraState, state);

	return mViewportManager[viewportId]->setCameraState(state);
}

Camera::CameraState MapViewer::getCameraState(float x, float y) const
{
	auto vp = mViewportManager.getViewportByPixel((int)x, (int)y);
	if (vp == NULL)
		return Camera::CameraState();
	return vp->getCameraState();
}

Camera::CameraState MapViewer::getCameraState(viewportId_t viewportId) const
{
	return mViewportManager[viewportId]->getCameraState();
}

Pyramid::CullResult const& MapViewer::getCullResult(viewportId_t viewportId) const
{
	return mViewportManager[viewportId]->getVisibleFeatures().cullState;
}

// TODO (scott) return an AABB instead of pos+size calls?
lgal::world::Vector3 MapViewer::getViewportPosition(float x, float y)  const
{
	WAIT_DISPATCH_QUEUE

	auto vp = mViewportManager.getViewportByPixel((int)x, (int)y);
	if (vp == NULL)
		return { 0, 0, 0 };
	return { vp->getState()->getPosX(), vp->getState()->getPosY(), 0 };
}

lgal::world::Vector3 MapViewer::getViewportPosition(viewportId_t viewportId) const
{
	WAIT_DISPATCH_QUEUE

	auto vp = mViewportManager[viewportId];
	return { vp->getState()->getPosX(), vp->getState()->getPosY(), 0 };
}

lgal::world::Vector2 MapViewer::getViewportSize(float x, float y)
{
	WAIT_DISPATCH_QUEUE

	auto vp = mViewportManager.getViewportByPixel((int)x, (int)y);
	if (vp == NULL)
		return { 0, 0 };
	return { vp->getWidthPixel(), vp->getHeightPixel() };
}

lgal::world::Vector2 MapViewer::getViewportSize(viewportId_t viewportId)
{
	WAIT_DISPATCH_QUEUE

	auto vp = mViewportManager[viewportId];
	return { vp->getWidthPixel(), vp->getHeightPixel() };
}

}