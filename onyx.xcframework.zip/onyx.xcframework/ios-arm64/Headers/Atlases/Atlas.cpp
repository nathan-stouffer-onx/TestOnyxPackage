#include "Atlas.h"

namespace onyx {
namespace Atlases {

	uint32_t BlitCap::sNumBlits = 0;

} }