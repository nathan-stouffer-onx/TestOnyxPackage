#ifndef __ATLAS_H__
#define __ATLAS_H__

#include <map>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include <3rdParty/nlohmann/json.hpp>

#include <System/OnyxException.h>

#include "Page.h"

namespace onyx::Atlases {

	static constexpr uint32_t cDefaultCellSize    = 256;
	static constexpr uint32_t cDefaultResolution  = 4096;
	static constexpr uint32_t cDefaultPadding     = 1;

	static constexpr uint64_t cRenderFlags = BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
	static constexpr uint64_t cBlitFlags   = BGFX_TEXTURE_BLIT_DST | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;

	class BlitCap
	{
	public:

		// a cap on the percentage of the maximum number of blits we can use. bgfx has a hard
		// limit of blits allowed per frame. this is a buffer so that Atlases doesn't use up 
		// all the blits for this frame and we allow other rendering processes to blit as well
		static constexpr float cBlitConsumptionCap = 0.7f;

	public:

		BlitCap() = delete;

		inline static void Reset()
		{
			sNumBlits = 0;
		}

		inline static uint32_t NumBlits()
		{
			return sNumBlits;
		}

		inline static uint32_t MaxBlits()
		{
			return uint32_t(cBlitConsumptionCap * bgfx::getCaps()->limits.maxBlits);
		}

		// blit function to ensure that sNumBlits always gets incremented when we perform a blit
		inline static void Blit(bgfx::ViewId viewId,
								bgfx::TextureHandle dst, uint16_t dstX, uint16_t dstY,
								bgfx::TextureHandle src, uint16_t srcX = 0, uint16_t srcY = 0,
								uint16_t width = std::numeric_limits<uint16_t>::max(), uint16_t height = std::numeric_limits<uint16_t>::max())
		{
			++sNumBlits;
			bgfx::blit(viewId, dst, dstX, dstY, src, srcX, srcY, width, height);
		}

	protected:

		static uint32_t sNumBlits;

	};

	/*
	* Atlas<T> is a class that maps a key T to cells in an atlas of textures on the gpu. When Atlas<T>::insert
	* is called, Atlas<T> finds an available slot and then calls Atlas<T>::enqueue with the relevant information.
	* Atlas<T>::enqueue is a pure virtual method that a derived class will implement to insert the texture into
	* the appropriate cell in the atlas.
	*/

	template<typename T>
	class Atlas
	{
	public:

		struct AtlasEntry
		{
			T index;
			PageLocation location;
		};

		template <class container>
		void addSpritePage(bgfx::TextureFormat::Enum format, lgal::screen::Vector2 res, bgfx::TextureHandle const& handle, container const &entries)
		{
			std::vector<Page>& pages = mPages[format];
			auto pageId = uint32_t(pages.size());

			pages.emplace_back(Page(format, res, handle));

			for (AtlasEntry const& entry : entries)
			{
				AtlasId id(format, pageId, entry.location);
				
				if (mPadding != 0)  // Compensate for padding if needed
				{
					id.rect.position = id.rect.position - lgal::screen::Vector2(mPadding);
					id.rect.size = id.rect.size + lgal::screen::Vector2(mPadding * 2);
				}

				mAtlasIds.insert_or_assign(entry.index, id);
			}
		}

		void setName(std::string const& name) { mName = name; }

	protected:

		std::map<T, AtlasId> mAtlasIds;

		uint32_t mCellSize;				// width and height of each cell
		uint32_t mRes;					// resolution of the atlas pages
		uint32_t mPadding;				// padding to insert around each cell
		uint64_t mPageTextureFlags;		// flags to apply to the texture when creating a page
		std::string mName;				// name of Atlas (for ease of spotting in gpu)

		// computed from inputs
		uint32_t mPaddedCellSize;		// cell size (includes padding)
		uint32_t mDimension;			// number of cells in the x and y components of the pages

		std::map<bgfx::TextureFormat::Enum, std::vector<Page>> mPages;

		AtlasId next(bgfx::TextureFormat::Enum format)
		{
			return next(format, lgal::screen::Vector2{ screen_coord_t(mCellSize + 2 * mPadding) });
		}

		AtlasId next(bgfx::TextureFormat::Enum format, lgal::screen::Vector2 const &size)
		{
			std::vector<Page>& pages = mPages[format];

			for (size_t i = 0; i < pages.size(); i++)
			{
				Page& page = pages[i];
				auto available = page.reserveSlot(size);
				if (page.isValidLocation(available))
				{
					return AtlasId(format, uint32_t(i), available, size);
				}
			}

			// made it through the loop -- no available space, need a new page
			pages.emplace_back(Page(format, mRes, mPageTextureFlags, mName));
			auto& page = pages.back();
			auto available = page.reserveSlot(size);
			ONYX_ASSERT(page.isValidLocation(available), "unable to find new atlas Id");

			return AtlasId(format, uint32_t(pages.size() - 1), available, size);
		}

		struct TexToDestroy
		{
			std::vector<bgfx::TextureHandle> handles;
			uint32_t frameCount = 0; // have to wait a few frames to delete or the render to texture fails
			
			TexToDestroy(std::vector<bgfx::TextureHandle> && handles, uint32_t frameCount = 0)
				: handles(std::move(handles))
				, frameCount(frameCount)
			{ }
			

		};

		// TODO performance test vector vs list
		std::vector<TexToDestroy> mDestroyQueue;

		// function to add a texture to the processing queue
		virtual void enqueue(T const& key, bgfx::TextureHandle const& handle, bool dealloc) = 0;

		// function that is called by Atlas<T>::update and is expected to process insertions from the queue
		virtual void derivedUpdate() = 0;

	public:

		Atlas(uint64_t pageTextureFlags, uint32_t cellSize = cDefaultCellSize, uint32_t res = cDefaultResolution, uint32_t padding = cDefaultPadding,
			  std::string name = "") :
			mCellSize(cellSize),
			mRes(std::min(res, bgfx::getCaps()->limits.maxTextureSize)),
			mPadding(padding),
			mPageTextureFlags(pageTextureFlags),
			mName(name),
			mPaddedCellSize(mCellSize + mPadding * 2),
			mDimension(uint32_t(mRes / mPaddedCellSize))
		{ }

		virtual ~Atlas()
		{
			// deallocate textures waiting to be destroyed
			for (auto& ttd : mDestroyQueue)
			{
				for (auto& handle : ttd.handles)
				{
					if (bgfx::isValid(handle))
					{
						bgfx::destroy(handle);
					}
				}
			}
		}

		inline uint32_t getResolution() const { return mRes; }

		// returns true only if atlas has a cell for the requested key and that cell is ready
		inline bool isReady(T const& key) const
		{
			auto it = mAtlasIds.find(key);
			return (it != mAtlasIds.end()) ? it->second.isReady : false;
		}

		// returns true if the atlas has a cell for the requested key
		inline bool contains(T const& key) const
		{
			return mAtlasIds.find(key) != mAtlasIds.end();
		}

		void insert(T const& key, bgfx::TextureHandle const& handle, bgfx::TextureFormat::Enum const format, bool dealloc = true)
		{
			bgfx::TextureInfo ti;
			ti.format = format;
			ti.width = uint16_t(mCellSize + mPadding + mPadding);
			ti.height = uint16_t(mCellSize + mPadding + mPadding);

			insert(key, handle, ti, dealloc);
		}

		void insert(T const& key, bgfx::TextureHandle const& handle, bgfx::TextureFormat::Enum const format, lgal::screen::Vector2 const &size, bool dealloc = true)
		{
			bgfx::TextureInfo ti;
			ti.format = format;
			ti.width = uint16_t(size.x + mPadding + mPadding);
			ti.height = uint16_t(size.y + mPadding + mPadding);

			insert(key, handle, ti, dealloc);
		}

		// TODO make this not bgfx::TextureHandle const since it may delete the texture the handle
		void insert(T const& key, bgfx::TextureHandle const& handle, bgfx::TextureInfo const& texInfo, bool dealloc = true)
		{
			if (!contains(key))	// if we don't have a cell for this key, allocate one
			{
				// determine where we will put the texture
				AtlasId id = next(texInfo.format, { texInfo.width, texInfo.height });

				mAtlasIds.insert_or_assign(key, id);
			}

			// add the texture to a processing queue
			enqueue(key, handle, dealloc);
		}

		virtual void erase(T const& key)
		{
			auto entry = mAtlasIds.find(key);
			if (entry == mAtlasIds.end())
			{
				return;
			}
			auto const& id = (entry->second);
			mPages[id.format][id.pageId].releaseSlot(id.rect);	// mark old cell as empty
			mAtlasIds.erase(entry);								// erase key from map
		}

		void erase(std::vector<T> const& keys)
		{
			for (auto key : keys)
			{
				erase(key);
			}
		}

		void erase()
		{
			std::vector<T> keys;
			keys.reserve(this->mAtlasIds.size());
			for (auto const& idItr : this->mAtlasIds)
			{
				keys.push_back(idItr.first);
			}

			this->Atlas<T>::erase(keys);
		}
	
		void update()
		{
			// destroy textures that we are done with
			for (int i = int(mDestroyQueue.size()) - 1; i >= 0; i--)
			{
				auto& ttd = mDestroyQueue[i];
				if (ttd.frameCount > 2)
				{
					for (auto& handle : ttd.handles)
					{
						if (bgfx::isValid(handle))
						{
							bgfx::destroy(handle);
						}
					}
					mDestroyQueue.erase(mDestroyQueue.begin() + i);
				}
				else
				{
					ttd.frameCount++;
				}
			}

			// call into the derived class to process the queue
			derivedUpdate();
		}

		std::string getName() const { return mName; }

		bgfx::TextureHandle getTexHandle(bgfx::TextureFormat::Enum format, size_t i) const
		{
			return mPages.at(format)[i].texHandle;
		}

		bgfx::TextureHandle getTexHandle(T const& key) const
		{
			AtlasId const& id = mAtlasIds.at(key);
			return mPages.at(id.format)[id.pageId].texHandle;
		}

		bgfx::TextureHandle tryGetTexHandle(T const& key) const
		{
			return (contains(key)) ? getTexHandle(key) : bgfx::TextureHandle(BGFX_INVALID_HANDLE);
		}

		lgal::gpu::Vector4 getUVOffset(T const& key, lgal::gpu::Vector4 mod = { 0 }) const
		{
			AtlasId const& id = mAtlasIds.at(key);

			auto const& pages = mPages.at(id.format);
			auto const& page = pages[id.pageId];

			// set the offset to the bottom left pixel of the texture
			auto x = gpu_float_t(id.rect.position.x + mPadding + mod.x) * page.scale.x;
			auto y = gpu_float_t(id.rect.position.y + mPadding + mod.y) * page.scale.y;
			auto w = gpu_float_t(id.rect.size.x - (mPadding * 2) + mod.z) * page.scale.x;
			auto h = gpu_float_t(id.rect.size.y - (mPadding * 2) + mod.w) * page.scale.y;

			return lgal::gpu::Vector4{ x, y, w, h };
		}

		PageLocation getPageLocation(T const& key) const
		{
			ONYX_DEBUG_ASSERT(contains(key), "Atlas does not contain given key");
			AtlasId const& id = mAtlasIds.at(key);
			return id.rect;
		}

		bool tryGetUVOffset(T const& key, lgal::gpu::Vector4& uvOffset)
		{
			if (!contains(key))
			{
				return false;
			}
			uvOffset = getUVOffset(key);
			return true;
		}

		nlohmann::json getJson() const
		{
			nlohmann::json json;

			json["mCellSize"] = mCellSize;
			json["mRes"] = mRes;
			json["mPadding"] = mPadding;
			json["TexToDestroyCount"] = mDestroyQueue.size();
			size_t pageCount = 0;
			size_t cellsUsed = 0;

			for (auto const& [format, pages] : mPages)
			{
				pageCount += pages.size();
				for (size_t i = 0; i < pages.size(); i++)
				{
					Page const& page = pages[i];
					cellsUsed += page.usedChunks.size();
				}
			}

			json["PageCount"] = pageCount;
			json["CellsUsed"] = cellsUsed;

			return json;
		}

	};

}

#endif