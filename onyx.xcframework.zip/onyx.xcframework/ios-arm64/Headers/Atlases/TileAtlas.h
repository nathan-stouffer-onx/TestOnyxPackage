#pragma once

#include <vector>

#include <bgfx/bgfx.h>

#include "Atlas.h"
#include "Tiles/TileId.h"

namespace onyx::Atlases
{

	/*
	* TileAtlas is a class that maps a Tiles::TileId to cells in an atlas of textures on the gpu. It inherits
	* from Atlas<T> and utilizes blitting to insert textures into it's cells. Insertions are queued and throttled
	* per frame to limit the effect on framerate.
	*
	* In addition to just inserting the tiled textures into cells, TileAtlas knows that it's entries are tiles.
	* It takes advantage of this by replacing edge padding with data from adjacent tiles when possible. This
	* allows us to use linear interpolation at tile border with accurate data.
	*/

	class TileAtlas : public Atlas<Tiles::TileId>
	{
		// cap for how many insertions to process per frame
		static constexpr uint32_t cInsertionCap = 20;

	public:

		struct InputPadding
		{
			// number of pixels of padding in the input data
			uint32_t padding;
			// how many of the pixels in the padded input data are synthetic
			uint32_t synthetic;

			InputPadding(uint32_t _padding = 0, uint32_t _synthetic = 0) : padding(_padding), synthetic(_synthetic) {}

		};

	public:

		TileAtlas(uint32_t cellSize = cDefaultCellSize, uint32_t res = cDefaultResolution,
					uint32_t cellPadding = cDefaultPadding, InputPadding inputPadding = {},
					bgfx::TextureHandle missingTileHandle = BGFX_INVALID_HANDLE);

		virtual ~TileAtlas();

		inline bgfx::TextureHandle getMissingTileHandle() const { return mMissingTileHandle; }
		inline lgal::gpu::Vector4 getMissingTileUVOffset() const { return { 0, 0, 0, 0 }; }
		inline uint32_t getMissingTileResolution() const { return 1; }

	protected:

		struct TexToBlit
		{
			Tiles::TileId key;
			bgfx::TextureHandle handle;
			bool dealloc;
		};

		// TODO performance test vector vs list
		std::vector<TexToBlit> mBlitQueue;

		InputPadding mInputPadding;

		uint32_t mMaxBlitsOnInsert;

		bgfx::TextureHandle mMissingTileHandle;

		// TODO make this not bgfx::TextureHandle const since it deletes the handle
		void enqueue(Tiles::TileId const& key, bgfx::TextureHandle const& handle, bool dealloc) override;

		void derivedUpdate() override;

		// insert the tile into the atlas. we pad the edges with copies of the edge of the tile
		void toAtlas(bgfx::ViewId viewId, AtlasId const& targetId, bgfx::TextureHandle const& src);
		// copy the edges of the tile to relevant neighbors that the atlas contains
		void toNeighbors(bgfx::ViewId viewId, Tiles::TileId const& key, bgfx::TextureHandle const& src, bgfx::TextureFormat::Enum const format);
		// copy the edges from neighboring tiles to the one we are inserting. to avoid an invalid framebuffer
		// loop, we first copy them to an interim texture and then to the atlas
		void fromNeighbors(bgfx::ViewId interimViewId, bgfx::ViewId viewId, Tiles::TileId const& key);

		// function that computes a bound on number of blits required to insert a texture
		inline static uint32_t BlitBound(uint32_t cellPadding, InputPadding inputPadding)
		{
			// amount of padding in the inserted texture
			uint32_t paddingDiff = cellPadding - inputPadding.padding;
			// amount of padding that needs to be overwritten with actual data
			uint32_t syntheticDiff = paddingDiff + inputPadding.synthetic;

			uint32_t bound = 1;							// blit the texture to the atlas
			bound += 4 * paddingDiff;					// blit the four borders to edge padding
			bound += 4 * paddingDiff * paddingDiff;		// blit the four corners to padding corner
			bound += (syntheticDiff > 0) ? 8 : 0;		// blit the border to the neighbors
			bound += (syntheticDiff > 0) ? 2 * 8 : 0;	// blit the neighbors border to this cell (2 blits per neighbor)
			return bound;
		}

	};

}