#include "HeightAtlas.h"

#include "Utils/MapMath.h"

namespace onyx::Atlases
{

	static bgfx::TextureHandle ConstructMissingHeightTileHandle()
	{
		float zero = 0.f;
		bgfx::Memory const* mem = bgfx::copy(static_cast<void*>(&zero), sizeof(float));
		bgfx::TextureHandle handle = bgfx::createTexture2D(1, 1, false, 1, bgfx::TextureFormat::Enum::R32F, cBlitFlags, mem);
		return handle;
	}

	HeightAtlas::HeightAtlas(int maxLevel, uint32_t cellSize, uint32_t res, uint32_t padding, InputPadding inputPadding) :
		TileAtlas(cellSize, res, padding, inputPadding, ConstructMissingHeightTileHandle()),
		mMaxLevel(maxLevel)
	{}

	void HeightAtlas::insert(Tiles::TileId const& tileId, std::shared_ptr<Tiles::HeightTile> tile, bgfx::TextureHandle const& handle, bgfx::TextureFormat::Enum const format, bool dealloc)
	{
		// write to atlas
		Atlas<Tiles::TileId>::insert(tileId, handle, format, dealloc);
		// write tile to cpu map
		mPyramid.insert(tile);
		// TODO possibly call methods to copy edges to/from adjacent cpu tiles here
	}

	void HeightAtlas::erase(Tiles::TileId const& tileId)
	{
		// erase from base class
		Atlas<Tiles::TileId>::erase(tileId);
		// erase from this class
		mPyramid.erase(tileId);
	}

	std::shared_ptr<Tiles::HeightTile const> HeightAtlas::highestDetailedTile(lgal::world::Vector2 const& pos) const
	{
		if (MapMath::inWorldBounds(pos))
		{
			Tiles::TileId tileId = Tiles::TileId::Containing(mMaxLevel, pos);
			return mPyramid.find(tileId, true);
		}

		return std::shared_ptr<Tiles::HeightTile>(nullptr);
	}

	height_float_t HeightAtlas::heightAt(lgal::world::Vector2 const& pos, bool mercatorDistortion, bool interpolate) const
	{
		std::shared_ptr<Tiles::HeightTile const> tile = highestDetailedTile(pos);
		if (tile == nullptr)
		{
			return MapMath::cBadHeight;
		}
		return tile->heightAt(pos, mercatorDistortion, interpolate);
	}

	lgal::world::Vector3 HeightAtlas::normalAt(lgal::world::Vector2 const& pos, bool interpolate) const
	{
		std::shared_ptr<Tiles::HeightTile const> tile = highestDetailedTile(pos);
		if (tile == nullptr)
		{
			return { 0, 0, 1 };
		}
		return tile->normalAt(pos, interpolate);
	}

	lgal::height::Range HeightAtlas::heightExtents(Tiles::TileId const& tileId, bool mercatorDistortion) const
	{
		if (contains(tileId))
		{
			std::shared_ptr<Tiles::HeightTile const> tile = mPyramid.at(tileId);
			return lgal::height::Range{ tile->getMinHeight(mercatorDistortion), tile->getMaxHeight(mercatorDistortion) };
		}
		else if (tileId.level == 0)
		{
			return lgal::height::Range{ MapMath::cMinHeight, MapMath::cMaxHeight };
		}
		else
		{
			return heightExtents(tileId.parent(), mercatorDistortion);
		}
	}

	lgal::height::Range HeightAtlas::heightExtents(std::vector<Tiles::TileId> const& tiles, bool mercatorDistortion) const
	{
		lgal::height::Range extents = { std::numeric_limits<height_float_t>::max(), std::numeric_limits<height_float_t>::lowest() };

		for (Tiles::TileId const& tile : tiles)
		{
			auto tileExtents = heightExtents(tile, mercatorDistortion);
			if (tileExtents.begin < extents.begin)
			{
				extents.begin = tileExtents.begin;
			}
			if (tileExtents.end > extents.end)
			{
				extents.end = tileExtents.end;
			}
		}

		return (extents.begin <= extents.end) ? extents : lgal::height::Range{ MapMath::cMinHeight, MapMath::cMaxHeight };
	}

}