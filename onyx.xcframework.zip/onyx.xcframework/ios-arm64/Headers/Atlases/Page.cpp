#include "Page.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Atlases {

	Page::Page(bgfx::TextureFormat::Enum format, lgal::screen::Vector2 res, uint64_t texFlags,
			   std::string const& _name) :
		format(format),
		res(res),
		emptyChunks({ chunk_t({ 0, 0 }, res) }),
		name(_name),
		scale{ 1 / gpu_float_t(res.x), 1 / gpu_float_t(res.y) }
	{
		texHandle = bgfx::createTexture2D(
			uint16_t(res.x), uint16_t(res.y),
			false, 1, format,
			texFlags
		);

		ONYX_ASSERT(bgfx::isValid(texHandle), "Failed to create atlas page texture handle");

		bgfx::setName(texHandle, name.c_str());
		if (texFlags & BGFX_TEXTURE_RT)
		{
			frameBufferHandle = bgfx::createFrameBuffer(1, &texHandle, false);
		}
	}

	Page::Page(bgfx::TextureFormat::Enum format, lgal::screen::Vector2 res, bgfx::TextureHandle const& handle)
		: format(format)
		, res(res)
		, ownsHandle(false)
		, texHandle(handle)
		, scale{ 1 / gpu_float_t(res.x), 1 / gpu_float_t(res.y) }
	{}

	Page::Page(Page&& other) noexcept :
		format(other.format),
		res(other.res),
		needsClearColor(other.needsClearColor),
		texHandle(other.texHandle),
		frameBufferHandle(other.frameBufferHandle),
		scale(other.scale)
	{
		emptyChunks = std::move(other.emptyChunks);
		usedChunks = std::move(other.usedChunks);

		// mark the frame buffer handles as invalid on the old page
		other.texHandle = BGFX_INVALID_HANDLE;
		other.frameBufferHandle = BGFX_INVALID_HANDLE;
	}

	Page::~Page()
	{
		// texture handle is destroyed along with frame buffer
		if (bgfx::isValid(frameBufferHandle))
		{
			bgfx::destroy(frameBufferHandle);
		}
		if (bgfx::isValid(texHandle) && ownsHandle)
		{
			bgfx::destroy(texHandle);
		}
	}

	void Page::mergeChunks()
	{
		bool found = false;
		do {
			found = false;
			for (auto iter1 = emptyChunks.begin(); iter1 != emptyChunks.end(); ++iter1)
			{
				auto& chunk1 = *iter1;
				for (auto iter2 = emptyChunks.begin(); iter2 != emptyChunks.end(); ++iter2)
				{
					if (iter1 == iter2)
					{
						continue;
					}

					auto& chunk2 = *iter2;
					if (chunk1.min.x == chunk2.min.x &&
						chunk1.max.x == chunk2.max.x &&
						chunk1.max.y == chunk2.min.y)
					{
						chunk1.max.y = chunk2.max.y;
						emptyChunks.erase(iter2);
						found = true;
					}
					else if (chunk1.min.y == chunk2.min.y &&
						chunk1.max.y == chunk2.max.y &&
						chunk1.max.x == chunk2.min.x)
					{
						chunk1.max.x = chunk2.max.x;
						emptyChunks.erase(iter2);
						found = true;
					}
					if (found)
					{
						break;
					}
				}
				if (found)
				{
					break;
				}
			}
		} while (found);
	}

	bool Page::releaseSlot(PageLocation const& rect)
	{
		auto const& position = rect.position;
		auto const& size = rect.size;
		lgal::screen::AABB2d aabb(position, position + size);
		for (auto iter = usedChunks.begin(); iter != usedChunks.end(); ++iter)
		{
			if (aabb == *iter)
			{
				emptyChunks.push_back(*iter);
				usedChunks.erase(iter);
				mergeChunks();
				return true;
			}
		}

		return false;
	}

	lgal::screen::Vector2 Page::reserveSlot(lgal::screen::Vector2 const& size)
	{
		// Find chunk that has the smallest difference in given size
		auto bestIndex = std::numeric_limits<size_t>::max();
		auto bestMod = std::numeric_limits<screen_coord_t>::max();
		for (size_t i = 0u; i < emptyChunks.size() && bestMod > 0; ++i)
		{
			auto& chunk = emptyChunks[i];
			auto chunkSize = chunk.max - chunk.min;
			if (chunkSize.x >= size.x && chunkSize.y >= size.y)
			{
				auto xMod = chunkSize.x % size.x;
				auto yMod = chunkSize.y % size.y;

				auto minMod = std::min(xMod, yMod);
				if (minMod < bestMod)
				{
					bestMod = minMod;
					bestIndex = i;
				}
			}
		}

		if (bestIndex == std::numeric_limits<size_t>::max())
		{
			return { -1, -1 };
		}

		auto& chunk = emptyChunks[bestIndex];
		chunk_t usedChunk = chunk;
		usedChunk.max = usedChunk.min + size;
		usedChunks.push_back(usedChunk);
		auto chunkSize = chunk.max - chunk.min;

		if (chunkSize.x == size.x && chunkSize.y == size.y) // This
		{
			emptyChunks.erase(emptyChunks.begin() + bestIndex);
		}
		else // Split chunk into two such that we get the largest contiguous space
		{
			auto xDiff = chunkSize.x - size.x;
			auto yDiff = chunkSize.y - size.y;

			auto xSize = xDiff * chunkSize.y;
			auto ySize = yDiff * chunkSize.x;

			chunk_t chunk1 = chunk,
				chunk2 = chunk;

			if (xSize >= ySize)
			{
				chunk1.min.x += size.x;
				chunk2.max.x = chunk1.min.x;
				chunk2.min.y += size.y;
			}
			else
			{
				chunk1.min.y += size.y;
				chunk2.max.y = chunk1.min.y;
				chunk2.min.x += size.x;
			}

			chunk = chunk1; // Assign the old chunk to the new chunk

			if (xDiff > 0 && yDiff > 0)
			{
				emptyChunks.push_back(chunk2);
			}
		}

		return usedChunk.min;
	}

} }