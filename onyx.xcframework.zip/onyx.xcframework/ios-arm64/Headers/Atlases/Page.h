#ifndef __ATLAS_PAGE_H__
#define __ATLAS_PAGE_H__

#include <vector>
#include <string>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Atlases {

	struct PageLocation
	{
		lgal::screen::Vector2 position,
			size;

		inline lgal::screen::AABB2d aabb() const { return { position, position + size }; }
	};

	struct AtlasId
	{
		bgfx::TextureFormat::Enum format;
		uint32_t pageId;
		PageLocation rect;
		bool isReady = false;

		AtlasId(bgfx::TextureFormat::Enum format, uint32_t pageId, lgal::screen::Vector2 const& position, lgal::screen::Vector2 const& size) : format(format), pageId(pageId), rect{ position, size } {}
		AtlasId(bgfx::TextureFormat::Enum format, uint32_t pageId, PageLocation const& rect) : format(format), pageId(pageId), rect(rect) {}
		AtlasId(AtlasId const& other) : format(other.format), pageId(other.pageId), rect(other.rect), isReady(other.isReady) {}
		AtlasId& operator=(AtlasId const& rhs) { format = rhs.format; pageId = rhs.pageId; rect.position = rhs.rect.position; rect.size = rhs.rect.size; isReady = rhs.isReady; return *this; }

		inline bool operator==(AtlasId const& rhs) const {
			return format == rhs.format &&
					pageId == rhs.pageId &&
					rect.position == rhs.rect.position &&
					rect.size == rhs.rect.size;
		}

		inline bool operator!=(AtlasId const& rhs) const {
			return !(*this == rhs);
		}

		inline bool ready() const { return isReady; }

		static inline AtlasId empty()
		{
			return
			{
				bgfx::TextureFormat::Enum::Unknown,
				0xFFFFFFFF,
				{ -1, -1 },
				{ -1, -1 }
			};
		}

		inline lgal::screen::AABB2d aabb() const { return rect.aabb(); }
	};

	struct Page
	{
		bgfx::TextureFormat::Enum format;
		lgal::screen::Vector2 res;
		
		bool needsClearColor = true;
		bool ownsHandle = true;

		bgfx::TextureHandle texHandle = BGFX_INVALID_HANDLE;
		bgfx::FrameBufferHandle frameBufferHandle = BGFX_INVALID_HANDLE;

		typedef lgal::screen::AABB2d chunk_t;

		std::vector<chunk_t> emptyChunks, usedChunks;
		
		std::string name = "Atlas Page";	// For GPU debugging purposes

		lgal::gpu::Vector2 scale;

		Page(bgfx::TextureFormat::Enum format, lgal::screen::Vector2 res, uint64_t texFlags,
			std::string const& _name = "Atlas Page");
		Page(bgfx::TextureFormat::Enum format, lgal::screen::Vector2 res, bgfx::TextureHandle const& handle);

		Page(Page&& other) noexcept;	// move constructor

		Page(Page const& other) = delete;				// delete copy constructor
		Page& operator=(Page const& other) = delete;	// delete copy assignment
		Page& operator=(Page&& other) = delete;			// delete move assignment

		~Page();

		inline bool isValidLocation(lgal::screen::Vector2 location)
		{
			return 0 <= location.x && location.x < res.x && 0 <= location.y && location.y < res.y;
		}

		void mergeChunks();
		
		bool releaseSlot(PageLocation const& rect);

		lgal::screen::Vector2 reserveSlot(lgal::screen::Vector2 const& size);
		
	};

} }

#endif