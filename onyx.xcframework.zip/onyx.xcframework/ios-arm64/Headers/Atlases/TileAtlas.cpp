#include "TileAtlas.h"

#include "Utils/BgfxUtils.h"

namespace onyx::Atlases
{

	static bgfx::TextureHandle ConstructMissingTileHandle()
	{
		uint32_t color = 0x00000000;
		bgfx::Memory const* mem = bgfx::copy(static_cast<void*>(&color), sizeof(uint32_t));
		bgfx::TextureHandle handle = bgfx::createTexture2D(1, 1, false, 1, bgfx::TextureFormat::Enum::RGBA8, cBlitFlags, mem);
		return handle;
	}

	TileAtlas::TileAtlas(uint32_t cellSize, uint32_t res, uint32_t cellPadding, InputPadding inputPadding, bgfx::TextureHandle missingTileHandle) :
		Atlas<Tiles::TileId>(Atlases::cBlitFlags, cellSize, res, cellPadding),
		mInputPadding(inputPadding),
		mMaxBlitsOnInsert(TileAtlas::BlitBound(mPadding, mInputPadding)),
		mMissingTileHandle(bgfx::isValid(missingTileHandle) ? missingTileHandle : ConstructMissingTileHandle())
	{}

	TileAtlas::~TileAtlas()
	{
		BgfxUtils::tryDestroy(mMissingTileHandle);

		for (auto& ttb : mBlitQueue)
		{
			if (ttb.dealloc)
			{
				BgfxUtils::tryDestroy(ttb.handle);
			}
		}
	}

	// TODO consider processing immediately (when possible) to avoid a queue allocation
	void TileAtlas::enqueue(Tiles::TileId const& key, bgfx::TextureHandle const& handle, bool dealloc)
	{
		mBlitQueue.push_back({ key, handle, dealloc });
	}

	void TileAtlas::derivedUpdate()
	{
		// count for how many insertions have been performed
		size_t i = 0;
		size_t inserted = 0;
		for (;
			// conditions for running this for loop
			i < mBlitQueue.size() &&										// check that there are blits to process
			inserted < cInsertionCap &&										// check that we are still below the insertion cap
			BlitCap::NumBlits() + mMaxBlitsOnInsert <= BlitCap::MaxBlits();	// check that this insertion won't go over the max
			// increment i
			i++)
		{
			TexToBlit& ttb = mBlitQueue[i];

			// only perform the blits if we still have the key (it might have been erased while in the queue)
			if (contains(ttb.key))
			{
				AtlasId const& atlasId = mAtlasIds.at(ttb.key);

				// view id 0 for inserting this texture into the atlas
				bgfx::ViewId insertViewId = bgfx::ViewId{ 0 };
				// blit from the source into the atlas
				toAtlas(insertViewId, atlasId, ttb.handle);

				// view id 1 for padding neighbors in the atlas
				bgfx::ViewId toNbrViewId = bgfx::ViewId{ 1 };
				// blit to edge padding for any existing neighbors
				toNeighbors(toNbrViewId, ttb.key, ttb.handle, atlasId.format);

				// view id 2 for the interim copy to an interim texture
				bgfx::ViewId interimViewId = bgfx::ViewId{ 2 };
				// view id 3 for updating the atlas from the interim textures
				bgfx::ViewId fromNbrViewId = bgfx::ViewId{ 3 };
				// blit from any existing neighbors into our edge padding
				fromNeighbors(interimViewId, fromNbrViewId, ttb.key);

				// mark this cell as ready
				mAtlasIds.at(ttb.key).isReady = true;
				// increment the number of textures that have been inserted
				++inserted;
			}

			// deallocate if necessary
			if (ttb.dealloc)
			{
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ ttb.handle } });
			}
		}

		// clean up textures that were blitted
		mBlitQueue.erase(mBlitQueue.begin(), mBlitQueue.begin() + i);
	}

	void TileAtlas::toAtlas(bgfx::ViewId viewId, AtlasId const& targetId, bgfx::TextureHandle const& src)
	{
		bgfx::TextureHandle dstHandle = mPages[targetId.format][targetId.pageId].texHandle;
		auto const& pos = targetId.rect.position;
		auto const& size = targetId.rect.size;

		// compute the amount of existing and missing padding in the input data
		uint32_t existingPadding = mInputPadding.padding;
		uint32_t missingPadding = mPadding - mInputPadding.padding;

		// side length of the input texture
		uint16_t xLen = uint16_t(size.x - (2 * missingPadding));
		uint16_t yLen = uint16_t(size.y - (2 * missingPadding));
		// number of pixels used to pad cells
		uint16_t pad = uint16_t(mPadding - mInputPadding.padding);

		// blit source texture into the atlas slot
		{
			uint16_t dstX = uint16_t(pos.x + missingPadding);
			uint16_t dstY = uint16_t(pos.y + missingPadding);
			BlitCap::Blit(viewId, dstHandle, dstX, dstY, src);
		}

		// blit the four edges
		{
			// blit north side to edge padding
			{
				uint16_t dstX = uint16_t(pos.x + missingPadding);
				uint16_t dstY = uint16_t(pos.y);
				for (uint16_t j = 0; j < pad; j++)
				{
					BlitCap::Blit(viewId, dstHandle, dstX, dstY + j, src, 0, 0, xLen, 1);
				}
			}
			// blit east side to edge padding
			{
				uint16_t dstX = uint16_t(pos.x + mPadding + mCellSize + existingPadding);
				uint16_t dstY = uint16_t(pos.y + missingPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					BlitCap::Blit(viewId, dstHandle, dstX + i, dstY, src, xLen - 1, 0, 1, yLen);
				}
			}
			// blit south side to edge padding
			{
				uint16_t dstX = uint16_t(pos.x + missingPadding);
				uint16_t dstY = uint16_t(pos.y + mPadding + mCellSize + existingPadding);
				for (uint16_t j = 0; j < pad; j++)
				{
					BlitCap::Blit(viewId, dstHandle, dstX, dstY + j, src, 0, yLen - 1, xLen, 1);
				}
			}
			// blit west side to edge padding
			{
				uint16_t dstX = uint16_t(pos.x);
				uint16_t dstY = uint16_t(pos.y + missingPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					BlitCap::Blit(viewId, dstHandle, dstX + i, dstY, src, 0, 0, 1, yLen);
				}
			}
		}

		// blit the four corners
		{
			// blit northwest corner
			{
				uint16_t dstX = uint16_t(pos.x);
				uint16_t dstY = uint16_t(pos.y);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, dstHandle, dstX + i, dstY + j, src, 0, 0, 1, 1);
					}
				}
			}
			// blit northeast corner
			{
				uint16_t dstX = uint16_t(pos.x + mPadding + mCellSize + existingPadding);
				uint16_t dstY = uint16_t(pos.y);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, dstHandle, dstX + i, dstY + j, src, xLen - 1, 0, 1, 1);
					}
				}
			}
			// blit southeast corner
			{
				uint16_t dstX = uint16_t(pos.x + mPadding + mCellSize + existingPadding);
				uint16_t dstY = uint16_t(pos.y + mPadding + mCellSize + existingPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, dstHandle, dstX + i, dstY + j, src, xLen - 1, yLen - 1, 1, 1);
					}
				}
			}
			// blit southwest corner
			{
				uint16_t dstX = uint16_t(pos.x);
				uint16_t dstY = uint16_t(pos.y + mPadding + mCellSize + existingPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, dstHandle, dstX + i, dstY + j, src, 0, yLen - 1, 1, 1);
					}
				}
			}
		}
	}

	void TileAtlas::toNeighbors(bgfx::ViewId viewId, Tiles::TileId const& key, bgfx::TextureHandle const& src, bgfx::TextureFormat::Enum const format)
	{
		// compute the amount of existing and missing padding in atlas cells
		uint32_t existingPadding = mInputPadding.padding - mInputPadding.synthetic;
		uint32_t missingPadding = mPadding - existingPadding;
		if (missingPadding == 0)	// early out if no work is needed
		{
			return;
		}

		uint32_t inputPadding = mInputPadding.padding;

		uint16_t pad = uint16_t(missingPadding);
		uint16_t len = uint16_t(mCellSize);

		// check neighbors directly adjacent to the tile
		{
			// blit to the north neighbor
			Tiles::TileId north = key.northNeighbor();
			if (north.isValid() && isReady(north))
			{
				AtlasId const& northId = mAtlasIds.at(north);

				if (format == northId.format)
				{
					// edge padding on the south side of the northward tile
					auto dst = mPages[northId.format][northId.pageId].texHandle;
					auto dstX = uint16_t(northId.rect.position.x + mPadding);
					auto dstY = uint16_t(northId.rect.position.y + mPadding + mCellSize + existingPadding);

					// north side of the source tile
					auto srcX = uint16_t(inputPadding);
					auto srcY = uint16_t(inputPadding);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, len, pad);
				}
			}
			// blit to the east neighbor
			Tiles::TileId east = key.eastNeighbor().moduloX();
			if (east.isValid() && isReady(east))
			{
				AtlasId& eastId = mAtlasIds.at(east);

				if (format == eastId.format)
				{
					// edge padding on the west side of the eastward tile
					auto dst = mPages[eastId.format][eastId.pageId].texHandle;
					auto dstX = uint16_t(eastId.rect.position.x);
					auto dstY = uint16_t(eastId.rect.position.y + mPadding);

					// east side of the source tile
					auto srcX = uint16_t(inputPadding + len - pad);
					auto srcY = uint16_t(inputPadding);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, pad, len);
				}
			}
			// blit to the south neighbor
			Tiles::TileId south = key.southNeighbor();
			if (south.isValid() && isReady(south))
			{
				AtlasId& southId = mAtlasIds.at(south);

				if (format == southId.format)
				{
					// edge padding on the north side of the southward tile
					auto dst = mPages[southId.format][southId.pageId].texHandle;
					auto dstX = uint16_t(southId.rect.position.x + mPadding);
					auto dstY = uint16_t(southId.rect.position.y);

					// south side of the source tile
					auto srcX = uint16_t(inputPadding);
					auto srcY = uint16_t(inputPadding + len - pad);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, len, pad);
				}
			}
			// blit to the west neighbor
			Tiles::TileId west = key.westNeighbor().moduloX();
			if (west.isValid() && isReady(west))
			{
				AtlasId& westId = mAtlasIds.at(west);

				if (format == westId.format)
				{
					// edge padding on the east side of the westward tile
					auto dst = mPages[westId.format][westId.pageId].texHandle;
					auto dstX = uint16_t(westId.rect.position.x + mPadding + mCellSize + existingPadding);
					auto dstY = uint16_t(westId.rect.position.y + mPadding);

					// west side of the source tile
					auto srcX = uint16_t(inputPadding);
					auto srcY = uint16_t(inputPadding);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, pad, len);
				}
			}
		}

		// check neighbors at the corners of the tile
		{
			// blit to the northwest neighbor
			Tiles::TileId northWest = key.northwestNeighbor().moduloX();
			if (northWest.isValid() && isReady(northWest))
			{
				AtlasId& northWestId = mAtlasIds.at(northWest);

				if (format == northWestId.format)
				{
					// edge padding on the southeast corner of the northwestward tile
					auto dst = mPages[northWestId.format][northWestId.pageId].texHandle;
					auto dstX = uint16_t(northWestId.rect.position.x + mPadding + mCellSize + existingPadding);
					auto dstY = uint16_t(northWestId.rect.position.y + mPadding + mCellSize + existingPadding);

					// northwest corner of the source tile
					auto srcX = uint16_t(inputPadding);
					auto srcY = uint16_t(inputPadding);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, pad, pad);
				}
			}
			// blit to the northeast neighbor
			Tiles::TileId northEast = key.northeastNeighbor().moduloX();
			if (northEast.isValid() && isReady(northEast))
			{
				AtlasId& northEastId = mAtlasIds.at(northEast);

				if (format == northEastId.format)
				{
					// edge padding on the southwest corner of the northeastward tile
					auto dst = mPages[northEastId.format][northEastId.pageId].texHandle;
					auto dstX = uint16_t(northEastId.rect.position.x);
					auto dstY = uint16_t(northEastId.rect.position.y + mPadding + mCellSize + existingPadding);

					// northeast corner of the source tile
					auto srcX = uint16_t(inputPadding + len - pad);
					auto srcY = uint16_t(inputPadding);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, pad, pad);
				}
			}
			// blit to the southeast neighbor
			Tiles::TileId southEast = key.southeastNeighbor().moduloX();
			if (southEast.isValid() && isReady(southEast))
			{
				AtlasId& southEastId = mAtlasIds.at(southEast);

				if (format == southEastId.format)
				{
					// edge padding on the northwest corner of the southeastward tile
					auto dst = mPages[southEastId.format][southEastId.pageId].texHandle;
					auto dstX = uint16_t(southEastId.rect.position.x);
					auto dstY = uint16_t(southEastId.rect.position.y);

					// southeast corner of the source tile
					auto srcX = uint16_t(inputPadding + len - pad);
					auto srcY = uint16_t(inputPadding + len - pad);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, pad, pad);
				}
			}
			// blit to the southwest neighbor
			Tiles::TileId southWest = key.southwestNeighbor().moduloX();
			if (southWest.isValid() && isReady(southWest))
			{
				AtlasId& southWestId = mAtlasIds.at(southWest);

				if (format == southWestId.format)
				{
					// edge padding on the northeast corner of the southwestward tile
					auto dst = mPages[southWestId.format][southWestId.pageId].texHandle;
					auto dstX = uint16_t(southWestId.rect.position.x + mPadding + mCellSize + existingPadding);
					auto dstY = uint16_t(southWestId.rect.position.y);

					// southwest corner of the source tile
					auto srcX = uint16_t(inputPadding);
					auto srcY = uint16_t(inputPadding + len - pad);

					BlitCap::Blit(viewId, dst, dstX, dstY, src, srcX, srcY, pad, pad);
				}
			}
		}
	}

	// TODO instead of allocating an interim texture for every blit here, it might be worthwhile to allocate
	// a single, large texture and just use segments of it
	void TileAtlas::fromNeighbors(bgfx::ViewId interimViewId, bgfx::ViewId viewId, Tiles::TileId const& key)
	{
		// compute the amount of existing and missing padding in atlas cells
		uint32_t existingPadding = mInputPadding.padding - mInputPadding.synthetic;
		uint32_t missingPadding = mPadding - existingPadding;
		if (missingPadding == 0)	// early out if no work is needed
		{
			return;
		}

		// TODO only copy over the segments that the input cell is missing. it will be the same number of blits,
		// but each blit will be smaller. currently, if a tile has padding, we overwrite it with identical data
		AtlasId const& targetId = mAtlasIds.at(key);
		uint16_t pad = uint16_t(mPadding);
		uint16_t len = uint16_t(mCellSize);

		// check neighbors directly adjacent to the tile
		// blit from the north neighbor
		Tiles::TileId north = key.northNeighbor();
		if (north.isValid() && isReady(north))
		{
			// atlas id for the north neighbor
			AtlasId& northId = mAtlasIds.at(north);

			if (targetId.format == northId.format)
			{
				// create interim texture for the south edge of the northward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(len, pad, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// south side of the northward tile
				auto src = mPages[northId.format][northId.pageId].texHandle;
				auto srcX = uint16_t(northId.rect.position.x + mPadding);
				auto srcY = uint16_t(northId.rect.position.y + mCellSize);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, len, pad);

				// edge padding on the north side
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x + mPadding);
				auto dstY = uint16_t(targetId.rect.position.y);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
		// blit from the east neighbor
		Tiles::TileId east = key.eastNeighbor().moduloX();
		if (east.isValid() && isReady(east))
		{
			// atlas id for the east neighbor
			AtlasId& eastId = mAtlasIds.at(east);

			if (targetId.format == eastId.format)
			{
				// create interim texture for the west edge of the eastward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(pad, len, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// west side of the eastward tile
				auto src = mPages[eastId.format][eastId.pageId].texHandle;
				auto srcX = uint16_t(eastId.rect.position.x + mPadding);
				auto srcY = uint16_t(eastId.rect.position.y + mPadding);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, pad, len);

				// edge padding on the east side
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x + mPadding + mCellSize);
				auto dstY = uint16_t(targetId.rect.position.y + mPadding);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
		// blit from the south neighbor
		Tiles::TileId south = key.southNeighbor();
		if (south.isValid() && isReady(south))
		{
			// atlas id for the south neighbor
			AtlasId& southId = mAtlasIds.at(south);

			if (targetId.format == southId.format)
			{
				// create interim texture for the north edge of the southward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(len, pad, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// north side of the southward tile
				auto src = mPages[southId.format][southId.pageId].texHandle;
				auto srcX = uint16_t(southId.rect.position.x + mPadding);
				auto srcY = uint16_t(southId.rect.position.y + mPadding);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, len, pad);

				// edge padding on the south side
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x + mPadding);
				auto dstY = uint16_t(targetId.rect.position.y + mPadding + mCellSize);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
		// blit from the west neighbor
		Tiles::TileId west = key.westNeighbor().moduloX();
		if (west.isValid() && isReady(west))
		{
			// atlas id for the west neighbor
			AtlasId& westId = mAtlasIds.at(west);

			if (targetId.format == westId.format)
			{
				// create interim texture for the east edge of the westward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(pad, len, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// east side of the westward tile
				auto src = mPages[westId.format][westId.pageId].texHandle;
				auto srcX = uint16_t(westId.rect.position.x + mCellSize);
				auto srcY = uint16_t(westId.rect.position.y + mPadding);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, pad, len);

				// edge padding on the west side
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x);
				auto dstY = uint16_t(targetId.rect.position.y + mPadding);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}

		// check neighbors at the corners of the tile
		// blit from the northwest neighbor
		Tiles::TileId northWest = key.northwestNeighbor().moduloX();
		if (northWest.isValid() && isReady(northWest))
		{
			// atlas id for the northwest neighbor
			AtlasId& northWestId = mAtlasIds.at(northWest);

			if (targetId.format == northWestId.format)
			{
				// create interim texture for the southeast corner of the northwestward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(pad, pad, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// grab pixels from the southeast corner of the northwestward tile
				auto src = mPages[northWestId.format][northWestId.pageId].texHandle;
				auto srcX = uint16_t(northWestId.rect.position.x + mCellSize);
				auto srcY = uint16_t(northWestId.rect.position.y + mCellSize);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, pad, pad);

				// edge padding for northwest corner of the destination tile
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x);
				auto dstY = uint16_t(targetId.rect.position.y);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
		// blit from the northeast neighbor
		Tiles::TileId northEast = key.northeastNeighbor().moduloX();
		if (northEast.isValid() && isReady(northEast))
		{
			// atlas id for the northeast neighbor
			AtlasId& northEastId = mAtlasIds.at(northEast);

			if (targetId.format == northEastId.format)
			{
				// create interim texture for the southwest corner of the northeastward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(pad, pad, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// grab pixels from the southwest corner of the northeastward tile
				auto src = mPages[northEastId.format][northEastId.pageId].texHandle;
				auto srcX = uint16_t(northEastId.rect.position.x + mPadding);
				auto srcY = uint16_t(northEastId.rect.position.y + mCellSize);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, pad, pad);

				// edge padding for northeast corner of the destination tile
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x + mPadding + mCellSize);
				auto dstY = uint16_t(targetId.rect.position.y);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
		// blit from the southeast neighbor
		Tiles::TileId southEast = key.southeastNeighbor().moduloX();
		if (southEast.isValid() && isReady(southEast))
		{
			// atlas id for the southeast neighbor
			AtlasId& southEastId = mAtlasIds.at(southEast);

			if (targetId.format == southEastId.format)
			{
				// create interim texture for the northwest corner of the southeastward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(pad, pad, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// grab pixels from the northwest corner of the southeastward tile
				auto src = mPages[southEastId.format][southEastId.pageId].texHandle;
				auto srcX = uint16_t(southEastId.rect.position.x + mPadding);
				auto srcY = uint16_t(southEastId.rect.position.y + mPadding);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, pad, pad);

				// edge padding for the southeast corner of the destination tile
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x + mPadding + mCellSize);
				auto dstY = uint16_t(targetId.rect.position.y + mPadding + mCellSize);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
		// blit from the southwest neighbor
		Tiles::TileId southWest = key.southwestNeighbor().moduloX();
		if (southWest.isValid() && isReady(southWest))
		{
			// atlas id for the southwest neighbor
			AtlasId& southWestId = mAtlasIds.at(southWest);

			if (targetId.format == southWestId.format)
			{
				// create interim texture for the northeast corner of the southwestward tile
				bgfx::TextureHandle interim = bgfx::createTexture2D(pad, pad, false, 1, targetId.format, BGFX_TEXTURE_BLIT_DST);

				// grab pixels from the northeast corner of the southwestward tile
				auto src = mPages[southWestId.format][southWestId.pageId].texHandle;
				auto srcX = uint16_t(southWestId.rect.position.x + mCellSize);
				auto srcY = uint16_t(southWestId.rect.position.y + mPadding);

				// blit to the interim texture
				BlitCap::Blit(interimViewId, interim, 0, 0, src, srcX, srcY, pad, pad);

				// edge padding for the southwest corner of the destination tile
				auto dst = mPages[targetId.format][targetId.pageId].texHandle;
				auto dstX = uint16_t(targetId.rect.position.x);
				auto dstY = uint16_t(targetId.rect.position.y + mPadding + mCellSize);

				// blit from the interim texture to the atlas
				BlitCap::Blit(viewId, dst, dstX, dstY, interim);

				// destroy interim texture
				mDestroyQueue.push_back(TexToDestroy{ std::vector<bgfx::TextureHandle>{ interim } });
			}
		}
	}

}