#ifndef __STYLE_ATLASES_H__
#define __STYLE_ATLASES_H__

#include <unordered_map>

#include <bgfx/bgfx.h>

#include <System/OnyxException.h>

#include <Styling/Styles/LineStyle.h>
#include <Styling/Styles/FillStyle.h>

#include "Atlases/DashAtlas.h"
#include "Atlases/RepeatAtlas.h"

namespace onyx {
namespace Atlases {

	/*
	* An atlas for base class that allows us to pack every styles on the gpu into a couple textures. This enables
	* us to render vectors with different styles in the same draw call.
	*
	* Some funtions return a StrongRef to count how many things outside this atlas are using a style. if all
	* strong references are destroyed, the atlas considers the slot where this style is stored available to 
	* overwrite.
	* 
	* NOTE: because we want to be able to draw all vector styles in the same draw call, this is not a multipaged atlas
	*/
	template<typename StyleT>
	class StyleAtlas
	{
	public:

		typedef std::shared_ptr<int const> StrongRef;	// typedef for reference counting system
		typedef std::weak_ptr<int const> WeakRef;		// typedef for reference counting system

		static StrongRef fresh()
		{
			return std::make_shared<int const>(0);
		}

	protected:

		using IndexT = uint32_t;

		// Internal struct to represent a slot in the atlas. At the moment it is really just an integer. If we 
		// change LineStyleAtlas to use blitting, then we will utilize Slot::isReady similar to how we use
		// AtlasId::isReady. Though for now, it is a glorified integer
		struct Slot
		{
			IndexT idx;
			//bool isReady;

			Slot(IndexT i) : idx(i) {} // , isReady(false) {}
			Slot(Slot const& rhs) : idx(rhs.idx) {} //, isReady(rhs.isReady) {}
			Slot& operator=(Slot const& rhs) { idx = rhs.idx; /* isReady = rhs.isReady; */ return *this; }

			//bool ready() const { return isReady; }

			static Slot invalid()
			{
				return Slot(std::numeric_limits<IndexT>::max());
			}
		};

	public:

		StyleAtlas(uint16_t res) : cTextureRes(res) {}
		virtual ~StyleAtlas() {}

		StyleAtlas(StyleAtlas const&) = delete;
		StyleAtlas& operator=(StyleAtlas const&) = delete;

		StyleAtlas(StyleAtlas&&) = delete;
		StyleAtlas& operator=(StyleAtlas&&) = delete;

		StrongRef insert(StyleT const& style)
		{
			StrongRef ref = contains(style);
			if (!ref)
			{
				// mark as dirty so we know to update the textures
				mIsDirty = true;

				// create a fresh reference
				ref = StyleAtlas::fresh();

				// compute the next slot and write the style to that index
				Slot slot = next();
				write(slot.idx, style);

				// update book-keeping
				erase(mEntries[slot.idx].style);		// erase the old style
				mEntries[slot.idx] = { ref, style };
				mSlots.insert_or_assign(style, slot);
			}

			return ref;
		}

		StrongRef contains(StyleT const& style) const
		{
			auto iter = mSlots.find(style);
			if (iter != mSlots.end())		// make sure we know about the style
			{
				Slot const& slot = iter->second;
				Entry const& entry = mEntries[slot.idx];	// grab the entry
				StrongRef ref = entry.reference.lock();		// lock the reference

				if (ref)		// make sure the reference is alive
				{
					if (style == entry.style)	// make sure the reference is pointing to the appropriate style
					{
						return ref;
					}
				}
			}

			// fall-through case where we just return nullptr if any of the above conditions fail
			return StrongRef(nullptr);
		}

		StrongRef isReady(StyleT const& style) const
		{
			// technically is slightly wrong because this will claim no styles are ready if we
			// just insert one new style. but since we create an entire new texture whenever we
			// insert a new style, it works out
			StrongRef ref = contains(style);
			return (ref && !mIsDirty) ? ref : StrongRef(nullptr); // mSlots.at(style).isReady;
		}

		void erase(StyleT const& style)
		{
			if (contains(style))
			{
				Slot& slot = mSlots.at(style);
				mEntries[slot.idx] = Entry{};
				mSlots.erase(style);
			}
		}

		// returns the texture coordinates of the style
		lgal::gpu::Vector2 coords(StyleT const& style) const
		{
			Slot const& slot = mSlots.at(style);

			// compute the uv coords of the pixel
			gpu_float_t px = gpu_float_t(slot.idx & 0xFF) / gpu_float_t(cTextureRes);
			gpu_float_t py = gpu_float_t((slot.idx / cTextureRes) & 0xFF) / gpu_float_t(cTextureRes);

			// compute half-pixel so we are sending over the pixel center
			gpu_float_t halfPixel = 0.5f / gpu_float_t(cTextureRes);

			return { px + halfPixel, py + halfPixel };
		}

	protected:

		uint16_t const cTextureRes;
		IndexT const cNumSlots = cTextureRes * cTextureRes;

		bool mIsDirty = false;

		// stores the slots index from a LineStyle into the subsequent arrays
		std::unordered_map<StyleT, Slot> mSlots;

		struct Entry
		{
			WeakRef reference;
			StyleT style = StyleT();
		};

		// use std::vector here for bounds checking
		std::vector<Entry> mEntries = std::vector<Entry>((size_t)cNumSlots);

		// the slot that should be checked when looking for an available slot (ie when LineStyleAtlas::next is called)
		mutable IndexT mSlotToCheck = 0;

	protected:

		// returns whether the atlas has a record of the style. this does not necessarily imply
		// that the style is contained in the atlas, it may be a dangling entry if all the strong
		// references have been destroyed
		bool knows(StyleT const& style) const
		{
			return mSlots.find(style) != mSlots.end();
		}

		Slot next() const
		{
			// iterate through all possible slots -- early out once we find an available one
			for (IndexT i = 0; i < cNumSlots; i++)
			{
				// if the slot can't produce a strong reference, it is available and we return
				if (!mEntries[mSlotToCheck].reference.lock())
				{
					return Slot(mSlotToCheck);
				}

				// update the slot we are checking
				mSlotToCheck = (mSlotToCheck + 1) % cNumSlots;
			}

			ONYX_THROW("No remaining slots in StyleAtlas");
			return Slot::invalid();
		}

		virtual void write(IndexT i, StyleT const& style) = 0;

		template<typename T>
		bgfx::TextureHandle BuildPage(T* data, bgfx::TextureFormat::Enum format)
		{
			// use makeRef because this data is stored in arrays that will never change memory addresses
			bgfx::Memory const* mem = bgfx::makeRef((void*)data, sizeof(T) * StyleAtlas::cNumSlots);
			bgfx::TextureHandle handle = bgfx::createTexture2D(StyleAtlas::cTextureRes, StyleAtlas::cTextureRes, false, 1, format, 0, mem);
			ONYX_ASSERT(bgfx::isValid(handle), "Failed to allocate StyleAtlas page");
			return handle;
		}

	};

	class LineStyleAtlas final : public StyleAtlas<Styling::LineStyle>
	{
	public:

		static constexpr uint16_t cDefaultTextureRes = 256;

		// if this value is changed, there is an analogous value in TileLineBase.json
		static constexpr float cMaxLineWidth = 16.0f;	// TODO allow for larger line widths and more precision
		
	public:

		LineStyleAtlas();
		~LineStyleAtlas();

		void update();
		
		inline bgfx::TextureHandle getColorHandle()      const { return mColorHandle; }
		inline bgfx::TextureHandle getWidthHandle()      const { return mWidthHandle; }
		inline bgfx::TextureHandle getJoinTypesHandle()  const { return mJoinTypesHandle; }
		inline bgfx::TextureHandle getCapTypesHandle()   const { return mCapTypesHandle; }
		inline bgfx::TextureHandle getDashCoordsHandle() const { return mDashCoordsHandle; }
		inline bgfx::TextureHandle getDashAtlasHandle()  const { return mDashAtlas.getHandle(); }

	private:

		void write(IndexT i, Styling::LineStyle const& style) override;

		void destroyTextures();

		std::vector<uint32_t> mColors				= std::vector<uint32_t>((size_t)cNumSlots);
		std::vector<uint32_t> mWidths				= std::vector<uint32_t>((size_t)cNumSlots);
		std::vector<uint8_t > mJoinTypes				= std::vector<uint8_t >((size_t)cNumSlots);
		std::vector<uint8_t > mCapTypes				= std::vector<uint8_t >((size_t)cNumSlots);
		std::vector<uint8_t > mDashCoords			= std::vector<uint8_t >((size_t)cNumSlots);

		DashAtlas mDashAtlas;

		// TODO possibly pack multiple parameters into the same texture?
		bgfx::TextureHandle mColorHandle      = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mWidthHandle      = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mJoinTypesHandle  = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mCapTypesHandle   = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mDashCoordsHandle = BGFX_INVALID_HANDLE;

	};

	class FillStyleAtlas final : public StyleAtlas<Styling::FillStyle>
	{
	public:

		static constexpr uint16_t cDefaultTextureRes = 256;
		static constexpr uint32_t cPatternCellSize = 32;

	public:

		FillStyleAtlas();
		~FillStyleAtlas();

		void update();

		inline bgfx::TextureHandle getColorHandle()         const { return mColorHandle; }
		inline bgfx::TextureHandle getPatternCoordsHandle() const { return mPatternCoordsHandle; }
		inline bgfx::TextureHandle getPatternAtlasHandle()  const { return mPatternAtlas.getTexHandle(bgfx::TextureFormat::Enum::RGBA8, 0); }

	private:

		void write(IndexT i, Styling::FillStyle const& style) override;

		void destroyTextures();

		std::vector<uint32_t> mColors        = std::vector<uint32_t>((size_t)cNumSlots);
		std::vector<uint32_t> mPatternCoords = std::vector<uint32_t>((size_t)cNumSlots);

		Atlases::RepeatAtlas<std::string> mPatternAtlas;

		bgfx::TextureHandle mColorHandle = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mPatternCoordsHandle = BGFX_INVALID_HANDLE;

	};

} }

#endif