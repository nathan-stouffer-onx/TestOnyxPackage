#ifndef __REPEAT_ATLAS_H__
#define __REPEAT_ATLAS_H__

#include "TextureAtlas.h"

/**
* RepeatAtlas is a class that takes "repeating" textures and inserts them into the atlas
* and copies the opposite edges and corners as padding so that it can be used in shaders
* with seamless joins across repeated edges.
*/

namespace onyx {
namespace Atlases {

	template<class T>
	class RepeatAtlas : public TextureAtlas<T>
	{
		// cap for how many insertions to process per frame
		static constexpr uint32_t cInsertionCap = 20;

	public:

		RepeatAtlas(uint64_t pageTextureFlags, uint32_t cellSize = cDefaultCellSize, uint32_t res = cDefaultResolution, uint32_t padding = cDefaultPadding) :
			TextureAtlas<T>(pageTextureFlags, cellSize, res, padding),
			mMaxBlitsOnInsert(RepeatAtlas<T>::BlitsBound(this->mPadding))
		{}

		~RepeatAtlas()
		{
			for (auto& ttb : mBlitQueue)
			{
				if (ttb.dealloc)
				{
					if (bgfx::isValid(ttb.handle))
					{
						bgfx::destroy(ttb.handle);
					}
				}
			}
		}

	protected:

		struct TexToBlit
		{
			T key;
			bgfx::TextureHandle handle;
			bool dealloc;
		};

		std::vector<TexToBlit> mBlitQueue;

		uint32_t mMaxBlitsOnInsert;

		// TODO make this not bgfx::TextureHandle const since it deletes the handle
		void enqueue(T const& key, bgfx::TextureHandle const& handle, bool dealloc) override
		{
			mBlitQueue.push_back({ key, handle, dealloc });
		}

		void derivedUpdate() override
		{
			// count for how many insertions have been performed
			size_t i = 0;
			size_t inserted = 0;
			auto maxBlits = BlitCap::MaxBlits();
			for (;
				// conditions for running this for loop
				i < mBlitQueue.size() &&								// check that there are blits to process
				inserted < cInsertionCap &&								// check that we are still below the insertion cap
				BlitCap::NumBlits() + mMaxBlitsOnInsert <= maxBlits;	// check that this insertion won't go over the max
				// increment i
				i++)
			{
				TexToBlit& ttb = mBlitQueue[i];

				// only perform the blits if we still have the key (it might have been erased while in the queue)
				if (this->contains(ttb.key))
				{
					AtlasId const& atlasId = this->mAtlasIds.at(ttb.key);

					// view id 0 for inserting this texture into the atlas
					bgfx::ViewId insertViewId = bgfx::ViewId{ 0 };
					// blit from the source into the atlas
					toAtlas(insertViewId, atlasId, ttb.handle);

					// mark this cell as ready
					this->mAtlasIds.at(ttb.key).isReady = true;
					// increment the number of textures that have been inserted
					inserted++;
				}

				// deallocate if necessary
				if (ttb.dealloc)
				{
					typename Atlas<T>::TexToDestroy destroy(std::vector<bgfx::TextureHandle>{ ttb.handle });
					this->mDestroyQueue.push_back(destroy);
				}
			}

			// clean up textures that were blitted
			mBlitQueue.erase(mBlitQueue.begin(), mBlitQueue.begin() + i);
		}

		// insert the tile into the atlas. we pad the edges with copies of the opposite edges of the tile
		void toAtlas(bgfx::ViewId viewId, AtlasId const& targetId, bgfx::TextureHandle const& src)
		{
			auto const& size = targetId.rect.size;
			auto const& position = targetId.rect.position;
			// side length of the texture
			uint16_t xLen = uint16_t(size.x - (this->mPadding + this->mPadding));
			uint16_t yLen = uint16_t(size.y - (this->mPadding + this->mPadding));
			// number of pixels used to pad cells
			uint16_t pad = uint16_t(this->mPadding);

			// blit source texture into the atlas slot
			{
				uint16_t dstX = uint16_t(position.x + this->mPadding);
				uint16_t dstY = uint16_t(position.y + this->mPadding);
				BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX, dstY, src);
			}

			// blit the four edges
			// blit -y edge to +y edge padding
			{
				uint16_t dstX = uint16_t(position.x + this->mPadding);
				uint16_t dstY = uint16_t(position.y + size.y - this->mPadding);
				for (uint16_t j = 0; j < pad; j++)
				{
					BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX, dstY + j, src, 0, 0, xLen, 1);
				}
			}
			// blit -x edge to +x edge padding
			{
				uint16_t dstX = uint16_t(position.x + size.x - this->mPadding);
				uint16_t dstY = uint16_t(position.y + this->mPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX + i, dstY, src, 0, 0, 1, yLen);
				}
			}
			// blit +y edge to -y edge padding
			{
				uint16_t dstX = uint16_t(position.x + this->mPadding);
				uint16_t dstY = uint16_t(position.y);
				for (uint16_t j = 0; j < pad; j++)
				{
					BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX, dstY + j, src, 0, yLen - 1, xLen, 1);
				}
			}
			// blit +x edge to -x edge padding
			{
				uint16_t dstX = uint16_t(position.x);
				uint16_t dstY = uint16_t(position.y + this->mPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX + i, dstY, src, xLen - 1, 0, 1, yLen);
				}
			}

			// blit the four corners
			// blit -x, -y from +x, +y
			{
				uint16_t dstX = uint16_t(position.x);
				uint16_t dstY = uint16_t(position.y);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX + i, dstY + j, src, xLen - 1, yLen - 1, 1, 1);
					}
				}
			}
			// blit -x, +y from +x, -y
			{
				uint16_t dstX = uint16_t(position.x);
				uint16_t dstY = uint16_t(position.y + size.y - this->mPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX + i, dstY + j, src, xLen - 1, 0, 1, 1);
					}
				}
			}
			// blit +x, -y from -x, +y
			{
				uint16_t dstX = uint16_t(position.x + size.x - this->mPadding);
				uint16_t dstY = uint16_t(position.y);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX + i, dstY + j, src, 0, yLen - 1, 1, 1);
					}
				}
			}
			// blit +x, +y from -x, -y
			{
				uint16_t dstX = uint16_t(position.x + size.x - this->mPadding);
				uint16_t dstY = uint16_t(position.y + size.y - this->mPadding);
				for (uint16_t i = 0; i < pad; i++)
				{
					for (uint16_t j = 0; j < pad; j++)
					{
						BlitCap::Blit(viewId, this->mPages[targetId.format][targetId.pageId].texHandle, dstX + i, dstY + j, src, 0, 0, 1, 1);
					}
				}
			}
		}

		// function that computes a bound on number of blits required to insert a texture
		inline static uint32_t BlitsBound(uint32_t padding)
		{
			// 1 ---------------------- blitting the actual texture
			// 4 * padding ------------ blitting the four borders to edge padding
			// 4 * padding * padding -- blitting the four corners to padding corner
			return 1 + 4 * padding + 4 * padding * padding;
		}
	};

} }

#endif