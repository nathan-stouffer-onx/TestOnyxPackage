#ifndef __TEXTURE_ATLAS_H__
#define __TEXTURE_ATLAS_H__

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include <Shaders/ShaderParameters.h>
#include <Shaders/ShaderManager.h>

#include "Atlas.h"
#include "Rendering/VertStructs.h"
#include "Rendering/ViewId.h"

namespace onyx {
namespace Atlases {
	
	/*
	* TextureAtlas<T> is a class that maps a key T to cells in an atlas of textures on the gpu. It inherits
	* from Atlas<T> and utilizes render-to-texture to insert textures into its cells. Insertions are queued
	* and throttled per frame to limit the effect on framerate.
	*
	* NOTE: Inheritance and templates can get a bit weird in C++. Accessing classes and members of the base
	* class requires some finesse. To use a type "A" defined in Atlas<T>, you must declare your variable as
	* "typename Atlas<T>::A". To access a member of the base class, you should use "this->" so that the proper
	* name resolution occurs.
	*
	* You can visit these links for a more in depth description:
	*   - https://isocpp.org/wiki/faq/templates#nondependent-name-lookup-types
	*   - https://isocpp.org/wiki/faq/templates#nondependent-name-lookup-members
	*/

	template <typename T>
	class TextureAtlas : public Atlas<T>
	{
		//cap for how many insertions to process per frame
		static constexpr uint32_t cInsertionCap = 10;

		// four corners with four vertices in each corner (we need to account for padding)
		static constexpr size_t cNumVertices = 4 * 4;
		// a quad is six vertices. so we have a quad for the center, a quad for each edge,
		// and a quad for each corner
		static constexpr size_t cNumIndices = 6 + 6 * 4 + 6 * 4;

	public:

		void setClearColor(uint32_t rgba) { mClearColorRGBA = rgba; }
		uint32_t getClearColor() const { return mClearColorRGBA; }

	protected:

		ShaderEnums::ConfigurableShaders mShaderType;

		float mFBOView[16];
		float mFBOProj[16];

		// our quad shape for both background and new texture
		Rendering::VertStructs::PosColorUV mVerts[cNumVertices];
		bgfx::VertexBufferHandle mVertexBuffer;
		bgfx::IndexBufferHandle mIndexBuffer;

		static const uint16_t sIndices[cNumIndices];
		uint32_t mClearColorRGBA = 0x00ff006f;

		struct TexToDraw
		{
			T key;
			lgal::gpu::Vector4 srcScaleOffset;	// where to query the source texture from
			AtlasId targetId;		// include this for the case of the erased texture
			std::vector<bgfx::TextureHandle> handles;
			std::vector<T> dependentIdKeys;		// once texture is drawn, use to set other AtlasIDs as ready
			bool dealloc;

			// TODO (Ronald): Consider using an rvalue reference for input array
			TexToDraw(T const& _key, AtlasId const& _targetId, 
				std::vector<bgfx::TextureHandle> const& _handles, 
				bool _dealloc)
				: key(_key), srcScaleOffset(0, 0, 1, 1),
				targetId(_targetId), handles(_handles), dealloc(_dealloc)
			{}

			// TODO (Ronald): Consider using an rvalue reference for input array
			TexToDraw(T const& _key, AtlasId const& _targetId,
				lgal::gpu::Vector4 const& _srcScaleOffset,
				std::vector<bgfx::TextureHandle> const& _handles, 
				bool _dealloc)
				: key(_key), srcScaleOffset(_srcScaleOffset),
				targetId(_targetId), handles(_handles), dealloc(_dealloc)
			{}

		};

		// TODO performance test vector vs list
		std::vector<TexToDraw> mDrawQueue;

		// TODO consider processing immediately (when possible) to avoid a queue allocation
		virtual void enqueue(T const& key, std::vector<bgfx::TextureHandle> const& handles, bool dealloc)
		{
			// include the target atlas id for the case where we are drawing the erased texture
			TexToDraw ttd{ key, this->mAtlasIds.at(key), handles, dealloc };
			mDrawQueue.push_back(ttd);
		}

		// have the override just call through to the general case of a vector of handles for TextureAtlas
		void enqueue(T const& key, bgfx::TextureHandle const& handle, bool dealloc) override
		{
			enqueue(key, std::vector<bgfx::TextureHandle>{ handle }, dealloc);
		}

		void derivedUpdate() override
		{
			int prevPage = -1;
			bgfx::ViewId viewId = BGFX_INVALID_HANDLE;
			size_t i = 0;
			for (;
				// conditions for running this for loop
				i < mDrawQueue.size() &&						// check that there are items to process
				i < cInsertionCap;								// check that we are still below the cap
				// increment i
				i++)
			{
				TexToDraw& ttd = mDrawQueue[i];
				AtlasId& id = ttd.targetId;
				Page& page = this->mPages[id.format][id.pageId];
				// set up a new ViewId if we have to render to a different page than the previous
				if (int(id.pageId) != prevPage)
				{
					viewId = Rendering::ViewId::next(Rendering::ViewId::Type::RenderToTexture);
					std::string name = "Texture Atlas page " + std::to_string(id.pageId);
					bgfx::setViewName(viewId, name.c_str());

					if (page.needsClearColor)
					{
						bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR, mClearColorRGBA, 1.0f, 0);
						page.needsClearColor = false;
					}
					else
					{
						bgfx::setViewClear(viewId, BGFX_CLEAR_NONE);
					}

					bgfx::setViewRect(viewId, 0, 0, uint16_t(this->mRes), uint16_t(this->mRes));
					bgfx::setViewFrameBuffer(viewId, page.frameBufferHandle);
					bgfx::setViewTransform(viewId, mFBOView, mFBOProj);
					bgfx::touch(viewId);
					prevPage = id.pageId;
				}

				int subset = static_cast<int>(ttd.handles.size()) - 1;

				auto shader = ShaderManager::Instance()->getShader(mShaderType, subset);

				for (size_t j = 0; j < ttd.handles.size(); j++)
				{
					bgfx::TextureHandle handle = ttd.handles[j];

					std::string tex = "s_texture" + std::to_string(j);
					shader->setParameter(tex, handle, this->mCellSize, this->mCellSize);

					std::string offset = "u_ScaleOffsetTex" + std::to_string(j);
					shader->setParameter(offset, ttd.srcScaleOffset);
				}

				// position the result in the texture
				auto xPos = id.rect.position.x;
				auto yPos = id.rect.position.y;
				if (!bgfx::getCaps()->originBottomLeft)
				{
					yPos = this->mRes - yPos;
				}

				lgal::gpu::Vector3 tileMin(static_cast<float>(xPos), static_cast<float>(yPos), 0);
                float yMaxModifier = float(id.rect.size.y) * (bgfx::getCaps()->originBottomLeft ? 1 : -1);    // flip the scale matrix according to origin position
                lgal::gpu::Vector3 tileMax(tileMin.x + id.rect.size.x, tileMin.y + yMaxModifier, 1.0);

				shader->setParameter("u_tileMin", tileMin);
				shader->setParameter("u_tileMax", tileMax);

				bgfx::setIndexBuffer(mIndexBuffer);
				bgfx::setVertexBuffer(0, mVertexBuffer);

				// Set render states
				uint64_t state = 0
					| BGFX_STATE_WRITE_RGB
					| BGFX_STATE_WRITE_A;

				bgfx::setState(state);
				bgfx::submit(viewId, shader->programHandle);

#if DEBUG_TEX_ATLAS
				if (ttd.handles[0].idx != mErasedTextureHandle.idx) // ignore updating AtlasId::isReady for the "erased" texture
#endif
				{
					// only update the cell as ready if we still have the key (it might have been erased while in the draw queue)
					if (this->contains(ttd.key))
					{
						this->mAtlasIds.at(ttd.key).isReady = true;
					}
				}
				
				for (T const& key : ttd.dependentIdKeys)
				{
					if (this->contains(key))
					{
						this->mAtlasIds.at(key).isReady = true;
					}
				}

				if (ttd.dealloc)
				{
					this->mDestroyQueue.push_back({ ttd.handles });
				}
			}

			// clean up textures that were drawn
			mDrawQueue.erase(mDrawQueue.begin(), mDrawQueue.begin() + i);
	}

#if DEBUG_TEX_ATLAS
		const uint32_t mErasedTextureColor;
		bgfx::TextureHandle mErasedTextureHandle;
#endif

	public:

		TextureAtlas(uint64_t pageTextureFlags, uint32_t cellSize = cDefaultCellSize, uint32_t res = cDefaultResolution, uint32_t padding = cDefaultPadding, std::string name = "") :
			  Atlas<T>(pageTextureFlags, cellSize, res, padding, name)
			, mShaderType(ShaderEnums::ConfigurableShaders::SimpleTexture)
#if DEBUG_TEX_ATLAS
			, mErasedTextureColor(0xffff0000)
			, mErasedTextureHandle(BGFX_INVALID_HANDLE)
#endif
		{
			float edge = float(this->mPadding) / float(this->mPaddedCellSize);

			// (0, 0) corner
			// vertices    // position                     // color       // uv coords
			mVerts[0 ] = { 0.f,        0.f,         0.f,   0xffffffff,    0.f, 0.f };
			mVerts[1 ] = { edge,       0.f,         0.f,   0xffffffff,    0.f, 0.f };
			mVerts[2 ] = { 0.f,        edge,        0.f,   0xffffffff,    0.f, 0.f };
			mVerts[3 ] = { edge,       edge,        0.f,   0xffffffff,    0.f, 0.f };
			// (0, 1) corner
			// vertices    // position                     // color       // uv coords
			mVerts[4 ] = { 0.f,        1.f - edge,  0.f,   0xffffffff,    0.f, 1.f };
			mVerts[5 ] = { edge,       1.f - edge,  0.f,   0xffffffff,    0.f, 1.f };
			mVerts[6 ] = { 0.f,        1.f,         0.f,   0xffffffff,    0.f, 1.f };
			mVerts[7 ] = { edge,       1.f,         0.f,   0xffffffff,    0.f, 1.f };
			// (1, 1) corner
			// vertices    // position                     // color       // uv coords
			mVerts[8 ] = { 1.f - edge, 1.f - edge,  0.f,   0xffffffff,    1.f, 1.f };
			mVerts[9 ] = { 1.f - edge, 1.f,         0.f,   0xffffffff,    1.f, 1.f };
			mVerts[10] = { 1.f,        1.0f - edge, 0.f,   0xffffffff,    1.f, 1.f };
			mVerts[11] = { 1.f,        1.f,         0.f,   0xffffffff,    1.f, 1.f };
			// (1, 0) corner
			// vertices    // position                     // color       // uv coords
			mVerts[12] = { 1.f - edge, edge,        0.f,   0xffffffff,    1.f, 0.f };
			mVerts[13] = { 1.f,        edge,        0.f,   0xffffffff,    1.f, 0.f };
			mVerts[14] = { 1.f - edge, 0.f,         0.f,   0xffffffff,    1.f, 0.f };
			mVerts[15] = { 1.f,        0.f,         0.f,   0xffffffff,    1.f, 0.f };

			// Create static vertex buffer.
			mVertexBuffer = bgfx::createVertexBuffer(
				// Static data can be passed with bgfx::makeRef
				bgfx::makeRef(mVerts, sizeof(Rendering::VertStructs::PosColorUV) * cNumVertices)
				, Rendering::VertStructs::PosColorUV::ms_layout
			);

			// Create static index buffer for triangle list rendering
			mIndexBuffer = bgfx::createIndexBuffer(
				// Static data can be passed with bgfx::makeRef
				bgfx::makeRef(sIndices, sizeof(uint16_t) * cNumIndices)
			);

			bgfx::setName(mVertexBuffer, "TextureAtlasQuad");

			bx::mtxLookAt(mFBOView, bx::Vec3(0, 0, -1), bx::Vec3(0), bx::Vec3(0, 1, 0));
			bx::mtxOrtho(mFBOProj, 0, static_cast<float>(this->mRes), 0, static_cast<float>(this->mRes), 0.01f, 10, 0, false);

#if DEBUG_TEX_ATLAS
			mErasedTextureHandle = bgfx::createTexture2D(
				uint16_t(1)
				, uint16_t(1)
				, false
				, 1
				, bgfx::TextureFormat::BGRA8
				, BGFX_SAMPLER_UVW_CLAMP
				, bgfx::makeRef((void*)&mErasedTextureColor, sizeof(uint32_t))
			);
			bgfx::setName(mErasedTextureHandle, "erased atlas cell");
#endif
		}

		~TextureAtlas()
		{
			for (auto& ttd : mDrawQueue)
			{
				if (ttd.dealloc)
				{
					for (auto& handle : ttd.handles)
					{
						if (bgfx::isValid(handle))
						{
							bgfx::destroy(handle);
						}
					}
				}
			}

			if (bgfx::isValid(mVertexBuffer))
				bgfx::destroy(mVertexBuffer);
			if (bgfx::isValid(mIndexBuffer))
				bgfx::destroy(mIndexBuffer);

#if DEBUG_TEX_ATLAS
			if (bgfx::isValid(mErasedTextureHandle))
				bgfx::destroy(mErasedTextureHandle);
#endif
		}

		void insertMultiple(T const& key, std::vector<bgfx::TextureHandle> const& handles, lgal::screen::Vector2 const &size, bgfx::TextureFormat::Enum const format, bool dealloc = true)
		{
			if (!this->contains(key))
			{
				// determine where we will put the texture
				AtlasId id = this->next(format, { size.x + this->mPadding * 2, size.y + this->mPadding * 2 });

				this->mAtlasIds.insert_or_assign(key, id);
			}

			// add the textures to a processing queue
			enqueue(key, handles, dealloc);
		}

		void insertMultiple(T const& key, std::vector<bgfx::TextureHandle> const& handles, bgfx::TextureFormat::Enum const format, bool dealloc = true)
		{
			if (!this->contains(key))	// if we don't have a cell for this key, allocate one
			{
				// determine where we will put the texture
				AtlasId id = this->next(format);

				this->mAtlasIds.insert_or_assign(key, id);
			}

			// add the textures to a processing queue
			enqueue(key, handles, dealloc);
		}

		struct SpriteIdx
		{
			std::string key;
			PageLocation loc;
		};

		// Adds sprites individually to the atlas
		void insertSpritesPerIdx(bgfx::TextureHandle const& spritesheetHndl,
			bgfx::TextureInfo const& texInfo,
			std::vector<SpriteIdx> const& idxs,
			bool dealloc = true)
		{
			const int lastElemIdx = int(idxs.size()) - 1;
			const int idxsSiz = int(idxs.size());
			for (int i = 0; i < idxsSiz; ++i)
			{
				auto const& idx = idxs[i];
				
				// Find where to place the sprite in the atlas
				auto idIter = this->mAtlasIds.find(idx.key);
				if (idIter == this->mAtlasIds.end())
				{
					AtlasId id = this->next(texInfo.format, idx.loc.size);
					idIter = this->mAtlasIds.insert_or_assign(idx.key, id).first;
				}
				MAP3D_DEBUG_ASSERT(idIter != this->mAtlasIds.end(),
					"Failed to insert nor retrieve atlas id for given key");

				auto srcPos = idx.loc.position.template as<gpu_float_t>();
				auto srcSize = idx.loc.size.template as<gpu_float_t>();
				auto invSheetSize = lgal::gpu::Vector2{ 1.f / texInfo.width, 1.f / texInfo.height };

				auto scaleOffsetTex = lgal::gpu::Vector4{
					srcPos.x * invSheetSize.x,
					srcPos.y * invSheetSize.y,
					srcSize.x * invSheetSize.x,
					srcSize.y * invSheetSize.y
				};

				bool deallocHndl = (i != lastElemIdx && dealloc) ? false : true;

				std::vector<bgfx::TextureHandle> hndls = { spritesheetHndl };
				mDrawQueue.emplace_back(idx.key, idIter->second, scaleOffsetTex, hndls, deallocHndl);
			}
		}

		// Add sprites using a single render to texture. mPadding should be set to 0 since we assume padding is
		// accounted for in the spritesheet texture
		void insertSpritesFull(bgfx::TextureHandle const& spritesheetHndl,
			T const& spritesheetKey,
			bgfx::TextureInfo const& texInfo,
			std::vector<SpriteIdx> const& idxs,
			bool dealloc = true)
		{
			MAP3D_ASSERT(this->mPadding == 0, "This function should be used with an atlas that has 0 padding");

			// Get spritesheet atlas info
			auto spritesheetIter = this->mAtlasIds.find(spritesheetKey);
			if (spritesheetIter == this->mAtlasIds.end())
			{
				AtlasId id = this->next(texInfo.format, 
					{ screen_coord_t(texInfo.width), screen_coord_t(texInfo.height) });
				spritesheetIter = this->mAtlasIds.insert_or_assign(spritesheetKey, id).first;
			}
			MAP3D_DEBUG_ASSERT(spritesheetIter != this->mAtlasIds.end(),
				"Failed to insert nor retrieve spritesheet atlas id for given key");
			AtlasId spritesheetId = spritesheetIter->second;

			std::vector hndls = { spritesheetHndl };
			TexToDraw& ttd = mDrawQueue.emplace_back(spritesheetKey, spritesheetId, hndls, dealloc);

			ttd.dependentIdKeys.reserve(idxs.size());
			// Add info about where to put full spritesheet in page
			for (size_t i = 0; i < idxs.size(); ++i)
			{
				SpriteIdx const& idx = idxs[i];

				auto idIter = this->mAtlasIds.find(idx.key);
				if (idIter == this->mAtlasIds.end())
				{
					// Adjust loc to be relative to atlas page instead of spritesheet
					PageLocation loc = idx.loc;
					loc.position += spritesheetId.rect.position;
					AtlasId id(texInfo.format, spritesheetId.pageId, loc);
					idIter = this->mAtlasIds.insert_or_assign(idx.key, id).first;
				}
				MAP3D_DEBUG_ASSERT(idIter != this->mAtlasIds.end(),
					"Failed to insert nor retrieve atlas id for given key");

				ttd.dependentIdKeys.push_back(idx.key);
			}
		}

		void erase(T const& key) override
		{
			// if the debug tex atlas compile flag is set insert the erased texture into the draw queue
#if DEBUG_TEX_ATLAS
			mDrawQueue.push_back({ key, this->mAtlasIds.at(key), std::vector<bgfx::TextureHandle>{ mErasedTextureHandle }, false });
#endif
			// call into the base class to do the actual erasing
			Atlas<T>::erase(key);
		}

	};

	template <typename T>
	const uint16_t TextureAtlas<T>::sIndices[cNumIndices] = {
			0, 1, 3,
			0, 3, 2,

			2, 3, 5,
			2, 5, 4,

			4, 5, 7,
			4, 7, 6,

			5, 8, 7,
			7, 8, 9,

			8, 10, 9,
			9, 10, 11,

			8,  12, 10,
			10, 12, 13,

			12, 14, 13,
			13, 14, 15,

			12, 3, 14,
			14, 3, 1,

			3, 12, 8,
			3, 8,  5
	};

} }



#endif
