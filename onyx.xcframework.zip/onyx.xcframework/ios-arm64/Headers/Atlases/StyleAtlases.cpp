#include "StyleAtlases.h"

#include <lucid/math/Algorithm.h>

#include "Utils/BgfxUtils.h"

namespace onyx {
namespace Atlases {

	// LineStyleAtlas --------------------------------------------------------------------------------------------------------

	LineStyleAtlas::LineStyleAtlas() : StyleAtlas<Styling::LineStyle>(cDefaultTextureRes) {}

	LineStyleAtlas::~LineStyleAtlas()
	{
		destroyTextures();
	}

	void LineStyleAtlas::update()
	{
		if (mIsDirty)
		{
			// update dash atlas
			mDashAtlas.update();

			// destroy the old textures
			destroyTextures();

			// allocate pages
			mColorHandle      = BuildPage(mColors.data(),     bgfx::TextureFormat::Enum::RGBA8);
			mWidthHandle      = BuildPage(mWidths.data(),     bgfx::TextureFormat::Enum::RGBA8);
			mJoinTypesHandle  = BuildPage(mJoinTypes.data(),  bgfx::TextureFormat::Enum::R8U);
			mCapTypesHandle   = BuildPage(mCapTypes.data(),   bgfx::TextureFormat::Enum::R8U);
			mDashCoordsHandle = BuildPage(mDashCoords.data(), bgfx::TextureFormat::Enum::R8);

			mIsDirty = false;
		}
	}

	void LineStyleAtlas::write(IndexT i, Styling::LineStyle const& style)
	{
		mColors[i] = style.abgr;
		//currently only storing solid width, but supports solid width, dash width, outline gap, outline width
		mWidths[i] = uint32_t((lmath::clamp(style.width, 0.0f, cMaxLineWidth) / cMaxLineWidth) * 255 + (uint32_t)(0 << 8) + (uint32_t)(0 << 16) + (uint32_t)(0 << 24));

		// encode join and cap type
		// NOTE: we may have to encode these as normalized values in a RGBA8 texture -- I'm not sure that all platforms/apis will correctly 
		//       support sampling R8U textures. it seems that windows supports R8U but not RG8U. I would guess other platforms are even pickier
		mJoinTypes[i] = (uint8_t)style.joinType;
		mCapTypes [i] = (uint8_t)style.capType;

		// write to dash atlas
		mDashAtlas.insert(style.dashArray);

		// encode index into DashAtlas
		mDashCoords[i] = uint8_t((gpu_float_t(mDashAtlas.row(style.dashArray)) / gpu_float_t(DashAtlas::cNumRows)) * 255);
	}

	void LineStyleAtlas::destroyTextures()
	{
		BgfxUtils::tryDestroy(mColorHandle);
		BgfxUtils::tryDestroy(mWidthHandle);
		BgfxUtils::tryDestroy(mJoinTypesHandle);
		BgfxUtils::tryDestroy(mCapTypesHandle);
		BgfxUtils::tryDestroy(mDashCoordsHandle);
	}

	// FillStyleAtlas --------------------------------------------------------------------------------------------------------

	static bgfx::TextureHandle TextureFromBits(std::vector<uint8_t> bits, size_t width)
	{
		ONYX_ASSERT(bits.size() * 8 % width == 0, "Invalid bit data");

		auto height = (bits.size() * 8) / width;
		auto dataSize = bits.size() * 8 * 4;

		auto mem = bgfx::alloc(uint32_t(dataSize));
		auto data = reinterpret_cast<uint32_t*>(mem->data);

		for (auto const byte : bits)
		{
			for (uint32_t bit = 1u; bit <= 128; bit <<= 1)
			{
				(*data++) = (bit & byte) == bit ? 0xFFFFFFFF : 0;
			}
		}

		return bgfx::createTexture2D(uint16_t(width), uint16_t(height), false, 1, bgfx::TextureFormat::RGBA8, 0, mem);
	}

	FillStyleAtlas::FillStyleAtlas() : 
		StyleAtlas<Styling::FillStyle>(cDefaultTextureRes),
		mPatternAtlas(Atlases::cBlitFlags | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, cPatternCellSize, 256, 1u)
	{
		mPatternAtlas.setClearColor(0xDEDEDEDE);

		std::vector<uint8_t> solidBits = std::vector<uint8_t>(cPatternCellSize * cPatternCellSize * 4, 0xFF);

		std::vector<uint8_t> hatchBits =
		{
			0x00, 0x00,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,

			0xFE, 0x7F,
			0xFE, 0x7F,

			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x80, 0x01,
			0x00, 0x00,
		};

		std::vector<uint8_t> check1Bits =
		{
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
			0x55, 0x55, 0x55, 0x55,
			0xAA, 0xAA, 0xAA, 0xAA,
		};

		std::vector<uint8_t> check4Bits =
		{
			0x0F,
			0x0F,
			0x0F,
			0x0F,
			0xF0,
			0xF0,
			0xF0,
			0xF0,
		};

		mPatternAtlas.insert("",         TextureFromBits(solidBits, 32),  bgfx::TextureFormat::Enum::RGBA8, { 32, 32 }, true);
		mPatternAtlas.insert("hatch",    TextureFromBits(hatchBits, 16),  bgfx::TextureFormat::Enum::RGBA8, { 16, 16 }, true);
		mPatternAtlas.insert("checker1", TextureFromBits(check1Bits, 32), bgfx::TextureFormat::Enum::RGBA8, { 32, 32 }, true);
		mPatternAtlas.insert("checker4", TextureFromBits(check4Bits, 8),  bgfx::TextureFormat::Enum::RGBA8, { 8, 8 },   true);
	}

	FillStyleAtlas::~FillStyleAtlas()
	{
		destroyTextures();
	}

	void FillStyleAtlas::update()
	{
		if (mIsDirty)
		{
			// update pattern atlas
			mPatternAtlas.update();

			// destroy the old textures
			destroyTextures();

			// allocate pages
			mColorHandle         = BuildPage(mColors.data(),        bgfx::TextureFormat::Enum::RGBA8);
			mPatternCoordsHandle = BuildPage(mPatternCoords.data(), bgfx::TextureFormat::Enum::RGBA8);

			mIsDirty = false;
		}
	}

	void FillStyleAtlas::write(IndexT i, Styling::FillStyle const& style)
	{
		lgal::gpu::Vector4 patternUV(0);
		if (mPatternAtlas.contains(style.pattern.key))
		{
			patternUV = mPatternAtlas.getUVOffset(style.pattern.key);
			patternUV = patternUV * 256.f;
		}

		auto patternInt = patternUV.as<uint8_t>();
		uint32_t pattern = patternInt.x | (patternInt.y << 8) | (patternInt.z << 16) | (patternInt.w << 24);

		mColors[i] = style.abgr;
		mPatternCoords[i] = pattern;
	}

	void FillStyleAtlas::destroyTextures()
	{
		BgfxUtils::tryDestroy(mColorHandle);
		BgfxUtils::tryDestroy(mPatternCoordsHandle);
	}

} }