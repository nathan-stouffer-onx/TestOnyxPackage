#include "HeightManager.h"

#include <ostream>
#include <string>
#include <vector>

#include <bimg/bimg.h>

#include <lucid/gal/Types.h>
#include <lucid/Profiler.h>

#include <Utils/UUID.h>
#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>

#include "Utils/MapMath.h"
#include "General/RenderTargetManager.h"
#include "Rendering/VertStructs.h"

namespace tiles = onyx::Tiles;

HeightManager* HeightManager::sSingleton = nullptr;

HeightManager* HeightManager::Instance()
{
	if (sSingleton == nullptr)
	{
		sSingleton = new HeightManager();
	}

	return sSingleton;
}

void HeightManager::Shutdown()
{
	if (sSingleton != NULL)
	{
		delete sSingleton;
		sSingleton = NULL;
	}
}

HeightManager::HeightManager() :
	mHighestLoadedLevel(-1)
{
	mLevelCounts.resize(MAX_HEIGHT_ZOOM_LEVEL + 1);
}

HeightManager::~HeightManager()
{
	mHeightTiles.clear();

	if (this == sSingleton)
		sSingleton = nullptr;
}

void HeightManager::insert(onyx::Tiles::TileId const& tileId, const std::shared_ptr<onyx::Tiles::HeightTile> tile)
{
	if (!contains(tileId))
	{
		++mLevelCounts[tileId.level];
	}
	mHeightTiles[tileId] = tile;
	mHighestLoadedLevel = std::max(mHighestLoadedLevel, tileId.level);
}

void HeightManager::erase(onyx::Tiles::TileId const& tileId)
{
	if (contains(tileId))
	{
		mHeightTiles.erase(tileId);
		if (mLevelCounts[tileId.level] > 0)
		{
			--mLevelCounts[tileId.level];
			
			// check if we just erased the last item in the highest loaded level
			if (tileId.level == mHighestLoadedLevel && mLevelCounts[tileId.level] < 1 && mHighestLoadedLevel > 0)
			{
				mHighestLoadedLevel--;
				while (mLevelCounts[mHighestLoadedLevel] == 0 && mHighestLoadedLevel > 0)
				{
					mHighestLoadedLevel--;		// decrement highest loaded level until we find a loaded level
				}
			}
		}
	}
}

bool HeightManager::contains(onyx::Tiles::TileId const &tileId) const
{
	return mHeightTiles.find(tileId) != mHeightTiles.end();
}

float HeightManager::heightAt(lgal::world::Vector2 const& pos, bool mercatorDistortion, bool interpolate) const
{
	std::shared_ptr<onyx::Tiles::HeightTile const> tile = highestDetailedTile(pos);
	if (tile == nullptr)
	{
		return onyx::MapMath::cBadHeight;
	}
	return tile->heightAt(pos, mercatorDistortion, interpolate);
}

std::shared_ptr<onyx::Tiles::HeightTile const> HeightManager::at(tiles::TileId const& tileId) const
{
	return mHeightTiles.at(tileId);
}

std::shared_ptr<onyx::Tiles::HeightTile const> HeightManager::highestDetailedTile(lgal::world::Vector2 const& pos) const
{
	if (onyx::MapMath::inWorldBounds(pos))
	{
		tiles::TileId tileId = onyx::Tiles::TileId::Containing(mHighestLoadedLevel, pos);
		while (tileId.level >= MIN_HEIGHT_ZOOM_LEVEL)
		{
			if (contains(tileId))
			{
				return mHeightTiles.at(tileId);
			}
			else
			{
				tileId = onyx::Tiles::TileId::Containing(tileId.level - 1, pos);
			}
		}
	}
	
	return std::shared_ptr<onyx::Tiles::HeightTile>(nullptr);
}

lgal::world::Range HeightManager::heightExtents(tiles::TileId const& tileId, bool mercatorDistortion) const
{
	if (contains(tileId))
	{
		std::shared_ptr<onyx::Tiles::HeightTile> tile = mHeightTiles.at(tileId);
		return tile->extents(mercatorDistortion).as<world_float_t>();
	}
	else if (tileId.level == 0)
	{
		return lgal::world::Range{ onyx::MapMath::cMinElevation, onyx::MapMath::cMaxElevation };
	}
	else
	{
		return heightExtents(tileId.parent(), mercatorDistortion);
	}
}

lgal::world::Range HeightManager::heightExtents(std::vector<tiles::TileId> const& tiles, bool mercatorDistortion) const
{
	lgal::world::Range extents = { std::numeric_limits<float>::max(), std::numeric_limits<float>::lowest()};

	for (tiles::TileId const& tile : tiles)
	{
		auto tileExtents = heightExtents(tile, mercatorDistortion);
		if (tileExtents.begin < extents.begin)
		{
			extents.begin = tileExtents.begin;
		}
		if (tileExtents.end > extents.end)
		{
			extents.end = tileExtents.end;
		}
	}

	return (extents.begin <= extents.end) ? extents : lgal::world::Range{ onyx::MapMath::cMinElevation, onyx::MapMath::cMaxElevation };
}


std::vector<float> HeightManager::heightAlongLine(const std::vector<lgal::gpu::Vector3>& vertices, bool loop, int numSamples, bool mercatorDistortion) const
{
	std::vector<float> heights;
	if (numSamples <= 0)
	{
		return heights;
	}

	lgal::gpu::Polyline line;
	for (size_t v = 0; v < vertices.size(); v++)
	{
		line.add(vertices[v].xy);
	}
	if (loop)
	{
		line.add(vertices[0].xy);
	}

	heights.push_back(heightAt({ vertices[0].x, vertices[0].y }, mercatorDistortion));		// insert the first point

	int n = numSamples - 1;									// compute number of steps we will make
	float step = 1.0f / ((float)n);							// compute step size in [0, 1]
	for (int v = 1; v <= n; v++)
	{
		float t = v * step;
		auto pos = line.interpolate(t);					// interpolate the position along the line
		float height = heightAt(pos.as<world_float_t>(), mercatorDistortion);
		heights.push_back(height);
	}

	return heights;
}

bool HeightManager::hasAllChildren(onyx::Tiles::TileId const& tileId) const
{
	if (tileId.level >= mHighestLoadedLevel)
	{
		return false;		// if we are at the highest loaded level, we can just return false
	}

	int childLevel = tileId.level + 1;
	if (mLevelCounts.at(childLevel) == 0)
	{
		return false;
	}
	else
	{
		for (int i = 0; i < 2; i++)			// loop over child indices, checking if they exist
		{
			for (int j = 0; j < 2; j++)
			{
				int childX = (tileId.x << 1) + i;
				int childY = (tileId.y << 1) + j;
				if (!contains({ childLevel, childX, childY }))
				{
					return false;
				}
			}
		}
	}

	return true;
}

// TODO refactor this to take in a std::vector<lgal::gpu::lgal::world::Vector2>
std::shared_ptr<HeightProfile> HeightManager::generateHeightProfileImage(std::vector<lgal::gpu::Vector3> const& points, uint32_t imageWidth, uint32_t imageHeight, float easySlope, float hardSlope, uint32_t easyColor, uint32_t hardColor)
{
	std::shared_ptr<HeightProfile> hp(new HeightProfile());

	std::shared_ptr<lgal::gpu::Polyline> line;
	for (size_t v = 0; v < points.size(); v++)
	{
		line->add(points[v].xy);
	}

	float lineLen = line->length();

	hp->pixelHeights = heightAlongLine(points, false, imageWidth);

	float maxHeight = *std::max_element(hp->pixelHeights.begin(), hp->pixelHeights.end());
	maxHeight = maxHeight * 1.25f;
	std::vector<onyx::Rendering::VertStructs::PosColor> terrainVerts;
	std::vector<onyx::Rendering::VertStructs::PosColor> lineVerts;
	float halfLineWidth = 1.f / imageHeight;
	uint32_t lineColor = 0x0; //black

	float prevHeight = -1;
	float currHeight = hp->pixelHeights[0];
	for (uint32_t i = 0; i < imageWidth; i++)
	{
		float xPos = float(i) / float(imageWidth);
		prevHeight = currHeight;
		currHeight = hp->pixelHeights[i];
		float h = currHeight / maxHeight;

		float rise = currHeight - prevHeight;
		float run = lineLen / imageWidth;
		float slope = lucid::math::atan2(rise, run) * 180.0f / lucid::math::constants::pi<float>();
		slope = std::max(slope, easySlope);
		uint32_t color = lucid::math::lerpHexColorABGR(easyColor, hardColor, std::min(1.0f, slope / hardSlope));


		terrainVerts.push_back(onyx::Rendering::VertStructs::PosColor(xPos, h, 0, color));
		terrainVerts.push_back(onyx::Rendering::VertStructs::PosColor(xPos, 0, 0, color));

		lineVerts.push_back(onyx::Rendering::VertStructs::PosColor(xPos, h + halfLineWidth, 0, lineColor));
		lineVerts.push_back(onyx::Rendering::VertStructs::PosColor(xPos, h - halfLineWidth, 0, lineColor));

	}

	bgfx::VertexBufferHandle groundVertBuffer = bgfx::createVertexBuffer(
		bgfx::copy(terrainVerts.data(), uint32_t(sizeof(onyx::Rendering::VertStructs::PosColor) * terrainVerts.size()))
		, onyx::Rendering::VertStructs::PosColor::ms_layout
	);

	bgfx::VertexBufferHandle lineVertBuffer = bgfx::createVertexBuffer(
		bgfx::copy(lineVerts.data(), uint32_t(sizeof(onyx::Rendering::VertStructs::PosColor) * lineVerts.size()))
		, onyx::Rendering::VertStructs::PosColor::ms_layout
	);

	auto shader = ShaderManager::Instance()->getShader("PosColor");

	RenderTargetManager::Instance()->renderToTexture(imageWidth, imageHeight, 0xaaeeffff, bgfx::TextureFormat::BGRA8,
		//render function
		std::function<void(bgfx::ViewId viewId)>([hp, shader, groundVertBuffer, lineVertBuffer](bgfx::ViewId viewId)
			{
				auto mtx = lgal::gpu::Identity<4>();

				shader->setParameter("u_tileMin", lgal::gpu::Vector3(0,0,0));
				shader->setParameter("u_tileMax", lgal::gpu::Vector3(1,1,1));

				// Set model matrix for rendering.
				bgfx::setTransform(mtx.elements);

				// Set vertex and index buffer.
				bgfx::setVertexBuffer(0, groundVertBuffer);

				// Set render states
				uint64_t state = 0
					| BGFX_STATE_WRITE_RGB
					| BGFX_STATE_WRITE_A
					| BGFX_STATE_PT_TRISTRIP
					;

				bgfx::setState(state);
				bgfx::submit(viewId, shader->programHandle);

				//now draw dividing line
				bgfx::setTransform(mtx.elements);
				bgfx::setVertexBuffer(0, lineVertBuffer);
				bgfx::setState(state);
				bgfx::submit(viewId, shader->programHandle);
			}),

		//finished function
				std::function<void(bgfx::TextureHandle handle)>([hp](bgfx::TextureHandle handle)
					{
						hp->mTexHandle = handle;
					})
				);
	return hp;
}

lgal::world::Vector3 HeightManager::getTerrainNormal(lgal::world::Vector3 const& center, world_float_t gridLength, int gridDim, bool mercatorDistortion) const
{
	// TODO: This size clamp should depend on our height data resolution to be honest
	constexpr world_float_t gridLengthEpsilon = 1e-2;
	if (gridLength < gridLengthEpsilon)
	{
		gridLength = gridLengthEpsilon;
	}

	// Generate uniform square grid of squares
	if (gridDim < 1) gridDim = 1;
	if (gridDim > 4) gridDim = 4;

	world_float_t gridSqLen = gridLength / static_cast<world_float_t>(gridDim);
	lgal::world::Vector3 llCorner = center + (gridLength * 0.5 * lgal::world::Vector3{ 0, -1.0, 0 }) + (gridLength * 0.5 * lgal::world::Vector3{ 0, -1.0, 0 });

	std::vector<lgal::world::Vector3> gridPoints;
	gridPoints.reserve((gridDim + 1) * (gridDim + 1));

	///
	// Subgrid index layout
	// 2-----3
	// |     |
	// |     |
	// 0-----1
	///
	// Get vertex of every square in grid
	for (int i = 0; i <= gridDim; ++i)
	{
		lgal::world::Vector3 start = llCorner + ((world_float_t)i * gridSqLen * lgal::world::Vector3 { 0, 1.0, 0 });

		for (int j = 0; j <= gridDim; ++j)
		{
			lgal::world::Vector3 samplePnt = start + (static_cast<world_float_t>(j) * gridSqLen * lgal::world::Vector3 { 1.0, 0, 0 });
			samplePnt.z = HeightManager::Instance()->heightAt({ samplePnt.x, samplePnt.y }, mercatorDistortion);
			gridPoints.push_back(samplePnt);
		}
	}

	// Turn grid into a triangle mesh, and generate normals
	world_float_t invNumNormals = 1.0 / (gridDim * gridDim);
	lgal::world::Vector3 terrainNormal{ 0, 0, 0 };
	int ni = gridDim + 1;
	for (int i = 0; i < gridDim; ++i)
	{
		for (int j = 0; j < gridDim; ++j)
		{
			// lr triangle plane
			lgal::world::Vector3 normal1 = normalize(cross(
				gridPoints[(ni * i + j) + 1] - gridPoints[ni * i + j],
				gridPoints[ni * (i + 1) + j + 1] - gridPoints[ni * i + j]));

			// ul triangle plane
			lgal::world::Vector3 normal2 = normalize(cross(
				gridPoints[ni * (i + 1) + j + 1] - gridPoints[ni * i + j],
				gridPoints[ni * (i + 1) + j] - gridPoints[ni * i + j]));

			lgal::world::Vector3 gridSqNormal = normalize(normal1 + normal2);
			terrainNormal = terrainNormal + invNumNormals * gridSqNormal;	// Mean avg the normals
		}
	}
	return normalize(terrainNormal);
}