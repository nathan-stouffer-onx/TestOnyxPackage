#ifndef HEIGHTMANAGER_H_
#define HEIGHTMANAGER_H_

#include <map>
#include <ostream>
#include <vector>
#include <memory>

#include <bgfx/bgfx.h>
#include <lucid/gal/Types.h>
#include <lucid/math/Vector.h>
#include <Utils/UUID.h>

#include "Utils/MapMath.h"
#include "Tiles/TileId.h"
#include "Tiles/HeightTile.h"

/**
* HeightManager is a class that stores height data (in kilometers) on the cpu. To request a height, use the
* HeightManager::heightAtWorldPos(float worldX, float worldY) method.
*
* HeightManager follows the singleton pattern and stores the height tiles in a hashmap with the tileID as key.
* HeightManager receives updates from the TileCache and is purged by the TileCache, all in the main thread.
*
* We receive height data as 256 x 256 tiles in slippy map format indexed with (level, x, y). To save
* memory, we reduce the tiles we receive to a coarser 64 x 64 tile.
*
*/

/*
* NOTE: Height values from the server do not require full 4-byte floats to store the precision that
* we need. We considered storing the heights as 2-byte half floats to save on memory. Via some
* benchmarking, we found that each ``viewable area'' takes up about 1 mb of height data when we use
* regular floats. While the memory savings of switching to 2-byte floats would be nice, we did some
* performance testing and found that math operations (on windows) are about 2x slower on halfs than
* on float. On android, the results seemed to be worse with halfs between 3-4x slower than floats.
* For now, we are sticking with floats, but we may switch to halfs later.
*/

// TODO set these up by configuration instead of defines
#define MIN_HEIGHT_ZOOM_LEVEL 0
#define MAX_HEIGHT_ZOOM_LEVEL 20

struct HeightProfile
{
	bgfx::TextureHandle mTexHandle = BGFX_INVALID_HANDLE;
	std::vector<float> pixelHeights;
};

class HeightManager
{
public:
	
	static HeightManager* Instance();
	static void Shutdown();

	HeightManager();
	~HeightManager();
	
	void insert(onyx::Tiles::TileId const& tileId, const std::shared_ptr<onyx::Tiles::HeightTile> tile);
	void erase(onyx::Tiles::TileId const& tileId);

	bool contains(onyx::Tiles::TileId const& tileId) const;
	bool hasAllChildren(onyx::Tiles::TileId const& tileId) const;
	
	float heightAt(lgal::world::Vector2 const& pos, bool mercatorDistortion = true, bool interpolate = true) const;
	inline lgal::world::Vector3 lockToTerrain(lgal::world::Vector2 const& pos) const { return { pos, heightAt(pos) }; }
	
	lgal::world::Range heightExtents(onyx::Tiles::TileId const& tileId, bool mercatorDistortion = true) const;
	lgal::world::Range heightExtents(std::vector<onyx::Tiles::TileId> const& tiles, bool mercatorDistortion = true) const;

	inline bool isValidHeight(float height) const { return height != onyx::MapMath::cBadHeight; }

	std::shared_ptr<onyx::Tiles::HeightTile const> at(onyx::Tiles::TileId const& tileId) const;
	std::shared_ptr<onyx::Tiles::HeightTile const> highestDetailedTile(lgal::world::Vector2 const& pos) const;

	std::vector<float> heightAlongLine(const std::vector<lgal::gpu::Vector3>& vertices, bool loop, int numSamples, bool mercatorDistortion = true) const;

	//std::shared_ptr<HeightProfile> generateHeightProfileImage(std::vector<lgal::gpu::Vector3> const& points, uint32_t imageWidth, uint32_t imageHeight, float easySlope = 0.0f, float hardSlope = 45.0f, uint32_t easyColor = 0xff00ff00, uint32_t hardColor = 0xff0000ff);

	// TODO: Figure out other ways of generating terrain normal
	// Splits quad to gridDim x gridDim axis-aligned squares. Each vertex of the square is a sample of the normal. Returns average of sampled normals
	lgal::world::Vector3 getTerrainNormal(lgal::world::Vector3 const& center, world_float_t gridLength, int gridDim = 1, bool mercatorDistortion = true) const;

private:

	static HeightManager* sSingleton;

	std::map<onyx::Tiles::TileId, std::shared_ptr<onyx::Tiles::HeightTile>> mHeightTiles;

	std::vector<size_t> mLevelCounts;
	int mHighestLoadedLevel;

	
};
#endif