#pragma once

#include <string>
#include <string_view>

#include <3rdParty/nlohmann/json.hpp>

namespace onyx::core
{

	class hashed_string
	{
	public:

		hashed_string(char const* chars) : hashed_string(std::string(chars)) {}
		hashed_string(std::string const& str) : mStr(str), mHash(std::hash<std::string>()(str)) {}

		inline bool operator==(hashed_string const& rhs) const { return mStr == rhs.mStr; }
		inline bool operator!=(hashed_string const& rhs) const { return !(*this == rhs); }

		inline bool operator==(std::string_view const& rhs) const { return mStr == rhs; }
		inline bool operator!=(std::string_view const& rhs) const { return !(*this == rhs); }

		inline bool operator==(std::string const& rhs) const { return *this == std::string_view(rhs); }
		inline bool operator!=(std::string const& rhs) const { return !(*this == rhs); }

		inline bool operator<(hashed_string const& rhs) const { return mStr < rhs.mStr; }
		inline bool operator>(hashed_string const& rhs) const { return rhs < *this; }

		operator std::string const&() const { return mStr; }
		operator std::string_view const() const { return mStr; }

		std::string const& str() const { return mStr; }
		size_t hash() const { return mHash; }

	private:

		std::string mStr;
		size_t mHash;

	};

	inline bool operator==(std::string_view const& lhs, hashed_string const& rhs) { return rhs == lhs; }
	inline bool operator==(std::string const& lhs, hashed_string const& rhs) { return rhs == lhs; }

	// NOTE: this class is less flexible than std::string_view. unlike its STL counterpart, this class cannot reference any character array.
	// it must reference a valid hashed_string object
	class hashed_string_view
	{
	public:

		hashed_string_view(hashed_string const& str) : mHashedStr(&str) {}

		inline bool operator==(hashed_string_view const& rhs) const { return *mHashedStr == *rhs.mHashedStr; }
		inline bool operator!=(hashed_string_view const& rhs) const { return !(*this == rhs); }

		inline bool operator==(std::string_view const& rhs) const { return mHashedStr->str() == rhs; }
		inline bool operator!=(std::string_view const& rhs) const { return !(*this == rhs); }

		inline bool operator==(std::string const& rhs) const { return *this == std::string_view(rhs); }
		inline bool operator!=(std::string const& rhs) const { return !(*this == rhs); }

		inline bool operator<(hashed_string_view const& rhs) const { return *mHashedStr < *rhs.mHashedStr; }
		inline bool operator>(hashed_string_view const& rhs) const { return rhs < *this; }

		operator std::string() const { return std::string(str()); }
		operator std::string_view const() const { return str(); }
		operator hashed_string() const { return *mHashedStr; }

		std::string_view const str() const { return mHashedStr->str(); }
		size_t hash() const { return mHashedStr->hash(); }

	private:

		hashed_string const* mHashedStr;

	};

	inline void from_json(nlohmann::json const& j, hashed_string& str)
	{
		str = std::string(j);
	}

}

namespace std
{

	template<>
	struct hash<onyx::core::hashed_string>
	{
		inline size_t operator()(onyx::core::hashed_string const& str) const
		{
			return str.hash();
		}
	};
	
	template<>
	struct hash<onyx::core::hashed_string_view>
	{
		inline size_t operator()(onyx::core::hashed_string_view const& str) const
		{
			return str.hash();
		}
	};

}