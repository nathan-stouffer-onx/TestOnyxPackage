#pragma once

#include <algorithm>
#include <string>
#include <unordered_map>
#include <vector>

namespace onyx::core
{

	template<typename V>
	class small_map
	{
	public:

		using pair_t = std::pair<std::string, V>;

		using iterator = typename std::vector<pair_t>::iterator;
		using const_iterator = typename std::vector<pair_t>::const_iterator;

	public:

		explicit small_map(std::unordered_map<std::string, V> const& map);

		iterator find(std::string_view const query)
		{
			size_t i = index(query);
			return (i == std::numeric_limits<size_t>::max()) ? end() : mValues.begin() + i;
		}

		const_iterator find(std::string_view const query) const
		{
			size_t i = index(query);
			return (i == std::numeric_limits<size_t>::max()) ? end() : mValues.begin() + i;
		}

		V& at(std::string_view const query) { return mValues[index(query)].second; }

		iterator begin() { return mValues.begin(); }
		iterator end() { return mValues.end(); }

		const_iterator begin() const { return mValues.begin(); }
		const_iterator end() const { return mValues.end(); }

	private:

		size_t index(std::string_view const query) const;

		std::vector<char> mKeys;
		std::vector<size_t> mKeyStarts;
		std::vector<size_t> mHashes;

		std::vector<pair_t> mValues;

	};

	template<typename V>
	small_map<V>::small_map(std::unordered_map<std::string, V> const& map)
	{
		// reserve memory
		mValues.reserve(map.size());
		mKeyStarts.reserve(map.size());
		mHashes.reserve(map.size());
		size_t count = 0;
		for (auto const& [key, _] : map)
		{
			count += key.size() + 1;
		}
		mKeys.resize(count);

		struct hashed_t
		{
			std::string key;
			size_t hash;

			inline bool operator<(hashed_t const& rhs) const
			{
				return (hash == rhs.hash) ? key < rhs.key : hash < rhs.hash;
			}
		};

		std::vector<hashed_t> hashed;
		hashed.reserve(map.size());
		std::hash<std::string> func;
		for (auto const& [key, _] : map)
		{
			hashed.push_back({ key, func(key) });
		}
		std::sort(hashed.begin(), hashed.end());

		// copy data
		char* data = mKeys.data();
		size_t offset = 0;
		for (auto const& [key, hash] : hashed)
		{
			mKeyStarts.push_back(offset);
			size_t len = key.size() + 1;
			std::memcpy(data + offset, key.data(), len);
			offset += len;
			mHashes.push_back(hash);
			mValues.push_back(pair_t{ key, map.at(key) });
		}
	}

	template<typename V>
	size_t small_map<V>::index(std::string_view const query) const
	{
		size_t hash = std::hash<std::string_view>{}(query);
		auto its = std::equal_range(mHashes.begin(), mHashes.end(), hash);
		
		for (auto it = its.first; it != its.second; ++it)
		{
			size_t i = it - mHashes.begin();
			std::string_view str = &mKeys[mKeyStarts[i]];
			if (query == str)
			{
				return i;
			}
		}
		return std::numeric_limits<size_t>::max();
	}

}