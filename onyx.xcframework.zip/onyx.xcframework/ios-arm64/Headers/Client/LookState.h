#ifndef __CLIENT_LOOK_STATE_H__
#define __CLIENT_LOOK_STATE_H__

#include <lucid/gal/Types.h>

#include "Camera/CameraState.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace Client {

	/*
	* A helper struct so that the client can easily set a CameraState via a LookState. This could be helpful for 
	* highlighting a specific point on the map or when transferring from Mapbox to Core (Mapbox's camera info
	* is based on a look point).
	*/

	struct LookState
	{
		MapMath::LonLatHeight lookPos;

		world_float_t heading;
		world_float_t pitch;
		world_float_t radius;

		world_float_t fov;

		Camera::CameraState::Mode mode;

		Camera::CameraState toCameraState() const
		{
			return Camera::CameraState{ lookPos.toWorldPos(), heading, pitch, radius, fov, Camera::DefaultAspect, Camera::DefaultNear, Camera::DefaultFar, mode };
		}
	};

} }

#endif