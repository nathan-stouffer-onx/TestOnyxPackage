#pragma once

#include "MapViewer.h"

/**
 * Binding-layer API for extending API functionality for platform-specific bindings.
 */
namespace onyx::api::internal
{
	// This is all for DebugUI integration
	class InputHandlerStub
	{
	public:
		virtual bool usedInput() = 0;
		virtual void pointerMoved(lgal::screen::Vector2 const &position) = 0;
		virtual void wheelMoved(lgal::screen::Vector2 const& delta) = 0; // Support 2 dimensional wheel ... though we'll probably never use it.
		virtual void pointerUp(uint32_t pointerId) = 0;
		virtual void pointerDown(uint32_t pointerId) = 0;
		virtual ~InputHandlerStub() {}
	};

	extern std::unique_ptr<InputHandlerStub> inputCallback;
}