#pragma once

#include "MapViewer.h"

/**
 * Binding-layer API for extending API functionality for platform-specific bindings.
 */
namespace onyx::api::internal
{
	extern MapViewer mapViewer;
}
