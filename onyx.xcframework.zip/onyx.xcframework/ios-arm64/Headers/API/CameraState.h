#pragma once

#include <lucid/gal/Types.h>
#include <Camera/CameraState.h>
#include <Utils/MapMath.h>

#include "LonLatElevation.h"

namespace onyx::api
{
	struct CameraState
	{
		LonLatElevation position;

		world_float_t heading;	// units in degrees
		world_float_t pitch;	// units in degrees

		CameraState() :
			position(LonLatElevation{ 0.0, 0.0, 10 * MapMath::kilometersToMeters }),
			heading(lmath::radiansToDegrees(Camera::DefaultHeading)),
			pitch(lmath::radiansToDegrees(Camera::DefaultPitch))
		{
		}

		CameraState(LonLatElevation const& position, world_float_t heading, world_float_t pitch) :
			position(position),
			heading(heading),
			pitch(pitch)
		{
		}

		explicit CameraState(Camera::CameraState const& state) :
			position(LonLatElevation(MapMath::LonLatElevation(state.position))),
			heading(lmath::radiansToDegrees(state.heading)),
			pitch(lmath::radiansToDegrees(state.pitch))
		{
		}

		[[nodiscard]] Camera::CameraState toInternal() const
		{
			return Camera::CameraState{ position.toWorldPosition(), lmath::degreesToRadians(heading), lmath::degreesToRadians(pitch) };
		}
	};
}
