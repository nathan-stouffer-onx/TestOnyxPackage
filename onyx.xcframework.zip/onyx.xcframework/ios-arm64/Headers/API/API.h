#pragma once

#include <Client/CameraState.h>
#include <Client/LonLatElevation.h>
#include <Client/LookState.h>
#include <Events/Events.h>
#include <Tiles/TileId.h>

/**
 * Onyx public API.
 *
 * Exposes functionality to be used by client applications to implement the Onyx viewer.
 *
 * Units:
 *     - World units are in meters and degrees and elevations are relative to sea level.
 *     - Screen and viewport units are in pixels.
 *     - Color values are in RGBA format from 0.0 to 1.0.
 *     - Time durations, such as animation durations, are in milliseconds unless otherwise stated.
 *
 * Terms:
 *     - Screen:    Renderable area where any graphics are drawn for the Onyx viewer.
 *     - Viewport:  Individual map viewer viewports. Most often a single viewport is used.
 *     - Elevation: Vertical distance from sea level.
 *     - Height:    Vertical distance from sea level distorted by WGS84 spheroid.
 *
 * \todo Comment struct members in each struct. Will follow-up with this when generating doxygen documentation.
 */

namespace onyx::api
{
	/**
	 * Base types.
	 *
	 * \defgroup baseType
	 * \{
	 */

	//

	/**
	 * String type.
	 *
	 * \warning This should be mapped to platform-native string types in functions that return this type or expect it as a parameter.
	 */
	using String = std::string;

	/**
	 * Dynamic array type.
	 *
	 * \warning This should be mapped to platform-native dynamic array types in functions that return this type or expect it as a parameter.
	 */
	template<typename T>
	using DynamicArray = std::vector<T>;

	/**
	 * Function reference that takes no arguments and returns no values.
	 *
	 * \warning This should be mapped to platform-native void-function types in functions that return this type or expect it as a parameter.
	 */
	using VoidFunction = std::function<void()>;

	/**
	 * Raw pointer/reference type.
	 *
	 * Often used as an opaque handle to an underlying type that can vary per-platform.
	 *
	 * \warning This should be mapped to platform-native pointer or reference types in functions that return this type or expect it as a parameter.
	 */
	using RawPointer = void*;

	/** \} */ // End of baseType group.

	/**
	 * Onyx struct types.
	 *
	 * \defgroup onyxStruct
	 * \{
	 */

	//

	/**
	 * Struct representing an x and y point as integer values.
	 */
	using Vector2Int = lucid::math::Vector<int, 2>;

	/**
	 * Struct representing a range of values as beginning and ending value.
	 */
	using Range = lgal::world::Range;

	/**
	 * Struct representing a longitude and latitude geographic position.
	 */
	using LonLat = MapMath::LonLat;

	/**
	 * Struct representing a longitude and latitude geographic position along with an elevation.
	 */
	using LonLatElevation = Client::LonLatElevation;

	/**
	 * Struct representing the camera's position with an eye position.
	 */
	using CameraState = Client::CameraState;

	/**
	 * Struct representing the camera's position with a focus point and radius.
	 *
	 * Similar to CameraState, helper struct to make it easier to set the camera state.
	 */
	using LookState = Client::LookState;

	/**
	 * Struct representing the camera's position with a focus point and radius.
	 *
	 * Similar to LookState but it includes no elevation information -- the viewport infers elevation from the terrain, helper struct to make it easier to set the camera state.
	 */
	using LookState2D = Client::LookState2D;

	/**
	 * Struct that identifies a tile via its coordinates and zoom level.
	 */
	using TileId = Tiles::TileId;

	/**
	 * Struct representing a color.
	 */
	using Color = lgal::Color;

	/** \} */ // End of onyxStruct group.

	/**
	 * Onyx enum types.
	 *
	 * \defgroup onyxEnum
	 * \{
	 */

	//

	/**
	 * Enum representing the type of an event.
	 */
	using EventType = Events::EventType;

	/** \} */ // End of onyxEnum group.

	/**
	 * Map viewer configuration.
	 *
	 * \defgroup mapViewer
	 * \{
	 */

	//

	/**
	 * Sets the maximum number of concurrent tile requests the viewer will submit
	 *
	 * \param maximum Maximum to set.
	 */
	void setMaxConcurrentTileRequests(int maximum);

	/**
	 * Gets the map viewer screen size.
	 *
	 * \return Map viewer screen size.
	 */
	Vector2Int getScreenSize();

	/**
	 * Sets the map viewer screen size.
	 *
	 * \param size Map viewer screen size to set.
	 */
	void setScreenSize(Vector2Int size);

	/**
	 * Gets the viewport size.
	 *
	 * \param viewportId Viewport ID to use.
	 * \return Viewport size.
	 */
	Vector2Int getViewportSize(int viewportId);

	/**
	 * Gets the previous tile load time.
	 *
	 * \param viewportId Viewport ID to use.
	 * \return Tile load time.
	 */
	double getTileLoadTime(int viewportId);

	/**
	 * Gets a the most recently loaded tiles by a given time.
	 *
	 * \param previousTime Time to look back for recently loaded tiles.
	 * \return Recently loaded tiles.
	 */
	DynamicArray<TileId> getRecentTiles(double previousTime);

	/**
	 * Gets the last frame time.
	 *
	 * \return Last frame time.
	 */
	double getLastFrameTime();

	/**
	 * Gets the average frame time.
	 *
	 * \return Average frame time.
	 */
	double getAvgFrameTime();

	/** \} */ // End of mapViewer group.

	/**
	 * Event handling.
	 *
	 * \defgroup events
	 * \{
	 */

	//

	/**
	 * Registers an event callback.
	 *
	 * \param type Event type to register for.
	 * \param callbackFn Callback to invoke when the event is triggered.
	 */
	void addEventCallback(EventType type, VoidFunction callbackFn);

	/** \} */ // End of events group.

	/**
	 * Camera configuration, control, and utilities.
	 *
	 * \defgroup camera
	 * \{
	 */

	//

	/**
	 * Computes the screen position given a world position in lon, lat.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param worldPosition The world position to convert to screen position.
	 * \return Screen position.
	 */
	Vector2Int worldLonLatToViewport(int viewportId, LonLat worldPosition);

	/**
	 * Computes the screen position given a world position in lon, lat, elevation.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param worldPosition The world position to convert to screen position.
	 * \return Screen position.
	 */
	Vector2Int worldLonLatElevationToViewport(int viewportId, LonLatElevation worldPosition);

	/**
	 * Computes the world position given a screen position.
	 *
	 * \param viewportId The viewport ID to use.
	 * \param screenPosition The screen position to convert to world position.
	 * \return World position.
	 */
	LonLatElevation viewportToWorldLonLatElevation(int viewportId, Vector2Int screenPosition);

	/**
	 * Gets the elevation at a given world position.
	 *
	 * \param worldPosition World position to get the elevation at.
	 * \return Elevation at the given world position.
	 */
	float getElevationAt(LonLat worldPosition);

	/**
	 * Gets the camera state.
	 *
	 * \param viewportId Viewport ID to use.
	 * \return Camera state.
	 */
	CameraState getCameraState(int viewportId);

	/**
	 * Sets the camera state.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param cameraState Camera state to set.
	 */
	void setCameraState(int viewportId, CameraState cameraState);

	/**
	 * Sets the camera's look state.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param lookState Camera's look state to set.
	 */
	void setLookState(int viewportId, LookState lookState);

	/**
	 * Flies the camera to a camera state with the given animation duration.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param destination CameraState to fly to.
	 * \param duration Duration of the animation.
	 */
	void flyToCameraState(int viewportId, CameraState destination, float duration);

	/**
	 * Flies the camera to a look state with the given animation duration.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param destination LookState to fly to.
	 * \param duration Duration of the animation.
	 */
	void flyToLookState(int viewportId, LookState destination, float duration);

	/**
	 * Flies the camera to a look state with the given animation duration.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param destination LookState2D to fly to.
	 * \param duration Duration of the animation.
	 */
	void flyToLookState2D(int viewportId, LookState2D destination, float duration);

	/**
	 * Zooms the camera about the focus point by the scalar amount over the given duration.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param focusPoint World position to zoom about.
	 * \param scalar Unitless value that scales the radius by particular amount. [0, 1) zooms in and (1, +inf) zooms out.
	 * \param duration Duration of the animation.
	 */
	void zoom(int viewportId, LonLatElevation focusPoint, float scalar, float duration);

	/**
	 * Orbits the camera about the focus point by the given delta heading and delta pitch over the given duration.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param focusPoint World position to orbit about.
	 * \param deltaHeading Delta heading to orbit by.
	 * \param deltaPitch Delta pitch to orbit by.
	 * \param radiusMultiplier Radius multiplier to orbit by.
	 * \param duration Duration of the animation.
	 */
	void orbit(int viewportId, LonLatElevation focusPoint, float deltaHeading, float deltaPitch, float radiusMultiplier, float duration);

	/**
	 * Rotates the camera about the focus point by the given delta heading and delta pitch over the given duration.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param focusPoint World position to rotate about.
	 * \param deltaHeading Delta heading to rotate by.
	 * \param deltaPitch Delta pitch to rotate by.
	 * \param duration Duration of the animation.
	 */
	void rotate(int viewportId, LonLatElevation focusPoint, float deltaHeading, float deltaPitch, float duration);

	/** \} */ // End of camera group.

	/**
	 * Style configuration
	 *
	 * \defgroup style
	 * \{
	 */

	//

	/**
	 * Sets the style on the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param style Style json serialized as a string.
	 */
	void setStyle(int viewportId, String style);

	/**
	 * Adds a source to the style of the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param id ID of the source to be added.
	 * \param source Source json serialized as a string.
	 */
	void addSource(int viewportId, String id, String source);

	/**
	 * Removes a source from the style of the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param id ID of the source to remove.
	 */
	void removeSource(int viewportId, String id);

	/**
	 * Adds a layer to the end of the style of the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param layer Layer json serialized as a string.
	 */
	void addLayer(int viewportId, String layer);

	/**
	 * Adds a layer to the style of the given viewport -- added before the layer referenced by beforeId.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param layer Layer json serialized as a string.
	 * \param beforeId ID of the layer to insert before.
	 */
	void addLayerBefore(int viewportId, String layer, String beforeId);

	/**
	 * Removes a layer from the style of the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param id ID of the layer to remove.
	 */
	void removeLayer(int viewportId, String id);

	/**
	 * Toggles a layer in the style of the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param id ID of the layer to remove.
	 * \param visibility Visibility of the layer -- must be 'visible' or 'none'.
	 */
	void toggleLayer(int viewportId, String id, String visibility);

	/**
	 * Toggles a layer group in the style of the given viewport.
	 *
	 * \param viewportId Viewport ID to use.
	 * \param group ID of the layer to remove.
	 * \param visibility Visibility of the layer -- must be 'visible' or 'none'.
	 */
	void toggleLayerGroup(int viewportId, String group, String visibility);
	
	/**
	* Controls parameters applied to the viewport when it's splatted to the screen
	* 
	* \param struct that holds all available parameters
	*/
	void setPostProcessParams(const float sharpen);

	/** \} */ // End of style group.

	/**
	 * Debug.
	 *
	 * \defgroup debug
	 * \{
	 */

	//

	/**
	 * Toggles the visibility the debug UI.
	 *
	 * \param visible Debug UI visibility state to set.
	 */
	void toggleDebugUI(bool visible);

	/** \} */ // End of debug group.

	/**
	 * Waypoint management.
	 *
	 * \defgroup waypoint
	 * \{
	 */

	//

	/**
	 * Adds a waypoint.
	 *
	 * \param uuid Unique identifier for the waypoint.
	 * \param position Position of the waypoint.
	 * \param color Color of the waypoint.
	 * \todo This will be deprecated in favor of adding waypoints via the stylesheet.
	 *
	 * \deprecated (SOON) Will be replaced by stylesheet functionality.
	 */
	void addWaypoint(String uuid, LonLat position, Color color);

	/**
	 * Gets the waypoint position.
	 *
	 * \param uuid Unique identifier for the waypoint.
	 * \param position New position of the waypoint.
	 * \return Position of the waypoint.
	 * \todo This will be deprecated in favor of updating waypoints via the stylesheet.
	 *
	 * \deprecated (SOON) Will be replaced by stylesheet functionality.
	 */
	void setWaypointPosition(String uuid, LonLat position);

	/**
	 * Deletes a waypoint.
	 *
	 * \param uuid Unique identifier for the waypoint.
	 * \todo This will be deprecated in favor of removing waypoints via the stylesheet.
	 *
	 * \deprecated (SOON) Will be replaced by stylesheet functionality.
	 */
	void deleteWaypoint(String uuid);

	/** \} */ // End of waypoint group.
}
