#pragma once

#include <lucid/gal/Types.h>
#include <Utils/MapMath.h>

namespace onyx::api
{

	/**
	 * Represents a point on the globe with elevation in meters.
	 */
	struct LonLatElevation
	{
		world_float_t lon;
		world_float_t lat;
		world_float_t elevation; // Value in meters.

		LonLatElevation()
			: lon(0.0)
			, lat(0.0)
			, elevation(0.0)
		{
		}

		LonLatElevation(world_float_t const lon, world_float_t const lat, world_float_t const elevation)
			: lon(lon)
			, lat(lat)
			, elevation(elevation)
		{
		}

		LonLatElevation(MapMath::LonLat const& pos, world_float_t const elevation)
			: lon(pos.lon)
			, lat(pos.lat)
			, elevation(elevation)
		{}

		explicit LonLatElevation(MapMath::LonLatElevation const& rhs)
			: lon(rhs.lon)
			, lat(rhs.lat)
			, elevation(rhs.elevation * MapMath::kilometersToMeters)
		{
		}

		[[nodiscard]] lgal::world::Vector3 toWorldPosition() const
		{
			return MapMath::LonLatElevation{ lon, lat, elevation * MapMath::metersToKilometers }.toWorldPos();
		}
	};

}
