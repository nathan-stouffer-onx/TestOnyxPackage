#include "API.h"
#include "API_Internal.h"

#include <WKT/WKTParser.h>

#include "Camera/Controllers/Animators/EaseTo.h"
#include "Camera/Controllers/Animators/FlyTo.h"
#include "Camera/Controllers/Animators/OrbitOn.h"
#include "Camera/Controllers/Animators/Rotate.h"
#include "Camera/Controllers/Animators/ZoomOn.h"
#include "../CameraSystem/FlybyGenerator.h"

namespace onyx::api
{
	namespace internal
	{
		//Experimental stuff (note, we may want a better way to handle this?)
		std::shared_ptr<onyx::Experimental::FlybyGenerator> flyby;
		std::unique_ptr<InputHandlerStub> inputCallback;
	}

	using namespace internal;

	void setMaxConcurrentTileRequests(int maximum)
	{
		MapViewer::Instance()->setMaxConcurrentTileRequests(static_cast<size_t>(maximum));
	}

	Vector2Int getScreenSize()
	{
		return MapViewer::Instance()->getScreenSize().as<int>();
	}

	void setScreenSize(const Vector2Int size)
	{
		MapViewer::Instance()->resize(size.x, size.y);
	}

	Vector2Int getViewportSize(const int viewportId)
	{
		return MapViewer::Instance()->getViewportSize(viewportId).as<int>();
	}

	double getTileLoadTime(const int viewportId)
	{
		return MapViewer::Instance()->tileLoadTimeMS(viewportId);
	}

	DynamicArray<TileId> getRecentTiles(const double previousTime)
	{
		return MapViewer::Instance()->recentTiles(previousTime);
	}

	double getLastFrameTime()
	{
		return MapViewer::Instance()->lastFrameTimeMS();
	}

	double getAvgFrameTime()
	{
		return MapViewer::Instance()->avgFrameTimeMS();
	}

	void addEventCallback(const EventType type, VoidFunction callbackFn)
	{
		addCallback(type, callbackFn);
	}

	Vector2Int worldLonLatToViewport(const int viewportId, const LonLat worldPosition)
	{
		const auto normalizedScreen = MapViewer::Instance()->project(viewportId, worldPosition.toVec2());
		const auto size = MapViewer::Instance()->getViewportSize(viewportId).as<int>();
		return { static_cast<int>(normalizedScreen.x) * size.x, static_cast<int>(normalizedScreen.y) * size.y };
	}

	Vector2Int worldLonLatElevationToViewport(const int viewportId, const LonLatElevation worldPosition)
	{
		const auto normalizedScreen = MapViewer::Instance()->project(viewportId, worldPosition.toWorldPosition());
		const auto size = MapViewer::Instance()->getViewportSize(viewportId).as<int>();
		return { static_cast<int>(normalizedScreen.x) * size.x, static_cast<int>(normalizedScreen.y) * size.y };
	}

	LonLatElevation viewportToWorldLonLatElevation(const int viewportId, const Vector2Int screenPosition)
	{
		lgal::world::Vector3 point = MapViewer::Instance()->unproject(viewportId, screenPosition.x, screenPosition.y);
		return LonLatElevation(MapMath::LonLatElevation(point));
	}

	LonLatElevation viewportCenterToWorldLonLatElevation(const int viewportId)
	{
		lgal::world::Vector3 point = MapViewer::Instance()->unproject(viewportId, lgal::world::Vector2(0.5, 0.5));
		return LonLatElevation(MapMath::LonLatElevation(point));
	}

	float getElevationAt(const LonLat worldPosition)
	{
		return MapViewer::Instance()->elevationAt(worldPosition.toVec2());
	}

	CameraState getCameraState(const int viewportId)
	{
		return CameraState(MapViewer::Instance()->getCameraState(viewportId));
	}

	ZoomState getZoomState(const int viewportId)
	{
		Camera::CameraState state = MapViewer::Instance()->getCameraState(viewportId);
		lgal::world::Vector3 look = MapViewer::Instance()->unproject(viewportId, lgal::world::Vector2(0.5, 0.5));
		world_float_t zoom = MapMath::zoom(state.position, look);
		LonLat center(look.xy);
		return ZoomState(center, lmath::radiansToDegrees(state.heading), lmath::radiansToDegrees(state.pitch), zoom);
	}

	void setCameraState(const int viewportId, const CameraState cameraState)
	{
		MapViewer::Instance()->setCameraState(viewportId, cameraState.toInternal());
	}

	void setLookState(const int viewportId, const LookState lookState)
	{
		MapViewer::Instance()->setCameraState(viewportId, lookState.toCameraState());
	}

	void setLookState2D(const int viewportId, const LookState2D lookState)
	{
		flyToLookState2D(viewportId, lookState, 0.f);
	}

	void setZoomState(const int viewportId, const ZoomState zoomState)
	{
		flyToZoomState(viewportId, zoomState, 0.f);
	}

	void setBoundsState(const int viewportId, BoundsState boundsState)
	{
		flyToLookState2D(viewportId, boundsState.toLookState2D(), 0.f);
	}

	void easeToCameraState(const int viewportId, const CameraState destination, const float duration)
	{
		const auto source = MapViewer::Instance()->getCameraState(viewportId);
		std::shared_ptr<Camera::CameraController> controller = std::make_shared<Camera::Controllers::EaseTo>(source, destination.toInternal(), duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void easeToLookState(const int viewportId, const LookState destination, const float duration)
	{
		easeToCameraState(viewportId, CameraState(destination.toCameraState()), duration);
	}

	void easeToLookState2D(const int viewportId, const LookState2D destination, const float duration)
	{
		const auto source = MapViewer::Instance()->getCameraState(viewportId);
		lgal::world::Vector2 focus = destination.focus.toWorldPos();
		world_float_t heading = lmath::degreesToRadians(destination.heading);
		world_float_t pitch = lmath::degreesToRadians(destination.pitch);
		world_float_t radius = destination.radius * MapMath::metersToKilometers * MapMath::mercatorDistortion(destination.focus);
		MapMath::Spherical spherical = { heading, pitch, radius };
		auto controller = std::make_shared<Camera::Controllers::EaseTo2D>(source, focus, spherical, duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void easeToZoomState(const int viewportId, const ZoomState destination, const float duration)
	{
		easeToLookState2D(viewportId, destination.toLookState2D(), duration);
	}

	void easeToBoundsState(const int viewportId, const BoundsState destination, const float duration)
	{
		easeToLookState2D(viewportId, destination.toLookState2D(), duration);
	}

	void flyToCameraState(const int viewportId, const CameraState destination, const float duration)
	{
		const auto source = MapViewer::Instance()->getCameraState(viewportId);
		std::shared_ptr<Camera::CameraController> controller = std::make_shared<Camera::Controllers::FlyTo>(source, destination.toInternal(), duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void flyToLookState(const int viewportId, const LookState destination, const float duration)
	{
		flyToCameraState(viewportId, CameraState(destination.toCameraState()), duration);
	}

	void flyToLookState2D(const int viewportId, const LookState2D destination, const float duration)
	{
		const auto source = MapViewer::Instance()->getCameraState(viewportId);
		lgal::world::Vector2 focus = destination.focus.toWorldPos();
		world_float_t heading = lmath::degreesToRadians(destination.heading);
		world_float_t pitch = lmath::degreesToRadians(destination.pitch);
		world_float_t radius = destination.radius * MapMath::metersToKilometers * MapMath::mercatorDistortion(destination.focus);
		MapMath::Spherical spherical = { heading, pitch, radius };
		auto controller = std::make_shared<Camera::Controllers::FlyTo2D>(source, focus, spherical, duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void flyToZoomState(const int viewportId, const ZoomState destination, const float duration)
	{
		flyToLookState2D(viewportId, destination.toLookState2D(), duration);
	}

	void flyToBoundsState(const int viewportId, const BoundsState destination, const float duration)
	{
		flyToLookState2D(viewportId, destination.toLookState2D(), duration);
	}

	void flybyGeoJson(const int viewportId, const String geojson, const float duration, const float radiusGuide, const float pitchGuide)
	{
		auto vp = MapViewer::Instance()->getViewport(viewportId);
		auto points = Experimental::FlybyGenerator::ParseFromGeoJson(geojson);
		Experimental::FlybyGenerator::PathConfig config;
		config.durationMS = duration;
		config.radiusGuide = radiusGuide * 0.001;
		config.pitchGuide = lmath::degreesToRadians(pitchGuide);
		flyby.reset(new Experimental::FlybyGenerator(points, config, vp->getHeightAtlas(), vp->getCameraState(), vp->getStyle()));
		auto cam = flyby->getFlyby();
		MapViewer::Instance()->setController(viewportId, cam);
	}

	void zoom(const int viewportId, const LonLatElevation focusPoint, const float scalar, const float duration)
	{
		auto source = MapViewer::Instance()->getCameraState(viewportId);
		auto controller = std::make_shared<Camera::Controllers::ZoomOn>( source, focusPoint.toWorldPosition(), scalar, duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void orbit(const int viewportId, const LonLatElevation focusPoint, const float deltaHeading, const float deltaPitch, const float radiusMultiplier, const float duration)
	{
		auto source = MapViewer::Instance()->getCameraState(viewportId);
		auto controller = std::make_shared<Camera::Controllers::OrbitOn>(source, focusPoint.toWorldPosition(), lmath::degreesToRadians(deltaHeading), lmath::degreesToRadians(deltaPitch), radiusMultiplier, duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void rotate(const int viewportId, const LonLatElevation focusPoint, const float deltaHeading, const float deltaPitch, const float duration)
	{
		auto source = MapViewer::Instance()->getCameraState(viewportId);
		auto controller = std::make_shared<Camera::Controllers::Rotate>(source, focusPoint.toWorldPosition(), lmath::degreesToRadians(deltaHeading), lmath::degreesToRadians(deltaPitch), duration);
		MapViewer::Instance()->setController(viewportId, controller);
	}

	void setStyle(int viewportId, String style)
	{
		MapViewer::Instance()->setStyle(viewportId, style);
	}

	void addSource(int viewportId, String id, String source)
	{
		MapViewer::Instance()->addSource(viewportId, id, source);
	}

	void removeSource(int viewportId, String id)
	{
		MapViewer::Instance()->removeSource(viewportId, id);
	}

	void addLayer(int viewportId, String layer)
	{
		MapViewer::Instance()->addLayer(viewportId, layer);
	}

	void addLayerBefore(int viewportId, String layer, String beforeId)
	{
		MapViewer::Instance()->addLayer(viewportId, layer, beforeId);
	}

	void removeLayer(int viewportId, String id)
	{
		MapViewer::Instance()->removeLayer(viewportId, id);
	}

	void toggleLayer(int viewportId, String id, String visibility)
	{
		MapViewer::Instance()->toggleLayer(viewportId, id, visibility);
	}

	void toggleLayerGroup(int viewportId, String group, String visibility)
	{
		MapViewer::Instance()->toggleLayerGroup(viewportId, group, visibility);
	}

	void setPostProcessParams(const float sharpen)
	{
		MapViewer::Instance()->getViewportManager().setPostProcessParams(sharpen);
	}

	void toggleDebugUI(bool visible)
	{
		MapViewer::Instance()->setShowDebugUI(visible);
	}

	void addWaypoint(const String uuid, const LonLat position, const Color color)
	{
		MapViewer::Instance()->addWaypoint(uuid, { position.toWorldPos(), 0.0 }, color);
	}

	void setWaypointPosition(const String uuid, const LonLat position)
	{
		MapViewer::Instance()->moveWaypointTo(uuid, { position.toWorldPos(), 0.0 });
	}

	void deleteWaypoint(const String uuid)
	{
		MapViewer::Instance()->deleteWaypoint(uuid);
	}

	FontFace getDefaultFont()
	{
		return Font::M3DFontManager::random(100ul);
	}

	/// TODO (scott)
	// expose Polyline via API
	void addLabel(int viewportId, const String key, const String text, const DynamicArray<Vector2Int>& points, const Styling::TextStyle& style, onyx::Styling::SymbolPlacement placement)
	{
		if (points.empty())
		{
			return;
		}

		auto vp = MapViewer::Instance()->getViewport(viewportId);

		if (vp == nullptr)
		{
			return;
		}

		logI("style flags: %d", int(style.flags));

		auto fontPtr = Style::TextStyleManager::find(style);
		lgal::tile::Polyline linestring;
		for (auto const& pt : points)
		{
			linestring.add({ globe_float_t(pt.x), globe_float_t(pt.y) });
		}

		auto caps = bgfx::getCaps();

		auto sharedGeom = std::make_shared<Vector::LinestringFeature>(0, linestring);
		auto ptr = new DataObjects::MapLabel(Styling::Formatted(text), { points.front().as<world_float_t>(), caps->homogeneousDepth ? -1. : 0 }, fontPtr, { 0, 0, 0 }, sharedGeom, false, Utils::SpaceTypes::ScreenPx);
		std::shared_ptr<DataObjects::MapLabel> lbl(ptr);
		if (points.size() > 1)
		{
			auto const& p1 = points[1];
			auto const& p2 = points.front();
			auto dir = (p1 - p2).as<gpu_float_t>();
			lbl->setTextDirection(lmath::normalize(dir));
		}
		lbl->setForce(true);
		lbl->setAlpha(255);

		vp->getState()->mSymbolCollection.append(key, std::make_shared<DataObjects::MapSymbol>(lbl, placement));
		vp->invalidate();

	}

	void addLabelDefaultStyle(int viewportId, const String key, const String text, const DynamicArray<Vector2Int> &points, onyx::Styling::SymbolPlacement placement)
	{
		if (points.empty())
		{
			return;
		}

		auto vp = MapViewer::Instance()->getViewport(viewportId);

		if (vp == nullptr)
		{
			return;
		}

		logD("Add Label - key: %s\t\ttext: %s\t\tpoints: %d", key.c_str(), text.c_str(), int(points.size()));

		Styling::FontFace font;
		font.name = "montefore";

		font.fontType = FONT_TYPE_DISTANCE_OUTLINE;
		font.pixelSize = 50;

		//TODO - control styling by platform side
		Styling::TextStyle style;
		style.font = font;
		style.color = lgal::Color::FromRGBA(0xFFFFFFFF);
		style.haloColor = lgal::Color::FromRGBA(0x000000FF);
		style.backgroundColor = lgal::Color::FromRGBA(0x0);
		style.anchors.push_back(Styling::Anchor::CENTER);
		style.flags = Styling::TextStyleFlags::NORMAL;

		addLabel(viewportId, key, text, points, style, placement);
	}

	void clearLabels(int viewportId, const String key)
	{
		auto vp = MapViewer::Instance()->getViewport(viewportId);

		if (vp == nullptr)
		{
			return;
		}

		vp->getState()->mSymbolCollection.erase(key);
		vp->invalidate();
	}

	void setScreenLogo(int viewportId, int logoId, int screenPosX, int screenPosY)
	{
		MapViewer::Instance()->setScreenLogo(viewportId, logoId, lgal::screen::Vector2(screenPosX, screenPosY));
	}

	void setPointerPosition(uint32_t pointerId, double newX, double newY, double newPressure)
	{
		double x = std::clamp(newX, -1.0, 1.0);
		double y = std::clamp(newY, -1.0, 1.0);

		if (inputCallback != nullptr)
		{
			if (pointerId == 0)
			{
				auto size = MapViewer::Instance()->getScreenSize();
				inputCallback->pointerMoved({ screen_coord_t(0.5f * (x + 1.0f) * size.x),
												screen_coord_t(0.5f * (y + 1.0f) * size.y) });
			}

			if (inputCallback->usedInput()) return;
		}

		MapViewer::Instance()->getInput()->setPointerPosition(pointerId, x, y, newPressure);

	}

	void setPointerUp(uint32_t pointerId)
	{
		if (inputCallback != nullptr)
		{
			inputCallback->pointerUp(pointerId);
			if (inputCallback->usedInput()) return;
		}

		MapViewer::Instance()->getInput()->setPointerUp(pointerId);
	}

	void setPointerDown(uint32_t pointerId)
	{
		if (inputCallback != nullptr)
		{
			inputCallback->pointerDown(pointerId);
			if (inputCallback->usedInput()) return;
		}

		MapViewer::Instance()->getInput()->setPointerDown(pointerId);
	}
}
