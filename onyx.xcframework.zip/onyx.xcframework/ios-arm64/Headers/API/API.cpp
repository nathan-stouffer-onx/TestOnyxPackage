#include "API.h"
#include "API_Internal.h"

#include <WKT/WKTParser.h>

#include "Camera/Controllers/Animators/FlyTo.h"
#include "Camera/Controllers/Animators/FlyTo2D.h"
#include "Camera/Controllers/Animators/OrbitOn.h"
#include "Camera/Controllers/Animators/Rotate.h"
#include "Camera/Controllers/Animators/ZoomOn.h"
#include "../CameraSystem/FlybyGenerator.h"

namespace onyx::api
{
	namespace internal
	{
		MapViewer mapViewer;

		//Experimental stuff (note, we may want a better way to handle this?)
		std::shared_ptr<onyx::Experimental::FlybyGenerator> flyby;
	}

	using namespace internal;

	void setMaxConcurrentTileRequests(int maximum)
	{
		mapViewer.setMaxConcurrentTileRequests(static_cast<size_t>(maximum));
	}

	Vector2Int getScreenSize()
	{
		return mapViewer.getScreenSize().as<int>();
	}

	void setScreenSize(const Vector2Int size)
	{
		mapViewer.resize(size.x, size.y);
	}

	Vector2Int getViewportSize(const int viewportId)
	{
		return mapViewer.getViewportSize(viewportId).as<int>();
	}

	double getTileLoadTime(const int viewportId)
	{
		return mapViewer.tileLoadTimeMS(viewportId);
	}

	DynamicArray<TileId> getRecentTiles(const double previousTime)
	{
		return mapViewer.recentTiles(previousTime);
	}

	double getLastFrameTime()
	{
		return mapViewer.lastFrameTimeMS();
	}

	double getAvgFrameTime()
	{
		return mapViewer.avgFrameTimeMS();
	}

	void addEventCallback(const EventType type, VoidFunction callbackFn)
	{
		addCallback(type, callbackFn);
	}

	Vector2Int worldLonLatToViewport(const int viewportId, const LonLat worldPosition)
	{
		const auto normalizedScreen = mapViewer.project(viewportId, worldPosition.toVec2());
		const auto size = mapViewer.getViewportSize(viewportId).as<int>();
		return { static_cast<int>(normalizedScreen.x) * size.x, static_cast<int>(normalizedScreen.y) * size.y };
	}

	Vector2Int worldLonLatElevationToViewport(const int viewportId, const LonLatElevation worldPosition)
	{
		const auto normalizedScreen = mapViewer.project(viewportId, worldPosition.toWorldPosition());
		const auto size = mapViewer.getViewportSize(viewportId).as<int>();
		return { static_cast<int>(normalizedScreen.x) * size.x, static_cast<int>(normalizedScreen.y) * size.y };
	}

	LonLatElevation viewportToWorldLonLatElevation(const int viewportId, const Vector2Int screenPosition)
	{
		lgal::world::Vector3 point = mapViewer.unproject(viewportId, screenPosition.x, screenPosition.y);
		return LonLatElevation(MapMath::LonLatElevation(point));
	}

	float getElevationAt(const LonLat worldPosition)
	{
		return mapViewer.elevationAt(worldPosition.toVec2());
	}

	CameraState getCameraState(const int viewportId)
	{
		return CameraState(mapViewer.getCameraState(viewportId));
	}

	void setCameraState(const int viewportId, const CameraState cameraState)
	{
		mapViewer.setCameraState(viewportId, cameraState.toInternal());
	}

	void setLookState(const int viewportId, const LookState lookState)
	{
		mapViewer.setCameraState(viewportId, lookState.toCameraState());
	}

	void setLookState2D(const int viewportId, const LookState2D lookState)
	{
		flyToLookState2D(viewportId, lookState, 0.f);
	}

	void flyToCameraState(const int viewportId, const CameraState destination, const float duration)
	{
		const auto source = mapViewer.getCameraState(viewportId);
		std::shared_ptr<Camera::CameraController> controller = std::make_shared<Camera::Controllers::FlyTo>(source, destination.toInternal(), duration);
		mapViewer.setController(viewportId, controller);
	}

	void flyToLookState(const int viewportId, const LookState destination, const float duration)
	{
		flyToCameraState(viewportId, CameraState(destination.toCameraState()), duration);
	}

	void flyToLookState2D(const int viewportId, const LookState2D destination, const float duration)
	{
		const auto source = mapViewer.getCameraState(viewportId);
		lgal::world::Vector2 focus = destination.focus.toWorldPos();
		world_float_t heading = lmath::degreesToRadians(destination.heading);
		world_float_t pitch = lmath::degreesToRadians(destination.pitch);
		world_float_t radius = destination.radius * MapMath::metersToKilometers * MapMath::mercatorDistortion(destination.focus);
		MapMath::Spherical spherical = { heading, pitch, radius };
		auto controller = std::make_shared<Camera::Controllers::FlyTo2D>(source, focus, spherical, duration);
		mapViewer.setController(viewportId, controller);
	}

	void flybyGeoJson(const int viewportId, const String geojson, const float duration, const float radiusGuide, const float pitchGuide)
	{
		auto vp = mapViewer.getViewport(viewportId);
		auto points = Experimental::FlybyGenerator::ParseFromGeoJson(geojson);
		Experimental::FlybyGenerator::PathConfig config;
		config.durationMS = duration;
		config.radiusGuide = radiusGuide * 0.001;
		config.pitchGuide = lmath::degreesToRadians(pitchGuide);
		flyby.reset(new Experimental::FlybyGenerator(points, config, vp->getHeightAtlas(), vp->getCameraState(), vp->getStyle()));
		auto cam = flyby->getFlyby();
		mapViewer.setController(viewportId, cam);
	}

	void zoom(const int viewportId, const LonLatElevation focusPoint, const float scalar, const float duration)
	{
		auto source = mapViewer.getCameraState(viewportId);
		auto controller = std::make_shared<Camera::Controllers::ZoomOn>( source, focusPoint.toWorldPosition(), scalar, duration);
		mapViewer.setController(viewportId, controller);
	}

	void orbit(const int viewportId, const LonLatElevation focusPoint, const float deltaHeading, const float deltaPitch, const float radiusMultiplier, const float duration)
	{
		auto source = mapViewer.getCameraState(viewportId);
		auto controller = std::make_shared<Camera::Controllers::OrbitOn>(source, focusPoint.toWorldPosition(), lmath::degreesToRadians(deltaHeading), lmath::degreesToRadians(deltaPitch), radiusMultiplier, duration);
		mapViewer.setController(viewportId, controller);
	}

	void rotate(const int viewportId, const LonLatElevation focusPoint, const float deltaHeading, const float deltaPitch, const float duration)
	{
		auto source = mapViewer.getCameraState(viewportId);
		auto controller = std::make_shared<Camera::Controllers::Rotate>(source, focusPoint.toWorldPosition(), lmath::degreesToRadians(deltaHeading), lmath::degreesToRadians(deltaPitch), duration);
		mapViewer.setController(viewportId, controller);
	}

	void setStyle(int viewportId, String style)
	{
		mapViewer.setStyle(viewportId, style);
	}

	void addSource(int viewportId, String id, String source)
	{
		mapViewer.addSource(viewportId, id, source);
	}

	void removeSource(int viewportId, String id)
	{
		mapViewer.removeSource(viewportId, id);
	}

	void addLayer(int viewportId, String layer)
	{
		mapViewer.addLayer(viewportId, layer);
	}

	void addLayerBefore(int viewportId, String layer, String beforeId)
	{
		mapViewer.addLayer(viewportId, layer, beforeId);
	}

	void removeLayer(int viewportId, String id)
	{
		mapViewer.removeLayer(viewportId, id);
	}

	void toggleLayer(int viewportId, String id, String visibility)
	{
		mapViewer.toggleLayer(viewportId, id, visibility);
	}

	void toggleLayerGroup(int viewportId, String group, String visibility)
	{
		mapViewer.toggleLayerGroup(viewportId, group, visibility);
	}

	void setPostProcessParams(const float sharpen)
	{
		mapViewer.getViewportManager().setPostProcessParams(sharpen);
	}

	void toggleDebugUI(bool visible)
	{
		mapViewer.setShowDebugUI(visible);
	}

	void addWaypoint(const String uuid, const LonLat position, const Color color)
	{
		mapViewer.addWaypoint(uuid, { position.toWorldPos(), 0.0 }, color);
	}

	void setWaypointPosition(const String uuid, const LonLat position)
	{
		mapViewer.moveWaypointTo(uuid, { position.toWorldPos(), 0.0 });
	}

	void deleteWaypoint(const String uuid)
	{
		mapViewer.deleteWaypoint(uuid);
	}

	/// TODO (scott)
	// expose Polyline via API
	void addLabel(int viewportId, const String key, const String text, DynamicArray<Vector2Int> points, onyx::Styling::SymbolPlacement placement)
	{
		if (points.empty())
		{
			return;
		}

		auto vp = mapViewer.getViewport(viewportId);

		if (vp == nullptr)
		{
			return;
		}

		logD("Add Label - key: %s\t\ttext: %s\t\tpoints: %d", key.c_str(), text.c_str(), int(points.size()));

		Styling::FontFace font;
		font.name = "montefore";

		font.fontType = FONT_TYPE_DISTANCE_OUTLINE;
		font.pixelSize = 50;

		//TODO - control styling by platform side
		Styling::TextStyle style;
		style.font = font;
		style.color = lgal::Color::FromRGBA(0xFFFFFFFF);
		style.haloColor = lgal::Color::FromRGBA(0x000000FF);
		style.backgroundColor = lgal::Color::FromRGBA(0x0);
		style.anchor = Styling::Anchor::CENTER;
		style.flags = Styling::TextStyleFlags::NORMAL;

		auto fontPtr = Style::TextStyleManager::find(style);
		lgal::tile::Polyline linestring;
		for (auto const& pt : points)
		{
			linestring.add({ globe_float_t(pt.x), globe_float_t(pt.y) });
		}

		auto caps = bgfx::getCaps();

		auto sharedGeom = std::make_shared<Vector::LinestringFeature>(0, linestring);
		auto ptr = new DataObjects::MapLabel(Styling::Formatted(text), { points.front().as<world_float_t>(), caps->homogeneousDepth ? -1. : 0 }, fontPtr, { 0, 0, 0 }, sharedGeom, false, Utils::SpaceTypes::ScreenPx);
		std::shared_ptr<DataObjects::MapLabel> lbl(ptr);
		if (points.size() > 1)
		{
			auto const &p1 = points[1];
			auto const &p2 = points.front();
			auto dir = (p1 - p2).as<gpu_float_t>();
			lbl->setTextDirection(lmath::normalize(dir));
		}
		lbl->setForce(true);
		lbl->setAlpha(255);

		vp->getState()->mSymbolCollection.append(key, std::make_shared<DataObjects::MapSymbol>(lbl, placement));
		vp->invalidate();
	}

	void clearLabels(int viewportId, const String key)
	{
		auto vp = mapViewer.getViewport(viewportId);

		if (vp == nullptr)
		{
			return;
		}

		vp->getState()->mSymbolCollection.erase(key);
		vp->invalidate();
	}

	void setScreenLogo(int viewportId, int logoId, int screenPosX, int screenPosY)
	{
		mapViewer.setScreenLogo(viewportId, logoId, lgal::screen::Vector2(screenPosX, screenPosY));
	}
}
