#pragma once

#include <lucid/gal/Types.h>

#include <Utils/MapMath.h>
#include <Camera/CameraState.h>

#include "LonLatElevation.h"

namespace onyx::api
{

	/*
	* A helper struct so that the client can easily set a CameraState via a LookState. This could be helpful for 
	* highlighting a specific point on the map or when transferring from Mapbox to Core (Mapbox's camera info
	* is based on a look point).
	*/

	struct LookState
	{
		LonLatElevation focus;

		world_float_t heading;	// units in degrees
		world_float_t pitch;	// units in degrees

		world_float_t radius;	// units in meters

		LookState() :
			focus(LonLatElevation{ 0.0, 0.0, 0.0 }),
			heading(lmath::radiansToDegrees(Camera::DefaultHeading)),
			pitch(lmath::radiansToDegrees(Camera::DefaultPitch)),
			radius(10 * MapMath::kilometersToMeters)
		{
		}

		LookState(LonLatElevation const& focus, world_float_t heading, world_float_t pitch, world_float_t radius) :
			focus(focus),
			heading(heading),
			pitch(pitch),
			radius(radius)
		{
		}

		[[nodiscard]] Camera::CameraState toCameraState() const
		{
			return
			{
				focus.toWorldPosition(),
				lmath::degreesToRadians(heading),
				lmath::degreesToRadians(pitch),
				radius * MapMath::metersToKilometers * MapMath::mercatorDistortion(focus.lat)
			};
		}
	};

	struct LookState2D
	{
		MapMath::LonLat focus;

		world_float_t heading;	// units in degrees
		world_float_t pitch;	// units in degrees

		world_float_t radius;	// units in meters

		LookState2D() :
			focus(MapMath::LonLat{ 0.0, 0.0 }),
			heading(lmath::radiansToDegrees(Camera::DefaultHeading)),
			pitch(lmath::radiansToDegrees(Camera::DefaultPitch)),
			radius(10 * MapMath::kilometersToMeters)
		{
		}

		LookState2D(MapMath::LonLat const& focus, world_float_t heading, world_float_t pitch, world_float_t radius) :
			focus(focus),
			heading(heading),
			pitch(pitch),
			radius(radius)
		{
		}

	};

	struct ZoomState
	{

		MapMath::LonLat focus;

		world_float_t heading;	// units in degrees
		world_float_t pitch;	// units in degrees

		world_float_t zoom;

		ZoomState() :
			focus(MapMath::LonLat{ 0.0, 0.0 }),
			heading(lmath::radiansToDegrees(Camera::DefaultHeading)),
			pitch(lmath::radiansToDegrees(Camera::DefaultPitch)),
			zoom(10)
		{
		}

		ZoomState(MapMath::LonLat const& focus, world_float_t heading, world_float_t pitch, world_float_t _zoom) :
			focus(focus),
			heading(heading),
			pitch(pitch),
			zoom(_zoom)
		{
		}

		[[nodiscard]] LookState2D toLookState2D() const
		{
			return
			{
				focus,
				heading,
				pitch,
				MapMath::zoomToKm(zoom) * MapMath::kilometersToMeters
			};
		}

	};

	struct BoundsState
	{
		MapMath::LonLat min;
		MapMath::LonLat max;

		world_float_t heading;	// units in degrees
		world_float_t pitch;	// units in degrees

		BoundsState() :
			min(MapMath::LonLat{ 0.0, 0.0 }),
			max(MapMath::LonLat{ 0.0, 0.0 }),
			heading(lmath::radiansToDegrees(Camera::DefaultHeading)),
			pitch(lmath::radiansToDegrees(Camera::DefaultPitch))
		{
		}

		BoundsState(MapMath::LonLat const& min, MapMath::LonLat const& max, world_float_t heading, world_float_t pitch) :
			min(min),
			max(max),
			heading(heading),
			pitch(pitch)
		{
		}

		[[nodiscard]] LookState2D toLookState2D() const
		{
			lgal::world::AABB2d box = { min.toWorldPos(), max.toWorldPos() };
			return
			{
				box.center(),
				heading,
				pitch,
				2.0 * box.extent().length() * MapMath::kilometersToMeters
			};
		}
	};

}