#pragma once

#include "../math/Range.h"

#include <limits>
#include <vector>

namespace lucid {
namespace spatial {

	template<class T, class V>
	class IntervalTree
	{
	public:

		using IntervalT = typename math::Range<T>;

		struct Entry
		{
			IntervalT interval;
			V value;

			Entry(IntervalT const& _interval, V const& _value) : interval(_interval), value(_value) {}

			inline bool operator==(Entry const& rhs) const
			{
				return interval == rhs.interval && value == rhs.value;
			}
		};

	private:

		using IndexT = size_t;

		static constexpr size_t cInvalid = std::numeric_limits<IndexT>::max();

		struct Center
		{

			T pivot;

			Entry const* data = nullptr;

			// these two lists are the same set of intervals (all containing the pivot), just sorted differently
			std::vector<IndexT> lesser;			// sorted by start point (ascending)
			std::vector<IndexT> greater;		// sorted by end point (descending)

			Center(T const _pivot, Entry const* _data) : pivot(_pivot), data(_data) {}

			inline bool isEmpty() const { return lesser.empty(); }

			void insert(IndexT const i)
			{
				lesser.push_back(i);
				greater.push_back(i);
			}

			void sort()
			{
				std::sort(lesser.begin(), lesser.end(), [=](IndexT const& lhs, IndexT const& rhs) { return (data + lhs)->interval.begin < (data + rhs)->interval.begin; });
				std::sort(greater.begin(), greater.end(), [=](IndexT const& lhs, IndexT const& rhs) { return (data + lhs)->interval.end > (data + rhs)->interval.end; });
			}

		};

		struct Node
		{
			Center center;

			size_t left  = cInvalid;
			size_t right = cInvalid;

			Node(Center&& _center) : center(std::move(_center)) {}
		};

		struct QueryIterator
		{

			struct Position
			{
				using iterator = typename std::vector<IndexT>::const_iterator;

				size_t idx;		// index into the Node array
				iterator it;	// iterator within the node's intervals

				Position(size_t _idx, iterator _it) : idx(_idx), it(_it) {}

				bool contains(std::vector<Node> const& nodes, T const query) const
				{
					if (idx < nodes.size())
					{
						Node const& node = nodes[idx];
						Center const& center = node.center;
						if (!center.isEmpty())
						{
							return ((center.data + *it)->interval.contains(query));
						}
					}
					return false;	// fall-through to false
				}

				// moves the iterator to the next possible interval -- (jumps to next node if necessary)
				void advance(std::vector<Node> const& nodes, T const query)
				{
					if (idx < nodes.size())
					{
						Node const& node = nodes[idx];
						Center const& center = node.center;
						// check if we need to update the node
						if (query <= center.pivot)
						{
							// if any of the following are true, we jump to the next node
							//   1. this iterator is the end (edge case -- this should only occur if the constructor points to a node that contains no intervals)
							//   2. the iterator points to a range that does not contain the query
							//   3. the incremented iterator is the end
							if (it == center.lesser.end() || query < (center.data + *it)->interval.begin || ++it == center.lesser.end())
							{
								jump(nodes, query);
							}
						}
						else
						{
							// if any of the following are true, we jump to the next node
							//   1. this iterator is the end (edge case -- this should only occur if the constructor points to a node that contains no intervals)
							//   2. the iterator points to a range that does not contain the query
							//   3. the incremented iterator is the end
							if (it == center.greater.end() || query > (center.data + *it)->interval.end || ++it == center.greater.end())
							{
								jump(nodes, query);
							}
						}
					}
				}

				inline bool operator==(Position const& rhs) const
				{
					if (idx == rhs.idx)	// check if the indices are equal
					{
						return (idx == cInvalid) ? true : it == rhs.it;	// if the index is invalid, return true. otherwise compare the iterators
					}
					else
					{
						return false;
					}
				}

			private:

				// assign the iterator (may call jump if there is no iterator to assign at the current node)
				void assign(std::vector<Node> const& nodes, T const query)
				{
					if (idx < nodes.size())
					{
						Node const& node = nodes[idx];
						Center const& center = node.center;
						if (center.isEmpty())
						{
							jump(nodes, query);
						}
						else
						{
							std::vector<IndexT> const& sorted = (query <= center.pivot) ? center.lesser : center.greater;
							it = sorted.begin();
						}
					}
				}

				// jump to the next relevant node, then assign the iterator
				void jump(std::vector<Node> const& nodes, T const query)
				{
					if (idx < nodes.size())
					{
						Node const& node = nodes[idx];
						if (query == node.center.pivot)
						{
							idx = cInvalid;
						}
						else if (query < node.center.pivot)
						{
							idx = node.left;
							assign(nodes, query);
						}
						else
						{
							idx = node.right;
							assign(nodes, query);
						}
					}
				}

			};

			/*
			* iterate forward until one of the following conditions is true
			*     1. we are at the end
			*     2. the iterator points to an interval that contains the query point
			*/
			void slide()
			{
				while (mPos.idx != cInvalid && !mPos.contains(mNodes, mQuery))
				{
					mPos.advance(mNodes, mQuery);
				}
			}

			QueryIterator(Position const& pos, T const query, std::vector<Node> const& nodes) : mPos(pos), mQuery(query), mNodes(nodes)
			{
				slide();
			}

			inline bool operator==(QueryIterator const& rhs) const { return mPos == rhs.mPos; }
			inline bool operator!=(QueryIterator const& rhs) const { return !(*this == rhs); }

			inline Entry const& operator*() const { return *(mNodes[mPos.idx].center.data + *mPos.it); }

			inline QueryIterator& operator++()
			{
				mPos.advance(mNodes, mQuery);	// go ahead and advance immediately
				slide();						// slide forward until we hit the end or an interval that contains the query
				return *this;					// return the iterator we landed at
			}

			inline QueryIterator operator++(int)
			{
				QueryIterator ret = *this;
				++(*this);
				return ret;
			}

		private:

			Position mPos;
			T mQuery;
			std::vector<Node> const& mNodes;

		};

	public:

		struct QueryIteratorRange
		{

			QueryIteratorRange(QueryIterator begin, QueryIterator end) : mBegin(begin), mEnd(end) {}

			QueryIterator begin() const { return mBegin; }
			QueryIterator end() const { return mEnd; }

		private:

			QueryIterator mBegin;
			QueryIterator mEnd;
		};

	public:

		IntervalTree(std::vector<Entry>&& entries) : mEntries(std::move(entries)), mNodes(Construct({ mEntries.data(), Indices(mEntries), Sorted(mEntries) })) {}

		IntervalTree(IntervalTree const& rhs) : mEntries(rhs.mEntries), mNodes(rhs.mNodes)
		{
			for (Node& node : mNodes)
			{
				node.center.data = mEntries.data();
			}
		}
		
		IntervalTree& operator=(IntervalTree const& rhs)
		{
			mEntries = rhs.mEntries;
			mNodes = rhs.mNodes;
			for (Node& node : mNodes)
			{
				node.center.data = mEntries.data();
			}
		}

		QueryIteratorRange find(T const query) const
		{
			QueryIterator end({ cInvalid, mInvalidFlag.cend() }, query, mNodes);
			if (mEntries.empty())
			{
				return { end, end };
			}
			else
			{
				Center const& center = mNodes.front().center;
				QueryIterator begin({ 0, query <= center.pivot ? center.lesser.cbegin() : center.greater.cbegin() }, query, mNodes);
				return { begin, end };
			}
		}

	private:

		struct Sortable
		{
			T x;
			Entry const* entry;
		};

		struct CtorArgs
		{
			Entry const* data;
			std::vector<IndexT> intervals;
			std::vector<Sortable> sorted;

			CtorArgs(Entry const* _data) : data(_data) {}
			CtorArgs(Entry const* _data, std::vector<IndexT>&& _intervals, std::vector<Sortable>&& _sorted) : data(_data), intervals(std::move(_intervals)), sorted(std::move(_sorted)) {}
		};

		static size_t Construct(CtorArgs const& args, std::vector<Node>& nodes)
		{
			// base case where there are no intervals
			if (args.intervals.empty()) { return cInvalid; }

			size_t mid = args.sorted.size() / 2;
			T median =  T(0.5) * (args.sorted[mid].x + args.sorted[mid - 1].x);	// there will always be an even number of elements (2 * number of intervals)

			Center center{ median, args.data };
			CtorArgs left{ args.data };
			CtorArgs right{ args.data };

			// iterate over all intervals, adding to the appropriate node
			for (IndexT i : args.intervals)
			{
				if (center.pivot > (center.data + i)->interval.end)			// if the interval is entirely to the left of the pivot, add to the left child
				{
					left.intervals.push_back(i);
				}
				else if (center.pivot < (center.data + i)->interval.begin)	// if the interval is entirely to the right of the pivot, add to the right child
				{
					right.intervals.push_back(i);
				}
				else														// the point must be contained in the interval, add to the center
				{
					center.insert(i);
				}
			}

			// iterate over sorted points, adding to the appropriate node
			for (auto sortable : args.sorted)
			{
				if (center.pivot > sortable.entry->interval.end)			// if the interval is entirely to the left of the pivot, add to the left child
				{
					left.sorted.push_back(sortable);
				}
				else if (center.pivot < sortable.entry->interval.begin)		// if the interval is entirely to the right of the pivot, add to the right child
				{
					right.sorted.push_back(sortable);
				}
			}

			center.sort();

			// push this node onto the array
			size_t idx = nodes.size();
			nodes.push_back(std::move(center));

			// update pointers to children
			nodes[idx].left  = Construct(left,  nodes);
			nodes[idx].right = Construct(right, nodes);

			// return our own index
			return idx;
		}

		static std::vector<Node> Construct(CtorArgs const& args)
		{
			std::vector<Node> nodes;
			Construct(args, nodes);
			return nodes;
		}

		// TODO maybe use an STL algorithm for this?
		static std::vector<IndexT> Indices(std::vector<Entry> const& entries)
		{
			std::vector<IndexT> indices;
			indices.reserve(entries.size());
			for (size_t i = 0; i < entries.size(); ++i)
			{
				indices.push_back(i);
			}
			return indices;
		}

		// TODO maybe use an STL algorithm for this?
		static std::vector<Sortable> Sorted(std::vector<Entry> const& entries)
		{
			std::vector<Sortable> sortable;
			sortable.reserve(2 * entries.size());
			for (Entry const& entry : entries)
			{
				sortable.push_back({ entry.interval.begin, &entry });
				sortable.push_back({ entry.interval.end,   &entry });
			}
			std::sort(sortable.begin(), sortable.end(), [](Sortable const& lhs, Sortable const& rhs) { return lhs.x < rhs.x; });
			return sortable;
		}

	private:

		std::vector<Entry> mEntries;
		std::vector<Node> mNodes;

		std::vector<IndexT> mInvalidFlag;	// used to signify the end iterator

	};

}
}