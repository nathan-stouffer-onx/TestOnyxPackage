#include "Context.h"
///
///
///
namespace lucid {
namespace gigl {

	/*
	Not implemented for bgfx 
	
	Context::Context(std::string const &path)
	{
		::lucid::core::FileReader rdr(path);
		initialize(rdr);
	}

	Context::Context(::lucid::core::Reader &reader)
	{
		initialize(reader);
	}

	void Context::initialize(::lucid::core::Reader &reader)
	{
		_values.clear();

		int32_t count = reader.read<int32_t>();
		for (int32_t i = 0; i < count; ++i)
		{
			std::string name = reader.read<std::string>();
			add(name, Primitive(reader));
		}
	}

	void Context::Serialize(::lucid::core::Writer &writer)
		{
		auto count = _values.size();
		writer.write(count);
		for (auto iter : _values)
			{
			auto prim = iter.second;
			writer.write(iter.first);
			prim.Serialize(writer);
			}
		}
	*/
}	///	gigl
}	///	lucid
