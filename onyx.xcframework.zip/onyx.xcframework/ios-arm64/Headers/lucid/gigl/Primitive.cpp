#include "Primitive.h"

namespace prim = ::lucid::gigl::primitives;

///
///
///
namespace /* anonymous */
{

/*	typedef ::lucid::core::Reader reader_t;
	typedef ::lucid::core::Writer writer_t;

	typedef ::lucid::gal::Unordered2D unordered2d_t;
	typedef std::shared_ptr<unordered2d_t> shared_unordered2d_t;

	typedef ::lucid::gal::Texture2D texture2d_t;
	typedef std::shared_ptr<texture2d_t> shared_texture2d_t;
	
	typedef ::lucid::gal::RenderTarget2D target2d_t;
	typedef std::shared_ptr<target2d_t> shared_target2d_t;
	
	typedef ::lucid::gal::DepthTarget2D depth2d_t;
	typedef std::shared_ptr<depth2d_t> shared_depth2d_t;

	typedef ::lucid::gal::Sampler sampler_t;
	typedef std::shared_ptr<sampler_t> shared_sampler_t;
*/

/*	/// ENUM LOOKUP
	::lucid::gal::PixelFormat const targetFormat[] =
	{
		::lucid::gal::FORMAT_UNORM_R8G8B8A8,
		::lucid::gal::FORMAT_UINT_R16G16,
		::lucid::gal::FORMAT_UINT_R10G10B10A2,
		::lucid::gal::FORMAT_FLOAT_R16G16,
		::lucid::gal::FORMAT_FLOAT_R32,
		::lucid::gal::FORMAT_FLOAT_R32G32,
		::lucid::gal::FORMAT_UINT_R32,
		::lucid::gal::FORMAT_UNORM_A8,
		::lucid::gal::FORMAT_UNORM_B8G8R8A8
	};

	/// ENUM LOOKUP
	::lucid::gal::DepthTarget2D::FORMAT const depthFormat[] =
	{
		depth2d_t::FORMAT_UINT_D16,
		depth2d_t::FORMAT_UINT_D24S8,
		depth2d_t::FORMAT_FLOAT_D32,
	};

	typedef void (*write_func_t)(writer_t &writer, primitive_t const *value);
	typedef primitive_t (*read_func_t)(reader_t &reader);
	extern write_func_t const write_jump[prim::TYPE_COUNT];
	extern read_func_t const read_jump[prim::TYPE_COUNT];
*/

}	///	anonymous

///
///
///
namespace lucid {
namespace gigl {

	PrimitiveInfo const prim::GiglTypes::infos[prim::GiglTypes::TYPE_COUNT] =
	{
		{ prim::GiglTypes::Type<        prim::    UNKNOWN>::VALUE,      "<unknown>" },
		{ prim::GiglTypes::Type<        prim::  UNDEFINED>::VALUE,    "<undefined>" },
		{ prim::GiglTypes::Type<                     bool>::VALUE,           "bool" },
		{ prim::GiglTypes::Type<                  int32_t>::VALUE,            "int" },
		{ prim::GiglTypes::Type<                float32_t>::VALUE,          "float" },
		{ prim::GiglTypes::Type<                float64_t>::VALUE,        "float64" },
		{ prim::GiglTypes::Type<	lgal::			Color>::VALUE,          "Color" },
		{ prim::GiglTypes::Type<	lgal::gpu::	  Vector2>::VALUE,	   "Vector2 GPU" },
		{ prim::GiglTypes::Type<	lgal::gpu::   Vector3>::VALUE,	   "Vector3 GPU" },
		{ prim::GiglTypes::Type<	lgal::gpu::   Vector4>::VALUE,	   "Vector4 GPU" },
		{ prim::GiglTypes::Type<	lgal::gpu::Quaternion>::VALUE,     "Quaternion" },
		{ prim::GiglTypes::Type<	lgal::gpu:: Matrix2x2>::VALUE,      "Matrix2x2" },
		{ prim::GiglTypes::Type<	lgal::gpu:: Matrix3x3>::VALUE,      "Matrix3x3" },
		{ prim::GiglTypes::Type<	lgal::gpu:: Matrix4x4>::VALUE,      "Matrix4x4" },
		{ prim::GiglTypes::Type<	lgal::gpu::		Range>::VALUE,	 "float32 Range" },
		{ prim::GiglTypes::Type<prim::  shared_gradient_t>::VALUE,		  "Gradient" },
		{ prim::GiglTypes::Type<prim::shared_range_list_t>::VALUE,		"Range List" },
		{ prim::GiglTypes::Type<	lgal::world:: Vector2>::VALUE,		   "Vector2" },
		{ prim::GiglTypes::Type<	lgal::world:: Vector3>::VALUE,		   "Vector3" },
		{ prim::GiglTypes::Type<	lgal::world:: Vector4>::VALUE,		   "Vector4" },

		//{ prim::Type<      shared_texture2d_t>::VALUE,      "Texture2D" },
		//{ prim::Type<       shared_target2d_t>::VALUE, "RenderTarget2D" },
		//{ prim::Type<         std::    string>::VALUE,         "string" },

		//{ prim::Type<    shared_unordered2d_t>::VALUE,    "Unordered2D" },
		//{ prim::Type<        shared_depth2d_t>::VALUE,  "DepthTarget2D" },
		//{ prim::Type<		 shared_sampler_t>::VALUE,		  "Sampler" }
	};

	/*
	void Primitive::readFrom(::lucid::core::Reader &reader)
	{
		int32_t tid = reader.read<int32_t>();
		LUCID_VALIDATE(tid < prim::TYPE_COUNT, "invalid primitive type id");

		///	TBD: this creates an intermediate primitive instance from which to coerce.
		///	use Primitive::Any directly to emliminate this if it becomes an issue (which i doubt).
		coerceFrom(read_jump[tid](reader));
	}

	void Primitive::Serialize(::lucid::core::Writer &writer)
		{
		writer.write(_tid);
		write_jump[_tid](writer, this);
		}
		*/
}	///	gigl
}	///	lucid