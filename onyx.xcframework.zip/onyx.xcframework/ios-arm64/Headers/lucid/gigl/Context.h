#pragma once

#include <string>
#include <unordered_map>
#include <System/Map3DException.h>
#include "Primitive.h"
#include <list>

///
///
///
namespace lucid {
namespace gigl {

	///	Context
	///
	///
	template <typename PrimType>
	class FlexContext final
	{
	public:
		using Primitive = lucid::gigl::Primitive<PrimType>;

		FlexContext() = default;

		~FlexContext() = default;

		//FlexContext(std::string const &path);

		//FlexContext(::lucid::core::Reader &reader);

		Primitive &operator[](std::string const &name)
		{
			return lookup(name);
		}

		Primitive const &operator[](std::string const &name) const
		{
			return lookup(name);
		}

		Primitive &lookup(std::string const &name)
		{
			auto iter = _values.find(name);
			MAP3D_ASSERT(iter != _values.end(), "unknown parameter, " + name + ", requested");

			return _values[name];
		}

		Primitive const &lookup(std::string const &name) const
		{
			auto iter = _values.find(name);
			MAP3D_ASSERT(iter != _values.end(), "unknown parameter, " + name + ", requested");

			return iter->second;
		}

		template<typename T>
		inline void getTo(std::string const& name, T& target) const
		{
			target = lookup(name).template as<T>();
		}

//		void Serialize(::lucid::core::Writer &writer);

		bool exists(std::string const& name) const
		{
			return _values.find(name) != _values.end();
		}

		void add(std::string const &name, Primitive const &parameter)
		{
			MAP3D_ASSERT(_values.end() == _values.find(name), "duplicate parameter, " + name + ", specified");

			_values[name] = parameter;
		}

		void set(std::string const& name, Primitive const& parameter)
		{
			_values[name] = parameter;
		}

		void remove(std::string const &name)
		{
			_values.erase(name);
		}

		void getKeys(std::list<std::string> &result) const
		{
			for (auto iter = _values.begin(); iter != _values.end(); ++iter)
				result.push_back(iter->first);
		}

		void clear()
		{
			_values.clear();
		}

	private:
		std::unordered_map<std::string, Primitive> _values;

//		void initialize(::lucid::core::Reader &reader);

	};

	using Context = FlexContext<primitives::GiglTypes>;

}	///	gigl
}	///	lucid
