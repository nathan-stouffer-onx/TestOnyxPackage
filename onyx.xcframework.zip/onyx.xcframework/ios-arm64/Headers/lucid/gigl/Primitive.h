#pragma once

#include <memory>
#include <string>
#include <lucid/Noncopyable.h>
#include <lucid/Types.h>
#include <lucid/gal/Types.h>
#include <System/Map3DException.h>
#include "Utils/Gradient.h"

/*
	This is all stuff that is possible with the full lucid library.
	
	We could adapt bgfx equivalents if we wanted to.
///
///
///
namespace lucid {
namespace gal {

	class Unordered2D;
	class Texture2D;
	class RenderTarget2D;
	class DepthTarget2D;
	class Sampler;
}	///	gal
}	///	lucid

///
///
///
*/

namespace lucid {
namespace gigl {

	struct PrimitiveInfo
	{
		int32_t const tid;
		char const* const name;
	};

	namespace primitives {
/*		Not implemented for bgfx

		typedef std::shared_ptr<::lucid::gal::Unordered2D> shared_unordered2d_t;
		typedef std::shared_ptr<::lucid::gal::Texture2D>   shared_texture2d_t;
		typedef std::shared_ptr<::lucid::gal::RenderTarget2D>    shared_target2d_t;
		typedef std::shared_ptr<::lucid::gal::DepthTarget2D>    shared_depth2d_t;
		typedef std::shared_ptr<::lucid::gal::Sampler> shared_sampler_t;
		*/
		typedef std::shared_ptr<onyx::Utils::Gradient> shared_gradient_t;
		typedef std::shared_ptr<std::vector<lgal::gpu::Range>> shared_range_list_t;

		struct UNKNOWN final {};
		struct UNDEFINED final {};

		struct GiglTypes
		{
			enum { TYPE_COUNT = 20 };

			static PrimitiveInfo const infos[TYPE_COUNT];

			// Deleting this constructor forces a compile error if someone tries to use a context
			// to store/retrieve something that is unsupported.
			template<class T> struct Type { Type() = delete; enum { VALUE = 0 }; };
			template<>        struct Type<	UNKNOWN					> { enum { VALUE = 0 }; };
			template<>        struct Type<	UNDEFINED				> { enum { VALUE = 1 }; };
			template<>        struct Type<	bool					> { enum { VALUE = 2 }; };
			template<>        struct Type<	int32_t					> { enum { VALUE = 3 }; };
			template<>        struct Type<	float32_t				> { enum { VALUE = 4 }; };
			template<>        struct Type<	float64_t				> { enum { VALUE = 5 }; };
			template<>        struct Type<	lgal::Color				> { enum { VALUE = 6 }; };
			template<>        struct Type<	lgal::gpu::Vector2		> { enum { VALUE = 7 }; };
			template<>        struct Type<	lgal::gpu::Vector3		> { enum { VALUE = 8 }; };
			template<>        struct Type<	lgal::gpu::Vector4		> { enum { VALUE = 9 }; };
			template<>        struct Type<	lgal::gpu::Quaternion	> { enum { VALUE = 10 }; };
			template<>        struct Type<	lgal::gpu::Matrix2x2	> { enum { VALUE = 11 }; };
			template<>        struct Type<	lgal::gpu::Matrix3x3	> { enum { VALUE = 12 }; };
			template<>        struct Type<	lgal::gpu::Matrix4x4	> { enum { VALUE = 13 }; };
			template<>		  struct Type<	lgal::gpu::Range		> { enum { VALUE = 14 }; };
			template<>		  struct Type<	shared_gradient_t		> { enum { VALUE = 15 }; };
			template<>		  struct Type<	shared_range_list_t		> { enum { VALUE = 16 }; };
			template<>        struct Type<	lgal::world::Vector2	> { enum { VALUE = 17 }; };
			template<>        struct Type<	lgal::world::Vector3	> { enum { VALUE = 18 }; };
			template<>        struct Type<	lgal::world::Vector4	> { enum { VALUE = 19 }; };
		};

/*		template<>        struct Type<           shared_texture2d_t> { enum { VALUE = 13 }; };
		template<>        struct Type<            shared_target2d_t> { enum { VALUE = 14 }; };
		template<>        struct Type<                  std::string> { enum { VALUE = 15 }; };

		template<>        struct Type<         shared_unordered2d_t> { enum { VALUE = 16 }; };
		template<>        struct Type<             shared_depth2d_t> { enum { VALUE = 17 }; };
		template<>		  struct Type<		       shared_sampler_t> { enum { VALUE = 18 }; };
		*/
	}

	///	Primitive
	///
	///	basic "variant" data type used by material and context.
	template<typename PrimType>
	class Primitive final
	{
	public:


		Primitive() = default;

		virtual ~Primitive() = default;

		template<class T> Primitive(T const &rhs)
		{
			_tid = PrimType::template Type<T>::VALUE;
			MAP3D_ASSERT(_tid != PrimType::template Type<primitives::UNKNOWN>::VALUE, "Unknown primitive added");
			_any.reset(new Specific<T>(rhs));
		}

/*		Primitive(::lucid::core::Reader& reader)
		{
			readFrom(reader);
		}

		void Serialize(::lucid::core::Writer &writer);
		*/

		Primitive(Primitive const &rhs)
		{
			coerceFrom(rhs);
		}

		template<class T> Primitive &operator=(T const &rhs)
		{
			asSpecific<T>(_any)->value = rhs;
			return *this;
		}

		Primitive &operator=(Primitive const &rhs)
		{
			if (this != &rhs)
				coerceFrom(rhs);
			return *this;
		}

		template<class T> T const &as() const
		{
			return asSpecific<T>(_any)->value;
		}

		template<class T> T &as()
		{
			return asSpecific<T>(_any)->value;
		}

		template<class T>
		inline bool is() const
		{
			return PrimType::template Type<T>::VALUE == _tid;

		}

		inline PrimitiveInfo const& info() const
		{
			return PrimType::template infos[_tid];
		}
	private:
		///
		///
		///
		struct Any
		{
			Any() = default;

			virtual ~Any() = default;

			virtual Any *clone() const = 0;

			// Function for non-RTTI type-checking
			virtual int32_t tid() const = 0;

			LUCID_PREVENT_COPY(Any);
			LUCID_PREVENT_ASSIGNMENT(Any);
		};

		///
		///
		///
		template<class T> struct Specific : public Any
		{
			T value;

			Specific() = default;

			virtual ~Specific() = default;

			// IF YOU SEE A "initialization requires a brace-enclosed initializer list" error here,
			// it is probably because you are attempting to add an unsupported type to the context.
			// This compile error is a trade-off for having run-time exceptions when unsupported
			// types are used.
			Specific(T const &value)
				: value(value)
			{
			}

			virtual Any *clone() const override
			{
				return new Specific(value);
			}

			// Function for non-RTTI type-checking
			virtual int32_t tid() const override { return PrimType::template Type<T>::VALUE; }

			LUCID_PREVENT_COPY(Specific);
			LUCID_PREVENT_ASSIGNMENT(Specific);
		};

		int32_t _tid = PrimType::template Type<primitives::UNDEFINED>::VALUE;
		std::unique_ptr<Any> _any;

		void coerceFrom(Primitive const& rhs)
		{
			_tid = rhs._tid;
			rhs._any ? _any.reset(rhs._any->clone()) : _any.reset();
		}

//		void readFrom(::lucid::core::Reader &reader);

		template<class T> static Specific<T> *asSpecific(std::unique_ptr<Any> const &rhs)
		{
			typedef Specific<T> specific_t;

// non-RTTI casts
			auto const tid = PrimType::template Type<T>::VALUE;
			if (tid != rhs->tid())
			{
				std::string msg = std::string("parameter type mismatch: expected `") + PrimType::infos[tid].name + "` got `" + PrimType::infos[rhs->tid()].name + "'";
				MAP3D_THROW(msg);
			}

			specific_t* specific = (specific_t*)(rhs.get());

// if RTTI is enabled, this is a better option
//			specific_t *specific = dynamic_cast<specific_t*>(rhs.get());
//			MAP3D_ASSERT(nullptr != specific, "parameter type mismatch");

			return specific;
		}

	};

}	///	gigl
}	///	lucid