#include "lucidJsonParsing.h"

#include <json/jsonParsing.h>
#include <lucid/gal/Types.h>

#include <sstream>

namespace lucid {
namespace gal {
	// Color
	void from_json(const nlohmann::json& j, Color& rhs)
	{
		std::string hexCode;
		j.get_to(hexCode);
		auto c = uint32_t(std::stoul(hexCode, nullptr, 16));

		rhs = Color(c);
	}

	void to_json(nlohmann::json& j, const Color& req)
	{
		std::ostringstream os;
		os << std::hex << req.argb();
		auto s = os.str();

		std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (unsigned char)std::toupper(c); });

		j = s;
	}

} }