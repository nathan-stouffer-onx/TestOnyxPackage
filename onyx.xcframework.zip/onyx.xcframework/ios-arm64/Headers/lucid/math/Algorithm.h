#pragma once

#include <vector>
#include <array>
#include <algorithm>
#include "Constants.h"
#include "Vector.h"
#include "Quaternion.h"
#include "Matrix.h"
#include "Sphere.h"
#include "AABB.h"
#include "Frustum.h"
#include "LineSegment.h"
#include "Polygon.h"
#include "Holygon.h"

#ifdef min
#	undef min
#	undef max
#endif

namespace lucid {
namespace math {

template<class T>
inline T lerp(T a, T b, T t)
{
	return (t * b + (a - t * a));
}

// function to exponentially interpolate between two points
template<class T>
inline T exponerp(T base, Vector<T, 2> const& a, Vector<T, 2> const& b, T input)
{
	Vector<T, 2> delta = b - a;

	// compute constants for the function f(x) = A * std::pow(base, x - x_0) + C
	T A = delta.y / (std::pow(base, delta.x) - T(1));
	T C = a.y - A;
	return A * std::pow(base, input - a.x) + C;
}

template<class T>
inline T inverseLerp(T a, T b, T x)
{
	return (x - a) / (b - a);
}

template<class T>
T lerpstep(T a, T b, T t)
{
	if (t < 0.0)
	{
		return a;
	}
	else if (0.0 <= t && t <= 1.0)
	{
		return lerp(a, b, t);
	}
	else
	{
		return b;
	}
}

template<class T>
T smoothstep(T a, T b, T t)
{
	if (t < T(0.0))
	{
		return a;
	}
	else if (T(0.0) <= t && t <= T(1.0))
	{
		// transform t to begin and end smoothly
		T smoothT = t * t * (T(3.0) - T(2.0) * t);
		return lerp(a, b, smoothT);
	}
	else
	{
		return b;
	}
}

template<class T>
T slerp(T a, T b, T t, T min, T max)
{
	T range = max - min;
	T slerped = T(0.0);
	if (std::abs(a - b) < T(0.5) * range)
	{
		slerped = lerp(a, b, t);
	}
	else if (a < b)
	{
		slerped = lerp(a + range, b, t);
	}
	else
	{
		slerped = lerp(a, b + range, t);
	}

	if (slerped >= max)
	{
		slerped -= range;
	}

	return slerped;
}

template<class T>
inline T sigmoid(T x)
{
	return 1.0 / (1.0 + std::exp(-x));
}

// Returns a value in the range 0..range that follows an inverse cosine curve
template<class T>
inline T periodic(T min, T range, T radians)
{
	return min + ((1 - std::cos(radians)) * 0.5f * range);
}

inline uint32_t lerpHexColorABGR(uint32_t color1, uint32_t color2, float t)
{
	unsigned char   r1 = (color1 >> 0) & 0xff;
	unsigned char   r2 = (color2 >> 0) & 0xff;
	unsigned char   g1 = (color1 >> 8) & 0xff;
	unsigned char   g2 = (color2 >> 8) & 0xff;
	unsigned char   b1 = (color1 >> 16) & 0xff;
	unsigned char   b2 = (color2 >> 16) & 0xff;
	unsigned char   a1 = (color1 >> 24) & 0xff;
	unsigned char   a2 = (color2 >> 24) & 0xff;

	return (uint32_t)((a2 - a1) * t + a1) << 24 |
		(uint32_t)((b2 - b1) * t + b1) << 16 |
		(uint32_t)((g2 - g1) * t + g1) << 8 |
		(uint32_t)((r2 - r1) * t + r1);
}

template<class T, int DIM>
inline Vector<T, DIM> lerp(Vector<T, DIM> const& a, Vector<T, DIM> const& b, T const& t)
{
	Vector<T, DIM> result;
	for (int i = 0; i < DIM; ++i)
	{
		result[i] = lerp(a[i], b[i], t);
	}
	return result;
}

template<class T, int DIM>
inline Vector<T, DIM> lerp(Vector<T, DIM> const& a, Vector<T, DIM> const& b, Vector<T, DIM> const& t)
{
	Vector<T, DIM> result;
	for (int i = 0; i < DIM; ++i)
	{
		result[i] = lerp(a[i], b[i], t[i]);
	}
	return result;
}

template<class T, int DIM>
inline Vector<T, DIM> clamp(Vector<T, DIM> const& vec, Vector<T, DIM> const& min, Vector<T, DIM> const& max)
{
	Vector<T, DIM> result;
	for (int i = 0; i < DIM; ++i)
	{
		result[i] = std::clamp(vec[i], min[i], max[i]);
	}
	return result;
}

template<class T, int DIM>
inline Vector<T, DIM> clamp(Vector<T, DIM> const& vec, T min, T max)
{
	Vector<T, DIM> result;
	for (int i = 0; i < DIM; ++i)
	{
		result[i] = std::clamp(vec[i], min, max);
	}
	return result;
}

template<class T, int DIM>
inline Vector<T, DIM> lerp(AABB<T, DIM> const& aabb, Vector<T, DIM> const& t)
{
	return lerp(aabb.min, aabb.max, t);
}

///	C++ style type-casts
///
///

template<class T> inline Quaternion<T> as_quaternion(Matrix<T, 3, 3> const& rhs)
{
	Quaternion<T> result;

	T const quarter = constants::half<T>() * constants::half<T>();
	T tr = rhs.xx + rhs.yy + rhs.zz;

	if (tr > 0)
	{
		T coeff = constants::half<T>() / sqrt(tr + 1);

		result.w = quarter / coeff;
		result.x = coeff * (rhs.zy - rhs.yz);
		result.y = coeff * (rhs.xz - rhs.zx);
		result.z = coeff * (rhs.yx - rhs.xy);
	}
	else if ((rhs.xx > rhs.yy) && (rhs.xx > rhs.zz))
	{
		T coeff = constants::half<T>() / sqrt(1 + rhs.xx - rhs.yy - rhs.zz);

		result.w = coeff * (rhs.zy - rhs.yz);
		result.x = quarter / coeff;
		result.y = coeff * (rhs.xy + rhs.yx);
		result.z = coeff * (rhs.xz + rhs.zx);
	}
	else if (rhs.yy > rhs.zz)
	{
		T coeff = constants::half<T>() / sqrt(1 + rhs.yy - rhs.xx - rhs.zz);

		result.w = coeff * (rhs.xz - rhs.zx);
		result.x = coeff * (rhs.xy + rhs.yx);
		result.y = quarter / coeff;
		result.z = coeff * (rhs.yz + rhs.zy);
	}
	else
	{
		T coeff = constants::half<T>() / sqrt(1 + rhs.zz - rhs.xx - rhs.yy);

		result.w = coeff * (rhs.yx - rhs.xy);
		result.x = coeff * (rhs.xz + rhs.zx);
		result.y = coeff * (rhs.yz + rhs.zy);
		result.z = quarter / coeff;
	}

	return result;
}

template<class T> inline Matrix<T, 3, 3> as_matrix(Quaternion<T> const& rhs)
{
	T xx = rhs.x * rhs.x;
	T xy = rhs.x * rhs.y;
	T xz = rhs.x * rhs.z;
	T xw = rhs.x * rhs.w;

	T yy = rhs.y * rhs.y;
	T yz = rhs.y * rhs.z;
	T yw = rhs.y * rhs.w;

	T zz = rhs.z * rhs.z;
	T zw = rhs.z * rhs.w;

	T ww = rhs.w * rhs.w;

	return Matrix<T, 3, 3>
		(
			1 - 2 * (yy + zz), 2 * (xy - zw), 2 * (xz + yw),
			2 * (xy + zw), 1 - 2 * (xx + zz), 2 * (yz - xw),
			2 * (xz - yw), 2 * (yz + xw), 1 - 2 * (xx + yy)
			);
}

///	clamp
///
///	clamp value between values a and b
///	where a < b
template<class T> inline T clamp(T const& x, T const& a, T const& b)
{
	return std::min(std::max(a, x), b);
}

///	exclude
///
///	range of exclusion for the value x defined by a and b
///	where a < b
template<class T> inline T exclude(T const& x, T const& a, T const& b)
{
	if ((x < a) || (b < x))
		return x;

	if ((b - x) > (x - a))
		return a;

	return b;
}

///	intersects
///
///	Sphere intersects AABB
template<class T> inline bool intersects(Sphere<T, 3> const& sphere, AABB<T, 3> const& aabb)
{
	float32_t RR = sphere.radius * sphere.radius;

	auto S = [](float x) { return x * x; };

	if (sphere.center.x < aabb.min.x)
	{
		RR -= S(sphere.center.x - aabb.min.x);
	}
	else if (sphere.center.x > aabb.max.x)
	{
		RR -= S(sphere.center.x - aabb.max.x);
	}

	if (sphere.center.y < aabb.min.y)
	{
		RR -= S(sphere.center.y - aabb.min.y);
	}
	else if (sphere.center.y > aabb.max.y)
	{
		RR -= S(sphere.center.y - aabb.max.y);
	}

	if (sphere.center.z < aabb.min.z)
	{
		RR -= S(sphere.center.z - aabb.min.z);
	}
	else if (sphere.center.z > aabb.max.z)
	{
		RR -= S(sphere.center.z - aabb.max.z);
	}

	return RR > constants::zero<T>();
}

///	intersects
///
///	Sphere intersects AABB
template<class T> inline bool intersects(Sphere<T, 2> const& sphere, AABB<T, 2> const& aabb)
{
	T RR = sphere.radius * sphere.radius;

	auto S = [](T x) { return x * x; };

	if (sphere.center.x < aabb.min.x)
	{
		RR -= S(sphere.center.x - aabb.min.x);
	}
	else if (sphere.center.x > aabb.max.x)
	{
		RR -= S(sphere.center.x - aabb.max.x);
	}

	if (sphere.center.y < aabb.min.y)
	{
		RR -= S(sphere.center.y - aabb.min.y);
	}
	else if (sphere.center.y > aabb.max.y)
	{
		RR -= S(sphere.center.y - aabb.max.y);
	}

	return RR > constants::zero<T>();
}

///	intersects
///
///	Frustum intersects AABB
template<class T> inline bool intersects(Frustum<T> const& frustum, AABB<T, 3> const& aabb)
{
	int const ELEMENT_COUNT = 3;
	int const CORNER_COUNT = Frustum<T>::CORNER_COUNT;

	for (int i = 0; i < ELEMENT_COUNT; ++i)
	{
		int left = 0;
		int right = 0;

		for (int j = 0; j < CORNER_COUNT; ++j)
		{
			left = (frustum.corners[j].elements[i] < aabb.min[i]) ? left + 1 : left;
			right = (aabb.max[i] < frustum.corners[j].elements[i]) ? right + 1 : right;
		}

		if ((CORNER_COUNT == left) || (CORNER_COUNT == right))
		{
			return false;
		}
	}

	Vector<T, 3> const boxCorners[] =
	{
		Vector<T, 3>(aabb.min.x, aabb.min.y, aabb.min.z),
		Vector<T, 3>(aabb.min.x, aabb.min.y, aabb.max.z),
		Vector<T, 3>(aabb.min.x, aabb.max.y, aabb.min.z),
		Vector<T, 3>(aabb.min.x, aabb.max.y, aabb.max.z),
		Vector<T, 3>(aabb.max.x, aabb.min.y, aabb.min.z),
		Vector<T, 3>(aabb.max.x, aabb.min.y, aabb.max.z),
		Vector<T, 3>(aabb.max.x, aabb.max.y, aabb.min.z),
		Vector<T, 3>(aabb.max.x, aabb.max.y, aabb.max.z),
	};

	for (int i = 0; i < Frustum<T>::PLANE_COUNT; ++i)
	{
		Plane<T, 3> const& plane = frustum.planes[i];

		int behind = 0;
		for (int j = 0; j < CORNER_COUNT; ++j)
		{
			if (dot(plane, boxCorners[j]) > 0.f)
				break;
			++behind;
		}

		if (CORNER_COUNT == behind)
		{
			return false;
		}
	}

	return true;
}


///	intersects
///
///	Frustum intersects AABB
template<class T> inline bool looselyIntersects(Frustum<T> const& frustum, AABB<T, 3> const& aabb)
{
	int const ELEMENT_COUNT = 3;
	int const CORNER_COUNT = Frustum<T>::CORNER_COUNT;

	Vector<T, 3> const len((aabb.max.x - aabb.min.x) * 0.5f,
		(aabb.max.y - aabb.min.y) * 0.5f,
		(aabb.max.z - aabb.min.z) * 0.5f);


	for (int i = 0; i < ELEMENT_COUNT; ++i)
	{
		int left = 0;
		int right = 0;

		for (int j = 0; j < CORNER_COUNT; ++j)
		{
			left = (frustum.corners[j].elements[i] < aabb.min[i] - len[i]) ? left + 1 : left;
			right = (aabb.max[i] + len[i] < frustum.corners[j].elements[i]) ? right + 1 : right;
		}

		if ((CORNER_COUNT == left) || (CORNER_COUNT == right))
		{
			return false;
		}
	}

	Vector<T, 3> const boxCorners[] =
	{
		Vector<T, 3>(aabb.min.x - len.x, aabb.min.y - len.y, aabb.min.z - len.z),
		Vector<T, 3>(aabb.min.x - len.x, aabb.min.y - len.y, aabb.max.z + len.z),
		Vector<T, 3>(aabb.min.x - len.x, aabb.max.y + len.y, aabb.min.z - len.z),
		Vector<T, 3>(aabb.min.x - len.x, aabb.max.y + len.y, aabb.max.z + len.z),
		Vector<T, 3>(aabb.max.x + len.x, aabb.min.y - len.y, aabb.min.z - len.z),
		Vector<T, 3>(aabb.max.x + len.x, aabb.min.y - len.y, aabb.max.z + len.z),
		Vector<T, 3>(aabb.max.x + len.x, aabb.max.y + len.y, aabb.min.z - len.z),
		Vector<T, 3>(aabb.max.x + len.x, aabb.max.y + len.y, aabb.max.z + len.z),
	};

	for (int i = 0; i < Frustum<T>::PLANE_COUNT; ++i)
	{
		Plane<T, 3> const& plane = frustum.planes[i];

		int behind = 0;
		for (int j = 0; j < CORNER_COUNT; ++j)
		{
			if (dot(plane, boxCorners[j]) > 0.f)
				break;
			++behind;
		}

		if (CORNER_COUNT == behind)
		{
			return false;
		}
	}

	return true;
}


///	project
///
///	project a specified number of 3D points onto an axis and return a min/max range.
template<class T> inline std::pair<T, T> project(Vector<T, 3> const* vertices, int32_t vertexCount, Vector<T, 3> const& axis)
{
	std::pair<T, T> result(0, 0);

	result.first = dot(vertices[0], axis);
	result.second = result.first;

	for (int32_t i = 1; i < vertexCount; ++i)
	{
		float32_t D = dot(vertices[i], axis);

		result.first = std::min(result.first, D);
		result.second = std::max(result.second, D);
	}

	return result;
}

///	intersect
///
///	3D AABB intersects 3D triangle
template<class T> inline bool intersect(AABB<T, 3> const& box, Vector<T, 3> const& v_i, Vector<T, 3> const& v_j, Vector<T, 3> const& v_k)
{
	Vector<T, 3> const boxNormals[] =
	{
		Vector<T, 3>(1, 0, 0),
		Vector<T, 3>(0, 1, 0),
		Vector<T, 3>(0, 0, 1),
	};

	Vector<T, 3> const faceVertices[] = { v_i, v_j, v_k, };

	for (int i = 0; i < 3; ++i)
	{
		std::pair<T, T> range = project(faceVertices, 3, boxNormals[i]);
		if ((range.second < box.min[i]) || (box.max[i] < range.first))
		{
			return false;
		}
	}

	Vector<T, 3> const boxVertices[] =
	{
		Vector<T, 3>(box.min.x, box.min.y, box.min.z),
		Vector<T, 3>(box.min.x, box.min.y, box.max.z),
		Vector<T, 3>(box.min.x, box.max.y, box.min.z),
		Vector<T, 3>(box.min.x, box.max.y, box.max.z),
		Vector<T, 3>(box.max.x, box.min.y, box.min.z),
		Vector<T, 3>(box.max.x, box.min.y, box.max.z),
		Vector<T, 3>(box.max.x, box.max.y, box.min.z),
		Vector<T, 3>(box.max.x, box.max.y, box.max.z),
	};

	{
		Vector<T, 3> const faceNormal = normalize(cross(v_j - v_i, v_k - v_i));
		float32_t D = dot(faceNormal, v_i);

		std::pair<T, T> range = project(boxVertices, 8, faceNormal);
		if ((range.second < D) || (D < range.first))
		{
			return false;
		}
	}

	Vector<T, 3> const faceEdges[] = { v_j - v_i, v_k - v_j, v_i - v_k, };

	for (int32_t i = 0; i < 3; ++i)
	{
		for (int32_t j = 0; j < 3; ++j)
		{
			Vector<T, 3> axis = cross(faceEdges[i], boxNormals[j]);

			std::pair<T, T> boxRange = project(boxVertices, 8, axis);
			std::pair<T, T> faceRange = project(faceVertices, 3, axis);
			if ((boxRange.second < faceRange.first) || (faceRange.second < boxRange.first))
			{
				return false;
			}
		}
	}

	return true;
}

///	contains
///
///	3D Frustum contains 3D AABB
template<class T> inline bool contains(Frustum<T> const& frustum, AABB<T, 3> const& aabb)
{
	int const CORNER_COUNT = 8;

	Vector<T, 3> const corners[] =
	{
		Vector<T, 3>(aabb.min.x, aabb.min.y, aabb.min.z),
		Vector<T, 3>(aabb.min.x, aabb.min.y, aabb.max.z),
		Vector<T, 3>(aabb.min.x, aabb.max.y, aabb.min.z),
		Vector<T, 3>(aabb.min.x, aabb.max.y, aabb.max.z),
		Vector<T, 3>(aabb.max.x, aabb.min.y, aabb.min.z),
		Vector<T, 3>(aabb.max.x, aabb.min.y, aabb.max.z),
		Vector<T, 3>(aabb.max.x, aabb.max.y, aabb.min.z),
		Vector<T, 3>(aabb.max.x, aabb.max.y, aabb.max.z),
	};

	for (int i = 0; i < Frustum<T>::PLANE_COUNT; ++i)
	{
		Plane<T, 3> const& plane = frustum.planes[i];

		for (int j = 0; j < CORNER_COUNT; ++j)
		{
			if (dot(plane, corners[j]) < 0.f)
				return false;
		}
	}

	return true;
}

///	projectedRect
///
///
template<class T> inline struct AABB<T, 2> projectedRect(Matrix<T, 4, 4> const& viewProjMatrix, T const& znear, AABB<T, 3> const& aabb)
{
	int const CORNER_COUNT = 8;

	AABB<T, 2> result;

	Vector<T, 4> const corners[] =
	{
		Vector<T, 4>(aabb.min.x, aabb.min.y, aabb.min.z, constants::one<T>()),
		Vector<T, 4>(aabb.min.x, aabb.min.y, aabb.max.z, constants::one<T>()),
		Vector<T, 4>(aabb.min.x, aabb.max.y, aabb.min.z, constants::one<T>()),
		Vector<T, 4>(aabb.min.x, aabb.max.y, aabb.max.z, constants::one<T>()),
		Vector<T, 4>(aabb.max.x, aabb.min.y, aabb.min.z, constants::one<T>()),
		Vector<T, 4>(aabb.max.x, aabb.min.y, aabb.max.z, constants::one<T>()),
		Vector<T, 4>(aabb.max.x, aabb.max.y, aabb.min.z, constants::one<T>()),
		Vector<T, 4>(aabb.max.x, aabb.max.y, aabb.max.z, constants::one<T>()),
	};

	Vector<T, 4> projected = viewProjMatrix * corners[0];

	Vector<T, 4> projectedCorners[CORNER_COUNT];
	Vector<T, 4> excludedCorners[CORNER_COUNT];

	projectedCorners[0] = projected;

	projected = projected / exclude(projected.w, -znear, znear);

	excludedCorners[0] = projected;

	T xmin = projected.x;
	T ymin = projected.y;

	T xmax = projected.x;
	T ymax = projected.y;

	for (int i = 1; i < CORNER_COUNT; ++i)
	{
		projected = viewProjMatrix * corners[i];
		projectedCorners[i] = projected;
		projected = projected / exclude(projected.w, -znear, znear);
		excludedCorners[i] = projected;

		xmin = std::min(xmin, projected.x);
		ymin = std::min(ymin, projected.y);

		xmax = std::max(xmax, projected.x);
		ymax = std::max(ymax, projected.y);
	}

	result.min[0] = xmin;
	result.min[1] = ymin;

	result.max[0] = xmax;
	result.max[1] = ymax;

	return result;
}

///	areaProjected
///
///
template<class T> inline T areaProjected(Matrix<T, 4, 4> const& viewProjMatrix, T const& znear, AABB<T, 3> const& aabb)
{
	AABB<T, 2> rect = projectedRect(viewProjMatrix, znear, aabb);
	return (rect.max[0] - rect.min[0]) * (rect.max[1] - rect.min[1]);
}

///	areaProjectedClipped
///
///
template<class T> inline T areaProjectedClipped(Matrix<T, 4, 4> const& viewProjMatrix, T const& znear, AABB<T, 3> const& aabb)
{
	//return areaProjected(viewProjMatrix, znear, aabb);

	AABB<T, 2> rect = projectedRect(viewProjMatrix, znear, aabb);

	if (rect.max[0] <= (T)-1 || rect.min[0] >= (T)1 || rect.max[1] <= (T)-1 || rect.min[1] >= (T)1)
		return 0;

	T xmax = std::min(rect.max[0], (T)1),
		xmin = std::max(rect.min[0], (T)-1),
		ymax = std::min(rect.max[1], (T)1),
		ymin = std::max(rect.min[1], (T)-1);

	return (xmax - xmin) * (ymax - ymin);
	/**/
}

// takes any angle theta (in radians) and returns the canonical angle in [0, 2pi) that is equivalent
// to theta
template<typename T>
T canonicalAngle(T const theta)
{
	// make sure angle is in [0, 2pi]
	T canonical = std::fmod(theta, constants::two_pi<T>());
	if (canonical < 0.0)
	{
		canonical += lucid::math::constants::two_pi<T>();
	}
	return canonical;
}

// function that will compute an angle that is closest to theta of all angles that are equivalent to phi 
template<typename T>
T closestEquivalentAngle(T theta, T phi)
{
	if (std::abs(theta - phi) <= constants::pi<T>())
	{
		return phi;
	}
	else
	{
		T tau = constants::two_pi<T>();
		return (theta < phi) ? closestEquivalentAngle(theta, phi - tau) : closestEquivalentAngle(theta, phi + tau);
	}
}

template<typename T>
inline T angle(Vector<T, 2> const& u, Vector<T, 2> const& v)
{
	return canonicalAngle(std::atan2(cross(u, v), dot(u, v)));
}

template<typename T>
T degreesToRadians(T const degrees)
{
	auto static const degToRadFactor = constants::pi<T>() / static_cast<T>(180.0);
	return degToRadFactor * degrees;
}

template<typename T>
T radiansToDegrees(T const radians)
{
	auto static const radToDegFactor = static_cast<T>(180.0) / constants::pi<T>();
	return radToDegFactor * radians;
}

template<typename T>
bool convexHullIsSquare(Vector<T, 2> const& a, Vector<T, 2> const& b, Vector<T, 2> const& c, Vector<T, 2> const& d)
{
	std::array<T, 6> distances =
	{
		lenSquared(a - b),
		lenSquared(a - c),
		lenSquared(a - d),
		lenSquared(b - c),
		lenSquared(b - d),
		lenSquared(c - d),
	};
	std::sort(distances.begin(), distances.end());
	bool sides = distances[0] == distances[1] && distances[1] == distances[2] && distances[2] == distances[3];
	bool diagonals = distances[4] == distances[5];
	return sides && diagonals;
}

template<typename T>
Polygon<T> subdivide(Polygon<T> const& source, T maxSegmentLength)
{
	Polygon<T> result;
	if (source.empty())
	{
		return result;
	}

	result.reserve(source.size());
	result.add(source[0]);

	for (auto idx = 0ull; idx < source.size(); ++idx)
	{
		auto segment = source.edge(idx);
		auto direction = segment.direction();
		auto length = lucid::math::len(direction);
		direction = direction / length;
		if (length <= maxSegmentLength)
		{
			// only add the last point if this is not the final segment
			if (idx < source.size() - 1) { result.add(segment.end); }
			continue;
		}

		auto count = size_t(std::ceil(length / maxSegmentLength));

		auto addLen = length / T(count);
		T currentPos = 0;
		for (auto i = 1ull; i < count; ++i)
		{
			currentPos += addLen;
			auto next = segment.start + (direction * currentPos);
			result.add(next);
		}

		if (idx < source.size() - 1)
		{
			result.add(segment.end);
		}
	}

	return result;
}

// theta is in radians
template<typename T>
lucid::math::Vector<T, 2> unitVector(T theta)
{
	return { lucid::math::cos(theta), lucid::math::sin(theta) };
}

template<typename T>
bool equWeak(T const lhs, T const rhs, T const epsilon = constants::tol_tol<T>())
{
	return std::abs(lhs - rhs) < epsilon;
}


// Implements Ramer-Douglas-Peucker algorithm:
// https://en.wikipedia.org/wiki/Ramer%E2%80%93Douglas%E2%80%93Peucker_algorithm
// Output will be in the indices and indexRange parameters
// indexRange IN is the first and last+1 indices of the indices (idx >= begin, idx < end) to be evaulated
//			  OUT is the first and last+1 indices of the actual indices used
template<typename T, int DIM>
void simplify(std::vector<lucid::math::Vector<T, DIM>> const& vertices, std::vector<size_t>& indices, lucid::math::Range<size_t>& indexRange, T epsilon)
{
	if (indexRange.end - indexRange.begin <= 2)
	{
		return;
	}

	T maxDist = T(0);
	size_t maxIndex = indexRange.begin;
	LineSegment2d<T> segment(vertices[indices[indexRange.begin]], vertices[indices[indexRange.end - 1]]);

	// Find the pivot vertex that is furthest from the line segment
	for (size_t pos = indexRange.begin + 1; pos < indexRange.end - 1; ++pos)
	{
		auto const& vtx = vertices[indices[pos]];
		auto pDist = segment.distanceTo(vtx);
		if (pDist > maxDist)
		{
			maxIndex = pos;
			maxDist = pDist;
		}
	}

	if (maxDist > epsilon && maxIndex != indexRange.begin)
	{
		// In the case where we have exactly 3 vertices and one is outside of the epsilon limit,
		// there are no more changes that need to be made.
		if (indexRange.end - indexRange.begin > 3)
		{
			lucid::math::Range<size_t> r1(indexRange.begin, maxIndex + 1),
				r2(maxIndex, indexRange.end);

			// Simplify the left side of the pivot vertex
			if (r1.end - r1.begin > 2)
			{
				simplify(vertices, indices, r1, epsilon);
			}
			// Simplify the right side of the pivot vertex
			if (r2.end - r2.begin > 2)
			{
				simplify(vertices, indices, r2, epsilon);
			}

			// If any vertices were eliminated, we need to update the indices
			if (r2.end != indexRange.end || r1.end != maxIndex + 1)
			{
				size_t moveIdx = r1.end;
				for (size_t idx = r2.begin + 1; idx < r2.end; ++idx)
				{
					indices[moveIdx++] = indices[idx];
				}
				indexRange.end = moveIdx;
			}
		}

	}
	else
	{
		indices[indexRange.begin + 1] = indices[indexRange.end - 1];
		indexRange.end = indexRange.begin + 2;
	}

	return;
}

// Convenience function to call the more performant version of simplify
template<typename T, int DIM>
std::vector<lucid::math::Vector<T, DIM>> simplify(std::vector<lucid::math::Vector<T, DIM>> const& vertices, T epsilon)
{
	std::vector<size_t> indices;
	indices.reserve(vertices.size());

	for (size_t i = 0; i < vertices.size(); ++i)
	{
		indices.push_back(i);
	}

	lucid::math::Range<size_t> range(0, vertices.size());
	simplify(vertices, indices, range, epsilon);

	std::vector<lucid::math::Vector<T, DIM>> result;
	result.reserve(range.end - range.begin);

	if (range.end != vertices.size())
	{
		for (size_t pos = 0; pos < range.end; ++pos)
		{
			result.push_back(vertices[indices[pos]]);
		}
	}
	else
	{
		result.insert(result.begin(), vertices.begin(), vertices.end());
	}
	return result;
}

// The transformations below only work if the given ObjT's relevant transformation functions
// do their transformations in place, and that the object is copy constructible
template <typename ObjT, typename T, int DIM>
ObjT translate(ObjT const& obj, Vector<T, DIM> const& translation)
{
	ObjT transfObj = obj;
	transfObj.translate(translation);
	return transfObj;
}

// If you get conversion warnings here, it most likely means there's a type mismatch
// between "s" and transfObj's input type that is causing a narrowing conversion.
// (transfObj take float but you pass s as a double)
// Would be nice to do a cast here to whatever type the called function expects, but idk if that is possible
template <typename ObjT, typename ScaleT>
ObjT scale(ObjT const& obj, ScaleT const& s)
{
	ObjT transfObj = obj;
	transfObj.scale(s);
	return transfObj;
}

template <typename ObjT, typename T, int DIM>
ObjT transform(ObjT const& obj, Matrix<T, DIM, DIM> const& mat)
{
	ObjT transfObj = obj;
	transfObj.transform(mat);
	return transfObj;
}

}	///	math
}	///	lucid