#pragma once

#include <cmath>

#include <vector>

#include "Vector.h"
#include "Matrix.h"
#include "LineSegment.h"
#include "AABB.h"
#include "Range.h"

namespace lucid {
namespace math {

	template<class T>
	// Structure that stores the results of the PolygonCollision function
	struct PolygonCollisionResult {
		// Are the polygons going to intersect forward in time?
		bool willIntersect;
		// Are the polygons currently intersecting?
		bool doIntersect;
		// The translation to apply to the first polygon to push the polygons apart.
		Vector<T, 2> minimumTranslationVector;
	};

	template<class T>
	class Polygon;

	template<class T>
	__inline PolygonCollisionResult<T> willCollide(Polygon<T> const& polygonA, Polygon<T> const& polygonB,
		Vector<T, 2> const& velocity);

	template<class T>
	class Polygon
	{
	public:
		typedef Vector<T, 2> vecT;
		typedef AABB<T, 2> aabbT;
		typedef vecT value_type; // for earcut algorithm
	private:

		std::vector<vecT>	_points;
		aabbT				_aabb = AABB<T, 2>::nothing();

	public:

		Polygon() {}
		Polygon(std::vector<vecT> const& points)
		{
			_points.reserve(points.size());
			for (auto const& p : points)
			{
				add(p);
			}
		}

		template<class Iter>
		__inline void append(Iter const& begin, Iter const& end)
		{
			for (auto curr = begin; curr != end; ++curr)
			{
				add(*curr);
			}
		}

		__inline void reserve(size_t size) { _points.reserve(size); }
		__inline bool empty() const { return _points.size() < 3; }
		__inline size_t size() const { auto count = _points.size(); if (count < 3) return 0; return count; }
		__inline size_t byteCount() const { return vecT::byteCount() * _points.capacity(); }
		__inline void add(vecT point)
		{
			if (!_points.empty())
			{
				if (point == _points.back())
				{
					return;
				}
			}
			_points.push_back(point);
			_aabb = _aabb.fit(point);
		}
		__inline void set(size_t index, vecT point)
		{
			_points[index] = point;
			_aabb = fit(_points);
		}

		__inline std::vector<vecT> const& getPoints() const { return _points; }

		__inline void clear() { _points.clear(); _aabb = AABB<T, 2>::Empty(); }
		__inline LineSegment<T, 2> edge(size_t index) const
		{
			auto count = _points.size();
			assert(index < count);
			auto i2 = index + 1;
			if (i2 == count)
				i2 = 0;

			return LineSegment<T, 2>(_points[index], _points[i2]);
		}
		__inline vecT vertex(size_t index) const
		{
			return _points[index];
		}

		__inline aabbT aabb() const { return _aabb; }

		__inline vecT operator[] (size_t index) const { assert(index < _points.size()); return _points[index]; }

		T length() const
		{
			T len = T(0.0);
			if (empty()) { return len; }
			auto end = _points.data() + _points.size();
			for (auto ptr = _points.data(); ptr + 1 < end; ++ptr)
			{
				len += lucid::math::len(ptr[1] - ptr[0]);
			}
			len += lucid::math::len(_points.front() - _points.back());
			return len;
		}

		// computed using the trapezoid formula for polygon area on this wikipedia page: https://en.wikipedia.org/wiki/Shoelace_formula
		T signedArea() const
		{
			T sum = 0.0;

			// early out for malformed polygons
			if (size() < 3)
			{
				return sum;
			}

			// iterate over every segment but the last
			for (size_t i = 0; i + 1 < size(); ++i)
			{
				vecT const& cur = _points[i];
				vecT const& nxt = _points[i + 1];
				sum += (cur.y + nxt.y) * (cur.x - nxt.x);
			}

			// add in the final segment
			vecT const& cur = _points.back();
			vecT const& nxt = _points.front();
			sum += (cur.y + nxt.y) * (cur.x - nxt.x);

			return T(0.5) * sum;
		}

		inline T area() const
		{
			return std::abs(signedArea());
		}

		bool contains(Vector<T, 2> const& query) const
		{
			bool inside = false;

			// early out if possible
			auto size = _points.size();
			if (size < 3) { return false; }
			if (!_aabb.contains(query)) { return false; }

			// shoot a ray in the +x direction and determine containment by how many edges are crossed
			auto const data = _points.data();
			size_t j = size - 1;
			for (size_t i = 0; i < size; j = i++)
			{
				auto const& p1 = data[j];
				auto const& p2 = data[i];
				if ((p1.y > query.y) != (p2.y > query.y))		// check if the y-range contains the query
				{
					if (query.x <= p1.x || query.x <= p2.x)		// check if the query is to the lhs of either endpoint
					{
						auto slopeInv = (p2.x - p1.x) / (p2.y - p1.y);
						auto intercept = slopeInv * (query.y - p1.y) + p1.x;
						if (query.x < intercept)
						{
							inside = !inside;
						}
					}
				}
			}

			return inside;
		}

		bool boundaryIntersects(aabbT const& bounds) const
		{
			if (intersectsOrTouches(_aabb, bounds))
			{
				if (intersects(_points, bounds))
				{
					return true;
				}
				else
				{
					// grab and clip the closing line segment
					LineSegment<T, 2> segment = { _points.back(), _points.front()};
					LineSegment<T, 2> clipped = clip(bounds, segment);
					if (clipped.start != clipped.end)		// check if the clipped segment was in the bounds
					{
						return true;
					}
				}
			}

			return false;
		}

		T distanceTo(Vector<T, 2> const& point) const
		{
			T dist = std::numeric_limits<T>::max();
			for (size_t i = 0; i < size(); ++i)
			{
				LineSegment<T, 2> e = edge(i);
				dist = std::min(dist, e.distanceTo(point));
			}
			return (contains(point)) ? -dist : dist;
		}

		Range<T> project(Vector<T, 2> axis) const
		{
			Range<T> result;
			result.begin = dot(axis, vertex(0));
			result.end = result.begin;

			for (size_t i = 1; i < size(); ++i)
			{
				Vector<T, 2> const p1 = vertex(i);
				auto d = dot(axis, p1);
				if (d < result.begin)
					result.begin = d;
				else if (d > result.end)
					result.end = d;
			}

			return result;
		}

		void translate(vecT translation)
		{
			for (auto& point : _points)
			{
				point += translation;
			}

			_aabb.min += translation;
			_aabb.max += translation;
		}

		void scale(vecT scalars)
		{
			for (auto& point : _points)
			{
				point[0] *= scalars[0];
				point[1] *= scalars[1];
			}

			for (int i = 0; i < 2; ++i)
			{
				_aabb.min[i] *= scalars[i];
				_aabb.max[i] *= scalars[i];
			}
		}

		void scale(T scale)
		{
			for (auto& point : _points)
			{
				point *= scale;
			}

			_aabb.min *= scale;
			_aabb.max *= scale;
		}

		void transform(Matrix<T, 3, 3> transformation)
		{
			for (auto& point : _points)
			{
				point = lucid::math::unHomogenize(transformation * lucid::math::homogenize(point));
			}
			_aabb = fit(_points);
		}

		PolygonCollisionResult<T> willCollide(Polygon<T> const& rhs, vecT velocity)
		{
			return lucid::math::willCollide(*this, rhs, velocity);
		}
	};

	template<class T>
	inline bool operator==(Polygon<T> const& lhs, Polygon<T> const& rhs)
	{
		using PointsVecT = std::vector<typename Polygon<T>::vecT>;

		// grab const references to each vector of points
		PointsVecT const& lPoints = lhs.getPoints();
		PointsVecT const& rPoints = rhs.getPoints();

		// check that the sizes are equal
		if (lPoints.size() != rPoints.size())
		{
			return false;
		}

		// check that each point equals the other
		for (size_t i = 0; i < lPoints.size(); ++i)
		{
			if (lPoints[i] != rPoints[i])
			{
				return false;
			}
		}

		// made it through all points, return true
		return true;
	}

	template<class T>
	inline bool operator!=(Polygon<T> const& lhs, Polygon<T> const& rhs)
	{
		return !(lhs == rhs);
	}

	// convencience fit function for a collection of Polygons. must be used like fit<ContainterType>
	template<template<class, class...> class ContainerT, class T, class... Additional>
	inline AABB<T, 2> fit(ContainerT<Polygon<T>, Additional...> const& container)
	{
		AABB<T, 2> box = AABB<T, 2>::nothing();
		for (Polygon<T> const& polygon : container)
		{
			box = fit(box, polygon.aabb());
		}
		return box;
	}

	template <class T>
	// This functions clips all the edges w.r.t one clip edge of clipping area
	std::vector<Vector<T, 2>> clip(std::vector<Vector<T, 2>> const& polygon, LineSegment<T, 2> const& edge)
	{
		size_t size = polygon.size();
		std::vector<Vector<T, 2>> newPoints;
		newPoints.reserve(size);

		auto p1 = polygon.back();
		auto p1Pos = sideRelativeTo(edge, p1);

		for (auto const& p2 : polygon)
		{
			// Calculating position of second point w.r.t. clipper line
			T p2Pos = sideRelativeTo(edge, p2);

			bool p1In = p1Pos <= 0;
			bool p2In = p2Pos <= 0;

			LineSegment<T, 2> segment(p1, p2);

			if (p1In && p2In)			// Case 1: When both points are inside
			{
				// Only add second point
				newPoints.push_back(p2);
			}
			else if (!p1In && p2In)		// Case 2: When only first point is outside
			{
				// Point of intersection with edge and the second point is added
				newPoints.push_back({ x_intersect(edge, segment), y_intersect(edge, segment) });
				newPoints.push_back(p2);
			}
			else if (p1In && !p2In)		// Case 3: When only second point is outside
			{
				// Only point of intersection with edge is added
				newPoints.push_back({ x_intersect(edge, segment), y_intersect(edge, segment) });
			}
			else						// Case 4: When both points are outside
			{
				// No points are added
			}

			p1 = p2;
			p1Pos = p2Pos;
		}

		return newPoints;
	}

	template<class T, class ClipListT>
	// Implements Sutherland-Hodgman algorithm; clip points must be a convex polygon specified in clockwise order
	inline std::vector<Vector<T, 2>> clip(std::vector<Vector<T, 2>> const& polygon, ClipListT const& clipPoints)
	{
		std::vector<Vector<T, 2>> result(polygon);
		auto p1 = clipPoints.back();

		for (auto const& p2 : clipPoints)
		{
			LineSegment<T, 2> clipEdge(p1, p2);
			result = clip(result, clipEdge);
			if (result.empty())
			{
				break;
			}
			p1 = p2;
		}
		return result;
	}

	template<class T, class ClipListT>
	inline Polygon<T> clip(Polygon<T> const& polygon, ClipListT const& clipPoints)
	{
		return Polygon<T>(clip(polygon.getPoints(), clipPoints));
	}

	template<class T>
	inline Polygon<T> clip(Polygon<T> const& polygon, AABB<T, 2> const& box)
	{
		std::array<Vector<T, 2>, 4> list = { box.min, { box.min.x, box.max.y }, box.max, { box.max.x, box.min.y } };
		return clip(polygon, list);
	}

	template<class T, class Intersector>
	inline Intersections intersects(Polygon<T> const&, T)
	{
		return Intersections::NONE;
	}

	template <class T>
	inline Intersections intersects(Polygon<T> const &lhs, Polygon<T> const& rhs)
	{
		if (lhs.size() < 2 || rhs.size() < 2)
			return Intersections::NONE;

		auto aabbIntersects = lucid::math::intersects(lhs._aabb, rhs._aabb); // _aabb.intersects(rhs._aabb);
		if (aabbIntersects == Intersections::NONE)
			return Intersections::NONE;

		for (size_t l1 = 0; l1 < lhs.size(); ++l1)
		{
			auto seg1 = lhs.edge(l1);
			for (size_t l2 = 0; l2 < rhs.size(); ++l2)
			{
				auto seg2 = rhs.edge(l2);
				auto segIntersect = lucid::math::intersects(seg1, seg2);
				if (std::isnan(segIntersect) || segIntersect == 0 || segIntersect == 1)
					continue;

				return Intersections::PARTIAL;
			}
		}

		return Intersections::NONE;
	}

	template<class T>
	PolygonCollisionResult<T> willCollide(Polygon<T> const& polygonA, Polygon<T> const& polygonB, Vector<T, 2> const& velocity)
	{
		PolygonCollisionResult<T> result;
		auto aabbA = polygonA.aabb().pushBounds(velocity);
		auto aabbB = polygonB.aabb();
		if (lucid::math::intersects(aabbA, aabbB) == Intersections::NONE)
		{
			result.doIntersect = false;
			result.willIntersect = false;
			return result;
		}

		result.doIntersect = true;
		result.willIntersect = true;

		int edgeCountA = polygonA.size();
		int edgeCountB = polygonB.size();
		T minIntervalDistance = lucid::math::constants::pos_inf<T>();

		Vector<T, 2> translationAxis;
		LineSegment<T, 2> segment;
		Vector<T, 2> edge;

		// Loop through all the edges of both polygons
		for (int edgeIndex = 0; edgeIndex < edgeCountA + edgeCountB; edgeIndex++)
		{
			if (edgeIndex < edgeCountA)
				segment = polygonA.edge(edgeIndex);
			else
				segment = polygonB.edge(edgeIndex - edgeCountA);

			edge = (segment.start - segment.end);

			// ===== 1. Find if the polygons are currently intersecting =====

			// Find the axis perpendicular to the current edge
			Vector<T, 2> axis(-edge.y, edge.x);
			axis = normalize(axis);

			// Find the projection of the polygon on the current axis
			auto rangeA = polygonA.project(axis);
			auto rangeB = polygonB.project(axis);
						  
			// Check if the polygon projections are currentlty intersecting
			if (distance(rangeA, rangeB) > 0)
				result.doIntersect = false;

			// ===== 2. Now find if the polygons *will* intersect =====

			// Project the velocity on the current axis
			T velocityProjection = dot(axis, velocity);

			// Get the projection of polygon A during the movement
			if (velocityProjection < 0)
				rangeA.begin += velocityProjection;
			else
				rangeA.end += velocityProjection;

			// Do the same test as above for the new projection
			T intervalDistance = distance(rangeA, rangeB);
			if (intervalDistance > 0) result.willIntersect = false;

			// If the polygons are not intersecting and won't intersect, exit the loop
			if (!(result.doIntersect || result.willIntersect)) break;

			// Check if the current interval distance is the minimum one. If so store
			// the interval distance and the current distance.
			// This will be used to calculate the minimum translation vector
			intervalDistance = std::abs(intervalDistance);
			if (intervalDistance < minIntervalDistance) {
				minIntervalDistance = intervalDistance;
				translationAxis = axis;

				auto d = polygonA.aabb().center() - polygonB.aabb().center();
				if (dot(d, translationAxis) < 0)
					translationAxis = -translationAxis;
			}
		}

		// The minimum translation vector
		// can be used to push the polygons appart.
		if (result.willIntersect)
			result.minimumTranslationVector =
			translationAxis * minIntervalDistance;

		return result;
	}

} // math
} // lucid