#pragma once

#include <cmath>

namespace lucid {
namespace math {

	enum class Boundary : uint32_t
	{
		CLOSED = 0x00000000,
		OPEN = 0xFFFFFFFF
	};

	inline Boundary complement(Boundary input)
	{
		uint32_t casted = static_cast<uint32_t>(input);
		return static_cast<Boundary>(~casted);
	}

} // math
} // lucid