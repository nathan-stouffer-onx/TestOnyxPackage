#pragma once

#include "Vector.h"

namespace lucid {
namespace math {

	template<class T, int DIM> struct Plane
	{
		using vecT = Vector<T, DIM>;

		Plane() = default;
		Plane(vecT const& _point, vecT const& _normal) : point(_point), normal(_normal) {}

		T distanceTo(vecT const& p) const
		{
			return math::dot(normal, p - point);
		}

		vecT point;
		vecT normal;

	};

}	///	math
}	///	lucid

///	TBD: operators...

namespace lucid {
namespace math {

	template<class T> inline Plane<T, 3> makePlane3(Vector<T, 3> const &a, Vector<T, 3> const &b, Vector<T, 3> const &c)
	{
		Vector<T, 3> normal = normalize(cross(b - a, c - a));
		return Plane<T, 3>(b, normal);
	}

}	///	math
}	///	lucid
