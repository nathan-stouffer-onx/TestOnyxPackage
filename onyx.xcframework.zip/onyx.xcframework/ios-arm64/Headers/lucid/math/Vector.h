#pragma once

#include <limits>
#include <cassert>
#include <algorithm>
#include "Constants.h"
#include "Scalar.h"
#include <math.h>

/// Note:	Our template specializations of Vector reads what should be "inactive" members of a union. We keep this convenience despite
///			it technically being undefined behavior because
///				1) It allows us to access members by indexing and by accessing xyz members easily, which makes usage feel more natural
///				2) We use simple types that won't result in extra padding, avoiding nasty behavior when reading by index after
///					writing by member access
///				3) This behavior has been around for awhile. Popular compilers wouldn't want to break apps by changing this behavior

namespace lucid {
namespace math {

	template<class T, int DIM, class VectorT> struct VectorBase
	{
	private:

		VectorT const& vector() const { return static_cast<VectorT const&>(*this); }
		VectorT& vector() { return static_cast<VectorT&>(*this); }

	public:

		T& operator[](int32_t i)
		{
			assert(i < DIM);
			return vector().elements[i];
		}

		T const& operator[](int32_t i) const
		{
			assert(i < DIM);
			return vector().elements[i];
		}

		VectorT& operator+=(VectorT const& rhs)
		{
			for (int i = 0; i < DIM; ++i)
			{
				vector().elements[i] += rhs.elements[i];
			}
			return vector();
		}

		VectorT& operator-=(VectorT const& rhs)
		{
			for (int i = 0; i < DIM; ++i)
			{
				vector().elements[i] -= rhs.elements[i];
			}
			return vector();
		}

		inline VectorT& operator*=(T const scalar)
		{
			for (int i = 0; i < DIM; ++i)
			{
				vector()[i] *= scalar;
			}
			return vector();
		}
		
		inline T const operator*(VectorT const& rhs) const
		{
			T dot = T(0);
			for (int i = 0; i < DIM; ++i) { dot += vector()[i] * rhs[i]; }
			return dot;
		}

		inline T const length() const { return std::sqrt(vector() * vector()); }

		inline void normalize() { vector() *= (T(1) / length()); }

		inline size_t size() const { return size_t(DIM); }
		static inline size_t byteCount() { return size_t(DIM) * sizeof(T); }

		VectorT minBound(VectorT const& rhs) const
		{
			VectorT result;
			for (size_t i = 0; i < DIM; ++i)
				result[i] = std::min<T>(vector().elements[i], rhs.elements[i]);
			return result;
		}

		VectorT maxBound(VectorT const& rhs) const
		{
			VectorT result;
			for (size_t i = 0; i < DIM; ++i)
				result.elements[i] = std::max<T>(vector().elements[i], rhs.elements[i]);
			return result;
		}

		size_t GetHashCode() const
		{
			size_t result = 17;
			for (int i = 0; i < DIM; ++i)
				result = result * 23 + std::hash<float>{}(vector().elements[i]);
			return result;
		}

	};

	///	Vector<T,DIM>
	///
	///	general vector template
	template<class T, int DIM> struct Vector : public VectorBase<T, DIM, Vector<T, DIM>>
	{
		T elements[DIM];

		Vector() = default;

		Vector<T, DIM + 1> homogenized() const
		{
			Vector<T, DIM + 1> result;

			for (int i = 0; i < DIM; ++i)
				result.elements[i] = elements[i];

			result[DIM] = 1;

			return result;
		}

		Vector<T, DIM - 1> unHomogenized() const
		{
			Vector<T, DIM - 1> result;

			for (int i = 0; i < DIM - 1; ++i)
				result.elements[i] = elements[i];

			return result;
		}

		template<typename CAST>
		inline Vector<CAST, DIM> as() const
		{
			static_assert(!std::is_same<CAST, T>::value, "Unnecessary vector cast");
			Vector<CAST, DIM> result;

			for (int i = 0; i < DIM; ++i)
				result.elements[i] = CAST(elements[i]);

			return result;
		}

	};

	///	Vector<T,2>
	///
	///	2D specialization of Vector<>
	///	providing (x,y) members.
	template<class T> struct Vector<T,2> : public VectorBase<T, 2, Vector<T, 2>>
	{
		union
		{
			T elements[2];
			struct { T x, y; };
		};

		Vector() = default;
		Vector(T const &x, T const &y) : x(x), y(y) {}
		Vector(T const& n) : x(n), y(n) {}

		template<typename CAST>
		inline Vector<CAST, 2> as() const
		{
			static_assert(!std::is_same<CAST, T>::value, "Unnecessary vector cast");
			return Vector<CAST, 2>{ CAST(x), CAST(y) };
		}

		static const Vector<T, 2> identity() { return Vector<T, 2>(1, 1); }
		static const Vector<T, 2> zero() { return Vector<T, 2>(0, 0); }
	};

	///	Vector<T,3>
	///
	///	3D specialization of Vector<>
	///	providing (x,y,z) members.
	template<class T> struct Vector<T,3> : public VectorBase<T, 3, Vector<T, 3>>
	{
		union
		{
			T elements[3];
			struct { T x, y, z; };
			struct { Vector<T, 2> xy; };
		};

		Vector() = default;
		Vector(T const &x, T const &y, T const &z) : x(x), y(y), z(z) {}
		Vector(T const& x, Vector<T, 2> const& yz) : x(x), y(yz.x), z(yz.y) {}
		Vector(Vector<T, 2> const& xy, T const& z) : x(xy.x), y(xy.y), z(z) {}
		Vector(T const& n) : x(n), y(n), z(n) {}

		template<typename CAST>
		inline Vector<CAST, 3> as() const
		{
			static_assert(!std::is_same<CAST, T>::value, "Unnecessary vector cast");
			return Vector<CAST, 3>{ CAST(x), CAST(y), CAST(z) };
		}

		static Vector<T, 3> identity() { return Vector<T, 3>(1, 1, 1); }
		static Vector<T, 3> zero() { return Vector<T, 3>(0, 0, 0); }
	};

	///	Vector<T,4>
	///
	///	4D specialization of Vector<>
	///	providing (x,y,z,w) members.
	template<class T> struct Vector<T,4> : public VectorBase<T, 4, Vector<T, 4>>
	{
		union
		{
			T elements[4];
			struct { T x, y, z, w; };
			struct { Vector<T, 2> xy, zw; };
			struct { Vector<T, 3> xyz; };
		};

		Vector() = default;
		Vector(T const &x, T const &y, T const &z, T const &w) : x(x), y(y), z(z), w(w) {}
		Vector(Vector<T, 2> const& xy, T const& z, T const& w) : x(xy.x), y(xy.y), z(z), w(w) {}
		Vector(T const& x, Vector<T, 2> const& yz, T const &w) : x(x), y(yz.x), z(yz.y), w(w) {}
		Vector(T const& x, T const& y, Vector<T, 2> const& zw) : x(x), y(y), z(zw.x), w(zw.y) {}
		Vector(Vector<T, 2> const& xy, Vector<T, 2> const& zw) : x(xy.x), y(xy.y), z(zw.x), w(zw.y) {}
		Vector(Vector<T, 3> const& xyz, T const& w) : x(xyz.x), y(xyz.y), z(xyz.z), w(w) {}
		Vector(T const& x, Vector<T, 3> const& yzw) : x(x), y(yzw.x), z(yzw.y), w(yzw.z) {}
		Vector(T const& n) : x(n), y(n), z(n), w(n) {}

		template<typename CAST>
		inline Vector<CAST, 4> as() const
		{
			static_assert(!std::is_same<CAST, T>::value, "Unnecessary vector cast");
			return Vector<CAST, 4>{ CAST(x), CAST(y), CAST(z), CAST(w) };
		}

		static const Vector<T, 4> identity() { return Vector<T, 4>(1); }
		static const Vector<T, 4> zero() { return Vector<T, 4>(0); }
	};

	template<class T, int DIM>
	inline Vector<T, DIM + 1> homogenize(Vector<T, DIM> lhs)
	{
		Vector<T, DIM + 1> result;

		for (int i = 0; i < DIM; ++i)
			result.elements[i] = lhs.elements[i];

		result[DIM] = 1;

		return result;
	}

	template<class T, int DIM>
	inline Vector<T, DIM - 1> unHomogenize(Vector<T, DIM> lhs)
	{
		Vector<T, DIM - 1> result;

		for (int i = 0; i < DIM - 1; ++i)
			result.elements[i] = lhs.elements[i];

		return result;
	}

}	///	math
}	///	lucid

///	vector shorthand for the following operator overloads
///
///	note: relies upon push/pop macro pragmas
#pragma push_macro("VECTOR")
#define VECTOR(T,DIM) ::lucid::math::Vector<T,DIM>

///
///
///
template<class T, int DIM> inline VECTOR(T,DIM) operator-(VECTOR(T,DIM) const &rhs)
{
	VECTOR(T,DIM) result;

	result.elements[0] = -rhs.elements[0];
	for (int32_t i = 1; i < DIM; ++i)
	{
		result.elements[i] = -rhs.elements[i];
	}

	return result;
}

///
///
///
template<class T, int DIM> inline VECTOR(T,DIM) operator+(VECTOR(T,DIM) const &lhs, VECTOR(T,DIM) const &rhs)
{
	VECTOR(T,DIM) result;

	result.elements[0] = lhs.elements[0] + rhs.elements[0];
	for (int32_t i = 1; i < DIM; ++i)
	{
		result.elements[i] = lhs.elements[i] + rhs.elements[i];
	}

	return result;
}

///
///
///
template<class T, int DIM> inline VECTOR(T,DIM) operator-(VECTOR(T,DIM) const &lhs, VECTOR(T,DIM) const &rhs)
{
	VECTOR(T,DIM) result;

	result.elements[0] = lhs.elements[0] - rhs.elements[0];
	for (int32_t i = 1; i < DIM; ++i)
	{
		result.elements[i] = lhs.elements[i] - rhs.elements[i];
	}

	return result;
}

///
///
///
template<class T, int DIM> inline VECTOR(T,DIM) operator*(VECTOR(T,DIM) const &lhs, T const &rhs)
{
	VECTOR(T,DIM) result;

	result.elements[0] = lhs.elements[0] * rhs;
	for (int32_t i = 1; i < DIM; ++i)
	{
		result.elements[i] = lhs.elements[i] * rhs;
	}

	return result;
}

///
///
///
template<class T, int DIM> inline VECTOR(T,DIM) operator*(T const &lhs, VECTOR(T,DIM) const &rhs)
{
	VECTOR(T,DIM) result;

	result.elements[0] = lhs * rhs.elements[0];
	for (int32_t i = 1; i < DIM; ++i)
	{
		result.elements[i] = lhs * rhs.elements[i];
	}

	return result;
}

///
///
///
template<class T, int DIM> inline VECTOR(T,DIM) operator/(VECTOR(T,DIM) const &lhs, T const &rhs)
{
	VECTOR(T,DIM) result;

	T const coeff = ::lucid::math::constants::one<T>() / rhs;

	result.elements[0] = coeff * lhs.elements[0];
	for (int32_t i = 1; i < DIM; ++i)
	{
		result.elements[i] = coeff * lhs.elements[i];
	}

	return result;
}

///
///	remove the vector shorthand
///
#undef VECTOR
#pragma pop_macro("VECTOR")

///
///
///
namespace lucid {
namespace math {

	///	dot
	///
	///	dot product
	template<class T, int DIM> inline T dot(Vector<T,DIM> const &lhs, Vector<T,DIM> const &rhs)
	{
		return lhs * rhs;
	}

	///	lenSquared
	///
	///	length squared
	template<class T, int DIM> inline T lenSquared(Vector<T, DIM> const &rhs)
	{
		return dot(rhs, rhs);
	}

	///	len
	///
	///	length
	template<class T, int DIM> inline T len(Vector<T,DIM> const &rhs)
	{
		return rhs.length();
	}

	///	normalize
	///
	///	normalize vector
	template<class T, int DIM> inline Vector<T, DIM> normalize(Vector<T,DIM> const &rhs)
	{
		Vector<T, DIM> normalized(rhs);
		normalized.normalize();
		return normalized;
	}

	///	cross
	///
	///	3D vector cross product
	template<class T> inline Vector<T,3> cross(Vector<T,3> const &lhs, Vector<T,3> const &rhs)
	{
		return Vector<T,3>
		(
			lhs.y * rhs.z - rhs.y * lhs.z,
			rhs.x * lhs.z - lhs.x * rhs.z,
			lhs.x * rhs.y - rhs.x * lhs.y
		);
	}

	/// hadamard
	/// 
	/// Vector elementwise multiplication
	template<class T, int DIM> 
	inline Vector<T, DIM> hadamard(Vector<T, DIM> const& lhs, Vector<T, DIM> const& rhs)
	{
		Vector<T, DIM> toRet;
		for (int i = 0; i < DIM; ++i)
		{
			toRet[i] = lhs[i] * rhs[i];
		}
		return toRet;
	}
	
	// 2D vector 'cross product'
	template<class T> inline T cross(Vector<T, 2> const& lhs, Vector<T, 2> const& rhs)
	{
		return lhs.x * rhs.y - lhs.y * rhs.x;
	}

	// Gets the intersection parameter t of two 2D line segments A and B where t is f(t) = a1(1 - t) + a2(t).
	// nan is returned if there are no/infinitely many intersection points
	template<class T>
	T intersects(Vector<T, 2> a1, Vector<T, 2> a2, Vector<T, 2> b1, Vector<T, 2> b2)
	{
		Vector<T, 2> b = a2 - a1;
		Vector<T, 2> d = b2 - b1;

		T bDotDPerp = b[0] * d[1] - b[1] * d[0];

		// if b dot d == 0, it means the lines are parallel so have infinite intersection points
		if (bDotDPerp == 0)
			return std::numeric_limits<T>::quiet_NaN();

		Vector<T, 2> c = b1 - a1;
		T t = (c[0] * d[1] - c[1] * d[0]) / bDotDPerp;
		if (t < 0 || t > 1)
			return std::numeric_limits<T>::quiet_NaN();

		T u = (c[0] * b[1] - c[1] * b[0]) / bDotDPerp;
		if (u < 0 || u > 1)
			return std::numeric_limits<T>::quiet_NaN();;

		return t;
	}
	
	// Returns the intersection point of two line segments A and B. output parameter will not change if no
	// intersection is found. Return value is true if only one single intersection point is found
	template<class T>
	bool intersection(Vector<T, 2> a1, Vector<T, 2> a2, Vector<T, 2> b1, Vector<T, 2> b2, Vector<T, 2> &intersection)
	{
		Vector<T, 2> b = a2 - a1;
		Vector<T, 2> d = b2 - b1;

		T bDotDPerp = b[0] * d[1] - b[1] * d[0];

		// if b dot d == 0, it means the lines are parallel so have infinite intersection points
		if (bDotDPerp == 0)
			return false;

		Vector<T, 2> c = b1 - a1;
		T t = (c[0] * d[1] - c[1] * d[0]) / bDotDPerp;
		if (t < 0 || t > 1)
			return false;

		T u = (c[0] * b[1] - c[1] * b[0]) / bDotDPerp;
		if (u < 0 || u > 1)
			return false;

		intersection = a1 + t * b;

		return true;
	}

	///	equ and neq
	///
	///	equality tests
	
	template<class T, int DIM> inline bool equWeak(Vector<T, DIM> const& lhs, Vector<T, DIM> const& rhs, T const epsilon = constants::tol_tol<T>())
	{
		return lenSquared(lhs - rhs) <= epsilon;
	}

	template<class T, int DIM> inline bool equ(Vector<T,DIM> const &lhs, Vector<T,DIM> const &rhs)
	{
		return equWeak(lhs, rhs);
	}

	template<class T, int DIM> inline bool operator==(Vector<T,DIM> const &lhs, Vector<T,DIM> const &rhs)
	{
		return equ(lhs, rhs);
	}

	template<>
	inline bool operator==(Vector<uint32_t, 2> const& lhs, Vector<uint32_t, 2> const& rhs)
	{
		return lhs.x == rhs.x &&
			lhs.y == rhs.y;
	}

	template<>
	inline bool operator==(Vector<int32_t, 2> const& lhs, Vector<int32_t, 2> const& rhs)
	{
		return lhs.x == rhs.x &&
			lhs.y == rhs.y;
	}

	template<class T, int DIM> inline bool operator!=(Vector<T,DIM> const &lhs, Vector<T,DIM> const &rhs)
	{
		return !equ(lhs, rhs);
	}

	template<class T, int DIM> inline bool neq(Vector<T,DIM> const &lhs, Vector<T,DIM> const &rhs)
	{
		return !equ(lhs, rhs);
	}

	/// Some more utility functions
	/// 
	///

	template<class T, int DIM> size_t hashCode(Vector<T, DIM> const& lhs)
	{
		size_t result = 17;
		for (int32_t i = 0; i < DIM; ++i)
			result = result * 23 + std::hash<T>{}(lhs.elements[i]);
		return result;
	}

	template<class T, int DIM>
	Vector<T, DIM> minBound(Vector<T, DIM> const& lhs, Vector<T, DIM> const& rhs)
	{
		Vector<T, DIM> result;
		for (int32_t i = 0; i < DIM; ++i)
			result[i] = std::min<T>(lhs.elements[i], rhs.elements[i]);
		return result;
	}

	template<class T, int DIM>
	Vector<T, DIM> maxBound(Vector<T, DIM> const& lhs, Vector<T, DIM> const& rhs)
	{
		Vector<T, DIM> result;
		for (int32_t i = 0; i < DIM; ++i)
			result.elements[i] = std::max<T>(lhs.elements[i], rhs.elements[i]);
		return result;
	}

	template <class T, int DIM>
	lucid::math::Vector<T, DIM> round(lucid::math::Vector<T, DIM> const& rhs)
	{
		lucid::math::Vector<T, DIM> result;
		for (int32_t i = 0; i < DIM; ++i)
		{
			result[i] = std::round(rhs[i]);
		}
		return result;
	}

	template <class T, int DIM>
	bool isNan(Vector<T, DIM> const& lhs)
	{
		for (int32_t i = 0; i < DIM; ++i)
		{
			if (std::isnan(lhs.elements[i]))
			{
				return true;
			}
		}
		return false;
	}

	template <class T, int DIM>
	bool isInf(Vector<T, DIM> const& lhs)
	{
		for (int32_t i = 0; i < DIM; ++i)
		{
			if (std::isinf(lhs.elements[i]))
			{
				return true;
			}
		}
		return false;
	}

	template <class T, int DIM>
	bool isValid(Vector<T, DIM> const& lhs)
	{
		for (int32_t i = 0; i < DIM; ++i)
		{
			if (std::isnan(lhs.elements[i]) || std::isinf(lhs.elements[i]))
			{
				return false;
			}
		}
		return true;
	}

}	/// math
}	///	lucid
namespace std
{
	template <class T, int DIM>
	struct hash<lucid::math::Vector<T, DIM>>
		{
		size_t operator()(const lucid::math::Vector<T, DIM>& k) const
			{
			return lucid::math::hashCode(k);
			}
		};
}

namespace std {

	// For use with Earcut algorithm

	template <size_t _Idx, class _Ty, int _Size>
	struct tuple_element<_Idx, lucid::math::Vector<_Ty, _Size>> {
		static_assert(_Idx < _Size, "vector index out of bounds");

		using type = _Ty;
	};

	template <size_t _Idx, class _Ty, size_t _Size>
	struct tuple_element<_Idx, lucid::math::Vector<_Ty, _Size> &> {
		static_assert(_Idx < _Size, "vector index out of bounds");

		using type = _Ty;
	};

	template <size_t _Idx, class _Ty, size_t _Size>
	constexpr _Ty get(lucid::math::Vector<_Ty, int(_Size)> const &_Vec) noexcept
	{
		static_assert(_Idx < _Size, "vector index out of bounds");
		return _Vec[_Idx];
	}

	template <size_t _Idx, class _Ty, int _Size>
	constexpr _Ty get(lucid::math::Vector<_Ty, _Size> const& _Vec) noexcept
	{
		static_assert(_Idx < _Size, "vector index out of bounds");
		return _Vec[_Idx];
	}
}