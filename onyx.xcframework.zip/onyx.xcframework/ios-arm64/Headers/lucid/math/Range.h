#pragma once

namespace lucid {
namespace math {

	template<class T>
	struct Range
	{
		T begin;
		T end;

		inline bool intersects(Range<T> rhs) const
		{
			return !(end <= rhs.begin || begin >= rhs.end);
		}

		inline bool contains(T x, bool closed = true) const
		{
			return (closed) ? begin <= x && x <= end : begin < x && x < end;
		}

		inline bool circularContains(T theta, bool closed = true) const
		{
			if (begin <= end)
			{
				return contains(theta, closed);
			}
			else
			{
				return !Range<T>{end, begin}.contains(theta, !closed);
			}
		}

		Range() { };

		Range(T begin_, T end_)
		{
			begin = begin_;
			end = end_;
		}

		inline bool empty() const
		{
			return begin >= end;
		}

		inline Range operator*(T rhs)
		{
			return Range{ begin * rhs, end * rhs };
		}

	};

	template<class T>
	inline bool operator==(Range<T> const& lhs, Range<T> const& rhs)
	{
		return lhs.begin == rhs.begin &&
				lhs.end == rhs.end;
	}

	template<class T>
	inline bool operator!=(Range<T> const& lhs, Range<T> const& rhs)
	{
		return !(lhs == rhs);
	}

	// Calculate the distance between [minA, maxA] and [minB, maxB]
	// The distance will be negative if the intervals overlap
	template<class T>
	inline float distance(Range<T> a, Range<T> b)
		{
		if (a.begin < b.begin)
			return b.begin - a.end;
		else
			return a.begin - b.end;
		}

} // math
} // lucid