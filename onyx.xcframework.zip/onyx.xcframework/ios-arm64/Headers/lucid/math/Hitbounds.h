#pragma once
#include "Polygon.h"
#include <unordered_set>
#include <vector>

namespace lucid {
namespace math {
    template <class T, int DIM>
    class HitBounds
        {
		private:
			struct AxisProjection
				{
				lucid::math::Vector<T, DIM> axis;
				lucid::math::Range<T> projected;
				};

			Polygon<T, DIM> _polygon;
			std::unordered_set<lucid::math::Vector<T, DIM>> _edgeAxes;
			std::vector<AxisProjection> _projections;

		public:
			HitBounds()
				{

				}

			HitBounds(Polygon<T, DIM> const & source)
				{
				refresh(source);
				}

			void refresh(Polygon<T, DIM> const& source)
				{
				_polygon = source;
				_edgeAxes.clear();
				_projections.clear();

				for (size_t edgeIndex = 0; edgeIndex < _polygon.size(); edgeIndex++)
					{
					AxisProjection proj;
					auto segment = _polygon.edge(edgeIndex);

					auto edge = (segment.start - segment.end);

					// ===== 1. Find if the polygons are currently intersecting =====

					// Find the axis perpendicular to the current edge
					Vector<T, DIM> axis(-edge.y, edge.x);
					proj.axis = normalize(axis);

					if (proj.axis.x < 0)
						proj.axis = proj.axis * (T)-1;
					else if (proj.axis.x == 0)
						{
						proj.axis.x = 0; // Remove signed zeroes
						proj.axis.y = std::abs(proj.axis.y);
						}
					if (proj.axis.y == -0)
						proj.axis.y = 0;

					if (_edgeAxes.find(proj.axis) != _edgeAxes.end())
						continue;

					_edgeAxes.insert(proj.axis);

					// Find the projection of the polygon on the current axis
					proj.projected = project(proj.axis, _polygon);
					_projections.push_back(proj);
					}

				}

			Polygon<T, DIM> const& polygon() const
				{
				return _polygon;
				}

			AABB<T, DIM> aabb() const { return AABB<T, DIM>(_polygon.aabb()); }

			__inline PolygonCollisionResult<T, DIM> willCollide(HitBounds<T, DIM> const& other, Vector<T, DIM> const& velocity) const
				{
				PolygonCollisionResult<T, DIM> result;
				auto aabbA = _polygon.aabb().pushBounds(velocity);
				auto aabbB = other._polygon.aabb();
				if (intersects(aabbA, aabbB) == Intersections::NONE)
					{
					result.doIntersect = false;
					result.willIntersect = false;
					return result;
					}

				result.doIntersect = true;
				result.willIntersect = true;

				int edgeCountA = _projections.size();
				int edgeCountB = other._projections.size();
				T minIntervalDistance = constants::pos_inf<T>();

				Vector<T, DIM> translationAxis;
				LineSegment<T, DIM> segment;
				Vector<T, DIM> axis;
				Range<T> rangeA, rangeB;

				// Loop through all the edges of both polygons
				for (int axisIndex = 0; axisIndex < edgeCountA + edgeCountB; axisIndex++)
					{
					if (axisIndex < edgeCountA)
						{
						auto proj = _projections[axisIndex];
						axis = proj.axis;
						rangeA = proj.projected;
						rangeB = project(axis, other._polygon);
						}
					else
						{
						auto proj = other._projections[axisIndex - edgeCountA];
						
						axis = proj.axis;
						rangeA = project(axis, _polygon);
						rangeB = proj.projected;
						}

					// ===== 1. Find if the polygons are currently intersecting =====

					// Check if the polygon projections are currentlty intersecting
					if (distance(rangeA, rangeB) > 0)
						result.doIntersect = false;

					// ===== 2. Now find if the polygons *will* intersect =====

					// Project the velocity on the current axis
					T velocityProjection = dot(axis, velocity);

					// Get the projection of polygon A during the movement
					if (velocityProjection < 0)
						rangeA.begin += velocityProjection;
					else
						rangeA.end += velocityProjection;

					// Do the same test as above for the new projection
					T intervalDistance = distance(rangeA, rangeB);
					if (intervalDistance > 0) result.willIntersect = false;

					// If the polygons are not intersecting and won't intersect, exit the loop
					if (!(result.doIntersect || result.willIntersect)) break;

					// Check if the current interval distance is the minimum one. If so store
					// the interval distance and the current distance.
					// This will be used to calculate the minimum translation vector
					intervalDistance = std::abs(intervalDistance);
					if (intervalDistance < minIntervalDistance) {
						minIntervalDistance = intervalDistance;
						translationAxis = axis;

						auto d = aabb().center() - other.aabb().center();
						if (dot(d, translationAxis) < 0)
							translationAxis = -translationAxis;
						}
					}

				// The minimum translation vector
				// can be used to push the polygons appart.
				if (result.willIntersect)
					result.minimumTranslationVector =
					translationAxis * minIntervalDistance;

				return result;
				}
        };

		typedef HitBounds<float32_t, 2> HitBounds2d;
		typedef HitBounds<float32_t, 3> HitBounds3d;
} }