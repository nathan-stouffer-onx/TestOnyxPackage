#pragma once

#include <vector>

#include "Vector.h"
#include "Constants.h"

#ifdef min
#	undef min
#	undef max
#endif

namespace lucid {
namespace math {

	enum Intersections
	{
		NONE = 0,
		PARTIAL = 1,
		FULL = 2
	};

	template<class T, int DIM> struct AABB;
	template<class T, int DIM> inline bool contains(AABB<T, DIM> const& box, Vector<T, DIM> const& point);

	///
	///
	///
	template<class T, int DIM> struct AABB
	{
		Vector<T, DIM> min = Vector<T, DIM>();
		Vector<T, DIM> max = Vector<T, DIM>();

		AABB()
		{
			auto maxVal = std::numeric_limits<T>::max();
			auto lowestVal = std::numeric_limits<T>::lowest();

			for (int i = 0; i < DIM; ++i)
			{
				min[i] = maxVal;
				max[i] = lowestVal;
			}
		}

		AABB(Vector<T, DIM> const & _min, Vector<T, DIM> const & _max)
			: min(_min)
			, max(_max)
		{
		}

		AABB(Vector<T, DIM> const& _min, T len)
			: min(_min)
			, max(_min)
		{
			for (int i = 0; i < DIM; ++i)
			{
				max[i] += len;
			}
		}

		static AABB unit()
		{
			return AABB{ Vector<T, DIM>::zero(), Vector<T, DIM>::identity() };
		}

		inline static AABB everything()
		{
			AABB toRet{};
			auto max = std::numeric_limits<T>::max();
			auto lowest = std::numeric_limits<T>::lowest();

			for (int i = 0; i < DIM; ++i)
			{
				toRet.min[i] = lowest;
				toRet.max[i] = max;
			}
			return toRet;
		}

		inline static AABB nothing()
		{
			AABB toRet{};
			auto max = std::numeric_limits<T>::max();
			auto lowest = std::numeric_limits<T>::lowest();

			for (int i = 0; i < DIM; ++i)
			{
				toRet.min[i] = max;
				toRet.max[i] = lowest;
			}
			return toRet;
		}

		inline constexpr int VERTEX_COUNT() const { return  1 << DIM; };
		
		/**
		   6----7
		  /|   /|
		 2----3 |
		 | 4--|-5
		 |    |/
		 0----1
		 -------
		 0 is min
		 3 is max for 2D, 7 is max for 3d
		 */
		Vector<T, DIM> vertex(int index) const
		{
			Vector<T, DIM> result = min;
			for (int i = 0; i < DIM; ++i)
			{
				if ((index & (1 << i)) != 0)
				{
					result[i] = max[i];
				}
			}
			
			return result;
		}

		Vector<T, DIM> center() const
		{
			return constants::half<T>() * (max + min);
		}

		Vector<T, DIM> extent() const
		{
			return constants::half<T>() * (max - min);
		}

		Vector<T, DIM> length() const
		{
			return (max - min);
		}

		template<class convertT>
		AABB<convertT, DIM> as() const
		{
			return {
				min.template as<convertT>(),
				max.template as<convertT>()
			};
		}
		
		T area() const
		{
			return generalVolume();
		}

		// Returns volume of an n-dim AABB(area for 2D)
		T generalVolume() const
		{
			auto len = length();
			T result = len[0];
			for (int i = 1; i < DIM; ++i)
			{
				result *= len[i];
			}
			
			return result;
		}

		T length(int dimension) const
		{
			return max[dimension] - min[dimension];
		}

		__inline bool contains(Vector<T, DIM> const &vertex) const
		{
			return ::lucid::math::contains(*this, vertex);
		}

		template<class Intersector>
		__inline Intersections intersects(Intersector const & rhs) const;

		AABB<T, DIM> fit(Vector<T, DIM> point)
		{
			AABB<T, DIM> result = *this;
			for (int i = 0; i < DIM; ++i)
			{
				result.max[i] = std::max(point[i], result.max[i]);
				result.min[i] = std::min(point[i], result.min[i]);
			}
			return result;
		}

		// Lengthens box boundaries per vector component, if vector component
		// is positive, then adds to maximum. Otherwise subtracts from
		// minimum
		AABB<T, DIM> pushBounds(Vector<T, DIM> direction) const
		{
			AABB<T, DIM> result = *this;
			for (int i = 0; i < DIM; ++i)
			{
				if (direction[i] > 0)
					result.max[i] += direction[i];
				else
					result.min[i] += direction[i];
			}
			return result;
		}
	};
	
	///	fit
	///
	///	expand the given box to include the specified point. Will not shrink the bounding box
	template<class T, int DIM> inline void fit(AABB<T, DIM> &box, Vector<T, DIM> const &point)
	{
		for (int i = 0; i < DIM; ++i)
		{
			box.min[i] = std::min(box.min[i], point[i]);
			box.max[i] = std::max(box.max[i], point[i]);
		}
	}

	/// fit
	///
	/// function to construct a bounding box from a collection of points
	template<template<class, class...> class ContainerT, class T, int DIM, class... Additional>
	inline AABB<T, DIM> fit(ContainerT<Vector<T, DIM>, Additional...> const& points)
	{
		AABB<T, DIM> box = AABB<T, DIM>::nothing();
		for (Vector<T, DIM> const& point : points)
		{
			fit(box, point);
		}
		return box;
	}

	///	fit
	///
	///	convienience method for creating a box which fits a triangle.
	template<class T, int DIM> inline AABB<T, DIM> fit(Vector<T, DIM> const &v_i, Vector<T, DIM> const &v_j, Vector<T, DIM> const &v_k)
	{
		AABB<T, DIM> box;

		fit(box, v_i);
		fit(box, v_j);
		fit(box, v_k);

		return box;
	}

	/// fit
	///
	/// return box that most tightly fits the given boxes. For nothing-boxes (min is greater than max)), this will return
	/// the other box that is not a nothing-box, or the "smallest" nothing box if no such box exists
	template<class T, int DIM> inline AABB<T, DIM> fit(AABB<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		return {
			lucid::math::minBound(lhs.min, rhs.min),
			lucid::math::maxBound(lhs.max, rhs.max)
		};
	}

	/// fit
	///
	/// return box that most tightly fits the given collection boxes
	template<template<class, class...> class ContainerT, class T, int DIM, class... Additional>
	inline AABB<T, DIM> fit(ContainerT<AABB<T, DIM>, Additional...> const& rhs)
	{
		AABB<T, DIM> aabb = AABB<T, DIM>::nothing();
		for (AABB<T, DIM> const& box : rhs)
		{
			aabb = fit(aabb, box);
		}
		return aabb;
	}

	///	contains
	///
	/// Given an AABB, create the tightest box that contains both the box and point
	template<class T, int DIM> inline bool contains(AABB<T, DIM> const &box, Vector<T, DIM> const &point)
	{
		for (int i = 0; i < DIM; ++i)
			if ((point[i] < box.min[i]) || (box.max[i] < point[i]))
				return false;

		return true;
	}

	/// looselyContains
	///
	///
	template<class T, int DIM> inline bool looselyContains(AABB<T, DIM> const &box, Vector<T, DIM> const &v_i, Vector<T, DIM> const &v_j, Vector<T, DIM> const &v_k)
	{
		AABB<T, DIM> faceBox = fit(v_i, v_j, v_k);
		Vector<T, DIM> faceCenter = faceBox.center();

		if (!contains(box, faceCenter))
			return false;

		Vector<T, DIM> faceExtent = faceBox.extent();
		Vector<T, DIM> boxExtent = box.extent();

		for (int i = 0; i < DIM; ++i)
			if (faceExtent[i] > boxExtent[i])
				return false;

		return true;
	}

	///
	///
	///
	template<class T, int DIM> inline bool contains(AABB<T, DIM> const &lhs, AABB<T, DIM> const &rhs)
	{
		for (int i = 0; i < DIM; ++i)
			if (lhs.min[i] > rhs.min[i] || rhs.max[i] > lhs.max[i])
				return false;
		
		return true;
	}

	template<class T, int DIM> inline bool looselyContains(AABB<T, DIM> const &lhs, AABB<T, DIM> const &rhs)
	{
		if (!contains(lhs, rhs.center()))
			return false;

		Vector<T, DIM> lhsExtent = lhs.extent();
		Vector<T, DIM> rhsExtent = rhs.extent();

		for (int i = 0; i < DIM; ++i)
			if (rhsExtent[i] > lhsExtent[i])
				return false;

		return true;
	}

	template<class T, int DIM> inline bool looselyContains(Vector<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		for (int i = 0; i < DIM; ++i)
			if (lhs[i] >= rhs.max[i] || lhs[i] <= rhs.min[i])
				return false;
		return true;
	}

	template<class T, int DIM> inline bool intersectsOrTouches(AABB<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		for (int i = 0; i < DIM; ++i)
			if (lhs.min[i] > rhs.max[i] || lhs.max[i] < rhs.min[i])
				return false;
		return true;
	}

	template<class T, int DIM> __inline Intersections intersects(AABB<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		for (int i = 0; i < DIM; ++i)
			if (lhs.min[i] >= rhs.max[i] || lhs.max[i] <= rhs.min[i])
				return Intersections::NONE;

		for (int i = 0; i < DIM; ++i)
			if (rhs.min[i] < lhs.min[i] || rhs.max[i] > lhs.max[i])
				return Intersections::PARTIAL;

		return Intersections::FULL;
	}

	template<class T, int DIM> __inline Intersections intersects(Vector<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		for (int i = 0; i < DIM; ++i)
			if (lhs[i] >= rhs.max[i] || lhs[i] <= rhs.min[i])
				return Intersections::NONE;

		return Intersections::FULL;
	}

	template<class T, int DIM> __inline Intersections intersects(void* const &/*rhs*/, AABB<T, DIM> const& /*lhs*/)
	{
		return Intersections::NONE;
	}

	template<class T, int DIM>
	template<class Intersector>
	__inline Intersections AABB<T, DIM>::intersects(Intersector const &rhs) const
	{
		return lucid::math::intersects(*this, rhs);
	};

	template<class T, int DIM> inline bool operator==(AABB<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		return lhs.min == rhs.min && lhs.max == rhs.max;
	}

	template<class T, int DIM> inline bool operator!=(AABB<T, DIM> const& lhs, AABB<T, DIM> const& rhs)
	{
		return lhs.min != rhs.min || lhs.max != rhs.max;
	}

	template<class T, int DIM>
	inline bool equWeak(AABB<T, DIM> lhs, AABB<T, DIM> rhs, T const epsilon =  constants::tol_tol<T>())
	{
		return equWeak(lhs.min, rhs.min, epsilon) && equWeak(lhs.max, rhs.max, epsilon);
	}

	template<class T, int DIM>
	inline bool equ(AABB<T, DIM> lhs, AABB<T, DIM> rhs)
	{
		return equ(lhs.min, rhs.min) && equ(lhs.max, rhs.max);
	}

	template<class T>
	inline std::array<Vector<T, 2>, 4> clockwise(AABB<T, 2> rhs)
	{
		return
		{
			Vector<T, 2>{ rhs.min.x, rhs.min.y },
			Vector<T, 2>{ rhs.min.x, rhs.max.y },
			Vector<T, 2>{ rhs.max.x, rhs.max.y },
			Vector<T, 2>{ rhs.max.x, rhs.min.y },
		};
	}

}	///	math
}	///	lucid
