#pragma once
#include "Vector.h"
#include "AABB.h"

#include <algorithm>
#include <vector>

namespace lucid {
namespace math {

	///
	///
	///
	template<class T, int DIM> struct LineSegment
	{
		typedef Vector<T, DIM> vec;
		vec start = vec();
		vec end = vec();

		LineSegment() { }

		LineSegment(vec p1, vec p2)
			: start(p1)
			, end(p2)
		{

		}

		inline vec direction() const { return end - start; }

		inline T length() const { return lucid::math::len(direction()); }

		T distanceSquaredTo(vec const& point) const
		{
			vec dir = direction();
			T l2 = lenSquared(dir);
			vec startDir = point - start;
			T t = std::clamp(dot(dir, startDir) / l2, T(0.0), T(1.0));
			vec projection = start + t * dir;  // Projection falls on the segment
			return lenSquared(point - projection);
		}

		inline T distanceTo(vec const& point) const { return std::sqrt(distanceSquaredTo(point)); }
		
		template <class Intersector>
		inline lucid::math::Intersections intersects(Intersector const & shape) const;

		vec position(T t)
		{
			auto dir = direction();
			auto dirScale = t / length();
			return start + (dir * dirScale);
		}

		bool operator==(LineSegment const& rhs) const
		{
			return start == rhs.start && end == rhs.end;
		}

		bool operator!=(LineSegment const& rhs) const
		{
			return !((*this) == rhs);
		}

	};

	template<class T, int DIM>
	bool equ(LineSegment<T, DIM> const& lhs, LineSegment<T, DIM> const& rhs)
	{
		return (equ(lhs.start, rhs.start) && equ(lhs.end, rhs.end))
			|| (equ(lhs.end, rhs.start) && equ(lhs.end, rhs.start));
	}

	template<class T, int DIM> inline bool operator==(LineSegment<T, DIM> const& lhs, LineSegment<T, DIM> const& rhs)
		{
		return lhs.start == rhs.start &&
			lhs.end == rhs.end;
		}

	template <class T>
	T intersects(LineSegment<T, 2> const &lhs, LineSegment<T, 2> const & rhs)
	{
		return intersects(lhs.start, lhs.end, rhs.start, rhs.end);
	}


	// Compute x-value of point of intersection of two lines
	template <class T>
	T x_intersect(LineSegment<T, 2> const &p1, LineSegment<T, 2> const& p2)
	{
		T num = (p1.start.x * p1.end.y - p1.start.y * p1.end.x) * (p2.start.x - p2.end.x) -
			(p1.start.x - p1.end.x) * (p2.start.x * p2.end.y - p2.start.y * p2.end.x);

		T den = (p1.start.x - p1.end.x) * (p2.start.y - p2.end.y) - (p1.start.y - p1.end.y) * (p2.start.x - p2.end.x);
		
		return num / den;
	}

	// Compute y-value of point of intersection of two lines
	template <class T>
	T y_intersect(LineSegment<T, 2> const& p1, LineSegment<T, 2> const& p2)
	{
		if (p1.start.y == p1.end.y) // Check for vertical lines
		{
			if (p2.start.y == p2.end.y)
			{
				return constants::neg_inf<T>();
			}
			return p1.start.y;
		}
		else if (p2.start.y == p2.end.y)
		{
			return p2.start.y;
		}

		T num = (p1.start.x	* p1.end.y	- p1.start.y	* p1.end.x) * (p2.start.y	- p2.end.y) -
			(p1.start.y	- p1.end.y) * (p2.start.x	* p2.end.y	- p2.start.y	* p2.end.x);
		T den = (p1.start.x	- p1.end.x) * (p2.start.y	- p2.end.y) - (p1.start.y	- p1.end.y) * (p2.start.x	- p2.end.x);

		return num / den;
	}
	template <class T>
	T sideRelativeTo(LineSegment<T, 2> const& edge, Vector<T, 2> position)
	{
		auto dir = edge.end - edge.start;
		return dir.x * (position.y - edge.start.y) - dir.y * (position.x - edge.start.x);
	}

	// Cohen-Sutherland line clipping algorithm
	template <class T>
	uint32_t regionCode(AABB<T, 2> const& box, Vector<T, 2> v)
	{
		uint32_t result = 0;

		if (v.y < box.min.y)
			result |= 1;

		if (v.y > box.max.y)
			result |= 2;

		if (v.x < box.min.x)
			result |= 4;

		if (v.x > box.max.x)
			result |= 8;

		return result;
	}

	template <class T>
	Intersections intersects(AABB<T, 2> const& bounds, LineSegment<T, 2> const& segment)
	{
		uint32_t p1Bits = regionCode(bounds, segment.start),
				p2Bits = regionCode(bounds, segment.end);

		if ((p1Bits | p2Bits) == 0)
			return Intersections::FULL;

		if ((p1Bits & p2Bits) != 0)
			return Intersections::NONE;

		return Intersections::PARTIAL;
	}

	template<class T>
	LineSegment<T, 2> clip(AABB<T, 2> const& bounds, LineSegment<T, 2> const& segment)
	{
		uint32_t p1Bits = regionCode(bounds, segment.start),
			p2Bits = regionCode(bounds, segment.end);

		if ((p1Bits | p2Bits) == 0)
			return segment;

		auto mask = p1Bits & p2Bits;
		if (mask != 0)
			return { bounds.min, bounds.min };

		auto result = segment;

		if (segment.end.x == segment.start.x || segment.end.y == segment.start.y) // Horizontal/vertical line
		{
			return { { std::max(std::min(segment.start.x, bounds.max.x), bounds.min.x), std::max(std::min(segment.start.y, bounds.max.y), bounds.min.y) },
					{ std::max(std::min(segment.end.x, bounds.max.x), bounds.min.x), std::max(std::min(segment.end.y, bounds.max.y), bounds.min.y) }
			};
		}

		T m = (segment.end.y - segment.start.y) / (segment.end.x - segment.start.x);
		T invM = constants::one<T>() / m;
		// 4 is the maximum number of times that this loop should ever need to run. the official algorithm uses while (true) but we have found cases where
		// that results in an infinite loop because of floating point precision
		for (size_t i = 0; i < 4; ++i)
		{
			auto codeBits = p1Bits != 0 ? p1Bits : p2Bits;
			T newX,
				newY;
			if ((codeBits & 1) != 0) // line intersects with -y boundary
			{
				newX = segment.start.x + (invM * (bounds.min.y - segment.start.y));
				newY = bounds.min.y;
			}
			else if ((codeBits & 2) != 0) // Line intersects with +y boundary
			{
				newX = segment.start.x + (invM * (bounds.max.y - segment.start.y));
				newY = bounds.max.y;
			}
			else if ((codeBits & 4) != 0) // Line intersects with -x boundary
			{
				newY = segment.start.y + (m * (bounds.min.x - segment.start.x));
				newX = bounds.min.x;
			}
			else if ((codeBits & 8) != 0) // Line intersects with +x boundary
			{
				newY = segment.start.y + (m * (bounds.max.x - segment.start.x));
				newX = bounds.max.x;
			}

			if (codeBits == p1Bits)
			{
				result.start = { newX, newY };
				p1Bits = regionCode(bounds, result.start);
			}
			else
			{
				result.end = { newX, newY };
				p2Bits = regionCode(bounds, result.end);
			}

			if ((p1Bits | p2Bits) == 0)
				return result;

			mask = p1Bits & p2Bits;
			if (mask != 0)
				return { bounds.min, bounds.min };
		}
		return { bounds.min, bounds.min };
	}

	template<class T, int DIM>
	template<class Intersector>
	__inline Intersections LineSegment<T, DIM>::intersects(Intersector const &rhs) const
	{
		return lucid::math::intersects(rhs, *this);
	};

	typedef LineSegment<float32_t, 2> LineSegment2d;
	typedef LineSegment<float32_t, 3> LineSegment3d;

}
}
