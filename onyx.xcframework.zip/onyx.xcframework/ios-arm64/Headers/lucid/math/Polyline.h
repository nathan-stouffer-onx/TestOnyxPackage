#pragma once

#include "AABB.h"
#include "Matrix.h"
#include "Vector.h"

namespace lucid {
namespace math {

	template<class T, int DIM>
	class Polyline
	{
	public:
		typedef Vector<T, DIM> vecT;
		typedef AABB<T, DIM> aabbT;
		typedef vecT value_type; // for earcut algorithm
	private:

		std::vector<vecT>	_points;
		aabbT				_aabb = AABB<T, DIM>::nothing();

	public:

		Polyline() { }
		Polyline(std::vector<vecT> const& points)
		{
			_points.reserve(points.size());
			for (auto const& p : points)
			{
				add(p);
			}
		}

		template<class Iter>
		inline void append(Iter const& begin, Iter const& end)
		{
			for (auto curr = begin; curr != end; ++curr)
			{
				add(*curr);
			}
		}

		inline void reserve(size_t size) { _points.reserve(size); }
		inline bool empty() const { return _points.size() < 2; }
		inline size_t size() const { auto count = _points.size(); if (count < 2) return 0; return count; }
		inline size_t byteCount() const { return vecT::byteCount() * _points.capacity(); }
		inline void add(vecT point)
		{
			if (!_points.empty())
			{
				if (point == _points.back())
				{
					return;
				}
			}
			_points.push_back(point);
			fit(_aabb, point);
		}

		inline void set(size_t index, vecT point)
		{
			_points[index] = point;

			_aabb = AABB<T, DIM>::nothing();
			for (auto const& p : _points)
			{
				fit(_aabb, p);
			}
		}

		inline vecT const& back() const { return _points.back(); }
		inline std::vector<vecT> const& points() const { return _points; }

		inline void clear() { _points.clear(); _aabb = AABB<T, DIM>::nothing(); }
		inline LineSegment<T, DIM> edge(size_t index) const
		{
			assert(index + 1 < _points.size());
			auto i2 = index + 1;

			return LineSegment<T, DIM>(_points[index], _points[i2]);
		}
		inline vecT vertex(size_t index) const
		{
			return _points[index];
		}

		inline aabbT aabb() const { return _aabb; }

		inline vecT operator[] (size_t index) const { assert(index < _points.size()); return _points[index]; }

		T length() const
		{
			T len = T(0.0);
			for (size_t i = 0; i + 1 < _points.size(); i++)
			{
				len += lucid::math::len(_points[i + 1] - _points[i]);
			}
			return len;
		}

		T distanceTo(vecT const& point) const
		{
			T dist = std::numeric_limits<T>::max();
			for (size_t i = 0; i + 1 < _points.size(); i++)
			{
				LineSegment<T, DIM> e = edge(i);
				dist = std::min(dist, e.distanceTo(point));
			}
			return dist;
		}

		vecT interpolate(T t) const
		{
			if (t <= T(0.0))
			{
				return _points[0];
			}
			else if (T(0.0) < t && t < T(1.0) && _points.size() > 1)
			{
				T len = length();
				T target = t * len;
				T traveled = 0.0f;
				for (size_t i = 0; i < _points.size(); i++)
				{
					T increase = lucid::math::len(_points[i + 1] - _points[i]);
					traveled += increase;
					if (target < traveled)
					{
						vecT const& a = _points[i];						// point preceding target
						vecT const& b = _points[i + 1];					// point following target

						T overshot = traveled - target;					// how much we overshot the target
						vecT dir = lucid::math::normalize(a - b);		// direction to target from b
						vecT offset = overshot * dir;					// offset vector from b to the target
						vecT point = b + offset;						// point at the target distance
						return point;
					}
				}

				// made it through the whole line, return the last point -- this should never be reached anyway
				return _points.back();
			}
			else
			{
				return _points.back();
			}
		}

		void translate(vecT const& translation) 
		{
			for (auto& point : _points)
			{
				point += translation;
			}

			_aabb.min += translation;
			_aabb.max += translation;
		}
		
		void scale(T const& scale)
		{
			for (auto& point : _points)
			{
				for (int i = 0; i < DIM; ++i)
					point[i] *= scale;
			}

			for (int i = 0; i < DIM; ++i)
			{
				_aabb.min[i] *= scale;
				_aabb.max[i] *= scale;
			}
		}

		void scale(vecT const& scale)
		{
			for (auto& point : _points)
			{
				for (int i = 0; i < DIM; ++i)
					point[i] *= scale[i];
			}

			for (int i = 0; i < DIM; ++i)
			{
				_aabb.min[i] *= scale[i];
				_aabb.max[i] *= scale[i];
			}
		}

		void transform(Matrix<T, DIM + 1, DIM + 1> const& transformation) 
		{
			_aabb = AABB<T, DIM>::nothing();
			for (auto& point : _points)
			{
				auto transformed = transformation * lucid::math::homogenize(point);
				point = lucid::math::unHomogenize(transformed);
				fit(_aabb, point);
			}
		}

	};

	template<class T, int DIM>
	inline bool operator==(Polyline<T, DIM> const& lhs, Polyline<T, DIM> const& rhs)
	{
		using PointsVecT = std::vector<typename Polyline<T, DIM>::vecT>;

		// grab const references to each vector of points
		PointsVecT const& lPoints = lhs.points();
		PointsVecT const& rPoints = rhs.points();

		// check that the sizes are equal
		if (lPoints.size() != rPoints.size())
		{
			return false;
		}

		// check that each point equals the other
		for (size_t i = 0; i < lPoints.size(); ++i)
		{
			if (lPoints[i] != rPoints[i])
			{
				return false;
			}
		}

		// made it through all points, return true
		return true;
	}

	template<class T, int DIM>
	inline bool operator!=(Polyline<T, DIM> const& lhs, Polyline<T, DIM> const& rhs)
	{
		return !(lhs == rhs);
	}

	// convencience fit function for a collection of Polylines. must be used like fit<ContainterType>
	template<template<class, class...> class ContainerT, class T, int DIM, class... Additional>
	inline AABB<T, DIM> fit(ContainerT<Polyline<T, DIM>, Additional...> const& container)
	{
		AABB<T, DIM> box = AABB<T, DIM>::nothing();
		for (Polyline<T, DIM> const& polyline : container)
		{
			box = fit(box, polyline.aabb());
		}
		return box;
	}

	template<class T>
	inline std::vector<std::vector<Vector<T, 2>>> clip(std::vector<Vector<T, 2>> const& polyline, AABB<T, 2> const& bounds)
	{
		using PolyVector = std::vector<Vector<T, 2>>;
		std::vector<PolyVector> result;
		
		PolyVector subPolyline;
		for (size_t i = 0; i + 1 < polyline.size(); ++i)	// iterate over the line segments defining this polyline
		{
			// grab and clip this line segment
			LineSegment<T, 2> segment = { polyline[i], polyline[i + 1] };
			LineSegment<T, 2> clipped = clip(bounds, segment);
			if (clipped.start != clipped.end)		// check if the clipped segment was in the bounds
			{
				if (subPolyline.empty())			// subPolyline is empty, add both points in the segment
				{
					subPolyline.push_back(clipped.start);
					subPolyline.push_back(clipped.end);
				}
				else if (subPolyline.back() == clipped.start)	// case where we add a point to the subPolyline
				{
					subPolyline.push_back(clipped.end);
				}
				else	// this segment is part of a new subPolyline. add the existing subPolyline and start a new one
				{
					// add the existing subPolyline
					result.push_back(subPolyline);

					// start a new subPolyline
					subPolyline.clear();
					subPolyline.push_back(clipped.start);
					subPolyline.push_back(clipped.end);
				}
			}
			else if (!subPolyline.empty())
			{
				result.push_back(subPolyline);
				subPolyline.clear();
			}
		}

		if (!subPolyline.empty())	// check for case where the final point of the line was in the bounds
		{
			result.push_back(subPolyline);
		}

		return result;
	}

	template<class T>
	inline std::vector<Polyline<T, 2>> clip(Polyline<T, 2> const& polyline, AABB<T, 2> const& bounds)
	{
		// clip the polyline
		std::vector<std::vector<Vector<T, 2>>> raw = clip(polyline.points(), bounds);

		// copy raw points into polylines
		std::vector<Polyline<T, 2>> polylines;
		polylines.reserve(raw.size());
		for (std::vector<Vector<T, 2>> const& points : raw)
		{
			polylines.push_back(Polyline<T, 2>{ points });
		}

		return polylines;
	}

	template<class T>
	inline bool intersects(std::vector<Vector<T, 2>> const& vertices, AABB<T, 2> const& bounds)
	{
		for (size_t i = 0; i + 1 < vertices.size(); ++i)	// iterate over the line segments defining this polyline
		{
			// grab and clip this line segment
			LineSegment<T, 2> segment = { vertices[i], vertices[i + 1] };
			LineSegment<T, 2> clipped = clip(bounds, segment);
			if (clipped.start != clipped.end)		// check if the clipped segment was in the bounds
			{
				return true;
			}
		}
		return false;
	}

	template<class T>
	inline bool intersects(Polyline<T, 2> const& polyline, AABB<T, 2> const& bounds)
	{
		return (intersectsOrTouches(bounds, polyline.aabb())) ? intersects(polyline.points(), bounds) : false;
	}

}	///	math
}	///	lucid