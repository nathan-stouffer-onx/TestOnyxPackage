#pragma once

#include <vector>

#include "Polygon.h"

namespace lucid {
namespace math {

	template<typename T>
	bool contains(Polygon<T> const& hull, std::vector<Polygon<T>> const& holes, Vector<T, 2> const& query)
	{
		if (hull.aabb().contains(query))
		{
			// check if a hole contains the centroid
			for (Polygon<T> const& hole : holes)
			{
				if (hole.contains(query)) { return false; }
			}

			// otherwise, fallback to just querying the hull
			return hull.contains(query);
		}
		else
		{
			return false;
		}
	}

	template<class T>
	class Holygon
	{
	public:

		typedef Vector<T, 2> vecT;
		typedef AABB<T, 2> aabbT;

	private:

		Polygon<T>				_hull;
		std::vector<Polygon<T>>	_holes;

	public:

		Holygon() {}
		Holygon(Polygon<T> const& hull) : _hull(hull) {}
		Holygon(Polygon<T> const& hull, std::vector<Polygon<T>> const& holes) :
			_hull(hull),
			_holes(holes)
		{}

		inline bool empty() const { return _hull.empty(); }

		inline Polygon<T> const& hull() const { return _hull; }
		inline std::vector<Polygon<T>> const& holes() const { return _holes; }

		inline aabbT aabb() const { return _hull.aabb(); }

		inline size_t byteCount() const
		{
			size_t count = _hull.byteCount();
			for (Polygon<T> const& hole : _holes)
			{
				count += hole.byteCount();
			}
			return count;
		}

		T area() const
		{
			T area = _hull.area();
			for (Polygon<T> hole : _holes)
			{
				area -= hole.area();
			}
			return area;
		}

		bool contains(Vector<T, 2> const& point) const
		{
			if (_hull.contains(point))
			{
				for (Polygon<T> const& hole : _holes)
				{
					// if a hole contains the point; return false
					if (hole.distanceTo(point) < 0.0)
					{
						return false;
					}
				}

				// point is in the hull but not in any holes; return true
				return true;
			}

			// the outside hull does not contain the point; return false
			return false;
		}

		void translate(vecT translation)
		{
			_hull.translate(translation);
			for (auto& hole : _holes)
			{
				hole.translate(translation);
			}
		}

		void scale(vecT scalars)
		{
			_hull.scale(scalars);
			for (auto& hole : _holes)
			{
				hole.scale(scalars);
			}
		}

		void scale(T scalar)
		{
			_hull.scale(scalar);
			for (auto& hole : _holes)
			{
				hole.scale(scalar);
			}
		}

		void transform(Matrix<T, 3, 3> transformation)
		{
			_hull.transform(transformation);
			for (auto& hole : _holes)
			{
				hole.transform(transformation);
			}
		}

	};

	template<class T>
	inline bool operator==(Holygon<T> const& lhs, Holygon<T> const& rhs)
	{
		if (lhs.hull() == rhs.hull())
		{
			std::vector<Polygon<T>> lHoles = lhs.holes();
			std::vector<Polygon<T>> rHoles = rhs.holes();
			if (lHoles.size() == rHoles.size())
			{
				for (size_t i = 0; i < lHoles.size(); ++i)
				{
					// if any hole is different, return false
					if (lHoles[i] != rHoles[i])
					{
						return false;
					}
				}

				// fall through case where all holes are equal; return true
				return true;
			}
		}

		// if either of the above if-conditions fail, we fall through to returning false
		return false;
	}

	template<class T>
	inline bool operator!=(Holygon<T> const& lhs, Holygon<T> const& rhs)
	{
		return !(lhs == rhs);
	}

	// convencience fit function for a collection of Holygons. must be used like fit<ContainterType>
	template<template<class, class...> class ContainerT, class T, class... Additional>
	inline AABB<T, 2> fit(ContainerT<Holygon<T>, Additional...> const& container)
	{
		AABB<T, 2> box = AABB<T, 2>::nothing();
		for (Holygon<T> const& holygon : container)
		{
			box = fit(box, holygon.aabb());
		}
		return box;
	}

	template<class T, class ClipListT>
	inline Holygon<T> clip(Holygon<T> const& holygon, ClipListT const& clipPoints)
	{
		Polygon<T> hull = clip(holygon.hull(), clipPoints);

		if (!hull.empty())
		{
			std::vector<Polygon<T>> holes;
			holes.reserve(holygon.holes().size());
			for (Polygon<T> const& hole : holygon.holes())
			{
				auto clipped = clip(hole, clipPoints);
				if (!clipped.empty())
				{
					holes.push_back(clipped);
				}
			}

			return Holygon<T>{ hull, holes };
		}
		else
		{
			return Holygon<T>{};
		}
		
	}

} // math
} // lucid