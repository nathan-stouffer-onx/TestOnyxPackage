#pragma once

#include <array>
#include <vector>

#include "AABB.h"
#include "Constants.h"
#include "Range.h"
#include "Vector.h"

namespace lucid {
namespace math {

	///
	///
	///
	template<class T, int DIM> struct OBB
	{
	public:

		using VecT = Vector<T, DIM>;

		// NOTE: we assume this to be an orthonormal set of vectors
		using BasisT = std::array<VecT, DIM>;

	private:

		VecT mCenter;
		BasisT mBasis;
		VecT mHalfExtents;

	public:

		OBB() : OBB(BasisT()) {}
		
		OBB(BasisT const& basis) : OBB(VecT(0), basis, VecT(std::numeric_limits<T>::lowest())) {}

		OBB(VecT const& center, BasisT const& basis, VecT const& halfExtents) :
			mCenter(center),
			mBasis(basis),
			mHalfExtents(halfExtents)
		{}

		VecT const& center() const { return mCenter; }
		BasisT const& basis() const { return mBasis; }
		VecT const& halfExtents() const { return mHalfExtents; }

		inline constexpr static int VERTEX_COUNT() { return 1 << DIM; };

		/**
		   6----7
		  /|   /|
		 2----3 |
		 | 4--|-5
		 |    |/
		 0----1
		 -------
		 0 is min
		 3 is max for 2D, 7 is max for 3d
		 */
		VecT vertex(int index) const
		{
			VecT result = mCenter;
			for (int i = 0; i < DIM; ++i)
			{
				if ((index & (1 << i)) != 0)
				{
					result += mHalfExtents[i] * mBasis[i];
				}
				else
				{
					result -= mHalfExtents[i] * mBasis[i];
				}
			}
			return result;
		}

		bool contains(VecT const& point) const
		{
			for (int d = 0; d < DIM; ++d)
			{
				VecT const& basis = mBasis[d];
				T l = dot(point - mCenter, basis);
				if (std::abs(l) > mHalfExtents[d])
				{
					return false;
				}
			}
			return true;
		}

		OBB& fit(VecT const& point)
		{
			for (int d = 0; d < DIM; ++d)
			{
				VecT const& basis = mBasis[d];
				T l = dot(point - mCenter, basis);
				T& halfExtent = mHalfExtents[d];
				if (std::abs(l) > halfExtent)
				{
					VecT min = (l < -halfExtent) ? mCenter + l * basis : mCenter - halfExtent * basis;
					VecT max = (l >  halfExtent) ? mCenter + l * basis : mCenter + halfExtent * basis;
					mCenter = 0.5 * (min + max);
					halfExtent = std::abs(dot(point - mCenter, basis));
				}
			}
			return *this;
		}

	};

	template<class T> OBB<T, 2> construct(AABB<T, 2> const& aabb)
	{
		using VecT = Vector<T, 2>;
		OBB<T, 2> obb = OBB<T, 2>({ VecT(1, 0), VecT(0, 1) });
		obb.fit(aabb.min);
		obb.fit(aabb.max);
		return obb;
	}
	template<class T> OBB<T, 3> construct(AABB<T, 3> const& aabb)
	{
		using VecT = Vector<T, 3>;
		OBB<T, 3> obb = OBB<T, 3>({ VecT(1, 0, 0), VecT(0, 1, 0), VecT(0, 0, 1) });
		obb.fit(aabb.min);
		obb.fit(aabb.max);
		return obb;
	}

	/// fit
	///
	/// function to construct a bounding box from a collection of points
	template<template<class, class...> class ContainerT, class T, int DIM, class... Additional>
	inline OBB<T, DIM> fit(OBB<T, DIM> const& basis, ContainerT<Vector<T, DIM>, Additional...> const& points)
	{
		OBB<T, DIM> box = OBB<T, DIM>(basis);
		for (Vector<T, DIM> const& point : points)
		{
			box.fit(point);
		}
		return box;
	}

	///	contains
	///
	/// Given an OBB, return whether or not the box contains the point
	template<class T, int DIM> inline bool contains(OBB<T, DIM> const &box, Vector<T, DIM> const &point)
	{
		return box.contains(point);
	}

	template<class T, int DIM> Range<T> project(OBB<T, DIM> const& obb, Vector<T, DIM> const& axis)
	{
		Range<T> range{ std::numeric_limits<T>::max(), std::numeric_limits<T>::lowest() };
		for (int i = 0; i < OBB<T, DIM>::VERTEX_COUNT(); ++i)
		{
			T l = dot(obb.vertex(i), axis);
			range.begin = std::min(range.begin, l);
			range.end = std::max(range.end, l);
		}
		return range;
	}

	/**
	 * @brief Computes whether or not a particular axis separates two OBBs.
	 *
	 * The separating axis test says that two objects are disjoint if there exists a line (separating axis) onto 
	 * which the two objects' projections are disjoint.
	 * https://en.wikipedia.org/wiki/Hyperplane_separation_theorem
	 * 
	 * @tparam T 
	 * @tparam DIM 
	 * @param [in] axis 
	 * @param [in] lhs 
	 * @param [in] rhs 
	 * @return 
	 */
	template<class T, int DIM> bool separates(Vector<T, DIM> const& axis, OBB<T, DIM> const& lhs, OBB<T, DIM> const& rhs)
	{
		Range<T> lrange = project(lhs, axis);
		Range<T> rrange = project(rhs, axis);
		return lrange.end < rrange.begin || rrange.end < lrange.begin;
	}

	template<class T> bool intersect(OBB<T, 2> const& lhs, OBB<T, 2> const& rhs)
	{
		// in 2 dimensions: if a separating axis exists, the set of edge normals contains the axis
		for (Vector<T, 2> const& basis : lhs.basis())
		{
			if (separates(basis, lhs, rhs))
			{
				return false;
			}
		}
		for (Vector<T, 2> const& basis : rhs.basis())
		{
			if (separates(basis, lhs, rhs))
			{
				return false;
			}
		}
		return true;
	}

	template<class T> bool intersect(OBB<T, 3> const& lhs, OBB<T, 3> const& rhs)
	{
		// in 3 dimensions: if a separating axis exists, the union of two sets is guaranteed to contain the axis. the first is the set of
		// face normals. the second is the cross products of all pairs of edges from each object (I could not prove this fact, but a number
		// of resources mentioned it). for OBBs, the set of edges is the same as the set of basis vectors.
		for (Vector<T, 3> const& basis : lhs.basis())
		{
			if (separates(basis, lhs, rhs))
			{
				return false;
			}
		}
		for (Vector<T, 3> const& basis : rhs.basis())
		{
			if (separates(basis, lhs, rhs))
			{
				return false;
			}
		}
		for (Vector<T, 3> const& l : lhs.basis())
		{
			for (Vector<T, 3> const& r : rhs.basis())
			{
				Vector<T, 3> b = cross(l, r);
				if (lenSquared(b) > T(0) && separates(b, lhs, rhs))
				{
					return false;
				}
			}
		}
		return true;
	}

}	///	math
}	///	lucid