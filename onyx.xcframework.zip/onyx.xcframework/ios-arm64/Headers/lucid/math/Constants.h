#pragma once

#include "../Types.h"

///
///
///
#if NO_ONYX_EXCEPTIONS
#define THROW //
#else
#define THROW throw
#endif

// TODO: Add support for signed int types?

#define LUCID_MATH_CONSTANT(name,value)					\
	template<class T> __inline T name()					\
	{													\
		THROW "bad cast";								\
		return T();										\
	}													\
	template<> __inline float32_t name()				\
	{													\
		static float32_t const result = value##F;		\
		return result;									\
	}													\
	template<> __inline float64_t name()				\
	{													\
		static float64_t const result = value;			\
		return result;									\
	}													\
	template<> __inline float128_t name()				\
	{													\
		static float128_t const result = value##L;		\
		return result;									\
	}													\
	template<> __inline uint16_t name()					\
	{													\
		static uint16_t const result = uint16_t(value);	\
		return result;									\
	}													\
	template<> __inline uint32_t name()					\
	{													\
		static uint32_t const result = uint32_t(value);	\
		return result;									\
	}													\
	template<> __inline uint64_t name()					\
	{													\
		static uint64_t const result = uint64_t(value);	\
		return result;									\
	}													\

///
///
///
namespace lucid::math::constants {

LUCID_MATH_CONSTANT(zero, 0.0)
LUCID_MATH_CONSTANT(one, 1.0)
LUCID_MATH_CONSTANT(half, 0.5)
LUCID_MATH_CONSTANT(two, 2.0)
LUCID_MATH_CONSTANT(sqrt_two, 1.41421356237)

LUCID_MATH_CONSTANT(two_pi, 6.283185307179586476925286766559)
LUCID_MATH_CONSTANT(pi, 3.141592653589793238462643383279)
LUCID_MATH_CONSTANT(half_pi, 1.570796326794896619231321691639)
LUCID_MATH_CONSTANT(quarter_pi, 0.785398163397448309615660845819)
LUCID_MATH_CONSTANT(deg_to_rad, 0.017453292519943295769236907684)
LUCID_MATH_CONSTANT(rad_to_deg, 57.29577951308232087679815481410)

LUCID_MATH_CONSTANT(e, 2.718281828459045235360287471352)

// Uses largest actual value instead of inf (should we use std::numeric_limits<T>::infinity()?)
template<class T> T pos_inf()
{
	return std::numeric_limits<T>::max();
}

template<class T> T neg_inf()
{
	return std::numeric_limits<T>::lowest();
}

LUCID_MATH_CONSTANT(tol, 0.0000001)
LUCID_MATH_CONSTANT(tol_tol, 0.00000000000001)

template<class T> __inline T max()
{
	return std::numeric_limits<T>::max();
}

template<class T> __inline T min()
{
	return std::numeric_limits<T>::min();
}

}
