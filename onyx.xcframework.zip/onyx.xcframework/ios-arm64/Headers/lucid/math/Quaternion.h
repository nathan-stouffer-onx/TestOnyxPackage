#pragma once

#include "Constants.h"
#include "Scalar.h"
#include "Vector.h"

// TODO (Ronald): May be worthwhile to let a lot of the code here just use
//	the Vector4 functions

///
///
///
namespace lucid {
namespace math {

	///	Quaternion<T>
	///
	///	templated quaternion. w is treated as the real factor
	template<class T> struct Quaternion
	{
		union {
			struct { T x, y, z, w; };
			Vector<T, 4> vec;
		};

		Quaternion() = default;

		Quaternion(T const &x, T const &y, T const &z, T const &w)
			: x(x), y(y), z(z)
			, w(w)
		{
		}

		Quaternion(Vector<T, 4> v)
			: x(v.x), y(v.y), z(v.z)
			, w(v.w)
		{
		}

	};

}	///	math
}	///	lucid

///	quaternion shorthand for the following operator overloads
///
///	note: relies upon push/pop macro pragmas
#pragma push_macro("QUATERNION")
#define QUATERNION(T) lucid::math::Quaternion<T>

template<class T> inline QUATERNION(T) operator-(QUATERNION(T) const &rhs)
{
	return QUATERNION(T)(-rhs.x, -rhs.y, -rhs.z, -rhs.w);
}

template<class T> inline QUATERNION(T) operator+(QUATERNION(T) const &lhs, QUATERNION(T) const &rhs)
{
	return QUATERNION(T)(lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z, lhs.w + rhs.w);
}

template<class T> inline QUATERNION(T) operator-(QUATERNION(T) const &lhs, QUATERNION(T) const &rhs)
{
	return QUATERNION(T)(lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z, lhs.w - rhs.w);
}

template<class T> inline QUATERNION(T) operator*(QUATERNION(T) const &lhs, T const &rhs)
{
	return QUATERNION(T)(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs, lhs.w * rhs);
}

template<class T> inline QUATERNION(T) operator*(T const &lhs, QUATERNION(T) const &rhs)
{
	return QUATERNION(T)(rhs.x * lhs, rhs.y * lhs, rhs.z * lhs, rhs.w * lhs);
}

template<class T> inline QUATERNION(T) operator*(QUATERNION(T) const &lhs, QUATERNION(T) const &rhs)
{
	return QUATERNION(T)
	(
		lhs.y * rhs.z - lhs.z * rhs.y + lhs.w * rhs.x + lhs.x * rhs.w,
		lhs.z * rhs.x - lhs.x * rhs.z + lhs.w * rhs.y + lhs.y * rhs.w,
		lhs.x * rhs.y - lhs.y * rhs.x + lhs.w * rhs.z + lhs.z * rhs.w,
		lhs.w * rhs.w - lhs.x * rhs.x - lhs.y * rhs.y - lhs.z * rhs.z
	);
}

template<class T> inline QUATERNION(T) operator/(QUATERNION(T) const &lhs, T const &rhs)
{
	T const coeff = ::lucid::math::constants::one<T>() / rhs;
	return QUATERNION(T)(coeff * lhs.x, coeff * lhs.y, coeff * lhs.z, coeff * lhs.w);
}

///
///	remove the shorthand
///
#undef QUATERNION
#pragma pop_macro("QUATERNION")

///
///
///
namespace lucid {
namespace math {

	///	conjugate
	///
	///	returns the conjugate of the supplied quaternion
	template<class T> inline Quaternion<T> conjugate(Quaternion<T> const &rhs)
	{
		return Quaternion<T>(-rhs.x, -rhs.y, -rhs.z, rhs.w);
	}

	///	dot
	///
	///	dot product
	template<class T> inline T dot(Quaternion<T> const &lhs, Quaternion<T> const &rhs)
	{
		return lhs.x * rhs.x + lhs.y * rhs.y + lhs.z * rhs.z + lhs.w * rhs.w;
	}

	///	lsq
	///
	///	length squared
	template<class T> inline T lsq(Quaternion<T> const &rhs)
	{
		return dot(rhs, rhs);
	}

	///	len
	///
	///	length
	template<class T> inline T len(Quaternion<T> const &rhs)
	{
		return sqrt(lsq(rhs));
	}

	///	normalize
	///
	///	return normalized quaternion
	template<class T> inline Quaternion<T> normalize(Quaternion<T> const &rhs)
	{
		return rhs / len(rhs);
	}

	///	equ and neq
	///
	///	equality tests
	
	template<class T> inline bool equ(Quaternion<T> const &lhs, Quaternion<T> const &rhs)
	{
		return lsq(lhs - rhs) < constants::tol_tol<T>();
	}

	template<class T> inline bool neq(Quaternion<T> const &lhs, Quaternion<T> const &rhs)
	{
		return !equ(lhs, rhs);
	}

	///	rotateUsingAxis
	///
	/// "axis" is not assumed to be normalized
	template<class T> Quaternion<T> rotateUsingAxis(Vector<T,3> const &axis, T radians)
	{
		T hTheta = constants::half<T>() * radians;
		Vector<T,3> n = normalize(axis) * sin(hTheta);

		return Quaternion<T>(n.x, n.y, n.z, cos(hTheta));
	}

	///	rotate
	///
	/// Assumes that "from" and "to" are normalized. If rotation is ill-defined, will return identity quaternion
	template<class T> Quaternion<T> rotate(Vector<T,3> const& from, Vector<T,3> const& to)
	{
		// Invalid if vectors are equal/negations of each other or if either are zero
		if (equ(from, to) ||
			equ(from, -to) ||
			equ(from, Vector<T, 3>::zero()) || equ(to, Vector<T, 3>::zero()))
		{
			return Quaternion<T>(0, 0, 0, T(1));
		}

		auto rotAxis = cross(from, to);
		auto angle = acos(dot(from, to));
		
		return rotateUsingAxis(rotAxis, angle);
	}

	///	transform direction
	///
	/// Uses sandwich product to rotate vector
	template<class T> inline Vector<T,3> transformDirection(Quaternion<T> const q, Vector<T,3> const &r)
	{
		Quaternion<T> u = q * Quaternion<T>(r.x, r.y, r.z, constants::zero<T>()) * conjugate(q);

		return Vector<T,3>(u.x, u.y, u.z);
	}

	/// lerp
	/// 
	/// t is between 0 and 1 inclusive.
	template<class T> inline Quaternion<T> lerp(T t, Quaternion<T> const& q1, Quaternion<T> const& q2)
	{
		return Quaternion<T>(lerp(q1.vec, q2.vec, t));
	}

	///	slerp
	/// Formula derivation: Animating Rotation with Quaternion Curves by Ken Shoemake
	///	q1 and q2 are assumed to be normalized. t is between 0 and 1 (inclusive). will invert to calculate shortest path rotation
	template<class T> inline Quaternion<T> slerp(T t, Quaternion<T> const &q1, Quaternion<T> const &q2)
	{
		T dp = dot(q1, q2);
		Quaternion<T> q3 = q2;

		if (dp < constants::zero<T>())
		{
			dp = -dp;
			q3 = -q2;
		}

		if (dp < T(0.95))
		{
			T theta = acos(dp);
			T coeff = constants::one<T>() / sin(theta);

			return coeff * (q1 * sin(theta * (constants::one<T>() - t)) + q3 * sin(theta * t));
		}
		
		return lerp(t, q1, q3);
	}

	///	slerpNoInvert
	/// Formula derivation: Animating rotation with quaternion curves by Ken Shoemake
	/// q1 and q2 are assumed to be normalized. t is between 0 and 1 (inclusive). Can encode a longer path rotation if dot(q1, q2) < 0
	template<class T> inline Quaternion<T> slerpNoInvert(T t, Quaternion<T> const &q1, Quaternion<T> const &q2)
	{
		T dp = dot(q1, q2);

		if ((T(-0.95) < dp) && (dp < T(0.95)))
		{
			T theta = acos(dp);
			T coeff = constants::one<T>() / sin(theta);

			return coeff * (q1 * sin(theta * (constants::one<T>() - t)) + q2 * sin(theta * t));
		}

		return lerp(t, q1, q2);
	}

	///	exp
	///
	///	returns the exponential of the quaternion.
	template<class T> inline Quaternion<T> exp(Quaternion<T> const &rhs)
	{
		T a = sqrt(rhs.x * rhs.x + rhs.y * rhs.y + rhs.z * rhs.z);
		T sina = sin(a);
		T cosa = cos(a);

		Quaternion<T> result(0, 0, 0, cosa);
		if (a > constants::zero<T>())
		{
			T coeff = sina / a;

			result.x = coeff * rhs.x;
			result.y = coeff * rhs.y;
			result.z = coeff * rhs.z;
		}

		return result * exp(rhs.w);
	}

	///	log
	///
	///	returns the natural log of the quaternion. Assumes rhs is a unit quaternion
	template<class T> inline Quaternion<T> log(Quaternion<T> const &rhs)
	{
		T a = acos(rhs.w);
		T sina = sin(a);

		Quaternion<T> result(0, 0, 0, 0);
		if (sina > constants::zero<T>())
		{
			T coeff = a / sina;

			result.x = coeff * rhs.x;
			result.y = coeff * rhs.y;
			result.z = coeff * rhs.z;
		}

		return result;
	}

	///	squad
	///
	///	spherical spline interpolation.  s1 and s2 are computed using computeControl(...) below.
	template<class T> inline Quaternion<T> squad(T t, Quaternion<T> const &q1, Quaternion<T> const &q2, Quaternion<T> const &s1, Quaternion<T> const &s2)
	{
		Quaternion<T> c = slerpNoInvert(t, q1, q2);
		Quaternion<T> d = slerpNoInvert(t, s1, s2);

		return slerpNoInvert(constants::two<T>() * t * (constants::one<T>() - t), c, d);
	}

	///	compute control
	///
	///	used to compute spline control values given: previous (q1), current (q2), and next (q3) values.
	template<class T> inline Quaternion<T> computeControl(Quaternion<T> const &q1, Quaternion<T> const &q2, Quaternion<T> const &q3)
	{
		Quaternion<T> q(-q2.x, -q2.y, -q2.z, q2.w);

		return q2 * exp(T(-0.25) * (log(q * q1) + log(q * q3)));
	}

}	///	math
}	///	lucid
