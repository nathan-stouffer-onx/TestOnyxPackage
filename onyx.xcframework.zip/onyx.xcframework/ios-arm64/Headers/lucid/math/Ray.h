#pragma once

#include "Vector.h"

namespace lucid {
namespace math {

	template<class T, int DIM>
	struct Ray
	{
		using vecT = Vector<T, DIM>;

		Ray() = default;
		Ray(vecT const& _origin, vecT const& _direction) :
			origin(_origin),
			direction(_direction)
		{}

		vecT origin = { 0, 0, 0 };
		vecT direction = { 0, 0, 0 };

	};

} // math
} // lucid