#include "Profiler.h"

#include <bx/timer.h>
#if defined(THREAD_SAFE)
#include <bx/thread.h>
#endif

#include "../Warnings.h"

#ifdef PLATFORM_WINDOWS
#include <Windows.h>
#elif PLATFORM_OSX
#elif PLATFORM_IOS
#elif PLATFORM_ANDROID
#include <pthread.h>
#elif PLATFORM_EMSCRIPTEN
#endif


namespace lucid {
namespace core {

	///
	///
	///

	Profiler::Sample::Sample(Profiler *profiler, char const *name)
		: profiler(profiler)
		, name(name)
	{
	}

	Profiler::Sample::~Sample()
	{
		delete firstChild;
		delete nextSibling;
	}

	void Profiler::Sample::reset()
	{
		count = 0;
		timeTotal = 0;
		timeMax = 0;
		timeMin = 10000000000;

		for (Sample *child = firstChild; child; child = child->nextSibling)
			child->reset();
	}

	void Profiler::Sample::begin()
	{
		if (0 == recursion)
		{
			timeStart = profiler->time();
		}
		++recursion;
		++count;
	}

	void Profiler::Sample::copyTo(Sample* other) const
	{
		other->count += count;
		if (recursion > 0)
		{
			float64_t tmp = profiler->time() - timeStart;
			other->timeTotal += tmp;
		}
		other->timeTotal += timeTotal;
		other->timeMax = std::max(other->timeMax, timeMax);
		other->timeMin = std::min(other->timeMin, timeMin);
		if (firstChild != nullptr)
		{
			firstChild->copyTo(other->findChild(firstChild->name));
		}
		if (nextSibling != nullptr)
		{
			nextSibling->copyTo(other->onlyParent->findChild(nextSibling->name));
		}
	}

	Profiler::Sample *Profiler::Sample::end()
	{
		--recursion;
		if (0 == recursion)
		{
			float64_t tmp = profiler->time() - timeStart;
			timeTotal += tmp;
			
			if (timeMax < tmp)
				timeMax = tmp;
			
			if (timeMin > tmp)
				timeMin = tmp;

			return onlyParent;
		}
		return this;
	}

	void Profiler::Sample::addChild(Sample *child)
	{
		child->onlyParent = this;
		if (nullptr == firstChild)
			firstChild = child;
		else
			firstChild->addSibling(child);
	}

	Profiler::Sample *Profiler::Sample::findChild(char const *childName)
	{
#ifdef THREAD_SAFE
		std::lock_guard<std::mutex> lock(_mtx);
#endif

		///	linear search, each sample will likely have just a few child samples.
		///	if this becomes an issue use hash map...
		for (Sample *child = firstChild; child; child = child->nextSibling)
			if (childName == child->name)
				return child;

		Sample *child = new Sample(profiler, childName);
		addChild(child);

		return child;
	}

	void Profiler::Sample::addSibling(Sample *sibling)
	{
		if (nullptr == nextSibling)
			nextSibling = sibling;
		else
			nextSibling->addSibling(sibling);
	}

	///
	///
	///

	bool Profiler::attached = false;
#ifndef THREAD_SAFE
	Profiler *Profiler::profiler = nullptr;
#else
	std::unordered_map<uint32_t, Profiler*>* Profiler::threadProfilers = nullptr;
	std::mutex Profiler::_mtx;
#endif

	Profiler::Profiler()
	{
		root = new Sample(this, "root");
		sample = root;

		_freq = 1.0 / bx::getHPFrequency();
		_startTime = bx::getHPCounter() * _freq;
	}

	Profiler::~Profiler()
	{
		delete root;
	}

	void Profiler::initialize()
	{
		attached = false;
		threadProfilers = new std::unordered_map<uint32_t, Profiler*>();

#ifndef THREAD_SAFE
		profiler = new Profiler();
#endif
	}

#ifndef THREAD_SAFE
	void Profiler::attach(Profiler* external)
	{
		attached = true;
		profiler = external;
	}
#else
	void Profiler::attach(Profiler* /* external */)
	{
		attached = true;
	}
#endif

	void Profiler::shutdown()
	{
#ifndef THREAD_SAFE
		if (!attached) delete profiler;
		profiler = nullptr;
#else
		if (!attached)
		{
			if (threadProfilers != nullptr)
			{
				std::lock_guard<std::mutex> lock(_mtx);
				for (auto& iter : (*threadProfilers))
				{
					delete iter.second;
				}

				threadProfilers->clear();
				delete threadProfilers;
			}
			threadProfilers = nullptr;
		}
#endif
		attached = false;
	}

	void Profiler::snapshot(Sample* target)
	{
#ifdef THREAD_SAFE
		auto profiler = threadProfiler();
#endif

		if (nullptr != profiler && nullptr != profiler->root->firstChild)
		{
			auto snapshotRoot = profiler->root->firstChild;
			
			// Skip any empty samples at the root level
			while (snapshotRoot != nullptr && snapshotRoot->count == 0)
			{
				snapshotRoot = snapshotRoot->nextSibling;
			}

			snapshotRoot->copyTo(target->findChild(snapshotRoot->name));
		}
	}

	float64_t Profiler::time() const
	{
		auto now = bx::getHPCounter() * _freq;
		return now - _startTime;
	}

	Profiler* Profiler::threadProfiler()
	{
		if (nullptr == threadProfilers)
			return nullptr;

		auto id = onyx::core::Threading::CurrentThreadId();
		auto iter = threadProfilers->find(id);
		if (iter != threadProfilers->end())
			return iter->second;

		{
			std::lock_guard<std::mutex> lock(_mtx);
			iter = threadProfilers->find(id);
			if (iter != threadProfilers->end())
				return iter->second;

			Profiler *newRoot = new Profiler();

			(*threadProfilers)[id] = newRoot;
			return newRoot;
		}
	}

	void Profiler::reset()
	{
#ifndef THREAD_SAFE
		if (nullptr != profiler)
			profiler->root->reset();
#else
		auto prof = threadProfiler();
		if (prof != nullptr)
			threadProfiler()->root->reset();
#endif
	}

	void Profiler::beginSample(char const *name)
	{
		Profiler *prof;
#ifndef THREAD_SAFE
		prof = profiler;
#else
		prof = threadProfiler();
#endif
		if (nullptr == prof)
		{
			return;
		}

		if (name != prof->sample->name)
		{
			prof->sample = prof->sample->findChild(name);
		}
		prof->sample->begin();
	}

	void Profiler::endSample()
	{
#ifndef THREAD_SAFE
		if (profiler != nullptr)
			profiler->sample = profiler->sample->end();
#else
		auto prof = threadProfiler();
		if (prof == nullptr)
			return;

		prof->sample = prof->sample->end();
#endif
	}
	
	Profiler::Sample const *Profiler::samples()
	{
#ifndef THREAD_SAFE
		if (nullptr == profiler)
			return nullptr;
		return profiler->root->firstChild;
#else
		auto prof = threadProfiler();
		if (prof == nullptr)
			return nullptr;
		return prof->root->firstChild;
#endif
	}


}	///	core
}	///	lucid
