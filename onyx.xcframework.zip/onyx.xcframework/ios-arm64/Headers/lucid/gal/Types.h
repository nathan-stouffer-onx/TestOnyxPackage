#if !defined(_LUCID_TYPES_H)
#define _LUCID_TYPES_H
#pragma once

#include <cstdint>

#include "lucid/Types.h"
#include "lucid/gal/Color.h"
#include "lucid/math/Vector.h"
#include "lucid/math/Quaternion.h"
#include "lucid/math/Matrix.h"
#include "lucid/math/AABB.h"
#include "lucid/math/Algorithm.h"
#include "lucid/math/Range.h"
#include "lucid/math/OBB.h"
#include "lucid/math/Polyline.h"
#include "lucid/math/Polygon.h"
#include "lucid/math/Holygon.h"
#include "lucid/math/Sphere.h"
#include "lucid/math/Ray.h"

// typedefs for difference float precisions at global scope
typedef float64_t time_float_t;			// precision to use when dealing with time
typedef float64_t world_float_t;		// precision to use when dealing with objects that can be anywhere in the world (eg camera values)
typedef float32_t globe_float_t;		// precision to use when dealing with objects that are defined in lon and lat
typedef float32_t tile_float_t;			// precision to use when dealing with objects in coordinates relative to a single tile (eg parsing protobuf)
typedef float32_t height_float_t;		// precision to use when dealing with objects only involving height
typedef float32_t gpu_float_t;			// precision to use when dealing with items directly associated with the gpu (eg shaders, atlases, etc)
typedef int screen_coord_t;				// precision to use when dealing with objects in screen space
typedef size_t index_t;					// precision to use when dealing with general data in arrays
typedef float64_t input_float_t;		// precision to use when dealing with input position information

namespace lucid {
namespace gal {

	template<class PRECISION>
	struct InstantiateTypes
	{
		typedef PRECISION coord_t;

		typedef ::lucid::math::Vector<PRECISION, 2> Vector2;
		typedef ::lucid::math::Vector<PRECISION, 3> Vector3;
		typedef ::lucid::math::Vector<PRECISION, 4> Vector4;

		typedef ::lucid::math::AABB<PRECISION, 2> AABB2d;
		typedef ::lucid::math::AABB<PRECISION, 3> AABB3d;

		typedef ::lucid::math::OBB<PRECISION, 2> OBB2d;
		typedef ::lucid::math::OBB<PRECISION, 3> OBB3d;

		typedef ::lucid::math::Matrix<PRECISION, 2, 2> Matrix2x2;
		typedef ::lucid::math::Matrix<PRECISION, 3, 3> Matrix3x3;
		typedef ::lucid::math::Matrix<PRECISION, 4, 4> Matrix4x4;

		typedef ::lucid::math::Quaternion<PRECISION> Quaternion;

		typedef ::lucid::math::Range<PRECISION> Range;

		typedef ::lucid::math::LineSegment<PRECISION, 2> LineSegment2;

		typedef ::lucid::math::Polyline<PRECISION, 2> Polyline;

		typedef ::lucid::math::Polygon<PRECISION> Polygon;
		typedef ::lucid::math::Holygon<PRECISION> Holygon;

		typedef ::lucid::math::Sphere<PRECISION, 2> Circle;
		typedef ::lucid::math::Sphere<PRECISION, 3> Sphere3;

		typedef ::lucid::math::Plane<PRECISION, 3> Plane;

		typedef ::lucid::math::Ray<PRECISION, 3> Ray3;

		template <int DIM>
		static inline ::lucid::math::Matrix<PRECISION, DIM, DIM> Identity()
		{
			return ::lucid::math::Identity<PRECISION, DIM>();
		}

		template <int DIM>
		static inline ::lucid::math::Matrix<PRECISION, DIM, DIM> Scale(::lucid::math::Vector<PRECISION, DIM> const &scale)
		{
			return ::lucid::math::Scale<PRECISION, DIM>(scale);
		}

	};

	// create typedefs for different precisions that we work in
	typedef InstantiateTypes<time_float_t>		time;
	typedef InstantiateTypes<world_float_t>		world;
	typedef InstantiateTypes<globe_float_t>		globe;
	typedef InstantiateTypes<height_float_t>	height;
	typedef InstantiateTypes<tile_float_t>		tile;
	typedef InstantiateTypes<gpu_float_t>		gpu;
	typedef InstantiateTypes<screen_coord_t>	screen;
	typedef InstantiateTypes<index_t>			array;
	typedef InstantiateTypes<input_float_t>		input;

	// create general typedefs
	typedef ::lucid::math::Range<int> Range;
	

} // gal
} // lucid

// shortcut namespaces to reduce verbosity
namespace lgal = lucid::gal;
namespace lmath = lucid::math;
#endif