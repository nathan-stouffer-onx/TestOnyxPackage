#if !defined(_LUCID_TYPES_H)
#define _LUCID_TYPES_H
#pragma once

#include <bx/math.h>

#include "lucid/Types.h"
#include "lucid/math/Vector.h"
#include "lucid/math/Quaternion.h"
#include "lucid/math/Matrix.h"
#include "lucid/math/AABB.h"
#include "lucid/math/Algorithm.h"
#include "lucid/math/Range.h"
#include "lucid/math/Polyline.h"
#include "lucid/math/Polygon.h"
#include "lucid/math/Holygon.h"
#include "lucid/math/Sphere.h"
#include "lucid/math/Ray.h"

// typedefs for difference float precisions at global scope
typedef float64_t time_float_t;			// precision to use when dealing with time
typedef float64_t world_float_t;		// precision to use when dealing with objects that can be anywhere in the world (eg camera values)
typedef float32_t tile_float_t;			// precision to use when dealing with objects in coordinates relative to a single tile (eg parsing protobuf)
typedef float32_t height_float_t;		// precision to use when dealing with objects only involving height
typedef float32_t gpu_float_t;			// precision to use when dealing with items directly associated with the gpu (eg shaders, atlases, etc)
typedef int screen_coord_t;				// precision to use when dealing with objects in screen space
typedef size_t index_t;					// precision to use when dealing with general data in arrays
typedef float64_t input_float_t;		// precision to use when dealing with input position information

namespace lucid {
namespace gal {

	template<class PRECISION>
	struct InstantiateTypes
	{
		typedef PRECISION coord_t;

		typedef ::lucid::math::Vector<PRECISION, 2> Vector2;
		typedef ::lucid::math::Vector<PRECISION, 3> Vector3;
		typedef ::lucid::math::Vector<PRECISION, 4> Vector4;

		typedef ::lucid::math::AABB<PRECISION, 2> AABB2d;
		typedef ::lucid::math::AABB<PRECISION, 3> AABB3d;

		typedef ::lucid::math::Matrix<PRECISION, 2, 2> Matrix2x2;
		typedef ::lucid::math::Matrix<PRECISION, 3, 3> Matrix3x3;
		typedef ::lucid::math::Matrix<PRECISION, 4, 4> Matrix4x4;

		typedef ::lucid::math::Quaternion<PRECISION> Quaternion;

		typedef ::lucid::math::Range<PRECISION> Range;

		typedef ::lucid::math::LineSegment<PRECISION, 2> LineSegment2;

		typedef ::lucid::math::Polyline<PRECISION, 2> Polyline;

		typedef ::lucid::math::Polygon<PRECISION> Polygon;
		typedef ::lucid::math::Holygon<PRECISION> Holygon;

		typedef ::lucid::math::Sphere<PRECISION, 2> Circle;
		typedef ::lucid::math::Sphere<PRECISION, 3> Sphere3;

		typedef ::lucid::math::Plane<PRECISION, 3> Plane;

		typedef ::lucid::math::Ray<PRECISION, 3> Ray3;

		static inline bx::Vec3 toBx(Vector3 const& rhs)
		{
			return { float(rhs.x), float(rhs.y), float(rhs.z) };
		}

		static inline bx::Vec3 toBx(Vector2 const& rhs)
		{
			return toBx(Vector3{ rhs, PRECISION(0) });
		}

	};

	// create typedefs for different precisions that we work in
	typedef InstantiateTypes<world_float_t>		world;
	typedef InstantiateTypes<height_float_t>	height;
	typedef InstantiateTypes<tile_float_t>		tile;
	typedef InstantiateTypes<gpu_float_t>		gpu;
	typedef InstantiateTypes<screen_coord_t>	screen;
	typedef InstantiateTypes<index_t>			array;
	typedef InstantiateTypes<input_float_t>		input;

	// create general typedefs
	typedef ::lucid::math::Range<int> Range;
	

} // gal
} // lucid

// shortcut namespaces to reduce verbosity
namespace lgal = lucid::gal;
namespace lmath = lucid::math;

/// TODO eventually drop this block in favor of the above blocks
namespace lucid {
namespace gal {

	// TODO These two typedefs confuse me. Both are the same and don't
	// tell me anything about when to use Map3D vs World types. Remove Map3D_float_t soon
	typedef float64_t Map3D_float_t;
	typedef float64_t World_float_t;

	typedef int Screen_coord_t;
	
	inline bx::Vec3 toBx(world::Vector3 const& rhs)
	{
		return { float(rhs.x), float(rhs.y), float(rhs.z) };
	}

	inline bx::Vec3 toBx(world::Vector2 const& rhs)
	{
		return { float(rhs.x), float(rhs.y), 0.f };
	}

	inline world::Vector3 toVec3(bx::Vec3 const& rhs)
	{
		return { rhs.x, rhs.y, rhs.z };
	}

	template <typename T, int DIM>
	inline lucid::math::Vector<gpu_float_t, DIM> toGPU(lucid::math::Vector<T, DIM> const& rhs)
	{
		lucid::math::Vector<gpu_float_t, DIM> result;
		for (int i = 0; i < DIM; ++i)
			result[i] = gpu_float_t(rhs[i]);

		return result;
	}

	///	Color
	///
	///
	struct Color
	{
		union {
			struct { float32_t r, g, b, a; };
			math::Vector<float32_t, 4> vec4;
		};
		

		constexpr Color()
			: r(1.f), g(1.f), b(1.f)
			, a(1.f)
		{
		}

		constexpr Color(float32_t r, float32_t g, float32_t b, float32_t a)
			: r(r), g(g), b(b)
			, a(a)
		{
		}

		constexpr Color(uint8_t r, uint8_t g, uint8_t b, uint8_t a)
			: r(r / 255.0f), g(g / 255.0f), b(b / 255.0f)
			, a(a / 255.0f)
		{
		}

		constexpr Color(uint32_t argb) :
			r((float) ((argb &   0xFF0000) >> 16) / 255.0f),
			g((float) ((argb &     0xFF00) >>  8) / 255.0f),
			b((float)  (argb &       0xFF)        / 255.0f),
			a((float) ((argb & 0xFF000000) >> 24) / 255.0f)
		{}

		static Color FromRGBA(uint32_t rgba)
		{
			return {
				(float)((rgba & 0xFF000000) >> 24) / 255.0f,
				(float)((rgba & 0xFF0000) >> 16) / 255.0f,
				(float)((rgba & 0xFF00) >> 8) / 255.0f,
				(float)(rgba & 0xFF) / 255.0f
			};
		}

		static Color FromARGB(uint32_t argb)
		{
			return {
				(float)((argb & 0xFF0000) >> 16) / 255.0f,
				(float)((argb & 0xFF00) >> 8) / 255.0f,
				(float)(argb & 0xFF) / 255.0f,
				(float)((argb & 0xFF000000) >> 24) / 255.0f
			};
		}

		static Color FromABGR(uint32_t abgr)
		{
			return {
				(float)(abgr & 0xFF) / 255.0f,
				(float)((abgr & 0xFF00) >> 8) / 255.0f,
				(float)((abgr & 0xFF0000) >> 16) / 255.0f,
				(float)((abgr & 0xFF000000) >> 24) / 255.0f
			};
		}

		static Color lerp(Color const& lhs, Color const& rhs, float32_t t)
		{
			return
			{
				(float32_t)lucid::math::lerp(lhs.r, rhs.r, t),
				(float32_t)lucid::math::lerp(lhs.g, rhs.g, t),
				(float32_t)lucid::math::lerp(lhs.b, rhs.b, t),
				(float32_t)lucid::math::lerp(lhs.a, rhs.a, t)
			};
		}

		template<class T>
		static Color HashColor(T const& value, int offset = 0, uint8_t alpha = 0xFF)
		{
			std::hash<T> tHasher;

			std::hash<int> iHasher;

			auto hash = uint32_t(iHasher(int(tHasher(value)) + offset));

			uint8_t r = (hash & 0xFF),
				g = ((hash >> 8) & 0xFF),
				b = ((hash >> 16) & 0xFF);
			return lucid::gal::Color(r, g, b, alpha);
		}

		uint32_t argb() const
		{
			return ( (int) (a * 255.0f) << 24) |
					((int) (r * 255.0f) << 16) |
					((int) (g * 255.0f) <<  8) |
					 (int) (b * 255.0f);
		}
		uint32_t abgr() const
		{
			return ((int) (a * 255.0f) << 24) |
			       ((int) (b * 255.0f) << 16) |
			       ((int) (g * 255.0f) <<  8) |
			        (int) (r * 255.0f);
		}

		uint32_t rgba() const
		{
			return ((int) (r * 255.0f) << 24) |
			       ((int) (g * 255.0f) << 16) |
			       ((int) (b * 255.0f) <<  8) |
			        (int) (a * 255.0f);
		}
		uint32_t bgra() const
		{
			return ((int) (b * 255.0f) << 24) |
			       ((int) (g * 255.0f) << 16) |
			       ((int) (r * 255.0f) <<  8) |
			       (int) (a * 255.0f);
		}

		float32_t *addr() const
			{
			return const_cast<float32_t *>(&r);
			}

	};

	inline Color operator*(Color const &lhs, float32_t const &rhs)
	{
		return Color(lhs.r * rhs, lhs.g * rhs, lhs.b * rhs, lhs.a);
	}

	inline bool equals(Color const& lhs, Color const& rhs, float32_t eps)
	{
		return std::abs(lhs.r - rhs.r) <= eps &&
				std::abs(lhs.g - rhs.g) <= eps &&
				std::abs(lhs.b - rhs.b) <= eps &&
				std::abs(lhs.a - rhs.a) <= eps;
	}

	inline bool operator==(Color const &lhs, Color const &rhs)
	{
		return equals(lhs, rhs, 0.f);
	}

	inline bool operator!=(Color const& lhs, Color const& rhs)
	{
		return !equals(lhs, rhs, 0.f);
	}

	inline bool operator<(Color const& lhs, Color const& rhs)
	{
		if (lhs.r < rhs.r) { return true; }
		if (lhs.r > rhs.r) { return false; }

		if (lhs.g < rhs.g) { return true; }
		if (lhs.g > rhs.g) { return false; }

		if (lhs.b < rhs.b) { return true; }
		if (lhs.b > rhs.b) { return false; }

		return lhs.a < rhs.a;
	}

	inline bool operator<=(Color const& lhs, Color const& rhs)
	{
		if (lhs.r <= rhs.r) { return true; }
		if (lhs.r >= rhs.r) { return false; }

		if (lhs.g <= rhs.g) { return true; }
		if (lhs.g >= rhs.g) { return false; }

		if (lhs.b <= rhs.b) { return true; }
		if (lhs.b >= rhs.b) { return false; }

		return lhs.a <= rhs.a;
	}

	inline bool operator>(Color const& lhs, Color const& rhs)
	{
		return rhs < lhs;
	}

	inline bool operator>=(Color const& lhs, Color const& rhs)
	{
		return rhs <= lhs;
	}

	struct HSV
	{

		float32_t h;       // angle in radians
		float32_t s;       // a fraction between 0 and 1
		float32_t v;       // a fraction between 0 and 1
		float32_t a;

		HSV() : h(0.0f), s(0.0f), v(0.0f), a(0.0f) { }

		HSV(float32_t hIn, float32_t sIn, float32_t vIn, float32_t aIn) : h(hIn), s(sIn), v(vIn), a(aIn) {}

		HSV(Color in)
		{
			a = in.a;
			float32_t      min, max, delta;

			min = in.r < in.g ? in.r : in.g;
			min = min  < in.b ? min  : in.b;

			max = in.r > in.g ? in.r : in.g;
			max = max  > in.b ? max  : in.b;

			v = max;                                // v
			delta = max - min;
			if (delta < 0.00001f)
			{
				s = 0;
				h = 0; // undefined, maybe nan?
				return;
			}
			if( max > 0.0f ) { // NOTE: if Max is == 0, this divide would cause a crash
				s = (delta / max);                  // s
			} else {
				// if max is 0, then r = g = b = 0
				// s = 0, h is undefined
				s = 0.0;
				h = NAN;                            // its now undefined
				return;
			}
			if( in.r >= max )                           // > is bogus, just keeps compilor happy
				h = ( in.g - in.b ) / delta;        // between yellow & magenta
			else
			if( in.g >= max )
				h = 2.0f + ( in.b - in.r ) / delta;  // between cyan & yellow
			else
				h = 4.0f + ( in.r - in.g ) / delta;  // between magenta & cyan

			h *= math::constants::pi<float32_t>() / 3.0f;                              // degrees

			if (h < 0.0f)
				h += math::constants::two_pi<float32_t>();
		}

		operator Color()
		{
			float32_t      hh, p, q, t, ff;
			int32_t        i;
			Color       out;

			out.a 		= a;

			if(s <= 0.0f) {       // < is bogus, just shuts up warnings
				out.r = v;
				out.g = v;
				out.b = v;
				return out;
			}
			hh = h;
			if(hh >= math::constants::two_pi<float32_t>()) hh = 0.0f;
			hh /= (math::constants::pi<float32_t>() / 3.0f);
			i = (int32_t)hh;
			ff = hh - i;
			p = v * (1.0f - s);
			q = v * (1.0f - (s * ff));
			t = v * (1.0f - (s * (1.0f - ff)));

			switch(i) {
				case 0:
					out.r = v;
					out.g = t;
					out.b = p;
					break;
				case 1:
					out.r = q;
					out.g = v;
					out.b = p;
					break;
				case 2:
					out.r = p;
					out.g = v;
					out.b = t;
					break;

				case 3:
					out.r = p;
					out.g = q;
					out.b = v;
					break;
				case 4:
					out.r = t;
					out.g = p;
					out.b = v;
					break;
				case 5:
				default:
					out.r = v;
					out.g = p;
					out.b = q;
					break;
			}
			return out;
		}
	};

	inline HSV operator*(HSV const &lhs, float32_t const &rhs)
	{
		return {lhs.h * rhs, lhs.s * rhs, lhs.v * rhs, lhs.a};
	}

	inline bool operator==(HSV const &lhs, HSV const &rhs)
	{
		return lhs.h == rhs.h &&
			   lhs.s == rhs.s &&
			   lhs.v == rhs.v &&
			   lhs.a == rhs.a;
	}

	struct HSL
	{

		float32_t h;       // angle in radians
		float32_t s;       // a fraction between 0 and 1
		float32_t l;       // a fraction between 0 and 1
		float32_t a;

		HSL() : h(0.0f), s(0.0f), l(0.0f), a(0.0f) { }

		HSL(float32_t hIn, float32_t sIn, float32_t lIn, float32_t aIn) : h(hIn), s(sIn), l(lIn), a(aIn) {}

		HSL(Color in)
		{
			a = in.a;
			float32_t min, max, delta;

			min = std::min(in.r, std::min(in.g, in.b));
			max = std::max(in.r, std::max(in.g, in.b));
			delta = max - min;

			l = 0.5f * (max + min);
			s = (l == 0.f) ? 0.f : delta / (1.f - std::abs(2.f * l - 1.f));

			float32_t numer = in.r - 0.5f * in.g - 0.5f * in.b;
			float32_t denom = std::sqrt(in.r * in.r + in.g * in.g + in.b * in.b - in.r * in.g - in.r * in.b - in.g * in.b);

			float32_t acos = std::acos(numer / denom);
			h = (in.g >= in.b) ? acos : math::constants::two_pi<float32_t>() - acos;
		}

		operator Color()
		{
			Color out;
			out.a = a;

			if (s <= 0.0f)	// < is bogus, just shuts up warnings
			{       
				out.r = l;
				out.g = l;
				out.b = l;
				return out;
			}

			float32_t c = (1.f - std::abs(2.f * l - 1.f)) * s;
			float32_t hh = h * (3.f / math::constants::pi<float32_t>());
			float32_t x = c * (1.f - std::abs(std::fmod(hh, 2.f) - 1.f));

			int32_t i = (int32_t)hh;
			switch (i) {
			case 0:
				out.r = c;
				out.g = x;
				out.b = 0;
				break;
			case 1:
				out.r = x;
				out.g = c;
				out.b = 0;
				break;
			case 2:
				out.r = 0;
				out.g = c;
				out.b = x;
				break;
			case 3:
				out.r = 0;
				out.g = x;
				out.b = c;
				break;
			case 4:
				out.r = x;
				out.g = 0;
				out.b = c;
				break;
			case 5:
			default:
				out.r = c;
				out.g = 0;
				out.b = x;
				break;
			}

			float32_t m = l - c / 2.f;

			out.r += m;
			out.g += m;
			out.b += m;

			return out;
		}
	};

	inline HSL operator*(HSL const& lhs, float32_t const& rhs)
	{
		return { lhs.h * rhs, lhs.s * rhs, lhs.l * rhs, lhs.a };
	}

	inline bool operator==(HSL const& lhs, HSL const& rhs)
	{
		return lhs.h == rhs.h &&
			lhs.s == rhs.s &&
			lhs.l == rhs.l &&
			lhs.a == rhs.a;
	}

#define saturate(x) ((x) > 1.0f ? 1.0f : (x))

	inline HSV operator+(HSV const &lhs, HSV const &rhs)
	{
		return {lhs.h + rhs.h,
				saturate(lhs.s + rhs.s),
				saturate(lhs.v + rhs.v),
				saturate(lhs.a + rhs.a)};
	}

	inline Color operator+(Color const &lhs, Color const &rhs)
	{
		return {saturate(lhs.r + rhs.r),
					 saturate(lhs.g + rhs.g),
					 saturate(lhs.b + rhs.b),
					 saturate(lhs.a + rhs.a)};
	}

	///	Viewport
	///
	///
	struct Viewport
	{
		int32_t x, y;
		int32_t width, height;
		float32_t znear, zfar;

		Viewport(int32_t x = 0, int32_t y = 0, int32_t width = 0, int32_t height = 0, float32_t znear = 0.f, float32_t zfar = 1.f)
			: x(x), y(y)
			, width(width), height(height)
			, znear(znear), zfar(zfar)
		{
		}
	};

}	///	gal
}	///	lucid

namespace lucid {
namespace math {

	inline lucid::gal::Color lerp(lucid::gal::Color color1, lucid::gal::Color color2, float t)
	{
		uint32_t abgr = lerpHexColorABGR(color1.abgr(), color2.abgr(), t);
		return lucid::gal::Color::FromABGR(abgr);
	}
} // math
} // lucid

namespace std
{

	template<>
	struct hash<lucid::gal::Color>
	{

		inline size_t operator()(lucid::gal::Color const& color) const
		{
			std::hash<float> hasher;
			return hasher(color.r) * 23 + hasher(color.g) * 23 + hasher(color.b) * 23 + hasher(color.a);
		}

	};

}

#endif