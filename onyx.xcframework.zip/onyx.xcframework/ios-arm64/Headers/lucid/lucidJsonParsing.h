#pragma once

#if !defined(LUCID_JSON_PARSING_H)
#define LUCID_JSON_PARSING_H

#include <json/jsonParsing.h>
#include <lucid/gal/Types.h>


#define JSON_HANDLER(typeName) void from_json(const nlohmann::json &j, typeName& rhs); \
void to_json(nlohmann::json& j, const typeName& req);

#define JSON_DIM_HANDLER(typeName, type, dim) void from_json(const nlohmann::json &j, typeName<type, dim>& rhs); \
void to_json(nlohmann::json& j, const typeName<type, dim>& req);

namespace lucid {
namespace math {
	JSON_DIM_HANDLER(Vector,	gal::Map3D_float_t, 2);
	JSON_DIM_HANDLER(Vector,	gal::Map3D_float_t, 3);
	JSON_DIM_HANDLER(Vector,	gal::Map3D_float_t, 4);
	JSON_DIM_HANDLER(AABB,		gal::Map3D_float_t, 2);

	JSON_HANDLER(Range<int>);
	JSON_HANDLER(Range<float32_t>);
	JSON_HANDLER(Range<float64_t>);
}
namespace gal {
	JSON_HANDLER(lucid::gal::Color);



} }

#endif