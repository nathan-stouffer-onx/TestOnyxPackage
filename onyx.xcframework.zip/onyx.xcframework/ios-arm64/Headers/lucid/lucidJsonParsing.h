#pragma once

#if !defined(LUCID_JSON_PARSING_H)
#define LUCID_JSON_PARSING_H

#include <json/jsonParsing.h>
#include <lucid/gal/Types.h>


#define JSON_HANDLER(typeName) void from_json(const nlohmann::json &j, typeName& rhs); \
void to_json(nlohmann::json& j, const typeName& req);

namespace lucid {
namespace math {

	// Vector2
	template<typename T>
	void from_json(const nlohmann::json& j, lmath::Vector<T, 2>& rhs)
	{
		JsonParsing::Require(j, "x", rhs.x, "Vector2 did not specify 'x' value");
		JsonParsing::Require(j, "y", rhs.y, "Vector2 did not specify 'y' value");
	}

	template<typename T>
	void to_json(nlohmann::json& j, const lmath::Vector<T, 2>& req)
	{
		j = { { "x", req.x}, {"y", req.y} };
	}

	// Vector3
	template<typename T>
	void from_json(const nlohmann::json& j, lmath::Vector<T, 3>& rhs)
	{
		JsonParsing::Require(j, "x", rhs.x, "Vector3 did not specify 'x' value");
		JsonParsing::Require(j, "y", rhs.y, "Vector3 did not specify 'y' value");
		JsonParsing::Require(j, "z", rhs.z, "Vector3 did not specify 'z' value");
	}
	template<typename T>
	void to_json(nlohmann::json& j, const lmath::Vector<T, 3>& req)
	{
		j = { { "x", req.x}, {"y", req.y}, { "z", req.z } };
	}

	// Vector4
	template<typename T>
	void from_json(const nlohmann::json& j, lmath::Vector<T, 4>& rhs)
	{
		JsonParsing::Require(j, "x", rhs.x, "Vector4 did not specify 'x' value");
		JsonParsing::Require(j, "y", rhs.y, "Vector4 did not specify 'y' value");
		JsonParsing::Require(j, "z", rhs.z, "Vector4 did not specify 'z' value");
		JsonParsing::Require(j, "w", rhs.w, "Vector4 did not specify 'w' value");
	}

	template<typename T>
	void to_json(nlohmann::json& j, const lmath::Vector<T, 4>& req)
	{
		j = { { "x", req.x}, {"y", req.y}, { "z", req.z }, { "w", req.w } };
	}

	// AABB 2
	template<typename T>
	void from_json(const nlohmann::json& j, lmath::AABB<T, 2>& rhs)
	{
		JsonParsing::Require(j, "min", rhs.min, "bounding box minimum ('min') not specified");
		JsonParsing::Require(j, "max", rhs.max, "bounding box maximum ('max') not specified");
	}

	template<typename T>
	void to_json(nlohmann::json& j, const lmath::AABB<T, 2>& rhs)
	{
		j = { { "min", rhs.min }, { "max", rhs.max } };
	}

	// Range
	template<typename T>
	void from_json(const nlohmann::json& j, lmath::Range<T>& rhs)
	{
		JsonParsing::Require(j, "begin", rhs.begin, "range 'begin' not specified");
		JsonParsing::Require(j, "end", rhs.end, "range 'end'  not specified");
	}

	template<typename T>
	void to_json(nlohmann::json& j, const lmath::Range<T>& rhs)
	{
		j = { { "begin", rhs.begin }, { "end", rhs.end } };
	}
}
namespace gal {
	JSON_HANDLER(lucid::gal::Color);



} }

#endif