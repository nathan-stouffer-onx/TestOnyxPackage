#include "Viewport.h"

#include <unordered_set>

#include <lucid/Profiler.h>
#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>
#include <Styling/Parse/MiscJson.h>

#include "Atlases/HeightAtlas.h"
#include "Atlases/TileAtlas.h"
#include "Caching/Tiles/TileCache.h"
#include "Caching/Tiles/Precache.h"
#include "Caching/Layers/Tasks/FillTasks.h"
#include "Caching/Layers/Tasks/LineTasks.h"
#include "Caching/Layers/Tasks/SymbolTasks.h"
#include "Caching/Layers/Tasks/HeightTileTasks.h"
#include "Camera/Controllers/Identity.h"
#include "Events/Events.h"
#include "Experimental/ParticleSystem.h"
#include "Rendering/Boxes.h"
#include "Rendering/Frustum.h"
#include "Rendering/Tiles.h"
#include "Symbol/SymbolManager.h"
#include "Symbol/Font/DefaultFonts.h"
#include "TerrainEffects/Factory.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/Timer.h"
#include "Utils/BgfxUtils.h"

namespace onyx
{

Viewport::Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
	mId(viewportId),
	mTileLoadTimeMS(Utils::Timer::nowMS(), 0.0),
	mSpritesheet(std::make_shared<Spritesheet>()),
	mDebugPrefix("viewport " + std::to_string(mId) + " -- "),
	mState(wRatio, hRatio, sortOrder),
	mController(std::make_shared<Camera::Controllers::Identity>()),
	mRenderCameraState(state),
	mCullCameraState(state),
	mZoomFilter(250.0),
	mStyle(new Styling::Style()),
	mLayerCache(new Caching::LayerCache()),
	mSkydome(new Rendering::Skydome()),
	mLineMesh(new Rendering::LineMesh()),
	mDummyTerrainHandle(Atlases::HeightAtlas::ConstructMissingHeightTileHandle())
{
#ifdef PLATFORM_EMSCRIPTEN
	mDepthStates.resize(1);
#else
	mDepthStates.resize(2);
#endif

	allocateTextures();
	allocateFramebuffers();
	
	mQuad.reset(static_cast<size_t>(getWidthPixel()), static_cast<size_t>(getHeightPixel()));

	mSymbolManager.reset(new Symbol::SymbolManager(this));
	mSymbolManager->initialize();
	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
}

Viewport::~Viewport()
{
	BgfxUtils::tryDestroy(mDummyTerrainHandle);
	deallocateTextures();
	deallocateFramebuffers();
}

bgfx::TextureHandle Viewport::getColorBuffer()
{
	if (bgfx::isValid(mColorTarg)) { return mColorTarg; }
	return BGFX_INVALID_HANDLE;
}

bgfx::TextureHandle Viewport::getDepthBuffer()
{
	if (bgfx::isValid(mDepthTarg)) { return mDepthTarg; }
	return BGFX_INVALID_HANDLE;
}

void Viewport::renderScreenLines()
{
	if (mState.getScreenLines().empty()) { return; }

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorFrameBuffer);
	bgfx::setViewName(renderId, "Draw screen-space lines");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	mScreenLineProgram.set("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA;
		;

	for (auto const& styles : mState.getScreenLines())
	{
		auto const& instances = styles.second;
		if (instances.empty()) { continue; }
		Rendering::render({ renderId, mScreenLineProgram, instances, styles.first, *mLineMesh, state });
	}
}

void Viewport::renderScreenSpaceManager()
{
	if (mScreenSpaceManager.empty() || !mState.getShowScreenSpaceManager())
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorFrameBuffer);
	bgfx::setViewName(renderId, "Draw Screen Space Manager");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	mScreenLineProgram.set("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA
		;

	screenLineVector_t instances;

	auto res = size().as<gpu_float_t>();
	auto xScale = 2.f / res.x;
	auto yScale = 2.f / res.y;

	for (auto const &screenRect : mScreenSpaceManager)
	{
		auto GPURect = screenRect.as<gpu_float_t>();
		static const std::array<int, 4> nextPts = { 1, 3, 0, 2 };

		for (int i = 0; i < lgal::gpu::AABB2d::VERTEX_COUNT(); ++i)
		{
			lgal::gpu::LineSegment2 segment(GPURect.vertex(i), GPURect.vertex(nextPts[i]));

			lgal::gpu::Vector2 p1(segment.start.x * xScale - 1, (segment.start.y * yScale - 1));

			p1.y *= -1;
			auto dir = lucid::math::normalize(segment.direction());
			dir.y *= -1;

			instances.push_back(Rendering::VertStructs::ScreenLineData(0, 0, 0xFFFF0000, { p1, 0 }, { dir, 0 }, segment.length(), 3.0 ));
		}
	}

	if (instances.empty())
	{
		return;
	}

	Rendering::render({ renderId, mScreenLineProgram, instances, "dotted", *mLineMesh, state });
}

Atlases::HeightAtlas const* Viewport::getHeightAtlas() const
{
	if (!mStyle->hasTerrain()) { return nullptr; }
	auto const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
	return static_cast<Atlases::HeightAtlas const*>(source.atlas());
}

void Viewport::update(time_float_t timeMS)
{
	time_float_t prevFrameTimeMS = mCurrentFrameTimeMS;

	mCurrentFrameTimeMS = timeMS;
	mLayerCache->setFrameTimeMS(timeMS);
	mState.mFrameRenderStats.reset();

	// check ViewportState for updated settings
	if (mState.getIsDirty()) { invalidate(); mState.setIsDirty(false); }

	// update camera
	{
		// update sources so the camera uses the most recent height atlas if there was a change
		if (mStyle->hasDirtySources()) { syncSources(); }

		Camera::CameraState newState = mController->update(mRenderCameraState, timeMS, getHeightAtlas(), mExaggeration);
		if (!newState.isValid()) { newState = mRenderCameraState; }	// only update camera if new state is valid

		// override aspect ratio and resolution with viewport value
		newState.aspect = getAspect();
		newState.resolution = getDimensions().as<screen_coord_t>();

		bool cameraWasMoving = isStale(Stale::CAMERA);
		bool cameraMoved = newState != mRenderCameraState;

		// trigger camera-related events
		toggle(Stale::CAMERA, cameraMoved);
		if (cameraMoved)
		{
			mRenderCameraState = newState;
			mRenderCameraState.updateViewProj();
			Events::trigger(Events::EventType::CAMERA_MOVED);
		}
		else if (cameraWasMoving)
		{
			Events::trigger(Events::EventType::CAMERA_STOPPED);
			lgal::world::Range r = lgal::world::Range(Utils::Timer::nowMS(), 0.0);
			mTileLoadTimeMS = r;
		}
		if (mState.getCullingEnabled()) { mCullCameraState = mRenderCameraState; }

		if (!mStyle->hasQueuedTasks())
		{
			if (cameraMoved) { mLayerCache->requestReduceLoad(); }
			else { mLayerCache->resume(); }
		}
	}

	// update style info (note that sources were updated prior to utilizing the camera)
	{
		if (mStyle->hasQueuedTasks() || mSpritesheet->recordUpdateReady())	// check if we have any queued tasks or updated the spritesheet's record
		{
			// request a pause on the prepare thread. once paused, flush the style edits and/or update spritesheet and then unpause the prepare thread
			if (mLayerCache->requestPause())
			{
				if (mStyle->hasQueuedTasks())
				{
					mStyle->flushTasks();
				}
				if (mSpritesheet->recordUpdateReady())
				{
					logI("Updating spritesheet and layer cache");
					// remove all spritesheet-dependent layers from layer cache
					for (auto const layer : mStyle->layers())
					{
						if (layer->hasAny(mStyle->initArgs(), Styling::Expressions::Dependencies::SPRITESHEET))
						{
							mLayerCache->purge(layer->id);
						}
					}
					mSpritesheet->updateRecord();
				}

				mLayerCache->resume();
			}
		}

		toggle(Stale::STYLE, mStyle->isDirty());
		if (mStyle->isDirty()) 
		{
			mark(Stale::FORCE); 
		}	// also mark FORCE because a style being dirty is caused by an API change that may impact many things
		mSpritesheet->updateAtlas();

		if (mStyle->hasTerrain())
		{
			if (!mTerrain || mStyle->hasDirtyTerrain())
			{
				std::shared_ptr<Styling::Terrain const> terrain = mStyle->terrain();
				Caching::Source const& source = Caching::TileCache::Instance()->getSource(terrain->source);
				std::shared_ptr<Styling::RasterDemSource const> specification = std::static_pointer_cast<Styling::RasterDemSource const>(source.specification());
				Atlases::HeightAtlas const* atlas = static_cast<Atlases::HeightAtlas const*>(source.atlas());
				mTerrain = { terrain, specification, atlas };
			}
		}
		else
		{
			mTerrain = {};
		}

		// update zoom
		{
			LUCID_PROFILE_SCOPE("compute zoom");
			auto old = zoomTie();

			mZoomFilter.update(timeMS);
			mZoom = computeZoom();
			mZoomFilter.push(mZoom, timeMS);
			mFilteredZoom = mZoomFilter.avg();
			mZoomKm = static_cast<float>(MapMath::zoomToKm(mZoom));
			mFilteredZoomKm = static_cast<float>(MapMath::zoomToKm(mFilteredZoom));
			// round to reduce how often zoom changes
			mZoom = Viewport::AliasZoom(mZoom);
			mFilteredZoomKm = Viewport::AliasZoom(mFilteredZoomKm);

			toggle(Stale::ZOOM, zoomTie() != old);
		}

		// update exaggeration
		{
			float exaggeration = mExaggeration;
			if (mTerrain)
			{
				mExaggeration = mStyle->terrain()->exaggeration->evaluate(expressionArgs());
				world_float_t constexpr start = 250;
				world_float_t constexpr end = 2 * start;
				world_float_t t = (mCullCameraState.position.z - start) / (end - start);
				mExaggeration = lmath::lerpstep(mExaggeration, 0.f, static_cast<float>(t));		// overwrite exaggeration if the camera is sufficiently zoomed out
			}
			else
			{
				mExaggeration = 0.f;
			}
			if (exaggeration != mExaggeration) 
			{ 
				mark(Stale::FORCE); 
			}
		}

		syncLayers();
		mStyle->update();
		if (assignPrograms()) { invalidate(); }

		// realize fog style and convert to world units
		Styling::realize(layerArgs(), mStyle->fog(), mFogStyle);
		mFogStyle = mHorizon.convert(mFogStyle, mFilteredZoomKm);
	}

	// cache updates
	{
		if (mTerrain && mExaggeration != 0.f)
		{
			time_float_t updateTimeMS = Caching::TileCache::Instance()->getSource(mTerrain.terrain->source).getUpdateTimestampMS();
			toggle(Stale::TERRAIN, updateTimeMS > mTerrainCacheUpdateMS);
			mTerrainCacheUpdateMS = updateTimeMS;
		}
		else
		{
			toggle(Stale::TERRAIN, false);
		}

		toggle(Stale::TILE_CACHE, false);
		for (std::string const& source : mStyle->activeSources())
		{
			auto updateTimeMS = Caching::TileCache::Instance()->getSource(source).getUpdateTimestampMS();
			if (updateTimeMS > mTileCacheUpdateMS)
			{
				mTileCacheUpdateMS = updateTimeMS;
				mark(Stale::TILE_CACHE);
			}
		}

		toggle(Stale::LAYER_CACHE, mLayerCache->isStale());
	}
	
	// check updaters
	time_float_t timeStep = timeMS - prevFrameTimeMS;
	{
		std::vector<std::vector<std::weak_ptr<Experimental::IUpdater>>::iterator> cleanup;
		for (auto updater = mState.mUpdaters.begin(); updater != mState.mUpdaters.end(); ++updater)
		{
			if (updater->expired())
			{
				cleanup.push_back(updater);
			}
			else
			{
				ONYX_TRY
					updater->lock()->update(this, timeStep);
				ONYX_CATCH
					logE("Updater had an error: %s", ex.what());
				ONYX_END_CATCH
			}
		}

		for (auto remove : cleanup)
		{
			mState.mUpdaters.erase(remove);
		}
	}

	// Update particle systems
	if (mGeyserParticles) { mGeyserParticles->update(timeStep); }
	if (mWindParticles) { mWindParticles->update(mRenderCameraState, timeStep); }

	touchRootTiles();

	bool oldRenderedDepth = mRenderedDepth;
	mRenderedDepth = false;

	if (mStaleFlags == Stale::NONE && mState.getQuiescenceMode()) // cached frame can be reused
	{
		std::vector<Caching::TileCacheKey> keys = Caching::keys(getFrameCullState().tileIds, *mStyle, mZoom);
		Caching::TileCache::Instance()->touch(keys);
	}
	else
	{
		if (isStale(Stale::FORCE | Stale::CAMERA | Stale::ZOOM | Stale::TERRAIN) && mState.getCullingEnabled())
		{
			LUCID_PROFILE_SCOPE("culling");
			auto& cullState = getFrameCullState();
			std::vector<Tiles::TileId> old = cullState.tileIds;
			cullState = Pyramid::cull(mCullCameraState, mState.getLODScaler(), mDeepestZoomLevel, &mZoomKm, getHeightAtlas(), mExaggeration);
			cullState.tileIds = Tiles::TileId::Filter(cullState.tileIds, mState.getTileZoomRange().begin, mState.getTileZoomRange().end);
			mCullStateChanged = cullState.tileIds != old;
		}

		render();
		toggle(Stale::FORCE, false); // Always clear this bit because "FORCE" just forces a rerender once
	}

	if (oldRenderedDepth && !mRenderedDepth)
	{
		if (++mDepthStateIndex == mDepthStates.size()) { mDepthStateIndex = 0; }
	}
}

void Viewport::render()
{
	mScreenSpaceManager.clear();

	if (mSkydome)
	{
		Styling::realize(layerArgs(), mStyle->skydome(), mSkydomeStyle);
		
		bgfx::ViewId id = allocateViewId(mDebugPrefix + "skydome", mColorFrameBuffer, mSkydomeStyle.hazeColor.rgba(), 1.0f, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH);
		mSkydomeProgram.set("u_SkyColor", mSkydomeStyle.skyColor);
		mSkydomeProgram.set("u_HazeColor", mSkydomeStyle.hazeColor);
		mSkydomeProgram.set("u_HazeStrength", lgal::gpu::Vector2(mSkydomeStyle.alpha, mSkydomeStyle.bandPow ));
		mSkydome->render(id, mRenderCameraState, mSkydomeProgram);
	}

	renderTiles();
	renderSymbols();

	renderScreenLines();
	renderScreenSpaceManager();

	if (mTerrain)
	{
		lgal::gpu::Vector2 screenSize = lgal::gpu::Vector2{ getWidthPixel(), getHeightPixel() };

		if (mWindParticles)
		{
			mWindParticles->draw(Tiles::TileId(2, 0, 1), mRenderCameraState, *mTerrain.atlas, screenSize, mColorFrameBuffer);
		}
		if (mGeyserParticles)
		{
			mGeyserParticles->draw(mRenderCameraState,  *mTerrain.atlas, screenSize, mColorFrameBuffer);
		}
	}

	if (mState.getShowFrustum())
	{
		bgfx::ViewId viewId = allocateViewId(mDebugPrefix + "frustum", mColorFrameBuffer, 0x00000000, 1.f, BGFX_CLEAR_NONE);
		Rendering::Frustum::render(viewId, mFrustumProgram, mRenderCameraState.position, Camera::Frustum(mCullCameraState));
	}

	if (mState.getShowFrustumAABB())
	{
		bgfx::ViewId viewId = allocateViewId(mDebugPrefix + "frustum aabb", mColorFrameBuffer, 0x00000000, 1.f, BGFX_CLEAR_NONE);
		Rendering::Boxes::render(viewId, mBoxProgram, mRenderCameraState.position, Camera::Frustum(mCullCameraState).aabb(), 0.5f);
	}

	if (mState.getShowTileBoxes())
	{
		bgfx::ViewId viewId = allocateViewId(mDebugPrefix + "tile boxes", mColorFrameBuffer, 0x00000000, 1.f, BGFX_CLEAR_NONE);
		std::vector<lgal::world::AABB3d> boxes;
		boxes.reserve(getFrameCullState().tileIds.size());
		Atlases::HeightAtlas const* atlas = getHeightAtlas();
		for (Tiles::TileId const& tileId : getFrameCullState().tileIds)
		{
			lgal::world::AABB2d bounds = tileId.worldBounds<world_float_t>();
			lgal::height::Range extents = ((atlas) ? atlas->extents(tileId, true) : lgal::height::Range(0, 0)) * mExaggeration;
			boxes.push_back({ lgal::world::Vector3(bounds.min, extents.begin), lgal::world::Vector3(bounds.max, extents.end) });
		}
		Rendering::Boxes::render(viewId, mBoxProgram, mRenderCameraState.position, boxes, mState.getTileBoxOpacity());
	}

	mState.mLifetimeRenderStats += mState.mFrameRenderStats;
	swapTripleBuffers();

	if (mRenderedDepth)
	{
		DepthState& state = mDepthStates[mDepthStateIndex];

		lgal::screen::Vector2 res = mRenderCameraState.resolution;
		if (!bgfx::isValid(state.handle) || state.camera.resolution != res)
		{
			BgfxUtils::tryDestroy(state.handle);
			state.handle = bgfx::createTexture2D(uint16_t(res.x), uint16_t(res.y), false, 1, bgfx::TextureFormat::RGBA8, BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP);
			bgfx::setName(state.handle, (mDebugPrefix + " viewport depth readback buffer").c_str());
		}
		
		auto size = res.x * res.y * 4 * sizeof(uint8_t);
		if (state.bytes.size() < size)
		{
			state.bytes.resize(size);
			std::memset(state.bytes.data(), 0xFF, state.bytes.size());
		}

		bgfx::blit(Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw), state.handle, 0, 0, mDepthTarg);
		bgfx::readTexture(state.handle, state.bytes.data());

		state.camera = mRenderCameraState;
		if (++mDepthStateIndex == mDepthStates.size()) { mDepthStateIndex = 0; }
	}
}

void Viewport::copyDepth(std::vector<uint8_t>& target) const
{
	std::vector<uint8_t> bytes = mDepthStates[mDepthStateIndex].bytes;
	target.resize(bytes.size());
	std::copy(bytes.begin(), bytes.end(), target.begin());
}

void Viewport::copyColor(std::vector<uint8_t> &target, uint8_t defaultValue) const
{
	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(uint32_t);
	if (target.size() != dataSize)
	{
		target.resize(dataSize);
		if (defaultValue != 0)
		{
			std::memset(target.data(), defaultValue, target.size());
		}
	}

	auto data = target.data();
	bgfx::blit(viewId, mColorReadbackHandle, 0, 0, mColorTarg);
	bgfx::readTexture(mColorReadbackHandle, data);
}

void Viewport::resize()
{
	// set the camera state aspect
	setController(std::make_shared<Camera::Controllers::Identity>());

	// reallocate textures of the appropriate size
	deallocateTextures();
	allocateTextures();

	// reallocate frame buffers with those textures
	deallocateFramebuffers();
	allocateFramebuffers();

	mQuad.reset(static_cast<size_t>(getWidthPixel()), static_cast<size_t>(getHeightPixel()));

	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
	invalidate();
}

void Viewport::setController(std::shared_ptr<Camera::CameraController> controller)
{
	mController = controller;
}

void Viewport::setCameraState(Camera::CameraState const& state)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mRenderCameraState = state;
}

gpu_float_t Viewport::depthAtPixel(lgal::screen::Vector2 const pos) const
{
	DepthState const& state = mDepthStates[mDepthStateIndex];
	size_t y = size_t(pos.y);
	if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
	{
		y = size_t(state.camera.resolution.y) - 1 - y;
	}
	auto i = (size_t(pos.x) + (y * size_t(state.camera.resolution.x))) * 4;
	if (i < state.bytes.size())
	{
		auto r = state.bytes[i + 0] * (1.f / 255.f);
		auto g = state.bytes[i + 1] * (1.f / 255.f);
		auto b = state.bytes[i + 2] * (1.f / 255.f);
		auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
		return result;
	}
	return -1;
}

gpu_float_t Viewport::depthAtNormalized(lgal::gpu::Vector2 const& pos) const
{
	// convert from normalized to uv cooridinates
	lgal::gpu::Vector2 dimensions = getDimensions();
	lgal::gpu::Vector2 uv = 0.5f * (pos + lgal::gpu::Vector2(1.f));
	lgal::gpu::Vector2 screen = lmath::clamp(lmath::hadamard(uv, dimensions), lgal::gpu::Vector2(0.f), dimensions - lgal::gpu::Vector2(1.f));
	return depthAtPixel(screen.as<screen_coord_t>());
}

lgal::world::Vector3 Viewport::unprojectPixel(lgal::screen::Vector2 const pos) const
{
	lgal::gpu::Vector2 dimensions = getDimensions();
	lgal::gpu::Vector2 normalized(static_cast<float>(pos.x) / dimensions.x, static_cast<float>(pos.y) / dimensions.y);
	normalized = 2.f * normalized - lgal::gpu::Vector2(1.f);
	return unprojectNormalized(normalized);
}

lgal::world::Vector3 Viewport::unprojectNormalized(lgal::gpu::Vector2 const& pos) const
{
	return unprojectNormalized(pos, depthAtNormalized(pos));
}

lgal::world::Vector3 Viewport::unprojectNormalized(lgal::gpu::Vector2 const& pos, world_float_t const depth) const
{
	Camera::CameraState const& camera = mDepthStates[mDepthStateIndex].camera;
	Camera::CameraState::ProjectionData projected = camera.unproject({ pos.as<world_float_t>(), depth * 2.0 - 1.0 });
	lgal::world::Vector3 result = projected.position;

	// override z with a more accurate value
	if (mTerrain)
	{
		auto distortedHeightKm = mTerrain.atlas->heightAt(MapMath::moduloX(result.xy));
		distortedHeightKm *= mExaggeration;
		result.z = distortedHeightKm;
	}
	else
	{
		result.z = 0.0;
	}

	return result;
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector2 const& pos) const
{
	// compute z with a more accurate value
	height_float_t z = 0.0;
	if (mTerrain)
	{
		auto distortedHeightKm = mTerrain.atlas->heightAt(MapMath::moduloX(pos));
		distortedHeightKm *= mExaggeration;
		z = distortedHeightKm;
	}
	return project(lgal::world::Vector3{ pos, z });
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector3 const& pos) const
{
	Camera::CameraState::ProjectionData projected = mRenderCameraState.project(pos);
	return projected.position;
}

float Viewport::computeZoom() const
{
	lgal::world::Vector3 eye = mRenderCameraState.position;
	if (mState.getZoomMode() == ZoomMode::CENTER)
	{
		lgal::world::Vector3 center = unprojectNormalized(lgal::gpu::Vector2{ 0.f, 0.f });
		world_float_t dist = lmath::len(eye - center);
		return static_cast<float>(MapMath::zoom(dist));
	}
	else
	{
		// start off by computing the zoom in one of two reasonable locations
		lgal::world::Vector3 center = unprojectNormalized(lgal::gpu::Vector2{ 0.f, 0.f });
		lgal::world::Vector3 bottom = unprojectNormalized(lgal::gpu::Vector2{ 0.f, 1.f });
		world_float_t dist = std::min(lmath::len(eye - center), lmath::len(eye - bottom));

		// if the depth is close enough, add some more sample locations
		size_t count = 1;
		int height = static_cast<int>(mState.getHeightPixel());
		int width = static_cast<int>(mState.getWidthPixel());
		int steps = 20;
		for (int y = height / 2; y < height; y += height / steps)
		{
			for (int x = width / 2; x < width; x += width / steps)
			{
				lgal::screen::Vector2 pos(x, y);
				if (depthAtPixel(pos) < 1.f)
				{
					dist += lmath::len(eye - unprojectPixel(pos));
					++count;
				}
			}
		}

		// average the distances, then compute and return the zoom
		if (count > 0) { dist /= static_cast<world_float_t>(count); }
		world_float_t zoom = MapMath::zoom(dist);
		return static_cast<float>(zoom);
	}
}

void Viewport::setMatrixUniforms(bgfx::ViewId const& viewId)
{
	mRenderCameraState.updateViewProj();
	bgfx::setViewTransform(viewId, mRenderCameraState.view.data(), mRenderCameraState.proj.data());
	bgfx::setViewRect(viewId, 0, 0, static_cast<uint16_t>(getWidthPixel()), static_cast<uint16_t>(getHeightPixel()));
}

bgfx::ViewId Viewport::allocateViewId(std::string const& name, bgfx::FrameBufferHandle handle, uint32_t rgba, float depth, uint16_t flags)
{
	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewName(viewId, name.c_str());
	bgfx::setViewMode(viewId, bgfx::ViewMode::Sequential);
	bgfx::setViewFrameBuffer(viewId, handle);
	bgfx::setViewClear(viewId, flags, rgba, depth);
	setMatrixUniforms(viewId);
	return viewId;
}

void Viewport::renderTiles()
{
	std::vector<Tiles::TileId> tileIds = getFrameCullState().tileIds;

	{
		Camera::CameraState const& state = mCullCameraState;
		lgal::world::Vector3 center = state.position + static_cast<world_float_t>(mZoomKm) * state.rayDir({ 0, 0 });
		std::vector<Tiles::TileId> sorted = Pyramid::sorted(Tiles::TileId::Filter2D(tileIds, mCullCameraState.position, mFogStyle.range.y), center.xy);
		std::vector<Tiles::TileId> grandparents = Tiles::TileId::UniqueParents(sorted, 2);

		{
			LUCID_PROFILE_SCOPE("precache tiles");
			std::vector<Caching::TileCacheKey> keys = Caching::keys(grandparents, *mStyle, mZoom);
			Caching::TileCache::Instance()->precache(keys);
			keys = Caching::keys(sorted, *mStyle, mZoom);
			Caching::TileCache::Instance()->precache(keys);

			// precache tiles associated with the controller's highlight states
			for (auto const& highlight : mController->highlights())
			{
				Pyramid::CullResult cullRes = Pyramid::cull(highlight, mState.getLODScaler(), mDeepestZoomLevel, &mZoomKm, getHeightAtlas(), mExaggeration);
				keys = Caching::keys(Tiles::TileId::UniqueParents(cullRes.tileIds, 2), *mStyle, mZoom);
				// only continue processing if the tiles are precached
				if (!Caching::TileCache::Instance()->precache(keys))
				{
					break;
				}
			}
		}

		{
			Caching::LayerCache::LockT lock = mLayerCache->lock();
			prepare(grandparents, lock);
			prepare(sorted, lock);
			mLayerCache->update(lock);
		}
	}

	{
		LUCID_PROFILE_SCOPE("prepare pseudorasters");
		for (auto const& layer : mStyle->visibleShaderLayers(mZoom))
		{
			std::string const& id = layer->id;
			auto it = mTerrainEffects.find(id);
			if (it != mTerrainEffects.end() && it->second->isVisible())
			{
				std::unique_ptr<TerrainEffects::TerrainEffectBase> const& effect = it->second;
				effect->prepare({ *layer, mRenderCameraState, getFrameCullState(), layerArgs(), mHorizon, mSpritesheet, mZoom, mFilteredZoomKm, mCurrentFrameTimeMS });
			}
		}
	}

	Tiles::Gathered gathered = gather(tileIds);

	if (isStale(Stale::FORCE | Stale::CAMERA | Stale::TERRAIN) || mCullStateChanged)
	{
		LUCID_PROFILE_SCOPE("render depth");
		bgfx::ViewId viewId = allocateViewId(mDebugPrefix + "depth", mDepthFrameBuffer, 0xFFFFFFFF, 1.f, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH);
		uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | static_cast<uint64_t>(Styling::DepthTest::LESS);
		for (Tiles::Gathered::Info const& info : gathered)
		{
			Rendering::render({ viewId, mRenderCameraState, mDepthProgram, info.terrain, info.pseudoraster, mExaggeration, state });
		}
		mRenderedDepth = true;
	}

	{
		LUCID_PROFILE_SCOPE("render tiles");
		bgfx::ViewId viewId = allocateViewId(mDebugPrefix + "tile group 0", mColorFrameBuffer, 0xaaeeffff, 1.f, (mSkydome) ? 0 : BGFX_CLEAR_COLOR);
		size_t group = 0;
		for (std::shared_ptr<Styling::Layer const> layer : mStyle->visibleLayers(mZoom))
		{
			if (layer->isShader() && mState.getShowPseudoRasters())
			{
				if (group == 0)		// if this is the first layer that is rendered, update the clear state appropriately
				{
					uint16_t clear = (mSkydome) ? 0 : BGFX_CLEAR_COLOR;
					bgfx::setViewClear(viewId, clear | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.f);
				}
				else				// otherwise, set up a new view id that just clears the depth state
				{
					viewId = allocateViewId(mDebugPrefix + "tile group " + std::to_string(group), mColorFrameBuffer, 0x00000000, 1.f, BGFX_CLEAR_DEPTH);
				}

				Tiles::TileId::IdCoordsT minzoom = 0;
				lgal::world::AABB2d bounds = Styling::Source::Bounds::Default().aabb();
				if (layer->isSourced())
				{
					Styling::SourcedLayer const& sourced = static_cast<Styling::SourcedLayer const&>(*layer);
					Caching::Source const& source = Caching::TileCache::Instance()->getSource(sourced.source);
					minzoom = source.specification()->minZoom;
					bounds = source.specification()->bounds.aabb();
				}
				
				uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | static_cast<uint64_t>(Styling::DepthTest::LESS);
				for (Tiles::Gathered::Info const& info : gathered)
				{
					if (minzoom <= info.id.level && info.terrain.distance <= mFogStyle.range.y)
					{
						if (lmath::intersectsOrTouches(bounds, info.terrain.globeBounds))
						{
							LUCID_PROFILE_SCOPE("pseudorasters");
							Shaders::Program& program = mPseudoRasterPrograms[static_cast<size_t>(Shaders::TiledPseudoRasters::convert(layer->type))];
							Rendering::render({ viewId, mRenderCameraState, program, info.terrain, info.pseudoraster, *mTerrainEffects[layer->id], mExaggeration, mZoomKm, state });
						}
					}
				}

				++group;
			}
			else if (layer->type == Styling::Layer::Types::FILL && mState.getShowFills())
			{
				render(viewId, static_cast<Styling::FillLayer const&>(*layer), gathered);
			}
			else if (layer->type == Styling::Layer::Types::LINE && mState.getShowLines())
			{
				render(viewId, static_cast<Styling::LineLayer const&>(*layer), gathered);
			}
		}
	}

	{
		LUCID_PROFILE_SCOPE("render fog");
		bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::setViewRect(viewId, 0, 0, bgfx::BackbufferRatio::Equal);
		bgfx::setViewClear(viewId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
		bgfx::setViewFrameBuffer(viewId, mColorFrameBuffer);
		bgfx::setViewTransform(viewId, mQuad.view().data(), mQuad.proj().data());
		bgfx::setViewName(viewId, (mDebugPrefix + "fog").c_str());
		bgfx::setViewMode(viewId, bgfx::ViewMode::Sequential);

		lgal::gpu::Vector2 tl(0, bgfx::getCaps()->originBottomLeft ? mState.getHeightPixel() : 0);
		lgal::gpu::Vector2 br(tl.x + mState.getWidthPixel(), tl.y + mState.getHeightPixel());

		std::array<float, 16> mtx = { 0 };
		bx::mtxInverse(mtx.data(), mRenderCameraState.proj.data());

		mFogProgram.set("u_Corners", lgal::gpu::Vector4(tl, br));
		mFogProgram.set("u_FogColor", mFogStyle.color);
		mFogProgram.set("u_FogTransition", mFogStyle.range);
		mFogProgram.set("u_Unproject", mtx);
		mFogProgram.set("s_Depth", mDepthTarg, size(), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);

		bgfx::setVertexBuffer(0, mQuad.vertexHandle());
		bgfx::setIndexBuffer(mQuad.indexHandle());

		uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_BLEND_ALPHA | BGFX_STATE_DEPTH_TEST_ALWAYS | BGFX_STATE_PT_TRISTRIP;
		bgfx::setState(state);
		bgfx::submit(viewId, mFogProgram.handle());
	}
}

template<typename LayerType>
bool Viewport::gatherSymbols()
{
	bool complete = true;
	std::vector<Tiles::TileId> tileIds = Tiles::TileId::Filter2D(getFrameCullState().tileIds, mCullCameraState.position, mFogStyle.range.y);
	for (auto const& layer : mStyle->visibleLayers<LayerType>(mZoom))
	{
		for (auto iter = tileIds.rbegin(); iter != tileIds.rend(); ++iter)
		{
			auto const& tileId = *iter;
			Caching::LayerCache::EntryKey key = { tileId, layer->id };

			if (mLayerCache->isPrepared(key))
			{
				Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
				auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
				auto& preparedSymbols = prepared->symbols();
				mFrameSymbols.insert(mFrameSymbols.end(), preparedSymbols.begin(), preparedSymbols.end());
			}
			else
			{
				complete = false;
			}
		}
	}
	return complete;
}

void Viewport::gatherSymbols()
{
	for (auto const& [key, symbols] : mState.mSymbolCollection.getSymbolsMap())
	{
		mFrameSymbols.insert(mFrameSymbols.end(), symbols.begin(), symbols.end());
	}

	// TODO we have to refactor this code at some point. viewports shouldn't have to add the terrain effect labels on a per frame basis
	for (auto const& [name, effect] : mTerrainEffects)
	{
		if (effect->isVisible())
		{
			effect->getLabels(mFrameSymbols);
		}
	}

	gatherSymbols<Styling::SymbolLayer>();
	gatherSymbols<Styling::ContourLabelLayer>();
}

void Viewport::renderSymbols()
{
	LUCID_PROFILE_SCOPE("symbol render");

	mSymbolManager->update();

	mFrameSymbols.clear();
	gatherSymbols();
	bool done = true;
	if (mState.getShowSymbols())
	{
		done &= mSymbolManager->draw(mScreenSpaceManager, mFrameSymbols, mColorFrameBuffer, *mSpritesheet->getImageAtlas(), getHeightAtlas(), mCurrentFrameTimeMS);
		// TODO (Ronald): (CSONYX-318) I *really* don't like this solution, but getting override symbols rendering above everything else quickly takes precedence
		done &= mSymbolManager->drawOverrideSymbols(mScreenSpaceManager, mOverrideSymbols, mColorFrameBuffer, *mSpritesheet->getImageAtlas(), getHeightAtlas());

		/// TODO (scott CSONYX-167)
		// Don't like having this here but it prevents the Symbol Manager from "completing" early before the depth buffer
		// has been read back.
		// We might need to add an overall "System is still initializing" flag for the first couple of frames.
		done = done && mDepthStates[mDepthStateIndex].bytes.size() > 0;
	}
	toggle(Stale::ANIMATIONS, !done);
}

void Viewport::allocateTextures()
{
	mColorTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP);
	mDepthTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP);
	mColorReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP);

	mZBufferFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
	mZTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, mZBufferFormat, BGFX_TEXTURE_RT);
	
	bgfx::setName(mColorTarg,           (mDebugPrefix + " viewport color tex").c_str());
	bgfx::setName(mDepthTarg,           (mDebugPrefix + " viewport float depth texture").c_str());
	bgfx::setName(mColorReadbackHandle, (mDebugPrefix + " viewport color readback texture").c_str());
	bgfx::setName(mZTarg,               (mDebugPrefix + " viewport z buffer").c_str());
}

void Viewport::deallocateTextures()
{
	BgfxUtils::tryDestroy(mColorTarg);
	BgfxUtils::tryDestroy(mDepthTarg);
	BgfxUtils::tryDestroy(mZTarg);
	BgfxUtils::tryDestroy(mColorReadbackHandle);
}

void Viewport::allocateFramebuffers()
{
	// first deallocate all the old frame buffers
	deallocateFramebuffers();

	{
		bgfx::TextureHandle handles[] = { mColorTarg, mZTarg };
		mColorFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(handles), handles, false);
		if (bgfx::isValid(mColorFrameBuffer)) { bgfx::setName(mColorFrameBuffer, (std::to_string(mId) + " viewport color/z framebuffer").c_str()); }
	}

	{
		bgfx::TextureHandle handles[] = { mDepthTarg, mZTarg };
		mDepthFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(handles), handles, false);
		if (bgfx::isValid(mDepthFrameBuffer)) { bgfx::setName(mDepthFrameBuffer, (std::to_string(mId) + " viewport color/depth/z framebuffer").c_str()); }
	}
}

void Viewport::deallocateFramebuffers()
{
	BgfxUtils::tryDestroy(mColorFrameBuffer);
	BgfxUtils::tryDestroy(mDepthFrameBuffer);
}

void Viewport::invalidate()
{
	mStaleFlags |= Stale::FORCE; // Force an update
}

void Viewport::propertyChanged(const char*)
{
	invalidate();
}

void Viewport::setStyle(std::shared_ptr<Styling::Style> style)
{
	mStyle = style;
	mLayerCache->clear();
	syncSources();
	invalidate();

	if (mStyle->hasSpriteUrl())
	{
		mSpritesheet->reset(style->spritesheetUrl(), mState.getSpritesheetSize());
	}

	// Reset font cache
	Font::M3DFontManager::reset(Font::getRobotoRegularConfig());
	mSymbolManager->resetFontManager();

	Font::M3DFontManager::addFontConfig({ Font::s_topoLabel, 9, Styling::TextFontTypes::DistanceOutline }, Font::s_topoLabelId);
	Font::M3DFontManager::addTTF(Font::s_atlasGrotesk, Font::s_atlasGroteskFile);
	Font::M3DFontManager::addTTF(Font::s_montefiore, Font::s_montefiorePath);
	Font::M3DFontManager::addTTF(onyx::Font::s_robotoMono, s_robotoMonoRegularTtf, s_robotoMonoRegularTtf_size);
}

void Viewport::purge(bool immediate)
{
	for (auto const& [key, value] : *mLayerCache)
	{
		mLayerCache->purge(key, immediate);
	}
	invalidate();
}

void Viewport::syncSources()
{
	Styling::Source::zoom_level_t maxZoom = 0;
	for (auto const& name : mStyle->activeSources())
	{
		std::shared_ptr<Styling::Source const> source = mStyle->source(name);
		if (source->isHeight())
		{
			auto dem = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			maxZoom = std::max(maxZoom, MapMath::maxDetailZoom(dem->tileSize, dem->maxZoom));
		}
		else
		{
			maxZoom = std::max(maxZoom, source->maxZoom);
		}
	}
	mDeepestZoomLevel = maxZoom;

	// add all dirty sources to TileCache
	for (std::string const& name : mStyle->dirtySourceNames())
	{
		// if TileCache already knows about a tiled source, it won't do anything
		Caching::TileCache::Instance()->addSource(name, mStyle->source(name));
	}

	touchRootTiles();
}

void Viewport::syncLayers()
{
	// utilize a const& to avoid overload confusion with private non-const methods of Style
	Styling::Style const& style = *mStyle;

	// NOTE: removing must occur first for correctness
	for (std::string const& id : style.removedLayerIds())
	{
		mTerrainEffects.erase(id);		// ignored if the layer is not present
		mLayerCache->purge(id, true);
	}

	// if necessary, allocate a terrain effect
	for (std::string const& id : style.addedLayerIds())
	{
		if (std::unique_ptr<TerrainEffects::TerrainEffectBase> effect = TerrainEffects::construct(style.layer(id)->type))
		{
			mTerrainEffects[id] = std::move(effect);
		}
	}

	// compute all updated layers
	std::set<std::string> updated = style.addedLayerIds();
	updated.insert(style.editedLayerIds().begin(), style.editedLayerIds().end());
	for (std::string const& id : updated)
	{
		// update LayerCache with a non-immediate purge of all updated layers
		mLayerCache->purge(id, false);
	}

	// sync visibility for terrain effects
	for (auto const& layer : style.layers())
	{
		auto found = mTerrainEffects.find(layer->id);
		if (found != mTerrainEffects.end())
		{
			bool enabled = layer->isVisible() && layer->range().contains(mZoom);
			found->second->toggle(enabled);
		}
	}
}

void Viewport::touchRootTiles()
{
	// prefetch the top level tiles
	for (auto const& [name, source] : mStyle->sources())
	{
		if (source->minZoom == 0)
		{
			Caching::TileCache::Instance()->at({ name, { 0, 0, 0 } });
		}
	}
}

Styling::Expressions::Arguments Viewport::expressionArgs() const
{
	return
	{
		mZoom,
		lmath::radiansToDegrees(mRenderCameraState.heading),
		lmath::radiansToDegrees(mRenderCameraState.pitch),
		mSpritesheet->getImageRecord(),
		0.0,	// center distance only matters for symbol layers, which should be prepared by LayerCache
		mStyle->getExpressionContext(),
		mState.getDpiScalar()
	};
}

Styling::Arguments Viewport::layerArgs() const
{
	return { { expressionArgs() }, mStyle->getLayoutContext(), mStyle->getPaintContext(), mStyle->getEffectContext() };
}

uint16_t Viewport::computeMeshResolution(Tiles::TileId const& tileId) const
{
	return (mTerrain && mExaggeration != 0.f) ? MapMath::meshResolution(mTerrain.source->tileSize, mTerrain.maxZoom(), tileId) : 1;
}

Caching::PreparedData::Metadata Viewport::computeMetadata(Tiles::TileId const& tileId, Styling::Layer const& layer, time_float_t const timestampMS, uint16_t const meshResolution) const
{
	return
	{
		layer.type,
		layer.dependencies(mStyle->initArgs()),
		layer.filter->dependencies(mStyle->getExpressionContext()),
		tileId,
		timestampMS,
		mZoom,
		mRenderCameraState,
		meshResolution,
		mSpritesheet->getImageRecord(),
		mStyle->getExpressionContext(),
		mStyle->getLayoutContext(),
		mStyle->getPaintContext(),
		mStyle->getEffectContext(),
		mState.getDpiScalar()
	};
}

bool Viewport::assignPrograms()
{
	if (!mAssignedPrograms)
	{
		size_t count = static_cast<size_t>(Shaders::TiledPseudoRasters::LayerTypes::COUNT);
		mPseudoRasterPrograms.resize(count);
		for (size_t i = 0; i < count; ++i)
		{
			Shaders::Program& program = mPseudoRasterPrograms[i];
			if (!program.isValid()) { program = Shaders::load(Shaders::TiledPseudoRasters::Options{ static_cast<Shaders::TiledPseudoRasters::LayerTypes>(i), true }); }
		}

		if (!mFillProgram.isValid()) { mFillProgram = Shaders::load(Shaders::TiledFills::Options{ true }); }
		if (!mLineProgram.isValid()) { mLineProgram = Shaders::load(Shaders::TiledLines::Options{ true, true }); }
		if (!mDepthProgram.isValid()) { mDepthProgram = Shaders::load(Shaders::TiledEncodings::Options{ Shaders::TiledEncodings::EncodedTypes::DEPTH, true }); }
		if (!mSkydomeProgram.isValid()) { mSkydomeProgram = Shaders::load(Shaders::Handwritten::cSkydome, false); }
		if (!mFogProgram.isValid()) { mFogProgram = Shaders::load(Shaders::Handwritten::cFog, false); }
		if (!mScreenLineProgram.isValid()) { mScreenLineProgram = Shaders::load(Shaders::Handwritten::cScreenLines, true); }
		if (!mBoxProgram.isValid()) { mBoxProgram = Shaders::load(Shaders::Handwritten::cPosColor, false); }
		if (!mFrustumProgram.isValid()) { mFrustumProgram = Shaders::load(Shaders::Handwritten::cPosColor, false); }

		mAssignedPrograms = true;
		return true;
	}
	return false;	// fallthrough to return false
}

void Viewport::prepare(std::vector<Tiles::TileId> const& tiles, Caching::LayerCache::LockT const& lock)
{
	LUCID_PROFILE_SCOPE("prepare vectors");

	std::vector<TileTuple> tuples;
	{
		lgal::world::Vector3 const& eye = mCullCameraState.position;
		tuples.reserve(tiles.size());
		for (Tiles::TileId const& tileId : tiles)
		{
			lgal::world::AABB3d aabb = (mTerrain) ? mTerrain.atlas->aabb(tileId, true) : lgal::world::AABB3d({ tileId.northwestCorner(), 0.0 }, { tileId.southeastCorner(), 0.0 });
			tuples.push_back({ tileId, MapMath::toGlobeBounds(tileId.moduloX().worldBounds<world_float_t>()), aabb.distanceTo(eye)});
		}
	}

	for (auto const& layer : mStyle->visibleVectorLayers<Styling::SourcedLayer>(mZoom))		// loop over all layers
	{
		LUCID_PROFILE_SCOPE("layers");
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
		if (layer->type == Styling::Layer::Types::CONTOUR_LABEL && mState.getShowSymbols())
		{
			LUCID_PROFILE_SCOPE("contour labels");
			auto downcast = std::static_pointer_cast<Styling::ContourLabelLayer const>(layer);
			prepare<Styling::ContourLabelLayer const>(tuples, downcast, source, mFogStyle.range.y, lock);
		}
		else if (layer->type == Styling::Layer::Types::FILL && mState.getShowFills())
		{
			LUCID_PROFILE_SCOPE("fills");
			auto downcast = std::static_pointer_cast<Styling::FillLayer const>(layer);
			Styling::FillStyle::Effect effect = mHorizon.convert(downcast->effect(layerArgs()), mFilteredZoomKm);	// realize effect and convert to world space units
			prepare<Styling::FillLayer const>(tuples, downcast, source, std::min(mFogStyle.range.y, effect.fadeRange.y), lock);
		}
		else if (layer->type == Styling::Layer::Types::LINE && mState.getShowLines())
		{
			LUCID_PROFILE_SCOPE("lines");
			auto downcast = std::static_pointer_cast<Styling::LineLayer const>(layer);
			Styling::LineStyle::Effect effect = mHorizon.convert(downcast->effect(layerArgs()), mFilteredZoomKm);	// realize effect and convert to world space units
			prepare<Styling::LineLayer const>(tuples, downcast, source, std::min(mFogStyle.range.y, effect.fadeRange.y), lock);
		}
		else if (layer->type == Styling::Layer::Types::SYMBOL && mState.getShowSymbols())
		{
			LUCID_PROFILE_SCOPE("symbols");
			auto downcast = std::static_pointer_cast<Styling::SymbolLayer const>(layer);
			prepare<Styling::SymbolLayer const>(tuples, downcast, source, mFogStyle.range.y, lock);
		}
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::ContourLabelLayer const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock)
{
	if (source.type() != Styling::Source::Types::RASTER_DEM) { return; }
	Atlases::HeightAtlas const* heightAtlas = static_cast<Atlases::HeightAtlas const*>(source.atlas());
	if (!heightAtlas->contains(tileId)) { return; }
	auto heightTile = heightAtlas->at(tileId);

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(heightTile->id(), *layer, heightTile->timestampMS(), computeMeshResolution(tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end() || mLayerCache->replaces(key, metadata, lock))
	{
		mLayerCache->insert(key, std::make_unique<Caching::Tasks::ContourLabelTask>(tileId, metadata, layer, heightTile), found, lock);
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::FillLayer const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock)
{
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	auto tileIter = pyramid->find(tileId, true);
	if (tileIter == pyramid->end()) { return; }
	std::shared_ptr<Tiles::VectorTile const> const& vectorTile = tileIter->second;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, vectorTile->timestampMS(layer->sourceLayer), computeMeshResolution(tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end())
	{
		mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
	}
	else if (mLayerCache->replaces(found, metadata, lock))
	{
		if (mLayerCache->restyles(found, metadata))
		{
			Caching::LayerCache::Entry const& entry = found->entry;
			auto existing = std::static_pointer_cast<Caching::PreparedFillData const>(entry.prepared);
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::RestyleFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, existing), found, lock);
		}
		else
		{
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
		}
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::LineLayer const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock)
{
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	auto tileIter = pyramid->find(tileId, true);
	if (tileIter == pyramid->end()) { return; }
	std::shared_ptr<Tiles::VectorTile const> const& vectorTile = tileIter->second;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, vectorTile->timestampMS(layer->sourceLayer), computeMeshResolution(tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end())
	{
		mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
	}
	else if (mLayerCache->replaces(found, metadata, lock))
	{
		if (mLayerCache->restyles(found, metadata))
		{
			Caching::LayerCache::Entry const& entry = found->entry;
			auto existing = std::static_pointer_cast<Caching::PreparedLineData const>(entry.prepared);
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::RestyleLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, existing), found, lock);
		}
		else
		{
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
		}
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::SymbolLayer const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock)
{
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	auto tileIter = pyramid->find(tileId, true);
	if (tileIter == pyramid->end()) { return; }
	std::shared_ptr<Tiles::VectorTile const> const& vectorTile = tileIter->second;

	Atlases::HeightAtlas const* heightAtlas = getHeightAtlas();
	std::shared_ptr<Tiles::HeightTile const> heightTile = (heightAtlas) ? heightAtlas->find(tileId, true) : nullptr;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	time_float_t timestampMS = std::max(vectorTile->timestampMS(layer->sourceLayer), heightTile ? heightTile->timestampMS() : 0.0);
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, timestampMS, computeMeshResolution(tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end() || mLayerCache->replaces(key, metadata, lock))
	{
		auto task = std::make_unique<Caching::Tasks::FreshSymbolTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, heightTile, size().as<gpu_float_t>());
		mLayerCache->insert(key, std::move(task), found, lock);
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

template<typename VectorLayerT>
void Viewport::prepare(std::vector<TileTuple> const& tuples, std::shared_ptr<VectorLayerT const> const& layer, Caching::Source const& source, world_float_t radius, Caching::LayerCache::LockT const& lock)
{
	for (TileTuple const& tuple : tuples)	// loop over all tiles
	{
		if (source.specification()->minZoom <= tuple.id.level && tuple.distance <= radius)	// check zoom level and radius
		{
			if (lmath::intersectsOrTouches(source.specification()->bounds.aabb(), tuple.globeBounds))
			{
				prepare(tuple.id.moduloX(), layer, source, lock);
			}
		}
	}
}

Tiles::Gathered Viewport::gather(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("gather render info");

	Tiles::Gathered gathered(tiles, mCurrentFrameTimeMS);

	{
		LUCID_PROFILE_SCOPE("terrain");
		for (Tiles::Gathered::Info& info : gathered)
		{
			gather(info.id, info.terrain);
		}
	}

	return gathered;
}

void Viewport::gather(Tiles::TileId const& tileId, Tiles::TerrainInfo& info)
{
	Tiles::TileId modulo = tileId.moduloX();
	info.isComplete = true; // assume the info is complete until proven otherwise
	info.globeBounds = MapMath::toGlobeBounds(modulo.worldBounds<world_float_t>());

	lgal::world::Vector3 const& eye = mCullCameraState.position;
	if (mTerrain)
	{
		info.distance = mTerrain.atlas->aabb(tileId, true).distanceTo(eye);

		Tiles::AtlasInfo atlasInfo = Tiles::AtlasInfo::Compute(*mTerrain.atlas, modulo, mTerrain.range());
		info.atlas = atlasInfo;
		info.meshResolution = computeMeshResolution(tileId);
		bool missing = atlasInfo.handle.idx == mTerrain.atlas->getMissingTileHandle().idx;
		info.isComplete &= !missing && (atlasInfo.level == std::min(tileId.level, mTerrain.range().end));
	}
	else
	{
		lgal::world::AABB3d aabb({ tileId.northwestCorner(), 0.0 }, { tileId.southeastCorner(), 0.0 });
		info.distance = aabb.distanceTo(eye);
		info.atlas = { mDummyTerrainHandle, 1, { 0, 0, 1, 1 }, 0.f, 0 };
		info.meshResolution = 1;
	}
}

void Viewport::render(bgfx::ViewId const viewId, Styling::FillLayer const& layer, Styling::FillStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector)
{
	LUCID_PROFILE_SCOPE("fills");

	// search cache for any reasonably detailed buffer
	lgal::gpu::Vector4 fragClip = { 0, 0, 1, 1 };	// TODO try using a stencil buffer to clip fragments to the rendered tile
	auto it = mLayerCache->find({ vector.id.moduloX(), layer.id }, 4, fragClip);
	if (it != mLayerCache->end() && it->entry.prepared && !it->entry.prepared->isTransparent())
	{
		Caching::PreparedFillData const& prepared = static_cast<Caching::PreparedFillData const&>(*it->entry.prepared);

		Tiles::TerrainInfo renderedTerrain = terrain;
		Tiles::VectorInfo renderedVector = vector;
		if (it->key.tileId() < vector.id)
		{
			renderedVector = Tiles::VectorInfo{ vector.id.parentAtLevel(it->key.tileId().level), renderedVector.useTimestamp };
			if (mTerrain)
			{
				renderedTerrain.atlas = Tiles::AtlasInfo::Compute(*mTerrain.atlas, it->key.tileId(), mTerrain.range());
			}
		}

		Rendering::render({ viewId, mRenderCameraState, mFillProgram, mLayerCache->getFillStyles(), *mSpritesheet, effect, renderedTerrain, renderedVector, prepared, fragClip, mExaggeration, mZoom, mZoomKm });
	}
}

void Viewport::render(bgfx::ViewId const viewId, Styling::LineLayer const& layer, Styling::LineStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector)
{
	LUCID_PROFILE_SCOPE("lines");

	lgal::gpu::AABB2d everything = lgal::gpu::AABB2d::everything();
	lgal::gpu::Vector4 fragClip = { everything.min, everything.max };
	auto it = mLayerCache->find({ vector.id.moduloX(), layer.id }, 4, fragClip);
	if (it != mLayerCache->end() && it->entry.prepared && !it->entry.prepared->isTransparent())
	{
		Caching::PreparedLineData const& prepared = static_cast<Caching::PreparedLineData const&>(*it->entry.prepared);
		uint32_t num = static_cast<uint32_t>(prepared.instances.size());
		if (num == 0 || !bgfx::isValid(prepared.handle())) { return; }

		Tiles::TerrainInfo renderedTerrain = terrain;
		Tiles::VectorInfo renderedVector = vector;
		if (it->key.tileId().level < vector.id.level)
		{
			renderedVector = Tiles::VectorInfo{ vector.id.parentAtLevel(it->key.tileId().level), renderedVector.useTimestamp };
			if (mTerrain)
			{
				renderedTerrain.atlas = Tiles::AtlasInfo::Compute(*mTerrain.atlas, it->key.tileId(), mTerrain.range());
			}
		}

		Rendering::render({ viewId, mRenderCameraState, mLineProgram, *mLineMesh, mLayerCache->getLineStyles(), *mSpritesheet, effect, renderedTerrain, renderedVector, prepared, fragClip, mExaggeration, mZoom, mZoomKm });
		mState.mFrameRenderStats.renderedLineInstances += num;
	}
}

template<typename VectorLayerT>
void Viewport::render(bgfx::ViewId const viewId, VectorLayerT const& layer, Tiles::Gathered const& gathered)
{
	// realize effect and convert to world space units
	auto effect = mHorizon.convert(layer.effect(layerArgs()), mFilteredZoomKm);

	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	world_float_t radius = std::min(mFogStyle.range.y, effect.fadeRange.y);
	for (Tiles::Gathered::Info const& info : gathered)
	{
		if (source.specification()->minZoom <= info.id.level && info.terrain.distance <= radius)
		{
			if (lmath::intersectsOrTouches(source.specification()->bounds.aabb(), info.terrain.globeBounds))
			{
				render(viewId, layer, effect, info.terrain, info.vector);
			}
		}
	}
}

float Viewport::AliasZoom(float const zoom)
{
	float precision = 10.0;
	uint32_t aliased = static_cast<uint32_t>(std::round(zoom * precision));
	return static_cast<float>(aliased) / precision;
}

Symbol::SharedSymbol_t Viewport::getOverrideSymbol(index_t i) const
{
	return overrideSymbolExists(i) ? mOverrideSymbols[i] : nullptr;
}

int Viewport::addOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s) 
{
	if (mOverrideSymbols.size() > cMaxNumOverrideSyms)
	{
		logE("Reached maximum number of override symbols");
		return -1;
	}
	mOverrideSymbols.push_back(std::move(s));
	invalidate();

	return (int)(mOverrideSymbols.size() - 1);
}

}
