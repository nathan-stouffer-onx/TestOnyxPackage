#include "Viewport.h"

#include <unordered_set>

#include <lucid/Profiler.h>
#include <Shaders/ShaderDefinition.h>
#include <Styling/Parse/MiscJson.h>

#include "Caching/Tiles/TileCache.h"
#include "Caching/Layers/Tasks/VectorTileTasks.h"
#include "Caching/Layers/Tasks/HeightTileTasks.h"
#include "DataObjects/SymbolManager.h"
#include "DataObjects/WaypointManager.h"
#include "Atlases/HeightAtlas.h"
#include "Atlases/TileAtlas.h"
#include "Rendering/Render.h"
#include "Tiles/TileRenderInfo.h"
#include "Tiles/TileMesh.h"
#include "Events/Events.h"
#include "Utils/Timer.h"
#include "Utils/BgfxUtils.h"

namespace onyx
{

Viewport::Viewport(onyx::viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
	mState(viewportId, wRatio, hRatio, state, sortOrder),
	mStyle(new Styling::Style()),
	mSkydome(new Drawers::Skydome()),
	mLayerCache(new Caching::LayerCache())
{
	mLineMesh.reset(new Rendering::VectorLineMesh());

	allocateTextures();
	allocateFramebuffers();
	
	mSymbolManager.reset(new DataObjects::SymbolManager(this));
	mSymbolManager->initialize();
	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
}

Viewport::~Viewport()
{
	deallocateTextures();
	deallocateFramebuffers();
}

bgfx::TextureHandle Viewport::getTexture()
{
	if (bgfx::isValid(mColorDepthZFrameBuffer) && bgfx::isValid(mColorZFrameBuffer) && bgfx::isValid(mColorTarg))
	{
		return mColorTarg;
	}

	return BGFX_INVALID_HANDLE;
}

void Viewport::renderScreenLines()
{
	if (mState.mScreenLines.empty())
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw screen-space lines");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);
	
	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA;
#ifdef ENABLE_MSAA
	| BGFX_STATE_MSAA
#endif
		;

	for (auto const& styles : mState.mScreenLines)
	{
		auto const& instances = styles.second;
		if (instances.empty())
		{
			continue;
		}

		Rendering::render(renderId, instances, styles.first, *mLineMesh, state, *shader);
	}
}

void Viewport::renderScreenSpaceManager()
{
	if (mState.mScreenSpaceManager.empty() || !mShowScreenSpaceManager)
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw Screen Space Manager");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA
#ifdef ENABLE_MSAA
	| BGFX_STATE_MSAA
#endif
		;

	screenLineVector_t instances;

	auto res = size().as<gpu_float_t>();

	auto xScale = 2.f / res.x;
	auto yScale = 2.f / res.y;

	for (auto const &screenRect : mState.mScreenSpaceManager)
	{
		auto GPURect = screenRect.as<gpu_float_t>();
		static const std::array<int, 4> nextPts = { 1, 3, 0, 2 };

		for (int i = 0; i < GPURect.VERTEX_COUNT(); ++i)
		{
			lgal::gpu::LineSegment2 segment(GPURect.vertex(i), GPURect.vertex(nextPts[i]));

			lgal::gpu::Vector2 p1(segment.start.x * xScale - 1, (segment.start.y * yScale - 1));

			p1.y *= -1;
			auto dir = lucid::math::normalize(segment.direction());
			dir.y *= -1;

			instances.push_back(Rendering::VertStructs::ScreenLineData(0, 0, 0xFFFF0000, { p1, 0 }, { dir, 0 }, segment.length(), 3.0 ));
		}
	}

	if (instances.empty())
	{
		return;
	}

	Rendering::render(renderId, instances, "dotted", *mLineMesh, state, *shader);
}

void Viewport::drawTerrainLines(bgfx::ViewId renderId, Tiles::TileVectorInfo const& info, bgfx::VertexBufferHandle const handle, uint32_t start, uint32_t num, float32_t fade, Shaders::ShaderDefinition* shader)
{
	if (num == 0 || !bgfx::isValid(handle))
	{
		return;
	}

	auto tileMin = (info.tileMin - mState.mRenderCameraState.position).as<gpu_float_t>();
	auto tileMax = (info.tileMax - mState.mRenderCameraState.position).as<gpu_float_t>();
	tileMax.z = (gpu_float_t)info.tileSize.x;

	shader->setParameter("u_tileMin", tileMin);
	shader->setParameter("u_tileMax", tileMax);

	setTextureParameters(info.heightAtlasInfo, shader, TextureType::Height);
	shader->setParameter("u_MeshResolution", lgal::gpu::Vector4({ gpu_float_t(info.meshResolution), 55, 66, 77 }));
	shader->setParameter("u_nearFarPlane", lgal::world::Vector3(mState.mRenderCameraState.nearClip, mState.mRenderCameraState.farClip, 0));
	shader->setParameter("u_FogTransition", mHorizon.realizeFog(mState.mRenderCameraState.pitch));
	shader->setParameter("u_TileLineOpacityTransition", mHorizon.realizeLineOpacity(mState.mRenderCameraState.pitch));
	shader->setParameter("u_vectorFade", fade);
	shader->setParameter("u_drawColor", info.color);
	shader->setParameter("u_lineWidthScale", lmath::clamp(fade * 2.f, 0.f, 1.f));
	
	auto sp = shader->parameters["u_tileSize"];
	if (sp != nullptr)
	{
		sp->setValue(lgal::gpu::Vector3((gpu_float_t)info.tileSize.x, (gpu_float_t)info.tileSize.y, sp->mVec3.z));
	}

	static uint64_t baseState = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA
		| BGFX_STATE_DEPTH_TEST_LEQUAL
#ifdef ENABLE_MSAA
	| BGFX_STATE_MSAA
#endif
		;

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);
	shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ info.distortion.as<gpu_float_t>(), 0.0 });

	Atlases::LineStyleAtlas const& lineStyles = mLayerCache->getLineStyles();
	shader->setParameter("s_VectorColors", lineStyles.getColorHandle());
	shader->setParameter("s_VectorWidths", lineStyles.getWidthHandle());
	shader->setParameter("s_DashCoords", lineStyles.getDashCoordsHandle());
	shader->setParameter("s_DashSampler", lineStyles.getDashAtlasHandle(), Atlases::DashAtlas::cRowResolution, Atlases::DashAtlas::cNumRows);

	mLineMesh->attach();
	mState.mFrameRenderStats.renderedLineInstances += num;

	bgfx::setInstanceDataBuffer(handle, start, num);
	bgfx::setState(baseState | BGFX_STATE_PT_TRISTRIP);
	bgfx::submit(renderId, shader->mInstancedHandle);
}

void Viewport::render(double timeMS)
{
	mCurrentFrameTimeMS = timeMS;
	mLayerCache->setFrameTimeMS(timeMS);
	mState.mFrameRenderStats.reset();

	if (mVectorShaderFamily.count() == 0)
	{
		mVectorShaderFamily.loadSignature(ShaderManager::Instance()->getDefaultConfiguration(ShaderEnums::ConfigurableShaders::TerrainVector));
		if (mVectorShaderFamily.count() == 0)
		{
			ONYX_THROW("Unable to load filled terrain vector shader!");
		}
	}

	// mark as dirty; sync sources and layers as necessary
	if (mStyle->isDirty()) { invalidate(); }
	if (mStyle->hasDirtySources()) { syncSources(); }
	syncLayers();

	if (assignTerrainShaderFamily())
	{
		invalidate();
	}

	mStyle->update();

	// compute height atlas if we have the source
	auto heightAtlas = getHeightAtlas();

	if (mStyle->hasSpritesheet())
    {
        mState.mSpriteAtlas.update();
    }

	touchRootTiles();

	// precache tiles associated with the controller's highlight states
	std::vector<Camera::CameraState> highlights = mState.mController->highlights();
	for (auto const& highlight : highlights)
	{
		Pyramid::CullResult cullRes = Pyramid::cull(highlight, mState.getLODScaler(), mState.getMaxSubdDepth(), heightAtlas, mState.getTerrainExaggeration());
		TileCollections tiles = { cullRes };
		tiles.update(cullRes);
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(tiles.rasterGrandparents, tiles.vectorGrandparents, mStyle, mState.getZoom());
		// only continue processing if the tiles are precached
		if (!Caching::TileCache::Instance()->precache(keys))
		{
			break;
		}
	}

	Camera::CameraState newState = mState.mController->update(mState.mRenderCameraState, timeMS, heightAtlas, mState.getTerrainExaggeration());

	// evaluate exaggeration
	if (mStyle->hasTerrain())
	{
		std::shared_ptr<Styling::Terrain const> const& terrain = mStyle->terrain();
		Styling::Expressions::Arguments args{ mState.getZoom(), lmath::radiansToDegrees(newState.heading), lmath::radiansToDegrees(newState.pitch), mStyle->getExpressionContext() };
		mState.setTerrainExaggeration(terrain->exaggeration->evaluate(args));
	}

	// override aspect ratio with viewport value
	newState.aspect = getAspect();

	bool cameraWasMoving = mState.getCameraMoved();
	mState.setCameraMoved(newState != mState.mRenderCameraState);

	// trigger camera-related events
	if (mState.getCameraMoved())
	{
		mState.mRenderCameraState = newState;
		if (mState.mSyncCameraStates)
		{
			mState.mCullCameraState = mState.mRenderCameraState;
		}

		mState.mRenderCameraState.updateViewProj();
		Events::trigger(Events::EventType::CAMERA_MOVED);
	}
	else if (cameraWasMoving)
	{
		Events::trigger(Events::EventType::CAMERA_STOPPED);
		lgal::world::Range r = lgal::world::Range(Utils::Timer::nowMS(), 0.0);
		mState.setTileLoadTimeMS(r);
	}

	if (mState.getCullingEnabled())
	{
		// compute zoom for this frame
		lgal::world::Vector3 center = unprojectNormalized(lgal::world::Vector2{ 0.f, 0.f });
		lgal::world::Vector3 bottom = unprojectNormalized(lgal::world::Vector2{ 0.f, 1.f });
		float zoom = (float)std::max(MapMath::zoom(newState.position, center), MapMath::zoom(newState.position, bottom));
		mState.setZoom(zoom);
	}

	if (mState.getCameraMoved() || mState.getForceCulling())
	{
		mState.setForceCulling(false);
		// reset tile load time when the camera moves

		auto &cullState = getFrameCullState();

		if (mState.getCullingEnabled())
		{
			LUCID_PROFILE_SCOPE("culling");
			mState.mTileRenderInfo.clear();
			cullState.reset();
			Pyramid::cull(cullState, mState.mCullCameraState, mState.getLODScaler(), mState.getMaxSubdDepth(), heightAtlas, mState.getTerrainExaggeration());
			mState.mTileCollections.update(cullState, mState.getTileZoomRange(), mState.getTileRenderRange());
			mLastCacheUpdate = 0;
		}
		mState.setRenderComplete(false);
	}

	if (mState.getRenderComplete() && mState.getQuiescenceMode()) // Nothing to do; render was already completed and nothing has changed.
	{
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(mState.mTileCollections.rasters, mState.mTileCollections.vectors, mStyle, mState.getZoom());
		Caching::TileCache::Instance()->touch(keys);
		return;
	}

	auto cacheTimestamp = Caching::TileCache::Instance()->getUpdateTimestamp();

	if (cacheTimestamp == mLastCacheUpdate)
	{
		//return; // Nothing new in the cache to render, so just bail
	}
//	logD("cache has new info %ul -> %ul", mLastCacheUpdate, cacheTimestamp);
	mLastCacheUpdate = cacheTimestamp;
	mState.getScreenSpaceManager().clear();
	mTerrainShaderFamily.setParameter("u_eyePos", mState.mRenderCameraState.position);
	mTerrainShaderFamily.setParameter("u_nearFarPlane", lgal::world::Vector3(mState.mRenderCameraState.nearClip, mState.mRenderCameraState.farClip, 0));
	mTerrainShaderFamily.setParameter("u_FogTransition", mHorizon.realizeFog(mState.mRenderCameraState.pitch));

	if (mSkydome.get() != nullptr)
	{
		auto id = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::Skydome, 0);
		auto p = shader->parameters["u_hazeColor"];
		bgfx::setViewClear(id, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, p->mColor.rgba(), 1.0f, 0);
		bgfx::setViewFrameBuffer(id, mColorDepthZFrameBuffer);
		bgfx::setViewRect(id, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());
		mSkydome->draw(id, mState.mRenderCameraState, shader);
	}

	renderTerrain();
	renderWaypoints();
	renderSymbols();

	renderScreenLines();
	renderScreenSpaceManager();
	
	mState.mLifetimeRenderStats += mState.mFrameRenderStats;
	swapTripleBuffers();
}

void Viewport::readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue)
{
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(float);
	if (mState.mDepthData.size() < dataSize)
	{
		mState.mDepthData.resize(dataSize);
		if (defaultValue != 0)
		{
			memset(mState.mDepthData.data(), defaultValue, mState.mDepthData.size());
		}
	}

	auto data = mState.mDepthData.data();
	bgfx::blit(viewId, mDepthReadbackHandle, 0, 0, mDepthTarg);
	bgfx::readTexture(mDepthReadbackHandle, data);
}

void Viewport::readDepth(std::vector<uint8_t>& target)
{
	target.resize(mState.mDepthData.size());
	std::copy(mState.mDepthData.begin(), mState.mDepthData.end(), target.begin());
}

void Viewport::readColor(std::vector<uint8_t> &target, uint8_t defaultValue)
{
	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);

	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(uint32_t);
	if (target.size() != dataSize)
	{
		target.resize(dataSize);
		if (defaultValue != 0)
		{
			std::memset(target.data(), defaultValue, target.size());
		}
	}

	auto data = target.data();
	bgfx::blit(viewId, mColorReadbackHandle, 0, 0, mColorTarg);
	bgfx::readTexture(mColorReadbackHandle, data);
}

void Viewport::resize()
{
	// set the camera state aspect
	setController(std::make_shared<Camera::Controllers::Identity>());
	mState.mRenderCameraState.aspect = getAspect();
	mState.mRenderCameraState.aspect = getAspect();

	// reallocate textures of the appropriate size
	deallocateTextures();
	allocateTextures();

	// reallocate frame buffers with those textures
	deallocateFramebuffers();
	allocateFramebuffers();

	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
	invalidate();
}

void Viewport::setController(std::shared_ptr<Camera::CameraController> controller)
{
	mState.mController = controller;
}

void Viewport::setCameraState(Camera::CameraState const& state)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mState.mRenderCameraState = state; //normal mode, keep render and cull in sync
	mState.mCullCameraState = state;
	mState.mSyncCameraStates = true;
}

void Viewport::setCameraState(Camera::CameraState const& render, Camera::CameraState const& cull)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mState.mRenderCameraState = render; //primarily for debugging, lets us split the view the terrain calculates with, and the view we see the terrain from
	mState.mCullCameraState = cull;
	mState.mSyncCameraStates = false;
}

gpu_float_t Viewport::depthAtPixel(int screenX, int screenY) const
{
	auto depthData = (uint8_t*)mState.mDepthData.data();
	size_t y = size_t(screenY);
	if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
	{
		y = size_t(getHeightPixel()) - 1 - y;
	}
	auto depthIndex = (size_t(screenX) + (y * size_t(mState.getWidthPixel()))) * 4;
	if (depthIndex < mState.mDepthData.size())
	{
		auto r = depthData[depthIndex] * (1.f / 255.f);
		auto g = depthData[depthIndex + 1] * (1.f / 255.f);
		auto b = depthData[depthIndex + 2] * (1.f / 255.f);
		auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
		return result;
	}
	return -1;
}

gpu_float_t Viewport::depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const
{
	int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * mState.getWidthPixel());
	int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * mState.getHeightPixel());
	return depthAtPixel(x, y);
}

lgal::world::Vector3 Viewport::unprojectPixel(int screenX, int screenY) const
{
	auto depth = depthAtPixel(screenX, screenY) * 2.0f - 1.0f;
	float x = (screenX / mState.getWidthPixel()) * 2.0f - 1.0f;
	float y = (screenY / mState.getHeightPixel()) * 2.0f - 1.0f;
	lgal::world::Vector3 normalizedCoords = { x, y, depth };
	return unprojectNormalized(normalizedCoords);
}

lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const
{
	int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * mState.getWidthPixel());
	int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * mState.getHeightPixel());
	return unprojectPixel(x, y);
}

// TODO change architecture so that the unprojected point is more accurate
// the height discrepancy is really off when the camera is zoomed out
lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const
{
	Camera::CameraState::ProjectionData unprojected = mState.mRenderCameraState.unproject(normalizedPos);
	lgal::world::Vector3 result = unprojected.position;

	// override z with a more accurate value
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(result.xy));
		distortedHeightKm *= mState.getTerrainExaggeration();
		result.z = distortedHeightKm;
	}
	else
	{
		result.z = 0.0;
	}

	return result;
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector2 const& pos) const
{
	// compute z with a more accurate value
	height_float_t z = 0.0;
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(pos));
		distortedHeightKm *= mState.getTerrainExaggeration();
		z = distortedHeightKm;
	}
	return project(lgal::world::Vector3{ pos, z });
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector3 const& pos) const
{
	Camera::CameraState::ProjectionData projected = mState.mRenderCameraState.project(pos);
	return projected.position;
}

void Viewport::setMatrixUniforms(bgfx::ViewId const& viewId)
{
	mState.mRenderCameraState.updateViewProj();
	bgfx::setViewTransform(viewId, mState.mRenderCameraState.view, mState.mRenderCameraState.proj);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)mState.getWidthPixel(), (uint16_t)mState.getHeightPixel());
}

void Viewport::renderTerrain()
{
	LUCID_PROFILE_SCOPE("viewport terrain render");

	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);

	if (mSkydome.get() == nullptr)
	{
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0);
	}

	bgfx::setViewName(viewId, (std::string("viewport terrain ") + std::to_string(mState.getId())).c_str());
	bgfx::setViewFrameBuffer(viewId, mColorDepthZFrameBuffer);
	setMatrixUniforms(viewId);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());

	if (renderTiles(viewId))
	{
		mState.setRenderComplete(true);
		if (mState.getTileLoadTimeMS().end == 0.0)
		{
			mState.setTileLoadTimeMS(lgal::world::Range(mState.getTileLoadTimeMS().begin, Utils::Timer::nowMS()));
			Events::trigger(Events::EventType::TILES_LOADED);
		}
	}
}

void Viewport::renderWaypoints()
{
	LUCID_PROFILE_SCOPE("viewport waypoint render");

	bgfx::ViewId renderDataId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::touch(renderDataId);
	bgfx::setViewFrameBuffer(renderDataId, mColorZFrameBuffer);
	bgfx::setViewClear(renderDataId, BGFX_CLEAR_NONE);
	bgfx::setViewName(renderDataId, "viewport waypoint");
	setMatrixUniforms(renderDataId);
	WaypointManager::Instance()->draw(renderDataId, mState.mRenderCameraState);
}

template<typename LayerType>
void Viewport::gatherSymbols()
{
	for (auto const& layer : mStyle->visibleLayers<LayerType>())
	{
		for (auto& tileId : mState.mTileCollections.vectors)
		{
			Caching::LayerCache::EntryKey key = { tileId, layer->id };

			if (mLayerCache->isPrepared(key))
			{
				Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
				auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
				auto preparedSymbols = prepared->symbols();
				mFrameSymbols.insert(mFrameSymbols.end(), preparedSymbols.begin(), preparedSymbols.end());
			}
		}
	}
}

void Viewport::gatherSymbols()
{
	for (auto const& [key, symbols] : mState.mSymbolCollection.getSymbolsMap())
	{
		mFrameSymbols.insert(mFrameSymbols.end(), symbols.begin(), symbols.end());
	}

	// TODO we have to refactor this code at some point. viewports shouldn't have to add the terrain effect labels on a per frame basis
	for (auto const& [name, effect] : mTerrainEffects)
	{
		if (effect->isVisible())
		{
			effect->getLabels(mFrameSymbols);
		}
	}

	gatherSymbols<Styling::SymbolLayer>();
	gatherSymbols<Styling::ContourLabelLayer>();
}

void Viewport::renderSymbols()
{
	LUCID_PROFILE_SCOPE("symbol render");

	mSymbolManager->update();

	mFrameSymbols.clear();

	gatherSymbols();

	mSymbolManager->draw(mState.getScreenSpaceManager(), mFrameSymbols, mColorZFrameBuffer, mState.mSpriteAtlas, getHeightAtlas());
}

void Viewport::gatherTileTextureInfo(Tiles::TileId const& tileId, Tiles::TileTextureInfo& target)
{
	target.layerCount = 0;
	bool hasAllTextures = true;
	
	if (mStyle->hasTerrain())
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
		Atlases::TileAtlas const* atlas = source.atlas();

		auto atlasInfo = Tiles::AtlasInfo::Compute(*atlas, tileId, source.specification()->range());
		target.heightAtlasInfo = atlasInfo;
	}

	for (std::shared_ptr<Styling::RasterLayer const> layer : mStyle->visibleLayers<Styling::RasterLayer>())
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
		Atlases::TileAtlas const* atlas = source.atlas();

		Styling::RasterStyle style = layer->realizeRasterStyle({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
		auto atlasInfo = Tiles::AtlasInfo::Compute(*atlas, tileId, source.specification()->range(), style.opacity);
		
		if (!bgfx::isValid(atlasInfo.handle))
		{
			hasAllTextures = false;
			continue;
		}

		if (source.specification()->minZoom <= atlasInfo.level)
		{
			target.layers[target.layerCount] = atlasInfo;
			++target.layerCount;
		}
	}

	target.isComplete = hasAllTextures;
	target.isReady = bgfx::isValid(target.heightAtlasInfo.handle);
}

// TODO refactor so this is no longer necessary
static std::map<TextureType, std::array<std::string, 3>> sTextureShaderMapping =
{
	{ TextureType::Basemap,			{ "s_texture0", "u_ScaleOffsetTex0", "u_OpacityTex0" } },
	{ TextureType::Basemap2,		{ "s_texture1", "u_ScaleOffsetTex1", "u_OpacityTex1" } },
	{ TextureType::Height,			{ "s_heightTexture", "u_ScaleOffsetHeight", "" } },
	{ TextureType::Weather,			{ "s_texture0", "u_ScaleOffsetTex0", "u_OpacityTex0" } },
	{ TextureType::Roads,			{ "s_texture1", "u_ScaleOffsetTex1", "u_OpacityTex1" } },
	{ TextureType::LocalData,		{ "s_texture2", "u_ScaleOffsetTex2", "u_OpacityTex2" } },
};

void Viewport::setTextureParameters(Tiles::AtlasInfo const& info, Shaders::ShaderDefinition* shader, TextureType textureType)
{
	auto const& texInfo = sTextureShaderMapping.at(textureType);
	std::string const& texName = texInfo[0];
	std::string const& uvOffsetName = texInfo[1];
	std::string const& opacity = texInfo[2];

	shader->setParameter(texName, info.handle, info.resolution, info.resolution);
	shader->setParameter(uvOffsetName, info.offset);
	shader->setParameter(opacity, info.opacity);
}

void Viewport::renderTileTextures(bgfx::ViewId const& viewId, Tiles::TileTextureInfo const& renderInfo)
{
	LUCID_PROFILE_SCOPE("terrain textures");

	uint16_t meshRes = 1;
	if (mStyle->hasTerrain())
	{
		auto const& source = mStyle->source(mStyle->terrain()->source);
		auto height = std::static_pointer_cast<Styling::RasterDemSource const>(source);
		meshRes = MapMath::meshResolution(*height, renderInfo.id);
	}

	if (renderInfo.isReady) // checks if samplers, etc all match up
	{
		auto subsetCount = std::min(size_t(renderInfo.layerCount), mTerrainShaderFamily.count() - 1);
		if (subsetCount > 0) { --subsetCount; }

		auto shader = mTerrainShaderFamily.getShader((int)subsetCount);
		ONYX_ASSERT(shader != nullptr, "Unable to retrieve shader for requested ConfigurableShader/texture count subset");

		lgal::Color background = 0x00FFFFFF;
		for (auto const& layer : mStyle->visibleLayers<Styling::BackgroundLayer>())
		{
			Styling::BackgroundStyle style = layer->realizeBackgroundStyle({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
			background = lgal::Color::FromABGR(style.abgr);
		}
		shader->setParameter("u_BackgroundColor", background);

		ShaderParam* sp = shader->parameters["u_tileSize"];
		if (sp != nullptr)
		{
			sp->setValue(lgal::gpu::Vector3((float)renderInfo.tileSize.x, (float)renderInfo.tileSize.y, (float)sp->mVec3.z));
		}

		shader->setParameter("u_tileDistortion", lgal::world::Vector3{ renderInfo.distortion, 0.0});

		sp = shader->parameters["u_heightTileSize"];
		if (sp != nullptr)
		{
			float size = (float)Tiles::TileId::LevelToTileExtent(renderInfo.heightAtlasInfo.level);
			sp->setValue(lgal::gpu::Vector3(size, size, sp->mVec3.z));
		}		

		setTextureParameters(renderInfo.heightAtlasInfo, shader.get(), TextureType::Height);
		setTextureParameters(renderInfo.layers[0], shader.get(), TextureType::Basemap);
		if (renderInfo.layers[1].isValid())
		{
			setTextureParameters(renderInfo.layers[1], shader.get(), TextureType::Roads);
			if (renderInfo.layers[2].isValid())
			{
				setTextureParameters(renderInfo.layers[2], shader.get(), TextureType::LocalData);
			}
		}

		auto tileMin = renderInfo.tileMin - mState.mRenderCameraState.position;
		auto tileMax = renderInfo.tileMax - mState.mRenderCameraState.position;
		tileMax.z = renderInfo.tileSize.x;

		shader->setParameter("u_tileMin", tileMin);
		shader->setParameter("u_tileMax", tileMax);

		for (size_t i = 0u; i < mTerrainShaderFamily.count(); i++)
		{
			sp = mTerrainShaderFamily.getParameter("u_tileSize", static_cast<int>(i));
			if (sp != nullptr)
			{
				sp->setValue(lgal::world::Vector3(sp->mVec3.x, sp->mVec3.y, mState.getTerrainExaggeration()));
			}
		}

		// set parameters from relevant terrain effects
		for (auto const& [id, effect] : mTerrainEffects)
		{
			LUCID_PROFILE_SCOPE("set terrain effect params");
			// set parameters from relevant terrain effects
			if (effect->isVisible())
			{
				effect->setParameters(*shader, renderInfo.id);
			}
		}

		//draw mesh
		Tiles::TileMesh::Instance(meshRes)->draw(renderInfo.id, mState.mRenderCameraState.position, mState.mRenderCameraState.heading, shader->programHandle, viewId, false);
	}
	else
	{
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0);
		shader->setParameter("u_tileMin", renderInfo.tileMin - mState.mRenderCameraState.position);
		shader->setParameter("u_tileMax", renderInfo.tileMax - mState.mRenderCameraState.position);
		Tiles::TileMesh::Instance(meshRes)->draw(renderInfo.id, mState.mRenderCameraState.position, mState.mRenderCameraState.heading, shader->programHandle, viewId, false);
	}
}

void Viewport::drawTerrainVectors(bgfx::ViewId viewId, Tiles::TileVectorInfo const& info, std::shared_ptr<Styling::FillLayer const> layer, Shaders::ShaderDefinition *shader, uint64_t flags)
{
	// render states
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		| BGFX_STATE_BLEND_ALPHA
		| BGFX_STATE_DEPTH_TEST_LEQUAL
		;

	Caching::LayerCache::EntryKey key = { info.id, layer->id };
	lgal::gpu::Vector4 fragClip = { 0, 0, 1, 1 };	// TODO try using a stencil buffer to clip fragments to the rendered tile

	Caching::PreparedFillData::Buffer_t const* buffer = nullptr;

	// search cache for any buffer we can find
	for (int i = key.tileId.level; !buffer && i >= 0; --i)
	{
		if (mCoveredFills.find({ key.tileId, layer->id }) != mCoveredFills.end())
		{
			break;
		}

		Caching::LayerCache::EntryKey modulo = { key.tileId.moduloX(), key.layerId };
		if (mLayerCache->isPrepared(modulo))
		{
			auto const& entry = mLayerCache->at(modulo);
			auto prepared = std::static_pointer_cast<Caching::PreparedFillData const>(entry.prepared);
			buffer = prepared->buffer.get();
		}
		else
		{
			key.tileId = key.tileId.parent();
		}
	}

	if (buffer)
	{
		Tiles::TileVectorInfo rendered = info;
		if (key.tileId < info.id)
		{
			rendered = Tiles::TileVectorInfo{ key.tileId, rendered.useTimestamp };
			if (mStyle->hasTerrain())
			{
				auto terrain = mStyle->terrain();
						
				Caching::Source const& source = Caching::TileCache::Instance()->getSource(terrain->source);
				rendered.heightAtlasInfo = Tiles::AtlasInfo::Compute(*source.atlas(), key.tileId.moduloX(), source.specification()->range());
			}
		}

		auto tileMin = (rendered.tileMin - mState.mRenderCameraState.position).as<gpu_float_t>();
		auto tileMax = (rendered.tileMax - mState.mRenderCameraState.position).as<gpu_float_t>();
		tileMax.z = (gpu_float_t)rendered.tileSize.x;

		mCoveredFills.insert({ rendered.id, layer->id });

		shader->setParameter("u_TileFragClip", fragClip);

		if (mState.getVectorWireframes())
		{
			bgfx::setDebug(BGFX_DEBUG_WIREFRAME);
		}

		setTextureParameters(rendered.heightAtlasInfo, shader, TextureType::Height);
		for (auto i = 0ull; i < buffer->numVertexPages(); ++i)
		{
			buffer->attachPageBuffers(i);
			setTextureParameters(rendered.heightAtlasInfo, shader, TextureType::Height);

			Atlases::FillStyleAtlas const& fillStyles = mLayerCache->getFillStyles();
			shader->setParameter("u_nearFarPlane", lgal::world::Vector3(mState.mRenderCameraState.nearClip, mState.mRenderCameraState.farClip, 0));
			shader->setParameter("u_FogTransition", mHorizon.realizeFog(mState.mRenderCameraState.pitch));
			shader->setParameter("u_TileVectorOpacityTransition", mHorizon.realizeFillOpacity(mState.mRenderCameraState.pitch));
			shader->setParameter("u_MeshResolution", lgal::gpu::Vector4({ gpu_float_t(info.meshResolution), 55, 66, 77 }));
			shader->setParameter("s_vectorColors", fillStyles.getColorHandle());
			shader->setParameter("s_vectorPatterns", fillStyles.getPatternCoordsHandle());
			shader->setParameter("s_patterns", fillStyles.getPatternAtlasHandle(), 256, 256);
			shader->setParameter("u_tileDistortion", lgal::world::Vector3{ rendered.distortion, 0.0 });
			shader->setParameter("u_screenResolution", lgal::gpu::Vector3{ size().as<gpu_float_t>(), 0 });
			shader->setParameter("u_tileMin", tileMin);
			shader->setParameter("u_tileMax", tileMax);
			shader->setParameter("u_tileVectorData", lgal::gpu::Vector3(std::floor(mState.getZoom()), 0, 0));

			// Set render states

			bgfx::setState(state | flags);
			bgfx::submit(viewId, shader->programHandle);
		}
	}
}

void Viewport::drawLineInstances(bgfx::ViewId const& viewId, Tiles::TileVectorInfo const& info, float32_t fade, std::shared_ptr<Styling::LineLayer const> layer, Shaders::ShaderDefinition* shader)
{
	Caching::LayerCache::EntryKey key = { info.id.moduloX(), layer->id };
	std::shared_ptr<Caching::PreparedLineData const> prepared = nullptr;

	lgal::gpu::AABB2d everything = lgal::gpu::AABB2d::everything();
	lgal::gpu::Vector4 fragClip = { everything.min, everything.max };
			
	for (int i = key.tileId.level; !prepared && i >= 0; --i)
	{
		if (mLayerCache->isPrepared(key))
		{
			if (key.tileId.level < info.id.level)
			{
				auto bounds = Tiles::TileId::InternalBounds(key.tileId, info.id.moduloX());
				fragClip = { bounds.min, bounds.max };
			}

			auto const& entry = mLayerCache->at(key);
			prepared = std::static_pointer_cast<Caching::PreparedLineData const>(entry.prepared);
		}
		else
		{
			key.tileId = key.tileId.parent();
		}
	}

	if (prepared)
	{
		uint32_t start = 0;
		uint32_t num = uint32_t(prepared->instances.size());

		shader->setParameter("u_TileFragClip", fragClip);

		Tiles::TileVectorInfo rendered = info;
		if (key.tileId.level < info.id.level)
		{
			rendered = Tiles::TileVectorInfo{ info.id.parentAtLevel(key.tileId.level), rendered.useTimestamp };

			if (mStyle->hasTerrain())
			{
				auto terrain = mStyle->terrain();

				Caching::Source const& heightSource = Caching::TileCache::Instance()->getSource(terrain->source);
				rendered.heightAtlasInfo = Tiles::AtlasInfo::Compute(*heightSource.atlas(), key.tileId, heightSource.specification()->range());
			}
		}

		drawTerrainLines(viewId, rendered, prepared->handle, start, num, fade, shader);
	}
}

void Viewport::renderTileVectors(bgfx::ViewId const& viewId, Tiles::TileVectorInfo& renderInfo, std::shared_ptr<Styling::Layer const> layer, Shaders::ShaderDefinition* shader)
{
	LUCID_PROFILE_SCOPE("terrain vectors");

	if (mState.getTerrainWireframes())
	{
		bgfx::setDebug(BGFX_DEBUG_WIREFRAME);
	}

	float32_t alpha = 1.0f;

	// TODO (stouff) reintroduce fade in/out
	//auto fadeIn = renderInfo.useTimestamp - renderInfo.addTimestamp;
	//auto fadeOut = mCurrentFrameTime - renderInfo.useTimestamp;
	//if (fadeIn < getVectorFadeTime() || fadeOut > 0)
	//{
	//	alpha = float32_t(std::min(fadeIn / getVectorFadeTime(), 1.));
	//	if (fadeOut > 0)
	//	{
	//		alpha *= (1 - float32_t(fadeOut / getVectorFadeTime()));
	//	}
	//}

	if (renderInfo.childIsLoading && getVectorDownloadPulseTimeMS() > 0)
	{
		double interval = std::fmod(mCurrentFrameTimeMS, getVectorDownloadPulseDelayMS() + getVectorDownloadPulseTimeMS());

		if (interval < getVectorDownloadPulseTimeMS())
		{
			auto period = interval * (lucid::math::constants::two_pi<double>() / getVectorDownloadPulseTimeMS());

			float32_t pulse = float32_t(lucid::math::periodic(0., 0.3, period));
			renderInfo.color.a = pulse;
		}
		else
		{
			renderInfo.color.a = 0;
		}
	}
	else
	{
		renderInfo.color.a = 0;
	}

	if (layer->type == Styling::Layer::Types::FILL && mState.getShowFilledVectors())
	{
		LUCID_PROFILE_SCOPE("draw fills");
		shader->setParameter("u_vectorFade", alpha);
		drawTerrainVectors(viewId, renderInfo, std::static_pointer_cast<Styling::FillLayer const>(layer), shader);
	}

	if (layer->type == Styling::Layer::Types::LINE && mState.getShowVectorLines())
	{
		LUCID_PROFILE_SCOPE("draw lines");
		shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainLine, 0).get();
		drawLineInstances(viewId, renderInfo, alpha, std::static_pointer_cast<Styling::LineLayer const>(layer), shader);
	}
}

bool Viewport::gatherTextureRenderInfo(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("gather texture render info");
	bool complete = true;

	if (mTerrainShaderLayers.empty()) { return complete; }

	for (auto& tileId : tiles)
	{
		auto ri = mState.mTileRenderInfo.find(tileId);
		if (ri == mState.mTileRenderInfo.end())
		{
			mState.mTileRenderInfo.insert({ tileId, Tiles::TileTextureInfo(tileId) });
			ri = mState.mTileRenderInfo.find(tileId);
		}

		if (!ri->second.isComplete)
		{
			gatherTileTextureInfo(tileId.moduloX(), ri->second);
		}

		complete &= ri->second.isComplete;
	}

	return complete;
}

bool Viewport::gatherVectorRenderInfo(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("gather vector render info");
	bool complete = true;

	if (!mStyle->hasTerrain())
	{
		return false;
	}

	std::shared_ptr<Styling::Terrain const> terrain = mStyle->terrain();
	auto heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(mStyle->source(terrain->source));
	lmath::Range<Tiles::TileId::IdCoordsT> heightZoomRange = heightSpec->range();

	auto heightAtlas = getHeightAtlas();

	LUCID_PROFILE_SCOPE("gather vector prepare tasks");
	for (Tiles::TileId const& requestId : tiles)	// loop over all tiles
	{
		LUCID_PROFILE_SCOPE("tiles");
		for (auto const& layer : mStyle->visibleLayers<Styling::SourcedLayer>(mState.getZoom()))	// loop over all layers
		{
			LUCID_PROFILE_SCOPE("layers");
			Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
			
			// check that we want to actually process this layer
			if (!source.specification()->isVector() || requestId.level < source.specification()->minZoom)
			{
				continue;
			}

			// prepare the (spatially) largest tile we can that will still satisfy all of our detail requirements. this
			// will result in fewer draw calls
			int maxLevel = std::max(MapMath::maxDetailZoom(*heightSpec), source.specification()->maxZoom);
			Tiles::TileId prepareId = (requestId.level <= maxLevel) ? requestId : requestId.parentAtLevel(maxLevel);

			Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();

			auto ri = mState.mVectorRenderInfo.find(prepareId);
			if (ri == mState.mVectorRenderInfo.end())
			{
				mState.mVectorRenderInfo.emplace(prepareId, Tiles::TileVectorInfo(prepareId, mCurrentFrameTimeMS));
				ri = mState.mVectorRenderInfo.find(prepareId);

				if (mState.getDebugVectorColors())
				{
					ri->second.color = lgal::Color::HashColor(prepareId, int(std::hash<std::string>()(layer->source)), 0xFF);
				}
			}
			else
			{
				ri->second.touch(mCurrentFrameTimeMS);
			}

			prepareId = prepareId.moduloX();

			// collect height info
			auto atlasInfo = Tiles::AtlasInfo::Compute(*heightAtlas, prepareId, heightZoomRange);
			if (atlasInfo.isValid())
			{
				ri->second.isReady = true;
				ri->second.heightAtlasInfo = atlasInfo;
				ri->second.meshResolution = (mStyle->hasTerrain()) ? MapMath::meshResolution(*heightSpec, prepareId) : 1;
			}

			std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(prepareId, true);
			std::shared_ptr<Tiles::HeightTile const> heightTile = heightAtlas->find(prepareId, true);

			if (vectorTile == nullptr || heightTile == nullptr) // No vectors available to display
			{
				continue;
			}

			if (prepareId.level > vectorTile->id().level)
			{
				ri->second.childIsLoading = vectorTile->id().level < source.specification()->maxZoom;
			}
			else
			{
				ri->second.childIsLoading = false;
			}

			if (layer->type == Styling::Layer::Types::LINE
				|| layer->type == Styling::Layer::Types::FILL
				|| layer->type == Styling::Layer::Types::SYMBOL)
			{
				Caching::LayerCache::EntryKey key = { prepareId, layer->id };
				Caching::PreparedData::Metadata metadata =
				{
					layer->type,
					layer->dependencies(mStyle->initArgs()),
					vectorTile->id(), std::max(vectorTile->timestampMS(layer->sourceLayer), heightTile->timestampMS()),
					mState.getZoom(), mState.mRenderCameraState,
					MapMath::meshResolution(*heightSpec, prepareId),
					mStyle->getExpressionContext(),
					mStyle->getLayoutContext(),
					mStyle->getPaintContext()
				};

				if (mLayerCache->replaces(key, metadata))
				{
					Caching::LayerCache::task_ptr_t task;
					switch (layer->type)
					{
					case Styling::Layer::Types::LINE:
						task.reset(new Caching::Tasks::VectorLineTask(mState.mRenderCameraState, prepareId, metadata, layer, vectorTile));
						break;
					case Styling::Layer::Types::FILL:
						task.reset(new Caching::Tasks::VectorFillTask(mState.mRenderCameraState, prepareId, metadata, layer, vectorTile));
						break;
					case Styling::Layer::Types::SYMBOL:
						task.reset(new Caching::Tasks::VectorSymbolTask(mState.mRenderCameraState, prepareId, metadata, layer, vectorTile, heightTile,
							mStyle->sprite(), ri->second));
						break;
					default:
						break;
					}
					mLayerCache->insert(key, std::move(task));
				}
				else
				{
					mLayerCache->touch(key);
				}
			}
		}
	}

	// TODO (stouff) wrap this into the above loop?
	for (std::shared_ptr<Styling::ContourLabelLayer const> const& layer : mStyle->visibleLayers<Styling::ContourLabelLayer>(mState.getZoom()))
	{
		LUCID_PROFILE_SCOPE("Cache contour data");

		std::shared_ptr<Styling::Source const> source = mStyle->source(layer->source);

		Atlases::HeightAtlas const* atlas = nullptr;
		{
			Caching::Source const& src = Caching::TileCache::Instance()->getSource(layer->source);
			atlas = static_cast<Atlases::HeightAtlas const*>(src.atlas());
			if (!atlas)
			{
				continue;
			}
		}

		std::vector<Tiles::TileId> filtered = Tiles::TileId::filter(tiles, std::max(layer->minZoom, source->minZoom), layer->maxZoom);
		
		for (Tiles::TileId const& tileId : filtered)
		{
			if (!atlas->contains(tileId))
			{
				continue;
			}

			auto tile = atlas->at(tileId);
			if (tile == nullptr)
			{
				continue;
			}

			Caching::PreparedData::Metadata metadata = 
			{ 
				layer->type, 
				layer->dependencies(mStyle->initArgs()),
				tileId, tile->timestampMS(),
				mState.getZoom(), mState.mRenderCameraState,
				MapMath::meshResolution(*heightSpec, tileId), 
				mStyle->getExpressionContext(),
				mStyle->getLayoutContext(),
				mStyle->getPaintContext()
			};

			Caching::LayerCache::EntryKey key = { tileId, layer->id };

			if (mLayerCache->replaces(key, metadata))
			{
				Caching::LayerCache::task_ptr_t task(new Caching::Tasks::ContourLabelTask(tileId, metadata, layer, tile));
				mLayerCache->insert(key, std::move(task));
			}
			else
			{
				mLayerCache->touch(key);
			}
		}
	}

	return complete;
}

bool Viewport::renderTiles(bgfx::ViewId const& renderId)
{
	bool complete = true;

	// TODO possibly compute/request neighbors of both parents/tileset so that rasters will always have the appropriate padding?

	{
		LUCID_PROFILE_SCOPE("precache tiles");
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(mState.mTileCollections.rasterGrandparents, mState.mTileCollections.vectorGrandparents, mStyle, mState.getZoom());
		if (Caching::TileCache::Instance()->precache(keys))
		{
			if (!mState.getCameraMoved())
			{
				// All of the higher-level tiles are cached; start fetching full detail
				keys = Viewport::CacheKeys(mState.mTileCollections.rasters, mState.mTileCollections.vectors, mStyle, mState.getZoom());
				Caching::TileCache::Instance()->precache(keys);
			}
		}
	}

	{
		LUCID_PROFILE_SCOPE("gather render info");
		complete &= gatherTextureRenderInfo(mState.mTileCollections.rasters);
		complete &= gatherVectorRenderInfo(mState.mTileCollections.vectors);

		// for the moment, we update after gathering vector render info but before rendering
		mLayerCache->update();
	}

	{
		LUCID_PROFILE_SCOPE("update terrain effects");

		size_t lines = 0;	// counting the number of contour line layers (temporary measure until shader lib is more flexible)
		for (auto const& layer : mStyle->visibleLayers(mState.getZoom()))
		{
			std::string const& id = layer->id;
			if (layer->isShaderLayer())	// if possible, avoid map lookup
			{
				auto it = mTerrainEffects.find(id);
				if (it != mTerrainEffects.end() && it->second->isVisible())
				{
					std::unique_ptr<TerrainEffects::TerrainEffectBase> const& effect = it->second;
					using T = Styling::Layer::Types;
					switch (layer->type)
					{
						case T::CONTOUR_LINE: update(static_cast<Styling::ContourLineLayer const&>(*layer), static_cast<TerrainEffects::ContourLine&>(*effect), lines); lines++; break;
						case T::ELEVATION:    update(static_cast<Styling::ElevationLayer   const&>(*layer), static_cast<TerrainEffects::ElevationShade&>(*effect));              break;
						case T::HILLSHADE:    update(static_cast<Styling::HillshadeLayer   const&>(*layer), static_cast<TerrainEffects::Hillshade&>(*effect));                   break;
						case T::INTERSECT:    update(static_cast<Styling::IntersectLayer   const&>(*layer), static_cast<TerrainEffects::IntersectShade&>(*effect));              break;
						case T::SLOPE_ANGLE:  update(static_cast<Styling::SlopeAngleLayer  const&>(*layer), static_cast<TerrainEffects::SlopeAngleShade&>(*effect));             break;
						case T::SLOPE_ASPECT: update(static_cast<Styling::SlopeAspectLayer const&>(*layer), static_cast<TerrainEffects::SlopeAspectShade&>(*effect));            break;
						case T::SUNLIGHT:     update(static_cast<Styling::SunlightLayer    const&>(*layer), static_cast<TerrainEffects::SunShadow&>(*effect));                   break;
						case T::VIEWSHED:     update(static_cast<Styling::ViewshedLayer    const&>(*layer), static_cast<TerrainEffects::Viewshed&>(*effect));                    break;
						default: break;
					}
				}
			}
		}
	}

	{
		LUCID_PROFILE_SCOPE("terrain draw");

		if (mState.getShowTextures() && mState.mTileRenderInfo.size() > 0)
		{
			for (auto& tileId : mState.mTileCollections.rasters)
			{
				auto ri = mState.mTileRenderInfo.find(tileId);
				if (ri->second.isReady)
				{
					renderTileTextures(renderId, ri->second);
				}
			}
		}
		if (mState.getShowVectors())
		{
			mCoveredFills.clear();

			auto vectorShader = mVectorShaderFamily.getShader(0);

			std::shared_ptr<Styling::RasterDemSource const> heightSpec = nullptr;
			if (mStyle->hasTerrain())
			{
				std::shared_ptr<Styling::Source const> const& source = mStyle->source(mStyle->terrain()->source);
				heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			}

			for (std::shared_ptr<Styling::SourcedLayer const> layer : mStyle->visibleLayers<Styling::SourcedLayer>(mState.getZoom()))
			{
				std::shared_ptr<Styling::Source const> source = mStyle->source(layer->source);

				int maxZoom = std::max((heightSpec) ? MapMath::maxDetailZoom(*heightSpec) : 0, source->maxZoom);
				std::vector<Tiles::TileId> clamped = Tiles::TileId::uniqueClampedToMaxLevel(mState.mTileCollections.vectors, maxZoom);
				std::vector<Tiles::TileId> filtered = Tiles::TileId::filter(clamped, source->minZoom, maxZoom);

				for (auto& tileId : filtered)
				{
					auto ri = mState.mVectorRenderInfo.find(tileId);
					if (ri != mState.mVectorRenderInfo.end() && ri->second.isReady)
					{
						renderTileVectors(renderId, ri->second, layer, vectorShader.get());
					}
				}
			}

			// clean up old vector render info
			std::vector<Tiles::TileId> toDelete;
			for (auto& [key, renderInfo] : mState.mVectorRenderInfo)
			{
				if (mCurrentFrameTimeMS - renderInfo.useTimestamp > getVectorFadeTime())
				{
					toDelete.push_back(key);
				}
			}

			for (auto const& key : toDelete)
			{
				mState.mVectorRenderInfo.erase(key);
			}
		}
	}

	return complete;
}

void Viewport::allocateTextures()
{
	// create color texture and set name
	{
		uint64_t flags = BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mColorTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		if (bgfx::isValid(mColorTarg))
		{
			bgfx::setName(mColorTarg, (std::to_string(mState.getId()) + " viewport color tex").c_str());
		}
	}

	{
		uint64_t flags = BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mColorReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		ONYX_ASSERT(bgfx::isValid(mColorReadbackHandle), "Failed to create color readback texture");
		bgfx::setName(mColorReadbackHandle, (std::to_string(mState.getId()) + " viewport color readback texture").c_str());
	}

	{
		uint64_t flags = BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mDepthTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		if (bgfx::isValid(mDepthTarg))
		{
			bgfx::setName(mDepthTarg, (std::to_string(mState.getId()) + " viewport RGBA8 float depth texture").c_str());
		}
	}

	// create z buffer texture and set name
	{
		mZBufferFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
		mZTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, mZBufferFormat, BGFX_TEXTURE_RT_WRITE_ONLY);
		if (bgfx::isValid(mZTarg))
		{
			bgfx::setName(mZTarg, (std::to_string(mState.getId()) + " viewport z buffer").c_str());
		}
	}

	{
		uint64_t requiredCaps = BGFX_CAPS_TEXTURE_BLIT | BGFX_CAPS_TEXTURE_READ_BACK;
		uint64_t caps = bgfx::getCaps()->supported;
		if ((caps & requiredCaps) == requiredCaps)
		{
			uint64_t flags = BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
			mDepthReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
			if (bgfx::isValid(mDepthReadbackHandle))
			{
				bgfx::setName(mDepthReadbackHandle, (std::to_string(mState.getId()) + " viewport RGBA8 depth readback buffer").c_str());
			}
		}
	}
}

void Viewport::deallocateTextures()
{
	BgfxUtils::tryDestroy(mColorTarg);
	BgfxUtils::tryDestroy(mDepthTarg);
	BgfxUtils::tryDestroy(mZTarg);
	BgfxUtils::tryDestroy(mColorReadbackHandle);
	BgfxUtils::tryDestroy(mDepthReadbackHandle);
}

void Viewport::allocateFramebuffers()
{
	// first deallocate all the old frame buffers
	deallocateFramebuffers();

	bgfx::TextureHandle colorDepthZHandles[] = { mColorTarg, mDepthTarg, mZTarg };
	mColorDepthZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorDepthZHandles), colorDepthZHandles, false);
	if (bgfx::isValid(mColorDepthZFrameBuffer))
	{
		bgfx::setName(mColorDepthZFrameBuffer, (std::to_string(mState.getId()) + " viewport color/depth/z framebuffer").c_str());
	}

	bgfx::TextureHandle colorZHandles[] = { mColorTarg, mZTarg };
	mColorZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorZHandles), colorZHandles, false);
	if (bgfx::isValid(mColorZFrameBuffer))
	{
		bgfx::setName(mColorZFrameBuffer, (std::to_string(mState.getId()) + " viewport color/z framebuffer").c_str());
	}
}

void Viewport::deallocateFramebuffers()
{
	BgfxUtils::tryDestroy(mColorZFrameBuffer);
	BgfxUtils::tryDestroy(mColorDepthZFrameBuffer);
}

void Viewport::setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration)
{
	invalidate();
	if (shader == ShaderEnums::ConfigurableShaders::Terrain)
	{
		mTerrainShaderFamily.setCurrentShaderByParams(params, configuration);
	}
}

void Viewport::invalidate()
{
	mState.invalidate();
}

void Viewport::setStyle(std::shared_ptr<Styling::Style> style)
{
	mStyle = style;
	mLayerCache->clear();
	syncSources();
	invalidate();

	if (style->hasSpritesheet())
	{
		// Parse sprite stylesheet
		auto names = Utils::splitString(style->spritesheetUrl(), '/');
		auto const numNames = names.size();
		ONYX_ASSERT(numNames >= 3, "Sprite URL should at least have [app]/[version number]/[spritesheet name]");
		std::string spritePath = "assets/spritesheets";
		for (size_t i = numNames - 3; i < numNames; ++i)
		{
			spritePath += '/' + names[i];
		}

		auto spriteJson = nlohmann::json::parse(core::FileSystem::readText(spritePath + ".json"));
		auto spritesheet = std::make_shared<Styling::Spritesheet>();
		from_json(spriteJson, *spritesheet);
		spritesheet->path = spritePath;
		style->addSpritesheet(spritesheet);
		
		// Insert sprite sheet
		mState.mSpriteAtlas.erase();

		std::string atlasPngPath = spritesheet->path + ".png";
		bgfx::TextureInfo texInfo;
		auto texHndl = BgfxUtils::loadTexture(atlasPngPath, 0, 0, &texInfo);
		ONYX_ASSERT(bgfx::isValid(texHndl), "Failed to load spritesheet texture");

		std::vector<Atlases::TextureAtlas<std::string>::SpriteIdx> idxs;
		idxs.reserve(spritesheet->indices.size());
        for (auto const& [name, spriteIdx] : spritesheet->indices)
        {
            // load into the SpriteIdx array
            Atlases::PageLocation pgLoc;
            pgLoc.position = spriteIdx.xy;
            pgLoc.size = spriteIdx.sizePx.as<screen_coord_t>();
            idxs.push_back({ spriteIdx.name, pgLoc });
        }

        mState.mSpriteAtlas.insertSpritesFull(texHndl, spritesheet->path, texInfo, idxs);
		mState.mSpriteAtlas.setName(spritesheet->path);

        // Add the atlas UV offsets to the sprite sheet
        for (auto& [name, spriteIdx] : spritesheet->indices)
        {
            auto uvOffset = mState.mSpriteAtlas.getUVOffset(name);
            spriteIdx.uvOffset = uvOffset;
        }
	}
}

void Viewport::syncSources()
{
	Styling::Source::zoom_level_t maxZoom = 0;
	for (auto const& name : mStyle->activeSources())
	{
		std::shared_ptr<Styling::Source const> source = mStyle->source(name);
		if (source->isHeight())
		{
			auto height = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			maxZoom = std::max(maxZoom, MapMath::maxDetailZoom(*height));
		}
		else
		{
			maxZoom = std::max(maxZoom, source->maxZoom);
		}
	}
	mState.setMaxSubdDepth(maxZoom);

	// add all dirty sources to TileCache
	for (std::string const& name : mStyle->dirtySourceNames())
	{
		// if TileCache already knows about a tiled source, it won't do anything
		Caching::TileCache::Instance()->addSource(name, mStyle->source(name));
	}

	touchRootTiles();
}

void Viewport::syncLayers()
{
	// utilize a const& to avoid overload confusion with private non-const methods of Style
	Styling::Style const& style = *mStyle;

	// NOTE: removing must occur first for correctness
	for (std::string const& id : style.removedLayerIds())
	{
		mTerrainEffects.erase(id);		// ignored if the layer is not present
	}

	// if necessary, allocate a terrain effect
	for (std::string const& id : style.addedLayerIds())
	{
		Styling::Layer::Types type = style.layer(id)->type;
		using T = Styling::Layer::Types;
		switch (type)
		{
			case T::CONTOUR_LINE: mTerrainEffects[id] = std::make_unique<TerrainEffects::ContourLine>();      break;
			case T::ELEVATION:    mTerrainEffects[id] = std::make_unique<TerrainEffects::ElevationShade>();   break;
			case T::HILLSHADE:    mTerrainEffects[id] = std::make_unique<TerrainEffects::Hillshade>();        break;
			case T::INTERSECT:    mTerrainEffects[id] = std::make_unique<TerrainEffects::IntersectShade>();   break;
			case T::SLOPE_ANGLE:  mTerrainEffects[id] = std::make_unique<TerrainEffects::SlopeAngleShade>();  break;
			case T::SLOPE_ASPECT: mTerrainEffects[id] = std::make_unique<TerrainEffects::SlopeAspectShade>(); break;
			case T::SUNLIGHT:     mTerrainEffects[id] = std::make_unique<TerrainEffects::SunShadow>();        break;
			case T::VIEWSHED:     mTerrainEffects[id] = std::make_unique<TerrainEffects::Viewshed>();         break;
			default: break;
		}
	}

	// compute all updated layers
	std::set<std::string> updated = style.addedLayerIds();
	updated.insert(style.editedLayerIds().begin(), style.editedLayerIds().end());
	for (std::string const& id : updated)
	{
		// update LayerCache with a non-immediate purge of all updated layers
		mLayerCache->purge(id, false);
	}

	// sync visibility for terrain effects
	for (auto const& layer : style.layers())
	{
		auto found = mTerrainEffects.find(layer->id);
		if (found != mTerrainEffects.end())
		{
			bool enabled = layer->isVisible() && layer->range().contains(mState.getZoom());
			found->second->toggle(enabled);
		}
	}
}

void Viewport::touchRootTiles()
{
	// prefetch the top level tiles
	for (auto const& [name, source] : mStyle->sources())
	{
		if (source->minZoom == 0)
		{
			Caching::TileCache::Instance()->at({ name, { 0, 0, 0 } });
		}
	}
}

Styling::Expressions::Arguments Viewport::expressionArgs() const
{
	return
	{
		mState.getZoom(),
		lmath::radiansToDegrees(mState.mRenderCameraState.heading),
		lmath::radiansToDegrees(mState.mRenderCameraState.pitch),
		mStyle->getExpressionContext()
	};
}

bool Viewport::assignTerrainShaderFamily()
{
	std::vector<Styling::Layer::Types> layers;
	for (auto const& layer : mStyle->visibleLayers(mState.getZoom()))
	{
		if (layer->isShaderLayer())
		{
			layers.push_back(layer->type);
		}
	}

	// only reload the shader when necessary -- it may be the case that layers got toggled but the necessary shader didn't change
	// eg: a layer was removed and then a layer of the same type was added in the same location
	if (layers != mTerrainShaderLayers)
	{
		Shaders::ConfigurableShader family;
		family.loadSignature(ShaderManager::Instance()->getDefaultConfiguration(ShaderEnums::ConfigurableShaders::Terrain));

		for (auto const& layer : mStyle->visibleLayers(mState.getZoom()))
		{
			switch (layer->type)
			{
				case Styling::Layer::Types::CONTOUR_LINE: family.toggleComponent("ContourLine", true); break;
				case Styling::Layer::Types::ELEVATION:    family.toggleComponent("ElevationShade", true); break;
				case Styling::Layer::Types::HILLSHADE:    family.toggleComponent("Hillshade", true); break;
				case Styling::Layer::Types::INTERSECT:    family.toggleComponent("IntersectShade", true); break;
				case Styling::Layer::Types::RASTER:       family.toggleComponent("TextureLayer", true); break;
				case Styling::Layer::Types::SLOPE_ANGLE:  family.toggleComponent("SlopeAngleShade", true); break;
				case Styling::Layer::Types::SLOPE_ASPECT: family.toggleComponent("SlopeAspectShade", true); break;
				case Styling::Layer::Types::SUNLIGHT:     family.toggleComponent("Sunlight", true); break;
				case Styling::Layer::Types::VIEWSHED:     family.toggleComponent("Viewshed", true); break;
				default: break;
			}
		}

		if (family.count() == 0)
		{
			ONYX_THROW("Unable to load terrain shader!");
		}

		mTerrainShaderLayers = layers;
		mTerrainShaderFamily = family;
		return true;
	}

	return false;	// fallthrough to return false
}

void Viewport::update(Styling::ContourLineLayer const& layer, TerrainEffects::ContourLine& effect, size_t index)
{
	Styling::ContourLineConfig config = layer.realizeContourLineConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext()});
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, index, { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::ElevationLayer const& layer, TerrainEffects::ElevationShade& effect)
{
	Styling::ElevationConfig config = layer.realizeElevationConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, atlas.heightExtents(mState.mTileCollections.rasters, false), {layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS});
}

void Viewport::update(Styling::HillshadeLayer const& layer, TerrainEffects::Hillshade& effect)
{
	Styling::HillshadeConfig config = layer.realizeHillshadeConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::IntersectLayer const& layer, TerrainEffects::IntersectShade& effect)
{
	Styling::IntersectConfig config = layer.realizeIntersectConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, atlas.heightExtents(mState.mTileCollections.rasters, false), { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SlopeAngleLayer const& layer, TerrainEffects::SlopeAngleShade& effect)
{
	Styling::SlopeAngleConfig config = layer.realizeSlopeAngleConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SlopeAspectLayer const& layer, TerrainEffects::SlopeAspectShade& effect)
{
	Styling::SlopeAspectConfig config = layer.realizeSlopeAspectConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext() });
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SunlightLayer const& layer, TerrainEffects::SunShadow& effect)
{
	// TODO consider just using the terrain source for SunShadow
	Styling::SunlightConfig config = layer.realizeSunlightConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext()});
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, getFrameCullState(), { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::ViewshedLayer const& layer, TerrainEffects::Viewshed& effect)
{
	// TODO consider just using the terrain source for Viewshed
	Styling::ViewshedConfig config = layer.realizeViewshedConfig({ expressionArgs(), mStyle->getLayoutContext(), mStyle->getPaintContext()});
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mState.mRenderCameraState, mCurrentFrameTimeMS });
}

std::vector<Caching::TileCacheKey> Viewport::CacheKeys(std::vector<Tiles::TileId> const& rasters, std::vector<Tiles::TileId> const& vectors, std::shared_ptr<Styling::Style const> style, float const zoom)
{
	LUCID_PROFILE_SCOPE("compute cache keys");
	
	std::vector<Tiles::TileId> rastersModuloX = Tiles::TileId::uniqueModuloX(rasters);
	std::vector<Tiles::TileId> vectorsModuloX = Tiles::TileId::uniqueModuloX(vectors);

	std::unordered_set<Tiles::TileId> const vectorSet(vectorsModuloX.begin(), vectorsModuloX.end());

	std::vector<std::string> activeSources = style->activeSources(zoom);

	std::vector<Caching::TileCacheKey> keys;
	keys.reserve(activeSources.size() * rastersModuloX.size());

	// only iterate over rasters because we assume vectors is a subset of rasters
	for (Tiles::TileId const& requestId : rastersModuloX)
	{
		for (std::string const& name : activeSources)
		{
			std::shared_ptr<Styling::Source const> const& source = style->source(name);

			if (source->minZoom <= requestId.level)
			{
				if (source->isRaster())
				{
					// adjust based on the resolution of the height tiles
					auto raster = std::static_pointer_cast<Styling::RasterSource const>(source);
					auto adjustment = Tiles::TileId::IdCoordsT(std::log2(std::max(raster->tileSize / 256, 1u)));
					Tiles::TileId submittedId = requestId.parent(std::min(adjustment, requestId.level - source->minZoom));
					submittedId = (submittedId.level <= source->maxZoom) ? submittedId : submittedId.parentAtLevel(source->maxZoom);
					keys.push_back({ name, submittedId });
				}
				else if (source->isVector() && vectorSet.find(requestId) != vectorSet.end())
				{
					Tiles::TileId submittedId = (requestId.level <= source->maxZoom) ? requestId : requestId.parentAtLevel(source->maxZoom);
					keys.push_back({ name, submittedId });
				}
			}
		}
	}

	return keys;
}


bool Viewport::hasIconImg(std::string id) 
{ 
	return mStyle->hasSprite(id); 
}

bool Viewport::addIconImg(std::string id, std::string url)
{
    if (hasIconImg(id))
    {
        logI("Sprite atlas entry already exists for " + id);
		return false;
    }

    bgfx::TextureInfo tInfo{};
    auto tHndl = BgfxUtils::loadTexture(url, 0, 0, &tInfo);
    if (!bgfx::isValid(tHndl))
    {
		logI("Failed to load texture from  " + url);
		return false;
    }
	
	mState.mSpriteAtlas.insert(id, tHndl, tInfo);
	if (!mState.mSpriteAtlas.contains(id))
	{
		logI("Failed to add " + id + " to Sprite Atlas");
		return false;
	}

	Styling::SpriteIndex idx{};
    idx.name = id;
    idx.sizePx = lgal::gpu::Vector2{ gpu_float_t(tInfo.width), gpu_float_t(tInfo.height) };
    idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
    idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };
    idx.content = { { 0, 0 }, { tInfo.width, tInfo.height } };
    idx.uvOffset = mState.mSpriteAtlas.getUVOffset(id);
    mStyle->addSprite(idx);

    return true;
}

void Viewport::compositeImages(std::string id, std::vector<std::string> const& filePaths)
{
	if (hasIconImg(id))
	{
		logE(id + " is already in SpriteAtlas!");
		return;
	}

	std::vector<bgfx::TextureHandle> tHndls;
	tHndls.reserve(filePaths.size());

	bgfx::TextureInfo tInfo = {};
	
	for (auto const& path : filePaths)
	{
		auto tHndl = BgfxUtils::loadTexture(path.c_str(), 0, 0, &tInfo);
		if (!bgfx::isValid(tHndl))
		{
			logE("Failed to load texture from " + path);
			for (auto h : tHndls)
			{
				BgfxUtils::tryDestroy(h);
			}
			return;
		}
		tHndls.push_back(tHndl);
	}

	if (!tHndls.empty())
	{
		mState.mSpriteAtlas.compositeTextures(id, tHndls,
			lgal::screen::Vector2{ screen_coord_t(tInfo.width), screen_coord_t(tInfo.height) },
			tInfo.format);

        Styling::SpriteIndex idx{};
        idx.name = id;
        idx.sizePx = lgal::gpu::Vector2{ gpu_float_t(tInfo.width), gpu_float_t(tInfo.height) };
        idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
        idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };
        idx.content = { { 0, 0 }, { tInfo.width, tInfo.height } };
        idx.uvOffset = mState.mSpriteAtlas.getUVOffset(id);
        mStyle->addSprite(idx);
	}
}

}
