#include "Viewport.h"

#include <unordered_set>

#include <lucid/Profiler.h>
#include <Shaders/ShaderDefinition.h>
#include <Styling/Parse/MiscJson.h>

#include "Atlases/HeightAtlas.h"
#include "Atlases/TileAtlas.h"
#include "Caching/Tiles/TileCache.h"
#include "Caching/Layers/Tasks/FillTasks.h"
#include "Caching/Layers/Tasks/LineTasks.h"
#include "Caching/Layers/Tasks/SymbolTasks.h"
#include "Caching/Layers/Tasks/HeightTileTasks.h"
#include "Camera/Controllers/Identity.h"
#include "DataObjects/Symbol/SymbolManager.h"
#include "DataObjects/WaypointManager.h"
#include "Events/Events.h"
#include "Experimental/ParticleSystem.h"
#include "Rendering/Render.h"
#include "Tiles/TileRenderInfo.h"
#include "Tiles/TileMesh.h"
#include "Utils/Timer.h"
#include "Utils/BgfxUtils.h"

namespace onyx
{

// TODO refactor so this is no longer necessary
static std::map<TextureType, std::array<std::string, 3>> sTextureShaderMapping =
{
	{ TextureType::Basemap,			{ "s_texture0", "u_ScaleOffsetTex0", "u_OpacityTex0" } },
	{ TextureType::Basemap2,		{ "s_texture1", "u_ScaleOffsetTex1", "u_OpacityTex1" } },
	{ TextureType::Height,			{ "s_heightTexture", "u_ScaleOffsetHeight", "" } },
	{ TextureType::Weather,			{ "s_texture0", "u_ScaleOffsetTex0", "u_OpacityTex0" } },
	{ TextureType::Roads,			{ "s_texture1", "u_ScaleOffsetTex1", "u_OpacityTex1" } },
	{ TextureType::LocalData,		{ "s_texture2", "u_ScaleOffsetTex2", "u_OpacityTex2" } },
};

static void SetTextureParameters(Tiles::AtlasInfo const& info, Shaders::ShaderDefinition* shader, TextureType textureType)
{
	auto const& texInfo = sTextureShaderMapping.at(textureType);
	std::string const& texName = texInfo[0];
	std::string const& uvOffsetName = texInfo[1];
	std::string const& opacity = texInfo[2];

	shader->setParameter(texName, info.handle, info.resolution, info.resolution);
	shader->setParameter(uvOffsetName, info.offset);
	shader->setParameter(opacity, info.opacity);
}

Viewport::Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
	mId(viewportId),
	mTileLoadTimeMS(Utils::Timer::nowMS(), 0.0),
	mState(wRatio, hRatio, sortOrder),
	mController(std::make_shared<Camera::Controllers::Identity>()),
	mRenderCameraState(state),
	mCullCameraState(state),
	mZoomFilter(250.0),
	mStyle(new Styling::Style()),
	mTextureAtlas(Atlases::cRenderFlags, Atlases::cDefaultCellSize, Atlases::cDefaultResolution, 0),
	mLayerCache(new Caching::LayerCache()),
	mSkydome(new Drawers::Skydome()),
	mLineMesh(new Rendering::VectorLineMesh())
{
#ifdef PLATFORM_EMSCRIPTEN
	mDepthCameras.resize(1);
#else
	mDepthCameras.resize(2);
#endif

	allocateTextures();
	allocateFramebuffers();
	
	mSymbolManager.reset(new DataObjects::SymbolManager(this));
	mSymbolManager->initialize();
	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
}

Viewport::~Viewport()
{
	deallocateTextures();
	deallocateFramebuffers();
}

bgfx::TextureHandle Viewport::getTexture()
{
	if (bgfx::isValid(mColorDepthZFrameBuffer) && bgfx::isValid(mColorZFrameBuffer) && bgfx::isValid(mColorTarg)) { return mColorTarg; }
	return BGFX_INVALID_HANDLE;
}

void Viewport::renderScreenLines()
{
	if (mState.getScreenLines().empty()) { return; }

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw screen-space lines");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);
	
	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA;
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		;

	for (auto const& styles : mState.getScreenLines())
	{
		auto const& instances = styles.second;
		if (instances.empty()) { continue; }
		Rendering::render(renderId, instances, styles.first, *mLineMesh, state, *shader);
	}
}

void Viewport::renderScreenSpaceManager()
{
	if (mScreenSpaceManager.empty() || !mState.getShowScreenSpaceManager())
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw Screen Space Manager");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		;

	screenLineVector_t instances;

	auto res = size().as<gpu_float_t>();
	auto xScale = 2.f / res.x;
	auto yScale = 2.f / res.y;

	for (auto const &screenRect : mScreenSpaceManager)
	{
		auto GPURect = screenRect.as<gpu_float_t>();
		static const std::array<int, 4> nextPts = { 1, 3, 0, 2 };

		for (int i = 0; i < GPURect.VERTEX_COUNT(); ++i)
		{
			lgal::gpu::LineSegment2 segment(GPURect.vertex(i), GPURect.vertex(nextPts[i]));

			lgal::gpu::Vector2 p1(segment.start.x * xScale - 1, (segment.start.y * yScale - 1));

			p1.y *= -1;
			auto dir = lucid::math::normalize(segment.direction());
			dir.y *= -1;

			instances.push_back(Rendering::VertStructs::ScreenLineData(0, 0, 0xFFFF0000, { p1, 0 }, { dir, 0 }, segment.length(), 3.0 ));
		}
	}

	if (instances.empty())
	{
		return;
	}

	Rendering::render(renderId, instances, "dotted", *mLineMesh, state, *shader);
}

// TODO (scott)
// Might be better to have this convenience function be part of the style class?
Atlases::HeightAtlas const* Viewport::getHeightAtlas() const
{
	if (!mStyle->hasTerrain()) { return nullptr; }
	auto const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
	return static_cast<Atlases::HeightAtlas const*>(source.atlas());
}

void Viewport::render(time_float_t timeMS)
{
	mCurrentFrameTimeMS = timeMS;
	mLayerCache->setFrameTimeMS(timeMS);
	mState.mFrameRenderStats.reset();

	// check ViewportState for updated settings
	if (mState.getIsDirty()) { invalidate(); mState.setIsDirty(false); }

	// update sources so the camera uses the most recent height atlas if there was a change
	if (mStyle->hasDirtySources()) { syncSources(); }
	auto heightAtlas = getHeightAtlas();	// compute height atlas if we have the source

	Camera::CameraState newState = mController->update(mRenderCameraState, timeMS, heightAtlas, mExaggeration);
	if (!newState.isValid())
	{
		// Don't set the camera to an invalid state; just use the previous state
		newState = mRenderCameraState;
	}

	newState.aspect = getAspect();	// override aspect ratio with viewport value

	bool cameraWasMoving = mCameraMoved;
	mCameraMoved = newState != mRenderCameraState;

	// trigger camera-related events
	toggle(ViewportCompletionFlags::CAMERA, !mCameraMoved);
	if (mCameraMoved)
	{
		toggle(cAllPrepareFlags, false);
		mRenderCameraState = newState;
		if (mState.getSyncCameraStates()) { mCullCameraState = mRenderCameraState; }
		mRenderCameraState.updateViewProj();
		Events::trigger(Events::EventType::CAMERA_MOVED);
	}
	else if (cameraWasMoving)
	{
		Events::trigger(Events::EventType::CAMERA_STOPPED);
		lgal::world::Range r = lgal::world::Range(Utils::Timer::nowMS(), 0.0);
		mTileLoadTimeMS = r;
	}

	// compute zoom for this frame
	{
		LUCID_PROFILE_SCOPE("compute zoom");

		// update filter
		mZoomFilter.update(timeMS);

		// compute zoom
		mZoom = computeZoom();

		// push to filter and compute filtered zoom
		mZoomFilter.push(mZoom, timeMS);
		mFilteredZoom = mZoomFilter.avg();
		
		// convert to km
		mZoomKm = static_cast<float>(MapMath::zoomToKm(mZoom));
		mFilteredZoomKm = static_cast<float>(MapMath::zoomToKm(mFilteredZoom));

		// round to reduce how often zoom changes
		mZoom = Viewport::AliasZoom(mZoom);
		mFilteredZoomKm = Viewport::AliasZoom(mFilteredZoomKm);
	}

	// update style-related info as necessary (note that sources were updated prior to utilizing the camera)
	{
		if (mStyle->hasQueuedTasks())	// check if we have any queued tasks
		{
			// request a pause on the prepare thread. once paused, flush the style edits and then unpause the prepare thread
			if (mLayerCache->requestPause())
			{
				mStyle->flushTasks();
				mLayerCache->resume();
			}
		}

		if (mStyle->isDirty()) { invalidate(); }
		if (mStyle->hasSpritesheet()) { mTextureAtlas.update(); }
		syncLayers();
		mStyle->update();

		if (mStyle->hasTerrain()) { mExaggeration = mStyle->terrain()->exaggeration->evaluate(expressionArgs()); }
		if (assignTerrainShaderFamily()) { invalidate(); }
	}

	// compute information global to the style
	{
		// realize fog style and convert to world units
		Styling::realize(layerArgs(), mStyle->fog(), mFogStyle);
		mHorizon.convert(mFogStyle, mFilteredZoomKm);
	}

	touchRootTiles();

	// precache tiles associated with the controller's highlight states
	std::vector<Camera::CameraState> highlights = mController->highlights();
	for (auto const& highlight : highlights)
	{
		Pyramid::CullResult cullRes = Pyramid::cull(highlight, mState.getLODScaler(), mDeepestZoomLevel, heightAtlas, mExaggeration);
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(Tiles::TileId::uniqueParents(cullRes.tileIds, 2), mStyle, mZoom);
		// only continue processing if the tiles are precached
		if (!Caching::TileCache::Instance()->precache(keys))
		{
			break;
		}
	}

	auto cacheTimestamp = Caching::TileCache::Instance()->getUpdateTimestamp();
	auto cacheUpdated = cacheTimestamp > mLastCacheUpdate;	// until we have more granular information, we must assume that any new cache info triggers culling/rendering
	mLastCacheUpdate = cacheTimestamp;
	toggle(ViewportCompletionFlags::CACHE_UPDATE, !cacheUpdated);

	if (mCameraMoved || mForceCulling || cacheUpdated)
	{
		// reset tile load time when the camera moves

		auto &cullState = getFrameCullState();
		if (mState.getCullingEnabled())
		{
			mCullStateChanged = true;

			LUCID_PROFILE_SCOPE("culling");
			mRasterRenderInfo.clear();
			cullState.reset();
			Pyramid::cull(cullState, mCullCameraState, mState.getLODScaler(), mDeepestZoomLevel, heightAtlas, mExaggeration);
			cullState.tileIds = Tiles::TileId::filter(cullState.tileIds, mState.getTileZoomRange().begin, mState.getTileZoomRange().end);
		}
	}

	if (mIncompleteRenderComponents == ViewportCompletionFlags::NONE && mState.getQuiescenceMode()) // Nothing to do; render was already completed and nothing has changed.
	{
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(getFrameCullState().tileIds, mStyle, mZoom);
		Caching::TileCache::Instance()->touch(keys);
		return;
	}

	toggle(ViewportCompletionFlags::INVALIDATED, true); // Always clear this bit because "invalidate" just forces a rerender once

	mScreenSpaceManager.clear();
	mTerrainShaderFamily.setParameter("u_eyePos", mRenderCameraState.position);
	mTerrainShaderFamily.setParameter("u_NearFarFocus", lgal::world::Vector3(mRenderCameraState.nearClip, mRenderCameraState.farClip, mZoomKm));
	mTerrainShaderFamily.setParameter("u_FogTransition", mFogStyle.range);
	mTerrainShaderFamily.setParameter("u_FogColor", mFogStyle.color);

	if (mSkydome)
	{
		auto id = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::Skydome, 0);
		auto p = shader->parameters["u_hazeColor"];
		bgfx::setViewClear(id, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, p->mColor.rgba(), 1.0f, 0);
		bgfx::setViewFrameBuffer(id, mColorDepthZFrameBuffer);
		bgfx::setViewRect(id, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());
		mSkydome->draw(id, mRenderCameraState, shader);
	}

	renderTiles();
	renderWaypoints();
	renderSymbols();

	renderScreenLines();
	renderScreenSpaceManager();

	Experimental::ParticleSystem::draw(mRenderCameraState, lgal::gpu::Vector2{ getWidthPixel(), getHeightPixel() }, mColorZFrameBuffer);
	
	mState.mLifetimeRenderStats += mState.mFrameRenderStats;
	swapTripleBuffers();
}

void Viewport::readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue)
{
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(float);
	if (mDepthData.size() < dataSize)
	{
		mDepthData.resize(dataSize);
		if (defaultValue != 0)
		{
			std::memset(mDepthData.data(), defaultValue, mDepthData.size());
		}
	}

	auto data = mDepthData.data();
	bgfx::blit(viewId, mDepthReadbackHandle, 0, 0, mDepthTarg);
	bgfx::readTexture(mDepthReadbackHandle, data);

	mDepthCameras[mDepthCameraIndex] = mRenderCameraState;
	mDepthCameraIndex = (mDepthCameraIndex + 1) % mDepthCameras.size();
}

void Viewport::copyDepth(std::vector<uint8_t>& target) const
{
	target.resize(mDepthData.size());
	std::copy(mDepthData.begin(), mDepthData.end(), target.begin());
}

void Viewport::copyColor(std::vector<uint8_t> &target, uint8_t defaultValue) const
{
	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(uint32_t);
	if (target.size() != dataSize)
	{
		target.resize(dataSize);
		if (defaultValue != 0)
		{
			std::memset(target.data(), defaultValue, target.size());
		}
	}

	auto data = target.data();
	bgfx::blit(viewId, mColorReadbackHandle, 0, 0, mColorTarg);
	bgfx::readTexture(mColorReadbackHandle, data);
}

void Viewport::resize()
{
	// set the camera state aspect
	setController(std::make_shared<Camera::Controllers::Identity>());
	mRenderCameraState.aspect = getAspect();
	mCullCameraState.aspect = getAspect();

	// reallocate textures of the appropriate size
	deallocateTextures();
	allocateTextures();

	// reallocate frame buffers with those textures
	deallocateFramebuffers();
	allocateFramebuffers();

	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
	invalidate();
}

void Viewport::setController(std::shared_ptr<Camera::CameraController> controller)
{
	mController = controller;
}

void Viewport::setCameraState(Camera::CameraState const& state)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mRenderCameraState = state; // normal mode, keep render and cull in sync
	mCullCameraState = state;
	mState.setSyncCameraStates(true);
}

void Viewport::setCameraState(Camera::CameraState const& render, Camera::CameraState const& cull)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mRenderCameraState = render; // primarily for debugging, lets us split the view the terrain calculates with, and the view we see the terrain from
	mCullCameraState = cull;
	mState.setSyncCameraStates(false);
}

gpu_float_t Viewport::depthAtPixel(int screenX, int screenY) const
{
	auto depthData = (uint8_t*)mDepthData.data();
	size_t y = size_t(screenY);
	if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
	{
		y = size_t(getHeightPixel()) - 1 - y;
	}
	auto depthIndex = (size_t(screenX) + (y * size_t(mState.getWidthPixel()))) * 4;
	if (depthIndex < mDepthData.size())
	{
		auto r = depthData[depthIndex] * (1.f / 255.f);
		auto g = depthData[depthIndex + 1] * (1.f / 255.f);
		auto b = depthData[depthIndex + 2] * (1.f / 255.f);
		auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
		return result;
	}
	return -1;
}

gpu_float_t Viewport::depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const
{
	// grab width and height
	float w = mState.getWidthPixel();
	float h = mState.getHeightPixel();

	// convert from normatlized to uv cooridinates
	float u = 0.5f * (normalizedScreen.x + 1.f);
	float v = 0.5f * (normalizedScreen.y + 1.f);
	
	// compute pixel coordinates and return depth
	int x = static_cast<int>(std::min(u * w, w - 1.f));
	int y = static_cast<int>(std::min(v * h, h - 1.f));
	return depthAtPixel(x, y);
}

lgal::world::Vector3 Viewport::unprojectPixel(int screenX, int screenY) const
{
	auto depth = depthAtPixel(screenX, screenY) * 2.0f - 1.0f;
	float x = (screenX / mState.getWidthPixel()) * 2.0f - 1.0f;
	float y = (screenY / mState.getHeightPixel()) * 2.0f - 1.0f;
	lgal::world::Vector3 normalizedCoords = { x, y, depth };
	return unprojectNormalized(normalizedCoords);
}

lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const
{
	auto depth = depthAtNormalized(normalizedScreen.as<gpu_float_t>()) * 2.0f - 1.0f;
	lgal::world::Vector3 normalizedCoords = { normalizedScreen, depth };
	return unprojectNormalized(normalizedCoords);
}

// TODO change architecture so that the unprojected point is more accurate
// the height discrepancy is really off when the camera is zoomed out
lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const
{
	Camera::CameraState::ProjectionData unprojected = mDepthCameras[mDepthCameraIndex].unproject(normalizedPos);
	lgal::world::Vector3 result = unprojected.position;

	// override z with a more accurate value
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(result.xy));
		distortedHeightKm *= mExaggeration;
		result.z = distortedHeightKm;
	}
	else
	{
		result.z = 0.0;
	}

	return result;
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector2 const& pos) const
{
	// compute z with a more accurate value
	height_float_t z = 0.0;
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(pos));
		distortedHeightKm *= mExaggeration;
		z = distortedHeightKm;
	}
	return project(lgal::world::Vector3{ pos, z });
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector3 const& pos) const
{
	Camera::CameraState::ProjectionData projected = mRenderCameraState.project(pos);
	return projected.position;
}

float Viewport::computeZoom() const
{
	lgal::world::Vector3 eye = mRenderCameraState.position;

	// start off by computing the zoom in one of two reasonable locations
	lgal::world::Vector3 center = unprojectNormalized(lgal::world::Vector2{ 0.f, 0.f });
	lgal::world::Vector3 bottom = unprojectNormalized(lgal::world::Vector2{ 0.f, 1.f });
	world_float_t dist = std::min(lmath::len(eye - center), lmath::len(eye - bottom));
	size_t count = 1;
	
	// if the depth is close enough, add some more sample locations
	int height = static_cast<int>(mState.getHeightPixel());
	int width = static_cast<int>(mState.getWidthPixel());
	int steps = 20;
	for (int y = height / 2; y < height; y += height / steps)
	{
		for (int x = width / 2; x < width; x += width / steps)
		{
			if (depthAtPixel(x, y) < 1.f)
			{
				dist += lmath::len(eye - unprojectPixel(x, y));
				++count;
			}
		}
	}
	

	// average the distances
	if (count > 0) { dist /= static_cast<world_float_t>(count); }

	// compute and return the zoom
	world_float_t zoom = MapMath::zoom(dist);
	return static_cast<float>(zoom);
}

void Viewport::setMatrixUniforms(bgfx::ViewId const& viewId)
{
	mRenderCameraState.updateViewProj();
	bgfx::setViewTransform(viewId, mRenderCameraState.view, mRenderCameraState.proj);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)mState.getWidthPixel(), (uint16_t)mState.getHeightPixel());
}

void Viewport::renderTiles()
{
	LUCID_PROFILE_SCOPE("viewport terrain render");

	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewMode(viewId, bgfx::ViewMode::Sequential);

	if (!mSkydome) { bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0); }

	bgfx::setViewName(viewId, (std::string("viewport terrain ") + std::to_string(mId)).c_str());
	bgfx::setViewFrameBuffer(viewId, mColorDepthZFrameBuffer);
	setMatrixUniforms(viewId);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());

	{
		// TODO possibly compute/request neighbors of both parents/tileset so that rasters will always have the appropriate padding?
		LUCID_PROFILE_SCOPE("precache tiles");
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(Tiles::TileId::uniqueParents(getFrameCullState().tileIds, 2), mStyle, mZoom);
		auto parentsPrecached = Caching::TileCache::Instance()->precache(keys);
		toggle(ViewportCompletionFlags::PRECACHE_PARENTS, parentsPrecached);
		bool precached = false;
		if (parentsPrecached)
		{
			// All of the higher-level tiles are cached; start fetching full detail
			keys = Viewport::CacheKeys(getFrameCullState().tileIds, mStyle, mZoom);
			precached = Caching::TileCache::Instance()->precache(keys);
		}
		toggle(ViewportCompletionFlags::PRECACHE, precached);
	}

	// for the moment, we update after preparing tiles but before rendering
	prepare(getFrameCullState().tileIds);

	mLayerCache->update();

	{
		LUCID_PROFILE_SCOPE("update terrain effects");

		size_t lines = 0;	// counting the number of contour line layers (temporary measure until shader lib is more flexible)
		for (auto const& layer : mStyle->visibleShaderLayers(mZoom))
		{
			std::string const& id = layer->id;
			auto it = mTerrainEffects.find(id);
			if (it != mTerrainEffects.end() && it->second->isVisible())
			{
				std::unique_ptr<TerrainEffects::TerrainEffectBase> const& effect = it->second;
				using T = Styling::Layer::Types;
				switch (layer->type)
				{
					case T::CONTOUR_LINE: update(static_cast<Styling::ContourLineLayer const&>(*layer), static_cast<TerrainEffects::ContourLine&>(*effect), lines); lines++; break;
					case T::ELEVATION:    update(static_cast<Styling::ElevationLayer   const&>(*layer), static_cast<TerrainEffects::ElevationShade&>(*effect));              break;
					case T::HILLSHADE:    update(static_cast<Styling::HillshadeLayer   const&>(*layer), static_cast<TerrainEffects::Hillshade&>(*effect));                   break;
					case T::INTERSECT:    update(static_cast<Styling::IntersectLayer   const&>(*layer), static_cast<TerrainEffects::IntersectShade&>(*effect));              break;
					case T::SLOPE_ANGLE:  update(static_cast<Styling::SlopeAngleLayer  const&>(*layer), static_cast<TerrainEffects::SlopeAngleShade&>(*effect));             break;
					case T::SLOPE_ASPECT: update(static_cast<Styling::SlopeAspectLayer const&>(*layer), static_cast<TerrainEffects::SlopeAspectShade&>(*effect));            break;
					case T::SUNLIGHT:     update(static_cast<Styling::SunlightLayer    const&>(*layer), static_cast<TerrainEffects::SunShadow&>(*effect));                   break;
					case T::VIEWSHED:     update(static_cast<Styling::ViewshedLayer    const&>(*layer), static_cast<TerrainEffects::Viewshed&>(*effect));                    break;
					default: break;
				}
			}
		}
	}

	{
		LUCID_PROFILE_SCOPE("render rasters");

		for (Tiles::TileId const& tileId : getFrameCullState().tileIds)
		{
			auto it = mRasterRenderInfo.find(tileId);
			if (it != mRasterRenderInfo.end() && it->second.isReady)
			{
				render(viewId, it->second);
			}
		}
	}

	{
		LUCID_PROFILE_SCOPE("render vectors");

		for (std::shared_ptr<Styling::SourcedLayer const> layer : mStyle->visibleLayers<Styling::SourcedLayer>(mZoom))
		{
			switch (layer->type)
			{
				case Styling::Layer::Types::FILL: render(viewId, static_cast<Styling::FillLayer const&>(*layer)); break;
				case Styling::Layer::Types::LINE: render(viewId, static_cast<Styling::LineLayer const&>(*layer)); break;
				default: break;
			}
		}
	}

	{
		// clean up old vector render info
		std::vector<Tiles::TileId> toDelete;
		for (auto& [key, renderInfo] : mVectorRenderInfo)
		{
			if (mCurrentFrameTimeMS - renderInfo.useTimestamp > mState.getVectorFadeTime())
			{
				toDelete.push_back(key);
			}
		}

		for (auto const& key : toDelete)
		{
			mVectorRenderInfo.erase(key);
		}
	}

	if ((mIncompleteRenderComponents & cAllPrepareFlags) == 0)
	{
		if (mTileLoadTimeMS.end == 0.0)
		{
			mTileLoadTimeMS = lgal::world::Range(mTileLoadTimeMS.begin, Utils::Timer::nowMS());
			Events::trigger(Events::EventType::TILES_LOADED);
		}
	}
}

void Viewport::renderWaypoints()
{
	LUCID_PROFILE_SCOPE("viewport waypoint render");

	bgfx::ViewId renderDataId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::touch(renderDataId);
	bgfx::setViewFrameBuffer(renderDataId, mColorZFrameBuffer);
	bgfx::setViewClear(renderDataId, BGFX_CLEAR_NONE);
	bgfx::setViewName(renderDataId, "viewport waypoint");
	setMatrixUniforms(renderDataId);
	WaypointManager::Instance()->draw(renderDataId, mRenderCameraState, mState.getDpiScalar());
}

template<typename LayerType>
bool Viewport::gatherSymbols()
{
	bool complete = true;
	for (auto const& layer : mStyle->visibleLayers<LayerType>(mZoom))
	{
		for (auto& tileId : getFrameCullState().tileIds)
		{
			Caching::LayerCache::EntryKey key = { tileId, layer->id };

			if (mLayerCache->isPrepared(key))
			{
				Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
				auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
				auto preparedSymbols = prepared->symbols();
				mFrameSymbols.insert(mFrameSymbols.end(), preparedSymbols.begin(), preparedSymbols.end());
			}
			else
			{
				complete = false;
			}
		}
	}
	return complete;
}

void Viewport::gatherSymbols()
{
	bool complete = true;

	for (auto const& [key, symbols] : mState.mSymbolCollection.getSymbolsMap())
	{
		mFrameSymbols.insert(mFrameSymbols.end(), symbols.begin(), symbols.end());
	}

	// TODO we have to refactor this code at some point. viewports shouldn't have to add the terrain effect labels on a per frame basis
	for (auto const& [name, effect] : mTerrainEffects)
	{
		if (effect->isVisible())
		{
			effect->getLabels(mFrameSymbols);
		}
	}

	complete &= gatherSymbols<Styling::SymbolLayer>();
	complete &= gatherSymbols<Styling::ContourLabelLayer>();
	
	toggle(ViewportCompletionFlags::GATHER_SYMBOLS, complete);
}

void Viewport::renderSymbols()
{
	LUCID_PROFILE_SCOPE("symbol render");

	mSymbolManager->update();

	mFrameSymbols.clear();
	gatherSymbols();
	bool done = true;
	if (mState.getShowSymbols())
	{
		done &= mSymbolManager->draw(mScreenSpaceManager, mFrameSymbols, mColorZFrameBuffer, mTextureAtlas, getHeightAtlas());
		// TODO (Ronald): I *really* don't like this solution, but getting override symbols rendering above everything else quickly takes precedence
		done &= mSymbolManager->drawOverrideSymbols(mScreenSpaceManager, mOverrideSymbols, mColorZFrameBuffer, mTextureAtlas, getHeightAtlas());

		/// TODO (scott)
		// Don't like having this here but it prevents the Symbol Manager from "completing" early before the depth buffer
		// has been read back.
		// We might need to add an overall "System is still initializing" flag for the first couple of frames.
		done = done && mDepthData.size() > 0;
	}
	toggle(ViewportCompletionFlags::DRAW_SYMBOLS, done);
}

void Viewport::allocateTextures()
{
	// create color texture and set name
	{
		uint64_t flags = BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mColorTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		if (bgfx::isValid(mColorTarg)) { bgfx::setName(mColorTarg, (std::to_string(mId) + " viewport color tex").c_str()); }
	}

	{
		uint64_t flags = BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mColorReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		ONYX_ASSERT(bgfx::isValid(mColorReadbackHandle), "Failed to create color readback texture");
		bgfx::setName(mColorReadbackHandle, (std::to_string(mId) + " viewport color readback texture").c_str());
	}

	{
		uint64_t flags = BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mDepthTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		if (bgfx::isValid(mDepthTarg)) { bgfx::setName(mDepthTarg, (std::to_string(mId) + " viewport RGBA8 float depth texture").c_str()); }
	}

	// create z buffer texture and set name
	{
		mZBufferFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
		mZTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, mZBufferFormat, BGFX_TEXTURE_RT_WRITE_ONLY);
		if (bgfx::isValid(mZTarg)) { bgfx::setName(mZTarg, (std::to_string(mId) + " viewport z buffer").c_str()); }
	}

	{
		uint64_t requiredCaps = BGFX_CAPS_TEXTURE_BLIT | BGFX_CAPS_TEXTURE_READ_BACK;
		uint64_t caps = bgfx::getCaps()->supported;
		if ((caps & requiredCaps) == requiredCaps)
		{
			uint64_t flags = BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
			mDepthReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
			if (bgfx::isValid(mDepthReadbackHandle)) { bgfx::setName(mDepthReadbackHandle, (std::to_string(mId) + " viewport RGBA8 depth readback buffer").c_str()); }
		}
	}
}

void Viewport::deallocateTextures()
{
	BgfxUtils::tryDestroy(mColorTarg);
	BgfxUtils::tryDestroy(mDepthTarg);
	BgfxUtils::tryDestroy(mZTarg);
	BgfxUtils::tryDestroy(mColorReadbackHandle);
	BgfxUtils::tryDestroy(mDepthReadbackHandle);
}

void Viewport::allocateFramebuffers()
{
	// first deallocate all the old frame buffers
	deallocateFramebuffers();

	bgfx::TextureHandle colorDepthZHandles[] = { mColorTarg, mDepthTarg, mZTarg };
	mColorDepthZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorDepthZHandles), colorDepthZHandles, false);
	if (bgfx::isValid(mColorDepthZFrameBuffer)) { bgfx::setName(mColorDepthZFrameBuffer, (std::to_string(mId) + " viewport color/depth/z framebuffer").c_str()); }

	bgfx::TextureHandle colorZHandles[] = { mColorTarg, mZTarg };
	mColorZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorZHandles), colorZHandles, false);
	if (bgfx::isValid(mColorZFrameBuffer)) { bgfx::setName(mColorZFrameBuffer, (std::to_string(mId) + " viewport color/z framebuffer").c_str()); }
}

void Viewport::deallocateFramebuffers()
{
	BgfxUtils::tryDestroy(mColorZFrameBuffer);
	BgfxUtils::tryDestroy(mColorDepthZFrameBuffer);
}

void Viewport::setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration)
{
	invalidate();
	if (shader == ShaderEnums::ConfigurableShaders::Terrain) { mTerrainShaderFamily.setCurrentShaderByParams(params, configuration); }
}

void Viewport::invalidate()
{
	mIncompleteRenderComponents |= ViewportCompletionFlags::INVALIDATED; // Force an update
}

void Viewport::propertyChanged(const char*)
{
	invalidate();
}

void Viewport::setStyle(std::shared_ptr<Styling::Style> style)
{
	mStyle = style;
	mRasterRenderInfo.clear();
	mLayerCache->clear();
	syncSources();
	invalidate();

	// TODO (Ronald): Move sprite atlas code out of viewport
	if (style->hasSpritesheet())
	{
		// Parse sprite stylesheet
		auto names = Utils::splitString(style->spritesheetUrl(), '/');
		auto const numNames = names.size();
		ONYX_ASSERT(numNames >= 3, "Sprite URL should at least have [app]/[version number]/[spritesheet name]");
		std::string spritePath = "assets/spritesheets";
		for (size_t i = numNames - 3; i < numNames; ++i)
		{
			spritePath += '/' + names[i];
		}
		
		// TODO (Ronald): The @3x spritesheet is larger than 4k res. Maybe the texture can be rearranged
		int roundedDpi = (int)std::round(mState.getDpiScalar());
		if (roundedDpi >= 2)
		{
			spritePath += "@" + std::to_string(roundedDpi) + "x";
		}

		auto spriteJson = nlohmann::json::parse(core::FileSystem::readText(spritePath + ".json"));
		auto spritesheet = std::make_shared<Styling::Spritesheet>();
		from_json(spriteJson, *spritesheet);
		spritesheet->path = spritePath;
		style->addSpritesheet(spritesheet);
		
		std::string atlasPngPath = spritesheet->path + ".png";
		bgfx::TextureInfo texInfo;
		auto texHndl = BgfxUtils::loadTexture(atlasPngPath, 0, 0, &texInfo);
		ONYX_ASSERT(bgfx::isValid(texHndl), "Failed to load spritesheet texture");

		// Clear old spritesheet
		mTextureAtlas.erase();

		std::vector<Atlases::TextureAtlas<std::string>::SpriteIdx> idxs;
		idxs.reserve(spritesheet->indices.size());
        for (auto const& [name, spriteIdx] : spritesheet->indices)
        {
            // load into the SpriteIdx array
            Atlases::PageLocation pgLoc;
            pgLoc.position = spriteIdx.loc;
            pgLoc.size = spriteIdx.sizePx.as<screen_coord_t>();
            idxs.push_back({ spriteIdx.name, pgLoc });
        }

		// Check if atlas texture is too big
		auto res = mTextureAtlas.getResolution();
		if (res > texInfo.width || res > texInfo.height)
		{
			mTextureAtlas.insertSpritesFull(texHndl, spritesheet->path, texInfo, idxs);
		}
		else
		{
			mTextureAtlas.insertSpritesPerIdx(texHndl, texInfo, idxs);
		}
		
		mTextureAtlas.setName(spritesheet->path);

        // Add the atlas UV offsets to the sprite sheet
        for (auto& [name, spriteIdx] : spritesheet->indices)
        {
            auto uvOffset = mTextureAtlas.getUVOffset(name);
            spriteIdx.uvOffset = uvOffset;
        }
	}
}

void Viewport::syncSources()
{
	Styling::Source::zoom_level_t maxZoom = 0;
	for (auto const& name : mStyle->activeSources())
	{
		std::shared_ptr<Styling::Source const> source = mStyle->source(name);
		if (source->isHeight())
		{
			auto height = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			maxZoom = std::max(maxZoom, MapMath::maxDetailZoom(*height));
		}
		else
		{
			maxZoom = std::max(maxZoom, source->maxZoom);
		}
	}
	mDeepestZoomLevel = maxZoom;

	// add all dirty sources to TileCache
	for (std::string const& name : mStyle->dirtySourceNames())
	{
		// if TileCache already knows about a tiled source, it won't do anything
		Caching::TileCache::Instance()->addSource(name, mStyle->source(name));
	}

	touchRootTiles();
}

void Viewport::syncLayers()
{
	// utilize a const& to avoid overload confusion with private non-const methods of Style
	Styling::Style const& style = *mStyle;

	// NOTE: removing must occur first for correctness
	for (std::string const& id : style.removedLayerIds())
	{
		mTerrainEffects.erase(id);		// ignored if the layer is not present
		mLayerCache->purge(id, true);
	}

	// if necessary, allocate a terrain effect
	for (std::string const& id : style.addedLayerIds())
	{
		Styling::Layer::Types type = style.layer(id)->type;
		using T = Styling::Layer::Types;
		switch (type)
		{
			case T::CONTOUR_LINE: mTerrainEffects[id] = std::make_unique<TerrainEffects::ContourLine>();      break;
			case T::ELEVATION:    mTerrainEffects[id] = std::make_unique<TerrainEffects::ElevationShade>();   break;
			case T::HILLSHADE:    mTerrainEffects[id] = std::make_unique<TerrainEffects::Hillshade>();        break;
			case T::INTERSECT:    mTerrainEffects[id] = std::make_unique<TerrainEffects::IntersectShade>();   break;
			case T::SLOPE_ANGLE:  mTerrainEffects[id] = std::make_unique<TerrainEffects::SlopeAngleShade>();  break;
			case T::SLOPE_ASPECT: mTerrainEffects[id] = std::make_unique<TerrainEffects::SlopeAspectShade>(); break;
			case T::SUNLIGHT:     mTerrainEffects[id] = std::make_unique<TerrainEffects::SunShadow>();        break;
			case T::VIEWSHED:     mTerrainEffects[id] = std::make_unique<TerrainEffects::Viewshed>();         break;
			default: break;
		}
	}

	// compute all updated layers
	std::set<std::string> updated = style.addedLayerIds();
	updated.insert(style.editedLayerIds().begin(), style.editedLayerIds().end());
	for (std::string const& id : updated)
	{
		// update LayerCache with a non-immediate purge of all updated layers
		mLayerCache->purge(id, false);
	}

	// sync visibility for terrain effects
	for (auto const& layer : style.layers())
	{
		auto found = mTerrainEffects.find(layer->id);
		if (found != mTerrainEffects.end())
		{
			bool enabled = layer->isVisible() && layer->range().contains(mZoom);
			found->second->toggle(enabled);
		}
	}
}

void Viewport::touchRootTiles()
{
	// prefetch the top level tiles
	for (auto const& [name, source] : mStyle->sources())
	{
		if (source->minZoom == 0)
		{
			Caching::TileCache::Instance()->at({ name, { 0, 0, 0 } });
		}
	}
}

Styling::Expressions::Arguments Viewport::expressionArgs() const
{
	return
	{
		mZoom,
		lmath::radiansToDegrees(mRenderCameraState.heading),
		lmath::radiansToDegrees(mRenderCameraState.pitch),
		0.0,	// center distance only matters for symbol layers, which should be prepared by LayerCache
		mStyle->getExpressionContext(),
		mState.getDpiScalar()
	};
}

Styling::Arguments Viewport::layerArgs() const
{
	return { { expressionArgs() }, mStyle->getLayoutContext(), mStyle->getPaintContext(), mStyle->getEffectContext() };
}


Caching::PreparedData::Metadata Viewport::computeMetadata(Tiles::TileId const& tileId, Styling::Layer const& layer, time_float_t const timestampMS, uint16_t const meshResolution) const
{
	return
	{
		layer.type,
		layer.dependencies(mStyle->initArgs()),
		layer.filter->dependencies(mStyle->getExpressionContext()),
		tileId,
		timestampMS,
		mZoom,
		mRenderCameraState,
		meshResolution,
		mStyle->getExpressionContext(),
		mStyle->getLayoutContext(),
		mStyle->getPaintContext(),
		mStyle->getEffectContext(),
		mState.getDpiScalar()
	};
}


bool Viewport::assignTerrainShaderFamily()
{
	std::vector<Styling::Layer::Types> layers;
	for (auto const& layer : mStyle->visibleLayers(mZoom))
	{
		if (layer->isShaderLayer())
		{
			layers.push_back(layer->type);
		}
	}

	// only reload the shader when necessary -- it may be the case that layers got toggled but the necessary shader didn't change
	// eg: a layer was removed and then a layer of the same type was added in the same location
	if (layers != mTerrainShaderLayers)
	{
		Shaders::ConfigurableShader family;
		family.loadSignature(ShaderManager::Instance()->getDefaultConfiguration(ShaderEnums::ConfigurableShaders::Terrain));

		for (auto const& layer : mStyle->visibleLayers(mZoom))
		{
			switch (layer->type)
			{
				case Styling::Layer::Types::CONTOUR_LINE: family.toggleComponent("ContourLine", true); break;
				case Styling::Layer::Types::ELEVATION:    family.toggleComponent("ElevationShade", true); break;
				case Styling::Layer::Types::HILLSHADE:    family.toggleComponent("Hillshade", true); break;
				case Styling::Layer::Types::INTERSECT:    family.toggleComponent("IntersectShade", true); break;
				case Styling::Layer::Types::RASTER:       family.toggleComponent("TextureLayer", true); break;
				case Styling::Layer::Types::SLOPE_ANGLE:  family.toggleComponent("SlopeAngleShade", true); break;
				case Styling::Layer::Types::SLOPE_ASPECT: family.toggleComponent("SlopeAspectShade", true); break;
				case Styling::Layer::Types::SUNLIGHT:     family.toggleComponent("Sunlight", true); break;
				case Styling::Layer::Types::VIEWSHED:     family.toggleComponent("Viewshed", true); break;
				default: break;
			}
		}

		if (family.count() == 0)
		{
			ONYX_THROW("Unable to load terrain shader!");
		}

		mTerrainShaderLayers = layers;
		mTerrainShaderFamily = family;
		return true;
	}

	return false;	// fallthrough to return false
}

void Viewport::prepare(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("prepare tiles");

	{
		bool rastersComplete = true;
		LUCID_PROFILE_SCOPE("prepare rasters");
		if (!mTerrainShaderLayers.empty())
		{
			for (Tiles::TileId const& tileId : tiles)
			{
				auto ret = mRasterRenderInfo.insert({ tileId, Tiles::RasterRenderInfo(tileId) });	// only inserts if no entry is present
				prepare(tileId.moduloX(), ret.first->second);
				rastersComplete &= ret.first->second.isComplete;
			}
		}
		toggle(ViewportCompletionFlags::PREPARE_RASTERS, rastersComplete);
	}

	// TODO (scott)
	// Not sure if I like automatically turning all of these off automatically if there's no terrain,
	// but it works for now.
	if (!mStyle->hasTerrain()) { toggle(cVectorPrepareFlags, true); return; }

	{
		LUCID_PROFILE_SCOPE("prepare vectors");

		bool contoursComplete = true;
		bool fillsComplete = true;
		bool linesComplete = true;
		bool symbolsComplete = true;

		std::shared_ptr<Styling::Terrain const> terrain = mStyle->terrain();
		auto heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(mStyle->source(terrain->source));

		for (Tiles::TileId const& requestId : tiles)	// loop over all tiles
		{
			LUCID_PROFILE_SCOPE("tiles");
			for (auto const& layer : mStyle->visibleLayers<Styling::SourcedLayer>(mZoom))	// loop over all layers
			{
				LUCID_PROFILE_SCOPE("layers");

				// check that we want to actually process this layer
				Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
				if (!source.specification()->isVector() || requestId.level < source.specification()->minZoom) { continue; }

				// prepare the (spatially) largest tile we can that will still satisfy all of our detail requirements. this will result in fewer draw calls
				int maxLevel = std::max(MapMath::maxDetailZoom(*heightSpec), source.specification()->maxZoom);
				Tiles::TileId prepareId = (requestId.level <= maxLevel) ? requestId : requestId.parentAtLevel(maxLevel);

				auto ret = mVectorRenderInfo.insert({ prepareId, Tiles::VectorRenderInfo(prepareId, mCurrentFrameTimeMS) });	// insert only creates new entry if key is not present
				Tiles::VectorRenderInfo& info = ret.first->second;
				info.touch(mCurrentFrameTimeMS);
				prepareId = prepareId.moduloX();

				switch (layer->type)
				{
					case Styling::Layer::Types::CONTOUR_LABEL: prepare(prepareId, std::static_pointer_cast<Styling::ContourLabelLayer const>(layer), source, info); contoursComplete	&= info.isComplete; break;
					case Styling::Layer::Types::FILL:          prepare(prepareId, std::static_pointer_cast<Styling::FillLayer         const>(layer), source, info); fillsComplete		&= info.isComplete; break;
					case Styling::Layer::Types::LINE:          prepare(prepareId, std::static_pointer_cast<Styling::LineLayer         const>(layer), source, info); linesComplete		&= info.isComplete; break;
					case Styling::Layer::Types::SYMBOL:        prepare(prepareId, std::static_pointer_cast<Styling::SymbolLayer       const>(layer), source, info); symbolsComplete		&= info.isComplete; break;
					default: break;
				}
			}
		}
		toggle(ViewportCompletionFlags::PREPARE_FILLS, fillsComplete);
		toggle(ViewportCompletionFlags::PREPARE_LINES, linesComplete);
		toggle(ViewportCompletionFlags::PREPARE_SYMBOLS, symbolsComplete);
		toggle(ViewportCompletionFlags::PREPARE_CONTOURS, contoursComplete);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, Tiles::RenderInfo& info)
{
	info.isComplete = true; // assume the info is complete until proven otherwise

	if (mStyle->hasTerrain())
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
		Styling::RasterDemSource const& specification = static_cast<Styling::RasterDemSource const&>(*source.specification());
		Atlases::TileAtlas const* atlas = source.atlas();

		Tiles::AtlasInfo atlasInfo = Tiles::AtlasInfo::Compute(*atlas, tileId, source.specification()->range());
		info.heightAtlasInfo = atlasInfo;
		info.meshResolution = MapMath::meshResolution(specification, tileId);
		bool missing = atlasInfo.handle.idx == atlas->getMissingTileHandle().idx;
		info.isComplete &= !missing && (atlasInfo.level == std::min(tileId.level, specification.range().end));
	}
	else
	{
		info.isComplete = false;
		// TODO set this up to use a dummy height texture when there is no terrain value
		//info.heightAtlasInfo = 
		//info.meshResolution = 1;
	}

	info.isReady = bgfx::isValid(info.heightAtlasInfo.handle);
}

void Viewport::prepare(Tiles::TileId const& tileId, Tiles::RasterRenderInfo& info)
{
	prepare(tileId, static_cast<Tiles::RenderInfo&>(info));;
	
	info.layerCount = 0;
	for (std::shared_ptr<Styling::RasterLayer const> layer : mStyle->visibleLayers<Styling::RasterLayer>(mZoom))
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
		Styling::RasterSource const& specification = static_cast<Styling::RasterSource const&>(*source.specification());
		Atlases::TileAtlas const* atlas = source.atlas();

		Styling::RasterStyle style = layer->realize(layerArgs());
		Tiles::AtlasInfo atlasInfo = Tiles::AtlasInfo::Compute(*atlas, tileId, source.specification()->range(), style.opacity);

		bool missing = atlasInfo.handle.idx == atlas->getMissingTileHandle().idx;
		info.isComplete &= !missing && (atlasInfo.level == std::min(tileId.level, specification.range().end));

		if (atlasInfo.level >= source.specification()->minZoom)
		{
			info.layers[info.layerCount] = atlasInfo;
			++info.layerCount;
		}
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::ContourLabelLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info)
{
	prepare(tileId, static_cast<Tiles::RenderInfo&>(info));

	Atlases::HeightAtlas const* heightAtlas = static_cast<Atlases::HeightAtlas const*>(source.atlas());
	if (!heightAtlas->contains(tileId)) { info.isComplete = false; return; }

	auto heightTile = heightAtlas->at(tileId);
	if (heightTile == nullptr) { info.isComplete = false; return; }

	info.childIsLoading = (tileId.level > heightTile->id().level) ? heightTile->id().level < source.specification()->maxZoom : false;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(heightTile->id(), *layer, heightTile->timestampMS(), info.meshResolution);
	if (mLayerCache->replaces(key, metadata))
	{
		mLayerCache->insert(key, std::make_unique< Caching::Tasks::ContourLabelTask>(tileId, metadata, layer, heightTile));
	}
	else
	{
		mLayerCache->touch(key);
	}

	Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
	info.isComplete &= (entry.prepared) ? !metadata.replaces(entry.prepared->metadata()) : false;
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::FillLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info)
{
	prepare(tileId, static_cast<Tiles::RenderInfo&>(info));

	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(tileId, true);

	// no vectors available to display
	if (vectorTile == nullptr) { info.isComplete = false; return; }
	info.childIsLoading = (tileId.level > vectorTile->id().level) ? vectorTile->id().level < source.specification()->maxZoom : false;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, vectorTile->timestampMS(layer->sourceLayer), info.meshResolution);
	if (mLayerCache->replaces(key, metadata))
	{
		if (mLayerCache->restyles(key, metadata))
		{
			Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
			auto existing = std::static_pointer_cast<Caching::PreparedFillData const>(entry.prepared);
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::RestyleFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, existing));
		}
		else
		{
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile));
		}
	}
	else
	{
		mLayerCache->touch(key);
	}

	Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
	info.isComplete &= (entry.prepared) ? !metadata.replaces(entry.prepared->metadata()) : false;
	info.isComplete &= !info.wasPulsing();
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::LineLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info)
{
	prepare(tileId, static_cast<Tiles::RenderInfo&>(info));
	
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(tileId, true);

	// no vectors available to display
	if (vectorTile == nullptr) { info.isComplete = false; return; }
	info.childIsLoading = (tileId.level > vectorTile->id().level) ? vectorTile->id().level < source.specification()->maxZoom : false;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, vectorTile->timestampMS(layer->sourceLayer), info.meshResolution);
	if (mLayerCache->replaces(key, metadata))
	{
		if (mLayerCache->restyles(key, metadata))
		{
			Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
			auto existing = std::static_pointer_cast<Caching::PreparedLineData const>(entry.prepared);
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::RestyleLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, existing));
		}
		else
		{
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile));
		}
	}
	else
	{
		mLayerCache->touch(key);
	}

	Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
	info.isComplete &= (entry.prepared) ? !metadata.replaces(entry.prepared->metadata()) : false;
	info.isComplete &= !info.wasPulsing();
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::SymbolLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info)
{
	prepare(tileId, static_cast<Tiles::RenderInfo&>(info));
	
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(tileId, true);

	Atlases::HeightAtlas const* heightAtlas = getHeightAtlas();
	std::shared_ptr<Tiles::HeightTile const> heightTile = heightAtlas->find(tileId, true);

	// no vectors available to display
	if (vectorTile == nullptr || heightTile == nullptr) { info.isComplete = false; return; }
	info.childIsLoading = (tileId.level > vectorTile->id().level) ? vectorTile->id().level < source.specification()->maxZoom : false;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	time_float_t timestampMS = std::max(vectorTile->timestampMS(layer->sourceLayer), heightTile->timestampMS());
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, timestampMS, info.meshResolution);
	if (mLayerCache->replaces(key, metadata))
	{
		auto task = std::make_unique<Caching::Tasks::FreshSymbolTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, heightTile, mStyle->sprite(), info);
		mLayerCache->insert(key, std::move(task));
	}
	else
	{
		mLayerCache->touch(key);
	}

	Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
	info.isComplete &= (entry.prepared) ? !metadata.replaces(entry.prepared->metadata()) : false;
}

void Viewport::update(Styling::ContourLineLayer const& layer, TerrainEffects::ContourLine& effect, size_t index)
{
	Styling::ContourLineConfig config = layer.realize(layerArgs());
	mHorizon.convert(config, mFilteredZoomKm);
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, index, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::ElevationLayer const& layer, TerrainEffects::ElevationShade& effect)
{
	Styling::ElevationConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, atlas.heightExtents(getFrameCullState().tileIds, false), {layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS});
}

void Viewport::update(Styling::HillshadeLayer const& layer, TerrainEffects::Hillshade& effect)
{
	Styling::HillshadeConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::IntersectLayer const& layer, TerrainEffects::IntersectShade& effect)
{
	Styling::IntersectConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, atlas.heightExtents(getFrameCullState().tileIds, false), { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SlopeAngleLayer const& layer, TerrainEffects::SlopeAngleShade& effect)
{
	Styling::SlopeAngleConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SlopeAspectLayer const& layer, TerrainEffects::SlopeAspectShade& effect)
{
	Styling::SlopeAspectConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SunlightLayer const& layer, TerrainEffects::SunShadow& effect)
{
	// TODO consider just using the terrain source for SunShadow
	Styling::SunlightConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, getFrameCullState(), { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::ViewshedLayer const& layer, TerrainEffects::Viewshed& effect)
{
	// TODO consider just using the terrain source for Viewshed
	Styling::ViewshedConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::render(bgfx::ViewId const viewId, Tiles::RasterRenderInfo const& info)
{
	if (!mState.getShowRasters()) { return; }

	if (info.isReady)
	{
		auto subsetCount = std::min(size_t(info.layerCount), mTerrainShaderFamily.count() - 1);
		if (subsetCount > 0) { --subsetCount; }

		auto shader = mTerrainShaderFamily.getShader((int)subsetCount);
		ONYX_ASSERT(shader != nullptr, "Unable to retrieve shader for requested ConfigurableShader/texture count subset");

		lgal::Color background = 0x00FFFFFF;
		for (auto const& layer : mStyle->visibleLayers<Styling::BackgroundLayer>(mZoom))
		{
			Styling::BackgroundStyle style = layer->realize(layerArgs());
			background = lgal::Color::FromABGR(style.abgr);
		}
		shader->setParameter("u_BackgroundColor", background);

		shader->setParameter("u_tileDistortion", lgal::world::Vector3{ info.distortion, 0.0});
		shader->setParameter("u_tileSize", lgal::world::Vector3(info.tileSize.x, info.tileSize.y, mExaggeration));

		SetTextureParameters(info.heightAtlasInfo, shader.get(), TextureType::Height);
		if (info.layers[0].isValid())
		{
			SetTextureParameters(info.layers[0], shader.get(), TextureType::Basemap);
			if (info.layers[1].isValid())
			{
				SetTextureParameters(info.layers[1], shader.get(), TextureType::Roads);
				if (info.layers[2].isValid())
				{
					SetTextureParameters(info.layers[2], shader.get(), TextureType::LocalData);
				}
			}
		}

		auto tileMin = info.tileMin - mRenderCameraState.position;
		auto tileMax = info.tileMax - mRenderCameraState.position;
		tileMax.z = info.tileSize.x;

		shader->setParameter("u_tileMin", tileMin);
		shader->setParameter("u_tileMax", tileMax);

		// set parameters from relevant terrain effects
		for (auto const& [id, effect] : mTerrainEffects)
		{
			LUCID_PROFILE_SCOPE("set terrain effect params");
			// set parameters from relevant terrain effects
			if (effect->isVisible())
			{
				effect->setParameters(*shader, info.id);
			}
		}

		//draw mesh
		Tiles::TileMesh::Instance(info.meshResolution)->draw(info.id, mRenderCameraState.position, mRenderCameraState.heading, shader->programHandle, viewId, false);
	}
	else
	{
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0);
		shader->setParameter("u_tileMin", info.tileMin - mRenderCameraState.position);
		shader->setParameter("u_tileMax", info.tileMax - mRenderCameraState.position);
		Tiles::TileMesh::Instance(1)->draw(info.id, mRenderCameraState.position, mRenderCameraState.heading, shader->programHandle, viewId, false);
	}
}

void Viewport::render(bgfx::ViewId const viewId, Styling::FillLayer const& layer, Styling::FillStyle::Effect const& effect, Tiles::VectorRenderInfo const& info)
{
	if (!mState.getShowFills()) { return; }

	Shaders::ShaderDefinition* shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainFill, 0).get();

	// render states
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		| BGFX_STATE_BLEND_ALPHA
		| BGFX_STATE_CULL_CW
		| static_cast<uint64_t>(effect.depthTest)
		;

	// search cache for any reasonably detailed buffer
	lgal::gpu::Vector4 fragClip = { 0, 0, 1, 1 };	// TODO try using a stencil buffer to clip fragments to the rendered tile
	auto it = mLayerCache->find({ info.id.moduloX(), layer.id }, 3, fragClip);
	if (it == mLayerCache->end()) { return; }
	auto prepared = std::static_pointer_cast<Caching::PreparedFillData const>(it->entry.prepared);
	Caching::PreparedFillData::Buffer_t const* buffer = prepared ? prepared->buffer.get() : nullptr;

	if (buffer)
	{
		Tiles::VectorRenderInfo rendered = info;
		if (it->key.tileId < info.id)
		{
			rendered = Tiles::VectorRenderInfo{ info.id.parentAtLevel(it->key.tileId.level), rendered.useTimestamp};
			if (mStyle->hasTerrain())
			{
				auto terrain = mStyle->terrain();

				Caching::Source const& source = Caching::TileCache::Instance()->getSource(terrain->source);
				rendered.heightAtlasInfo = Tiles::AtlasInfo::Compute(*source.atlas(), it->key.tileId, source.specification()->range());
			}
		}

		auto tileMin = (rendered.tileMin - mRenderCameraState.position).as<gpu_float_t>();
		auto tileMax = (rendered.tileMax - mRenderCameraState.position).as<gpu_float_t>();
		tileMax.z = (gpu_float_t)rendered.tileSize.x;

		// compute vertex clip range
		lgal::gpu::Vector4 vertClip = fragClip;
		{
			lgal::gpu::Vector2 delta = { vertClip.z - vertClip.x, vertClip.w - vertClip.y };
			delta *= 0.25;
			vertClip.xy -= delta;
			vertClip.zw += delta;
		}

		shader->setParameter("u_TileVertClip", vertClip);
		shader->setParameter("u_TileFragClip", fragClip);

		float fade = 1.f;// info.alpha(mCurrentFrameTimeMS, mState.getVectorFadeTime(), mState.getVectorPulseTimeMS(), mState.getVectorPulseDelayMS());

		for (auto i = 0ull; i < buffer->pages().size(); ++i)
		{
			buffer->attach(i);
			SetTextureParameters(rendered.heightAtlasInfo, shader, TextureType::Height);

			Atlases::FillStyleAtlas const& fillStyles = mLayerCache->getFillStyles();
			shader->setParameter("u_NearFarFocus", lgal::world::Vector3(mRenderCameraState.nearClip, mRenderCameraState.farClip, mZoomKm));
			shader->setParameter("u_FogTransition", mFogStyle.range);
			shader->setParameter("u_FogColor", mFogStyle.color);
			shader->setParameter("u_TileFillOpacityTransition", effect.fadeRange);
			shader->setParameter("u_MeshResolution", lgal::gpu::Vector4({ gpu_float_t(info.meshResolution), 55, 66, 77 }));
			shader->setParameter("u_vectorFade", fade);
			shader->setParameter("s_vectorColors", fillStyles.getColorHandle());
			shader->setParameter("s_vectorPatterns", fillStyles.getPatternCoordsHandle());
			shader->setParameter("s_patterns", fillStyles.getPatternAtlasHandle(), 256, 256);
			shader->setParameter("u_tileDistortion", lgal::world::Vector3{ rendered.distortion, 0.0 });
			shader->setParameter("u_screenResolution", lgal::gpu::Vector3{ size().as<gpu_float_t>(), 0 });
			shader->setParameter("u_tileMin", tileMin);
			shader->setParameter("u_tileMax", tileMax);
			shader->setParameter("u_TileFillData", lgal::gpu::Vector3(std::floor(mZoom), 0, 0));

			// Set render states
			bgfx::setState(state);
			bgfx::submit(viewId, shader->programHandle);
		}
	}
}

void Viewport::render(bgfx::ViewId const viewId, Styling::LineLayer const& layer, Styling::LineStyle::Effect const& effect, Tiles::VectorRenderInfo const& info)
{
	if (!mState.getShowLines()) { return; }

	Shaders::ShaderDefinition* shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainLine, 0).get();

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA
		| static_cast<uint64_t>(effect.depthTest)
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		;

	lgal::gpu::AABB2d everything = lgal::gpu::AABB2d::everything();
	lgal::gpu::Vector4 fragClip = { everything.min, everything.max };

	auto it = mLayerCache->find({ info.id.moduloX(), layer.id }, 3, fragClip);
	if (it == mLayerCache->end()) { return; }
	auto prepared = std::static_pointer_cast<Caching::PreparedLineData const>(it->entry.prepared);

	if (prepared)
	{
		uint32_t start = 0;
		uint32_t num = uint32_t(prepared->instances.size());

		shader->setParameter("u_TileFragClip", fragClip);

		Tiles::VectorRenderInfo rendered = info;
		if (it->key.tileId.level < info.id.level)
		{
			rendered = Tiles::VectorRenderInfo{ info.id.parentAtLevel(it->key.tileId.level), rendered.useTimestamp };
			if (mStyle->hasTerrain())
			{
				auto terrain = mStyle->terrain();

				Caching::Source const& heightSource = Caching::TileCache::Instance()->getSource(terrain->source);
				rendered.heightAtlasInfo = Tiles::AtlasInfo::Compute(*heightSource.atlas(), it->key.tileId, heightSource.specification()->range());
			}
		}

		float fade = 1.f;// info.alpha(mCurrentFrameTimeMS, mState.getVectorFadeTime(), mState.getVectorPulseTimeMS(), mState.getVectorPulseDelayMS());

		if (num == 0 || !bgfx::isValid(prepared->handle())) { return; }

		auto tileMin = (rendered.tileMin - mRenderCameraState.position).as<gpu_float_t>();
		auto tileMax = (rendered.tileMax - mRenderCameraState.position).as<gpu_float_t>();
		tileMax.z = (gpu_float_t)rendered.tileSize.x;

		SetTextureParameters(rendered.heightAtlasInfo, shader, TextureType::Height);
		shader->setParameter("u_tileMin", tileMin);
		shader->setParameter("u_tileMax", tileMax);
		shader->setParameter("u_MeshResolution", lgal::gpu::Vector4({ gpu_float_t(rendered.meshResolution), 55, 66, 77 }));
		shader->setParameter("u_NearFarFocus", lgal::world::Vector3(mRenderCameraState.nearClip, mRenderCameraState.farClip, mZoomKm));
		shader->setParameter("u_FogTransition", mFogStyle.range);
		shader->setParameter("u_FogColor", mFogStyle.color);
		shader->setParameter("u_TileLineOpacityTransition", effect.fadeRange);
		shader->setParameter("u_vectorFade", fade);
		shader->setParameter("u_tileSize", lgal::gpu::Vector3((gpu_float_t)rendered.tileSize.x, (gpu_float_t)rendered.tileSize.y, mExaggeration));

		lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
		shader->setParameter("u_screenDimensions", pixelSize);
		shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ rendered.distortion.as<gpu_float_t>(), 0.0 });

		Atlases::LineStyleAtlas const& lineStyles = mLayerCache->getLineStyles();
		shader->setParameter("s_VectorColors", lineStyles.getColorHandle());
		shader->setParameter("s_VectorWidths", lineStyles.getWidthHandle());
		shader->setParameter("s_DashCoords", lineStyles.getDashCoordsHandle());
		shader->setParameter("s_DashSampler", lineStyles.getDashAtlasHandle(), Atlases::DashAtlas::cRowResolution, Atlases::DashAtlas::cNumRows);

		mLineMesh->attach();
		mState.mFrameRenderStats.renderedLineInstances += num;

		bgfx::setInstanceDataBuffer(prepared->handle(), start, num);
		bgfx::setState(state | BGFX_STATE_PT_TRISTRIP);
		bgfx::submit(viewId, shader->mInstancedHandle);
	}
}

template<typename VectorLayerT>
void Viewport::render(bgfx::ViewId const viewId, VectorLayerT const& layer)
{
	std::shared_ptr<Styling::RasterDemSource const> heightSpec = nullptr;
	if (mStyle->hasTerrain())
	{
		std::shared_ptr<Styling::Source const> const& source = mStyle->source(mStyle->terrain()->source);
		heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(source);
	}

	std::shared_ptr<Styling::Source const> source = mStyle->source(layer.source);

	// compute the (spatially) largest tiles that satisfy our level of detail requirements
	int maxZoom = std::max((heightSpec) ? MapMath::maxDetailZoom(*heightSpec) : 0, source->maxZoom);
	std::vector<Tiles::TileId> clamped = Tiles::TileId::uniqueClampedToMaxLevel(getFrameCullState().tileIds, maxZoom);
	std::vector<Tiles::TileId> filtered = Tiles::TileId::filter(clamped, source->minZoom, maxZoom);

	// realize effect and convert to world space units
	auto effect = layer.effect(layerArgs());
	mHorizon.convert(effect, mFilteredZoomKm);

	for (Tiles::TileId const& tileId : filtered)
	{
		auto it = mVectorRenderInfo.find(tileId);
		if (it != mVectorRenderInfo.end() && it->second.isReady)
		{
			render(viewId, layer, effect, it->second);
		}
	}
}

std::vector<Caching::TileCacheKey> Viewport::CacheKeys(std::vector<Tiles::TileId> const& tiles, std::shared_ptr<Styling::Style const> style, float const zoom)
{
	LUCID_PROFILE_SCOPE("compute cache keys");
	
	std::vector<Tiles::TileId> moduloX = Tiles::TileId::uniqueModuloX(tiles);

	std::vector<std::string> activeSources = style->activeSources(zoom);

	std::vector<Caching::TileCacheKey> keys;
	keys.reserve(activeSources.size() * moduloX.size());

	// only iterate over rasters because we assume vectors is a subset of rasters
	for (Tiles::TileId const& requestId : moduloX)
	{
		for (std::string const& name : activeSources)
		{
			std::shared_ptr<Styling::Source const> const& source = style->source(name);

			if (source->minZoom <= requestId.level)
			{
				if (source->isRaster())
				{
					// adjust based on the resolution of the height tiles
					auto raster = std::static_pointer_cast<Styling::RasterSource const>(source);
					auto adjustment = Tiles::TileId::IdCoordsT(std::log2(std::max(raster->tileSize / 256, 1u)));
					Tiles::TileId submittedId = requestId.parent(std::min(adjustment, requestId.level - source->minZoom));
					submittedId = (submittedId.level <= source->maxZoom) ? submittedId : submittedId.parentAtLevel(source->maxZoom);
					keys.push_back({ name, submittedId });
				}
				else if (source->isVector())
				{
					Tiles::TileId submittedId = (requestId.level <= source->maxZoom) ? requestId : requestId.parentAtLevel(source->maxZoom);
					keys.push_back({ name, submittedId });
				}
			}
		}
	}

	return keys;
}

float Viewport::AliasZoom(float const zoom)
{
	float precision = 10.0;
	uint32_t aliased = static_cast<uint32_t>(std::round(zoom * precision));
	return static_cast<float>(aliased) / precision;
}

bool Viewport::hasIconImg(std::string id) 
{ 
	return mStyle->hasSprite(id); 
}

Styling::SpriteIndex Viewport::getSpriteIdx(std::string const& id) const
{
	Styling::SpriteIndex toRet{};
	auto const spritesheet = mStyle->sprite();
	if (spritesheet)
	{
		toRet = spritesheet->getSpriteIdx(id);
	}
	
	return toRet;
}

bool Viewport::addIconImg(std::string id, std::string url)
{
    if (hasIconImg(id))
    {
        logI("Sprite atlas entry already exists for " + id);
		return false;
    }

    bgfx::TextureInfo tInfo{};
    auto tHndl = BgfxUtils::loadTexture(url, 0, 0, &tInfo);
    if (!bgfx::isValid(tHndl))
    {
		logI("Failed to load texture from  " + url);
		return false;
    }
	
	mTextureAtlas.insert(id, tHndl, tInfo);
	if (!mTextureAtlas.contains(id))
	{
		logI("Failed to add " + id + " to Sprite Atlas");
		return false;
	}

	Styling::SpriteIndex idx{};
    idx.name = id;
    idx.sizePx = lgal::gpu::Vector2{ gpu_float_t(tInfo.width), gpu_float_t(tInfo.height) };
    idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
    idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };
    idx.content = { { 0, 0 }, { tInfo.width, tInfo.height } };
    idx.uvOffset = mTextureAtlas.getUVOffset(id);
    mStyle->addSprite(idx);

    return true;
}

void Viewport::compositeImages(std::string id, std::vector<std::string> const& filePaths)
{
	if (hasIconImg(id))
	{
		logE(id + " is already in SpriteAtlas!");
		return;
	}

	std::vector<bgfx::TextureHandle> tHndls;
	tHndls.reserve(filePaths.size());

	bgfx::TextureInfo tInfo = {};
	
	for (auto const& path : filePaths)
	{
		auto tHndl = BgfxUtils::loadTexture(path.c_str(), 0, 0, &tInfo);
		if (!bgfx::isValid(tHndl))
		{
			logE("Failed to load texture from " + path);
			for (auto h : tHndls)
			{
				BgfxUtils::tryDestroy(h);
			}
			return;
		}
		tHndls.push_back(tHndl);
	}

	if (!tHndls.empty())
	{
		mTextureAtlas.compositeTextures(id, tHndls,
			lgal::screen::Vector2{ screen_coord_t(tInfo.width), screen_coord_t(tInfo.height) },
			tInfo.format);

        Styling::SpriteIndex idx{};
        idx.name = id;
        idx.sizePx = lgal::gpu::Vector2{ gpu_float_t(tInfo.width), gpu_float_t(tInfo.height) };
        idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
        idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };
        idx.content = { { 0, 0 }, { tInfo.width, tInfo.height } };
        idx.uvOffset = mTextureAtlas.getUVOffset(id);
        mStyle->addSprite(idx);
	}
}

DataObjects::MapSymbol Viewport::getOverrideSymbol(index_t i) const
{
	DataObjects::MapSymbol toRet{ Styling::SymbolPlacement::UNSPECIFIED };
	if (overrideSymbolExists(i))
	{
		auto const s = mOverrideSymbols[i];
		auto placement = s->getPlacement();
		toRet.setPlacement(placement);

		if (s->hasLabel())
		{
			auto const lbl = s->getLabel();
			auto lblCpy = std::make_shared<DataObjects::MapLabel>(*lbl);
			toRet.addLabel(lblCpy);
		}
		if (s->hasIcon())
		{
			auto const& icon = s->getIcon().value();
			toRet.addIcon(icon);
		}
	}

	return toRet;
}

int Viewport::addOverrideSymbol(std::unique_ptr<DataObjects::MapSymbol> s) 
{
	if (mOverrideSymbols.size() > 32)
	{
		logE("Reached maximum number of override symbols");
		return -1;
	}
	mOverrideSymbols.push_back(std::move(s));
	invalidate();

	return (int)(mOverrideSymbols.size() - 1);
}

}
