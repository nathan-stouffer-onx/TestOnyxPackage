#include "Viewport.h"

#include <unordered_set>

#include <lucid/Profiler.h>
#include <Shaders/ShaderDefinition.h>
#include <Shaders/v2/Handwritten.h>
#include <Shaders/v2/Load.h>
#include <Styling/Parse/MiscJson.h>

#include "Atlases/HeightAtlas.h"
#include "Atlases/TileAtlas.h"
#include "Caching/Tiles/TileCache.h"
#include "Caching/Tiles/Precache.h"
#include "Caching/Layers/Tasks/FillTasks.h"
#include "Caching/Layers/Tasks/LineTasks.h"
#include "Caching/Layers/Tasks/SymbolTasks.h"
#include "Caching/Layers/Tasks/HeightTileTasks.h"
#include "Camera/Controllers/Identity.h"
#include "DataObjects/WaypointManager.h"
#include "Drawers/AABB3d.h"
#include "Drawers/Frustum.h"
#include "Events/Events.h"
#include "Experimental/ParticleSystem.h"
#include "Rendering/Render.h"
#include "Symbol/SymbolManager.h"
#include "Symbol/Font/DefaultFonts.h"
#include "Tiles/TileRenderInfo.h"
#include "TerrainEffects/Factory.h"
#include "Utils/Timer.h"
#include "Utils/BgfxUtils.h"

namespace onyx
{

Viewport::Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
	mId(viewportId),
	mTileLoadTimeMS(Utils::Timer::nowMS(), 0.0),
	mSpritesheet(std::make_shared<Spritesheet>()),
	mState(wRatio, hRatio, sortOrder),
	mController(std::make_shared<Camera::Controllers::Identity>()),
	mRenderCameraState(state),
	mCullCameraState(state),
	mZoomFilter(250.0),
	mStyle(new Styling::Style()),
	mLayerCache(new Caching::LayerCache()),
	mSkydome(new Drawers::Skydome()),
	mLineMesh(new Rendering::LineMesh()),
	mDummyTerrainHandle(Atlases::HeightAtlas::ConstructMissingHeightTileHandle())
{
#ifdef PLATFORM_EMSCRIPTEN
	mDepthCameras.resize(1);
#else
	mDepthCameras.resize(2);
#endif

	allocateTextures();
	allocateFramebuffers();
	
	mSymbolManager.reset(new Symbol::SymbolManager(this));
	mSymbolManager->initialize();
	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
}

Viewport::~Viewport()
{
	BgfxUtils::tryDestroy(mDummyTerrainHandle);
	deallocateTextures();
	deallocateFramebuffers();
}

bgfx::TextureHandle Viewport::getTexture()
{
	if (bgfx::isValid(mColorDepthZFrameBuffer) && bgfx::isValid(mColorZFrameBuffer) && bgfx::isValid(mColorTarg)) { return mColorTarg; }
	return BGFX_INVALID_HANDLE;
}

bgfx::TextureHandle Viewport::getDepthReader()
{
	if (bgfx::isValid(mColorDepthZFrameBuffer) && bgfx::isValid(mColorZFrameBuffer) && bgfx::isValid(mDepthTarg)) { return mDepthTarg; }
	return BGFX_INVALID_HANDLE;
}

bgfx::TextureHandle Viewport::getDepthBuffer()
{
	if (bgfx::isValid(mColorDepthZFrameBuffer) && bgfx::isValid(mColorZFrameBuffer) && bgfx::isValid(mZTarg)) { return mZTarg; }
	return BGFX_INVALID_HANDLE;
}

void Viewport::renderScreenLines()
{
	if (mState.getScreenLines().empty()) { return; }

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw screen-space lines");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);
	
	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA;
		;

	for (auto const& styles : mState.getScreenLines())
	{
		auto const& instances = styles.second;
		if (instances.empty()) { continue; }
		Rendering::render({ renderId, *shader, instances, styles.first, *mLineMesh, state });
	}
}

void Viewport::renderScreenSpaceManager()
{
	if (mScreenSpaceManager.empty() || !mState.getShowScreenSpaceManager())
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw Screen Space Manager");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_ALPHA
		;

	screenLineVector_t instances;

	auto res = size().as<gpu_float_t>();
	auto xScale = 2.f / res.x;
	auto yScale = 2.f / res.y;

	for (auto const &screenRect : mScreenSpaceManager)
	{
		auto GPURect = screenRect.as<gpu_float_t>();
		static const std::array<int, 4> nextPts = { 1, 3, 0, 2 };

		for (int i = 0; i < GPURect.VERTEX_COUNT(); ++i)
		{
			lgal::gpu::LineSegment2 segment(GPURect.vertex(i), GPURect.vertex(nextPts[i]));

			lgal::gpu::Vector2 p1(segment.start.x * xScale - 1, (segment.start.y * yScale - 1));

			p1.y *= -1;
			auto dir = lucid::math::normalize(segment.direction());
			dir.y *= -1;

			instances.push_back(Rendering::VertStructs::ScreenLineData(0, 0, 0xFFFF0000, { p1, 0 }, { dir, 0 }, segment.length(), 3.0 ));
		}
	}

	if (instances.empty())
	{
		return;
	}

	Rendering::render({ renderId, *shader, instances, "dotted", *mLineMesh, state });
}

Atlases::HeightAtlas const* Viewport::getHeightAtlas() const
{
	if (!mStyle->hasTerrain()) { return nullptr; }
	auto const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
	return static_cast<Atlases::HeightAtlas const*>(source.atlas());
}

void Viewport::render(time_float_t timeMS)
{
	time_float_t timeStep = timeMS - mCurrentFrameTimeMS;
	mCurrentFrameTimeMS = timeMS;
	mLayerCache->setFrameTimeMS(timeMS);
	mState.mFrameRenderStats.reset();

	// check ViewportState for updated settings
	if (mState.getIsDirty()) { invalidate(); mState.setIsDirty(false); }

	// update sources so the camera uses the most recent height atlas if there was a change
	if (mStyle->hasDirtySources()) { syncSources(); }
	auto heightAtlas = getHeightAtlas();	// compute height atlas if we have the source

	Camera::CameraState newState = mController->update(mRenderCameraState, timeMS, heightAtlas, mExaggeration);
	if (!newState.isValid())
	{
		// Don't set the camera to an invalid state; just use the previous state
		newState = mRenderCameraState;
	}

	// override aspect ratio and resolution with viewport value
	newState.aspect = getAspect();
	newState.resolution = getDimensions().as<screen_coord_t>();

	bool cameraWasMoving = mCameraMoved;
	mCameraMoved = newState != mRenderCameraState;

	// trigger camera-related events
	toggle(ViewportCompletionFlags::CAMERA, !mCameraMoved);
	if (mCameraMoved)
	{
		toggle(cAllPrepareFlags, false);
		mRenderCameraState = newState;
		mRenderCameraState.updateViewProj();
		Events::trigger(Events::EventType::CAMERA_MOVED);
	}
	else if (cameraWasMoving)
	{
		Events::trigger(Events::EventType::CAMERA_STOPPED);
		lgal::world::Range r = lgal::world::Range(Utils::Timer::nowMS(), 0.0);
		mTileLoadTimeMS = r;
	}
	if (mState.getCullingEnabled()) { mCullCameraState = mRenderCameraState; }

	if (!mStyle->hasQueuedTasks())
	{
		if (mCameraMoved) { mLayerCache->requestReduceLoad(); }
		else { mLayerCache->resume(); }
	}

	// compute zoom for this frame
	{
		LUCID_PROFILE_SCOPE("compute zoom");

		// update filter
		mZoomFilter.update(timeMS);

		// compute zoom
		mZoom = computeZoom();

		// push to filter and compute filtered zoom
		mZoomFilter.push(mZoom, timeMS);
		mFilteredZoom = mZoomFilter.avg();
		
		// convert to km
		mZoomKm = static_cast<float>(MapMath::zoomToKm(mZoom));
		mFilteredZoomKm = static_cast<float>(MapMath::zoomToKm(mFilteredZoom));

		// round to reduce how often zoom changes
		mZoom = Viewport::AliasZoom(mZoom);
		mFilteredZoomKm = Viewport::AliasZoom(mFilteredZoomKm);
	}

	{
		std::vector<std::vector<std::weak_ptr<Experimental::IUpdater>>::iterator> cleanup;
		for (auto updater = mState.mUpdaters.begin(); updater != mState.mUpdaters.end(); ++updater)
		{
			if (updater->expired())
			{
				cleanup.push_back(updater);
			}
			else
			{
				ONYX_TRY
					updater->lock()->update(this, timeStep);
				ONYX_CATCH
					logE("Updater had an error: %s", ex.what());
				ONYX_END_CATCH
			}
		}

		for (auto remove : cleanup)
		{
			mState.mUpdaters.erase(remove);
		}
	}

	// update style-related info as necessary (note that sources were updated prior to utilizing the camera)
	{
		if (mStyle->hasQueuedTasks() || mSpritesheet->recordUpdateReady())	// check if we have any queued tasks or updated the spritesheet's record
		{
			// request a pause on the prepare thread. once paused, flush the style edits and/or update spritesheet and then unpause the prepare thread
			if (mLayerCache->requestPause())
			{
				if (mStyle->hasQueuedTasks())
				{
					mStyle->flushTasks();
				}
				if (mSpritesheet->recordUpdateReady())
				{
					logI("Updating spritesheet and layer cache");
					// remove all symbol layers from layer cache
					for (auto const lyr : mStyle->layers<Styling::SymbolLayer>())
					{
						mLayerCache->purge(lyr->id);
					}
					for (auto const lyr : mStyle->layers<Styling::ContourLabelLayer>())
					{
						mLayerCache->purge(lyr->id);
					}
					mSpritesheet->updateRecord();
				}

				mLayerCache->resume();
			}
		}

		if (mStyle->isDirty()) { invalidate(); }

		mSpritesheet->updateAtlas();

		syncLayers();
		mStyle->update();

		if (mStyle->hasTerrain()) { mExaggeration = mStyle->terrain()->exaggeration->evaluate(expressionArgs()); }
		if (assignShaders()) { invalidate(); }
	}

	// overwrite exaggeration if the camera is sufficiently zoomed out
	{
		using Defaults = Camera::Controllers::Constraints::DefaultConstraints;
		world_float_t constexpr start = 250;
		world_float_t constexpr end = 2 * start;
		world_float_t t = (mCullCameraState.position.z - start) / (end - start);
		mExaggeration = lmath::lerpstep(mExaggeration, 0.f, static_cast<float>(t));
	}

	// compute information global to the style
	{
		// realize fog style and convert to world units
		Styling::realize(layerArgs(), mStyle->fog(), mFogStyle);
		mFogStyle = mHorizon.convert(mFogStyle, mFilteredZoomKm);
	}

	touchRootTiles();

	// precache tiles associated with the controller's highlight states
	std::vector<Camera::CameraState> highlights = mController->highlights();
	for (auto const& highlight : highlights)
	{
		Pyramid::CullResult cullRes = Pyramid::cull(highlight, mState.getLODScaler(), mDeepestZoomLevel, &mZoomKm, heightAtlas, mExaggeration);
		std::vector<Caching::TileCacheKey> keys = Caching::keys(Tiles::TileId::UniqueParents(cullRes.tileIds, 2), *mStyle, mZoom);
		// only continue processing if the tiles are precached
		if (!Caching::TileCache::Instance()->precache(keys))
		{
			break;
		}
	}

	auto cacheTimestamp = Caching::TileCache::Instance()->getUpdateTimestamp();
	auto cacheUpdated = cacheTimestamp > mLastCacheUpdate;	// until we have more granular information, we must assume that any new cache info triggers culling/rendering
	mLastCacheUpdate = cacheTimestamp;
	toggle(ViewportCompletionFlags::CACHE_UPDATE, !cacheUpdated);

	if (mCameraMoved || mForceCulling || cacheUpdated)
	{
		// reset tile load time when the camera moves

		auto &cullState = getFrameCullState();
		if (mState.getCullingEnabled())
		{
			mCullStateChanged = true;

			LUCID_PROFILE_SCOPE("culling");
			cullState = Pyramid::cull(mCullCameraState, mState.getLODScaler(), mDeepestZoomLevel, &mZoomKm, heightAtlas, mExaggeration);
			cullState.tileIds = Tiles::TileId::Filter(cullState.tileIds, mState.getTileZoomRange().begin, mState.getTileZoomRange().end);
		}
	}

	if (mIncompleteRenderComponents == ViewportCompletionFlags::NONE && mState.getQuiescenceMode()) // Nothing to do; render was already completed and nothing has changed.
	{
		std::vector<Caching::TileCacheKey> keys = Caching::keys(getFrameCullState().tileIds, *mStyle, mZoom);
		Caching::TileCache::Instance()->touch(keys);
		return;
	}

	toggle(ViewportCompletionFlags::INVALIDATED, true); // Always clear this bit because "invalidate" just forces a rerender once

	mScreenSpaceManager.clear();
	mRasterBasedShaderFamily.setParameter("u_eyePos", mRenderCameraState.position);
	mRasterBasedShaderFamily.setParameter("u_NearFarFocus", lgal::world::Vector3(mRenderCameraState.nearClip, mRenderCameraState.farClip, mZoomKm));
	mRasterBasedShaderFamily.setParameter("u_FogTransition", mFogStyle.range);
	mRasterBasedShaderFamily.setParameter("u_FogColor", mFogStyle.color);

	if (mSkydome)
	{
		auto id = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		mSkydomeProgram.set("u_SkyColor", mState.getSkyColor());
		mSkydomeProgram.set("u_HazeColor", mState.getHazeColor());
		bgfx::setViewClear(id, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, mState.getHazeColor().rgba(), 1.0f, 0);
		bgfx::setViewFrameBuffer(id, mColorDepthZFrameBuffer);
		bgfx::setViewRect(id, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());
		mSkydome->draw(id, mRenderCameraState, mSkydomeProgram);
	}

	renderTiles();
	renderWaypoints();
	renderSymbols();

	renderScreenLines();
	renderScreenSpaceManager();

	Experimental::ParticleSystem::draw(mRenderCameraState, lgal::gpu::Vector2{ getWidthPixel(), getHeightPixel() }, mColorZFrameBuffer);

	if (mState.getShowFrustum())
	{
		bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::setViewName(viewId, (std::string("viewport frustum ") + std::to_string(mId)).c_str());
		bgfx::setViewFrameBuffer(viewId, mColorZFrameBuffer);
		setMatrixUniforms(viewId);
		bgfx::setViewRect(viewId, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());
		Drawers::Frustum::draw(viewId, mFrustumProgram, mRenderCameraState.position, Camera::Frustum(mCullCameraState));
	}
	
	if (mState.getShowTileBoxes())
	{
		bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::setViewName(viewId, (std::string("viewport aabbs ") + std::to_string(mId)).c_str());
		bgfx::setViewFrameBuffer(viewId, mColorZFrameBuffer);
		setMatrixUniforms(viewId);
		bgfx::setViewRect(viewId, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());
		std::vector<lgal::world::AABB3d> boxes;
		boxes.reserve(getFrameCullState().tileIds.size());
		Atlases::HeightAtlas const* atlas = getHeightAtlas();
		for (Tiles::TileId const& tileId : getFrameCullState().tileIds)
		{
			lgal::world::AABB2d bounds = tileId.worldBounds<world_float_t>();
			lgal::height::Range extents = ((atlas) ? atlas->extents(tileId, true) : lgal::height::Range(0, 0)) * mExaggeration;
			boxes.push_back({ lgal::world::Vector3(bounds.min, extents.begin), lgal::world::Vector3(bounds.max, extents.end) });
		}
		Drawers::AABB3d::draw(viewId, mBoxProgram, mRenderCameraState.position, boxes, mState.getTileBoxOpacity());
	}

	mState.mLifetimeRenderStats += mState.mFrameRenderStats;
	swapTripleBuffers();
}

void Viewport::readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue)
{
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(float);
	if (mDepthData.size() < dataSize)
	{
		mDepthData.resize(dataSize);
		if (defaultValue != 0)
		{
			std::memset(mDepthData.data(), defaultValue, mDepthData.size());
		}
		mWaitForDepthAfterResizing = 3;
	}

	if (mWaitForDepthAfterResizing <= 0)
	{
		auto data = mDepthData.data();
		bgfx::blit(viewId, mDepthReadbackHandle, 0, 0, mDepthTarg);
		bgfx::readTexture(mDepthReadbackHandle, data);

		mDepthCameras[mDepthCameraIndex] = mRenderCameraState;
		mDepthCameraIndex = (mDepthCameraIndex + 1) % mDepthCameras.size();
	}
	mWaitForDepthAfterResizing--;
}

void Viewport::copyDepth(std::vector<uint8_t>& target) const
{
	target.resize(mDepthData.size());
	std::copy(mDepthData.begin(), mDepthData.end(), target.begin());
}

void Viewport::copyColor(std::vector<uint8_t> &target, uint8_t defaultValue) const
{
	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(uint32_t);
	if (target.size() != dataSize)
	{
		target.resize(dataSize);
		if (defaultValue != 0)
		{
			std::memset(target.data(), defaultValue, target.size());
		}
	}

	auto data = target.data();
	bgfx::blit(viewId, mColorReadbackHandle, 0, 0, mColorTarg);
	bgfx::readTexture(mColorReadbackHandle, data);
}

void Viewport::resize()
{
	// set the camera state aspect
	setController(std::make_shared<Camera::Controllers::Identity>());
	mRenderCameraState.aspect = getAspect();
	mCullCameraState.aspect = getAspect();

	// reallocate textures of the appropriate size
	deallocateTextures();
	allocateTextures();

	// reallocate frame buffers with those textures
	deallocateFramebuffers();
	allocateFramebuffers();

	mSymbolManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
	invalidate();
}

void Viewport::setController(std::shared_ptr<Camera::CameraController> controller)
{
	mController = controller;
}

void Viewport::setCameraState(Camera::CameraState const& state)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mRenderCameraState = state;
}

gpu_float_t Viewport::depthAtPixel(int screenX, int screenY) const
{
	auto depthData = (uint8_t*)mDepthData.data();
	size_t y = size_t(screenY);
	if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
	{
		y = size_t(getHeightPixel()) - 1 - y;
	}
	auto depthIndex = (size_t(screenX) + (y * size_t(mState.getWidthPixel()))) * 4;
	if (depthIndex < mDepthData.size())
	{
		auto r = depthData[depthIndex] * (1.f / 255.f);
		auto g = depthData[depthIndex + 1] * (1.f / 255.f);
		auto b = depthData[depthIndex + 2] * (1.f / 255.f);
		auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
		return result;
	}
	return -1;
}

gpu_float_t Viewport::depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const
{
	// grab width and height
	float w = mState.getWidthPixel();
	float h = mState.getHeightPixel();

	// convert from normatlized to uv cooridinates
	float u = 0.5f * (normalizedScreen.x + 1.f);
	float v = 0.5f * (normalizedScreen.y + 1.f);
	
	// compute pixel coordinates and return depth
	int x = static_cast<int>(std::min(u * w, w - 1.f));
	int y = static_cast<int>(std::min(v * h, h - 1.f));
	return depthAtPixel(x, y);
}

lgal::world::Vector3 Viewport::unprojectPixel(int screenX, int screenY) const
{
	auto depth = depthAtPixel(screenX, screenY) * 2.0f - 1.0f;
	float x = (screenX / mState.getWidthPixel()) * 2.0f - 1.0f;
	float y = (screenY / mState.getHeightPixel()) * 2.0f - 1.0f;
	lgal::world::Vector3 normalizedCoords = { x, y, depth };
	return unprojectNormalized(normalizedCoords);
}

lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const
{
	auto depth = depthAtNormalized(normalizedScreen.as<gpu_float_t>()) * 2.0f - 1.0f;
	lgal::world::Vector3 normalizedCoords = { normalizedScreen, depth };
	return unprojectNormalized(normalizedCoords);
}

// TODO change architecture so that the unprojected point is more accurate
// the height discrepancy is really off when the camera is zoomed out
lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const
{
	Camera::CameraState::ProjectionData unprojected = mDepthCameras[mDepthCameraIndex].unproject(normalizedPos);
	lgal::world::Vector3 result = unprojected.position;

	// override z with a more accurate value
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(result.xy));
		distortedHeightKm *= mExaggeration;
		result.z = distortedHeightKm;
	}
	else
	{
		result.z = 0.0;
	}

	return result;
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector2 const& pos) const
{
	// compute z with a more accurate value
	height_float_t z = 0.0;
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(pos));
		distortedHeightKm *= mExaggeration;
		z = distortedHeightKm;
	}
	return project(lgal::world::Vector3{ pos, z });
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector3 const& pos) const
{
	Camera::CameraState::ProjectionData projected = mRenderCameraState.project(pos);
	return projected.position;
}

float Viewport::computeZoom() const
{
	lgal::world::Vector3 eye = mRenderCameraState.position;

	// start off by computing the zoom in one of two reasonable locations
	lgal::world::Vector3 center = unprojectNormalized(lgal::world::Vector2{ 0.f, 0.f });
	lgal::world::Vector3 bottom = unprojectNormalized(lgal::world::Vector2{ 0.f, 1.f });
	world_float_t dist = std::min(lmath::len(eye - center), lmath::len(eye - bottom));
	size_t count = 1;
	
	// if the depth is close enough, add some more sample locations
	int height = static_cast<int>(mState.getHeightPixel());
	int width = static_cast<int>(mState.getWidthPixel());
	int steps = 20;
	for (int y = height / 2; y < height; y += height / steps)
	{
		for (int x = width / 2; x < width; x += width / steps)
		{
			if (depthAtPixel(x, y) < 1.f)
			{
				dist += lmath::len(eye - unprojectPixel(x, y));
				++count;
			}
		}
	}

	// average the distances, then compute and return the zoom
	if (count > 0) { dist /= static_cast<world_float_t>(count); }
	world_float_t zoom = MapMath::zoom(dist);
	return static_cast<float>(zoom);
}

void Viewport::setMatrixUniforms(bgfx::ViewId const& viewId)
{
	mRenderCameraState.updateViewProj();
	bgfx::setViewTransform(viewId, mRenderCameraState.view, mRenderCameraState.proj);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)mState.getWidthPixel(), (uint16_t)mState.getHeightPixel());
}

void Viewport::renderTiles()
{
	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::setViewMode(viewId, bgfx::ViewMode::Sequential);

	if (!mSkydome) { bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0); }

	bgfx::setViewName(viewId, (std::string("viewport tiles ") + std::to_string(mId)).c_str());
	bgfx::setViewFrameBuffer(viewId, mColorDepthZFrameBuffer);
	setMatrixUniforms(viewId);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());

	std::vector<Tiles::TileId> tileIds = getFrameCullState().tileIds;

	{
		Camera::CameraState const& state = mCullCameraState;
		lgal::world::Vector3 center = state.position + static_cast<world_float_t>(mZoomKm) * state.rayDir({ 0, 0 });
		std::vector<Tiles::TileId> sorted = Pyramid::sorted(Tiles::TileId::Filter2D(tileIds, mCullCameraState.position, mFogStyle.range.y), center.xy);
		std::vector<Tiles::TileId> grandparents = Tiles::TileId::UniqueParents(sorted, 2);

		{
			LUCID_PROFILE_SCOPE("precache tiles");
			std::vector<Caching::TileCacheKey> keys = Caching::keys(grandparents, *mStyle, mZoom);
			auto parentsPrecached = Caching::TileCache::Instance()->precache(keys);
			toggle(ViewportCompletionFlags::PRECACHE_PARENTS, parentsPrecached);
			keys = Caching::keys(sorted, *mStyle, mZoom);
			bool precached = Caching::TileCache::Instance()->precache(keys);
			toggle(ViewportCompletionFlags::PRECACHE, precached);
		}

		{
			Caching::LayerCache::LockT lock = mLayerCache->lock();
			prepare(grandparents, lock);
			prepare(sorted, lock);
			mLayerCache->update(lock);
			toggle(ViewportCompletionFlags::PREPARE_VECTORS, mLayerCache->isQuiescent(lock));
		}
	}

	{
		LUCID_PROFILE_SCOPE("update terrain effects");

		size_t lines = 0;	// counting the number of contour line layers (temporary measure until shader lib is more flexible)
		for (auto const& layer : mStyle->visibleShaderLayers(mZoom))
		{
			std::string const& id = layer->id;
			auto it = mTerrainEffects.find(id);
			if (it != mTerrainEffects.end() && it->second->isVisible())
			{
				std::unique_ptr<TerrainEffects::TerrainEffectBase> const& effect = it->second;
				using T = Styling::Layer::Types;
				switch (layer->type)
				{
					case T::CONTOUR_LINE: update(static_cast<Styling::ContourLineLayer const&>(*layer), static_cast<TerrainEffects::ContourLine&>(*effect), lines); lines++; break;
					case T::ELEVATION:    update(static_cast<Styling::ElevationLayer   const&>(*layer), static_cast<TerrainEffects::ElevationShade&>(*effect));              break;
					case T::HILLSHADE:    update(static_cast<Styling::HillshadeLayer   const&>(*layer), static_cast<TerrainEffects::Hillshade&>(*effect));                   break;
					case T::INTERSECT:    update(static_cast<Styling::IntersectLayer   const&>(*layer), static_cast<TerrainEffects::IntersectShade&>(*effect));              break;
					case T::SLOPE_ANGLE:  update(static_cast<Styling::SlopeAngleLayer  const&>(*layer), static_cast<TerrainEffects::SlopeAngleShade&>(*effect));             break;
					case T::SLOPE_ASPECT: update(static_cast<Styling::SlopeAspectLayer const&>(*layer), static_cast<TerrainEffects::SlopeAspectShade&>(*effect));            break;
					case T::SUNLIGHT:     update(static_cast<Styling::SunlightLayer    const&>(*layer), static_cast<TerrainEffects::SunShadow&>(*effect));                   break;
					case T::VIEWSHED:     update(static_cast<Styling::ViewshedLayer    const&>(*layer), static_cast<TerrainEffects::Viewshed&>(*effect));                    break;
					default: break;
				}
			}
		}
	}

	Tiles::Gathered gathered = gather(tileIds);

	{
		LUCID_PROFILE_SCOPE("render tiles");
		{
			LUCID_PROFILE_SCOPE("rasters");

			if (mState.getShowRasters())
			{
				for (Tiles::Gathered::Info const& info : gathered)
				{
					render(viewId, info.terrain, info.raster);
				}
			}
		}

		{
			LUCID_PROFILE_SCOPE("vectors");
			for (std::shared_ptr<Styling::SourcedLayer const> layer : mStyle->visibleVectorLayers<Styling::SourcedLayer>(mZoom))
			{
				Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
				if (layer->type == Styling::Layer::Types::FILL && mState.getShowFills())
				{
					render(viewId, static_cast<Styling::FillLayer const&>(*layer), source, gathered);
				}
				else if (layer->type == Styling::Layer::Types::LINE && mState.getShowLines())
				{
					render(viewId, static_cast<Styling::LineLayer const&>(*layer), source, gathered);
				}
			}
		}
	}

	if ((mIncompleteRenderComponents & cAllPrepareFlags) == 0)
	{
		if (mTileLoadTimeMS.end == 0.0)
		{
			mTileLoadTimeMS = lgal::world::Range(mTileLoadTimeMS.begin, Utils::Timer::nowMS());
			Events::trigger(Events::EventType::TILES_LOADED);
		}
	}
}

void Viewport::renderWaypoints()
{
	LUCID_PROFILE_SCOPE("waypoints");

	bgfx::ViewId renderDataId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::touch(renderDataId);
	bgfx::setViewFrameBuffer(renderDataId, mColorZFrameBuffer);
	bgfx::setViewClear(renderDataId, BGFX_CLEAR_NONE);
	bgfx::setViewName(renderDataId, "viewport waypoint");
	setMatrixUniforms(renderDataId);
	WaypointManager::Instance()->draw(renderDataId, mRenderCameraState, mState.getDpiScalar());
}

template<typename LayerType>
bool Viewport::gatherSymbols()
{
	bool complete = true;
	std::vector<Tiles::TileId> tileIds = Tiles::TileId::Filter2D(getFrameCullState().tileIds, mCullCameraState.position, mFogStyle.range.y);
	for (auto const& layer : mStyle->visibleLayers<LayerType>(mZoom))
	{
		for (auto iter = tileIds.rbegin(); iter != tileIds.rend(); ++iter)
		{
			auto const& tileId = *iter;
			Caching::LayerCache::EntryKey key = { tileId, layer->id };

			if (mLayerCache->isPrepared(key))
			{
				Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
				auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
				auto& preparedSymbols = prepared->symbols();
				mFrameSymbols.insert(mFrameSymbols.end(), preparedSymbols.begin(), preparedSymbols.end());
			}
			else
			{
				complete = false;
			}
		}
	}
	return complete;
}

void Viewport::gatherSymbols()
{
	bool complete = true;

	for (auto const& [key, symbols] : mState.mSymbolCollection.getSymbolsMap())
	{
		mFrameSymbols.insert(mFrameSymbols.end(), symbols.begin(), symbols.end());
	}

	// TODO we have to refactor this code at some point. viewports shouldn't have to add the terrain effect labels on a per frame basis
	for (auto const& [name, effect] : mTerrainEffects)
	{
		if (effect->isVisible())
		{
			effect->getLabels(mFrameSymbols);
		}
	}

	complete &= gatherSymbols<Styling::SymbolLayer>();
	complete &= gatherSymbols<Styling::ContourLabelLayer>();
	
	toggle(ViewportCompletionFlags::GATHER_SYMBOLS, complete);
}

void Viewport::renderSymbols()
{
	LUCID_PROFILE_SCOPE("symbol render");

	mSymbolManager->update();

	mFrameSymbols.clear();
	gatherSymbols();
	bool done = true;
	if (mState.getShowSymbols())
	{
		done &= mSymbolManager->draw(mScreenSpaceManager, mFrameSymbols, mColorZFrameBuffer, *mSpritesheet->getImageAtlas(), getHeightAtlas());
		// TODO (Ronald): I *really* don't like this solution, but getting override symbols rendering above everything else quickly takes precedence
		done &= mSymbolManager->drawOverrideSymbols(mScreenSpaceManager, mOverrideSymbols, mColorZFrameBuffer, *mSpritesheet->getImageAtlas(), getHeightAtlas());

		/// TODO (scott CSONYX-167)
		// Don't like having this here but it prevents the Symbol Manager from "completing" early before the depth buffer
		// has been read back.
		// We might need to add an overall "System is still initializing" flag for the first couple of frames.
		done = done && mDepthData.size() > 0;
	}
	toggle(ViewportCompletionFlags::DRAW_SYMBOLS, done);
}

void Viewport::allocateTextures()
{
	// create color texture and set name
	{
		uint64_t flags = BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mColorTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		if (bgfx::isValid(mColorTarg)) { bgfx::setName(mColorTarg, (std::to_string(mId) + " viewport color tex").c_str()); }
	}

	{
		uint64_t flags = BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mColorReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		ONYX_ASSERT(bgfx::isValid(mColorReadbackHandle), "Failed to create color readback texture");
		bgfx::setName(mColorReadbackHandle, (std::to_string(mId) + " viewport color readback texture").c_str());
	}

	{
		uint64_t flags = BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
		mDepthTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
		if (bgfx::isValid(mDepthTarg)) { bgfx::setName(mDepthTarg, (std::to_string(mId) + " viewport RGBA8 float depth texture").c_str()); }
	}

	// create z buffer texture and set name
	{
		mZBufferFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
		mZTarg = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, mZBufferFormat, BGFX_TEXTURE_RT);
		if (bgfx::isValid(mZTarg)) { bgfx::setName(mZTarg, (std::to_string(mId) + " viewport z buffer").c_str()); }
	}

	{
		uint64_t requiredCaps = BGFX_CAPS_TEXTURE_BLIT | BGFX_CAPS_TEXTURE_READ_BACK;
		uint64_t caps = bgfx::getCaps()->supported;
		if ((caps & requiredCaps) == requiredCaps)
		{
			uint64_t flags = BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
			mDepthReadbackHandle = bgfx::createTexture2D(uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), false, 1, bgfx::TextureFormat::RGBA8, flags);
			if (bgfx::isValid(mDepthReadbackHandle)) { bgfx::setName(mDepthReadbackHandle, (std::to_string(mId) + " viewport RGBA8 depth readback buffer").c_str()); }
		}
	}
}

void Viewport::deallocateTextures()
{
	BgfxUtils::tryDestroy(mColorTarg);
	BgfxUtils::tryDestroy(mDepthTarg);
	BgfxUtils::tryDestroy(mZTarg);
	BgfxUtils::tryDestroy(mColorReadbackHandle);
	BgfxUtils::tryDestroy(mDepthReadbackHandle);
}

void Viewport::allocateFramebuffers()
{
	// first deallocate all the old frame buffers
	deallocateFramebuffers();

	bgfx::TextureHandle colorDepthZHandles[] = { mColorTarg, mDepthTarg, mZTarg };
	mColorDepthZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorDepthZHandles), colorDepthZHandles, false);
	if (bgfx::isValid(mColorDepthZFrameBuffer)) { bgfx::setName(mColorDepthZFrameBuffer, (std::to_string(mId) + " viewport color/depth/z framebuffer").c_str()); }

	bgfx::TextureHandle colorZHandles[] = { mColorTarg, mZTarg };
	mColorZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorZHandles), colorZHandles, false);
	if (bgfx::isValid(mColorZFrameBuffer)) { bgfx::setName(mColorZFrameBuffer, (std::to_string(mId) + " viewport color/z framebuffer").c_str()); }
}

void Viewport::deallocateFramebuffers()
{
	BgfxUtils::tryDestroy(mColorZFrameBuffer);
	BgfxUtils::tryDestroy(mColorDepthZFrameBuffer);
}

void Viewport::setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration)
{
	invalidate();
	if (shader == ShaderEnums::ConfigurableShaders::Terrain) { mRasterBasedShaderFamily.setCurrentShaderByParams(params, configuration); }
}

void Viewport::invalidate()
{
	mIncompleteRenderComponents |= ViewportCompletionFlags::INVALIDATED; // Force an update
}

void Viewport::propertyChanged(const char*)
{
	invalidate();
}

void Viewport::setStyle(std::shared_ptr<Styling::Style> style)
{
	mStyle = style;
	mLayerCache->clear();
	syncSources();
	invalidate();

	if (mStyle->hasSpriteUrl())
	{
		mSpritesheet->reset(style->spritesheetUrl(), mState.getSpritesheetSize());
	}

	// Reset font cache
	Font::M3DFontManager::reset(Font::getRobotoRegularConfig());
	mSymbolManager->resetFontManager();

	Font::M3DFontManager::addFontConfig({ Font::s_topoLabel, Styling::TextFontTypes::DistanceOutline, 9 }, Font::s_topoLabelId);
	Font::M3DFontManager::addTTF(Font::s_atlasGrotesk, Font::s_atlasGroteskFile);
	Font::M3DFontManager::addTTF(Font::s_montefiore, Font::s_montefiorePath);
	Font::M3DFontManager::addTTF(onyx::Font::s_robotoMono, s_robotoMonoRegularTtf, s_robotoMonoRegularTtf_size);
}

void Viewport::purge(bool immediate)
{
	for (auto const& [key, value] : *mLayerCache)
	{
		mLayerCache->purge(key, immediate);
	}
	invalidate();
}

void Viewport::syncSources()
{
	Styling::Source::zoom_level_t maxZoom = 0;
	for (auto const& name : mStyle->activeSources())
	{
		std::shared_ptr<Styling::Source const> source = mStyle->source(name);
		if (source->isHeight())
		{
			auto height = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			maxZoom = std::max(maxZoom, MapMath::maxDetailZoom(*height));
		}
		else
		{
			maxZoom = std::max(maxZoom, source->maxZoom);
		}
	}
	mDeepestZoomLevel = maxZoom;

	// add all dirty sources to TileCache
	for (std::string const& name : mStyle->dirtySourceNames())
	{
		// if TileCache already knows about a tiled source, it won't do anything
		Caching::TileCache::Instance()->addSource(name, mStyle->source(name));
	}

	touchRootTiles();
}

void Viewport::syncLayers()
{
	// utilize a const& to avoid overload confusion with private non-const methods of Style
	Styling::Style const& style = *mStyle;

	// NOTE: removing must occur first for correctness
	for (std::string const& id : style.removedLayerIds())
	{
		mTerrainEffects.erase(id);		// ignored if the layer is not present
		mLayerCache->purge(id, true);
	}

	// if necessary, allocate a terrain effect
	for (std::string const& id : style.addedLayerIds())
	{
		if (std::unique_ptr<TerrainEffects::TerrainEffectBase> effect = TerrainEffects::construct(style.layer(id)->type))
		{
			mTerrainEffects[id] = std::move(effect);
		}
	}

	// compute all updated layers
	std::set<std::string> updated = style.addedLayerIds();
	updated.insert(style.editedLayerIds().begin(), style.editedLayerIds().end());
	for (std::string const& id : updated)
	{
		// update LayerCache with a non-immediate purge of all updated layers
		mLayerCache->purge(id, false);
	}

	// sync visibility for terrain effects
	for (auto const& layer : style.layers())
	{
		auto found = mTerrainEffects.find(layer->id);
		if (found != mTerrainEffects.end())
		{
			bool enabled = layer->isVisible() && layer->range().contains(mZoom);
			found->second->toggle(enabled);
		}
	}
}

void Viewport::touchRootTiles()
{
	// prefetch the top level tiles
	for (auto const& [name, source] : mStyle->sources())
	{
		if (source->minZoom == 0)
		{
			Caching::TileCache::Instance()->at({ name, { 0, 0, 0 } });
		}
	}
}

Styling::Expressions::Arguments Viewport::expressionArgs() const
{
	return
	{
		mZoom,
		lmath::radiansToDegrees(mRenderCameraState.heading),
		lmath::radiansToDegrees(mRenderCameraState.pitch),
		0.0,	// center distance only matters for symbol layers, which should be prepared by LayerCache
		mStyle->getExpressionContext(),
		mState.getDpiScalar()
	};
}

Styling::Arguments Viewport::layerArgs() const
{
	return { { expressionArgs() }, mStyle->getLayoutContext(), mStyle->getPaintContext(), mStyle->getEffectContext() };
}

uint16_t Viewport::computeMeshResolution(DemPtrT const& dem, Tiles::TileId const& tileId) const
{
	return (dem && mExaggeration != 0.f) ? MapMath::meshResolution(*dem, tileId) : 1;
}

Caching::PreparedData::Metadata Viewport::computeMetadata(Tiles::TileId const& tileId, Styling::Layer const& layer, time_float_t const timestampMS, uint16_t const meshResolution) const
{
	return
	{
		layer.type,
		layer.dependencies(mStyle->initArgs()),
		layer.filter->dependencies(mStyle->getExpressionContext()),
		tileId,
		timestampMS,
		mZoom,
		mRenderCameraState,
		meshResolution,
		mStyle->getExpressionContext(),
		mStyle->getLayoutContext(),
		mStyle->getPaintContext(),
		mStyle->getEffectContext(),
		mState.getDpiScalar()
	};
}

bool Viewport::assignShaders()
{
	// these never change, just assign them once per frame
	mFillShader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainFill, 0);
	mLineShader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainLine, 0);

	if (!mSkydomeProgram.isValid()) { mSkydomeProgram = Shaders::load(Shaders::Handwritten::cSkydome, false); }
	if (!mBoxProgram.isValid()) { mBoxProgram = Shaders::load(Shaders::Handwritten::cPosColor, false); }
	if (!mFrustumProgram.isValid()) { mFrustumProgram = Shaders::load(Shaders::Handwritten::cPosColor, false); }

	std::vector<Styling::Layer::Types> layers;
	for (auto const& layer : mStyle->visibleLayers(mZoom))
	{
		if (layer->isShader())
		{
			layers.push_back(layer->type);
		}
	}

	// only reload the shader when necessary -- it may be the case that layers got toggled but the necessary shader didn't change
	// eg: a layer was removed and then a layer of the same type was added in the same location
	if (layers != mRasterBasedShaderLayers)
	{
		Shaders::ConfigurableShader family;
		family.loadSignature(ShaderManager::Instance()->getDefaultConfiguration(ShaderEnums::ConfigurableShaders::Terrain));

		for (Styling::Layer::Types const& layer : layers)
		{
			switch (layer)
			{
				case Styling::Layer::Types::CONTOUR_LINE: family.toggleComponent("ContourLine", true); break;
				case Styling::Layer::Types::ELEVATION:    family.toggleComponent("ElevationShade", true); break;
				case Styling::Layer::Types::HILLSHADE:    family.toggleComponent("Hillshade", true); break;
				case Styling::Layer::Types::INTERSECT:    family.toggleComponent("IntersectShade", true); break;
				case Styling::Layer::Types::RASTER:       family.toggleComponent("TextureLayer", true); break;
				case Styling::Layer::Types::SLOPE_ANGLE:  family.toggleComponent("SlopeAngleShade", true); break;
				case Styling::Layer::Types::SLOPE_ASPECT: family.toggleComponent("SlopeAspectShade", true); break;
				case Styling::Layer::Types::SUNLIGHT:     family.toggleComponent("Sunlight", true); break;
				case Styling::Layer::Types::VIEWSHED:     family.toggleComponent("Viewshed", true); break;
				default: break;
			}
		}

		if (family.count() == 0)
		{
			ONYX_THROW("Unable to load terrain shader!");
		}

		mRasterBasedShaderLayers = layers;
		mRasterBasedShaderFamily = family;
		return true;
	}

	return false;	// fallthrough to return false
}

void Viewport::prepare(std::vector<Tiles::TileId> const& tiles, Caching::LayerCache::LockT const& lock)
{
	LUCID_PROFILE_SCOPE("prepare vectors");

	std::shared_ptr<Styling::Terrain const> terrain = mStyle->terrain();
	DemPtrT dem = (terrain) ? std::static_pointer_cast<Styling::RasterDemSource const>(mStyle->source(terrain->source)) : nullptr;

	std::vector<TileTuple> tuples;
	{
		lgal::world::Vector3 const& eye = mCullCameraState.position;
		Atlases::HeightAtlas const* atlas = (terrain) ? static_cast<Atlases::HeightAtlas const*>(Caching::TileCache::Instance()->getSource(terrain->source).atlas()) : nullptr;
		tuples.reserve(tiles.size());
		for (Tiles::TileId const& tileId : tiles)
		{
			lgal::world::AABB3d aabb = (atlas) ? atlas->aabb(tileId, true) : lgal::world::AABB3d({ tileId.northwestCorner(), 0.0 }, { tileId.southeastCorner(), 0.0 });
			tuples.push_back({ tileId, MapMath::toGlobeBounds(tileId.worldBounds<world_float_t>()), aabb.distanceTo(eye) });
		}
	}

	for (auto const& layer : mStyle->visibleVectorLayers<Styling::SourcedLayer>(mZoom))		// loop over all layers
	{
		LUCID_PROFILE_SCOPE("layers");
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
		if (layer->type == Styling::Layer::Types::CONTOUR_LABEL && mState.getShowSymbols())
		{
			LUCID_PROFILE_SCOPE("contour labels");
			auto downcast = std::static_pointer_cast<Styling::ContourLabelLayer const>(layer);
			prepare<Styling::ContourLabelLayer const>(tuples, downcast, source, dem, mFogStyle.range.y, lock);
		}
		else if (layer->type == Styling::Layer::Types::FILL && mState.getShowFills())
		{
			LUCID_PROFILE_SCOPE("fills");
			auto downcast = std::static_pointer_cast<Styling::FillLayer const>(layer);
			Styling::FillStyle::Effect effect = mHorizon.convert(downcast->effect(layerArgs()), mFilteredZoomKm);	// realize effect and convert to world space units
			prepare<Styling::FillLayer const>(tuples, downcast, source, dem, std::min(mFogStyle.range.y, effect.fadeRange.y), lock);
		}
		else if (layer->type == Styling::Layer::Types::LINE && mState.getShowLines())
		{
			LUCID_PROFILE_SCOPE("lines");
			auto downcast = std::static_pointer_cast<Styling::LineLayer const>(layer);
			Styling::LineStyle::Effect effect = mHorizon.convert(downcast->effect(layerArgs()), mFilteredZoomKm);	// realize effect and convert to world space units
			prepare<Styling::LineLayer const>(tuples, downcast, source, dem, std::min(mFogStyle.range.y, effect.fadeRange.y), lock);
		}
		else if (layer->type == Styling::Layer::Types::SYMBOL && mState.getShowSymbols())
		{
			LUCID_PROFILE_SCOPE("symbols");
			auto downcast = std::static_pointer_cast<Styling::SymbolLayer const>(layer);
			prepare<Styling::SymbolLayer const>(tuples, downcast, source, dem, mFogStyle.range.y, lock);
		}
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::ContourLabelLayer const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock)
{
	if (source.type() != Styling::Source::Types::RASTER_DEM) { return; }
	Atlases::HeightAtlas const* heightAtlas = static_cast<Atlases::HeightAtlas const*>(source.atlas());
	if (!heightAtlas->contains(tileId)) { return; }
	auto heightTile = heightAtlas->at(tileId);

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(heightTile->id(), *layer, heightTile->timestampMS(), computeMeshResolution(dem, tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end() || mLayerCache->replaces(key, metadata, lock))
	{
		mLayerCache->insert(key, std::make_unique<Caching::Tasks::ContourLabelTask>(tileId, metadata, layer, heightTile), found, lock);
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::FillLayer const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock)
{
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(tileId, true);
	if (vectorTile == nullptr) { return; }

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, vectorTile->timestampMS(layer->sourceLayer), computeMeshResolution(dem, tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end())
	{
		mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
	}
	else if (mLayerCache->replaces(found, metadata, lock))
	{
		if (mLayerCache->restyles(found, metadata))
		{
			Caching::LayerCache::Entry const& entry = found->entry;
			auto existing = std::static_pointer_cast<Caching::PreparedFillData const>(entry.prepared);
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::RestyleFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, existing), found, lock);
		}
		else
		{
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshFillTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
		}
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::LineLayer const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock)
{
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(tileId, true);
	if (vectorTile == nullptr) { return; }

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, vectorTile->timestampMS(layer->sourceLayer), computeMeshResolution(dem, tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end())
	{
		mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), found, lock);
	}
	else if (mLayerCache->replaces(found, metadata, lock))
	{
		if (mLayerCache->restyles(found, metadata))
		{
			Caching::LayerCache::Entry const& entry = found->entry;
			auto existing = std::static_pointer_cast<Caching::PreparedLineData const>(entry.prepared);
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::RestyleLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, existing), lock);
		}
		else
		{
			mLayerCache->insert(key, std::make_unique<Caching::Tasks::FreshLineTask>(mRenderCameraState, tileId, metadata, layer, vectorTile), lock);
		}
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

void Viewport::prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::SymbolLayer const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock)
{
	Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();
	std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(tileId, true);
	if (vectorTile == nullptr) { return; }

	Atlases::HeightAtlas const* heightAtlas = getHeightAtlas();
	std::shared_ptr<Tiles::HeightTile const> heightTile = (heightAtlas) ? heightAtlas->find(tileId, true) : nullptr;

	Caching::LayerCache::EntryKey key = { tileId, layer->id };
	time_float_t timestampMS = std::max(vectorTile->timestampMS(layer->sourceLayer), heightTile ? heightTile->timestampMS() : 0.0);
	Caching::PreparedData::Metadata metadata = computeMetadata(vectorTile->id(), *layer, timestampMS, computeMeshResolution(dem, tileId));
	Caching::LayerCache::iterator found = mLayerCache->find(key);
	if (found == mLayerCache->end() || mLayerCache->replaces(key, metadata, lock))
	{
		auto task = std::make_unique<Caching::Tasks::FreshSymbolTask>(mRenderCameraState, tileId, metadata, layer, vectorTile, heightTile, mSpritesheet);
		mLayerCache->insert(key, std::move(task), found, lock);
	}
	else
	{
		mLayerCache->touch(found, lock);
	}
}

template<typename VectorLayerT>
void Viewport::prepare(std::vector<TileTuple> const& tuples, std::shared_ptr<VectorLayerT const> const& layer, Caching::Source const& source, DemPtrT const& dem, world_float_t radius, Caching::LayerCache::LockT const& lock)
{
	for (TileTuple const& tuple : tuples)	// loop over all tiles
	{
		if (source.specification()->minZoom <= tuple.id.level && tuple.distance <= radius)	// check zoom level and radius
		{
			if (lmath::intersectsOrTouches(source.specification()->bounds.aabb(), tuple.globeBounds))
			{
				prepare(tuple.id.moduloX(), layer, source, dem, lock);
			}
		}
	}
}

void Viewport::update(Styling::ContourLineLayer const& layer, TerrainEffects::ContourLine& effect, size_t index)
{
	Styling::ContourLineConfig config = mHorizon.convert(layer.realize(layerArgs()), mFilteredZoomKm);
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, index, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::ElevationLayer const& layer, TerrainEffects::ElevationShade& effect)
{
	Styling::ElevationConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, atlas.extents(getFrameCullState().tileIds, false), {layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS});
}

void Viewport::update(Styling::HillshadeLayer const& layer, TerrainEffects::Hillshade& effect)
{
	Styling::HillshadeConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::IntersectLayer const& layer, TerrainEffects::IntersectShade& effect)
{
	Styling::IntersectConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, atlas.extents(getFrameCullState().tileIds, false), { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SlopeAngleLayer const& layer, TerrainEffects::SlopeAngleShade& effect)
{
	Styling::SlopeAngleConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SlopeAspectLayer const& layer, TerrainEffects::SlopeAspectShade& effect)
{
	Styling::SlopeAspectConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::SunlightLayer const& layer, TerrainEffects::SunShadow& effect)
{
	// TODO consider just using the terrain source for SunShadow
	Styling::SunlightConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, getFrameCullState(), { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

void Viewport::update(Styling::ViewshedLayer const& layer, TerrainEffects::Viewshed& effect)
{
	// TODO consider just using the terrain source for Viewshed
	Styling::ViewshedConfig config = layer.realize(layerArgs());
	Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
	Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
	effect.update(config, { layer.source, source, atlas, mRenderCameraState, mCurrentFrameTimeMS });
}

Tiles::Gathered Viewport::gather(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("gather render info");

	Tiles::Gathered gathered(tiles);

	{
		LUCID_PROFILE_SCOPE("terrain");
		bool complete = true;
		for (Tiles::Gathered::Info& info : gathered)
		{
			gather(info.id, info.terrain);
			complete &= info.terrain.isComplete;
		}
		toggle(ViewportCompletionFlags::GATHER_TERRAIN, complete);
	}

	{
		LUCID_PROFILE_SCOPE("rasters");
		bool complete = true;
		if (!mRasterBasedShaderLayers.empty())
		{
			for (Tiles::Gathered::Info& info : gathered)
			{
				info.raster = Tiles::RasterInfo(info.id);
				gather(info.id, info.raster);
				complete &= info.raster.isComplete;
			}
		}
		toggle(ViewportCompletionFlags::GATHER_RASTERS, complete);
	}

	{
		LUCID_PROFILE_SCOPE("vectors");
		for (Tiles::Gathered::Info& info : gathered)
		{
			info.vector = Tiles::VectorInfo(info.id, mCurrentFrameTimeMS);
			info.vector.touch(mCurrentFrameTimeMS);
		}
		toggle(ViewportCompletionFlags::GATHER_VECTORS, true);
	}

	return gathered;
}

void Viewport::gather(Tiles::TileId const& tileId, Tiles::TerrainInfo& info)
{
	info.isComplete = true; // assume the info is complete until proven otherwise
	info.globeBounds = MapMath::toGlobeBounds(tileId.worldBounds<world_float_t>());

	lgal::world::Vector3 const& eye = mCullCameraState.position;
	if (mStyle->hasTerrain())
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
		std::shared_ptr<Styling::RasterDemSource const> specification = std::static_pointer_cast<Styling::RasterDemSource const>(source.specification());
		Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());

		info.distance = atlas.aabb(tileId, true).distanceTo(eye);

		Tiles::AtlasInfo atlasInfo = Tiles::AtlasInfo::Compute(atlas, tileId, source.specification()->range());
		info.atlas = atlasInfo;
		info.meshResolution = computeMeshResolution(specification, tileId);
		bool missing = atlasInfo.handle.idx == atlas.getMissingTileHandle().idx;
		info.isComplete &= !missing && (atlasInfo.level == std::min(tileId.level, specification->range().end));
	}
	else
	{
		lgal::world::AABB3d aabb({ tileId.northwestCorner(), 0.0 }, { tileId.southeastCorner(), 0.0 });
		info.distance = aabb.distanceTo(eye);
		info.atlas = { mDummyTerrainHandle, 1, { 0, 0, 1, 1 }, 0.f, 0 };
		info.meshResolution = 1;
	}
}

void Viewport::gather(Tiles::TileId const& tileId, Tiles::RasterInfo& info)
{
	info.isComplete = true;	// assume true until proven false
	info.layerCount = 0;
	for (std::shared_ptr<Styling::RasterLayer const> layer : mStyle->visibleLayers<Styling::RasterLayer>(mZoom))
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
		Styling::RasterSource const& specification = static_cast<Styling::RasterSource const&>(*source.specification());
		Atlases::TileAtlas const* atlas = source.atlas();

		Styling::RasterStyle style = layer->realize(layerArgs());
		Tiles::AtlasInfo atlasInfo = Tiles::AtlasInfo::Compute(*atlas, tileId.moduloX(), source.specification()->range(), style.opacity);

		bool missing = atlasInfo.handle.idx == atlas->getMissingTileHandle().idx;
		info.isComplete &= !missing && (atlasInfo.level == std::min(tileId.level, specification.range().end));

		// TODO (stouff) remove the max raster layer limitation 
		if (atlasInfo.level >= source.specification()->minZoom && info.layerCount < Tiles::RasterInfo::MAX_TEXTURE_LAYERS)
		{
			info.layers[info.layerCount++] = atlasInfo;
		}
	}
}

void Viewport::render(bgfx::ViewId const viewId, Tiles::TerrainInfo const& terrain, Tiles::RasterInfo const& raster)
{
	if (!mRasterBasedShaderLayers.empty())
	{
		auto subsetCount = std::min(size_t(raster.layerCount), mRasterBasedShaderFamily.count() - 1);
		if (subsetCount > 0) { --subsetCount; }

		auto shader = mRasterBasedShaderFamily.getShader((int)subsetCount);
		ONYX_ASSERT(shader != nullptr, "Unable to retrieve shader for requested ConfigurableShader/texture count subset");

		lgal::Color background = 0x00FFFFFF;
		for (auto const& layer : mStyle->visibleLayers<Styling::BackgroundLayer>(mZoom))
		{
			Styling::BackgroundStyle style = layer->realize(layerArgs());
			background = lgal::Color::FromABGR(style.abgr);
		}
		
		Rendering::render({ viewId, mRenderCameraState, *shader, terrain, raster, background, mTerrainEffects, mExaggeration });
	}
}

void Viewport::render(bgfx::ViewId const viewId, Styling::FillLayer const& layer, Styling::FillStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector)
{
	LUCID_PROFILE_SCOPE("fills");

	// search cache for any reasonably detailed buffer
	lgal::gpu::Vector4 fragClip = { 0, 0, 1, 1 };	// TODO try using a stencil buffer to clip fragments to the rendered tile
	auto it = mLayerCache->find({ vector.id.moduloX(), layer.id }, 4, fragClip);
	if (it != mLayerCache->end() && it->entry.prepared)
	{
		Caching::PreparedFillData const& prepared = static_cast<Caching::PreparedFillData const&>(*it->entry.prepared);

		Tiles::TerrainInfo renderedTerrain = terrain;
		Tiles::VectorInfo renderedVector = vector;
		if (it->key.tileId() < vector.id)
		{
			renderedVector = Tiles::VectorInfo{ vector.id.parentAtLevel(it->key.tileId().level), renderedVector.useTimestamp };
			if (mStyle->hasTerrain())
			{
				Caching::Source const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
				renderedTerrain.atlas = Tiles::AtlasInfo::Compute(*source.atlas(), it->key.tileId(), source.specification()->range());
			}
		}

		uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_BLEND_ALPHA | BGFX_STATE_CULL_CCW;
		Rendering::render({ viewId, mRenderCameraState, *mFillShader, mLayerCache->getFillStyles(), mFogStyle, effect, renderedTerrain, renderedVector, prepared, fragClip, mExaggeration, mZoom, mZoomKm, state });
	}
}

void Viewport::render(bgfx::ViewId const viewId, Styling::LineLayer const& layer, Styling::LineStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector)
{
	LUCID_PROFILE_SCOPE("lines");

	lgal::gpu::AABB2d everything = lgal::gpu::AABB2d::everything();
	lgal::gpu::Vector4 fragClip = { everything.min, everything.max };
	auto it = mLayerCache->find({ vector.id.moduloX(), layer.id }, 4, fragClip);
	if (it != mLayerCache->end() && it->entry.prepared)
	{
		Caching::PreparedLineData const& prepared = static_cast<Caching::PreparedLineData const&>(*it->entry.prepared);
		uint32_t num = static_cast<uint32_t>(prepared.instances.size());
		if (num == 0 || !bgfx::isValid(prepared.handle())) { return; }

		Tiles::TerrainInfo renderedTerrain = terrain;
		Tiles::VectorInfo renderedVector = vector;
		if (it->key.tileId().level < vector.id.level)
		{
			renderedVector = Tiles::VectorInfo{ vector.id.parentAtLevel(it->key.tileId().level), renderedVector.useTimestamp };
			if (mStyle->hasTerrain())
			{
				Caching::Source const& heightSource = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
				renderedTerrain.atlas = Tiles::AtlasInfo::Compute(*heightSource.atlas(), it->key.tileId(), heightSource.specification()->range());
			}
		}

		uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_BLEND_ALPHA;
		Rendering::render({ viewId, mRenderCameraState, *mLineShader, *mLineMesh, mLayerCache->getLineStyles(), mFogStyle, effect, renderedTerrain, renderedVector, prepared, fragClip, mExaggeration, mZoomKm, state });
		mState.mFrameRenderStats.renderedLineInstances += num;
	}
}

template<typename VectorLayerT>
void Viewport::render(bgfx::ViewId const viewId, VectorLayerT const& layer, Caching::Source const& source, Tiles::Gathered const& gathered)
{
	// realize effect and convert to world space units
	auto effect = mHorizon.convert(layer.effect(layerArgs()), mFilteredZoomKm);

	world_float_t radius = std::min(mFogStyle.range.y, effect.fadeRange.y);
	for (Tiles::Gathered::Info const& info : gathered)
	{
		if (source.specification()->minZoom <= info.id.level && info.terrain.distance <= radius)
		{
			if (lmath::intersectsOrTouches(source.specification()->bounds.aabb(), info.terrain.globeBounds))
			{
				render(viewId, layer, effect, info.terrain, info.vector);
			}
		}
	}
}

float Viewport::AliasZoom(float const zoom)
{
	float precision = 10.0;
	uint32_t aliased = static_cast<uint32_t>(std::round(zoom * precision));
	return static_cast<float>(aliased) / precision;
}

Symbol::MapSymbol Viewport::getOverrideSymbol(index_t i) const
{
	Symbol::MapSymbol toRet{ Styling::SymbolPlacement::UNSPECIFIED };
	if (overrideSymbolExists(i))
	{
		auto const s = mOverrideSymbols[i];
		auto placement = s->getPlacement();
		toRet.setPlacement(placement);

		if (s->hasLabel())
		{
			auto const lbl = s->getLabel();
			auto lblCpy = std::make_shared<Symbol::MapLabel>(*lbl);
			toRet.addLabel(lblCpy);
		}
		if (s->hasIcon())
		{
			auto const& icon = s->getIcon().value();
			toRet.addIcon(icon);
		}
	}

	return toRet;
}

int Viewport::addOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s) 
{
	if (mOverrideSymbols.size() > cMaxNumOverrideSyms)
	{
		logE("Reached maximum number of override symbols");
		return -1;
	}
	mOverrideSymbols.push_back(std::move(s));
	invalidate();

	return (int)(mOverrideSymbols.size() - 1);
}

}
