#include "Picker.h"

#include "Caching/Layers/LayerCache.h"
#include "Caching/Layers/PreparedData.h"
#include "Camera/ScreenSpaceManager.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Style.h"
#include "MapViewer.h"

namespace onyx::Picking
{


bool withinRange(lgal::globe::Vector2 pos, lgal::gpu::LineSegment2 segment, input_float_t pickRange)
{
	float dist = segment.distanceTo(pos);
	return dist < pickRange;
}

// TODO (scott CSONYX-166) determine if we need to return duplicate features
void addFeature(FeatureId picked, std::vector<FeatureId>& features)
{
	bool alreadyHave = false;
	for (size_t i = 0; i < features.size(); i++)
	{
		if (features[i] == picked)
		{
			alreadyHave = true;
			break;
		}
	}

	if (!alreadyHave)
	{
		features.push_back(picked);
	}
}

void gatherLines(std::shared_ptr<const Caching::PreparedLineData> prepared, lgal::world::Vector2 tilePos, std::string const &sourceId, std::string const& source, std::string const& sourceLayer, std::vector<FeatureId>& features, input_float_t pickRange)
{
	if (prepared)
	{
		auto const pos = tilePos.as<globe_float_t>();

		for (auto const& feature : prepared->features)
		{
		
			auto bounds = feature.feature->aabb();

			if (bounds.contains(pos))
			{
				for (size_t j = feature.range.begin; j < feature.range.end; j++)
				{
					auto const& segment = prepared->instances[j].segment;
					if (withinRange(pos, segment, pickRange))
					{
						addFeature({ sourceId, { source, sourceLayer, feature.feature->id() } }, features);
					}
				}
			}
		}
	}
}

void gatherFills(std::shared_ptr<const Caching::PreparedFillData> prepared, lgal::world::Vector2 tilePos, std::string const& sourceId, std::string const& source, std::string const& sourceLayer, std::vector<FeatureId>& features)
{
	if (prepared)
	{
		auto const pos = tilePos.as<globe_float_t>();

		for (auto const &feature : prepared->features)
		{
			lgal::tile::AABB2d const bounds = feature.feature->aabb();
			if (bounds.contains(pos))
			{
				Vector::PolygonFeature const& polygon = static_cast<Vector::PolygonFeature const&>(*feature.feature);

				for (size_t j = 0; j < polygon.geometries().size(); j++)
				{
					if (polygon.geometries()[j].contains(pos, lmath::Boundary::CLOSED)) //may not be quite as precise as it should be? Not sure it properly handles holes in polygons every time
					{
						addFeature({ sourceId, { source, sourceLayer, feature.feature->id() } }, features);
						break;
					}
				}
			}
		}
	}
}

void gatherSymbols(Viewport* vp, std::shared_ptr<Caching::PreparedSymbolData const> prepared, lgal::gpu::Vector2 screenPos, std::string const& sourceId, std::string const& source, std::string const& sourceLayer, std::vector<FeatureId>& features)
{
	std::vector<std::shared_ptr<Symbol::MapSymbol>> const preparedSymbols = prepared->symbols();
	for (auto symbol : preparedSymbols)
	{
		if (symbol != nullptr)
		{
			//looks like symbols may not be storing their screen state after symbol manager generates it?
			//Symbol::SymbolState state = symbol->getScreenState();
			lgal::world::Vector3 wp = symbol->getPosition();
			lgal::gpu::Vector2 sp = vp->project(wp).xy.as<gpu_float_t>();
			sp.x = (sp.x * 0.5f + 0.5f) * (gpu_float_t)vp->getWidthPixel();
			sp.y = (-sp.y * 0.5f + 0.5f) * (gpu_float_t)vp->getHeightPixel();
			lgal::gpu::Vector2 size = lgal::gpu::Vector2(25.0f, 25.0f);
			lgal::gpu::AABB2d box(sp - size, sp + size);

			if (box.contains(screenPos))
			{
				addFeature({ sourceId, { source, sourceLayer, symbol->getFeatureId() } }, features);
			}
		}
	}
}

void gatherAll(Viewport* vs, Caching::LayerCache const& layerCache, Tiles::TileId id, lgal::input::Vector2 point, std::vector<FeatureId>& features, input_float_t pickRange)
{
	time_float_t start = Utils::Timer::nowMS();

	std::vector<Utils::UUID> selectedIds;

	//project screen to world
	int screenX = (int)((point.x * 0.5 + 0.5) * vs->getWidthPixel());
	int screenY = (int)((point.y * 0.5 + 0.5) * vs->getHeightPixel());
	lgal::gpu::Vector2 screenPos = lgal::gpu::Vector2((gpu_float_t)screenX, vs->getHeightPixel() - (gpu_float_t)screenY);

	logI("click pos %f, %f", screenPos.x, screenPos.y);
	const lgal::world::Vector3 worldPos = vs->unprojectPixel(screenX, screenY);
	lgal::world::Vector2 tilePos = id.toUVCoords<world_float_t>(worldPos.xy, onyx::Tiles::TileId::Origin::TOP_LEFT);
	if (tilePos.x < 0 || tilePos.y < 0 || tilePos.x > 1 || tilePos.y > 1) //outside this tile bounds, ignore it
	{
		return;
	}

	lgal::gpu::Vector4 fragClip;
	for (std::shared_ptr<Styling::SourcedLayer const> layer : vs->getStyle()->visibleLayers<Styling::SourcedLayer>(vs->getZoom()))
	{
		if ((layer->type & Styling::Layer::Types::LINE) != 0)
		{
			Styling::LineLayer const& line = static_cast<Styling::LineLayer const&>(*layer);

			auto it = layerCache.find({ id.moduloX(), line.id }, 3, fragClip);
			auto prepared = std::static_pointer_cast<Caching::PreparedLineData const>(it->entry.prepared);

			gatherLines(prepared, tilePos, layer->id, layer->source, layer->sourceLayer, features, pickRange);
		}
		else if ((layer->type & Styling::Layer::Types::FILL) != 0)
		{
			auto it = layerCache.find({ id.moduloX(), layer->id }, 3, fragClip);
			if (it == layerCache.end()) { return; }
			auto prepared = std::static_pointer_cast<Caching::PreparedFillData const>(it->entry.prepared);
			gatherFills(prepared, tilePos, layer->id, layer->source, layer->sourceLayer, features);
		}
		else if ((layer->type & Styling::Layer::Types::SYMBOL) != 0)
		{
			Caching::LayerCache::EntryKey key = { id, layer->id };

			if (layerCache.isPrepared(key))
			{
				Caching::LayerCache::Entry const& entry = layerCache.at(key);
				auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
				gatherSymbols(vs, prepared, screenPos, layer->id, layer->source, layer->sourceLayer, features);
			}
		}
	}

	logI("Pick Time %f", Utils::Timer::nowMS() - start);
}

std::vector<FeatureId> queryFeatures(viewportId_t id, lgal::input::Vector2 pos, input_float_t radiusPixels)
{
	logD("querying features at position: (%0.4f, %0.4f)", pos.x, pos.y);
	auto vs = MapViewer::Instance()->getViewport(id);
	auto linePickerRange = (radiusPixels / vs->getWidthPixel()) * 2.0; //converting approximately to pixels (wont be quite the same on x and y due to aspect ratio, but should be close enough
	std::vector<FeatureId> features;
	Caching::LayerCache const& layerCache = vs->getLayerCache();
	Pyramid::CullResult const& cullResult = static_cast<const Viewport*>(vs)->getFrameCullState();
	std::vector<Tiles::TileId> const& tileIds = cullResult.tileIds;

	for (size_t i = 0; i < tileIds.size(); i++)
	{
		{
			LUCID_PROFILE_SCOPE("Picking - Highlight");
			gatherAll(vs, layerCache, tileIds[i], pos, features, linePickerRange);
		}
	}

	//flip it around so it returns in top down order of the layers
	std::reverse(features.begin(), features.end());
	return features;
}

}