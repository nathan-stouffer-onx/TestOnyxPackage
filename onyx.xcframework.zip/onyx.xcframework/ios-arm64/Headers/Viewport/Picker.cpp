#include "Picker.h"

#include "Caching/Layers/LayerCache.h"
#include "Caching/Layers/PreparedData.h"
#include "Camera/ScreenSpaceManager.h"
#include "MapViewer.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Style.h"

namespace onyx::Picking
{

// const val SPOT_ID_PROPERTY_ID = "id"
// string  const val SPOT_NAME_PROPERTY_ID = "name"
// const val SPOT_MODE_PROPERTY_ID = "mode"
// const val SPOT_COUNT_PROPERTY_ID = "count"
// int const val SPOT_ROUTE_COUNT_PROPERTY_ID = "routeCount"
// int const val SPOT_TRAIL_COUNT_PROPERTY_ID = "trailCount"
// const val SPOT_HAS_CLASSIC = "hasClassic"

// TODO (scott CSONYX-166) determine if we need to return duplicate features
void addFeature(FeatureId picked, std::vector<FeatureId>& features)
{
	bool alreadyHave = false;
	for (size_t i = 0; i < features.size(); i++)
	{
		if (features[i] == picked)
		{
			alreadyHave = true;
			break;
		}
	}

	if (!alreadyHave)
	{
		features.push_back(picked);
	}
}

void gatherLines(std::shared_ptr<const Caching::PreparedLineData> prepared, lgal::world::Vector2 tilePos, std::string const &sourceId, std::string const& source, std::string const& sourceLayer, std::vector<FeatureId>& features, input_float_t pickRange)
{
	if (prepared)
	{
		lgal::tile::Circle circle(tilePos.as<globe_float_t>(), static_cast<tile_float_t>(pickRange));
		for (auto const& feature : prepared->features)
		{
			if (feature.feature->intersects(circle))
			{
				addFeature({ sourceId, { source, sourceLayer, feature.feature->id() }, feature.feature }, features);
			}
		}
	}
}

void gatherFills(std::shared_ptr<const Caching::PreparedFillData> prepared, lgal::world::Vector2 tilePos, std::string const& sourceId, std::string const& source, std::string const& sourceLayer, std::vector<FeatureId>& features, input_float_t pickRange)
{
	if (prepared)
	{
		lgal::tile::Circle circle(tilePos.as<globe_float_t>(), static_cast<tile_float_t>(pickRange));
		for (auto const &feature : prepared->features)
		{
			if (feature.feature->intersects(circle))
			{
				addFeature({ sourceId, { source, sourceLayer, feature.feature->id() }, feature.feature }, features);
			}
		}
	}
}

void gatherSymbols(Viewport* vp, std::shared_ptr<Caching::PreparedSymbolData const> prepared, lgal::gpu::Vector2 screenPos, std::string const& sourceId, std::string const& source, std::string const& sourceLayer, std::vector<FeatureId>& features)
{
	std::vector<std::shared_ptr<Symbol::MapSymbol>> const preparedSymbols = prepared->symbols();
	for (auto const &symbol : preparedSymbols)
	{
		if (symbol != nullptr)
		{
			// To get the symbol's persistent state, you'll have to grab the symbol from symbol manager
			//Symbol::SymbolState state = symbol->getScreenState();
			lgal::world::Vector3 wp = symbol->getAnchorPos();
			lgal::gpu::Vector2 sp = vp->project(wp).xy.as<gpu_float_t>();
			sp.x = (sp.x * 0.5f + 0.5f) * (gpu_float_t)vp->getWidthPixel();
			sp.y = (-sp.y * 0.5f + 0.5f) * (gpu_float_t)vp->getHeightPixel();
			lgal::gpu::Vector2 size = lgal::gpu::Vector2(25.0f, 25.0f);
			lgal::gpu::AABB2d box(sp - size, sp + size);

			if (box.contains(screenPos))
			{
				auto const feature = symbol->getFeature();
				if (feature == nullptr)
				{
					continue;
				}

				addFeature({ sourceId, { source, sourceLayer, feature->id() }, feature }, features);
				auto const& props = feature->properties();
				auto name = props.find("name");
				if (name != props.end())
				{
					auto const &val = name->second;
					if (val.is_string())
					{
						logD("property name: %s", std::string(val).c_str());
					}
				}
			}
		}
	}
}

void gatherAll(Viewport* vs, Caching::LayerCache const& layerCache, Tiles::TileId id, lgal::input::Vector2 point, std::vector<FeatureId>& features, input_float_t pickRange, char const* layerName, Styling::Layer::Types layerTypes)
{
	time_float_t start = Utils::Timer::nowMS();

	std::vector<Utils::UUID> selectedIds;

	//project screen to world
	int screenX = (int)((point.x * 0.5 + 0.5) * vs->getWidthPixel());
	int screenY = (int)((point.y * 0.5 + 0.5) * vs->getHeightPixel());
	lgal::gpu::Vector2 screenPos = lgal::gpu::Vector2((gpu_float_t)screenX, (gpu_float_t)screenY);

	logI("click pos %f, %f", screenPos.x, screenPos.y);
	lgal::world::Vector3 const worldPos = vs->unprojectPixel(screenPos.as<screen_coord_t>());
	lgal::world::Vector2 tilePos = id.toUVCoords<world_float_t>(worldPos.xy, Tiles::TileId::Origin::TOP_LEFT);
	lgal::world::AABB2d bounds = lgal::world::AABB2d::unit();
	if (!bounds.contains(tilePos))	// ignore queries outside the tile bounds
	{
		return;
	}

	for (std::shared_ptr<Styling::SourcedLayer const> layer : vs->getStyle()->visibleLayers<Styling::SourcedLayer>(vs->getZoom()))
	{
		if ((layer->type & layerTypes) == 0)
		{
			continue;
		}
		if (layerName != nullptr && layer->sourceLayer != layerName)
		{
			continue;
		}

		if ((layer->type & Styling::Layer::Types::LINE) != 0)
		{
			Styling::LineLayer const& line = static_cast<Styling::LineLayer const&>(*layer);

			auto it = layerCache.find({ id.moduloX(), line.id }, 4);
			if (it == layerCache.end()) { continue; }

			auto prepared = std::static_pointer_cast<Caching::PreparedLineData const>(it->entry.prepared);
			gatherLines(prepared, tilePos, layer->id, layer->source, layer->sourceLayer, features, pickRange);
		}
		else if ((layer->type & Styling::Layer::Types::FILL) != 0)
		{
			auto it = layerCache.find({ id.moduloX(), layer->id }, 4);
			if (it == layerCache.end()) { continue; }

			auto prepared = std::static_pointer_cast<Caching::PreparedFillData const>(it->entry.prepared);
			gatherFills(prepared, tilePos, layer->id, layer->source, layer->sourceLayer, features, pickRange);
		}
		else if ((layer->type & Styling::Layer::Types::SYMBOL) != 0)
		{
			Caching::LayerCache::EntryKey key = { id, layer->id };

			if (layerCache.isPrepared(key))
			{
				Caching::LayerCache::Entry const& entry = layerCache.at(key);
				auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
				gatherSymbols(vs, prepared, screenPos, layer->id, layer->source, layer->sourceLayer, features);
			}
		}
	}

	logI("Pick Time %f", Utils::Timer::nowMS() - start);
}

std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, MapMath::LonLat const& globePos, char const* layerName, input_float_t radius)
{
	logD("querying features at globe position: (%0.4f, %0.4f)", globePos.lon, globePos.lat);
	auto vs = MapViewer::Instance()->getViewport(id);
	auto pt = globePos.toWorldPos();
	auto atlas = vs->getHeightAtlas();//  HeightManager::Instance()->heightAt(pt);
	lgal::world::Vector3 worldPos(pt, 0);
	if (atlas != nullptr)
	{
		worldPos.z = atlas->heightAt(pt);
	}
	logD("querying features at world position: (%0.4f, %0.4f, %0.4f)", worldPos.x, worldPos.y, worldPos.z);
	auto &state = vs->getCameraState();
	logD("camera is %s", state.isValid() ? "valid" : "INVALID");
	auto screenPos = vs->project(worldPos);
	return queryRenderedFeatures(id, screenPos.xy, layerName, radius);
}

std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, MapMath::LonLatElevation const& globePos, char const* layerName, input_float_t radius)
{
	logD("querying features at globe position: (%0.4f, %0.4f, %0.4f)", globePos.lon, globePos.lat, globePos.elevation);
	auto vs = MapViewer::Instance()->getViewport(id);
	auto worldPos = globePos.toWorldPos();
	logD("querying features at world position: (%0.4f, %0.4f, %0.4f)", worldPos.x, worldPos.y, worldPos.z);
	auto &state = vs->getCameraState();
	logD("camera is %s", state.isValid() ? "valid" : "INVALID");
	auto screenPos = vs->project(worldPos);
	return queryRenderedFeatures(id, screenPos.xy, layerName, radius);
}

std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, lgal::input::Vector2 screenPos, char const* layerName, input_float_t radiusPixels)
{
	logD("querying features at screen position: (%0.4f, %0.4f)", screenPos.x, screenPos.y);
	auto vs = MapViewer::Instance()->getViewport(id);
	auto linePickerRange = (radiusPixels / vs->getWidthPixel()) * 2.0; //converting approximately to pixels (wont be quite the same on x and y due to aspect ratio, but should be close enough
	std::vector<FeatureId> features;
	Caching::LayerCache const& layerCache = vs->getLayerCache();
	Pyramid::CullResult const& cullResult = static_cast<const Viewport*>(vs)->getFrameCullState();
	std::vector<Tiles::TileId> const& tileIds = cullResult.tileIds;

	for (size_t i = 0; i < tileIds.size(); i++)
	{
		{
			LUCID_PROFILE_SCOPE("Picking - Highlight");
			gatherAll(vs, layerCache, tileIds[i], screenPos, features, linePickerRange, layerName, Styling::Layer::Types::ALL);
		}
	}

	//flip it around so it returns in top down order of the layers
	std::reverse(features.begin(), features.end());
	return features;
}

std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, lgal::input::Vector2 screenPos, input_float_t radiusPixels, Styling::Layer::Types layerTypes)
{
	logD("querying features at screen position: (%0.4f, %0.4f)", screenPos.x, screenPos.y);
	auto vs = MapViewer::Instance()->getViewport(id);
	auto linePickerRange = (radiusPixels / vs->getWidthPixel()) * 2.0; //converting approximately to pixels (wont be quite the same on x and y due to aspect ratio, but should be close enough
	std::vector<FeatureId> features;
	Caching::LayerCache const& layerCache = vs->getLayerCache();
	Pyramid::CullResult const& cullResult = static_cast<const Viewport*>(vs)->getFrameCullState();
	std::vector<Tiles::TileId> const& tileIds = cullResult.tileIds;

	for (size_t i = 0; i < tileIds.size(); i++)
	{
		{
			LUCID_PROFILE_SCOPE("Picking - Highlight");
			gatherAll(vs, layerCache, tileIds[i], screenPos, features, linePickerRange, nullptr, layerTypes);
		}
	}

	//flip it around so it returns in top down order of the layers
	std::reverse(features.begin(), features.end());
	return features;
}

}