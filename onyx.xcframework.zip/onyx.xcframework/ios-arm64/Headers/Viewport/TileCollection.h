#ifndef __TILE_COLLECTION_H__
#define __TILE_COLLECTION_H__

#include <vector>

#include <lucid/Profiler.h>

#include "Tiles/VectorTile.h"
#include "Pyramid/Culling.h"

namespace onyx {
		
	typedef lucid::math::Range<Tiles::TileId::IdCoordsT> tileRangeT;

	// TODO (stouff) probably delete this class
	struct TileCollections
	{
		// forced cull state
		std::vector<Tiles::TileId> forceCulled;

		// cull state clipped to debug zoom level
		std::vector<Tiles::TileId> zoomCulled;

		// the tiles we would like to render -- zoomCulled clipped by debug UI
		std::vector<Tiles::TileId> rasters;

		// TileCollections::rasters filtered to [maxZoom - 2, maxZoom]
		std::vector<Tiles::TileId> vectors;

		// 2 zoom levels above TileCollections::rasters
		std::vector<Tiles::TileId> rasterGrandparents;

		// 2 zoom levels above TileCollections::vectors
		std::vector<Tiles::TileId> vectorGrandparents;

		TileCollections() { }

		TileCollections(Pyramid::CullResult const& cullState, tileRangeT zoomRange = { 0, 20 }, tileRangeT renderRange = { -1, -1 })
		{
			update(cullState, zoomRange, renderRange);
		}

		void clear()
		{
			zoomCulled.clear();

			rasters.clear();
			vectors.clear();

			rasterGrandparents.clear();
			vectorGrandparents.clear();
		}

		void update(Pyramid::CullResult const& cullState, tileRangeT zoomRange = { 0, 20 }, tileRangeT renderRange = { -1, -1 })
		{
			clear();

			if (forceCulled.empty())
			{
				// cull out zoom levels for debugging
				Tiles::TileId::filter(zoomCulled, cullState.tileIds, zoomRange.begin, zoomRange.end);
			}
			else
			{
				Tiles::TileId::filter(zoomCulled, forceCulled, zoomRange.begin, zoomRange.end);
			}

			// filter the tiles by debug range
			{
				if (renderRange.begin == -1 || renderRange.end == -1)
				{
					rasters.insert(rasters.begin(), zoomCulled.begin(), zoomCulled.end());
				}
				else
				{
					auto min = std::min(zoomCulled.size(), size_t(std::max(0, renderRange.begin)));
					auto max = std::min(zoomCulled.size(), size_t(renderRange.end));
					min = std::min(min, max);

					auto begin = zoomCulled.begin() + min;
					auto end = zoomCulled.begin() + max;

					if (end != zoomCulled.end())
					{
						++end;
					}

					rasters.insert(rasters.begin(), begin, end);
				}
			}

			vectors = rasters;

			// compute low detail collections
			Tiles::TileId::uniqueParents(rasterGrandparents, rasters, 2);
			Tiles::TileId::uniqueParents(vectorGrandparents, vectors, 2);
		}
	};
}

#endif