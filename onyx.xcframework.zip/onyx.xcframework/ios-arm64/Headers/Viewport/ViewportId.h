#ifndef __VIEWPORT_ID_T_H__
#define __VIEWPORT_ID_T_H__

namespace onyx {

    using viewportId_t = int;

}

#endif