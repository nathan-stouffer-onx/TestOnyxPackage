#ifndef __VIEWPORT_ID_T_H__
#define __VIEWPORT_ID_T_H__

#include <string>

namespace onyx {

    // This is only necessary for areas where you want to copy the string, otherwise use viewportId_t.
    // This may also become obsolete if viewportId_t becomes an integer identifier.
    using _viewportId_t = std::string;
    using viewportId_t = _viewportId_t const&;

}

#endif