#pragma once

#include <vector>
#include <map>
#include <array>

#include <bgfx/bgfx.h>

#include <Shaders/v2/Program.h>

#include "Camera/CameraController.h"
#include "Rendering/VertStructs.h"
#include "Viewport/Viewport.h"

namespace onyx
{
	struct PostProcessParams
	{
		union {
			struct {
				gpu_float_t sharpenStrength;
				gpu_float_t reserved1[3];

			};
			lgal::gpu::Vector4 params;
		} sharpen;
		
		union {
			struct {
				gpu_float_t distance;
				gpu_float_t range;
				gpu_float_t reserved;
				gpu_float_t blend;
			};
			lgal::gpu::Vector4 params;
		} depthOfField;

		PostProcessParams(gpu_float_t sharpen_, gpu_float_t dofDist, gpu_float_t dofRange) { sharpen.params = { sharpen_, 0, 0, 0 }; depthOfField.params = { dofDist, dofRange, 3.0, 0.0f }; }
		PostProcessParams() : PostProcessParams(0.0f, 0.5f, 0.01f) { }

		inline bool operator==(PostProcessParams const& rhs)
		{
			return sharpen.params == rhs.sharpen.params
				&& depthOfField.params == rhs.depthOfField.params;
		}

		inline bool operator!=(PostProcessParams const& rhs)
		{
			return !(*this == rhs);
		}
	};

	class ViewportManager
	{
	public:

		// Preset viewport IDs.
		static inline viewportId_t sUnknownViewportId = -1;
		static inline viewportId_t sMainViewportId = 0;
		static inline viewportId_t sPipViewportId = 1;
		// Arbitrary viewports should start counting from here.
		static inline viewportId_t sFirstCustomViewportId = 2;

	public:
		
		ViewportManager();
		~ViewportManager();

		ViewportManager(ViewportManager const& rhs) = delete;
		ViewportManager& operator=(ViewportManager const& rhs) = delete;

		void init(uint32_t w, uint32_t h);
		void shutdown();

		void setScreenSize(uint32_t w, uint32_t h);
		lmath::Vector<uint32_t, 2> getScreenSize() const;

		Viewport *addViewport(viewportId_t viewportId, float wRatio, float hRatio, int sortOrder, Camera::CameraState const& state = { { -11000, -5600.0, 10000.0 } });
		void removeViewport(viewportId_t viewportId);
	
		// TODO (stouff) [CSONYX-204] const functions should return const pointers
		Viewport* operator[](viewportId_t const viewportId) const { return getViewport(viewportId); }
		Viewport* getViewport(viewportId_t viewportId) const;
		Viewport* getViewportByPixel(int x, int y) const;
		Viewport* getViewportByNormalized(lgal::world::Vector2 const& normalizedPos) const;

		void update(double timeMS);
		void drawViewportsToScreen();

		void invalidate();

		std::vector<Viewport*>::const_iterator getSortedViewports() { return mSortableViewports.begin(); }
		std::vector<Viewport*>::const_iterator sortedViewportsEnd() { return mSortableViewports.end(); }

		void setPostProcessParams(PostProcessParams const &params);

	private:

		std::map<viewportId_t, Viewport*> mViewports;
		std::vector<Viewport*> mSortableViewports;

		float viewMat[16] = { 0 };
		float projMat[16] = { 0 };

		uint32_t mScreenWidth = 1280;
		uint32_t mScreenHeight = 720;

		Shaders::Program mBorderProgram;
		Shaders::Program mPostProcessProgram;

		bool mHasSharpen;
		bool mHasDOF;

		std::array<Rendering::VertStructs::PosColorUV, 4> mVertData;
		std::array<uint16_t, 6> mIdxData;

		bgfx::VertexBufferHandle mVertexBuffer = BGFX_INVALID_HANDLE;
		bgfx::IndexBufferHandle mIndexBuffer = BGFX_INVALID_HANDLE;

		PostProcessParams mPostProcess;

		bool mDirtyPrograms = true;

		void assignPrograms();

	};

}