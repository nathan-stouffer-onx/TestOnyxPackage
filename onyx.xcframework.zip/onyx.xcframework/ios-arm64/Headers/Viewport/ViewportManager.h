#ifndef __VIEWPORT_MANAGER_H__
#define __VIEWPORT_MANAGER_H__

#include <vector>
#include <map>
#include <array>

#include <bgfx/bgfx.h>

#include "Camera/CameraController.h"
#include "Rendering/VertStructs.h"
#include "Viewport/Viewport.h"

namespace onyx {

class ViewportManager
{
public:
	// Preset viewport IDs.
	static inline viewportId_t sUnknownViewportId = -1;
	static inline viewportId_t sMainViewportId = 0;
	static inline viewportId_t sPipViewportId = 1;
	// Arbitrary viewports should start counting from here.
	static inline viewportId_t sFirstCustomViewportId = 2;

	static ViewportManager* Instance();
	static void Shutdown();

	void init(uint32_t w, uint32_t h);
	void setScreenSize(uint32_t w, uint32_t h);
	lmath::Vector<uint32_t, 2> getScreenSize() const;

	void addViewport(viewportId_t viewportId, float wRatio, float hRatio, int sortOrder, Camera::CameraState const& state = { { -11000, -5600.0, 10000.0 } });
	void removeViewport(viewportId_t viewportId);
	
	Viewport* getViewport(viewportId_t viewportId) const;
	Viewport* getViewportByPixel(int x, int y) const;
	Viewport* getViewportByNormalized(lgal::world::Vector2 const& normalizedPos) const;
	ViewportState* getViewportStateByNormalized(lgal::world::Vector2 const& normalizedPos) const;

	ViewportState* getViewportState(viewportId_t viewportId) const;

	void updateViewports(double timeMS);
	void drawViewportsToScreen();

	void invalidate();

	std::shared_ptr<Camera::CameraController> getController(int x, int y);
	void setController(int x, int y, std::shared_ptr<Camera::CameraController> controller);

	std::shared_ptr<Camera::CameraController> getController(viewportId_t viewportId);
	void setController(viewportId_t viewportId, std::shared_ptr<Camera::CameraController> controller);

	std::vector<Viewport*>::const_iterator getSortedViewports() { return mSortableViewports.begin(); }
	std::vector<Viewport*>::const_iterator sortedViewportsEnd() { return mSortableViewports.end(); }

private:

	ViewportManager() {}
	~ViewportManager();

	std::map<viewportId_t, Viewport*> mViewports;
	std::vector<Viewport*> mSortableViewports;

	float viewMat[16] = { 0 };
	float projMat[16] = { 0 };

	uint32_t mScreenWidth = 1280;
	uint32_t mScreenHeight = 720;
	std::array<Rendering::VertStructs::PosColorUV, 4> mVertData;
	std::array<uint16_t, 6> mIdxData;

	bgfx::VertexBufferHandle mVertexBuffer = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle mIndexBuffer = BGFX_INVALID_HANDLE;

protected:

	static ViewportManager* sSingleton;

};

}
#endif //_VIEWPORTMANAGER_H_