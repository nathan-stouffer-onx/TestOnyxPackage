#include "ViewportManager.h"

#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>

#include "Utils/BgfxUtils.h"

namespace onyx
{

	ViewportManager::ViewportManager()
	{
		setPostProcessParams(mPostProcess);
	}

	ViewportManager::~ViewportManager()
	{
		shutdown();
	}

	void ViewportManager::shutdown()
	{
		for (auto& [viewportId, vp] : mViewports)
		{
			delete vp;
			vp = nullptr;
		}

		mViewports.clear();

		mQuad.free();

		// destroys the old programs
		mBorderProgram = Shaders::Program();
		mPostProcessProgram = Shaders::Program();
	}

	void ViewportManager::init(uint32_t w, uint32_t h)
	{
		mScreenWidth = w;
		mScreenHeight = h;
		ViewportState::setScreenSize(float(w), float(h));
		mQuad.reset(w, h);
	}

	void ViewportManager::setScreenSize(uint32_t w, uint32_t h)
	{
		if (mScreenWidth != w || mScreenHeight != h)
		{
			mScreenWidth = w;
			mScreenHeight = h;
			ViewportState::setScreenSize(float(w), float(h));

			invalidate();

			mQuad.reset(w, h);

			for (size_t i = 0; i < mSortableViewports.size(); i++)
			{
				auto vp = mSortableViewports[i];
				vp->resize(); //update all the viewports
			}
		}
	}

	lmath::Vector<uint32_t, 2> ViewportManager::getScreenSize() const
	{
		return lmath::Vector<uint32_t, 2>{ mScreenWidth, mScreenHeight };
	}

	Viewport *ViewportManager::addViewport(viewportId_t viewportId, float wRatio, float hRatio, int sortOrder, Camera::CameraState const& state)
	{
		auto vp = new Viewport(viewportId, wRatio, hRatio, state, sortOrder);
		mViewports[viewportId] = vp;
		mSortableViewports.push_back(vp);
	
		//sort by depth, currently only could change when we add another, so only have to sort here
		std::sort(mSortableViewports.begin(), mSortableViewports.end());
		return vp;
	}

	void ViewportManager::removeViewport(viewportId_t viewportId)
	{
		auto found = mViewports.find(viewportId);
		if (found != mViewports.end())
		{
			Viewport* viewport = found->second;
			mSortableViewports.erase(std::remove_if(mSortableViewports.begin(), mSortableViewports.end(), [viewport](Viewport const* lhs) { return lhs == viewport; }), mSortableViewports.end());
			delete viewport;
			mViewports.erase(found);
		}
	}

	Viewport* ViewportManager::getViewport(viewportId_t viewportId) const
	{
		ONYX_DEBUG_ASSERT(mViewports.find(viewportId) != mViewports.end(), "Invalid viewport requested");

		if (mViewports.find(viewportId) == mViewports.end())
			return nullptr;

		return mViewports.at(viewportId);
	}

	Viewport* ViewportManager::getViewportByPixel(int x, int y) const
	{
		for(int i = (int)mSortableViewports.size() - 1; i >= 0; i--)
		{
			auto vp = mSortableViewports[i];
			float px  = vp->getState()->getPosX();
			float px2 = vp->getState()->getPosX() + vp->getWidthPixel();
			float py  = vp->getState()->getPosY();
			float py2 = vp->getState()->getPosY() + vp->getHeightPixel();
			if (x >= px && x <= px2 && y >= py && y <= py2)
				return vp;
		}

		return nullptr;	
	}

	Viewport* ViewportManager::getViewportByNormalized(lgal::world::Vector2 const& normalizedPos) const
	{
		int x = static_cast<int>(((normalizedPos.x + 1.0) / 2.0) * mScreenWidth);
		int y = static_cast<int>(((normalizedPos.y + 1.0) / 2.0) * mScreenHeight);
		return getViewportByPixel(x, y);
	}

	void ViewportManager::invalidate()
	{
		for (auto& kvp : mViewports)
		{
			kvp.second->invalidate();
		}
	}

	void ViewportManager::update(double timeMS)
	{
		for (auto& kvp : mViewports)
		{
			kvp.second->update(timeMS);
		}
	}

	void ViewportManager::drawViewportsToScreen()
	{
		if (mDirtyPrograms)
		{
			assignPrograms();
		}

		LUCID_PROFILE_SCOPE("draw viewports");
		bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);
		bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
		bgfx::setViewClear(renderId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0);
		bgfx::setViewFrameBuffer(renderId, BGFX_INVALID_HANDLE);
		bgfx::setViewTransform(renderId, mQuad.view().data(), mQuad.proj().data());
		bgfx::setViewName(renderId, "Draw Viewports");
		bgfx::touch(renderId);

		bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

		auto dof = mPostProcess.depthOfField;
		static lgal::gpu::Range DOFCutoffRad(lmath::constants::pi<gpu_float_t>() * 0.125f, lmath::constants::pi<gpu_float_t>() * 0.375f);

		for (auto& vp : mSortableViewports)
		{
			if (vp->getState()->hasBorder) // quick little border slapped on
			{
				auto ypos = vp->getState()->getPosY() - 2;
				if (bgfx::getCaps()->originBottomLeft)
				{
					ypos = float(mScreenHeight) - ypos;
				}

				lgal::gpu::Vector2 tl(vp->getState()->getPosX() - 2, ypos);
				lgal::gpu::Vector2 br(tl.x + vp->getWidthPixel() + 4, tl.y + vp->getHeightPixel() + 4);

				mBorderProgram.set("u_Corners", lgal::gpu::Vector4(tl, br));

				// set vertex and index buffer.
				bgfx::setVertexBuffer(0, mQuad.vertexHandle());
				bgfx::setIndexBuffer(mQuad.indexHandle());

				// set render states
				uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_WRITE_A | BGFX_STATE_PT_TRISTRIP;

				bgfx::setState(state);
				bgfx::submit(renderId, mBorderProgram.handle());
			}

			auto ypos = bgfx::getCaps()->originBottomLeft ? float(mScreenHeight) - vp->getState()->getPosY() : vp->getState()->getPosY();
			lgal::gpu::Vector2 tl(vp->getState()->getPosX(), ypos);
			lgal::gpu::Vector2 br(tl.x + vp->getWidthPixel(), tl.y + vp->getHeightPixel());

			mPostProcessProgram.set("u_Corners", lgal::gpu::Vector4(tl, br));

			auto const& camState = vp->getCameraState();
			// Dampen the depth of field effect based on camera pitch
			auto pitchPos = lmath::clamp(gpu_float_t(camState.pitch), DOFCutoffRad.begin, DOFCutoffRad.end) - DOFCutoffRad.begin;
			auto pitchScale = pitchPos / (DOFCutoffRad.end - DOFCutoffRad.begin);
			dof.blend = dof.blend * pitchScale;
			if (mHasDOF) { mPostProcessProgram.set("u_DOFParams", dof.params); }
			if (mHasSharpen) { mPostProcessProgram.set("u_PackedSharpenParams", mPostProcess.sharpen.params); }

			// Set vertex and index buffer.
			bgfx::setVertexBuffer(0, mQuad.vertexHandle());
			bgfx::setIndexBuffer(mQuad.indexHandle());

			auto size = vp->size();
			mPostProcessProgram.set("s_Color", vp->getColorBuffer(), size, false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
			if (mHasDOF) { mPostProcessProgram.set("s_Depth", vp->getDepthBuffer(), size, false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC); }

			uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_WRITE_A | BGFX_STATE_DEPTH_TEST_ALWAYS | BGFX_STATE_PT_TRISTRIP;
			bgfx::setState(state);
			bgfx::submit(renderId, mPostProcessProgram.handle());
		}

		return;
	}

	void ViewportManager::setPostProcessParams(PostProcessParams const& params)
	{
		mPostProcess = params;
		mDirtyPrograms = true;
	}

	void ViewportManager::assignPrograms()
	{
		if (!mBorderProgram.isValid()) { mBorderProgram = Shaders::load(Shaders::Handwritten::cPosColorCorner, false); }

		mHasSharpen = mPostProcess.sharpen.sharpenStrength > 0;
		mHasDOF = mPostProcess.depthOfField.blend > 0;

		Shaders::PostProcess::Options options{ mHasSharpen, mHasDOF };
		mPostProcessProgram = Shaders::load(options);

		mDirtyPrograms = false;
	}
}
