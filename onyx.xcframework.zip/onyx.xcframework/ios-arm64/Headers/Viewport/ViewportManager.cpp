#include "ViewportManager.h"

#include "Utils/BgfxUtils.h"

namespace onyx
{

	ViewportManager::ViewportManager()
	{
		setPostProcessParams(mPostProcess);
	}

	ViewportManager::~ViewportManager()
	{
		shutdown();
	}

	void ViewportManager::shutdown()
	{
		for (auto& [viewportId, vp] : mViewports)
		{
			delete vp;
			vp = nullptr;
		}

		mViewports.clear();

		BgfxUtils::tryDestroy(mVertexBuffer);
		BgfxUtils::tryDestroy(mIndexBuffer);
	}

	void ViewportManager::init(uint32_t w, uint32_t h)
	{
		mScreenWidth = w;
		mScreenHeight = h;
		ViewportState::setScreenSize(float(w), float(h));

		bx::mtxLookAt(viewMat, bx::Vec3(0,0,10), bx::Vec3(0,0,0), bx::Vec3(0,1,0));
		if (bgfx::getCaps()->originBottomLeft)
		{
			bx::mtxOrtho(projMat, 0, -float(mScreenWidth), 0, float(mScreenHeight), 0.01f, 20, 0, false);
		
			// subtract 1 from y coord so position specifies the top left corner
			mVertData[0] = Rendering::VertStructs::PosColorUV(0, 0 - 1, 0, 0xFFFFFFFF, 0, 0);
			mVertData[1] = Rendering::VertStructs::PosColorUV(0, 1 - 1, 0, 0xFFFFFFFF, 0, 1);
			mVertData[2] = Rendering::VertStructs::PosColorUV(1, 1 - 1, 0, 0xFFFFFFFF, 1, 1);
			mVertData[3] = Rendering::VertStructs::PosColorUV(1, 0 - 1, 0, 0xFFFFFFFF, 1, 0);
		}
		else
		{
			bx::mtxOrtho(projMat, 0, -float(mScreenWidth), float(mScreenHeight), 0, 0.01f, 20, 0, false);

			mVertData[0] = Rendering::VertStructs::PosColorUV(0, 0, 0, 0xFFFFFFFF, 0, 0);
			mVertData[1] = Rendering::VertStructs::PosColorUV(0, 1, 0, 0xFFFFFFFF, 0, 1);
			mVertData[2] = Rendering::VertStructs::PosColorUV(1, 1, 0, 0xFFFFFFFF, 1, 1);
			mVertData[3] = Rendering::VertStructs::PosColorUV(1, 0, 0, 0xFFFFFFFF, 1, 0);
		}

		mIdxData[0] = 0;
		mIdxData[1] = 1;
		mIdxData[2] = 2;
		mIdxData[3] = 0;
		mIdxData[4] = 2;
		mIdxData[5] = 3;

		// create static vertex buffer
		mVertexBuffer = bgfx::createVertexBuffer(
			// static data can be passed with bgfx::makeRef
			bgfx::makeRef(mVertData.data(), (uint32_t)(sizeof(Rendering::VertStructs::PosColorUV) * mVertData.size()))
			, Rendering::VertStructs::PosColorUV::ms_layout
		);
		bgfx::setName(mVertexBuffer, "ViewportManagerVerts");

		// create static index buffer
		mIndexBuffer = bgfx::createIndexBuffer(
			// static data can be passed with bgfx::makeRef
			bgfx::makeRef(mIdxData.data(), (uint32_t)(sizeof(uint16_t) * mIdxData.size()))
		);
		bgfx::setName(mIndexBuffer, "ViewportManagerIndices");
	}

	void ViewportManager::setScreenSize(uint32_t w, uint32_t h)
	{
		if (mScreenWidth != w || mScreenHeight != h)
		{
			mScreenWidth = w;
			mScreenHeight = h;
			ViewportState::setScreenSize(float(w), float(h));

			invalidate();

			if (bgfx::getCaps()->originBottomLeft)
			{
				bx::mtxOrtho(projMat, 0, -float(mScreenWidth), 0, float(mScreenHeight), 0.01f, 20, 0, false);
			}
			else
			{
				bx::mtxOrtho(projMat, 0, -float(mScreenWidth), float(mScreenHeight), 0, 0.01f, 20, 0, false);
			}
		
			for (size_t i = 0; i < mSortableViewports.size(); i++)
			{
				auto vp = mSortableViewports[i];
				vp->resize(); //update all the viewports
			}
		}
	}

	lmath::Vector<uint32_t, 2> ViewportManager::getScreenSize() const
	{
		return lmath::Vector<uint32_t, 2>{ mScreenWidth, mScreenHeight };
	}

	Viewport *ViewportManager::addViewport(viewportId_t viewportId, float wRatio, float hRatio, int sortOrder, Camera::CameraState const& state)
	{
		auto vp = new Viewport(viewportId, wRatio, hRatio, state, sortOrder);
		mViewports[viewportId] = vp;
		mSortableViewports.push_back(vp);
	
		//sort by depth, currently only could change when we add another, so only have to sort here
		std::sort(mSortableViewports.begin(), mSortableViewports.end());
		return vp;
	}

	void ViewportManager::removeViewport(viewportId_t viewportId)
	{
		for (size_t i = 0; i < mSortableViewports.size(); i++)
		{
			if (mSortableViewports[i] == mViewports[viewportId])
			{
				mSortableViewports.erase(mSortableViewports.begin() + i);
			}
		}

		mViewports.erase(viewportId);
	}

	Viewport* ViewportManager::getViewport(viewportId_t viewportId) const
	{
		if (mViewports.find(viewportId) == mViewports.end())
			return nullptr;

		return mViewports.at(viewportId);
	}

	Viewport* ViewportManager::getViewportByPixel(int x, int y) const
	{
		for(int i = (int)mSortableViewports.size() - 1; i >= 0; i--)
		{
			auto vp = mSortableViewports[i];
			float px  = vp->getState()->getPosX();
			float px2 = vp->getState()->getPosX() + vp->getWidthPixel();
			float py  = vp->getState()->getPosY();
			float py2 = vp->getState()->getPosY() + vp->getHeightPixel();
			if (x >= px && x <= px2 && y >= py && y <= py2)
				return vp;
		}

		return nullptr;	
	}

	Viewport* ViewportManager::getViewportByNormalized(lgal::world::Vector2 const& normalizedPos) const
	{
		int x = static_cast<int>(((normalizedPos.x + 1.0) / 2.0) * mScreenWidth);
		int y = static_cast<int>(((normalizedPos.y + 1.0) / 2.0) * mScreenHeight);
		return getViewportByPixel(x, y);
	}

	void ViewportManager::invalidate()
	{
		for (auto& kvp : mViewports)
		{
			kvp.second->invalidate();
		}
	}

	void ViewportManager::update(double timeMS)
	{
		for (auto& kvp : mViewports)
		{
			kvp.second->render(timeMS);
		}

		// get depth
		bgfx::ViewId depthViewId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);
		for (auto& kvp : mViewports)
		{
			kvp.second->readDepth(depthViewId); //TODO - add a dirty flag so only the ones that need to update
		}
	}

	void ViewportManager::drawViewportsToScreen()
	{
		if (mDirtyShader)
		{
			assignShader();
		}

		LUCID_PROFILE_SCOPE("draw viewports");
		bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Types::Composite);
		bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
		bgfx::setViewClear(renderId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0);
		bgfx::setViewFrameBuffer(renderId, BGFX_INVALID_HANDLE);
		bgfx::setViewTransform(renderId, viewMat, projMat);
		bgfx::setViewName(renderId, "Draw Viewports");
		bgfx::touch(renderId);

		bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::ViewportBlit, 0);
		shader->setParameter("u_SharpenStrength", mPostProcess.sharpen.params);
		auto dof = mPostProcess.depthOfField;
		static lgal::gpu::Range DOFCutoffRad(lmath::constants::pi<gpu_float_t>() * 0.125f, lmath::constants::pi<gpu_float_t>() * 0.375f);
		shader->setParameter("u_time", lgal::gpu::Vector3(gpu_float_t(rand()) / 1000.f, 0, 0));
		shader->setParameter("u_BackgroundColor", lgal::Color(0xFF000000));

		for (auto& vp : mSortableViewports)
		{
			auto const &camState = vp->getCameraState();
			shader->setParameter("u_CameraParams", lgal::gpu::Vector4(gpu_float_t(camState.nearClip), gpu_float_t(camState.farClip), 0, 0));

			// Dampen the depth of field effect based on camera pitch
			auto pitchPos = lmath::clamp(gpu_float_t(camState.pitch), DOFCutoffRad.begin, DOFCutoffRad.end) - DOFCutoffRad.begin;
			auto pitchScale = pitchPos / (DOFCutoffRad.end - DOFCutoffRad.begin);
			dof.blend = dof.blend * pitchScale;
			shader->setParameter("u_DOFParams", dof.params);

			if (vp->getState()->hasBorder) //quick little border slapped on
			{
				auto ypos = vp->getState()->getPosY() - 2;
				if (bgfx::getCaps()->originBottomLeft)
				{
					ypos = float(mScreenHeight) - ypos;
				}

				lgal::gpu::Vector3 tileMin(vp->getState()->getPosX() - 2, ypos, 0);
				lgal::gpu::Vector3 tileMax(tileMin.x + vp->getWidthPixel() + 4, tileMin.y + vp->getHeightPixel() + 4, 0.0);

				shader->setParameter("u_tileMin", tileMin);
				shader->setParameter("u_tileMax", tileMax);

				// Set vertex and index buffer.
				bgfx::setVertexBuffer(0, mVertexBuffer);
				bgfx::setIndexBuffer(mIndexBuffer);

				// Set render states - maybe should do this higher up?.
				uint64_t state = 0;
				state = 0
					| BGFX_STATE_WRITE_R
					| BGFX_STATE_WRITE_G
					| BGFX_STATE_WRITE_B
					| BGFX_STATE_WRITE_A;

				bgfx::setState(state | BGFX_STATE_PT_TRISTRIP);
				bgfx::submit(renderId, ShaderManager::Instance()->getShaderHandle("PosColor"));
			}

			auto ypos = bgfx::getCaps()->originBottomLeft ? float(mScreenHeight) - vp->getState()->getPosY() : vp->getState()->getPosY();

			lgal::gpu::Vector3 tileMin(vp->getState()->getPosX(), ypos, 0);
			lgal::gpu::Vector3 tileMax(tileMin.x + vp->getWidthPixel(), tileMin.y + vp->getHeightPixel(), 0.0);

			shader->setParameter("u_tileMin", tileMin);
			shader->setParameter("u_tileMax", tileMax);
			shader->setParameter("u_OpacityTex0", 1.f);

			// Set vertex and index buffer.
			bgfx::setVertexBuffer(0, mVertexBuffer);
			bgfx::setIndexBuffer(mIndexBuffer);

			auto size = vp->size();
			shader->setParameter("s_FrameTexture", vp->getTexture(), size);
			shader->setParameter("s_DepthTexture", vp->getDepthBuffer(), size);

			// Set render states - maybe should do this higher up?.
			uint64_t state = 0;
			state = 0
				| BGFX_STATE_WRITE_R
				| BGFX_STATE_WRITE_G
				| BGFX_STATE_WRITE_B
				| BGFX_STATE_WRITE_A
				| BGFX_STATE_DEPTH_TEST_ALWAYS;

			bgfx::setState(state | BGFX_STATE_PT_TRISTRIP);
			bgfx::submit(renderId, ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::ViewportBlit, 0)->programHandle);
		}

		return;
	}

	void ViewportManager::setPostProcessParams(PostProcessParams const& params)
	{
		mPostProcess = params;
		mDirtyShader = true;
	}

	void ViewportManager::assignShader()
	{
		bool hasSharpen = mPostProcess.sharpen.sharpenStrength > 0;
		bool hasDOF = mPostProcess.depthOfField.blend > 0;

		// enable/disable components; we need a way to atomize or batch these up so that ordering is unnecessary.
		if (hasDOF)
		{
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "Blit", false);
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "Sharpen", false);
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "DOF", true);
		}
		else if (hasSharpen)
		{
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "Blit", false);
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "DOF", false);
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "Sharpen", true);
		}
		else
		{
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "DOF", false);
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "Sharpen", false);
			ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::ViewportBlit, "Blit", true);
		}

		mDirtyShader = false;
	}
}
