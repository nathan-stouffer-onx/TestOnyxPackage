#ifndef PICKER_H_
#define PICKER_H_

#include <lucid/gal/Types.h>
#include <Styling/Layers/Layer.h>

#include "FeatureId.h"
#include "Utils/MapMath.h"
#include "ViewportId.h"

namespace onyx::Picking
{
	constexpr input_float_t cDefaultRange = 0.01;

	std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, MapMath::LonLat const & globePos, char const* layerName, input_float_t radius);
	std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, MapMath::LonLatElevation const& globePos, char const* layerName, input_float_t radius);
	std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, lgal::input::Vector2 screenPos, char const* layerName, input_float_t radius);
	std::vector<FeatureId> queryRenderedFeatures(viewportId_t id, lgal::input::Vector2 screenPos, input_float_t radius, Styling::Layer::Types layerTypes = Styling::Layer::Types::ALL);

}
#endif