#ifndef PICKER_H_
#define PICKER_H_

#include <lucid/gal/Types.h>

#include "FeatureId.h"
#include "ViewportId.h"


namespace onyx::Picking
{
	constexpr input_float_t cDefaultRange = 0.01;

	std::vector<FeatureId> queryFeatures(viewportId_t vs, lgal::input::Vector2 pos, input_float_t radius);

}
#endif