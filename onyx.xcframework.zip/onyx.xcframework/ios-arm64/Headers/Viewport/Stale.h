#pragma once

#include <lucid/gal/Types.h>

#include <Utils/BitwiseEnumOperators.h>
#include <Utils/EnumUtils.h>

namespace onyx
{
	enum class Stale : uint64_t
	{
		NONE					= 0x00000,
		FORCE					= 0x00001,
		CAMERA					= 0x00002,
		ZOOM					= 0x00004,
		STYLE					= 0x00008,
		TERRAIN					= 0x00010,
		TILE_CACHE				= 0x00020,
		LAYER_CACHE				= 0x00040,
		ANIMATIONS				= 0x00080,
		ALL						= 0x000FF,
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(Stale);

}

namespace std
{
	template<>
	inline onyx::Stale fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Stale> const nameMap =
		{
			{ "none",					onyx::Stale::NONE			},
			{ "force",					onyx::Stale::FORCE			},
			{ "camera",					onyx::Stale::CAMERA			},
			{ "zoom",					onyx::Stale::ZOOM			},
			{ "style",					onyx::Stale::STYLE			},
			{ "terrain",				onyx::Stale::TERRAIN		},
			{ "tile-cache",				onyx::Stale::TILE_CACHE		},
			{ "layer-cache",			onyx::Stale::LAYER_CACHE	},
			{ "animations",				onyx::Stale::ANIMATIONS		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum onyx::Stale");
	}

	inline std::string_view toStringView(onyx::Stale value)
	{
		static std::unordered_map<onyx::Stale, std::string_view> const nameMap =
		{
			{ onyx::Stale::NONE,				"none"				},
			{ onyx::Stale::FORCE,				"force"				},
			{ onyx::Stale::CAMERA,				"camera"			},
			{ onyx::Stale::ZOOM,				"zoom"				},
			{ onyx::Stale::STYLE,				"style"				},
			{ onyx::Stale::TERRAIN,				"terrain"			},
			{ onyx::Stale::TILE_CACHE,			"tile-cache"		},
			{ onyx::Stale::LAYER_CACHE,			"layer-cache"		},
			{ onyx::Stale::ANIMATIONS,			"animations"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum onyx::Stale");
	}
}