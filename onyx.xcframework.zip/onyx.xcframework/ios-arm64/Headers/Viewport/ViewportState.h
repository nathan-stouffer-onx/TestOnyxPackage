#pragma once

#include <vector>

#include <lucid/gal/Types.h>

#include <lucid/gigl/Context.h>

#include "Symbol/SymbolCollection.h"
#include "Rendering/VertStructs.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/property.h"
#include "Experimental/Updater.h"

namespace onyx
{

	class ViewportState
	{
	public:

		typedef lmath::Range<Tiles::TileId::IdCoordsT> tileRangeT;
		typedef std::shared_ptr<lucid::gigl::Context> sharedContextT;

		struct RenderStats
		{
			size_t renderedLineInstances = 0,
				skippedLineInstances = 0;

			void reset()
			{
				renderedLineInstances = 0;
				skippedLineInstances = 0;
			}

			void operator+=(RenderStats const& rhs)
			{
				renderedLineInstances += rhs.renderedLineInstances;
				skippedLineInstances += rhs.skippedLineInstances;
			}

			bool operator==(RenderStats const& rhs)
			{
				return renderedLineInstances == rhs.renderedLineInstances 
					&& skippedLineInstances == rhs.skippedLineInstances;
			}
		};

		static float sScreenWidth;
		static float sScreenHeight;
		static void setScreenSize(float width, float height)
		{
			sScreenWidth = width;
			sScreenHeight = height;
		}

		ViewportState();
		ViewportState(float wRatio, float hRatio, int sortOrder);

		// TODO possibly get rid of the scaling in the viewports
		float getAspect() { return getWidthPixel() / getHeightPixel(); }
		float getWidthPixel() const { return mWidthRatio * sScreenWidth; }
		float getHeightPixel() const { return mHeightRatio * sScreenHeight; }
	
		// TODO move this to somewhere else?
		// function to convert global input coordinates to coordinates this viewport understands
		lgal::world::Vector2 convertGlobalToViewportCoords(lgal::world::Vector2 const& globalNormalizedCoords) const;

		bool hasBorder = false; //temp hacky bit to add an outline
	
		RenderStats mFrameRenderStats = RenderStats();
		RenderStats mLifetimeRenderStats = RenderStats();

		GET_SET_PROP(CullingEnabled, bool, true);
		GET_SET_PROP(IsDirty, bool, true);
		GET_SET_PROP(LODScaler, float, 1.0f);
		GET_SET_PROP(MaxLabelsPerTile, uint32_t, 10);
		GET_SET_PROP(QuiescenceMode, bool,  true);
		GET_SET_PROP(ShowScreenSpaceManager, bool, false);
		GET_SET_PROP(ShowFrustum, bool, false);
		GET_SET_PROP(ShowTileBoxes, bool, false);
		GET_SET_PROP(TileBoxOpacity, float, 0.f);
		GET_SET_PROP(TileZoomRange, tileRangeT, tileRangeT(0, 24));
		GET_SET_PROP(VectorFadeTime, time_float_t, Tiles::VectorInfo::DefaultFadeTime);
		GET_SET_PROP(VectorPulseTimeMS, float32_t, 750);
		GET_SET_PROP(VectorPulseDelayMS, float32_t, 2000);
		
		GET_SET_PROP(ShowFills, bool, true);
		GET_SET_PROP(ShowLines, bool, true);
		GET_SET_PROP(ShowRasters, bool, true);
		GET_SET_PROP(ShowSymbols, bool, true);
		
		GET_SET_PROP(SkyColor, lgal::Color, lgal::Color(0.52f, 0.65f, 0.85f, 1.0f));
		GET_SET_PROP(HazeColor, lgal::Color, lgal::Color(0.7f, 0.8f, 0.91f, 1.0f));
		
		GET_SET_PROP(HeightRatio, float, 1);
		GET_SET_PROP(WidthRatio, float, 1);
		GET_SET_PROP(PosX, float, 0);
		GET_SET_PROP(PosY, float, 0);
		GET_SET_PROP(SortOrder, int, 0); // higher numbers on top, lower behind
		GET_SET_PROP(DpiScalar, float, 1.f);
		GET_SET_PROP(SpritesheetSize, int, 1);

		GET_PROP(Context, sharedContextT, nullptr);	

		void propertyChanged(const char* propName);
		void invalidate();

		template <typename T>
		inline void setContext(std::string const& key, T value)
		{
			mContext->set(key, value);
		}

		template <typename T>
		inline T getContext(std::string const& key) const
		{
			return mContext->lookup(key).as<T>();
		}

		Symbol::SymbolCollection mSymbolCollection;	// TODO move this to Viewport -- will be a little tricky because some things access this directly

		void clearScreenLines() { mScreenLines.clear(); }
		void clearScreenLines(std::string const &style)
		{
			auto iter = mScreenLines.find(style);
			if (iter == mScreenLines.end())
			{
				return;
			}

			iter->second.clear();
		}

		template <typename T>
		void addScreenLines(std::string style, T const& lines)
		{
			auto iter = mScreenLines.find(style);
			if (iter == mScreenLines.end())
			{
				mScreenLines.emplace(style, std::vector<Rendering::VertStructs::ScreenLineData>());
				iter = mScreenLines.find(style);
			}

			iter->second.insert(iter->second.end(), std::begin(lines), std::end(lines));
		}

		void addScreenLine(std::string style, Rendering::VertStructs::ScreenLineData const& line)
		{
			auto iter = mScreenLines.find(style);
			if (iter == mScreenLines.end())
			{
				mScreenLines.emplace(style, std::vector<Rendering::VertStructs::ScreenLineData>());
				iter = mScreenLines.find(style);
			}

			iter->second.push_back(line);
		}

		std::unordered_map<std::string, std::vector<Rendering::VertStructs::ScreenLineData>> const& getScreenLines() const { return mScreenLines; }

		std::vector<std::weak_ptr<Experimental::IUpdater>> mUpdaters;
	private:

		std::unordered_map<std::string, std::vector<Rendering::VertStructs::ScreenLineData>> mScreenLines;	// TODO move this to Viewport?

	};

}