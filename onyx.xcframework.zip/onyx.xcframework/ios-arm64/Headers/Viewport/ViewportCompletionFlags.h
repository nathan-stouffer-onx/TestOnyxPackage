#pragma once

#include <lucid/gal/Types.h>

#include <Utils/BitwiseEnumOperators.h>
#include <Utils/EnumUtils.h>

namespace onyx
{
	enum class ViewportCompletionFlags : uint64_t
	{
		NONE				= 0x00000,
		PREPARE_RASTERS		= 0x00001,
		PREPARE_LINES		= 0x00002,
		PREPARE_FILLS		= 0x00004,
		PREPARE_SYMBOLS		= 0x00008,
		PREPARE_CONTOURS	= 0x00010,
		GATHER_SYMBOLS		= 0x00020,
		DRAW_SYMBOLS		= 0x00040,
		PRECACHE			= 0x00080,
		PRECACHE_PARENTS	= 0x00100,
		CAMERA				= 0x00200,
		CACHE_UPDATE		= 0x00400,
		INVALIDATED			= 0x00800,
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(ViewportCompletionFlags);

static constexpr ViewportCompletionFlags cAllCompletionFlags = ViewportCompletionFlags(0xFFF);
static constexpr ViewportCompletionFlags cAllPrepareFlags = ViewportCompletionFlags(0x1F);
static constexpr ViewportCompletionFlags cVectorPrepareFlags = ViewportCompletionFlags(0x1E);
}

namespace std
{
	template<>
	inline onyx::ViewportCompletionFlags fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::ViewportCompletionFlags> const nameMap =
		{
			{ "none",						onyx::ViewportCompletionFlags::NONE				},
			{ "prepareRasters",				onyx::ViewportCompletionFlags::PREPARE_RASTERS	},
			{ "prepareLines",				onyx::ViewportCompletionFlags::PREPARE_LINES	},
			{ "prepareFills",				onyx::ViewportCompletionFlags::PREPARE_FILLS	},
			{ "prepareSymbols",				onyx::ViewportCompletionFlags::PREPARE_SYMBOLS	},
			{ "prepareContours",			onyx::ViewportCompletionFlags::PREPARE_CONTOURS	},
			{ "gatherSymbols",				onyx::ViewportCompletionFlags::GATHER_SYMBOLS	},
			{ "drawSymbols",				onyx::ViewportCompletionFlags::DRAW_SYMBOLS		},
			{ "precache",					onyx::ViewportCompletionFlags::PRECACHE			},
			{ "precacheParents",			onyx::ViewportCompletionFlags::PRECACHE_PARENTS	},
			{ "camera",						onyx::ViewportCompletionFlags::CAMERA			},
			{ "cacheUpdate",				onyx::ViewportCompletionFlags::CACHE_UPDATE		},
			{ "invalidated",				onyx::ViewportCompletionFlags::INVALIDATED		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum onyx::ViewportCompletionFlags");
	}

	inline std::string_view toStringView(onyx::ViewportCompletionFlags value)
	{
		static std::unordered_map<onyx::ViewportCompletionFlags, std::string_view> const nameMap =
		{
			{ onyx::ViewportCompletionFlags::NONE,				"none"				},
			{ onyx::ViewportCompletionFlags::PREPARE_RASTERS,	"prepareRasters"	},
			{ onyx::ViewportCompletionFlags::PREPARE_LINES,		"prepareLines"		},
			{ onyx::ViewportCompletionFlags::PREPARE_FILLS,		"prepareFills"		},
			{ onyx::ViewportCompletionFlags::PREPARE_SYMBOLS,	"prepareSymbols"	},
			{ onyx::ViewportCompletionFlags::PREPARE_CONTOURS,	"prepareContours"	},
			{ onyx::ViewportCompletionFlags::GATHER_SYMBOLS,	"gatherSymbols"		},
			{ onyx::ViewportCompletionFlags::DRAW_SYMBOLS,		"drawSymbols"		},
			{ onyx::ViewportCompletionFlags::PRECACHE,			"precache"			},
			{ onyx::ViewportCompletionFlags::PRECACHE_PARENTS,	"precacheParents"	},
			{ onyx::ViewportCompletionFlags::CAMERA,			"camera"			},
			{ onyx::ViewportCompletionFlags::CACHE_UPDATE,		"cacheUpdate"		},
			{ onyx::ViewportCompletionFlags::INVALIDATED,		"invalidated"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum onyx::ViewportCompletionFlags");
	}
}