#include "ViewportState.h"

namespace onyx
{

	float ViewportState::sScreenWidth = 1280.f;
	float ViewportState::sScreenHeight = 720.f;

	ViewportState::ViewportState() : ViewportState(1, 1, 0) {}

	ViewportState::ViewportState(float wRatio, float hRatio, int sortOrder) :
		mHeightRatio(hRatio),
		mWidthRatio(wRatio),
		mPosX(0),
		mPosY(0),
		mSortOrder(sortOrder),
		mContext(std::make_shared<lucid::gigl::Context>())
	{}

	void ViewportState::propertyChanged(const char*)
	{
		invalidate();
	}

	void ViewportState::invalidate()
	{
		mIsDirty = true;
	}

	lgal::world::Vector2 ViewportState::convertGlobalToViewportCoords(lgal::world::Vector2 const& globalNormalizedCoords) const
	{
		int pixX = static_cast<int>(((globalNormalizedCoords.x + 1.0) / 2.0) * ViewportState::sScreenWidth);
		int pixY = static_cast<int>(((globalNormalizedCoords.y + 1.0) / 2.0) * ViewportState::sScreenHeight);

		int minX = (int)mPosX;
		int maxX = (int)(mPosX + getWidthPixel());
		int minY = (int)mPosY;
		int maxY = (int)(mPosY + getHeightPixel());

		float x = static_cast<float>(pixX - minX) / static_cast<float>(maxX - minX);
		float y = static_cast<float>(pixY - minY) / static_cast<float>(maxY - minY);

		x = (x * 2.f) - 1.f;
		y = (y * 2.f) - 1.f;

		return { x, y };
	}

}
