#include "ViewportState.h"
#include "Height/HeightManager.h"

namespace onyx {

	float ViewportState::sScreenWidth = 1280.f;
	float ViewportState::sScreenHeight = 720.f;

	ViewportState::ViewportState() : ViewportState(sUnknownViewportId, 1, 1, mRenderCameraState, 0)
	{
	}

	ViewportState::ViewportState(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
		mId(viewportId),
		mWidthRatio(wRatio),
		mHeightRatio(hRatio),
		mPosX(0),
		mPosY(0),
		mSortOrder(sortOrder),
		mTileLoadTimeMS(Utils::Timer::nowMS(), 0.0),
		mSpriteAtlas(Atlases::cRenderFlags, Atlases::cDefaultCellSize, Atlases::cDefaultResolution, 0),
		mContext(std::make_shared<lucid::gigl::Context>()),
		mRenderCameraState(state),
		mCullCameraState(state),
		mController(std::make_shared<Camera::Controllers::Identity>())
	{
		mRenderCameraState.aspect = getAspect();
		mCullCameraState.aspect = getAspect();
	}

	float ViewportState::depthAtPixel(int screenX, int screenY) const
	{
		auto depthData = (uint8_t*)mDepthData.data();
		size_t y = size_t(screenY);
		if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
		{
			y = size_t(getHeightPixel()) - 1 - y;
		}
		auto depthIndex = (size_t(screenX) + (y * size_t(getWidthPixel()))) * 4;
		if (depthIndex < mDepthData.size())
		{
			auto r = depthData[depthIndex] * (1.f / 255.f);
			auto g = depthData[depthIndex + 1] * (1.f / 255.f);
			auto b = depthData[depthIndex + 2] * (1.f / 255.f);
			auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
			return result;
		}
		return -1;
	}

	float ViewportState::depthAtNormalized(lgal::world::Vector2 const& normalizedScreen) const
	{
		int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * getWidthPixel());
		int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * getHeightPixel());
		return depthAtPixel(x, y);
	}

	lgal::world::Vector3 ViewportState::unprojectPixel(int screenX, int screenY) const
	{
		auto depth = depthAtPixel(screenX, screenY) * 2.0f - 1.0f;
		float x = (screenX / getWidthPixel()) * 2.0f - 1.0f;
		float y = (screenY / getHeightPixel()) * 2.0f - 1.0f;
		lgal::world::Vector3 normalizedCoords = { x, y, depth };
		return unprojectNormalized(normalizedCoords);
	}

	lgal::world::Vector3 ViewportState::unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const
	{
		int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * getWidthPixel());
		int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * getHeightPixel());
		return unprojectPixel(x, y);
	}

	// TODO change architecture so that the unprojected point is more accurate
	// the height discrepancy is really off when the camera is zoomed out
	lgal::world::Vector3 ViewportState::unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const
	{
		Camera::CameraState::ProjectionData unprojected = mRenderCameraState.unproject(normalizedPos);

		lgal::world::Vector3 result = unprojected.position;

		// override z with a more accurate value
		auto heightKm = HeightManager::Instance()->heightAt({ result.x, result.y });
		result.z = heightKm;

		return result;
	}

	lgal::world::Vector3 ViewportState::project(lgal::world::Vector3 const& pos) const
	{
		Camera::CameraState::ProjectionData projected = mRenderCameraState.project(pos);
		return projected.position;
	}

	lgal::world::Vector2 ViewportState::convertGlobalToViewportCoords(lgal::world::Vector2 const& globalNormalizedCoords) const
	{
		int pixX = static_cast<int>(((globalNormalizedCoords.x + 1.0) / 2.0) * ViewportState::sScreenWidth);
		int pixY = static_cast<int>(((globalNormalizedCoords.y + 1.0) / 2.0) * ViewportState::sScreenHeight);

		int minX = (int)mPosX;
		int maxX = (int)(mPosX + getWidthPixel());
		int minY = (int)mPosY;
		int maxY = (int)(mPosY + getHeightPixel());

		float x = static_cast<float>(pixX - minX) / static_cast<float>(maxX - minX);
		float y = static_cast<float>(pixY - minY) / static_cast<float>(maxY - minY);

		x = (x * 2.f) - 1.f;
		y = (y * 2.f) - 1.f;

		return { x, y };
	}

}
