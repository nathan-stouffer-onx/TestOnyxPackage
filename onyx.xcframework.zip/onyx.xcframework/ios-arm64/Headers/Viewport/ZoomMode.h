#pragma once

namespace onyx
{

	enum class ZoomMode
	{
		GRID,
		CENTER,
	};

}