#pragma once

#include <string>

#include <Utils/UUID.h>
#include <Styling/Types.h>

#include "Vector/Feature.h"

namespace onyx::Picking
{
	struct FeatureId
	{
		std::string sourceId;
		Styling::Feature feature;
		Vector::SharedFeatureT data;
	};

	inline bool operator==(FeatureId const& lhs, FeatureId const& rhs)
	{
		return lhs.sourceId == rhs.sourceId
			&& lhs.feature == rhs.feature;
	}
}