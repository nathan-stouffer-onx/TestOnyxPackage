#pragma once

#include <memory>
#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ConfigurableShader.h>
#include <Styling/Style.h>

#include "Caching/Layers/LayerCache.h"
#include "Caching/Tiles/TileCache.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "DataObjects/SymbolManager.h"
#include "DataObjects/MapLabel.h"
#include "DataObjects/Symbol/MapSymbol.h"
#include "Drawers/Skydome.h"
#include "Pyramid/Culling.h"
#include "Rendering/VectorLineMesh.h"
#include "TerrainEffects/ContourLine.h"
#include "TerrainEffects/Shading/ElevationShade.h"
#include "TerrainEffects/Shading/IntersectShade.h"
#include "TerrainEffects/Shading/SlopeAngleShade.h"
#include "TerrainEffects/Shading/SlopeAspectShade.h"
#include "TerrainEffects/SunShadow.h"
#include "TerrainEffects/Viewshed.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/property.h"
#include "Utils/TripleBuffer.h"
#include "Viewport/ViewportState.h"

namespace onyx {

typedef lucid::math::Range<Tiles::TileId::IdCoordsT> tileRangeT;
typedef std::vector<Rendering::VertStructs::ScreenLineData> screenLineVector_t;

// TODO (scott) fill this out with other visible features (vectors, etc)
struct VisibleFeatures
{
	Pyramid::CullResult cullState;
};

class Viewport
{
public:

	Viewport()
	{
		mLineMesh.reset(new Rendering::VectorLineMesh());
	}

	Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder = 0);
	~Viewport();
	
	void render(double timeMS);
	void readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue = 0);
	void readColor(std::vector<uint8_t>& target, uint8_t defaultValue);
	void readDepth(std::vector<uint8_t>& target);
	bgfx::TextureHandle getTexture();

	void resize();

	void setController(std::shared_ptr<Camera::CameraController> controller);

	// TODO possibly get rid of the scaling in the viewports
	float getAspect() { return mViewportState.getAspect(); }

	float getWidthPixel() const { return mViewportState.getWidthPixel(); }
	float getHeightPixel() const { return mViewportState.getHeightPixel(); }

	lgal::screen::Vector2 size() const { return { screen_coord_t(mViewportState.getWidthPixel()), screen_coord_t(mViewportState.getHeightPixel()) }; }

	void setTileLod(float lod) { mViewportState.setLODScaler(lod); }

	bool operator<(Viewport& comp)
	{
		return mViewportState.getSortOrder() < comp.getState()->getSortOrder();
	}

	gpu_float_t depthAtPixel(int screenX, int screenY) const;
	gpu_float_t depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectPixel(int screenX, int screenY) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const;
	lgal::world::Vector3 project(lgal::world::Vector2 const& pos) const;
	lgal::world::Vector3 project(lgal::world::Vector3 const& pos) const;

	void setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration);
	void setCameraState(Camera::CameraState const& state);
	void setCameraState(Camera::CameraState const& render, Camera::CameraState const& cull);
	Camera::CameraState const& getCameraState() const { return mViewportState.mRenderCameraState; }

	void invalidate();
	DataObjects::SymbolManager* getSymbolManager() { return mSymbolManager.get(); }

	inline double tileLoadTimeMS() const { return mViewportState.getTileLoadTimeMS().end - mViewportState.getTileLoadTimeMS().begin; }

	ViewportState* getState() { return &mViewportState; }
	ViewportState const * getState() const { return (ViewportState const *)&mViewportState; }

	std::shared_ptr<Styling::Style> getStyle() const { return mStyle; }
	void setStyle(std::shared_ptr<Styling::Style> style);
	
	std::shared_ptr<Caching::LayerCache const> getLayerCache() const { return mLayerCache; }

	// Returns a non-owning const* meant for exposing debug info
	TerrainEffects::TerrainEffectBase const* getTerrainEffect(std::string const& id) const
	{
		auto found = mTerrainEffects.find(id);
		return (found == mTerrainEffects.end()) ? nullptr : found->second.get();
	}

	template <typename T>
	void setContext(std::string const& key, T value)
	{
		mViewportState.setContext(key, value);
	}

	template <typename T>
	T getContext(std::string const& key) const
	{
		return mViewportState.getContext<T>(key);
	}

	bool hasIconImg(std::string id);
	inline size_t getNumRenderedIcons() const { return mSymbolManager->getNumRenderedIcons(); }
	bool addIconImg(std::string id, std::string url);
	void compositeImages(std::string id, std::vector<std::string> const& filePaths);
	
	//keeping in sync with viewportstate for the moment, for easy flowthrough as needed
	GET_SET_CHILD(mViewportState, CullingEnabled, bool);
	GET_SET_CHILD(mViewportState, QuiescenceMode, bool);
	GET_SET_CHILD(mViewportState, TerrainExaggeration, float);
	GET_SET_CHILD(mViewportState, TileZoomRange, tileRangeT);
	GET_SET_CHILD(mViewportState, TileRenderRange, tileRangeT);
	GET_SET_CHILD(mViewportState, ShowTextures, bool);
	GET_SET_CHILD(mViewportState, ShowVectors, bool);
	GET_SET_CHILD(mViewportState, ShowVectorLines, bool);
	GET_SET_CHILD(mViewportState, ShowFilledVectors, bool);
	GET_SET_CHILD(mViewportState, DebugVectorColors, bool);
	GET_SET_CHILD(mViewportState, TileLineInstanceLimit, uint32_t);
	GET_SET_CHILD(mViewportState, VectorWireframes, bool);
	GET_SET_CHILD(mViewportState, TerrainWireframes, bool);
	GET_SET_CHILD(mViewportState, Id, viewportId_t);
	GET_SET_CHILD(mViewportState, WidthRatio, float);
	GET_SET_CHILD(mViewportState, HeightRatio, float);
	GET_SET_CHILD(mViewportState, PosX, float);
	GET_SET_CHILD(mViewportState, PosY, float);
	GET_SET_CHILD(mViewportState, SortOrder, int);
	GET_SET_CHILD(mViewportState, RenderComplete, bool);
	GET_SET_CHILD(mViewportState, ForceCulling, bool);
	GET_SET_CHILD(mViewportState, TileLoadTimeMS, lucid::math::Range<double>);
	GET_SET_CHILD(mViewportState, LODScaler, float);
	GET_SET_CHILD(mViewportState, MaxSubdDepth, int);
	GET_SET_CHILD(mViewportState, CameraMoved, bool);
	GET_SET_CHILD(mViewportState, VectorFadeTime, time_float_t);
	GET_SET_CHILD(mViewportState, VectorDownloadPulseTimeMS, float32_t);
	GET_SET_CHILD(mViewportState, VectorDownloadPulseDelayMS, float32_t);

	GET_SET_PROP(MaxLabelsPerTile, uint32_t, 10);
	GET_SET_PROP(ShowScreenSpaceManager, bool, false);

	template <class T>
	void setRenderedTileIds(T const& tileIds)
	{
		mViewportState.mTileCollections.forceCulled.clear();
		mViewportState.mTileCollections.forceCulled.insert(mViewportState.mTileCollections.forceCulled.end(), tileIds.begin(), tileIds.end());
	}

private:

	ViewportState mViewportState;

	std::shared_ptr<Styling::Style> mStyle;
	
	std::shared_ptr<Drawers::Skydome> mSkydome;

	std::unordered_map<std::string, std::unique_ptr<TerrainEffects::TerrainEffectBase>> mTerrainEffects;

	Shaders::ConfigurableShader mTerrainShaderFamily, mVectorShaderFamily;

	std::vector<Styling::Layer::Types> mTerrainShaderLayers;
	
	uint64_t mLastCacheUpdate = 0;

	// track which fill entries have been rendered so that we don't double render -- cleared every frame
	std::unordered_set<Caching::LayerCache::EntryKey, Caching::LayerCache::EntryKeyHasher> mCoveredFills;

	std::unique_ptr<Rendering::VectorLineMesh> mLineMesh;

	std::unique_ptr<DataObjects::SymbolManager> mSymbolManager;
	time_float_t mCurrentFrameTimeMS = 0;

	std::vector<DataObjects::SharedSymbol_t> mFrameSymbols;

	std::shared_ptr<Caching::LayerCache> mLayerCache;

	bgfx::TextureHandle mColorTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mDepthTarg = BGFX_INVALID_HANDLE;
	
	bgfx::TextureHandle mZTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureFormat::Enum mZBufferFormat = bgfx::TextureFormat::Enum::Unknown;

	bgfx::TextureHandle mDepthReadbackHandle = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mColorReadbackHandle = BGFX_INVALID_HANDLE;

	bgfx::FrameBufferHandle mColorDepthZFrameBuffer = BGFX_INVALID_HANDLE;
	bgfx::FrameBufferHandle mColorZFrameBuffer = BGFX_INVALID_HANDLE;

	void allocateTextures();
	void deallocateTextures();

	void allocateFramebuffers();
	void deallocateFramebuffers();

	void setMatrixUniforms(bgfx::ViewId const& viewId);

	void renderTerrain();
	void renderWaypoints();
	void renderSymbols();

	void syncSources();
	void syncLayers();
	
	void touchRootTiles();

	Styling::Expressions::Arguments expressionArgs() const;

	// return value indiciates whether the shader changed
	bool assignTerrainShaderFamily();

	Atlases::HeightAtlas const* getHeightAtlas() const
	{
		if (!mStyle->hasTerrain())
		{
			return nullptr;
		}

		auto const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
		return static_cast<Atlases::HeightAtlas const*>(source.atlas());
	}

	// uses the current style object to determine layers
	bool gatherTextureRenderInfo(std::vector<Tiles::TileId> const& tiles);
	bool gatherVectorRenderInfo(std::vector<Tiles::TileId> const& tiles);
	void gatherTileTextureInfo(Tiles::TileId const& tileId, Tiles::TileTextureInfo& target);
	bool renderTiles(bgfx::ViewId const& viewId);
	void renderTileTextures(bgfx::ViewId const& viewId, Tiles::TileTextureInfo const& renderInfo);
	void renderTileVectors(bgfx::ViewId const& viewId, Tiles::TileVectorInfo& renderInfo, std::shared_ptr<Styling::Layer const> layer, Shaders::ShaderDefinition* shader);

	void drawTerrainLines(bgfx::ViewId renderId, Tiles::TileVectorInfo const& info, bgfx::VertexBufferHandle const handle, uint32_t start, uint32_t num, float32_t fade, Shaders::ShaderDefinition* shader);
	void drawLineInstances(bgfx::ViewId const& viewId, Tiles::TileVectorInfo const& info, float32_t fade, std::shared_ptr<Styling::LineLayer const> layer, Shaders::ShaderDefinition* shader);
	void drawTerrainVectors(bgfx::ViewId viewId, Tiles::TileVectorInfo const& info, std::shared_ptr<Styling::FillLayer const> layer, Shaders::ShaderDefinition* shader, uint64_t flags = 0ull);

	void renderScreenLines();
	void renderScreenSpaceManager();
	void setTextureParameters(Tiles::AtlasInfo const& info, Shaders::ShaderDefinition * shader, TextureType textureType);
	void propertyChanged(const char* /* propName */) { invalidate(); }

	template<typename LayerType>
	void gatherSymbols();
	void gatherSymbols();

	void update(Styling::ContourLineLayer const& layer, TerrainEffects::ContourLine&      effect, size_t index);	// NOTE: the index parameter is a place-holder until the shader lib is more flexible
	void update(Styling::ElevationLayer   const& layer, TerrainEffects::ElevationShade&   effect);
	void update(Styling::IntersectLayer   const& layer, TerrainEffects::IntersectShade&   effect);
	void update(Styling::SlopeAngleLayer  const& layer, TerrainEffects::SlopeAngleShade&  effect);
	void update(Styling::SlopeAspectLayer const& layer, TerrainEffects::SlopeAspectShade& effect);
	void update(Styling::SunlightLayer    const& layer, TerrainEffects::SunShadow&        effect);
	void update(Styling::ViewshedLayer    const& layer, TerrainEffects::Viewshed&         effect);

public:

	template<template<class, class...> class ContainerT, class... Additional>
	void debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds);

	// NOTE: we assume that vectors is a subset of rasters
	static std::vector<Caching::TileCacheKey> CacheKeys(std::vector<Tiles::TileId> const& rasters, std::vector<Tiles::TileId> const& vectors, std::shared_ptr<Styling::Style const> style);

#if !defined(PLATFORM_EMSCRIPTEN)	// Triple-buffered data
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures.getReady(); }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.getWorking().cullState; }
private:
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.getWorking().cullState; }
	inline void swapTripleBuffers() { mVisibleFeatures.setReady(); }

	Utils::TripleBuffer<VisibleFeatures> mVisibleFeatures;
#else // no triple-buffering
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures; }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.cullState; }
private:
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.cullState; }

	inline void swapTripleBuffers() { }

	VisibleFeatures mVisibleFeatures;
#endif

};

template<template<class, class...> class ContainerT, class... Additional>
void Viewport::debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds)
{
	mViewportState.mCullingEnabled = false;

	for (size_t i = 0; i < 3; ++i) // We need to clear the debug cull state for each of the triple-buffered result
	{
		auto &cullState = getFrameCullState();
		cullState.reset();
		float avgLevel = 0.f;
		for (Tiles::TileId const& id : tileIds)
		{
			cullState.add(id);
		}
		cullState.avgLevel = avgLevel / float(cullState.tileIds.size());
		swapTripleBuffers();
		getFrameCullState();
	}

	mViewportState.mTileCollections.update(getFrameCullState(), getTileZoomRange(), getTileRenderRange());
}

}