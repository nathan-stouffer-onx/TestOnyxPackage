#pragma once

#include <memory>
#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ConfigurableShader.h>
#include <Styling/Style.h>

#include "Caching/Layers/LayerCache.h"
#include "Caching/Tiles/TileCache.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Symbol/SymbolManager.h"
#include "Symbol/MapSymbol.h"
#include "Drawers/Skydome.h"
#include "Pyramid/Culling.h"
#include "Rendering/VectorLineMesh.h"
#include "TerrainEffects/ContourLine.h"
#include "TerrainEffects/Horizon.h"
#include "TerrainEffects/Gradients/ElevationShade.h"
#include "TerrainEffects/Gradients/IntersectShade.h"
#include "TerrainEffects/Gradients/SlopeAngleShade.h"
#include "TerrainEffects/Gradients/SlopeAspectShade.h"
#include "TerrainEffects/Hillshade.h"
#include "TerrainEffects/SunShadow.h"
#include "TerrainEffects/Viewshed.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/property.h"
#include "Utils/TripleBuffer.h"
#include "Utils/TimeFilter.h"
#include "ViewportCompletionFlags.h"
#include "Viewport/ViewportState.h"
#include "Viewport/ViewportId.h"

namespace onyx {

typedef lucid::math::Range<Tiles::TileId::IdCoordsT> tileRangeT;
typedef std::vector<Rendering::VertStructs::ScreenLineData> screenLineVector_t;

// TODO (scott) fill this out with other visible features (vectors, etc)
struct VisibleFeatures
{
	Pyramid::CullResult cullState;
};

class Viewport
{
public:
	static inline viewportId_t sUnknownViewportId = -1;

	Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder = 0);
	~Viewport();
	
	void render(time_float_t timeMS);
	void readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue = 255);
	void copyDepth(std::vector<uint8_t>& target) const;
	void copyColor(std::vector<uint8_t>& target, uint8_t defaultValue) const;
	bgfx::TextureHandle getTexture();		// get color buffer
	bgfx::TextureHandle getDepthReader();	// get our custom Z depth buffer reader
	bgfx::TextureHandle getDepthBuffer();	// get Z buffer

	void resize();

	void setController(std::shared_ptr<Camera::CameraController> controller);
	std::shared_ptr<Camera::CameraController> const& getController() const { return mController; }

	float getAspect() { return mState.getAspect(); }

	float getWidthPixel() const { return mState.getWidthPixel(); }
	float getHeightPixel() const { return mState.getHeightPixel(); }

	lgal::screen::Vector2 size() const { return { screen_coord_t(mState.getWidthPixel()), screen_coord_t(mState.getHeightPixel()) }; }

	bool operator<(Viewport const& comp)
	{
		return mState.getSortOrder() < comp.getState()->getSortOrder();
	}

	
	gpu_float_t depthAtPixel(int screenX, int screenY) const;
	gpu_float_t depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectPixel(int screenX, int screenY) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const;
	lgal::world::Vector3 project(lgal::world::Vector2 const& pos) const;
	lgal::world::Vector3 project(lgal::world::Vector3 const& pos) const;

	void setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration);
	void setCameraState(Camera::CameraState const& state);
	void setCameraState(Camera::CameraState const& render, Camera::CameraState const& cull);
	Camera::CameraState const& getCameraState() const { return mRenderCameraState; }

	void invalidate();
	Symbol::SymbolManager* getSymbolManager() { return mSymbolManager.get(); }

	inline double tileLoadTimeMS() const { return mTileLoadTimeMS.end - mTileLoadTimeMS.begin; }

	ViewportState* getState() { return &mState; }
	ViewportState const* getState() const { return &mState; }

	std::shared_ptr<Styling::Style> getStyle() const { return mStyle; }
	void setStyle(std::shared_ptr<Styling::Style> style);

	void purge(bool immediate = true);

	Caching::LayerCache const& getLayerCache() const { return *mLayerCache; }

	// Returns a non-owning const* meant for exposing debug info
	TerrainEffects::TerrainEffectBase const* getTerrainEffect(std::string const& id) const
	{
		auto found = mTerrainEffects.find(id);
		return (found == mTerrainEffects.end()) ? nullptr : found->second.get();
	}

	template <typename T>
	void setContext(std::string const& key, T value)
	{
		mState.setContext(key, value);
	}

	template <typename T>
	T getContext(std::string const& key) const
	{
		return mState.getContext<T>(key);
	}

	bool hasImage(std::string id);

	// Will return a sprite idx with no name if sprite idx does not exist
	Styling::SpriteIndex getSpriteIdx(std::string const& id) const;

	inline size_t getNumRenderedIcons() const { return mSymbolManager->getNumRenderedIcons(); }

	// Image API
	// Adds sprite image to spritesheet. If id is already in spritesheet, the input will replace the image.
	// ImgData should be in RGBA8 (32-bit, 8 bit uint per color component)
	bool addImage(std::string const& id, std::vector<uint8_t> const& imgData, lgal::array::Vector2 const& imgRes);
	bool addImage(std::string const& id, std::string const& url);
	void removeImage(std::string const& id);
	void compositeImages(std::string const& id, std::vector<std::string> const& filePaths);

	// TODO (Ronald): In the interest of time, haven't added unit tests for these yet
	inline bool overrideSymbolExists(index_t i) const { return (mOverrideSymbols.size() >= i + 1); }
	// Returns a copy of the symbol. Will return an empty symbol (no icon nor label) if it doesn't exist
	Symbol::MapSymbol getOverrideSymbol(index_t i) const;
	inline size_t getNumOverrideSymbols() const { return mOverrideSymbols.size(); }
	int  addOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s);
	inline void updateOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s, index_t i) 
	{
		if (overrideSymbolExists(i)) { 
			mOverrideSymbols[i] = std::move(s); 
			invalidate();
		}
	}
	inline void deleteOverrideSymbol(index_t i) 
	{
		if (overrideSymbolExists(i)) {
			mOverrideSymbols.erase(mOverrideSymbols.begin() + i);
			invalidate();
		}
	}
	inline void clearOverrideSymbols() { 
		mOverrideSymbols.clear(); 
		invalidate();
	}
	
	GET_PROP(Id, viewportId_t, sUnknownViewportId);
	GET_PROP(CameraMoved, bool, false);
	GET_PROP(Zoom, float, 0.f);
	GET_PROP(ZoomKm, float, 0.f);
	GET_PROP(FilteredZoom, float, 0.f);
	GET_PROP(FilteredZoomKm, float, 0.f);
	GET_PROP(FogStyle, Styling::FogStyle, {});
	GET_PROP(DeepestZoomLevel, int, 0);
	GET_PROP(Exaggeration, float, 1.f);
	GET_PROP(ForceCulling, bool, true);
	GET_PROP(IncompleteRenderComponents, ViewportCompletionFlags, cAllCompletionFlags);
	GET_PROP(TileLoadTimeMS, lmath::Range<double>, lgal::world::Range(0.0, 0.0));

	GET_SET_PROP(Horizon, TerrainEffects::Horizon, {});
	
	Atlases::HeightAtlas const* getHeightAtlas() const;

private:

	ViewportState mState;

	Symbol::SymbolManager::symbolVec_t mOverrideSymbols;
	
	std::shared_ptr<Camera::CameraController> mController;
	Camera::CameraState mRenderCameraState;
	Camera::CameraState mCullCameraState;

	Utils::TimeFilter<float> mZoomFilter;

	std::shared_ptr<Styling::Style> mStyle;
	Atlases::TextureAtlas<std::string> mTextureAtlas;
	std::unique_ptr<Caching::LayerCache> mLayerCache;

	std::unordered_map<std::string, std::unique_ptr<TerrainEffects::TerrainEffectBase>> mTerrainEffects;

	Shaders::ConfigurableShader mTerrainShaderFamily;
	std::vector<Styling::Layer::Types> mTerrainShaderLayers;
	
	std::unordered_map<Tiles::TileId, Tiles::RasterRenderInfo> mRasterRenderInfo;
	std::unordered_map<Tiles::TileId, Tiles::VectorRenderInfo> mVectorRenderInfo;

	Camera::ScreenSpaceManager mScreenSpaceManager;
	std::unique_ptr<Symbol::SymbolManager> mSymbolManager;
	std::vector<Symbol::SharedSymbol_t> mFrameSymbols;

	time_float_t mLastCacheUpdate = 0;
	time_float_t mCurrentFrameTimeMS = 0;

	std::unique_ptr<Drawers::Skydome> mSkydome;
	std::unique_ptr<Rendering::VectorLineMesh> mLineMesh;

	std::vector<uint8_t> mDepthData;
	std::vector<Camera::CameraState> mDepthCameras;
	size_t mDepthCameraIndex = 0;	// the index we read/write to

	bgfx::TextureHandle mColorTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mDepthTarg = BGFX_INVALID_HANDLE;
	
	bgfx::TextureHandle mZTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureFormat::Enum mZBufferFormat = bgfx::TextureFormat::Enum::Unknown;

	bgfx::TextureHandle mDepthReadbackHandle = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mColorReadbackHandle = BGFX_INVALID_HANDLE;

	bgfx::FrameBufferHandle mColorDepthZFrameBuffer = BGFX_INVALID_HANDLE;
	bgfx::FrameBufferHandle mColorZFrameBuffer = BGFX_INVALID_HANDLE;

	int mWaitForDepthAfterResizing = false;

	inline void toggle(ViewportCompletionFlags flag, bool complete)
	{
		if (complete) mIncompleteRenderComponents &= ~flag;
		else mIncompleteRenderComponents |= flag;
	}

	inline bool isIncomplete(ViewportCompletionFlags flags) const
	{
		return (mIncompleteRenderComponents & flags) != 0;
	}

	void allocateTextures();
	void deallocateTextures();

	void allocateFramebuffers();
	void deallocateFramebuffers();

	float computeZoom() const;

	void setMatrixUniforms(bgfx::ViewId const& viewId);

	void renderTiles();
	void renderWaypoints();
	void renderSymbols();
	void renderScreenLines();
	void renderScreenSpaceManager();

	void syncSources();
	void syncLayers();
	
	void touchRootTiles();

	Styling::Expressions::Arguments expressionArgs() const;
	Styling::Arguments layerArgs() const;
	Caching::PreparedData::Metadata computeMetadata(Tiles::TileId const& tileId, Styling::Layer const& layer, time_float_t const timestampMS, uint16_t const meshResolution) const;

	// return value indicates whether the shader changed
	bool assignTerrainShaderFamily();

	void propertyChanged(const char* propName);

	template<typename LayerType>
	bool gatherSymbols();
	void gatherSymbols();
	
	// uses the current style object to determine layers
	void prepare(std::vector<Tiles::TileId> const& tiles);
	void prepare(Tiles::TileId const& tileId, Tiles::RenderInfo& info);
	void prepare(Tiles::TileId const& tileId, Tiles::RasterRenderInfo& info);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::ContourLabelLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::FillLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::LineLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::SymbolLayer const> const& layer, Caching::Source const& source, Tiles::VectorRenderInfo& info);

	void update(Styling::ContourLineLayer const& layer, TerrainEffects::ContourLine&      effect, size_t index);	// NOTE: the index parameter is a place-holder until the shader lib is more flexible
	void update(Styling::ElevationLayer   const& layer, TerrainEffects::ElevationShade&   effect);
	void update(Styling::HillshadeLayer   const& layer, TerrainEffects::Hillshade&        effect);
	void update(Styling::IntersectLayer   const& layer, TerrainEffects::IntersectShade&   effect);
	void update(Styling::SlopeAngleLayer  const& layer, TerrainEffects::SlopeAngleShade&  effect);
	void update(Styling::SlopeAspectLayer const& layer, TerrainEffects::SlopeAspectShade& effect);
	void update(Styling::SunlightLayer    const& layer, TerrainEffects::SunShadow&        effect);
	void update(Styling::ViewshedLayer    const& layer, TerrainEffects::Viewshed&         effect);

	void render(bgfx::ViewId const viewId, Tiles::RasterRenderInfo const& info);
	void render(bgfx::ViewId const viewId, Styling::FillLayer const& layer, Styling::FillStyle::Effect const& effect, Tiles::VectorRenderInfo const& info);
	void render(bgfx::ViewId const viewId, Styling::LineLayer const& layer, Styling::LineStyle::Effect const& effect, Tiles::VectorRenderInfo const& info);
	
	// templated function to reduce verbosity
	template<typename VectorLayerT>
	void render(bgfx::ViewId const viewId, VectorLayerT const& layer);

	bool addImage(std::string const& id, bgfx::TextureHandle texHndl, bgfx::TextureFormat::Enum format, lgal::array::Vector2 const& imgRes);

public:

	template<template<class, class...> class ContainerT, class... Additional>
	void debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds);

	// NOTE: we assume that vectors is a subset of rasters
	static std::vector<Caching::TileCacheKey> CacheKeys(std::vector<Tiles::TileId> const& tiles, std::shared_ptr<Styling::Style const> style, float const zoom);

	static float AliasZoom(float const zoom);

#if !defined(PLATFORM_EMSCRIPTEN)	// Triple-buffered data
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures.getReady(); }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.getWorking().cullState; }
private:
	bool mCullStateChanged = false;

	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.getWorking().cullState; }
	inline void swapTripleBuffers() { if (mCullStateChanged) { mCullStateChanged = false; mVisibleFeatures.setReady(); } }

	Utils::TripleBuffer<VisibleFeatures> mVisibleFeatures;
#else // no triple-buffering
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures; }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.cullState; }
private:
	bool mCullStateChanged = false;
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.cullState; }

	inline void swapTripleBuffers() { }

	VisibleFeatures mVisibleFeatures;
#endif

};

template<template<class, class...> class ContainerT, class... Additional>
void Viewport::debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds)
{
	mState.setCullingEnabled(false);

	for (size_t i = 0; i < 3; ++i) // We need to clear the debug cull state for each of the triple-buffered result
	{
		auto &cullState = getFrameCullState();
		cullState.reset();
		float avgLevel = 0.f;
		for (Tiles::TileId const& id : tileIds)
		{
			cullState.add(id);
		}
		cullState.avgLevel = avgLevel / float(cullState.tileIds.size());
		swapTripleBuffers();
		getFrameCullState();
	}
}

}
