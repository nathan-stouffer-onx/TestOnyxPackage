#pragma once

#include <memory>
#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ConfigurableShader.h>
#include <Shaders/v2/Program.h>
#include <Styling/Style.h>

#include "Caching/Layers/LayerCache.h"
#include "Caching/Tiles/TileCache.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Sprites/Spritesheet.h"
#include "Pyramid/Culling.h"
#include "Rendering/LineMesh.h"
#include "Rendering/Skydome.h"
#include "Symbol/SymbolManager.h"
#include "Symbol/MapSymbol.h"
#include "TerrainEffects/ContourLine.h"
#include "TerrainEffects/Horizon.h"
#include "TerrainEffects/Gradients/ElevationShade.h"
#include "TerrainEffects/Gradients/IntersectShade.h"
#include "TerrainEffects/Gradients/SlopeAngleShade.h"
#include "TerrainEffects/Gradients/SlopeAspectShade.h"
#include "TerrainEffects/Hillshade.h"
#include "TerrainEffects/SunShadow.h"
#include "TerrainEffects/Viewshed.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/property.h"
#include "Utils/TripleBuffer.h"
#include "Utils/TimeFilter.h"
#include "ViewportCompletionFlags.h"
#include "Viewport/ViewportState.h"
#include "Viewport/ViewportId.h"

namespace onyx {

typedef lucid::math::Range<Tiles::TileId::IdCoordsT> tileRangeT;
typedef std::vector<Rendering::VertStructs::ScreenLineData> screenLineVector_t;

// TODO (scott CSONYX-168) fill this out with other visible features (vectors, etc)
struct VisibleFeatures
{
	Pyramid::CullResult cullState;
};

class Viewport
{
public:
	static inline viewportId_t sUnknownViewportId = -1;

	Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder = 0);
	~Viewport();
	
	void render(time_float_t timeMS);
	void readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue = 255);
	void copyDepth(std::vector<uint8_t>& target) const;
	void copyColor(std::vector<uint8_t>& target, uint8_t defaultValue) const;
	bgfx::TextureHandle getColorBuffer();	// get color buffer
	bgfx::TextureHandle getDepthBuffer();	// get depth buffer

	void resize();

	void setController(std::shared_ptr<Camera::CameraController> controller);
	std::shared_ptr<Camera::CameraController> const& getController() const { return mController; }

	float getAspect() { return mState.getAspect(); }

	float getWidthPixel() const { return mState.getWidthPixel(); }
	float getHeightPixel() const { return mState.getHeightPixel(); }
	lmath::Vector<float, 2> getDimensions() const { return { getWidthPixel(), getHeightPixel() }; }

	lgal::screen::Vector2 size() const { return { screen_coord_t(mState.getWidthPixel()), screen_coord_t(mState.getHeightPixel()) }; }

	bool operator<(Viewport const& comp) const
	{
		return mState.getSortOrder() < comp.getState()->getSortOrder();
	}
	
	gpu_float_t depthAtPixel(lgal::screen::Vector2 const pos) const;
	gpu_float_t depthAtNormalized(lgal::gpu::Vector2 const& pos) const;

	lgal::world::Vector3 unprojectPixel(lgal::screen::Vector2 const pos) const;
	lgal::world::Vector3 unprojectNormalized(lgal::gpu::Vector2 const& pos) const;
	lgal::world::Vector3 unprojectNormalized(lgal::gpu::Vector2 const& pos, world_float_t const depth) const;

	lgal::world::Vector3 project(lgal::world::Vector2 const& pos) const;
	lgal::world::Vector3 project(lgal::world::Vector3 const& pos) const;

	void setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration);
	void setCameraState(Camera::CameraState const& state);
	Camera::CameraState const& getCameraState() const { return mRenderCameraState; }
	Camera::CameraState const& getRenderCameraState() const { return mRenderCameraState; }
	Camera::CameraState const& getCullCameraState() const { return mCullCameraState; }

	void invalidate();
	Symbol::SymbolManager* getSymbolManager() { return mSymbolManager.get(); }

	inline double tileLoadTimeMS() const { return mTileLoadTimeMS.end - mTileLoadTimeMS.begin; }

	ViewportState* getState() { return &mState; }
	ViewportState const* getState() const { return &mState; }

	std::shared_ptr<Styling::Style> getStyle() const { return mStyle; }
	void setStyle(std::shared_ptr<Styling::Style> style);

	void purge(bool immediate = true);

	Caching::LayerCache const& getLayerCache() const { return *mLayerCache; }

	// Returns a non-owning const* meant for exposing debug info
	TerrainEffects::TerrainEffectBase const* getTerrainEffect(std::string const& id) const
	{
		auto found = mTerrainEffects.find(id);
		return (found == mTerrainEffects.end()) ? nullptr : found->second.get();
	}

	template <typename T>
	void setContext(std::string const& key, T value)
	{
		mState.setContext(key, value);
	}

	template <typename T>
	T getContext(std::string const& key) const
	{
		return mState.getContext<T>(key);
	}
	
	inline size_t getNumRenderedIcons() const { return mSymbolManager->getNumRenderedIcons(); }

	// TODO (Ronald): Override symbol api should be moved out of viewport

	static constexpr size_t cMaxNumOverrideSyms = 32;
	inline bool overrideSymbolExists(index_t i) const { 
		return (i != std::numeric_limits<index_t>::max()) && (mOverrideSymbols.size() >= i + 1); 
	}
	// Returns a copy of the symbol. Will return an empty symbol (no icon nor label) if it doesn't exist
	Symbol::MapSymbol getOverrideSymbol(index_t i) const;
	inline size_t getNumOverrideSymbols() const { return mOverrideSymbols.size(); }
	int addOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s);
	inline void updateOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s, index_t i) 
	{
		if (overrideSymbolExists(i)) { 
			mOverrideSymbols[i] = std::move(s); 
			invalidate();
		}
	}
	inline void deleteOverrideSymbol(index_t i) 
	{
		if (overrideSymbolExists(i)) {
			mOverrideSymbols.erase(mOverrideSymbols.begin() + i);
			invalidate();
		}
	}
	inline void clearOverrideSymbols() { 
		mOverrideSymbols.clear(); 
		invalidate();
	}
	
	GET_PROP(Id, viewportId_t, sUnknownViewportId);
	GET_PROP(CameraMoved, bool, false);
	GET_PROP(Zoom, float, 0.f);
	GET_PROP(ZoomKm, float, 0.f);
	GET_PROP(FilteredZoom, float, 0.f);
	GET_PROP(FilteredZoomKm, float, 0.f);
	GET_PROP(FogStyle, Styling::FogStyle, {});
	GET_PROP(DeepestZoomLevel, int, 0);
	GET_PROP(Exaggeration, float, 1.f);
	GET_PROP(ForceCulling, bool, true);
	GET_PROP(IncompleteRenderComponents, ViewportCompletionFlags, cAllCompletionFlags);
	GET_PROP(TileLoadTimeMS, lmath::Range<double>, lgal::world::Range(0.0, 0.0));
	GET_PROP(Spritesheet, std::shared_ptr<Spritesheet>, nullptr);

	GET_PROP_REF(FrameSymbols, std::vector<Symbol::SharedSymbol_t>, {});
	GET_SET_PROP(Horizon, TerrainEffects::Horizon, {});
	
	Atlases::HeightAtlas const* getHeightAtlas() const;

private:

	ViewportState mState;

	Symbol::SymbolManager::symbolVec_t mOverrideSymbols;
	
	std::shared_ptr<Camera::CameraController> mController;
	Camera::CameraState mRenderCameraState;
	Camera::CameraState mCullCameraState;

	Utils::TimeFilter<float> mZoomFilter;

	std::shared_ptr<Styling::Style> mStyle;
	std::unique_ptr<Caching::LayerCache> mLayerCache;

	std::unordered_map<std::string, std::unique_ptr<TerrainEffects::TerrainEffectBase>> mTerrainEffects;

	Shaders::ConfigurableShader mRasterBasedShaderFamily;
	std::vector<Styling::Layer::Types> mRasterBasedShaderLayers;
	Shaders::Program mDepthProgram;
	Shaders::Program mFillProgram;
	Shaders::Program mLineProgram;
	Shaders::Program mSkydomeProgram;
	Shaders::Program mScreenLineProgram;
	Shaders::Program mBoxProgram;
	Shaders::Program mFrustumProgram;
	
	Camera::ScreenSpaceManager mScreenSpaceManager;
	std::unique_ptr<Symbol::SymbolManager> mSymbolManager;

	time_float_t mLastCacheUpdate = 0;
	time_float_t mCurrentFrameTimeMS = 0;

	std::unique_ptr<Rendering::Skydome> mSkydome;
	std::unique_ptr<Rendering::LineMesh> mLineMesh;

	std::vector<uint8_t> mDepthData;
	std::vector<Camera::CameraState> mDepthCameras;
	size_t mDepthCameraIndex = 0;	// the index we read/write to

	bgfx::TextureHandle mDummyTerrainHandle = BGFX_INVALID_HANDLE;

	bgfx::TextureHandle mColorTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mDepthTarg = BGFX_INVALID_HANDLE;
	
	bgfx::TextureHandle mZTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureFormat::Enum mZBufferFormat = bgfx::TextureFormat::Enum::Unknown;

	bgfx::TextureHandle mColorReadbackHandle = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mDepthReadbackHandle = BGFX_INVALID_HANDLE;

	bgfx::FrameBufferHandle mColorFrameBuffer = BGFX_INVALID_HANDLE;
	bgfx::FrameBufferHandle mDepthFrameBuffer = BGFX_INVALID_HANDLE;

	int mWaitForDepthAfterResizing = false;

	inline void toggle(ViewportCompletionFlags flag, bool complete)
	{
		if (complete) mIncompleteRenderComponents &= ~flag;
		else mIncompleteRenderComponents |= flag;
	}

	inline bool isIncomplete(ViewportCompletionFlags flags) const
	{
		return (mIncompleteRenderComponents & flags) != 0;
	}

	void allocateTextures();
	void deallocateTextures();

	void allocateFramebuffers();
	void deallocateFramebuffers();

	float computeZoom() const;

	void setMatrixUniforms(bgfx::ViewId const& viewId);

	void renderTiles();
	void renderWaypoints();
	void renderSymbols();
	void renderScreenLines();
	void renderScreenSpaceManager();

	void syncSources();
	void syncLayers();
	
	void touchRootTiles();

	using DemPtrT = std::shared_ptr<Styling::RasterDemSource const>;

	Styling::Expressions::Arguments expressionArgs() const;
	Styling::Arguments layerArgs() const;
	uint16_t computeMeshResolution(DemPtrT const& dem, Tiles::TileId const& tileId) const;
	Caching::PreparedData::Metadata computeMetadata(Tiles::TileId const& tileId, Styling::Layer const& layer, time_float_t const timestampMS, uint16_t const meshResolution) const;

	// return value indicates whether the programs changed
	bool assignPrograms();

	void propertyChanged(const char* propName);

	void prepare(std::vector<Tiles::TileId> const& tiles, Caching::LayerCache::LockT const& lock);		// uses the current style object to determine layers
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::ContourLabelLayer const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::FillLayer         const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::LineLayer         const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::SymbolLayer       const> const& layer, Caching::Source const& source, DemPtrT const& dem, Caching::LayerCache::LockT const& lock);

	struct TileTuple
	{
		Tiles::TileId id;
		lgal::world::AABB2d globeBounds;	// the bounds of the tile in lon/lat coordinates
		world_float_t distance;
	};

	template<typename VectorLayerT>
	void prepare(std::vector<TileTuple> const& tuples, std::shared_ptr<VectorLayerT const> const& layer, Caching::Source const& source, DemPtrT const& dem, world_float_t radius, Caching::LayerCache::LockT const& lock);

	void update(Styling::ContourLineLayer const& layer, TerrainEffects::ContourLine&      effect, size_t index);	// NOTE: the index parameter is a place-holder until the shader lib is more flexible
	void update(Styling::ElevationLayer   const& layer, TerrainEffects::ElevationShade&   effect);
	void update(Styling::HillshadeLayer   const& layer, TerrainEffects::Hillshade&        effect);
	void update(Styling::IntersectLayer   const& layer, TerrainEffects::IntersectShade&   effect);
	void update(Styling::SlopeAngleLayer  const& layer, TerrainEffects::SlopeAngleShade&  effect);
	void update(Styling::SlopeAspectLayer const& layer, TerrainEffects::SlopeAspectShade& effect);
	void update(Styling::SunlightLayer    const& layer, TerrainEffects::SunShadow&        effect);
	void update(Styling::ViewshedLayer    const& layer, TerrainEffects::Viewshed&         effect);

	Tiles::Gathered gather(std::vector<Tiles::TileId> const& tiles);
	void gather(Tiles::TileId const& tileId, Tiles::TerrainInfo& info);
	void gather(Tiles::TileId const& tileId, Tiles::RasterInfo& info);

	template<typename LayerType>
	bool gatherSymbols();
	void gatherSymbols();

	void render(bgfx::ViewId const viewId, Tiles::TerrainInfo const& height, Tiles::RasterInfo const& raster);
	void render(bgfx::ViewId const viewId, Styling::FillLayer const& layer, Styling::FillStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector);
	void render(bgfx::ViewId const viewId, Styling::LineLayer const& layer, Styling::LineStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector);
	
	// templated function to reduce verbosity
	template<typename VectorLayerT>
	void render(bgfx::ViewId const viewId, VectorLayerT const& layer, Caching::Source const& source, Tiles::Gathered const& gathered);

public:

	template<template<class, class...> class ContainerT, class... Additional>
	void debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds);

	static float AliasZoom(float const zoom);

#if !defined(PLATFORM_EMSCRIPTEN)	// Triple-buffered data
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures.getReady(); }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.getWorking().cullState; }

private:
	bool mCullStateChanged = false;

	inline void swapTripleBuffers() { if (mCullStateChanged) { mCullStateChanged = false; mVisibleFeatures.setReady(); } }
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.getWorking().cullState; }

	Utils::TripleBuffer<VisibleFeatures> mVisibleFeatures;
#else // no triple-buffering
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures; }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.cullState; }
private:
	bool mCullStateChanged = false;
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.cullState; }
	inline void swapTripleBuffers() { }

	VisibleFeatures mVisibleFeatures;
#endif

};

template<template<class, class...> class ContainerT, class... Additional>
void Viewport::debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds)
{
	mState.setCullingEnabled(false);

	for (size_t i = 0; i < 3; ++i) // We need to clear the debug cull state for each of the triple-buffered result
	{
		auto &cullState = getFrameCullState();
		cullState.reset();
		float avgLevel = 0.f;
		for (Tiles::TileId const& id : tileIds)
		{
			cullState.add(id);
		}
		cullState.avgLevel = avgLevel / float(cullState.tileIds.size());
		swapTripleBuffers();
		getFrameCullState();
	}
}

}
