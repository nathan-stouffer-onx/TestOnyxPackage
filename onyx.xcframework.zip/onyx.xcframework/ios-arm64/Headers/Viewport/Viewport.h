#pragma once

#include <memory>
#include <mutex>
#include <tuple>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/Program.h>
#include <Styling/Style.h>
#include <Styling/Styles/SkydomeStyle.h>

#include "Caching/Layers/LayerCache.h"
#include "Caching/Tiles/TileCache.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Sprites/Spritesheet.h"
#include "Pyramid/Culling.h"
#include "Rendering/LineMesh.h"
#include "Rendering/Quad.h"
#include "Rendering/Skydome.h"
#include "Symbol/SymbolManager.h"
#include "Symbol/MapSymbol.h"
#include "TerrainEffects/TerrainEffectBase.h"
#include "TerrainEffects/Horizon.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/property.h"
#include "Utils/TripleBuffer.h"
#include "Utils/TimeFilter.h"
#include "Viewport/Stale.h"
#include "Viewport/ViewportState.h"
#include "Viewport/ViewportId.h"
#include "Experimental/WindParticleSystem.h"
#include "Experimental/ParticleSystem.h"

namespace onyx {

typedef lucid::math::Range<Tiles::TileId::IdCoordsT> tileRangeT;
typedef std::vector<Rendering::VertStructs::ScreenLineData> screenLineVector_t;

// TODO (scott CSONYX-168) fill this out with other visible features (vectors, etc)
struct VisibleFeatures
{
	Pyramid::CullResult cullState;
};

class Viewport
{
public:
	static inline viewportId_t sUnknownViewportId = -1;

	Viewport(viewportId_t viewportId, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder = 0);
	~Viewport();
	
	void update(time_float_t timeMS);

	void copyDepth(std::vector<uint8_t>& target) const;
	void copyColor(std::vector<uint8_t>& target, uint8_t defaultValue) const;
	bgfx::TextureHandle getColorBuffer();	// get color buffer
	bgfx::TextureHandle getDepthBuffer();	// get depth buffer

	void resize();

	void setController(std::shared_ptr<Camera::CameraController> controller);
	std::shared_ptr<Camera::CameraController> const& getController() const { return mController; }

	float getAspect() { return mState.getAspect(); }

	float getWidthPixel() const { return mState.getWidthPixel(); }
	float getHeightPixel() const { return mState.getHeightPixel(); }
	lmath::Vector<float, 2> getDimensions() const { return { getWidthPixel(), getHeightPixel() }; }

	lgal::screen::Vector2 size() const { return { screen_coord_t(mState.getWidthPixel()), screen_coord_t(mState.getHeightPixel()) }; }

	bool operator<(Viewport const& comp) const
	{
		return mState.getSortOrder() < comp.getState()->getSortOrder();
	}
	
	gpu_float_t depthAtPixel(lgal::screen::Vector2 const pos) const;
	gpu_float_t depthAtNormalized(lgal::gpu::Vector2 const& pos) const;

	lgal::world::Vector3 unprojectPixel(lgal::screen::Vector2 const pos) const;
	lgal::world::Vector3 unprojectNormalized(lgal::gpu::Vector2 const& pos) const;
	lgal::world::Vector3 unprojectNormalized(lgal::gpu::Vector2 const& pos, world_float_t const depth) const;

	lgal::world::Vector3 project(lgal::world::Vector2 const& pos) const;
	lgal::world::Vector3 project(lgal::world::Vector3 const& pos) const;

	void setCameraState(Camera::CameraState const& state);
	Camera::CameraState const& getCameraState() const { return mRenderCameraState; }
	Camera::CameraState const& getRenderCameraState() const { return mRenderCameraState; }
	Camera::CameraState const& getCullCameraState() const { return mCullCameraState; }

	void invalidate();
	Symbol::SymbolManager* getSymbolManager() { return mSymbolManager.get(); }

	inline double tileLoadTimeMS() const { return mTileLoadTimeMS.end - mTileLoadTimeMS.begin; }

	ViewportState* getState() { return &mState; }
	ViewportState const* getState() const { return &mState; }

	std::shared_ptr<Styling::Style> getStyle() const { return mStyle; }
	void setStyle(std::shared_ptr<Styling::Style> style);

	void purge(bool immediate = true);

	inline void requestKill() { mLayerCache->requestKill(); }

	Caching::LayerCache const& getLayerCache() const { return *mLayerCache; }

	// Returns a non-owning const* meant for exposing debug info
	TerrainEffects::TerrainEffectBase const* getTerrainEffect(std::string const& id) const
	{
		auto found = mTerrainEffects.find(id);
		return (found == mTerrainEffects.end()) ? nullptr : found->second.get();
	}

	template <typename T>
	void setContext(std::string const& key, T value)
	{
		mState.setContext(key, value);
	}

	template <typename T>
	T getContext(std::string const& key) const
	{
		return mState.getContext<T>(key);
	}
	
	inline size_t getNumRenderedIcons() const { return mSymbolManager->getNumRenderedIcons(); }

	// TODO (Ronald): Override symbol api should be moved out of viewport

	static constexpr size_t cMaxNumOverrideSyms = 32;
	inline bool overrideSymbolExists(index_t i) const { 
		return (i != std::numeric_limits<index_t>::max()) && (mOverrideSymbols.size() >= i + 1); 
	}
	// Returns the symbol. Will return an empty symbol (no icon nor label) if it doesn't exist
	Symbol::SharedSymbol_t getOverrideSymbol(index_t i) const;
	inline size_t getNumOverrideSymbols() const { return mOverrideSymbols.size(); }
	int addOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s);
	inline void updateOverrideSymbol(std::unique_ptr<Symbol::MapSymbol> s, index_t i) 
	{
		if (overrideSymbolExists(i)) { 
			mOverrideSymbols[i] = std::move(s); 
			invalidate();
		}
	}
	inline void deleteOverrideSymbol(index_t i) 
	{
		if (overrideSymbolExists(i)) {
			mOverrideSymbols.erase(mOverrideSymbols.begin() + i);
			invalidate();
		}
	}
	inline void clearOverrideSymbols() { 
		mOverrideSymbols.clear(); 
		invalidate();
	}
	
	GET_PROP(Id, viewportId_t, sUnknownViewportId);
	GET_PROP(Zoom, float, 0.f);
	GET_PROP(ZoomKm, float, 0.f);
	GET_PROP(FilteredZoom, float, 0.f);
	GET_PROP(FilteredZoomKm, float, 0.f);
	GET_PROP(FogStyle, Styling::FogStyle, {});
	GET_PROP(SkydomeStyle, Styling::SkydomeStyle, {});
	GET_PROP(DeepestZoomLevel, int, 0);
	GET_PROP(Exaggeration, float, 1.f);
	GET_PROP(StaleFlags, Stale, Stale::ALL);
	GET_PROP(TileLoadTimeMS, lmath::Range<double>, lgal::world::Range(0.0, 0.0));
	GET_PROP(Spritesheet, std::shared_ptr<Spritesheet>, nullptr);

	GET_PROP_REF(FrameSymbols, std::vector<Symbol::SharedSymbol_t>, {});
	GET_SET_PROP(Horizon, TerrainEffects::Horizon, {});
	
	Atlases::HeightAtlas const* getHeightAtlas() const;
	
	inline void startWindParticles() { mWindParticles = std::make_unique<Experimental::WindParticleSystem>(); }
	inline void stopWindParticles() { mWindParticles = nullptr; }
	inline bool windParticlesOn() const { return mWindParticles != nullptr; }

	inline void startGeyserParticles() { mGeyserParticles = std::make_unique<Experimental::ParticleSystem>(); }
	inline void stopGeyserParticles() { mGeyserParticles = nullptr; }
	inline bool geyserParticlesOn() const { return mGeyserParticles != nullptr; }

private:

	std::string mDebugPrefix;

	ViewportState mState;

	Symbol::SymbolManager::symbolVec_t mOverrideSymbols;
	
	std::shared_ptr<Camera::CameraController> mController;
	Camera::CameraState mRenderCameraState;
	Camera::CameraState mCullCameraState;

	Utils::TimeFilter<float> mZoomFilter;

	std::shared_ptr<Styling::Style> mStyle;
	std::unique_ptr<Caching::LayerCache> mLayerCache;

	struct Terrain
	{
		std::shared_ptr<Styling::Terrain const> terrain = nullptr;
		std::shared_ptr<Styling::RasterDemSource const> source = nullptr;
		Atlases::HeightAtlas const* atlas = nullptr;

		operator bool() const { return terrain && source && atlas; }

		int maxZoom() const { return source->maxZoom; }
		
		lgal::Range range() const { return source->range(); }
		
	};

	Terrain mTerrain;

	std::unordered_map<std::string, std::unique_ptr<TerrainEffects::TerrainEffectBase>> mTerrainEffects;

	Rendering::Quad mQuad;

	std::vector<Shaders::Program> mPseudoRasterPrograms;
	Shaders::Program mFillProgram;
	Shaders::Program mLineProgram;
	Shaders::Program mDepthProgram;
	Shaders::Program mSkydomeProgram;
	Shaders::Program mFogProgram;
	Shaders::Program mScreenLineProgram;
	Shaders::Program mBoxProgram;
	Shaders::Program mFrustumProgram;
	bool mAssignedPrograms = false;	// book-keeping so we only load programs once

	Camera::ScreenSpaceManager mScreenSpaceManager;
	std::unique_ptr<Symbol::SymbolManager> mSymbolManager;

	std::unique_ptr<Experimental::WindParticleSystem> mWindParticles = nullptr;
	std::unique_ptr<Experimental::ParticleSystem> mGeyserParticles = nullptr;
	
	time_float_t mTerrainCacheUpdateMS = 0;
	time_float_t mTileCacheUpdateMS = 0;
	time_float_t mCurrentFrameTimeMS = 0;

	std::unique_ptr<Rendering::Skydome> mSkydome;
	std::unique_ptr<Rendering::LineMesh> mLineMesh;

	struct DepthState
	{
		bgfx::TextureHandle handle = BGFX_INVALID_HANDLE;
		std::vector<uint8_t> bytes;
		Camera::CameraState camera;

		~DepthState() { BgfxUtils::tryDestroy(handle); }
	};

	std::vector<DepthState> mDepthStates;
	size_t mDepthStateIndex = 0;	// the index we read/write to
	bool mRenderedDepth = false;

	bgfx::TextureHandle mDummyTerrainHandle = BGFX_INVALID_HANDLE;

	bgfx::TextureHandle mColorTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mDepthTarg = BGFX_INVALID_HANDLE;
	
	bgfx::TextureHandle mZTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureFormat::Enum mZBufferFormat = bgfx::TextureFormat::Enum::Unknown;

	bgfx::TextureHandle mColorReadbackHandle = BGFX_INVALID_HANDLE;

	bgfx::FrameBufferHandle mColorFrameBuffer = BGFX_INVALID_HANDLE;
	bgfx::FrameBufferHandle mDepthFrameBuffer = BGFX_INVALID_HANDLE;

	inline void toggle(Stale flags, bool stale)
	{
		if (stale) { mStaleFlags |= flags; }
		else { mStaleFlags &= ~flags; }
	}

	inline void mark(Stale flags) { mStaleFlags |= flags; }
	inline bool isStale(Stale flags) const { return (mStaleFlags & flags) != 0; }

	auto zoomTie() const { return std::tie(mZoom, mFilteredZoom, mZoomKm, mFilteredZoomKm); }

	void allocateTextures();
	void deallocateTextures();

	void allocateFramebuffers();
	void deallocateFramebuffers();

	float computeZoom() const;

	void setMatrixUniforms(bgfx::ViewId const& viewId);
	bgfx::ViewId allocateViewId(std::string const& name, bgfx::FrameBufferHandle handle, uint32_t rgba, float depth, uint16_t flags);

	void renderTiles();
	void renderSymbols();
	void renderScreenLines();
	void renderScreenSpaceManager();

	void syncSources();
	void syncLayers();
	
	void touchRootTiles();

	Styling::Expressions::Arguments expressionArgs() const;
	Styling::Arguments layerArgs() const;
	uint16_t computeMeshResolution(Tiles::TileId const& tileId) const;
	Caching::PreparedData::Metadata computeMetadata(Tiles::TileId const& tileId, Styling::Layer const& layer, time_float_t const timestampMS, uint16_t const meshResolution) const;

	// return value indicates whether the programs changed
	bool assignPrograms();

	void propertyChanged(const char* propName);

	void prepare(std::vector<Tiles::TileId> const& tiles, Caching::LayerCache::LockT const& lock);		// uses the current style object to determine layers
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::ContourLabelLayer const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::FillLayer         const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::LineLayer         const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock);
	void prepare(Tiles::TileId const& tileId, std::shared_ptr<Styling::SymbolLayer       const> const& layer, Caching::Source const& source, Caching::LayerCache::LockT const& lock);

	struct TileTuple
	{
		Tiles::TileId id;
		lgal::world::AABB2d globeBounds;	// the bounds of the tile in lon/lat coordinates
		world_float_t distance;
	};

	template<typename VectorLayerT>
	void prepare(std::vector<TileTuple> const& tuples, std::shared_ptr<VectorLayerT const> const& layer, Caching::Source const& source, world_float_t radius, Caching::LayerCache::LockT const& lock);

	Tiles::Gathered gather(std::vector<Tiles::TileId> const& tiles);
	void gather(Tiles::TileId const& tileId, Tiles::TerrainInfo& info);

	template<typename LayerType>
	bool gatherSymbols();
	void gatherSymbols();

	void render();
	void render(bgfx::ViewId const viewId, Styling::FillLayer const& layer, Styling::FillStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector);
	void render(bgfx::ViewId const viewId, Styling::LineLayer const& layer, Styling::LineStyle::Effect const& effect, Tiles::TerrainInfo const& terrain, Tiles::VectorInfo const& vector);
	
	// templated function to reduce verbosity
	template<typename VectorLayerT>
	void render(bgfx::ViewId const viewId, VectorLayerT const& layer, Tiles::Gathered const& gathered);

public:

	template<template<class, class...> class ContainerT, class... Additional>
	void debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds);

	static float AliasZoom(float const zoom);

#if !defined(PLATFORM_EMSCRIPTEN)	// Triple-buffered data
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures.getReady(); }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.getWorking().cullState; }

private:
	bool mCullStateChanged = false;

	inline void swapTripleBuffers() { if (mCullStateChanged) { mCullStateChanged = false; mVisibleFeatures.setReady(); } }
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.getWorking().cullState; }

	Utils::TripleBuffer<VisibleFeatures> mVisibleFeatures;
#else // no triple-buffering
	VisibleFeatures const& getVisibleFeatures() const { return mVisibleFeatures; }
	Pyramid::CullResult const& getFrameCullState() const { return mVisibleFeatures.cullState; }
private:
	bool mCullStateChanged = false;
	Pyramid::CullResult& getFrameCullState() { return mVisibleFeatures.cullState; }
	inline void swapTripleBuffers() { }

	VisibleFeatures mVisibleFeatures;
#endif

};

template<template<class, class...> class ContainerT, class... Additional>
void Viewport::debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds)
{
	mState.setCullingEnabled(false);

	for (size_t i = 0; i < 3; ++i) // We need to clear the debug cull state for each of the triple-buffered result
	{
		auto &cullState = getFrameCullState();
		cullState.reset();
		float avgLevel = 0.f;
		for (Tiles::TileId const& id : tileIds)
		{
			cullState.add(id);
		}
		cullState.avgLevel = avgLevel / float(cullState.tileIds.size());
		swapTripleBuffers();
		getFrameCullState();
	}
}

}
