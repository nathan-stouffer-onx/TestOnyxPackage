#ifndef __AABOX_DRAWER_H__
#define __AABOX_DRAWER_H__

#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ShaderEnums.h>

#include "Rendering/VertStructs.h"

namespace drawers
{
	// TODO wait and see if the this is a good way to architect our drawing code
	class AABoxDrawer
	{

	public:
		
		static void shutdown();

		static void draw(bgfx::ViewId viewId, const std::vector<lgal::world::AABB3d>& boxes);

	private:

		static std::vector<uint16_t> sIndices;
		static std::vector<uint16_t> sEdgeIndices;

		static bgfx::VertexBufferHandle sVertexBuffer;
		static bgfx::IndexBufferHandle sIndexBuffer;

		static bgfx::VertexBufferHandle sEdgeVertexBuffer;
		static bgfx::IndexBufferHandle sEdgeIndexBuffer;

		static void drawBoxes(bgfx::ViewId viewId, const std::vector<lgal::world::AABB3d>& boxes);
		static void drawEdges(bgfx::ViewId viewId, const std::vector<lgal::world::AABB3d>& boxes);

	};
}

#endif