#ifndef __FRUSTUM_DRAWER_H__
#define __FRUSTUM_DRAWER_H__

#include <vector>

#include <bgfx/bgfx.h>

#include "Camera/Frustum.h"

namespace drawers
{

	class FrustumDrawer
	{

	public:

		static void shutdown();
		
		static void draw(bgfx::ViewId viewId, lgal::world::Vector3 eye, const onyx::Camera::Frustum& frustum);
		static void draw(bgfx::ViewId viewId, lgal::world::Vector3 eye, const onyx::Camera::Frustum* frustum);

	private:

		static std::vector<uint16_t> sIndices;
		static std::vector<uint16_t> sEdgeIndices;

		static bgfx::VertexBufferHandle sVertexBuffer;
		static bgfx::IndexBufferHandle sIndexBuffer;

		static bgfx::VertexBufferHandle sEdgeVertexBuffer;
		static bgfx::IndexBufferHandle sEdgeIndexBuffer;

		static void drawPlanes(bgfx::ViewId viewId, const onyx::Camera::Frustum* frustum);
		static void drawEdges(bgfx::ViewId viewId, const onyx::Camera::Frustum* frustum);

	};

}

#endif