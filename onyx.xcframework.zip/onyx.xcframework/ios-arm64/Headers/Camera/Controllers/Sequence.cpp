#include "Sequence.h"

#include <cmath>
#include <algorithm>

namespace onyx {
namespace Camera {
namespace Controllers {

	Sequence::Sequence(std::vector<Point> const& points, Camera_time_t loopMS, Camera_time_t beginMS) :
		mPoints(points),
		mLoopTimeMS(loopMS),
		mBeginTimeMS(beginMS)
	{
		std::stable_sort(mPoints.begin(), mPoints.end(), [](Point const& a, Point const& b) -> bool { return a.beginTimeMS < b.beginTimeMS; });
	}

	CameraState Sequence::derivedUpdate(ControllerOptions const& options)
	{
		if (options.timeMS < mBeginTimeMS || mPoints.size() == 0)
		{
			return options.previousState;
		}
		else
		{
			// compute relative time -- account for looping
			Camera_time_t relativeTimeMS = std::fmod(options.timeMS - mBeginTimeMS, mLoopTimeMS);

			// account for the case where the first Point doest not start at t = 0
			relativeTimeMS = std::max(relativeTimeMS, mPoints[0].beginTimeMS);

			// compute index of the active controller
			size_t i = mPoints.size() - 1;
			while (relativeTimeMS < mPoints[i].beginTimeMS)		// TODO possibly make this a binary search
			{
				i--;
			}

			// call into active controller update method
			auto relOpts = options;
			relOpts.timeMS = relativeTimeMS;
			return mPoints[i].controller->update(relOpts);
		}
	}

} } }