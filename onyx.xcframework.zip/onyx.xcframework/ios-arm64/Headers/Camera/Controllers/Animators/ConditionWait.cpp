#include "ConditionWait.h"

namespace onyx::Camera::Controllers {

	CameraState ConditionWait::animationUpdate(Camera_time_t, Atlases::HeightAtlas const*)
	{
		mAnimationState = mCallback();

		return mBeginState;
	}

}