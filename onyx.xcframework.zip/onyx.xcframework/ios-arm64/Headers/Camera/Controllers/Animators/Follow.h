#ifndef __FOLLOW_CONTROLLER_H__
#define __FOLLOW_CONTROLLER_H__

#include "Animator.h"
#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* Camera controller that locks the camera to a point at a certain orientation
	* 
	* NOTE: User must supply a callback that outputs a location in world space to follow as well as
	*		a new camera heading and pitch.
	*
	*		If there is a change in position/orientation from
	*		the previous callback invocation, the interpolation animation will reset with the current CameraState
	*		as its start point and the new position/orientation as the end point.
	*/

	class Follow : public Animator
	{
	public:
		
		struct CamPosSphereCoords
		{
			lgal::world::Vector3 lookAt;
			MapMath::Spherical coords;	// Note that these coordinates are from the camera's perspective.
			CamPosSphereCoords(lgal::world::Vector3 const& _lookAt, lgal::world::Vector3 _coords) : lookAt{ _lookAt }, coords{}
			{
				coords.heading = _coords.x;
				coords.pitch = _coords.y;
				coords.radius = _coords.z;
			}

			CamPosSphereCoords(lgal::world::Vector3 const& _lookAt, MapMath::Spherical _coords) : lookAt{ _lookAt }, coords{ _coords }
			{}

			CamPosSphereCoords() : CamPosSphereCoords{ lgal::world::Vector3{0, 0, 0}, lgal::world::Vector3{ 0, 0, 0 } }
			{}
		};
		typedef std::function<CamPosSphereCoords()> GetCamPosSphereCoordsCallback_t;

		static constexpr world_float_t cDefaultRefreshCycleMS = 100.0;

		Follow(
			CameraState const& beginState,
			CamPosSphereCoords const& beginCamCoords,
			GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
			Camera_time_t refreshCycleMS = cDefaultRefreshCycleMS,
			Camera_time_t beginTimeMS = Utils::Timer::nowMS(),
			bool isCamOrientLockedToInitState = false
		);

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		// Camera state will match passed-in orientation. Pitch is locked between 0 to pi/2
		static CameraState getFollowEndState(CameraState const& initial, CamPosSphereCoords const& sphCoords);

		std::string getName() const override { return "Follow"; }

	private:
		Camera_time_t mRefreshCycleMS;
		Camera_time_t mRefreshStartMS;

		CameraState mEndState;
		GetCamPosSphereCoordsCallback_t const mGetCamPosSphereCoordsCallback;
		const bool mIsCamOrientLockedToInitState;
	};

} } }


#endif

