#ifndef __PATH_TRACE_CONTROLLER_H__
#define __PATH_TRACE_CONTROLLER_H__

#include <array>

#include <lucid/gal/Types.h>

#include "Animator.h"
#include "Camera/CameraController.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	class PathTrace : public Animator
	{
	public:

		struct Anchor
		{
			Camera_time_t timeMS;
			CameraState state;
		};

		// TODO possibly break this out into a class hierarchy with LinearPath, CubicHermitePath, BezierPath, and so on
		struct Path
		{
		public:

			Path(std::vector<Anchor> const& anchors);

			// uses cubic hermite spline interpolation -- https://en.wikipedia.org/wiki/Cubic_Hermite_spline
			CameraState interpolate(Camera_time_t const relativeTimeMS) const;

			struct LocalAnchors
			{
				std::array<Anchor const, 4> anchors;
				Camera_time_t t;
			};

		private:

			std::vector<Anchor> mAnchors;

			CameraState interpolateEdgeCases(Camera_time_t const relativeTimeMS) const;

			// takes in a const iterator to a vector element and approximates the derivative
			// using finite difference (one-sided at the end, two-sided otherwise)
			CameraState finiteDifference(std::vector<Anchor>::const_iterator iter) const;

		};

		// TODO possibly support loop option
		PathTrace(std::vector<Anchor> const& anchors, Camera_time_t const durationMS,
					Camera_time_t const beginMS = Utils::Timer::nowMS());

		CameraState animationUpdate(Camera_time_t const relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "PathTrace"; }

	private:

		Path mPath;

		Camera_time_t const mDurationMS;

		CameraState mEndState;

	};

} } }

#endif