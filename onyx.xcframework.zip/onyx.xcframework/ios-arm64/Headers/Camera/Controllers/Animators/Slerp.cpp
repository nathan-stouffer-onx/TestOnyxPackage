#include "Slerp.h"

#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	Slerp::Slerp(CameraState const& begin, TimingParams const &timing, CameraState const& end, TimeTransform::Types transform) :
		Animator(begin, timing, std::make_unique<Constraints::DefaultConstraints>()),
		mEndState(end),
		mTimeTransform(transform)
	{}

	CameraState Slerp::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) //  during animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = mCurrentTimeMS / mTiming.durationMS;

			// transform t according to the transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			return CameraState::slerp(mBeginState, mEndState, t);
		}
		else // past the animation time, just return the end state
		{
			return mEndState;
		}
	}

} } }