#include "Slerp.h"

#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	Slerp::Slerp(CameraState const& begin, CameraState const& end,
					Camera_time_t durationMS, TimeTransform::Types transform, Camera_time_t beginMS) :
		Animator(begin, beginMS, std::make_unique<Constraints::DefaultConstraints>()),
		mEndState(end),
		mDurationMS(durationMS),
		mTimeTransform(transform)
	{}

	CameraState Slerp::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		if (relativeTimeMS <= mDurationMS) // in animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = relativeTimeMS / mDurationMS;

			// transform t according to the transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			return CameraState::slerp(mBeginState, mEndState, t);
		}
		else // past the animation time, just return the end state
		{
			mAnimationState = State::COMPLETE;
			return mEndState;
		}
	}

} } }