#ifndef __WAIT_CONTROLLER_H__
#define __WAIT_CONTROLLER_H__

#include "Animator.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx::Camera::Controllers {

	// camera controller that does not change anything for a timed duration; the identity map

	class TimedWait final : public TimedAnimator
	{
	public:
		TimedWait(CameraState const& begin, Camera_time_t beginMS, Camera_time_t duration) :
			TimedAnimator(begin, beginMS, std::make_unique<Constraints::DefaultConstraints>(), duration)
		{}

		std::string getName() const override { return "TimedWait"; }

	private:

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

	};

}

#endif