#ifndef __WAIT_CONTROLLER_H__
#define __WAIT_CONTROLLER_H__

#include "Animator.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx::Camera::Controllers {

	// camera controller that does not change anything for a timed duration; the identity map

	class TimedWait final : public Animator
	{
	public:
		TimedWait(CameraState const& begin, TimingParams const & timing) :
			Animator(begin, timing, std::make_unique<Constraints::DefaultConstraints>())
		{}

		std::string getName() const override { return "TimedWait"; }

	private:

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

	};

}

#endif