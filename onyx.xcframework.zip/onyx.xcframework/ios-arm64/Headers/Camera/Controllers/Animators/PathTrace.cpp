#include "PathTrace.h"

#include <algorithm>

#include <System/OnyxException.h>

#include "Camera/Algorithm.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"
#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {
	
	PathTrace::Path::Path(std::vector<Anchor> const& anchors) :
		mAnchors(anchors)
	{
		ONYX_ASSERT(mAnchors.size() > 0, "cannot create Path without anchors");
		std::stable_sort(mAnchors.begin(), mAnchors.end(), [](Anchor const& a, Anchor const& b) -> bool { return a.timeMS < b.timeMS; });
	}

	CameraState PathTrace::Path::interpolate(Camera_time_t const relativeTimeMS) const
	{
		if (mAnchors.size() < 3)
		{
			return interpolateEdgeCases(relativeTimeMS);
		}
		else
		{
			if (relativeTimeMS <= mAnchors.front().timeMS)
			{
				return mAnchors.front().state;
			}
			else if (mAnchors.front().timeMS < relativeTimeMS && relativeTimeMS < mAnchors.back().timeMS)
			{
				// iterator pointing to the Anchor to the right of relativeTimeMS
				auto p1Iter = std::upper_bound(mAnchors.begin(), mAnchors.end(), relativeTimeMS, 
												[](Camera_time_t value, Anchor const& anchor) -> bool { return value < anchor.timeMS; });
				
				auto p0Iter = p1Iter - 1;

				// grab our anchors
				Anchor const& p0 = *p0Iter;
				Anchor const& p1 = *p1Iter;
				
				Camera_time_t duration = p1.timeMS - p0.timeMS;
				Camera_time_t t = (relativeTimeMS - p0.timeMS) / duration;

				// approximate derivatives with finite difference
				CameraState deriv0 = finiteDifference(p0Iter);
				CameraState deriv1 = finiteDifference(p1Iter);

				// scale the derivatives because CameraState::cubicHermiteSpline assumes interpolation on [0, 1]
				CameraState m0 = { duration * deriv0.position, duration * deriv0.heading, duration * deriv0.pitch };
				CameraState m1 = { duration * deriv1.position, duration * deriv1.heading, duration * deriv1.pitch };

				return CameraState::cubicHermiteSpline(p0.state, m0, p1.state, m1, t);
			}
			else
			{
				return mAnchors.back().state;
			}
		}
	}

	CameraState PathTrace::Path::finiteDifference(std::vector<Anchor>::const_iterator iter) const
	{
		// derivative approximations
		lgal::world::Vector3 posDeriv = { 0, 0, 0 };
		world_float_t headingDeriv = 0.0;
		world_float_t pitchDeriv = 0.0;

		bool hasLeft  = iter != mAnchors.begin();
		bool hasRight = iter + 1 != mAnchors.end();
		
		if (hasLeft)		// approximate derivative only on the left
		{
			Anchor const& left = *(iter - 1);
			Anchor const& point = *iter;

			Camera_time_t deltaT = point.timeMS - left.timeMS;

			// account for heading being on a circle
			world_float_t heading = lmath::closestEquivalentAngle(left.state.heading, point.state.heading);

			posDeriv = posDeriv + (point.state.position - left.state.position) / deltaT;
			headingDeriv += (heading - left.state.heading) / deltaT;
			pitchDeriv += (point.state.pitch - left.state.pitch) / deltaT;
		}

		if (hasRight)		// approximate derivative only on the right
		{
			Anchor const& point = *iter;
			Anchor const& right = *(iter + 1);

			Camera_time_t deltaT = right.timeMS - point.timeMS;

			// account for heading being on a circle
			world_float_t heading = lmath::closestEquivalentAngle(point.state.heading, right.state.heading);

			posDeriv = posDeriv + (right.state.position - point.state.position) / deltaT;
			headingDeriv += (heading - point.state.heading) / deltaT;
			pitchDeriv += (right.state.pitch - point.state.pitch) / deltaT;
		}

		if (hasLeft && hasRight)	// if we have both left and right, average the derivatives
		{
			posDeriv = 0.5 * posDeriv;
			headingDeriv = 0.5 * headingDeriv;
			pitchDeriv = 0.5 * pitchDeriv;
		}

		return { posDeriv, headingDeriv, pitchDeriv };
	}

	CameraState PathTrace::Path::interpolateEdgeCases(Camera_time_t const relativeTimeMS) const
	{
		if (mAnchors.size() == 1)
		{
			return mAnchors[0].state;
		}
		else if (mAnchors.size() == 2)
		{
			Anchor const& front = mAnchors[0];
			Anchor const& back  = mAnchors[1];

			if (relativeTimeMS < front.timeMS)
			{
				return front.state;
			}
			else if (front.timeMS <= relativeTimeMS && relativeTimeMS <= back.timeMS)
			{
				Camera_time_t t = (relativeTimeMS - front.timeMS) / (back.timeMS - front.timeMS);
				t = TimeTransform::evaluate(TimeTransform::Types::SMOOTHSTEP, t);
				return CameraState::slerp(front.state, back.state, t);
			}
			else
			{
				return back.state;
			}
		}

		ONYX_THROW("missed a condition for edge case in PathTrace");
		return CameraState{};
	}

	PathTrace::PathTrace(std::vector<Anchor> const& anchors, Camera_time_t const durationMS, Camera_time_t const beginMS) :
		// NOTE: mBeginState is overwritten later in this constructor. initially, we just pass in the default CameraState
		Animator(CameraState{}, beginMS, std::make_unique<Constraints::DefaultConstraints>()),
		mPath(anchors),
		mDurationMS(durationMS)
	{
		mBeginState = animationUpdate(0.0, nullptr);			// NOTE: compute mBeginState here so all initialization is complete
		mEndState = animationUpdate(mDurationMS, nullptr);
	}

	CameraState PathTrace::animationUpdate(Camera_time_t const relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		if (relativeTimeMS <= mDurationMS)
		{
			mAnimationState = State::ACTIVE;
			return mPath.interpolate(relativeTimeMS);
		}
		else
		{
			mAnimationState = State::COMPLETE;
			return mEndState;
		}
	}

} } }