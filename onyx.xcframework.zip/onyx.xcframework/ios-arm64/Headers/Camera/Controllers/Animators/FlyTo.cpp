#include "FlyTo.h"

#include <cmath>

#include "Camera/Algorithm.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"
#include "Camera/TimeTransform.h"

namespace onyx::Camera::Controllers
{

	static constexpr world_float_t cChangeDirectionThreshold = 200.0;

	FlyTo::FlyTo(CameraState const& begin, TimingParams const& timing, CameraState const& end) :
		Animator(begin, timing, std::make_unique<Constraints::DefaultConstraints>()),
		mCubicBezierAnchor0(begin),
		mCubicBezierAnchor3(end)
	{
		computeAnchors(begin, end);
	}

	FlyTo::FlyTo(CameraState const& begin, CameraState const& end,
		Camera_time_t const durationMS, Camera_time_t const beginMS)
		: FlyTo(begin, { beginMS, durationMS }, end)
	{ }

	FlyTo::FlyTo(CameraState const& begin, TimingParams const& timing, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical) :
		FlyTo(begin, timing, CameraState{ lookPt, spherical.heading, spherical.pitch, spherical.radius, begin.fov, begin.aspect, begin.nearClip, begin.farClip })
	{}

	CameraState FlyTo::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) //  during animation window, animate
		{
			// t is guaranteed to be in [0, 1]
			auto t = mCurrentTimeMS / mTiming.durationMS;

			// transform t to begin and end the animation smoothly
			t = TimeTransform::evaluate(TimeTransform::Types::SMOOTHSTEP, t);

			// compute control points for the quadratic bezier calculation
			auto quadraticBezierAnchor0 = CameraState::slerp(mCubicBezierAnchor0, mCubicBezierAnchor1, t);
			auto quadraticBezierAnchor1 = CameraState::slerp(mCubicBezierAnchor1, mCubicBezierAnchor2, t);
			auto quadraticBezierAnchor2 = CameraState::slerp(mCubicBezierAnchor2, mCubicBezierAnchor3, t);
			
			// compute control points for the linear bezier calculation
			auto linearBezierAnchor0 = CameraState::slerp(quadraticBezierAnchor0, quadraticBezierAnchor1, t);
			auto linearBezierAnchor1 = CameraState::slerp(quadraticBezierAnchor1, quadraticBezierAnchor2, t);
			
			// compute and return the linear bezier calculation
			auto interpolated = CameraState::slerp(linearBezierAnchor0, linearBezierAnchor1, t);
			return interpolated;
		}
		else
		{
			return mCubicBezierAnchor3;
		}
	}

	void FlyTo::computeAnchors(CameraState const& begin, CameraState const& end)
	{
		mCubicBezierAnchor0 = begin;
		mCubicBezierAnchor3 = end;

		auto delta = end.position - begin.position;
		auto dist = lmath::len(delta.xy);

		auto distanceStrength = std::clamp(dist / Tiles::TileId::LevelToTileExtent(5), 0.0, 1.0);
		auto heightStrength = 1.0 - std::clamp((begin.position.z + end.position.z) / Constraints::ConstraintHandler::cGlobalMaxZ, 0.0, 1.0);
		auto bump = distanceStrength * heightStrength * dist;

		// set the 1 anchor point
		mCubicBezierAnchor1 = begin;
		mCubicBezierAnchor1.position.z = lmath::lerp(begin.position.z, end.position.z, 0.5) + bump;

		// set the 2 anchor point
		mCubicBezierAnchor2 = end;
		mCubicBezierAnchor2.position.z = lmath::lerp(begin.position.z, end.position.z, 0.5) + bump;

		// smoothly change pitch/heading based on how far apart the beginning and end are
		auto t = std::min(lmath::len(delta) / cChangeDirectionThreshold, 1.0);

		mCubicBezierAnchor1.pitch = lmath::lerp(mCubicBezierAnchor1.pitch, 0.0, t);
		mCubicBezierAnchor2.pitch = lmath::lerp(mCubicBezierAnchor2.pitch, 0.0, t);

		// set intermediate anchor points with a heading in the direction from begin to end
		//auto heading = CameraState::headingTo(begin, end);
		//mCubicBezierAnchor1.heading = lmath::lerp(mCubicBezierAnchor1.heading, heading, t);
		//mCubicBezierAnchor2.heading = lmath::lerp(mCubicBezierAnchor2.heading, heading, t);
	}

	FlyTo2D::FlyTo2D(CameraState const& begin, TimingParams const& timing, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical) :
		FlyTo(begin, timing, { lookPt, 0.0 }, spherical),
		mLookPoint(lookPt),
		mSpherical(spherical)
	{}

	CameraState FlyTo2D::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas)
	{
		// update anchors
		float height = (atlas) ? atlas->heightAt(mLookPoint) : 0.0f;
		lgal::world::Vector3 lookPt = { mLookPoint, static_cast<world_float_t>(height) };
		CameraState end = { lookPt, mSpherical.heading, mSpherical.pitch, mSpherical.radius };

		computeAnchors(mBeginState, end);

		// call into base class
		return FlyTo::animationUpdate(relativeTimeMS, atlas);
	}

}