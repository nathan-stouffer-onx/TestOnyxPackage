#include "OrbitOn.h"

#include <lucid/math/Algorithm.h>

#include "Camera/Algorithm.h"
#include "Camera/Controllers/Constraints/OrbitConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	OrbitOn::OrbitOn(CameraState const& initial, lgal::world::Vector3 const& focus,
						world_float_t deltaHeading, world_float_t deltaPitch, world_float_t radiusMultiplier, 
						Camera_time_t durationMS, TimeTransform::Types transform, Camera_time_t beginMS) :
		Animator(initial, beginMS, std::make_unique<Constraints::OrbitConstraints>(initial, focus, beginMS)),
		mOrbitPoint(focus),
		mDeltaHeading(deltaHeading),
		mDeltaPitch(deltaPitch),
		mDeltaRadius((radiusMultiplier - 1.0) * len(initial.position - focus)),
		mEndState(Math::orbit(focus, initial, mDeltaHeading, mDeltaPitch, mDeltaRadius)),
		mDurationMS(durationMS),
		mTimeTransform(transform)
	{}

	CameraState OrbitOn::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		if (relativeTimeMS <= mDurationMS) // in animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = relativeTimeMS / mDurationMS;

			// transform t according the time transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			// lerp the values
			auto deltaHeading = lmath::lerp(0.0, mDeltaHeading, t);
			auto deltaPitch = lmath::lerp(0.0, mDeltaPitch, t);
			auto deltaRadius = lmath::lerp(0.0, mDeltaRadius, t);

			return Math::orbit(mOrbitPoint, mBeginState, deltaHeading, deltaPitch, deltaRadius);
		}
		else // past the animation time, just return the end state
		{
			mAnimationState = State::COMPLETE;
			return mEndState;
		}
	}

} } }