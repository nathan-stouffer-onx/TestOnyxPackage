#include "ZoomOn.h"

#include "Camera/Controllers/Constraints/ZoomConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	ZoomOn::ZoomOn(CameraState const& initial, lgal::world::Vector3 const& focus, world_float_t scalar,
					Camera_time_t durationMS, TimeTransform::Types transform, Camera_time_t beginMS) :
		TimedAnimator(initial, beginMS, std::make_unique<Constraints::ZoomConstraints>(initial, focus, beginMS), durationMS),
		mFocusPoint(focus),
		mInitialOffset(initial.position - focus),
		mEndState(initial),
		mTimeTransform(transform)
	{
		mEndState.position = mFocusPoint + scalar * mInitialOffset;
	}

	CameraState ZoomOn::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mDurationMS) // in animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = mCurrentTimeMS / mDurationMS;

			// transform t according to the transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			// compute the camera state
			return CameraState::lerp(mBeginState, mEndState, t);
		}
		else // past the animation time, just return the end state
		{
			return mEndState;
		}
	}

} } }