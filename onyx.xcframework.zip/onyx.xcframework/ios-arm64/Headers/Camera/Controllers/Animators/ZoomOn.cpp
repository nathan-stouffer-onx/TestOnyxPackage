#include "ZoomOn.h"

#include "Camera/Controllers/Constraints/ZoomConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	ZoomOn::ZoomOn(CameraState const& initial, TimingParams const& timing, lgal::world::Vector3 const& focus, world_float_t scalar,
					TimeTransform::Types transform) :
		Animator(initial, timing, std::make_unique<Constraints::ZoomConstraints>(initial, focus, timing.beginTimeMS)),
		mFocusPoint(focus),
		mInitialOffset(initial.position - focus),
		mEndState(initial),
		mTimeTransform(transform)
	{
		mEndState.position = mFocusPoint + scalar * mInitialOffset;
	}

	CameraState ZoomOn::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) // in animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = mCurrentTimeMS / mTiming.durationMS;

			// transform t according to the transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			// compute the camera state
			return CameraState::lerp(mBeginState, mEndState, t);
		}
		else // past the animation time, just return the end state
		{
			return mEndState;
		}
	}

} } }