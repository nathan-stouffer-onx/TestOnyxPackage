#ifndef __SLERP_CONTROLLER_H__
#define __SLERP_CONTROLLER_H__

#include "Animator.h"
#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that will slerp between the two controllers

	class Slerp : public TimedAnimator
	{
	public:

		Slerp(CameraState const& begin, CameraState const& end, 
				Camera_time_t durationMS = 3000.0, TimeTransform::Types transform = TimeTransform::Types::LINEAR,
				Camera_time_t beginTimeMS = Utils::Timer::nowMS());

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "Slerp"; }

	private:

		CameraState const mEndState;

		TimeTransform::Types const mTimeTransform;

	};

} } }

#endif