#ifndef __ORBIT_ATTRACT_CONTROLLER_H__
#define __ORBIT_ATTRACT_CONTROLLER_H__

#include "Animator.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// controller that will animate an "attract" interaction. the animation will begin at 
	// the initial state and orbit the camera heading around the focus

	class OrbitAttract : public Animator
	{
	public:

		// defaults to one revolution every sixty seconds
		OrbitAttract(CameraState const& initial, TimingParams const &timing, lgal::world::Vector3 const& focus, 
						world_float_t radPerMS = lmath::constants::two_pi<world_float_t>() / 60000.0);

		OrbitAttract(CameraState const& initial, lgal::world::Vector3 const& focus,
			world_float_t radPerMS = lmath::constants::two_pi<world_float_t>() / 60000.0,
			Camera_time_t durationMS = TimingParams::cMaxDurationMS, Camera_time_t beginMS = Utils::Timer::nowMS())
			: OrbitAttract(initial, TimingParams(beginMS, durationMS), focus, radPerMS)
		{ }


		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "OrbitAttract"; }

		std::vector<CameraState> highlights() const override;

	private:

		lgal::world::Vector3 const mOrbitPoint;

		Camera_time_t const mRadPerMS;

		CameraState mEndState;

	};

} } }

#endif