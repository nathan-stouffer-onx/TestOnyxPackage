#ifndef __ANIMATOR_CONTROLLER_H__
#define __ANIMATOR_CONTROLLER_H__

#include <memory>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Camera/Controllers/Constraints/ConstraintHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* A class that abstracts away animations. Animator inherits from CameraController and overrides the pure virtual 
	* method CameraController::derivedUpdate. Animator defines a pure virtual method animationUpdate that it's derived 
	* controllers must implement. When a derived controller completes its animation, it should set mAnimationState to 
	* State::COMPLETE so that Animator knows to trigger constraint animations.
	* 
	* Additionally, Animator requires a ConstraintHandler. The method InputHandler::animationUpdate will handle the 
	* logic of what mode each of the handlers should be in. If a derived controller doesn't want to have constraints, 
	* it can provide the default constraint handler.
	*/

	class Animator : public CameraController
	{

	public:

		enum class State
		{
			ACTIVE,
			COMPLETE
		};

		Animator(CameraState const& begin, Camera_time_t const beginMS, std::unique_ptr<Constraints::ConstraintHandler> constraints);
		virtual ~Animator() {}

		virtual CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) = 0;

		State getState() const { return mAnimationState; }

	protected:

		State mAnimationState = State::ACTIVE;

		// Note: we leave end state to the derived controllers so that the value can be updated if necessary
		// eg: if FlyTo is created with a 2d look point, we may want to update the height as more tiles load
		CameraState mBeginState;
		Camera_time_t const mBeginTimeMS;

	private:

		CameraState derivedUpdate(ControllerOptions const& options) final override;

		std::unique_ptr<Constraints::ConstraintHandler> mConstraintHandler;

	};

} } }

#endif