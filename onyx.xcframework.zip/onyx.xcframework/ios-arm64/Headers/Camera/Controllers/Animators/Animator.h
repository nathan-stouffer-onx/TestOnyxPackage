#ifndef __ANIMATOR_CONTROLLER_H__
#define __ANIMATOR_CONTROLLER_H__

#include <memory>
#include <algorithm>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Camera/Controllers/Constraints/ConstraintHandler.h"

namespace onyx::Camera::Controllers
{

	/*
	* A class that abstracts away animations. Animator inherits from CameraController and overrides the pure virtual 
	* method CameraController::derivedUpdate. Animator defines a pure virtual method animationUpdate that it's derived 
	* controllers must implement. When a derived controller completes its animation, it should set mAnimationState to 
	* State::COMPLETE so that Animator knows to trigger constraint animations.
	* 
	* Additionally, Animator requires a ConstraintHandler. The method InputHandler::animationUpdate will handle the 
	* logic of what mode each of the handlers should be in. If a derived controller doesn't want to have constraints, 
	* it can provide the default constraint handler.
	*/

	class Animator : public CameraController
	{

	public:

		struct TimingParams
		{
			static constexpr Camera_time_t cMaxDurationMS = std::numeric_limits<Camera_time_t>::max();
			static constexpr Camera_time_t cDefaultDurationMS = 0;

			Camera_time_t beginTimeMS = Utils::Timer::nowMS();
			Camera_time_t durationMS = cDefaultDurationMS;
			Camera_time_t loopTimeMS = 0;
			Camera_time_t animationSpeed = 1;
			size_t currentLoop = 0;
			TimingParams() {}
			TimingParams(Camera_time_t beginTimeMS, Camera_time_t durationMS = 0, Camera_time_t loopTimeMS = 0, Camera_time_t animationSpeed = 1)
				: beginTimeMS(beginTimeMS)
				, durationMS(durationMS)
				, loopTimeMS(loopTimeMS)
				, animationSpeed(animationSpeed)
			{}

			static inline TimingParams Duration(Camera_time_t duration) {
				return { Utils::Timer::nowMS(), duration };
			}

			inline bool hasLoop() const { return loopTimeMS != 0 && loopTimeMS >= durationMS && loopTimeMS != std::numeric_limits<Camera_time_t>::max(); }

			Camera_time_t getRelativeTimeMS(Camera_time_t absoluteTime)
			{
				auto result = (absoluteTime - beginTimeMS) * animationSpeed;
				
				return getLoopRelativeTimeMS(result);
			}

			Camera_time_t getLoopRelativeTimeMS(Camera_time_t relativeTime)
			{
				auto result = relativeTime;

				if (hasLoop())
				{
					currentLoop = size_t(result / loopTimeMS * animationSpeed);
					result = std::fmod(result, loopTimeMS * animationSpeed);
				}

				return result;
			}

			Camera_time_t getDurationMS() const
			{
				return durationMS / animationSpeed;
			}

			Camera_time_t getLoopTimeMS() const
			{
				return loopTimeMS / animationSpeed;
			}
		};

		enum class State
		{
			ACTIVE,
			COMPLETE
		};

		Animator(CameraState const& begin, TimingParams const &timing, std::unique_ptr<Constraints::ConstraintHandler> constraints);
		virtual ~Animator() {}

		virtual CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) = 0;

		State getState() const { return mAnimationState; }

		virtual void restart(Camera_time_t newBeginMS) { mTiming.beginTimeMS = newBeginMS; mAnimationState = State::ACTIVE; }
		void restart() { restart(Utils::Timer::nowMS()); }

		TimingParams getTiming() const { return mTiming; }
		void setTiming(TimingParams const &timing) { mTiming = timing; }

		void setAnimationSpeed(Camera_time_t speed) { mTiming.animationSpeed = std::max(0.000001, speed); }
		Camera_time_t getAnimationSpeed() const { return mTiming.animationSpeed; }
		Camera_time_t beginTimeMS() const { return mTiming.beginTimeMS; }

		/// <summary>
		/// Returns the duration of the animation in MS
		/// </summary>
		virtual Camera_time_t getDurationMS() const { return mTiming.getDurationMS(); }
		virtual Camera_time_t getLoopTimeMS() const { return mTiming.getLoopTimeMS(); }

		/// <summary>
		/// Returns the current time for the animation in MS
		/// </summary>
		virtual Camera_time_t getCurrentTimeMS() const { return 0; }

		CameraState getBeginState() const { return mBeginState; }

		inline bool hasLoop() const { return mTiming.loopTimeMS >= mTiming.durationMS && mTiming.loopTimeMS != std::numeric_limits<Camera_time_t>::max(); }

	protected:

		State mAnimationState = State::ACTIVE;

		// Note: we leave end state to the derived controllers so that the value can be updated if necessary
		// eg: if FlyTo is created with a 2d look point, we may want to update the height as more tiles load
		CameraState mBeginState;
		
		TimingParams mTiming;
		Camera_time_t mCurrentTimeMS = 0;

		inline void setCurrentTimeMS(Camera_time_t relativeTimeMS)
		{
			mCurrentTimeMS = std::max(Camera_time_t(0), std::min(mTiming.durationMS, relativeTimeMS));

			mAnimationState = mCurrentTimeMS < mTiming.durationMS ? State::ACTIVE : State::COMPLETE;
		}

	private:

		CameraState derivedUpdate(ControllerOptions const& options) final override;

		std::unique_ptr<Constraints::ConstraintHandler> mConstraintHandler;

	};

	using SharedAnimatorT = std::shared_ptr<Animator>;

	template<class _Controller, class... _Args>
	inline static SharedAnimatorT make_animator(_Args&&... args)
	{
		return std::make_shared<_Controller>(args...);
	}

}

#endif