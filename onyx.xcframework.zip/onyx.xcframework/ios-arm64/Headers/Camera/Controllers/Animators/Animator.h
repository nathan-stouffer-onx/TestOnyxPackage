#ifndef __ANIMATOR_CONTROLLER_H__
#define __ANIMATOR_CONTROLLER_H__

#include <memory>
#include <algorithm>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Camera/Controllers/Constraints/ConstraintHandler.h"

namespace onyx::Camera::Controllers
{

	/*
	* A class that abstracts away animations. Animator inherits from CameraController and overrides the pure virtual 
	* method CameraController::derivedUpdate. Animator defines a pure virtual method animationUpdate that it's derived 
	* controllers must implement. When a derived controller completes its animation, it should set mAnimationState to 
	* State::COMPLETE so that Animator knows to trigger constraint animations.
	* 
	* Additionally, Animator requires a ConstraintHandler. The method InputHandler::animationUpdate will handle the 
	* logic of what mode each of the handlers should be in. If a derived controller doesn't want to have constraints, 
	* it can provide the default constraint handler.
	*/

	class Animator : public CameraController
	{

	public:

		enum class State
		{
			ACTIVE,
			COMPLETE
		};

		Animator(CameraState const& begin, Camera_time_t const beginMS, std::unique_ptr<Constraints::ConstraintHandler> constraints);
		virtual ~Animator() {}

		virtual CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) = 0;

		State getState() const { return mAnimationState; }

		void reset(Camera_time_t newBeginMS) { mBeginTimeMS = newBeginMS; }
		void reset() { reset(Utils::Timer::nowMS()); }

		void setAnimationSpeed(Camera_time_t speed) { mAnimationSpeed = std::max(0.000001, speed); }
		Camera_time_t getAnimationSpeed() const { return mAnimationSpeed; }
		Camera_time_t beginTimeMS() const { return mBeginTimeMS; }
		
		/// <summary>
		/// Returns the duration of the animation in MS
		/// </summary>
		virtual Camera_time_t getDurationMS() const { return 0; }
		/// <summary>
		/// Returns the current time for the animation in MS
		/// </summary>
		virtual Camera_time_t getCurrentTimeMS() const { return 0; }

	protected:

		State mAnimationState = State::ACTIVE;

		// Note: we leave end state to the derived controllers so that the value can be updated if necessary
		// eg: if FlyTo is created with a 2d look point, we may want to update the height as more tiles load
		CameraState mBeginState;
		Camera_time_t mBeginTimeMS;
		Camera_time_t mAnimationSpeed = 1.f;

	private:

		CameraState derivedUpdate(ControllerOptions const& options) final override;

		std::unique_ptr<Constraints::ConstraintHandler> mConstraintHandler;

	};

	class TimedAnimator : public Animator
	{
	public:
		TimedAnimator(CameraState const& begin, Camera_time_t const beginMS, std::unique_ptr<Constraints::ConstraintHandler> constraints, Camera_time_t durationMS)
			: Animator(begin, beginMS, std::move(constraints))
			, mDurationMS(durationMS)
		{

		}
		Camera_time_t getDurationMS() const override { return mDurationMS; }
		Camera_time_t getCurrentTimeMS() const override { return mCurrentTimeMS; }

	protected:

		inline void setCurrentTimeMS(Camera_time_t value)
		{
			mCurrentTimeMS = std::max(Camera_time_t(0), std::min(mDurationMS, value));
			mAnimationState = mCurrentTimeMS < mDurationMS ? State::ACTIVE : State::COMPLETE;
		}
		
		Camera_time_t mDurationMS;
		Camera_time_t mCurrentTimeMS = 0;
	};

	using SharedAnimatorT = std::shared_ptr<Animator>;

	template<class _Controller, class... _Args>
	inline static SharedAnimatorT make_animator(_Args&&... args)
	{
		return std::make_shared<_Controller>(args...);
	}

}

#endif