#include "Follow.h"

#include "Camera/Algorithm.h"
#include "Camera/Controllers/Constraints/OrbitConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	Follow::Follow(
		CameraState const& beginState,
		CamPosSphereCoords const& beginCamCoords,
		GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		Camera_time_t refreshCycleMS,
		Camera_time_t beginTimeMS,
		bool isCamOrientLockedToInitState
	) :
		Animator{ beginState, { beginTimeMS },
			std::make_unique<Constraints::OrbitConstraints>( beginState, beginCamCoords.lookAt, beginTimeMS ) },
		mRefreshCycleMS{ refreshCycleMS }, mRefreshStartMS{ beginTimeMS },
		mEndState{beginState}, mGetCamPosSphereCoordsCallback{getCamPosSphereCoordsCallback},
		mIsCamOrientLockedToInitState{ isCamOrientLockedToInitState }
	{
		auto camCoordsInner = beginCamCoords;
		if (mIsCamOrientLockedToInitState)
		{
			camCoordsInner.coords.heading = mBeginState.heading;
			camCoordsInner.coords.pitch = mBeginState.pitch;
		}
		mEndState = getFollowEndState(beginState, camCoordsInner);
	}

	CameraState Follow::animationUpdate(Camera_time_t fullRelativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		// TODO: I'm not a fan of overriding the meaning of the passed-in parameter here. I've made a coupling with the implementation
		//  of how Animator uses this function. This suggeststhat either the Animator class needs to change or Follow needs not be an Animator.
		auto actualTimeMS = fullRelativeTimeMS + mTiming.beginTimeMS;
		auto relativeTimeMS = actualTimeMS - mRefreshStartMS;

		auto t = relativeTimeMS / mRefreshCycleMS;
		t = TimeTransform::evaluate(TimeTransform::Types::LINEAR, t);
		auto currState = CameraState::slerp(mBeginState, mEndState, t);
		
		auto camCoords = mGetCamPosSphereCoordsCallback();
		if (mIsCamOrientLockedToInitState)
		{
			camCoords.coords.heading = mBeginState.heading;
			camCoords.coords.pitch = mBeginState.pitch;
		}
		auto newEndState = getFollowEndState(currState, camCoords);
		
		// I'd usually be wary of floating point equality comparisons but the unit tests haven't failed and visuals look fine
		if (newEndState != mEndState)
		{
			mEndState = newEndState;
			// Don't use Utils::Timer::Now() here since Sequence is not adhering to that timeframe.
			mRefreshStartMS = actualTimeMS;	
			mBeginState = currState;
		}

		return currState;
	}

	CameraState Follow::getFollowEndState(CameraState const& initial, CamPosSphereCoords const& sphCoords)
	{
		CameraState endState{ initial };

		endState.position = sphCoords.lookAt - sphCoords.coords.toEuclidean();	
		endState.pitch = sphCoords.coords.pitch;
		endState.heading = sphCoords.coords.heading;

		return endState;
	}

} } }

