#include "TimedWait.h"

namespace onyx::Camera::Controllers {

	CameraState TimedWait::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const*)
	{
		setCurrentTimeMS(relativeTimeMS);
		
		return mBeginState;
	}

}