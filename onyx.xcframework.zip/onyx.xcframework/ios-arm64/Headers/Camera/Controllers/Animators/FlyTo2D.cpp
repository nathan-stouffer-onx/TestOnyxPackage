#include "FlyTo2D.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	FlyTo2D::FlyTo2D(CameraState const& begin, TimingParams const& timing, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical) :
		FlyTo(begin, timing, { lookPt, 0.0 }, spherical),
		mLookPoint(lookPt),
		mSpherical(spherical)
	{}

	CameraState FlyTo2D::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas)
	{
		// update anchors
		float height = (atlas) ? atlas->heightAt(mLookPoint) : 0.0f;
		lgal::world::Vector3 lookPt = { mLookPoint, static_cast<world_float_t>(height) };
		CameraState end = { lookPt, mSpherical.heading, mSpherical.pitch, mSpherical.radius };

		computeAnchors(mBeginState, end);

		// call into base class
		return FlyTo::animationUpdate(relativeTimeMS, atlas);
	}

} } }