#ifndef __ZOOM_ON_CONTROLLER_H__
#define __ZOOM_ON_CONTROLLER_H__

#include "Animator.h"
#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/**
	 * ZoomOn animates a zoom interaction. The animation will begin at the initial CameraState and change
	 * the radius based on the passed in value of scalar. Scalar should be in [0, +inf)
	 */
	class ZoomOn : public Animator
	{
	public:

		ZoomOn(CameraState const& initial, TimingParams const& timing, lgal::world::Vector3 const& focus, world_float_t scalar,
				TimeTransform::Types transform = TimeTransform::Types::QUADRATIC_EASE_OUT
				);

		ZoomOn(CameraState const& initial, lgal::world::Vector3 const& focus, world_float_t scalar,
			Camera_time_t durationMS, TimeTransform::Types transform = TimeTransform::Types::QUADRATIC_EASE_OUT,
			Camera_time_t beginMS = Utils::Timer::nowMS())
			: ZoomOn(initial, TimingParams(beginMS, durationMS), focus, scalar, transform)
		{ }

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "ZoomOn"; }

	private:

		lgal::world::Vector3 const mFocusPoint;
		lgal::world::Vector3 const mInitialOffset;
		
		CameraState mEndState;

		TimeTransform::Types const mTimeTransform;

	};

} } }

#endif