#include "OrbitAttract.h"

#include "Camera/Algorithm.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	static constexpr uint8_t cHighlightStateCount = 4;

	OrbitAttract::OrbitAttract(CameraState const& initial, TimingParams const& timing, lgal::world::Vector3 const& focus, world_float_t radPerMS) :
		Animator(initial, timing, std::make_unique<Constraints::DefaultConstraints>()),
		mOrbitPoint(focus),
		mRadPerMS(radPerMS),
		mEndState(initial)
	{
		mEndState = Math::orbit(mOrbitPoint, mBeginState, mTiming.durationMS * mRadPerMS, 0.0, 0.0);
	}

	CameraState OrbitAttract::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) //  during animation window, animate
		{
			return Math::orbit(mOrbitPoint, mBeginState, mCurrentTimeMS * mRadPerMS, 0.0, 0.0);
		}
		else // beyond animation windows, return state at the end
		{
			return mEndState;
		}
	}

	std::vector<CameraState> OrbitAttract::highlights() const
	{
		std::vector<CameraState> states;
		states.reserve(cHighlightStateCount);

		if constexpr (cHighlightStateCount > 0)
		{
			auto period = lmath::constants::two_pi<world_float_t>() / std::abs(mRadPerMS);
			// interval of time between to highlight states
			auto deltaT = period / world_float_t(cHighlightStateCount);
			for (uint8_t i = 0; i < cHighlightStateCount; i++)
			{
				// incorporate mRadPerMS in this computation so states are requested in the right order
				CameraState orbited = Math::orbit(mOrbitPoint, mBeginState, i * deltaT * mRadPerMS, 0.0, 0.0);

				// make sure heading is in [0, 2pi]
				orbited.heading = std::fmod(orbited.heading, lmath::constants::two_pi<world_float_t>());
				if (orbited.heading < 0.0)
				{
					orbited.heading += lmath::constants::two_pi<world_float_t>();
				}

				states.push_back(orbited);
			}
		}

		return states;
	}


} } }