#ifndef __ANIMATION_SEQUENCE_CONTROLLER_H__
#define __ANIMATION_SEQUENCE_CONTROLLER_H__

#include <vector>
#include <memory>
#include <string>
#include <limits>

#include "Camera/Controllers/Animators/Animator.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* This controller is represents a sequence of other Animation controllers. As input, it takes a list of
	* animation controllers. Each frame, updates the current controller and then checks to see if it has
	* completed its animation, and if so, moves on to the next in the sequence.  Each controller in the
	* sequence should have a begin time of 0, as the AnimationSequence will handle the relative start times
	* automatically.
	* 
	* If desired, it is possible to pass in another AnimationSequence as part of the sequence. Looping can
	* be achieved by passing in the duration of the loop as loopMS.
	*/

	class AnimationSequence : public Animator
	{

	public:

		using CamSequenceT = std::vector<std::shared_ptr<Animator>>;

		AnimationSequence(CameraState const& beginState, CamSequenceT const& sequence, Camera_time_t loopMS = std::numeric_limits<Camera_time_t>::max(),
					Camera_time_t beginMS = Utils::Timer::nowMS());

		std::string getName() const override;
		std::string getDesc() const override;

	private:

		CamSequenceT mAnimatorSequence;
		size_t mCurrentStep = 0;
		size_t mCurrentLoop = 0;

		Camera_time_t mLoopTimeMS;
		Camera_time_t mCurrentStepRelativeTimeMS = 0;
		Camera_time_t mCurrentRelativeTimeMS = 0;
		CameraState mPreviousState;

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

	};

} } }

#endif