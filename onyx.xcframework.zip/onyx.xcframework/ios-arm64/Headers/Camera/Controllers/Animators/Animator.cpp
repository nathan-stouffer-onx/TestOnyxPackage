#include "Animator.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	Animator::Animator(CameraState const& begin, Camera_time_t const beginMS, std::unique_ptr<Constraints::ConstraintHandler> constraints) :
		mBeginState(begin),
		mBeginTimeMS(beginMS),
		mConstraintHandler(std::move(constraints))
	{}

	CameraState Animator::derivedUpdate(ControllerOptions const& options)
	{
		if (options.timeMS < mBeginTimeMS)
		{
			return mBeginState;
		}
		else
		{
			State old = mAnimationState;

			// compute the update from the input
			auto relativeTimeMS = options.timeMS - mBeginTimeMS;
			CameraState nextState = animationUpdate(relativeTimeMS, options.atlas);
			nextState.terrainExaggeration = options.exaggeration;

			bool toComplete = old == State::ACTIVE   && mAnimationState == State::COMPLETE;
			bool toActive   = old == State::COMPLETE && mAnimationState == State::ACTIVE;

			// update constraint mode if the animation changed states
			if (toComplete)
			{
				mConstraintHandler->setMode(Constraints::Mode::ANIMATE);
			}
			else if (toActive)
			{
				mConstraintHandler->setMode(Constraints::Mode::LOCK);
			}

			// constrain the camera state
			nextState = mConstraintHandler->update({ nextState, options.timeMS, options.atlas });

			// return the next state
			return nextState;
		}
	}


} } }