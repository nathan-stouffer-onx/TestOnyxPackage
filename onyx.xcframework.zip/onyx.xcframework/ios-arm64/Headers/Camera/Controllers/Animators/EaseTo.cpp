#include "EaseTo.h"

#include "Camera/Controllers/Constraints/DefaultConstraints.h"
#include "Camera/TimeTransform.h"

namespace onyx::Camera::Controllers
{

	EaseTo::EaseTo(CameraState const& begin, TimingParams const& timing, CameraState const& end) :
		Animator(begin, timing, std::make_unique<Constraints::DefaultConstraints>()),
		mBeginState(begin),
		mEndState(end)
	{}

	EaseTo::EaseTo(CameraState const& begin, CameraState const& end,
		Camera_time_t const durationMS, Camera_time_t const beginMS)
		: EaseTo(begin, { beginMS, durationMS }, end)
	{}

	EaseTo::EaseTo(CameraState const& begin, TimingParams const& timing, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical) :
		EaseTo(begin, timing, CameraState{ lookPt, spherical.heading, spherical.pitch, spherical.radius, begin.fov, begin.aspect, begin.nearClip, begin.farClip })
	{}

	CameraState EaseTo::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) //  during animation window, animate
		{
			// t is guaranteed to be in [0, 1]
			auto t = mCurrentTimeMS / mTiming.durationMS;

			// transform t to begin and end the animation smoothly
			t = TimeTransform::evaluate(TimeTransform::Types::SMOOTHSTEP, t);

			// compute and return the linear bezier calculation
			return CameraState::slerp(mBeginState, mEndState, t);
		}
		else
		{
			return mEndState;
		}
	}

	EaseTo2D::EaseTo2D(CameraState const& begin, TimingParams const& timing, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical) :
		EaseTo(begin, timing, { lookPt, 0.0 }, spherical),
		mLookPoint(lookPt),
		mSpherical(spherical)
	{}

	CameraState EaseTo2D::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas)
	{
		// update anchors
		float height = (atlas) ? atlas->heightAt(mLookPoint) : 0.0f;
		lgal::world::Vector3 lookPt = { mLookPoint, static_cast<world_float_t>(height) };
		mEndState = { lookPt, mSpherical.heading, mSpherical.pitch, mSpherical.radius };

		// call into base class
		return EaseTo::animationUpdate(relativeTimeMS, atlas);
	}

}