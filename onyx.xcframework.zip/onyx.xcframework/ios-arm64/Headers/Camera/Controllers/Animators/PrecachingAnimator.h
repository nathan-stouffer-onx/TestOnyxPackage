#ifndef __PRECACHING_ANIMATOR_CONTROLLER_H__
#define __PRECACHING_ANIMATOR_CONTROLLER_H__

#include <functional>

#include "Camera/Controllers/Animators/Animator.h"
#include "Utils/Precache.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// TODO (scott)
	// This controller might not belong here, because it knows about a lot more of the system
	// (stylesheets, atlases, tile cache) than most others do.  It might belong in an API-level
	// namespace instead of the root onyx::Camera::Controllers namespace.

	class PrecachingAnimator : public Animator
	{

	public:

		using PrecacheCallbackT = std::function<size_t(Utils::Precaching::KeyVisibilityList const& keys)>;

		// TODO (scott)
		// Potentially add configuration for parent tile level and framerate for prefetch
		PrecachingAnimator(SharedAnimatorT &controller, Styling::Style const& style, onyx::Atlases::HeightAtlas const* heightAtlas = nullptr, PrecacheCallbackT callback = nullptr);

		void restart(Camera_time_t newBeginMS) override;

		std::string getName() const override;
		std::string getDesc() const override;

	private:

		PrecacheCallbackT mPrecacheCallback;

		SharedAnimatorT mController;

		std::unique_ptr<Utils::Precaching::Precacher> mPrecacher;

		Utils::Precaching::KeyVisibilityList mVisibleKeys;

		size_t mCachedCount = 0;
		size_t mRequestedCount = 0;

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

	};

} } }

#endif