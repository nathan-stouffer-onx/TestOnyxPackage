#include "AnimationSequence.h"

#include <algorithm>
#include <cmath>
#include <sstream>

#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	AnimationSequence::AnimationSequence(CameraState const& beginState, CamSequenceT const& sequence, Camera_time_t loopMS, Camera_time_t beginMS) :
		Animator(beginState, beginMS, std::make_unique<Constraints::DefaultConstraints>()),
		mAnimatorSequence(sequence),
		mLoopTimeMS(loopMS),
		mPreviousState(beginState)
	{
	}

	std::string AnimationSequence::getName() const
	{
		if (mAnimatorSequence.empty())
		{
			return "AnimationSequence: empty";
		}
		if (mCurrentStep >= mAnimatorSequence.size())
		{
			return "AnimationSequence: complete";
		}
		else
		{
			return std::string("AnimationSequence: ") + mAnimatorSequence[mCurrentStep]->getName();
		}
	}

	std::string AnimationSequence::getDesc() const
	{
		std::ostringstream out;
		out.precision(0);
		out << std::fixed << mCurrentRelativeTimeMS;

		return out.str() + " ms";
	}

	CameraState AnimationSequence::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas)
	{
		if (mLoopTimeMS > 0 && mLoopTimeMS != std::numeric_limits<Camera_time_t>::max())
		{
			size_t newLoop = size_t(relativeTimeMS / mLoopTimeMS);
			if (mCurrentLoop != newLoop)
			{
				mCurrentLoop = newLoop;
				mCurrentStep = 0;
				mCurrentStepRelativeTimeMS = 0;
			}
		}

		if (mAnimatorSequence.empty())
		{
			return mBeginState;
		}
		else if (mCurrentStep >= mAnimatorSequence.size())
		{
			return mPreviousState;
		}
		else
		{
			// compute relative time -- account for looping
			Camera_time_t relativeLoopTimeMS = relativeTimeMS - mCurrentStepRelativeTimeMS;
			if (mLoopTimeMS > 0)
			{
				relativeLoopTimeMS = std::fmod(relativeLoopTimeMS, mLoopTimeMS);
			}

			auto& animator = mAnimatorSequence[mCurrentStep];
			// account for the case where the first Point doest not start at t = 0
			relativeLoopTimeMS = std::max(relativeLoopTimeMS, animator->beginTimeMS());

			mCurrentRelativeTimeMS = relativeLoopTimeMS;
			// call into active controller update method
			mPreviousState = animator->animationUpdate(relativeLoopTimeMS, atlas);

			if (animator->getState() == Animator::State::COMPLETE)
			{
				mCurrentStepRelativeTimeMS += relativeLoopTimeMS;
				logD("current relative step time: %4.0f", mCurrentStepRelativeTimeMS);
				++mCurrentStep;
			}

			return mPreviousState;
		}
	}

} } }