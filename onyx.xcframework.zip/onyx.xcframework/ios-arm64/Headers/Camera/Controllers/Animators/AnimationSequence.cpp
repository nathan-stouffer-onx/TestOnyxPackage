#include "AnimationSequence.h"

#include <algorithm>
#include <cmath>
#include <sstream>

#include "Camera/Controllers/Constraints/DefaultConstraints.h"
#include "Camera/Controllers/Sequence.h"
#include "Utils/TextUtils.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	AnimationSequence::AnimationSequence(CameraState const& beginState, TimingParams const& timing, CamSequenceT const& sequence) :
		Animator(beginState, timing, std::make_unique<Constraints::DefaultConstraints>()),
		mAnimatorSequence(sequence),
		mPreviousState(beginState)
	{
		if (mTiming.durationMS == 0)
		{
			mTiming.durationMS = getDurationMS(sequence);
		}
	}

	CameraController::Camera_time_t AnimationSequence::getDurationMS(AnimationSequence::CamSequenceT const& sequence)
	{
		CameraController::Camera_time_t result = 0;

		for (auto const& anim : sequence)
		{
			result += anim->getDurationMS() * anim->getAnimationSpeed();
		}

		return result;
	}

	CameraController::Camera_time_t AnimationSequence::getDurationMS() const
	{
		return getDurationMS(mAnimatorSequence);
	}

	void AnimationSequence::restart(Camera_time_t newBeginMS)
	{
		Animator::restart(newBeginMS);
		mCurrentLoop = 0;
		mCurrentStep = 0;
		mCurrentRelativeTimeMS = 0;
		mCurrentStepRelativeTimeMS = 0;
		for (auto& anim : mAnimatorSequence)
		{
			anim->restart(0);
		}
	}

	std::string AnimationSequence::getName() const
	{
		if (mAnimatorSequence.empty())
		{
			return "AnimationSequence: empty";
		}
		if (mCurrentStep >= mAnimatorSequence.size())
		{
			return "AnimationSequence: complete";
		}
		else
		{
			return std::string("AnimationSequence: ") + mAnimatorSequence[mCurrentStep]->getName();
		}
	}

	std::string AnimationSequence::getDesc() const
	{
		return Utils::Text::ReadableDurationStr(mCurrentRelativeTimeMS / mTiming.animationSpeed);
	}

	CameraState AnimationSequence::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas)
	{
		if (mCurrentLoop != mTiming.currentLoop)
		{
			mCurrentLoop = mTiming.currentLoop;
			mCurrentStep = 0;
			mCurrentStepRelativeTimeMS = 0;
		}

		if (mAnimatorSequence.empty())
		{
			mAnimationState = State::COMPLETE;
			return mBeginState;
		}
		else if (mCurrentStep >= mAnimatorSequence.size())
		{
			mAnimationState = State::COMPLETE;
			return mPreviousState;
		}
		else
		{
			mAnimationState = State::ACTIVE;

			// compute relative time -- account for looping
			Camera_time_t relativeLoopTimeMS = relativeTimeMS - mCurrentStepRelativeTimeMS;
			relativeLoopTimeMS = mTiming.getLoopRelativeTimeMS(relativeLoopTimeMS);

			auto& animator = mAnimatorSequence[mCurrentStep];
			// account for the case where the first Point doest not start at t = 0
			relativeLoopTimeMS = std::max(relativeLoopTimeMS, animator->beginTimeMS());

			mCurrentRelativeTimeMS = relativeLoopTimeMS;
			// call into active controller update method
			mPreviousState = animator->animationUpdate(relativeLoopTimeMS, atlas);

			if (animator->getState() == Animator::State::COMPLETE)
			{
				mCurrentStepRelativeTimeMS += relativeLoopTimeMS;
				logD("current relative step time: %4.0f", mCurrentStepRelativeTimeMS);
				++mCurrentStep;
			}

			return mPreviousState;
		}
	}

} } }