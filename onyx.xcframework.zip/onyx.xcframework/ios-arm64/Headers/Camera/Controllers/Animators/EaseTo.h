#pragma once

#include "Animator.h"
#include "Utils/MapMath.h"

namespace onyx::Camera::Controllers
{

	// camera controller that will ease the camera from a begin state to an end state.
	// the flight path is defined by regular lerping
	class EaseTo : public Animator
	{
	public:

		
		static constexpr world_float_t cDefaultDurationMS = 5500.0;

		EaseTo(CameraState const& begin, TimingParams const& timing, CameraState const& end);

		EaseTo(CameraState const& begin, CameraState const& end,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS());

		EaseTo(CameraState const& begin, TimingParams const& timing, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical);

		EaseTo(CameraState const& begin, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS())
			: EaseTo(begin, { beginMS, durationMS }, lookPt, spherical)
		{ }

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "EaseTo"; }

		std::vector<CameraState> highlights() const override { return std::vector<CameraState>{ mEndState }; }

	protected:

		CameraState mBeginState;
		CameraState mEndState;

	};

	class EaseTo2D : public EaseTo
	{
	public:

		EaseTo2D(CameraState const& begin, TimingParams const& timing, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical);

		EaseTo2D(CameraState const& begin, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS())
			: EaseTo2D(begin, { beginMS, durationMS }, lookPt, spherical)
		{ }

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "EaseTo2D"; }

	private:

		lgal::world::Vector2 const mLookPoint;
		MapMath::Spherical const mSpherical;

	};

}