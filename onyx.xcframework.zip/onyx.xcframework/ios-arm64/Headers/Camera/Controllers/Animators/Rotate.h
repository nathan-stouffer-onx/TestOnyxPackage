#ifndef __ROTATE_CONTROLLER_H__
#define __ROTATE_CONTROLLER_H__

#include "Animator.h"
#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// controller that will animate a camera rotation. the animation will begin at the initial state
	// and orbit the camera by the interpolating the deltas provided at construction time

	class Rotate : public Animator
	{
	public:

		Rotate(CameraState const& initial, lgal::world::Vector3 const& focus, 
				world_float_t deltaHeading, world_float_t deltaPitch, 
				Camera_time_t durationMS, TimeTransform::Types transform = TimeTransform::Types::QUADRATIC_EASE_OUT,
				Camera_time_t beginMS = Utils::Timer::nowMS());

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "Rotate"; }

	private:

		world_float_t const mDeltaHeading;
		world_float_t const mDeltaPitch;
		CameraState mEndState;

		Camera_time_t const mDurationMS;

		TimeTransform::Types const mTimeTransform;

	};

} } }

#endif