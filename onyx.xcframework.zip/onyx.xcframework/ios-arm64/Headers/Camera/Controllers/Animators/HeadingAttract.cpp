#include "HeadingAttract.h"

#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	static constexpr uint8_t cHighlightStateCount = 4;

	HeadingAttract::HeadingAttract(CameraState const& initial, TimingParams const& timing, world_float_t radPerMS) :
		Animator(initial, timing, std::make_unique<Constraints::DefaultConstraints>()),
		mRadPerMS(radPerMS),
		mEndState(initial)
	{
		mEndState.heading += mTiming.durationMS * mRadPerMS;
	}

	CameraState HeadingAttract::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) //  during animation window, animate
		{
			// copy initial state
			auto state = mBeginState;
			// compute the updated heading
			state.heading += mCurrentTimeMS * mRadPerMS;
			return state;
		}
		else // past animation window, return state at the duration
		{
			return mEndState;
		}
	}

	std::vector<CameraState> HeadingAttract::highlights() const
	{
		std::vector<CameraState> states;
		states.reserve(cHighlightStateCount);

		if constexpr (cHighlightStateCount > 0)
		{
			auto period = lmath::constants::two_pi<world_float_t>() / std::abs(mRadPerMS);
			// interval of time between to highlight states
			auto deltaT = period / world_float_t(cHighlightStateCount);
			for (uint8_t i = 0; i < cHighlightStateCount; i++)
			{
				// incorporate mRadPerMS in this computation so states are requested in the right order
				CameraState rotated = mBeginState;
				rotated.heading += i * deltaT * mRadPerMS;

				// make sure heading is in [0, 2pi]
				rotated.heading = std::fmod(rotated.heading, lmath::constants::two_pi<world_float_t>());
				if (rotated.heading < 0.0)
				{
					rotated.heading += lmath::constants::two_pi<world_float_t>();
				}

				states.push_back(rotated);
			}
		}

		return states;
	}

} } }