#ifndef __HEADING_ATTRACT_CONTROLLER_H__
#define __HEADING_ATTRACT_CONTROLLER_H__

#include "Animator.h"
#include "Camera/CameraController.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// controller that will animate an "attract" interaction. the animation will begin at 
	// the initial state and change only the camera heading (look direction)

	class HeadingAttract : public Animator
	{
	public:

		// defaults to one revolution every sixty seconds
		HeadingAttract(CameraState const& initial, TimingParams const& timing, world_float_t radPerMS = lmath::constants::two_pi<world_float_t>() / 60000.0);
		
		HeadingAttract(CameraState const& initial, world_float_t radPerMS = lmath::constants::two_pi<world_float_t>() / 60000.0,
			Camera_time_t durationMS = TimingParams::cMaxDurationMS, Camera_time_t beginMS = Utils::Timer::nowMS())
			: HeadingAttract(initial, TimingParams(beginMS, durationMS), radPerMS)
		{ }

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "HeadingAttract"; }

		std::vector<CameraState> highlights() const override;

	private:

		Camera_time_t const mRadPerMS;

		CameraState mEndState;

	};

} } }

#endif