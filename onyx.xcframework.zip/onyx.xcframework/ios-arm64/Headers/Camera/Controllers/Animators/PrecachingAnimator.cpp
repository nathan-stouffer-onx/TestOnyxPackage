#include "PrecachingAnimator.h"

#include <algorithm>
#include <cmath>
#include <sstream>

#include "Caching/Tiles/TileCache.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"
#include "Camera/Controllers/Sequence.h"
#include "Utils/TextUtils.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	PrecachingAnimator::PrecachingAnimator(SharedAnimatorT& controller, Styling::Style const& style, onyx::Atlases::HeightAtlas const* heightAtlas, PrecacheCallbackT callback)
		: Animator(controller->getBeginState(), { controller->beginTimeMS(), controller->getDurationMS() }, std::make_unique<Constraints::DefaultConstraints>())
		, mPrecacheCallback(callback)
		, mController(controller)
	{
		controller->restart(0);
		mPrecacher = std::make_unique<Utils::Precaching::Precacher>(*controller, controller->getDurationMS(), 0, style, Utils::Precaching::cDefaultDepth, 1000. / 60., 1000., heightAtlas);

		controller->restart(0);
		mVisibleKeys.reserve(mPrecacher->getKeyCount());
	}

	void PrecachingAnimator::restart(Camera_time_t newBeginMS)
	{
		Animator::restart(newBeginMS);
		mController->restart(0);
	}

	std::string PrecachingAnimator::getName() const
	{
		if (mController == nullptr)
		{
			return "PrecachingAnimator (empty)";
		}
		if (mController->getState() == State::ACTIVE)
		{
			return std::string("PrecachingAnimator (active)->") + mController->getName();
		}
		else
		{
			return "PrecachingAnimator (complete)";
		}
	}

	std::string PrecachingAnimator::getDesc() const
	{
		if (mAnimationState == State::ACTIVE)
		{
			return Utils::Text::ReadableCountStr(mCachedCount) + " / " + Utils::Text::ReadableCountStr(mRequestedCount);
		}
		else
		{
			return "";
		}
	}

	CameraState PrecachingAnimator::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mController->getState() == State::ACTIVE)
		{
			if (relativeTimeMS < mTiming.getDurationMS() - 500)
			{
				mVisibleKeys.clear();
				mPrecacher->getVisibleKeys(mVisibleKeys, { mCurrentTimeMS + 500, mCurrentTimeMS + 2500 }); // Precache 0.5ms - 2.5ms ahead

				auto tc = Caching::TileCache::Instance();

				auto now = Utils::Timer::nowMS();

				mRequestedCount = mVisibleKeys.size();
				mCachedCount = 0;

				if (mPrecacheCallback != nullptr)
				{
					mCachedCount = mPrecacheCallback(mVisibleKeys);
				}
				else
				{
					for (auto const& key : mVisibleKeys)
					{
						auto duration = key.visibility.whenSeen.end - mCurrentTimeMS;
						auto tileState = tc->at(key.key, now + duration);
						if (tileState == nullptr ||
							(tileState->status == Caching::TileCache::Entry::Status::LOADED
								|| tileState->status == Caching::TileCache::Entry::Status::NOT_AVAILABLE))
						{
							++mCachedCount;
						}
					}
				}
			}
			else
			{
				mRequestedCount = 0;
				mCachedCount = 0;
			}
		}
		
		auto result = mController->animationUpdate(relativeTimeMS, atlas);
		mAnimationState = mController->getState();

		return result;
	}

} } }