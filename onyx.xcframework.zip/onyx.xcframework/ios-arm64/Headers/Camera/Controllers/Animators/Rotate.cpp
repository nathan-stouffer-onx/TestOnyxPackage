#include "Rotate.h"

#include <lucid/math/Algorithm.h>

#include "Camera/Controllers/Constraints/RotateConstraints.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	Rotate::Rotate(CameraState const& initial, TimingParams const &timing, lgal::world::Vector3 const& focus, world_float_t deltaHeading, world_float_t deltaPitch, 
					TimeTransform::Types transform) :
		Animator(initial, timing, std::make_unique<Constraints::RotateConstraints>(initial, focus, timing.beginTimeMS)),
		mDeltaHeading(deltaHeading),
		mDeltaPitch(deltaPitch),
		mEndState(initial),
		mTimeTransform(transform)
	{
		mEndState.heading += mDeltaHeading;
		mEndState.pitch += mDeltaPitch;
	}

	CameraState Rotate::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		setCurrentTimeMS(relativeTimeMS);

		if (mCurrentTimeMS <= mTiming.durationMS) //  during animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = mCurrentTimeMS / mTiming.durationMS;

			// transform t according to the transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			// lerp the values
			auto deltaHeading = lmath::lerp(0.0, mDeltaHeading, t);
			auto deltaPitch = lmath::lerp(0.0, mDeltaPitch, t);

			// copy current state
			auto state = mBeginState;
			state.heading = mBeginState.heading + deltaHeading;
			state.pitch = mBeginState.pitch + deltaPitch;

			return state;
		}
		else // past the animation time, just return the end state
		{
			return mEndState;
		}
	}

} } }