#include "Rotate.h"

#include <lucid/math/Algorithm.h>

#include "Camera/Controllers/Constraints/RotateConstraints.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	Rotate::Rotate(CameraState const& initial, lgal::world::Vector3 const& focus, world_float_t deltaHeading, world_float_t deltaPitch, 
					Camera_time_t durationMS, TimeTransform::Types transform, Camera_time_t beginMS) :
		Animator(initial, beginMS, std::make_unique<Constraints::RotateConstraints>(initial, focus, beginMS)),
		mDeltaHeading(deltaHeading),
		mDeltaPitch(deltaPitch),
		mEndState(initial),
		mDurationMS(durationMS),
		mTimeTransform(transform)
	{
		mEndState.heading += mDeltaHeading;
		mEndState.pitch += mDeltaPitch;
	}

	CameraState Rotate::animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* /* atlas */)
	{
		if (relativeTimeMS <= mDurationMS) // in animation window, animate
		{
			// compute t (guaranteed to be in [0, 1])
			auto t = relativeTimeMS / mDurationMS;

			// transform t according to the transform type
			t = TimeTransform::evaluate(mTimeTransform, t);

			// lerp the values
			auto deltaHeading = lmath::lerp(0.0, mDeltaHeading, t);
			auto deltaPitch = lmath::lerp(0.0, mDeltaPitch, t);

			// copy current state
			auto state = mBeginState;
			state.heading = mBeginState.heading + deltaHeading;
			state.pitch = mBeginState.pitch + deltaPitch;

			return state;
		}
		else // past the animation time, just return the end state
		{
			mAnimationState = State::COMPLETE;
			return mEndState;
		}
	}

} } }