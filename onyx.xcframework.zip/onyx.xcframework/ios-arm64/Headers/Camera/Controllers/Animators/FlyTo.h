#pragma once

#include "Animator.h"
#include "Utils/MapMath.h"

namespace onyx::Camera::Controllers
{

	// camera controller that will fly the camera from a begin state to an end state.
	// the flight path is defined by a cubic bezier function. the begin and end states
	// provide the 0 and 3 anchor points (respectively). and the middle two anchor
	// points are computed internally based off the begin/end states
	class FlyTo : public Animator
	{
	public:

		static constexpr world_float_t cDefaultDurationMS = 5500.0;

		FlyTo(CameraState const& begin, TimingParams const& timing, CameraState const& end);

		FlyTo(CameraState const& begin, CameraState const& end,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS());

		FlyTo(CameraState const& begin, TimingParams const& timing, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical);

		FlyTo(CameraState const& begin, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS())
			: FlyTo(begin, { beginMS, durationMS }, lookPt, spherical)
		{ }

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "FlyTo"; }

		std::vector<CameraState> highlights() const override { return std::vector<CameraState>{ mCubicBezierAnchor3 }; }

	protected:

		// CameraState anchors for the cubic bezier calculation
		// NOTE: anchor points 0 and 3 are the begin/end state respectively
		CameraState mCubicBezierAnchor0;
		CameraState mCubicBezierAnchor1;
		CameraState mCubicBezierAnchor2;
		CameraState mCubicBezierAnchor3;

		void computeAnchors(CameraState const& begin, CameraState const& end);

	};

	class FlyTo2D : public FlyTo
	{
	public:

		FlyTo2D(CameraState const& begin, TimingParams const& timing, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical);

		FlyTo2D(CameraState const& begin, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS())
			: FlyTo2D(begin, { beginMS, durationMS }, lookPt, spherical)
		{ }

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "FlyTo2D"; }

	private:

		lgal::world::Vector2 const mLookPoint;
		MapMath::Spherical const mSpherical;

	};

}
