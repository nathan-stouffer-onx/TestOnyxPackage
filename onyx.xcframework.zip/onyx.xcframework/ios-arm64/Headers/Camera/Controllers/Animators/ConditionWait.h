#ifndef __CONDITION_WAIT_CONTROLLER_H__
#define __CONDITION_WAIT_CONTROLLER_H__

#include <functional>

#include "Animator.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx::Camera::Controllers {

	// camera controller that does not move the camera until a callback function tells it to

	class ConditionWait final : public Animator
	{
	public:

		using WaitCallbackT = std::function<Animator::State()>;

		ConditionWait(CameraState const& begin, Camera_time_t beginMS, WaitCallbackT callback) :
			Animator(begin, beginMS, std::make_unique<Constraints::DefaultConstraints>()),
			mCallback(callback) {}

		std::string getName() const override { return "ConditionWait"; }

	private:

		WaitCallbackT mCallback;

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;
	};

}

#endif