#include "Pan.h"

#include <cmath>

#include <algorithm>

#include "Camera/Controllers/Constraints/PanConstraints.h"
#include "Camera/Controllers/Physics/FreeBodyPhysics.h"
#include "Camera/Algorithm.h"
#include "Input/ButtonState.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// represents the minimum angle between the focus direction and the pan plane
	static constexpr world_float_t cMinFocusAngle = 0.174533;

	lgal::world::Plane Pan::DefaultPlane(CameraState const& state, lgal::world::Vector3 const& focus)
	{
		lgal::world::Vector3 delta = focus - state.position;
		
		// angle that the focus direction makes with the flat plane -- in the range [-pi/2, pi/2]
		world_float_t theta = std::asin(std::clamp(delta.z / lmath::len(delta), -1.0, 1.0));
		
		// early out to a flat plane if the angle meets requirements
		if (theta <= -cMinFocusAngle)
		{
			return lgal::world::Plane{ state.position, { 0, 0, 1 } };
		}

		// angle between the pan plane and the flat plane
		world_float_t phi = std::min(theta + cMinFocusAngle, lmath::constants::half_pi<world_float_t>());
		
		// compute deltaZ from the flat plane to a point on the pan plane
		world_float_t projectedDist = lmath::len(lgal::world::Vector2{ delta.x, delta.y });
		world_float_t deltaZ = projectedDist * std::tan(phi);
		
		// three points that define the pan plane
		lgal::world::Vector3 p0 = { focus.x, focus.y, state.position.z + deltaZ };
		lgal::world::Vector3 p1 = state.position;
		lgal::world::Vector3 p2 = state.position + state.rightDir();

		return lmath::makePlane3(p0, p1, p2);
	}

	Pan::Pan(CameraState const& initial, lgal::world::Vector3 const& focus, lgal::world::Plane const& plane, std::shared_ptr<Input::Pointer const> pointer, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::PanConstraints>(initial, beginMS),
			std::make_unique<Physics::FreeBodyPhysics>(Physics::FreeBodyPhysics::KinematicState{ beginMS, initial })
		),
		mInitialState(initial),
		mFocusPoint(focus),
		mPanPlane(plane),
		mPointer(pointer),
		mFirstFrame(true),
		mErrorDelta({ 0, 0, 0 })
	{}

	Pan::Pan(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> pointer, Camera_time_t beginMS) :
		Pan(initial, focus, Pan::DefaultPlane(initial, focus), pointer, beginMS)
	{}

	CameraState Pan::inputUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state
		CameraState state = previousState;

		// if the pointer is pressed, update the position
		if (mPointer->getState() == Input::ButtonState::Pressed && mInputState == State::ACTIVE)
		{
			auto pos = mPointer->getPosition();
			
			// compute ray pointing from focus to eye
			lgal::world::Vector3 dir = -mInitialState.rayDir(pos);
			lgal::world::Ray3 ray = { mFocusPoint, dir };
			
			// compute delta from the desired eye to the initial eye
			lgal::world::Vector3 eye = Math::pointIntersection(ray, mPanPlane);
			lgal::world::Vector3 delta = eye - mInitialState.position;

			if (mFirstFrame)
			{
				mFirstFrame = false;
				mErrorDelta = delta;
			}
			else
			{
				state.position = mInitialState.position + delta - mErrorDelta;
				state.heading = mInitialState.heading;
				state.pitch = mInitialState.pitch;
			}
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

} } }
