#ifndef __PAN_CONTROLLER_H__
#define __PAN_CONTROLLER_H__

#include <memory>

#include "InputHandler.h"
#include "Input/Pointer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* Camera controller that will move the camera in a plane based on the movement of an Input::Pointer. The
	* pan plane can be passed as an explicit construction parameter or can be left up to the Pan::defaultPlane
	* static method. Pan is written in such a way that the focus point will stay under the Input::Pointer.
	*/

	class Pan : public InputHandler
	{
	public:

		Pan(CameraState const& initial, lgal::world::Vector3 const& focus, lgal::world::Plane const& panPlane,
			std::shared_ptr<Input::Pointer const> pointer, Camera_time_t beginMS = Utils::Timer::nowMS());
		Pan(CameraState const& initial, lgal::world::Vector3 const& focus,
			std::shared_ptr<Input::Pointer const> pointer, Camera_time_t beginMS = Utils::Timer::nowMS());

		virtual CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "Pan"; }

	protected:
		
		CameraState const mInitialState;
		lgal::world::Vector3 const mFocusPoint;
		lgal::world::Plane const mPanPlane;
		std::shared_ptr<Input::Pointer const> mPointer;

		world_float_t mFirstFrame;
		lgal::world::Vector3 mErrorDelta;

		// computes the default pan plane. when possible, this is just a plane parallel to z = 0. but 
		// when focus.z is above or close to state.position.z, then the plane will adjust itself so that
		// the camera moves uphill
		static lgal::world::Plane DefaultPlane(CameraState const& state, lgal::world::Vector3 const& focus);

	};

} } }

#endif