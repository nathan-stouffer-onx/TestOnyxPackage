#include "MouseOrbit.h"

#include "Camera/Controllers/Constraints/OrbitConstraints.h"
#include "Camera/Controllers/Physics/OrbitPhysics.h"
#include "Camera/Algorithm.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	MouseOrbit::MouseOrbit(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> pointer, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::OrbitConstraints>(initial, focus, beginMS),
			std::make_unique<Physics::OrbitPhysics>(focus, Physics::OrbitPhysics::KinematicState{ beginMS, initial, lmath::len(initial.position - focus) })
		),
		mInitialState(initial),
		mFocusPoint(focus),
		mPointer(pointer),
		mInitialPointerPos(pointer->getPosition())
	{}

	CameraState MouseOrbit::inputUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state (preserves fov and such)
		CameraState state = previousState;

		// if the pointer is pressed, update the camera state
		if (mPointer->getState() == Input::ButtonState::Pressed && mInputState == State::ACTIVE)
		{
			auto pos = mPointer->getPosition();

			// compute the change in x/y in screen space
			auto dx = (pos.x - mInitialPointerPos.x) / 3.0;
			auto dy = (pos.y - mInitialPointerPos.y) / 2.0;

			// compute how much heading and pitch will change based on changes in screen space
			auto deltaHeading = dx * lmath::constants::two_pi<world_float_t>();
			auto deltaPitch = -dy * lmath::constants::pi<world_float_t>();

			state = Math::orbit(mFocusPoint, mInitialState, deltaHeading, deltaPitch, 0.0);
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

} } }