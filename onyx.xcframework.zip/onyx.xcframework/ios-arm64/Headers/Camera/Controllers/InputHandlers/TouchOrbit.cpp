#include "TouchOrbit.h"

#include <cmath>

#include "Camera/Controllers/Constraints/OrbitConstraints.h"
#include "Camera/Controllers/Physics/OrbitPhysics.h"
#include "Camera/Algorithm.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	static constexpr world_float_t cPointerDistTriggerClassification = 0.001;
	static constexpr world_float_t cPointerActiveThreshold = 0.5 * cPointerDistTriggerClassification;
	static constexpr world_float_t cDeltaSimilarityThreshold = 0.7;

	TouchOrbit::TouchOrbit(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> const& pointer0, std::shared_ptr<Input::Pointer const> const& pointer1, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::OrbitConstraints>(initial, focus, beginMS),
			std::make_unique<Physics::OrbitPhysics>(focus, Physics::OrbitPhysics::KinematicState{ beginMS, initial, len(initial.position - focus) })
		),
		mInitialState(initial),
		mFocusPoint(focus),
		mInitialRadius(len(initial.position - focus)),
		mPointer0(pointer0),
		mPointer1(pointer1),
		mConstructionTimePointerInfo(pointer0->getPosition(), pointer1->getPosition(), initial.aspect),
		mOrbitType(OrbitType::NONE)
	{}

	CameraState TouchOrbit::inputUpdate(CameraState const& previousState, Camera_time_t timeMS)
	{
		// store the previous orbit type
		// if we haven't yet identified the orbit type, attempt to detect one
		if (mOrbitType == OrbitType::NONE)
		{
			auto pointerInfo = PointerInfo{ mPointer0->getPosition(), mPointer1->getPosition(), mInitialState.aspect };
			
			auto delta0 = pointerInfo.pos0 - mConstructionTimePointerInfo.pos0;
			auto delta1 = pointerInfo.pos1 - mConstructionTimePointerInfo.pos1;

			auto len0 = lmath::len(delta0);
			auto len1 = lmath::len(delta1);

			bool pointer0Triggered = len0 >= cPointerDistTriggerClassification;
			bool pointer1Triggered = len1 >= cPointerDistTriggerClassification;
			if (pointer0Triggered || pointer1Triggered) // check if either pointer has triggered classifying orbit type
			{
				// since cPointerDistTriggerClassification > cPointerActiveThreshold, at least one pointer must be active
				bool pointer0Active = len0 >= cPointerActiveThreshold;
				bool pointer1Active = len1 >= cPointerActiveThreshold;

				if (pointer0Active != pointer1Active) // if only is active moved, we should zoom orbit
				{
					mOrbitType = OrbitType::ZOOM_ORBIT;
					mClassifiedTimerPointerInfo = pointerInfo;
				}
				else // we are now in the case where both pointers are beyond the threshold
				{
					auto unit0 = delta0 / len0;
					auto unit1 = delta1 / len1;
					if (lmath::dot(unit0, unit1) >= cDeltaSimilarityThreshold) // if they moved in a similar direction, do a pure orbit
					{
						mOrbitType = OrbitType::PURE_ORBIT;
						mClassifiedTimerPointerInfo = pointerInfo;
					}
					else // otherwise, do a zoom orbit
					{
						mOrbitType = OrbitType::ZOOM_ORBIT;
						mClassifiedTimerPointerInfo = pointerInfo;
					}
				}
			}
		}

		// depending on the orbit type, interpret input differently
		switch (mOrbitType)
		{
		case OrbitType::NONE:
			return previousState;
			break;
		case OrbitType::PURE_ORBIT:
			return pureOrbitUpdate(previousState, timeMS);
			break;
		case OrbitType::ZOOM_ORBIT:
			return zoomOrbitUpdate(previousState, timeMS);
			break;
		default:
			return previousState;
			break;
		}
	}

	CameraState TouchOrbit::pureOrbitUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state (preserves fov and such)
		CameraState state = previousState;

		// if the pointer is pressed, update the camera state
		bool pointer0Down = mPointer0->getState() == Input::ButtonState::Pressed;
		bool pointer1Down = mPointer1->getState() == Input::ButtonState::Pressed;
		if (pointer0Down && pointer1Down && mInputState == State::ACTIVE)
		{
			auto pointerInfo = PointerInfo{ mPointer0->getPosition(), mPointer1->getPosition(), mInitialState.aspect };
			
			// compute the change in x/y in screen space
			auto dx = (pointerInfo.avg.x - mClassifiedTimerPointerInfo.avg.x) / 3.0;
			auto dy = (pointerInfo.avg.y - mClassifiedTimerPointerInfo.avg.y) / 2.0;

			// compute how much heading and pitch will change based on changes in screen space
			auto deltaHeading = dx * lmath::constants::two_pi<world_float_t>();
			auto deltaPitch = -dy * lmath::constants::pi<world_float_t>();

			state = Math::orbit(mFocusPoint, mInitialState, deltaHeading, deltaPitch, 0.0);
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

	CameraState TouchOrbit::zoomOrbitUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state (preserves fov and such)
		CameraState state = previousState;

		// if the pointer is pressed, update the camera state
		bool pointer0Down = mPointer0->getState() == Input::ButtonState::Pressed;
		bool pointer1Down = mPointer1->getState() == Input::ButtonState::Pressed;
		if (pointer0Down && pointer1Down && mInputState == State::ACTIVE)
		{
			auto pointerInfo = PointerInfo{ mPointer0->getPosition(), mPointer1->getPosition(), mInitialState.aspect };

			// compute the change in dist/rho in screen space
			auto dDist = pointerInfo.dist - mClassifiedTimerPointerInfo.dist;
			auto finalRadius = std::exp(-dDist) * mInitialRadius;
			auto dRho = -(pointerInfo.rho - mClassifiedTimerPointerInfo.rho);

			// compute how much heading and deltaRadius will change based on changes in screen space
			auto deltaHeading = dRho;
			auto deltaRadius = finalRadius - mInitialRadius;

			state = Math::orbit(mFocusPoint, mInitialState, deltaHeading, 0.0, deltaRadius);
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

} } }