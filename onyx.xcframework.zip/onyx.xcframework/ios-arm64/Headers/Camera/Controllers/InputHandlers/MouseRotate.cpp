#include "MouseRotate.h"

#include "Camera/Controllers/Constraints/RotateConstraints.h"
#include "Camera/Controllers/Physics/FreeBodyPhysics.h"
#include "Input/ButtonState.h"

namespace onyx {
namespace Camera {
namespace Controllers {
	
	MouseRotate::MouseRotate(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> const& pointer, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::RotateConstraints>(initial, focus, beginMS),
			std::make_unique<Physics::FreeBodyPhysics>(Physics::FreeBodyPhysics::KinematicState{ beginMS, initial })
		),
		mInitialState(initial),
		mPointer(pointer),
		mInitialPointerPos(pointer->getPosition())
	{}

	CameraState MouseRotate::inputUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state
		CameraState state = previousState;

		// if the pointer is pressed
		if (mPointer->getState() == Input::ButtonState::Pressed && mInputState == State::ACTIVE)
		{
			auto pos = mPointer->getPosition();

			// compute the deltas in screen coordinates
			auto dx = pos.x - mInitialPointerPos.x;
			auto dy = pos.y - mInitialPointerPos.y;

			// compute the field of view (in radians) for the theta/phi directions
			auto halfFov = 0.5 * state.fov * lmath::constants::pi<world_float_t>() / 180.0;
			auto halfThetaFov = halfFov * state.aspect;
			auto halfPhiFov = halfFov;

			auto deltaHeading = -dx * halfThetaFov;
			auto deltaPitch = dy * halfPhiFov;

			state.heading = mInitialState.heading + deltaHeading;	// don't fmod so physics calculation is easier
			state.pitch = mInitialState.pitch + deltaPitch;
			state.position = mInitialState.position;
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

} } }
