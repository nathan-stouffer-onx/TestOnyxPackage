#include "TouchRotate.h"

#include <cmath>

#include "Camera/Controllers/Constraints/RotateConstraints.h"
#include "Camera/Controllers/Physics/FreeBodyPhysics.h"
#include "Camera/Algorithm.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	TouchRotate::TouchRotate(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> const& pointer0, std::shared_ptr<Input::Pointer const> const& pointer1, std::shared_ptr<Input::Pointer const> const& pointer2, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::RotateConstraints>(initial, focus, beginMS),
			std::make_unique<Physics::FreeBodyPhysics>(Physics::FreeBodyPhysics::KinematicState{ beginMS, initial })
		),
		mInitialState(initial),
		mFocusPoint(focus),
		mPointer0(pointer0),
		mPointer1(pointer1),
		mPointer2(pointer2),
		mInitialPointer0Pos(pointer0->getPosition()),
		mInitialPointer1Pos(pointer1->getPosition()),
		mInitialPointer2Pos(pointer2->getPosition()),
		mAvgInitialPos((mInitialPointer0Pos + mInitialPointer1Pos + mInitialPointer2Pos) / 3.0) // avg pointer position
	{}

	CameraState TouchRotate::inputUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state (preserves fov and such)
		CameraState state = previousState;

		// if the pointer is pressed, update the camera state
		bool pointer0Down = mPointer0->getState() == Input::ButtonState::Pressed;
		bool pointer1Down = mPointer1->getState() == Input::ButtonState::Pressed;
		bool pointer2Down = mPointer2->getState() == Input::ButtonState::Pressed;
		if (pointer0Down && pointer1Down && pointer2Down && mInputState == State::ACTIVE)
		{
			auto avg = (mPointer0->getPosition() + mPointer1->getPosition() + mPointer2->getPosition()) / 3.0;

			auto dx = avg.x - mAvgInitialPos.x;
			auto dy = avg.y - mAvgInitialPos.y;

			// compute the field of view (in radians) for the theta/phi directions
			auto halfFov = 0.5 * mInitialState.fov * lmath::constants::pi<world_float_t>() / 180.0;
			auto halfThetaFov = halfFov * mInitialState.aspect;
			auto halfPhiFov = halfFov;

			auto deltaHeading = -dx * halfThetaFov;
			auto deltaPitch = dy * halfPhiFov;

			state.heading = mInitialState.heading + deltaHeading;	// don't fmod so physics calculation is easier
			state.pitch = mInitialState.pitch + deltaPitch;
			state.position = mInitialState.position;
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

} } }