#ifndef __TOUCH_ROTATE_CONTROLLER_H__
#define __TOUCH_ROTATE_CONTROLLER_H__

#include <memory>

#include "InputHandler.h"
#include "Input/Pointer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* Camera controller that will only change the look direction of the camera. It is meant
	* to feel as if you were at the camera eye and able to turn only your head. TouchRotate
	* reacts to user input by using the passed two Input::Pointers. It interprets changes in
	* the average screen space position in the following way:
	*       deltaX => change heading
	*       deltaY => change pitch
	* TouchRotate is designed so that the focus point will stay near the average of the two
	* Input::Pointers
	*/

	class TouchRotate : public InputHandler
	{

	public:

		TouchRotate(CameraState const& initial, lgal::world::Vector3 const& focus,
					std::shared_ptr<Input::Pointer const> const& pointer0, 
					std::shared_ptr<Input::Pointer const> const& pointer1, 
					std::shared_ptr<Input::Pointer const> const& pointer2,
					Camera_time_t beginMS = Utils::Timer::nowMS());
		
		CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "TouchRotate"; }

	protected:

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocusPoint;

		std::shared_ptr<Input::Pointer const> mPointer0;
		std::shared_ptr<Input::Pointer const> mPointer1;
		std::shared_ptr<Input::Pointer const> mPointer2;

		lgal::world::Vector2 const mInitialPointer0Pos;
		lgal::world::Vector2 const mInitialPointer1Pos;
		lgal::world::Vector2 const mInitialPointer2Pos;

		lgal::world::Vector2 const mAvgInitialPos;

	};

} } }

#endif