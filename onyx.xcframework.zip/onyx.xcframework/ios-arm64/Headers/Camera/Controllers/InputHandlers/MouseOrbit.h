#ifndef __MOUSE_ORBIT_CONTROLLER_H__
#define __MOUSE_ORBIT_CONTROLLER_H__

#include <memory>

#include "InputHandler.h"
#include "Input/Pointer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that will orbit the camera in a sphere around the focus point. the initial camera
	// position is assumed to be a point on the sphere. so the orbit sphere S is defined by:
	//              center = focus      radius = len(initial.position - focus)
	// 
	// MouseOrbit reacts to user input by using the passed Input::Pointer. it interprets changes in screen
	// space as
	//        deltaY => amount to pitch around the focus point
	//        deltaX => amount to yaw around the focus point
	// MouseOrbit is designed so that the focus point will always stay at the same point in screen space

	class MouseOrbit : public InputHandler
	{

	public:

		MouseOrbit(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> pointer,
					Camera_time_t beginMS = Utils::Timer::nowMS());

		CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "MouseOrbit"; }

	protected:

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocusPoint;
		std::shared_ptr<Input::Pointer const> mPointer;
		lgal::world::Vector2 const mInitialPointerPos;

	};

} } }

#endif