#ifndef __INPUT_HANDLER_CONTROLLER_H__
#define __INPUT_HANDLER_CONTROLLER_H__

#include <memory>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Camera/Controllers/Physics/PhysicsHandler.h"
#include "Camera/Controllers/Constraints/ConstraintHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* A class that abstracts away handling input. InputHandler inherits from CameraController and overrides the pure virtual 
	* method CameraController::derivedUpdate. InputHandler defines a pure virtual method inputUpdate that it's derived controllers
	* must implement. When a derived controller knows that it's input is no longer active, it should set the member mInputState
	* to InputState::INACTIVE so that InputHandler knows to trigger animations (ie physics or constraints).
	* 
	* Additionally, InputHandler requires a ConstraintHandler and a PhysicsHandler. The method InputHandler::inputUpdate
	* will handle the logic of what mode each of the handlers should be in. If a derived controller doesn't want to have
	* physics or constraints, it can provide the identity physics handler and the default constraint handler.
	*/

	class InputHandler : public CameraController
	{

	public:

		InputHandler(std::unique_ptr<Constraints::ConstraintHandler> constraints, std::unique_ptr<Physics::PhysicsHandler> physics);
		virtual ~InputHandler() {}

		// TODO if possible, get rid of timeMS from this signature -- only WheelZoom uses it
		virtual CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) = 0;

	protected:

		enum class State
		{
			ACTIVE,
			INACTIVE
		};

		State mInputState;

	private:

		CameraState derivedUpdate(ControllerOptions const& options) final override;

		std::unique_ptr<Constraints::ConstraintHandler> mConstraintHandler;
		std::unique_ptr<Physics::PhysicsHandler> mPhysicsHandler;

	};

} } }

#endif