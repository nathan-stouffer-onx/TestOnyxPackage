#include "InputHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	InputHandler::InputHandler(std::unique_ptr<Constraints::ConstraintHandler> constraints, std::unique_ptr<Physics::PhysicsHandler> physics) :
		mInputState(State::ACTIVE),
		mConstraintHandler(std::move(constraints)),
		mPhysicsHandler(std::move(physics))
	{}

	CameraState InputHandler::derivedUpdate(ControllerOptions const& options)
	{
		State old = mInputState;

		// compute the update from the input
		CameraState nextState = inputUpdate(options.previousState, options.timeMS);
		nextState.terrainExaggeration = options.exaggeration;

		bool toInactive = old == State::ACTIVE   && mInputState == State::INACTIVE;
		bool toActive   = old == State::INACTIVE && mInputState == State::ACTIVE;

		// update the state of the handlers according to whether the input state changed
		if (toInactive)
		{
			mPhysicsHandler->setMode(Physics::Mode::APPLY);
		}
		else if (toActive)
		{
			mPhysicsHandler->setMode(Physics::Mode::TRACK);
			mConstraintHandler->setMode(Constraints::Mode::LOCK);
		}

		// update for physics
		nextState = mPhysicsHandler->update(nextState, options.timeMS);

		// update for constraints
		nextState = mConstraintHandler->update({ nextState, options.timeMS, options.atlas });

		// check if we should set constraint mode to ANIMATE
		// NOTE: this assumes that physics only ever applies drag to the CameraState. once we 
		// detects that the constraint handler has not changed for a frame (and that the 
		// input is inactive), it will immediately set the constraint handler to animate
		if (mInputState == State::INACTIVE && !mConstraintHandler->changed())
		{
			mConstraintHandler->setMode(Constraints::Mode::ANIMATE);
		}

		// return the next state
		return nextState;
	}


} } }