#ifndef __TOUCH_ORBIT_CONTROLLER_H__
#define __TOUCH_ORBIT_CONTROLLER_H__

#include <memory>
#include <cmath>

#include "InputHandler.h"
#include "Input/Pointer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* Camera controller that will orbit the camera around the focus point. The initial camera
	* position is assumed to be a point on a sphere S. so the orbit sphere S is defined by:
	*              center = focus      radius = len(initial.position - focus)
	* 
	* TouchOrbit reacts to user input by using the passed two Input::Pointers. Based on the initial 
	* movement directions of the pointers, we will assign an orbit type. If the pointers are moving 
	* in the same general direction, then we will apply a pure orbit (we will stay on the orbit 
	* sphere S). In any other case (only one pointer moves or if pointers move in different 
	* directions). We will apply a zoom orbit, meaning we change heading and radius based on the 
	* pointer positions.
	* 
	* TouchOrbit is designed so that the focus point will always stay at the same point in screen space
	*/

	class TouchOrbit : public InputHandler
	{

	public:

		TouchOrbit(CameraState const& initial, lgal::world::Vector3 const& focus,
					std::shared_ptr<Input::Pointer const> const& pointer0, std::shared_ptr<Input::Pointer const> const& pointer1,
					Camera_time_t beginMS = Utils::Timer::nowMS());

		CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "TouchOrbit"; }

	protected:

		// class describing the state of the orbit type
		enum class OrbitType
		{
			NONE,
			PURE_ORBIT,
			ZOOM_ORBIT
		};

		// a small struct that computes all the relevant pointer info that we need to determine how to manipulate the camera.
		// all these values are scaled by the aspect ratio for more natural controls
		struct PointerInfo
		{
			lgal::world::Vector2 pos0;
			lgal::world::Vector2 pos1;

			lgal::world::Vector2 avg;

			lgal::world::Vector2 delta;
			world_float_t dist;
			world_float_t rho;

			PointerInfo() : PointerInfo{ { 0, 0 }, { 0, 0 }, 1.0 } {}
			PointerInfo(lgal::world::Vector2 const& p0, lgal::world::Vector2 const& p1, world_float_t const aspect) :
				pos0({ aspect * p0.x, p0.y }),
				pos1({ aspect * p1.x, p1.y }),
				avg(0.5 * (pos0 + pos1)),
				delta(pos1 - pos0),
				dist(len(delta)),
				rho(std::atan2(delta.y, delta.x))
			{}
		};

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocusPoint;
		world_float_t const mInitialRadius;
		std::shared_ptr<Input::Pointer const> mPointer0;
		std::shared_ptr<Input::Pointer const> mPointer1;
		PointerInfo const mConstructionTimePointerInfo;
		
		// the pointer info when we classified the orbit type
		PointerInfo mClassifiedTimerPointerInfo;
		OrbitType mOrbitType;

		CameraState pureOrbitUpdate(CameraState const& previousState, Camera_time_t timeMS);
		CameraState zoomOrbitUpdate(CameraState const& previousState, Camera_time_t timeMS);

	};

} } }

#endif