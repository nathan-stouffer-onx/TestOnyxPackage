#ifndef _MOUSE_SPIN_CONTROLLER_H_
#define _MOUSE_SPIN_CONTROLLER_H_

#include <memory>

#include "InputHandler.h"
#include "Input/Pointer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that will only change the look direction of the camera. it is meant to feel
	// as if you were at the camera eye and able to turn your head. MouseSpin reacts to user input by
	// using the passed Input::Pointer. if the pointer is pressed, changes in screen position affect
	// the camera state in the following way:
	//      deltaX => change heading
	//      deltaY => change pitch
	// MouseRotate is designed so that the focus point will be near the cursor

	class MouseRotate : public InputHandler
	{

	public:

		MouseRotate(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> const& pointer,
					Camera_time_t beginMS = Utils::Timer::nowMS());

		CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "MouseRotate"; }

	private:

		CameraState const mInitialState;
		std::shared_ptr<Input::Pointer const> mPointer;
		lgal::world::Vector2 const mInitialPointerPos;

	};

} } }

#endif