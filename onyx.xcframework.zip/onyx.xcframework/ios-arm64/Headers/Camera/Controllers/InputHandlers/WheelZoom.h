#ifndef __WHEEL_ZOOM_CONTROLLER_H__
#define __WHEEL_ZOOM_CONTROLLER_H__

#include "InputHandler.h"
#include "Input/Wheel.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that zooms in/out from the initial camera position to the focus point.
	// WheelZoom reacts to user input byusing the passed Input::Wheel. if the wheel is 
	// pressed, changes in the scroll wheel position affect the camera state in the following way:
	//      deltaX => no change
	//      deltaY => zoom in/out to the focus point

	class WheelZoom : public InputHandler
	{
	public:

		WheelZoom(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Wheel const> const& wheel,
					Camera_time_t beginMS = Utils::Timer::nowMS());

		CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "WheelZoom"; }

	private:

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocusPoint;
		lgal::world::Vector3 const mInitialOffset;
		std::shared_ptr<Input::Wheel const> const mWheel;

		// for trackpads, we want to ignore the first wheel event and update CameraState based on subsequent changes to scroll
		// position. but with a mouse, we will frequently get just a single wheel event. in that case, we want to update the
		// CameraState based on that single event. these variables track both pieces of information so the update funcion can
		// use the appropriate one
		Input::Wheel::ScrollState const mInitialScrollState;			// scroll state at construction time
		Input::Wheel::ScrollState const mPrevInitialScrollState;		// scroll state prior to the inital scroll state

		enum class Granularity
		{
			UNKOWN,
			SMOOTH,
			COARSE
		};

		Granularity mGranularity;

		CameraState smoothInputUpdate(CameraState const& previousState, Camera_time_t timeMS);
		CameraState coarseInputUpdate(CameraState const& previousState, Camera_time_t timeMS);

		struct WheelAnimation
		{
			Camera_time_t beginMS;
			lgal::world::Vector2 beginPos;

			Camera_time_t endMS;
			lgal::world::Vector2 endPos;

			WheelAnimation(Camera_time_t beginMS, lgal::world::Vector2 beginPos, Camera_time_t endMS, lgal::world::Vector2 endPos) :
				beginMS(beginMS),
				beginPos(beginPos),
				endMS(endMS),
				endPos(endPos)
			{}

			lgal::world::Vector2 animate(Camera_time_t timeMS)
			{
				if (endMS == beginMS)
				{
					return endPos;
				}
				else
				{
					auto t = (timeMS - beginMS) / (endMS - beginMS);
					return { lmath::lerpstep(beginPos.x, endPos.x, t), lmath::lerpstep(beginPos.y, endPos.y, t) };
				}
			}
		};

		WheelAnimation mAnimation;

	};

} } }

#endif