#include "MouseZoom.h"

#include <cmath>

#include "Camera/Controllers/Constraints/ZoomConstraints.h"
#include "Camera/Controllers/Physics/OrbitPhysics.h"
#include "Camera/Algorithm.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	MouseZoom::MouseZoom(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> pointer, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::ZoomConstraints>(initial, focus, beginMS),
			std::make_unique<Physics::OrbitPhysics>(focus, Physics::OrbitPhysics::KinematicState{ beginMS, initial, lmath::len(initial.position - focus) })
		),
		mInitialState(initial),
		mFocusPoint(focus),
		mPointer(pointer),
		mInitialPointerPos(pointer->getPosition()),
		mInitialRadius(len(initial.position - focus)),
		mZoomTheta(0),
		mZoomPhi(0)
	{
		lgal::world::Vector3 delta = initial.position - focus;
		mZoomTheta = std::atan2(delta.y, delta.x);
		// with infinite precision, the value of delta.z / mInitialRadius is in the range
		// [-1, 1], but with finite precision we might be slightly over. so we clamp to the
		// bounds to avoid getting NaNs
		mZoomPhi = std::acos(std::clamp(delta.z / mInitialRadius, -1.0, 1.0));
	}

	CameraState MouseZoom::inputUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state
		CameraState state = previousState;

		// if the pointer is pressed, update the camera state
		if (mPointer->getState() == Input::ButtonState::Pressed && mInputState == State::ACTIVE)
		{
			auto pos = mPointer->getPosition();
			
			auto dy = -(pos.y - mInitialPointerPos.y);

			auto radius = std::exp(dy) * mInitialRadius;

			lgal::world::Vector3 offset = 
			{
				std::cos(mZoomTheta) * std::sin(mZoomPhi),
				std::sin(mZoomTheta) * std::sin(mZoomPhi), 
				std::cos(mZoomPhi)
			};
			offset = radius * offset;
				
			state.position = mFocusPoint + offset;
			state.heading = mInitialState.heading;
			state.pitch = mInitialState.pitch;

			return state;
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

} } }