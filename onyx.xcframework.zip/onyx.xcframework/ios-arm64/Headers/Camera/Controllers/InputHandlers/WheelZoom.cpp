#include "WheelZoom.h"

#include "Camera/Controllers/Constraints/ZoomConstraints.h"
#include "Camera/Controllers/Physics/OrbitPhysics.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// magic number used to classify a scroll interaction as smooth or coarse
	static constexpr world_float_t cCoarseThreshold = 0.05;

	static constexpr CameraController::Camera_time_t cAnimationTimeMS = 250.0;

	WheelZoom::WheelZoom(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Wheel const> const& wheel, Camera_time_t beginMS) :
		InputHandler(
			std::make_unique<Constraints::ZoomConstraints>(initial, focus, beginMS),
			std::make_unique<Physics::OrbitPhysics>(focus, Physics::OrbitPhysics::KinematicState{ beginMS, initial, len(initial.position - focus) })
		),
		mInitialState(initial),
		mFocusPoint(focus),
		mInitialOffset(initial.position - focus),
		mWheel(wheel),
		mInitialScrollState(wheel->getScrollState()),
		mPrevInitialScrollState(wheel->getPrevScrollState()),
		mGranularity(Granularity::UNKOWN),
		mAnimation(0, { 0, 0 }, 0, { 0, 0 })
	{}

	CameraState WheelZoom::inputUpdate(CameraState const& previousState, Camera_time_t timeMS)
	{
		// NOTE: this will currently always classify the input as COARSE because the wheel only updates once per frame. the
		// call to construct the WheelZoom controller will set mInitialScrollState to the same state that mWheel->getScrollState()
		// returns below. so delta is always 0 and the granularity is always COARSE. for right now, this works reasonably
		// well. but if we want to get more precise, the options are still there
		if (mGranularity == Granularity::UNKOWN)	// if unknown and not the first iteration, attempt to classify
		{
			// current scroll position
			auto scrollPos = mWheel->getScrollState().pos;

			// compute the delta and the clamped delta
			auto delta = scrollPos - mInitialScrollState.pos;
			auto threshold = lgal::world::Vector2{ cCoarseThreshold, cCoarseThreshold };
			auto clamped = clamp(delta, -threshold, threshold);
			
			if (delta == lgal::world::Vector2{ 0, 0 })	// if there has been no change, coarse input
			{
				mGranularity = Granularity::COARSE;
			}
			else if (delta == clamped)		// if there was a change and it was small, smooth input
			{
				mGranularity = Granularity::SMOOTH;
			}
			else							// if there was a change and it was big, coarse input
			{
				mGranularity = Granularity::COARSE;
			}
		}

		// depending on the input type, interpret input differently
		switch (mGranularity)
		{
		case Granularity::UNKOWN:
			return previousState;
			break;
		case Granularity::SMOOTH:
			return smoothInputUpdate(previousState, timeMS);
			break;
		case Granularity::COARSE:
			return coarseInputUpdate(previousState, timeMS);
			break;
		default:
			return previousState;
			break;
		}
	}

	CameraState WheelZoom::smoothInputUpdate(CameraState const& previousState, Camera_time_t /* timeMS */)
	{
		// initially, copy the current state (preserves fov and such)
		CameraState state = previousState;

		// if the wheel is active, update the camera state
		if (mWheel->getButtonState() == Input::ButtonState::Pressed)
		{
			mInputState = State::ACTIVE;

			// compute the scroll position delta
			auto delta = mWheel->getScrollState().pos - mInitialScrollState.pos;

			// transform scroll position to zoom amount. this function is continuous and has the following useful properties
			//     - f(0) = 1                 (scroll pos = 0 keeps us at current camera location)
			//     - limit as x -> +inf is 0  (as we zoom in, we will approach the focus point, but at a slower rate as we get closer)
			//     - f(x) = 1 / f(-x)         (zooming in and out by the same number of scrolls ticks will leave the position unchanged)
			//     - f(x + 1) = f(x) / 2      (each additional tick cuts the zoom in half)
			auto zoomScalar = std::pow(2.0, -delta.y);
			
			state.position = mFocusPoint + zoomScalar * mInitialOffset;
			state.heading = mInitialState.heading;
			state.pitch = mInitialState.pitch;
		}
		else
		{
			mInputState = State::INACTIVE;
		}

		return state;
	}

	CameraState WheelZoom::coarseInputUpdate(CameraState const& previousState, Camera_time_t timeMS)
	{
		// initially, copy the current state (preserves fov and such)
		CameraState state = previousState;

		// if the wheel is active, update the camera state
		if (mWheel->getButtonState() == Input::ButtonState::Pressed)
		{
			mInputState = State::ACTIVE;

			// compute the updated animation
			auto animated = mAnimation.animate(timeMS);

			// compute the scroll position delta
			auto delta = animated - mPrevInitialScrollState.pos;

			// transform scroll position to zoom amount. this function is continuous and has the following useful properties
			//     - f(0) = 1                 (scroll pos = 0 keeps us at current camera location)
			//     - limit as x -> +inf is 0  (as we zoom in, we will approach the focus point, but at a slower rate as we get closer)
			//     - f(x) = 1 / f(-x)         (zooming in and out by the same number of scrolls ticks will leave the position unchanged)
			//     - f(x + 1) = f(x) / 2      (each additional tick cuts the zoom in half)
			auto zoomScalar = std::pow(2.0, -delta.y);
			
			state.position = mFocusPoint + zoomScalar * mInitialOffset;
			state.heading = mInitialState.heading;
			state.pitch = mInitialState.pitch;

			auto wheelDelta = mWheel->getScrollState().pos - mWheel->getPrevScrollState().pos;
			if (wheelDelta != lgal::world::Vector2{ 0, 0 })
			{
				auto animationDelta = mAnimation.endPos - mAnimation.beginPos;
				if (std::signbit(wheelDelta.y) == std::signbit(animationDelta.y))	// if wheel and animation deltas are in the same direction, add on the wheel delta
				{
					mAnimation = { timeMS, animated, timeMS + cAnimationTimeMS, mAnimation.endPos + wheelDelta };
				}
				else	// if wheel and animation deltas are in opposite directions, reverse direction immediately
				{
					mAnimation = { timeMS, animated, timeMS + cAnimationTimeMS, animated + wheelDelta };
				}
			}
		}
		else
		{
			mInputState = State::INACTIVE;
		}
		
		return state;
	}

} } }