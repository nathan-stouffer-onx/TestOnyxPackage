#ifndef __MOUSE_ZOOM_CONTROLLER_H__
#define __MOUSE_ZOOM_CONTROLLER_H__

#include <memory>

#include "InputHandler.h"
#include "Input/Pointer.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that zooms in/out from the initial camera position to the focus point.
	// MouseZoom reacts to user input byusing the passed Input::Pointer. if the pointer is 
	// pressed, changes in screen position affect the camera state in the following way:
	//      deltaX => no change
	//      deltaY => zoom in/out to the focus point
	// MouseZoom is designed so that the focus point will always be under the cursor

	class MouseZoom : public InputHandler
	{
	public:

		MouseZoom(CameraState const& initial, lgal::world::Vector3 const& focus, std::shared_ptr<Input::Pointer const> pointer,
					Camera_time_t beginMS = Utils::Timer::nowMS());

		CameraState inputUpdate(CameraState const& previousState, Camera_time_t timeMS) override;

		std::string getName() const override { return "MouseZoom"; }

	private:

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocusPoint;
		std::shared_ptr<Input::Pointer const> mPointer;
		lgal::world::Vector2 const mInitialPointerPos;

		world_float_t mInitialRadius;
		world_float_t mZoomTheta;
		world_float_t mZoomPhi;

	};

} } }

#endif