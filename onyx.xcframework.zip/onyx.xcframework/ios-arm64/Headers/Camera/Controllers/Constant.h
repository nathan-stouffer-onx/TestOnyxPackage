#pragma once

#include "Camera/CameraController.h"
#include "Camera/Controllers/Constraints/DefaultConstraints.h"

namespace onyx::Camera::Controllers
{

	// camera controller that always returns the state it is constructed with; a constant map
	// NOTE: the CameraController base class may still change the camera state if mState is invalid

	class Constant : public CameraController
	{
	public:

		Constant(CameraState const& state, bool strict = false) : mState(state), mStrict(strict) {}

		std::string getName() const override { return "Constant"; }

	private:

		CameraState mState;
		bool mStrict;
		Constraints::DefaultConstraints mConstraintHandler;

		CameraState derivedUpdate(ControllerOptions const& options) override
		{
			CameraState state = (mStrict) ? mState : mConstraintHandler.update({ mState, options.timeMS, options.atlas });
			return state;
		}

		CameraState clipPlanesUpdate(CameraState const& nextState, Atlases::HeightAtlas const* atlas) override
		{
			return (mStrict) ? nextState : CameraController::clipPlanesUpdate(nextState, atlas);
		}

	};

}