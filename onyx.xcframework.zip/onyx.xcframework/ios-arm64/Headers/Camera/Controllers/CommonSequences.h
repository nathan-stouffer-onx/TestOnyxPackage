#ifndef __COMMON_SEQUENCES_CONTROLLER_H__
#define __COMMON_SEQUENCES_CONTROLLER_H__

#include "Camera/Controllers/Animators/AnimationSequence.h"
#include "Camera/Controllers/Animators/Follow.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// TODO: Move Path Trace demo sequence from DebugUI to here?

	struct ApproachFollowSeqConfig
	{
		CameraController::Camera_time_t longDistApproachDurationMS = 4000.0;
		CameraController::Camera_time_t shortDistApproachDurationMS = 700.0;
		CameraController::Camera_time_t beginMS =  Utils::Timer::nowMS();
		bool isCamOrientLocked = false;
	};

	std::shared_ptr<AnimationSequence> genApproachFollowSequence(
		CameraState const& beginState,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		ApproachFollowSeqConfig afSeqConfig = ApproachFollowSeqConfig{}
	);

} } }

#endif

