#pragma once

#include "Animators/AnimationSequence.h"
#include "Animators/Follow.h"
#include "Animators/OrbitAttract.h"

namespace onyx::Camera::Controllers {

// TODO: Move Path Trace demo sequence from DebugUI to here?

// Camera controller sequence that approaches a point and then follows the point. Good for location pucks
class ApproachFollowGenerator
{
public:

	struct Config
	{
		CameraController::Camera_time_t longDistApproachDurationMS = 4000.0;
		CameraController::Camera_time_t shortDistApproachDurationMS = 700.0;
		CameraController::Camera_time_t beginMS =  Utils::Timer::nowMS();
		bool isCamOrientLocked = false;
	};
	
	static std::shared_ptr<AnimationSequence> genSequence(
		CameraState const& beginState,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		Config afSeqConfig = Config{ 4000.0, 700.0, Utils::Timer::nowMS(), false }
	);

	ApproachFollowGenerator() = delete;
	~ApproachFollowGenerator() = delete;

private:

	static bool isFarFromLookAt(lgal::world::Vector3 camPos, lgal::world::Vector3 lookAt);

	static SharedAnimatorT genApproach(
		CameraState const& beginState,
		CameraState const& endState,
		CameraController::Camera_time_t beginRelToSeqMS,
		CameraController::Camera_time_t durationMS
	);
	
	static SharedAnimatorT genFollow(
		CameraState const& beginState,
		CameraController::Camera_time_t beginRelToSeqMS,
		Follow::CamPosSphereCoords const& initialConfig,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		bool isCamOrientLockedToInitialState
	);

	static std::shared_ptr<AnimationSequence> genSequence(
		CameraState const& initialState,
		SharedAnimatorT const& approachPoint,
		SharedAnimatorT const& followPoint,
		CameraController::Camera_time_t beginMS
	);
		
};

// TODO (Ronald): There's a bug in this where the beginning orbit camera doesn't quite agree with the FlyTo camera. The
// switch to the OrbitAttract causes a slight shift in heading.
class ApproachOrbitGenerator
{
public:

	/// <summary>
	/// Sequence generator for approaching and orbiting a point
	/// </summary>
	/// <param name="begin">Beginning camera state</param>
	/// <param name="beginOrbit">Camera state at start of orbit</param>
	/// <param name="orbitCenter">point in world space to orbit around</param>
	/// <returns></returns>
	static std::shared_ptr<AnimationSequence> genSequence(CameraState const& begin, MapMath::Spherical const& beginOrbitState,
		lgal::world::Vector3 const& orbitCenter);

	ApproachOrbitGenerator() = delete;
	~ApproachOrbitGenerator() = delete;

private:


};

}

