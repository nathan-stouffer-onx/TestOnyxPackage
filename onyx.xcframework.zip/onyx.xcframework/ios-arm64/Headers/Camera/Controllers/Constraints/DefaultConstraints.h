#ifndef __DEFAULT_CONSTRAINTS_H__
#define __DEFAULT_CONSTRAINTS_H__

#include "ConstraintHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	/*
	* a simple class that doesn't really implement any constraints at all. it just returns the current
	* state and leaves it to the base class to ensure general camera constraints.
	*/

	class DefaultConstraints : public ConstraintHandler
	{

	public:

		DefaultConstraints(Mode mode = Mode::LOCK) : ConstraintHandler(mode) {}

	private:

		CameraState derivedUpdate(ConstraintOptions const& options) override
		{
			return options.candidate;
		}

	};

} } } }

#endif