#ifndef __ORBIT_CONSTRAINTS_H__
#define __ORBIT_CONSTRAINTS_H__

#include <lucid/gal/Types.h>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "ConstraintHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	/*
	* OrbitConstraints provides constraints for the camera that are appropriate when orbiting around a focus 
	* point. it constrains pitch and ensures smooth terrain collision that keeps the point on the orbit sphere
	*/

	class OrbitConstraints : public ConstraintHandler
	{

	public:

		OrbitConstraints(CameraState const& initial, lgal::world::Vector3 const& focus, CameraController::Camera_time_t const timeMS);

	private:

		static CameraState orbitCollisionUpdate(CameraState const& candidate, lgal::world::Vector3 const& focus, Atlases::HeightAtlas const* atlas);

		static ConstraintHandler::Bounds computeIdealPitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus);
		static ConstraintHandler::Bounds computePitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus);

		static ConstraintHandler::Bounds computeZBounds(CameraState const& initial);
		static ConstraintHandler::Bounds computeRadiusBounds(CameraState const& initial, lgal::world::Vector3 const& focus);

	private:

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocus;

		ConstraintHandler::Bounds const mIdealPitchBounds;
		ConstraintHandler::Bounds const mPitchBounds;

		ConstraintHandler::Bounds const mIdealZBounds;
		ConstraintHandler::Bounds const mZBounds;

		ConstraintHandler::Bounds const mIdealRadiusBounds;
		ConstraintHandler::Bounds const mRadiusBounds;

		lgal::world::Vector3 const mInitialDelta;
		world_float_t const mInitialRadius;

		world_float_t const mZoomTransitionWidth;

		world_float_t mRadiusThreshold;

		CameraState derivedUpdate(ConstraintOptions const& options) override;

	};

} } } }

#endif