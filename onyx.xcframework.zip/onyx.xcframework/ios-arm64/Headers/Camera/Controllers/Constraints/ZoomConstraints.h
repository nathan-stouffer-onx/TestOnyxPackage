#ifndef __ZOOM_CONSTRAINTS_H__
#define __ZOOM_CONSTRAINTS_H__

#include <lucid/gal/Types.h>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "ConstraintHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	/*
	* ZoomConstraints handles constraints when the camera is zooming. Namely when camera is zoomed out, it will 
	* smoothly transfer the pitch to 0. However, it will remember the initial pitch and as you zoom back to the
	* initial position, the constraints will relax and smoothly return to the original pitch
	*/

	class ZoomConstraints : public ConstraintHandler
	{

	public:

		ZoomConstraints(CameraState const& initial, lgal::world::Vector3 const& focus, CameraController::Camera_time_t const timeMS);

	private:

		static ConstraintHandler::Bounds computeZBounds(CameraState const& initial);
		static ConstraintHandler::Bounds computeRadiusBounds(CameraState const& initial, lgal::world::Vector3 const& focus);

	private:

		CameraState const mInitialState;
		lgal::world::Vector3 const mFocus;

		ConstraintHandler::Bounds const mIdealZBounds;
		ConstraintHandler::Bounds const mZBounds;

		ConstraintHandler::Bounds const mIdealRadiusBounds;
		ConstraintHandler::Bounds const mRadiusBounds;

		lgal::world::Vector3 const mInitialDelta;

		world_float_t const mInitialRadius;
		world_float_t const mInitialZoomTheta;
		world_float_t const mInitialZoomPhi;

		world_float_t const mTransitionWidth;

		world_float_t mDeltaThreshold;

		CameraState derivedUpdate(ConstraintOptions const& options) override;

	};

} } } }

#endif