#include "OrbitConstraints.h"

#include <lucid/math/Algorithm.h>

#include <System/OnyxException.h>

#include "Camera/Algorithm.h"
#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	// these constexprs describe how we restrain pitch in a pure orbit (the orbit in the sphere around the focus point)
	static constexpr world_float_t cHardMaxPitch = ConstraintHandler::cGlobalMaxPitch;
	static constexpr world_float_t cHardMinPitch = std::max(ConstraintHandler::cGlobalMinPitch, -0.25);

	static constexpr world_float_t cInitialCruisingHardMaxPitch = 1.4;
	static constexpr world_float_t cInitialCruisingSoftMaxPitch = cInitialCruisingHardMaxPitch - 0.25;
	static constexpr ConstraintHandler::Bounds cInitialClimbBeginBounds = { cHardMinPitch, 0.0, cHardMaxPitch - 0.25, cHardMaxPitch };
	static constexpr ConstraintHandler::Bounds cInitialClimbEndBounds = { cHardMinPitch, 0.0, cInitialCruisingSoftMaxPitch, cInitialCruisingHardMaxPitch };
	static constexpr ConstraintHandler::Climb cInitialClimb = { 1.0, cInitialClimbBeginBounds, 10.0, cInitialClimbEndBounds };

	static constexpr world_float_t cFinalCruisingHardMaxPitch = -cHardMinPitch;
	static constexpr ConstraintHandler::Bounds cFinalClimbBeginBounds = { cHardMinPitch, 0.0, cInitialCruisingSoftMaxPitch, cInitialCruisingHardMaxPitch };
	static constexpr ConstraintHandler::Bounds cFinalClimbEndBounds = { cHardMinPitch, 0.0, 0.0, cFinalCruisingHardMaxPitch };
	static constexpr ConstraintHandler::Climb cFinalClimb = { 1000.0, cFinalClimbBeginBounds, 5000.0, cFinalClimbEndBounds };

	// variables that describe at what radius values we would like to restrain pitch. we begin restraining pitch when the 
	// radius is greater than 0 (cBeginZoomClimb = 0). ideally, by the time we have radius = 30, we will have smoothly 
	// transitioned to have pitch = 0. this isn't always possible because the initial radius might be greater than 30 with 
	// some non-zero pitch. in that case, we do the best we can and smoothly transition to pitch = 0 over an appropriate interval
	static constexpr world_float_t cBeginZoomClimb = 0.0;
	static constexpr world_float_t cEndZoomClimb = 30.0;
	static constexpr world_float_t cCruisingRadiusPitch = 0.0;

	static constexpr world_float_t cMinZoomTransitionIntervalWidth = 30.0;

	// z constraints
	static constexpr world_float_t cMinZ = ConstraintHandler::cGlobalMinZ;
	static constexpr world_float_t cMaxZ = ConstraintHandler::cGlobalMaxZ;
	static constexpr world_float_t cZSoftConstraintMultiplier = 0.9;
	static constexpr ConstraintHandler::Bounds cIdealZBounds = { cMinZ, cMinZ, cZSoftConstraintMultiplier * cMaxZ, cMaxZ };

	// radius constraints
	static constexpr world_float_t cHardMinRadius = 0.015;
	static constexpr world_float_t cSoftMinRadius = 0.020;
	static constexpr world_float_t cMaxRadius = std::numeric_limits<world_float_t>::max();
	static constexpr ConstraintHandler::Bounds cIdealRadiusBounds = { cHardMinRadius, cSoftMinRadius, cMaxRadius, cMaxRadius };

	// we correct orbit terrain collision by binary searching a range of values for a valid pitch.
	// this constexpr describes how many iterations that binary search should run. all that really should
	// be necessary is the number of precision bits in CameraState::pitch, but we'll do the full number
	// of bits in CameraState::pitch for good measure (8 bits in a byte)
	static constexpr size_t cCollisionIterations = 8 * sizeof(CameraState::pitch);

	ConstraintHandler::Bounds OrbitConstraints::computeIdealPitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus)
	{
		// compute the radius
		auto radius = len(initial.position - focus);
		// signbit returns true if the value is negative
		auto signedRadius = (std::signbit(initial.position.z - focus.z)) ? -radius : radius;

		// compute the appropriate constraints based on the signed radius
		if (signedRadius < cInitialClimb.end)
		{
			auto t = (signedRadius - cInitialClimb.begin) / (cInitialClimb.end - cInitialClimb.begin);
			return ConstraintHandler::Bounds::lerpstep(cInitialClimb.beginBounds, cInitialClimb.endBounds, t);
		}
		else
		{
			auto t = (signedRadius - cFinalClimb.end) / (cFinalClimb.end - cFinalClimb.begin);
			return ConstraintHandler::Bounds::lerpstep(cFinalClimb.beginBounds, cFinalClimb.endBounds, t);
		}
	}

	ConstraintHandler::Bounds OrbitConstraints::computePitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus)
	{
		// compute the ideal constraints
		ConstraintHandler::Bounds bounds = OrbitConstraints::computeIdealPitchBounds(initial, focus);

		// adjust bounds for the initial state (so the camera doesn't jump states)
		bounds.hardMin = std::min(initial.pitch, bounds.hardMin);
		bounds.softMin = std::min(initial.pitch, bounds.softMin);
		bounds.softMax = std::max(initial.pitch, bounds.softMax);
		bounds.hardMax = std::max(initial.pitch, bounds.hardMax);

		return bounds;
	}

	ConstraintHandler::Bounds OrbitConstraints::computeZBounds(CameraState const& initial)
	{
		// compute the ideal constraints
		ConstraintHandler::Bounds bounds = cIdealZBounds;

		// adjust bounds for the initial state (so the camera doesn't jump states)
		bounds.hardMin = std::min(initial.position.z, bounds.hardMin);
		bounds.softMin = std::min(initial.position.z, bounds.softMin);
		bounds.softMax = std::max(initial.position.z, bounds.softMax);
		bounds.hardMax = std::max(initial.position.z, bounds.hardMax);

		return bounds;
	}

	ConstraintHandler::Bounds OrbitConstraints::computeRadiusBounds(CameraState const& initial, lgal::world::Vector3 const& focus)
	{
		// compute the ideal constraints
		ConstraintHandler::Bounds bounds = cIdealRadiusBounds;

		world_float_t radius = len(initial.position - focus);

		bounds.hardMin = std::min(radius, bounds.hardMin);
		bounds.softMin = std::min(radius, bounds.softMin);

		return bounds;
	}

	CameraState OrbitConstraints::orbitCollisionUpdate(CameraState const& candidate, lgal::world::Vector3 const& focus, Atlases::HeightAtlas const* atlas)
	{
		CameraState constrained = candidate;

		auto exaggeration = candidate.terrainExaggeration;

		// check if we are below the terrain
		auto height = (atlas) ? exaggeration * atlas->heightAt(constrained.position.xy) : 0.0;
		auto offset = MapMath::mercatorDistortion(constrained.position.xy) * cGlobalMinTerrainOffsetKm;
		if (constrained.position.z < height + offset)
		{
			// if the position is below the terrain, we will binary search to find a valid pitch value. we search the 
			// range [0, constrained.pitch] (or [constrained.pitch, 0], depending on the sign) for a pitch value that 
			// keeps position above the terrain
			struct Endpoint
			{
				// the pitch value of the camera state at the endpoint
				world_float_t pitch;
				// whether the pitch value results in a camera state above the terrain
				bool above;
			};

			// set up the left and right endpoints
			auto left  = (constrained.pitch > 0.0) ? Endpoint{ 0.0, true } : Endpoint{ constrained.pitch, false };
			auto right = (constrained.pitch < 0.0) ? Endpoint{ 0.0, true } : Endpoint{ constrained.pitch, false };
			ONYX_DEBUG_ASSERT(left.pitch <= right.pitch, "left endpoint of binary search must be less than or equal to right endpoint");
			ONYX_DEBUG_ASSERT(left.above != right.above, "binary search must have opposite conditions at endpoints");

			auto pitch = candidate.pitch;
			// loop binary search for a constant number of iterations
			for (size_t i = 0; i < cCollisionIterations; i++)
			{
				// compute the midpoint and update the output pitch
				auto mid = Endpoint{ (left.pitch + right.pitch) / 2.0, false };
				pitch = mid.pitch;

				// compute orbited camera state
				auto deltaPitch = mid.pitch - constrained.pitch;
				auto orbited = Math::orbit(focus, constrained, 0.0, deltaPitch, 0.0);

				// test if the orbited state is above the terrain and update mid appropriately
				height = (atlas) ? exaggeration * atlas->heightAt(orbited.position.xy) : 0.0;
				offset = MapMath::mercatorDistortion(constrained.position.xy) * cGlobalMinTerrainOffsetKm;
				mid.above = (orbited.position.z >= height + offset);

				// update the left and right bounds of the binary search
				left = (left.above == mid.above) ? mid : left;
				right = (right.above == mid.above) ? mid : right;
			}

			// after running the binary search, update the orbited position
			auto deltaPitch = pitch - constrained.pitch;
			constrained = Math::orbit(focus, constrained, 0.0, deltaPitch, 0.0);
		}

		return constrained;
	}

	OrbitConstraints::OrbitConstraints(CameraState const& initial, lgal::world::Vector3 const& focus, CameraController::Camera_time_t const timeMS) :
		mInitialState(initial),
		mFocus(focus),
		mIdealPitchBounds(OrbitConstraints::computeIdealPitchBounds(initial, focus)),
		mPitchBounds(OrbitConstraints::computePitchBounds(initial, focus)),
		mIdealZBounds(cIdealZBounds),
		mZBounds(OrbitConstraints::computeZBounds(initial)),
		mIdealRadiusBounds(cIdealRadiusBounds),
		mRadiusBounds(OrbitConstraints::computeRadiusBounds(initial, focus)),
		mInitialDelta(initial.position - focus),
		mInitialRadius(len(mInitialDelta)),
		mZoomTransitionWidth(std::max(cMinZoomTransitionIntervalWidth, mInitialRadius))
	{
		// the delta value that we begin restricting pitch at
		auto t = lmath::inverseLerp(ConstraintHandler::cGlobalMaxPitch, cCruisingRadiusPitch, mInitialState.pitch);
		mRadiusThreshold = std::max(mInitialRadius, t * (cEndZoomClimb - cBeginZoomClimb));
		
		// passing nullptr for the height atlas is a bit of a bummer because it won't do true terrain collision when computing
		// mLockedState. but since we should always be above the terrain when constructing a camera controller, this won't be
		// too much of an issue. though there is the edge case where the camera is below zero elevation but above the ground
		// (eg Death Valley). I tested in Death Valley and the Dead Sea and so no issues from this
		mLockedState = { timeMS, derivedUpdate(ConstraintOptions{ initial, timeMS, nullptr }) };
	}

	CameraState OrbitConstraints::derivedUpdate(ConstraintOptions const& options)
	{
		CameraState constrained = options.candidate;

		if (mMode == Mode::LOCK)
		{
			// constrain the orbiting points if the radius has changed
			{
				// compute the current radius value
				auto radius = len(constrained.position - mFocus);

				// constrain the camera from zooming in too close
				if (radius < mRadiusBounds.softMin)
				{
					auto dist = ConstraintHandler::dampen(radius, mRadiusBounds.softMin, mRadiusBounds.hardMin);
					lgal::world::Vector3 dir = normalize(constrained.position - mFocus);
					
					constrained.position = mFocus + dist * dir;
				}

				// smoothly move the camera to the cruising altitude pitch if we are above the threshold for delta
				if (radius >= mRadiusThreshold)
				{
					auto t = (radius - mRadiusThreshold) / mZoomTransitionWidth;
					auto deltaPitch = lmath::smoothstep(mInitialState.pitch, cCruisingRadiusPitch, t) - mInitialState.pitch;

					// orbit the camera state around the focus to conform to pitch requirements
					constrained = Math::orbit(mFocus, constrained, 0.0, deltaPitch, 0.0);
				}
			}

			// if we are above the max z value, correct appropriately
			if (constrained.position.z > mZBounds.softMax)
			{
				auto z = ConstraintHandler::dampen(constrained.position.z, mZBounds.softMax, mZBounds.hardMax);

				lgal::world::Ray3 ray = { mFocus, normalize(constrained.position - mFocus) };
				lgal::world::Plane plane = { lgal::world::Vector3{ 0, 0, z }, lgal::world::Vector3{ 0, 0, 1 } };
				constrained.position = Math::pointIntersection(ray, plane);
			}

			// constrain pitch with damping
			{
				// constrain pitch according to minimums and maximums set by this instance
				auto pitch = constrained.pitch;

				// if we are beyond the soft min, dampen the pitch
				if (pitch < mPitchBounds.softMin)
				{
					pitch = ConstraintHandler::dampen(pitch, mPitchBounds.softMin, mPitchBounds.hardMin);
				}
				// if we are beyond the soft max, dampen the pitch
				if (pitch > mPitchBounds.softMax)
				{
					pitch = ConstraintHandler::dampen(pitch, mPitchBounds.softMax, mPitchBounds.hardMax);
				}

				auto deltaPitch = pitch - constrained.pitch;
				constrained = Math::orbit(mFocus, constrained, 0.0, deltaPitch, 0.0);
			}

			// constrain orbiting so that we don't go below the terrain
			constrained = OrbitConstraints::orbitCollisionUpdate(constrained, mFocus, options.atlas);

			return constrained;
		}
		else if (mMode == Mode::ANIMATE)
		{
			constrained = mLockedState.state;

			auto t = (options.timeMS - mLockedState.timeMS) / cAnimationTimeMS;
			t = TimeTransform::evaluate(TimeTransform::Types::SMOOTHSTEP, t);

			// constrain pitch
			{
				auto pitch = constrained.pitch;
				// if we are beyond the ideal soft min, lerp to the soft min
				if (pitch < mIdealPitchBounds.softMin)
				{
					pitch = lmath::lerp(mLockedState.state.pitch, mIdealPitchBounds.softMin, t);
				}
				// if we are beyond the ideal soft max, lerp to the soft max
				if (pitch > mIdealPitchBounds.softMax)
				{
					pitch = lmath::lerp(mLockedState.state.pitch, mIdealPitchBounds.softMax, t);
				}

				auto deltaPitch = pitch - constrained.pitch;
				constrained = Math::orbit(mFocus, constrained, 0.0, deltaPitch, 0.0);
			}

			auto delta = constrained.position - mFocus;
			auto dist = len(delta);

			// if we are too close, correct appropriately
			if (dist < mRadiusBounds.softMin)
			{
				auto radius = lmath::lerp(dist, mIdealRadiusBounds.softMin, t);
				lgal::world::Vector3 dir = normalize(mLockedState.state.position - mFocus);
				
				constrained.position = mFocus + radius * dir;
			}

			// if we are above the max z value, correct appropriately
			if (constrained.position.z > mIdealZBounds.softMax)
			{
				auto z = lmath::lerp(mLockedState.state.position.z, mIdealZBounds.softMax, t);

				lgal::world::Ray3 ray = { mFocus, normalize(delta) };
				lgal::world::Plane plane = { lgal::world::Vector3{ 0, 0, z }, lgal::world::Vector3{ 0, 0, 1 } };
				constrained.position = Math::pointIntersection(ray, plane);
			}

			return constrained;
		}
		else
		{
			return constrained;
		}
	}

} } } }