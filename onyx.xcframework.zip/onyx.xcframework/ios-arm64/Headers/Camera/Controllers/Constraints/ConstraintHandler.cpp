#include "ConstraintHandler.h"

#include "Camera/Algorithm.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	CameraState ConstraintHandler::update(ConstraintOptions const& options)
	{
		// compute the constrained position from the derived handler
		CameraState constrained = derivedUpdate(options);

		// override camera state with general constraints and naive collision detection
		constrained = generalUpdate(constrained);
		constrained = collisionUpdate(constrained, options.atlas);
		
		if (mMode == Mode::LOCK)
		{
			mChanged = constrained != mLockedState.state;
			mLockedState = { options.timeMS, constrained };
		}

		return constrained;
	}

	CameraState ConstraintHandler::generalUpdate(CameraState const& candidate)
	{
		// initially copy the current state to preserve fov and such
		CameraState constrained = candidate;
		constrained.position.xy = MapMath::moduloX(constrained.position.xy);

		// constrain position to be in the world bounds
		lgal::world::Vector3 min = { cGlobalMinX, cGlobalMinY, cGlobalMinZ };
		lgal::world::Vector3 max = { cGlobalMaxX, cGlobalMaxY, cGlobalMaxZ };
		constrained.position = clamp(constrained.position, min, max);

		// make sure heading is in [0, 2pi]
		constrained.heading = lmath::canonicalAngle(constrained.heading);

		// clamp pitch to the absolue min and max values
		constrained.pitch = std::clamp(constrained.pitch, cGlobalMinPitch, cGlobalMaxPitch);

		// return the constrained state
		return constrained;
	}

	CameraState ConstraintHandler::collisionUpdate(CameraState const& candidate, Atlases::HeightAtlas const* atlas)
	{
		// initially copy the current state to preserve fov and such
		CameraState constrained = candidate;

		auto exaggeration = candidate.terrainExaggeration;

		if (atlas)
		{
			auto mapHeight = exaggeration * atlas->heightAt(constrained.position.xy);
			auto offset = MapMath::mercatorDistortion(constrained.position.xy) * cGlobalMinTerrainOffsetKm;
			constrained.position.z = std::max(constrained.position.z, mapHeight + offset);
		}
		else
		{
			constrained.position.z = std::max(constrained.position.z, cGlobalMinTerrainOffsetKm);
		}

		return constrained;
	}
	
} } } }