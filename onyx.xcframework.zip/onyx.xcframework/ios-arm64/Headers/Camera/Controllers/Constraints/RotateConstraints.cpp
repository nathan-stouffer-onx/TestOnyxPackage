#include "RotateConstraints.h"

#include <lucid/math/Algorithm.h>

#include "Camera/TimeTransform.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	static constexpr world_float_t cHardMaxPitch = ConstraintHandler::cGlobalMaxPitch;
	static constexpr world_float_t cHardMinPitch = std::max(ConstraintHandler::cGlobalMinPitch, -0.15);

	static constexpr world_float_t cInitialCruisingHardMaxPitch = 3.1415926535 / 2.0;
	static constexpr world_float_t cInitialCruisingSoftMaxPitch = cInitialCruisingHardMaxPitch - 0.25;
	static constexpr ConstraintHandler::Bounds cInitialClimbBeginBounds = { cHardMinPitch, 0.0, cHardMaxPitch - 0.25, cHardMaxPitch };
	static constexpr ConstraintHandler::Bounds cInitialClimbEndBounds = { cHardMinPitch, 0.0, cInitialCruisingSoftMaxPitch, cInitialCruisingHardMaxPitch };
	static constexpr ConstraintHandler::Climb cInitialClimb = { -0.100, cInitialClimbBeginBounds, 0.250, cInitialClimbEndBounds };

	static constexpr world_float_t cFinalCruisingHardMaxPitch = -cHardMinPitch;
	static constexpr ConstraintHandler::Bounds cFinalClimbBeginBounds = { cHardMinPitch, 0.0, cInitialCruisingSoftMaxPitch, cInitialCruisingHardMaxPitch };
	static constexpr ConstraintHandler::Bounds cFinalClimbEndBounds = { cHardMinPitch, 0.0, 0.0, cFinalCruisingHardMaxPitch };
	static constexpr ConstraintHandler::Climb cFinalClimb = { 1000.0, cFinalClimbBeginBounds, 5000.0, cFinalClimbEndBounds };

	ConstraintHandler::Bounds RotateConstraints::computeIdealPitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus)
	{
		auto deltaZ = initial.position.z - focus.z;
		if (deltaZ < cInitialClimb.end)
		{
			auto t = (deltaZ - cInitialClimb.begin) / (cInitialClimb.end - cInitialClimb.begin);
			return ConstraintHandler::Bounds::lerpstep(cInitialClimb.beginBounds, cInitialClimb.endBounds, t);
		}
		else
		{
			auto t = (deltaZ - cFinalClimb.end) / (cFinalClimb.end - cFinalClimb.begin);
			return ConstraintHandler::Bounds::lerpstep(cFinalClimb.beginBounds, cFinalClimb.endBounds, t);
		}
	}

	ConstraintHandler::Bounds RotateConstraints::computePitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus)
	{
		// compute the ideal constraints
		ConstraintHandler::Bounds bounds = RotateConstraints::computeIdealPitchBounds(initial, focus);

		// adjust bounds for the initial state (so the camera doesn't jump states)
		bounds.hardMin = std::min(initial.pitch, bounds.hardMin);
		bounds.softMin = std::min(initial.pitch, bounds.softMin);
		bounds.softMax = std::max(initial.pitch, bounds.softMax);
		bounds.hardMax = std::max(initial.pitch, bounds.hardMax);

		return bounds;
	}

	RotateConstraints::RotateConstraints(CameraState const& initial, lgal::world::Vector3 const& focus, CameraController::Camera_time_t const timeMS) :
		mInitialState(initial),
		mIdealPitchBounds(RotateConstraints::computeIdealPitchBounds(initial, focus)),
		mPitchBounds(RotateConstraints::computePitchBounds(initial, focus))
	{
		mLockedState = { timeMS, derivedUpdate(ConstraintOptions{ initial, timeMS, nullptr }) };
	}

	CameraState RotateConstraints::derivedUpdate(ConstraintOptions const& options)
	{
		CameraState constrained = options.candidate;

		if (mMode == Mode::LOCK)
		{
			auto pitch = constrained.pitch;
			// if we are beyond the soft min, dampen the pitch
			if (pitch < mPitchBounds.softMin)
			{
				pitch = ConstraintHandler::dampen(pitch, mPitchBounds.softMin, mPitchBounds.hardMin);
			}
			// if we are beyond the soft max, dampen the pitch
			if (pitch > mPitchBounds.softMax)
			{
				pitch = ConstraintHandler::dampen(pitch, mPitchBounds.softMax, mPitchBounds.hardMax);
			}

			// override the pitch value
			constrained.pitch = pitch;

			return constrained;
		}
		else if (mMode == Mode::ANIMATE)
		{
			constrained = mLockedState.state;

			auto t = (options.timeMS - mLockedState.timeMS) / cAnimationTimeMS;
			t = TimeTransform::evaluate(TimeTransform::Type::SMOOTHSTEP, t);

			// animate pitch
			{
				auto pitch = constrained.pitch;
				// if we are beyond the ideal soft min, lerp to the soft min
				if (pitch < mIdealPitchBounds.softMin)
				{
					pitch = lmath::lerp(mLockedState.state.pitch, mIdealPitchBounds.softMin, t);
				}
				// if we are beyond the ideal soft max, lerp to the soft max
				if (pitch > mIdealPitchBounds.softMax)
				{
					pitch = lmath::lerp(mLockedState.state.pitch, mIdealPitchBounds.softMax, t);
				}

				// override the pitch value
				constrained.pitch = pitch;
			}

			return constrained;
		}
		else
		{
			return constrained;
		}
	}

} } } }