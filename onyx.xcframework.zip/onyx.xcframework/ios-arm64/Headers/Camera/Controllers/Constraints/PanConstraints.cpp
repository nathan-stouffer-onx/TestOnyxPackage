#include "PanConstraints.h"

#include <cmath>

#include "Camera/TimeTransform.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	static constexpr world_float_t cSoftConstraintMultiplier = 0.8;

	// compute the x/y bounds based on the following triangle. we care about the distance d, which we are able to compute as
	//      (1) d = eye.z * tan(fov/2)
	// this means the closest we can get to the each edge of the square world is d
	// 
	//                eye.z
	//              /|
	//             / |
	//            /  |
	//           /   |
	//          /    |
	//         /_____| z = 0
	//            d
	//
	// NOTE: we must account for aspect ratio when computing the bounds in x/y directions
	ConstraintHandler::Bounds PanConstraints::computeIdealYBounds(CameraState const& initial)
	{
		auto halfHeight = 0.0;
		// if we are above sea level, compute dist based on the above triangle
		if (initial.position.z > 0.0)
		{
			auto halfFovRad = 0.5 * initial.fov * lmath::constants::pi<world_float_t>() / 180.0;
			// this is half the height of the frustum at the z = 0 plane
			halfHeight = initial.position.z * std::tan(halfFovRad);
		}

		// compute magnitude of the bounds for eye.y
		auto mag = 0.5 * Tiles::cMaxExtent - halfHeight;

		// compute the bounds
		return { -mag, -cSoftConstraintMultiplier * mag, cSoftConstraintMultiplier * mag, mag };
	}

	ConstraintHandler::Bounds PanConstraints::computeYBounds(CameraState const& initial)
	{
		ConstraintHandler::Bounds bounds = PanConstraints::computeIdealYBounds(initial);

		// adjust bounds for the initial state (so the camera doesn't jump states)
		bounds.hardMin = std::min(initial.position.y, bounds.hardMin);
		bounds.softMin = std::min(initial.position.y, bounds.softMin);
		bounds.softMax = std::max(initial.position.y, bounds.softMax);
		bounds.hardMax = std::max(initial.position.y, bounds.hardMax);

		return bounds;
	}

	PanConstraints::PanConstraints(CameraState const& initial, CameraController::Camera_time_t const timeMS) :
		mInitialState(initial),
		mIdealYBounds(PanConstraints::computeIdealYBounds(initial)),
		mYBounds(PanConstraints::computeYBounds(initial))
	{
		mLockedState = { timeMS, derivedUpdate(ConstraintOptions{ initial, timeMS, nullptr }) };
	}

	CameraState PanConstraints::derivedUpdate(ConstraintOptions const& options)
	{
		CameraState constrained = options.candidate;

		if (mMode == Mode::LOCK)
		{
			// constrain y position
			{
				// dampen if we are beyond the soft min
				if (constrained.position.y < mYBounds.softMin)
				{
					constrained.position.y = ConstraintHandler::dampen(constrained.position.y, mYBounds.softMin, mYBounds.hardMin);
				}
				// dampen if we are beyond the soft max
				if (constrained.position.y > mYBounds.softMax)
				{
					constrained.position.y = ConstraintHandler::dampen(constrained.position.y, mYBounds.softMax, mYBounds.hardMax);
				}
			}

			return constrained;
		}
		else if (mMode == Mode::ANIMATE)
		{
			constrained = mLockedState.state;

			auto t = (options.timeMS - mLockedState.timeMS) / cAnimationTimeMS;
			t = TimeTransform::evaluate(TimeTransform::Types::SMOOTHSTEP, t);

			// animate the y value
			{
				auto y = constrained.position.y;
				// if we are beyond the ideal soft min, lerp to the soft min
				if (y < mIdealYBounds.softMin)
				{
					y = lmath::lerp(mLockedState.state.position.y, mIdealYBounds.softMin, t);
				}
				// if we are beyond the ideal soft max, lerp to the soft max
				if (y > mIdealYBounds.softMax)
				{
					y = lmath::lerp(mLockedState.state.position.y, mIdealYBounds.softMax, t);
				}

				// override the y value
				constrained.position.y = y;
			}

			// if we are overpitched, animate to 0
			if (constrained.pitch < 0.0)
			{
				constrained.pitch = lmath::lerp(mLockedState.state.pitch, 0.0, t);
			}

			return constrained;
		}
		else
		{
			return constrained;
		}
	}

} } } }