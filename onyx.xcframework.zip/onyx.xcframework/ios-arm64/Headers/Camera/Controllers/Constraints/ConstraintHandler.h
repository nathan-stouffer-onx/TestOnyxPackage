#ifndef __CAMERA_CONSTRAINT_HANDLER_H__
#define __CAMERA_CONSTRAINT_HANDLER_H__

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Utils/MapMath.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	/*
	* Abstract class that defines the core elements of a ConstraintHandler. it's primary purpose is to
	* define some global camera constraints that should never be violated as well as call into a derived
	* class for more specific camera constraints
	* 
	* This header also defines a mode in which to apply the constraints. derived controllers should account
	* for this and apply their constraints in line with the mode
	*/

	// this enum describes the mode a constraint handler should apply constraints in. in LOCK mode, the handler
	// takes in the candidate CameraState and, if it violates constraints, locks it to a state that does not violate
	// constraints -- somewhere between the soft and hard bounds. in ANIMATE mode, the handler animates between 
	// the last locked state and the ideal constraints
	enum class Mode
	{
		LOCK,
		ANIMATE
	};

	class ConstraintHandler
	{

	public:

		// global constraints for camera position
		static constexpr world_float_t cGlobalMinX = Tiles::cLeftX;
		static constexpr world_float_t cGlobalMaxX = Tiles::cRightX;
		static constexpr world_float_t cGlobalMinY = Tiles::cTopY;
		static constexpr world_float_t cGlobalMaxY = Tiles::cBotY;
		static constexpr world_float_t cGlobalMinZ = -0.5;
		static constexpr world_float_t cGlobalMaxZ = Tiles::cMaxExtent / 2.0;

		// global constrants for min/max pitch
		static constexpr world_float_t cGlobalMinPitch = -0.4;
		static constexpr world_float_t cGlobalMaxPitch = 2.1;

		// global minimum offset from the terrain (measured in km)
		static constexpr world_float_t cGlobalMinTerrainOffsetKm = 0.0075;

		// time it takes to animate to soft constraints
		static constexpr CameraController::Camera_time_t cAnimationTimeMS = 750.0;

		// a small struct that describe the bounds of a property. the values should satisfy the following property
		//      (1) hardMin <= softMin <= softMax <= hardMax
		// the function ConstraintHandler::dampen can be used to map values outside the soft bounds to the interval
		// in between the soft and hard max. that is, the range (-inf, softMin] --> (hardMin, softMin] and 
		// [softMax, +inf) --> [softMax, hardMax)
		struct Bounds
		{
			world_float_t hardMin;
			world_float_t softMin;
			world_float_t softMax;
			world_float_t hardMax;

			static inline Bounds lerpstep(Bounds const& a, Bounds const& b, world_float_t t)
			{
				if (t <= 0.0)
				{
					return a;
				}
				else if (0.0 < t && t < 1.0)
				{
					return
					{
						lmath::lerpstep(a.hardMin, b.hardMin, t),
						lmath::lerpstep(a.softMin, b.softMin, t),
						lmath::lerpstep(a.softMax, b.softMax, t),
						lmath::lerpstep(a.hardMax, b.hardMax, t),
					};
				}
				else
				{
					return b;
				}
			}
		};

		// a struct that describes a sort of "climb" in constraints. based on some parameter (eg orbit radius or deltaZ),
		// we lerpstep between the bound structures at beginning and end of the climb to get the appropriate bounds for
		// some initial camera state
		struct Climb
		{
			// value the climb begins at
			world_float_t begin;
			// bounds at the beginning of the climb
			Bounds beginBounds;

			// value the climb ends at
			world_float_t end;
			// bounds at the end of the climb
			Bounds endBounds;
		};

		ConstraintHandler(Mode mode = Mode::LOCK) : mMode(mode) {}
		virtual ~ConstraintHandler() {}

		struct ConstraintOptions
		{
			CameraState const& candidate;
			CameraController::Camera_time_t const timeMS;
			Atlases::HeightAtlas const* atlas;

			ConstraintOptions(CameraState const& _candidate, CameraController::Camera_time_t const _timeMS, Atlases::HeightAtlas const* _atlas) :
				candidate(_candidate), timeMS(_timeMS), atlas(_atlas)
			{}

		};

		CameraState update(ConstraintOptions const& options);

		// returns whether the last call to constraintUpdate changed the value of the locked CameraState
		inline bool changed() const { return mChanged; }

		inline void setMode(Mode mode) { mMode = mode; }
		inline Mode getMode() const { return mMode; }

	protected:

		struct LockedState
		{
			CameraController::Camera_time_t timeMS;
			CameraState state;

			LockedState(CameraController::Camera_time_t const timeMS, CameraState const& state) :
				timeMS(timeMS), state(state) {}
		};

		Mode mMode;

		LockedState mLockedState = { 0.0, {} };

		bool mChanged = true;

		// function that dampens the input val when it is beyond the value of the soft bound. note that softBound
		// and hardBound can refer to either maximums or minimums because the signs cancel. for this comment,
		// we will assume that the bounds refer to maximums (there is an analogous set of properties for minimums)
		// 
		// this function maps [softBound, +inf) to [softBound, hardBound) with the following useful properties
		//    (1) dampen(softBound) = softBound         damping is continous with not damping
		//    (2) dampen'(softBound) = 1                derivative of damping is continuous with derivative of not damping
		//    (3) lim x -> +inf dampen(x) = hardBound   we approach the hard bound as we get further from the soft bound
		//    (4) dampen(x) < hardBound for all x       we never exceed the hard bound
		//
		// properties (1) and (2) mean that the transition from damping to not damping is C^1. this makes for 
		// a nice, smooth transition between unrestricted movement and damped movement
		inline static world_float_t dampen(world_float_t val, world_float_t softBound, world_float_t hardBound)
		{
			auto diff = hardBound - softBound;
			if (diff == 0.0)
			{
				return hardBound;
			}
			auto x = (2.0 / diff) * (val - softBound);
			return softBound + diff * (2.0 * lucid::math::sigmoid(x) - 1.0);
		}

	private:

		// method for a derived class to implement and constrain the camera in a nice way
		virtual CameraState derivedUpdate(ConstraintOptions const& options) = 0;

		// update the state for general camera constraints
		CameraState generalUpdate(CameraState const& candidate);
		// update the state to make sure we don't go under the terrain
		CameraState collisionUpdate(CameraState const& candidate, Atlases::HeightAtlas const* atlas);

	};

} } } }

#endif