#ifndef __PAN_CONSTRAINTS_H__
#define __PAN_CONSTRAINTS_H__

#include <lucid/gal/Types.h>

#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "ConstraintHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	/*
	* PanConstraints handles constraints when the camera is panning around the map. Namely, when camera is near
	* the edges of the map, it will smoothly stop motion to prevent the user from seeing the clear color.
	*/

	class PanConstraints : public ConstraintHandler
	{

	public:

		PanConstraints(CameraState const& initial, CameraController::Camera_time_t const timeMS);

	private:

		static ConstraintHandler::Bounds computeIdealYBounds(CameraState const& initial);
		static ConstraintHandler::Bounds computeYBounds(CameraState const& initial);

	private:

		CameraState const mInitialState;

		ConstraintHandler::Bounds const mIdealYBounds;
		ConstraintHandler::Bounds const mYBounds;

		CameraState derivedUpdate(ConstraintOptions const& options) override;

	};

} } } }

#endif