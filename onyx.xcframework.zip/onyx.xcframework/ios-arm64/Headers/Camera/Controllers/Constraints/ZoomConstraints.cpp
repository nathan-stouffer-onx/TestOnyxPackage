#include "ZoomConstraints.h"

#include <lucid/math/Algorithm.h>

#include "Camera/Algorithm.h"
#include "Camera/TimeTransform.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	// variables that describe at what values we would like to restrain pitch. we begin restraining pitch when the focus point
	// and the initial state are at the same z value (cBeginClimb = 0). ideally, by the time we reach a difference of 30 in our
	// z value, we will have smoothly transitioned to have pitch = 0. this isn't always possible because the initial camera
	// position might be at a delta greater than 30 with some non-zero pitch. in that case, we do the best we can and smoothly
	// transition to pitch = 0 over an appropriate interval
	static constexpr world_float_t cBeginClimb = 0.0;
	static constexpr world_float_t cEndClimb = 30.0;
	static constexpr world_float_t cCruisingAltitudePitch = 0.0;

	static constexpr world_float_t cMinTransitionIntervalWidth = 30.0;

	// z bounds
	static constexpr world_float_t cMinZ = ConstraintHandler::cGlobalMinZ;
	static constexpr world_float_t cMaxZ = ConstraintHandler::cGlobalMaxZ;
	static constexpr world_float_t cZSoftConstraintMultiplier = 0.9;
	static constexpr ConstraintHandler::Bounds cIdealZBounds = { cMinZ, cMinZ, cZSoftConstraintMultiplier * cMaxZ, cMaxZ };
	
	// radius bounds
	static constexpr world_float_t cHardMinRadius = 0.015;
	static constexpr world_float_t cSoftMinRadius = 0.020;
	static constexpr world_float_t cMaxRadius = std::numeric_limits<world_float_t>::max();
	static constexpr ConstraintHandler::Bounds cIdealRadiusBounds = { cHardMinRadius, cSoftMinRadius, cMaxRadius, cMaxRadius };

	ConstraintHandler::Bounds ZoomConstraints::computeZBounds(CameraState const& initial)
	{
		// compute the ideal constraints
		ConstraintHandler::Bounds bounds = cIdealZBounds;

		// adjust bounds for the initial state (so the camera doesn't jump states)
		bounds.hardMin = std::min(initial.position.z, bounds.hardMin);
		bounds.softMin = std::min(initial.position.z, bounds.softMin);
		bounds.softMax = std::max(initial.position.z, bounds.softMax);
		bounds.hardMax = std::max(initial.position.z, bounds.hardMax);

		return bounds;
	}

	ConstraintHandler::Bounds ZoomConstraints::computeRadiusBounds(CameraState const& initial, lgal::world::Vector3 const& focus)
	{
		// compute the ideal constraints
		ConstraintHandler::Bounds bounds = cIdealRadiusBounds;

		world_float_t radius = len(initial.position - focus);

		bounds.hardMin = std::min(radius, bounds.hardMin);
		bounds.softMin = std::min(radius, bounds.softMin);

		return bounds;
	}

	ZoomConstraints::ZoomConstraints(CameraState const& initial, lgal::world::Vector3 const& focus, CameraController::Camera_time_t const timeMS) :
		mInitialState(initial),
		mFocus(focus),
		mIdealZBounds(cIdealZBounds),
		mZBounds(ZoomConstraints::computeZBounds(initial)),
		mIdealRadiusBounds(cIdealRadiusBounds),
		mRadiusBounds(ZoomConstraints::computeRadiusBounds(initial, focus)),
		mInitialDelta(initial.position - focus),
		mInitialRadius(len(mInitialDelta)),
		mInitialZoomTheta(std::atan2(mInitialDelta.y, mInitialDelta.x)),
		mInitialZoomPhi(std::acos(std::clamp(mInitialDelta.z / mInitialRadius, -1.0, 1.0))),	// clamp to [-1.0, 1.0] to avoid NaNs resulting from finite precision
		mTransitionWidth(std::max(cMinTransitionIntervalWidth, 0.75 * mInitialDelta.z))
	{
		// the delta value that we begin restricting pitch at
		auto t = lmath::inverseLerp(ConstraintHandler::cGlobalMaxPitch, cCruisingAltitudePitch, mInitialState.pitch);
		mDeltaThreshold = std::max(mInitialDelta.z, t * (cEndClimb - cBeginClimb));
	
		mLockedState = { timeMS, derivedUpdate(ConstraintOptions{ initial, timeMS, nullptr }) };
	}

	CameraState ZoomConstraints::derivedUpdate(ConstraintOptions const& options)
	{
		CameraState constrained = options.candidate;

		if (mMode == Mode::LOCK)
		{
			// compute the current delta value
			auto delta = constrained.position.z - mFocus.z;
			auto dist = len(constrained.position - mFocus);

			// constrain the camera from zooming in too close
			if (dist < mRadiusBounds.softMin)
			{
				auto radius = ConstraintHandler::dampen(dist, mRadiusBounds.softMin, mRadiusBounds.hardMin);

				lgal::world::Vector3 dir =
				{ 
					std::cos(mInitialZoomTheta) * std::sin(mInitialZoomPhi),
					std::sin(mInitialZoomTheta) * std::sin(mInitialZoomPhi),
					std::cos(mInitialZoomPhi)
				};
				constrained.position = mFocus + radius * dir;
			}

			// smoothly move the camera to the cruising altitude pitch if we are above the threshold for delta
			if (delta >= mDeltaThreshold)
			{
				auto t = (delta - mDeltaThreshold) / mTransitionWidth;
				auto deltaPitch = lmath::smoothstep(mInitialState.pitch, cCruisingAltitudePitch, t) - mInitialState.pitch;

				lgal::world::Vector3 const& eye = mInitialState.position;
				if (eye.x == mFocus.x && eye.y == mFocus.y)		// check for edge case where eye and focus are on top of each other
				{
					// edit the pitch directly
					constrained.pitch = mInitialState.pitch + deltaPitch;
				}
				else
				{
					// orbit the camera state around the focus to conform to pitch requirements
					constrained = Math::orbit(mFocus, constrained, 0.0, deltaPitch, 0.0);
				}
			}

			// if we are above the max z value, correct appropriately
			if (constrained.position.z > mZBounds.softMax)
			{
				auto z = ConstraintHandler::dampen(constrained.position.z, mZBounds.softMax, mZBounds.hardMax);

				lgal::world::Ray3 ray = { mFocus, normalize(constrained.position - mFocus) };
				lgal::world::Plane plane = { lgal::world::Vector3{ 0, 0, z }, lgal::world::Vector3{ 0, 0, 1 } };
				constrained.position = Math::pointIntersection(ray, plane);
			}

			// based on the z value, constrain y position
			if (constrained.position.z > 0.0)
			{
				// compute half the height and width of the frustum at the z = 0 plane
				auto halfYFovRad = 0.5 * constrained.fov * lmath::constants::pi<world_float_t>() / 180.0;
				auto halfHeight = constrained.position.z * std::tan(halfYFovRad);

				// compute magnitude of the bounds for y components
				auto yMag = 0.5 * Tiles::cMaxExtent - halfHeight;

				constrained.position.y = std::clamp(constrained.position.y, -yMag, yMag);
			}

			// return the constrained controller
			return constrained;
		}
		else if (mMode == Mode::ANIMATE)
		{
			constrained = mLockedState.state;

			auto t = (options.timeMS - mLockedState.timeMS) / cAnimationTimeMS;
			t = TimeTransform::evaluate(TimeTransform::Types::SMOOTHSTEP, t);

			auto delta = constrained.position - mFocus;
			auto dist = len(delta);
			
			// if we are too close, correct appropriately
			if (dist < mRadiusBounds.softMin)
			{
				auto radius = lmath::lerp(dist, mIdealRadiusBounds.softMin, t);

				lgal::world::Vector3 dir =
				{
					std::cos(mInitialZoomTheta) * std::sin(mInitialZoomPhi),
					std::sin(mInitialZoomTheta) * std::sin(mInitialZoomPhi),
					std::cos(mInitialZoomPhi)
				};
				constrained.position = mFocus + radius * dir;
			}

			// if we are above the max z value, correct appropriately
			if (constrained.position.z > mIdealZBounds.softMax)
			{
				auto z = lmath::lerp(mLockedState.state.position.z, mIdealZBounds.softMax, t);

				lgal::world::Ray3 ray = { mFocus, lmath::normalize(delta) };
				lgal::world::Plane plane = { lgal::world::Vector3{ 0, 0, z }, lgal::world::Vector3{ 0, 0, 1 } };
				constrained.position = Math::pointIntersection(ray, plane);
			}
			
			return constrained;
		}
		else
		{
			return constrained;
		}
	}

} } } }