#ifndef __ROTATE_CONSTRAINTS_H__
#define __ROTATE_CONSTRAINTS_H__

#include <lucid/gal/Types.h>

#include "ConstraintHandler.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Constraints {

	/*
	* RotateConstraints provides constraints for the camera that are appropriate when the camera stays at a single
	* location and just changes heading/pitch (spin).
	*/

	class RotateConstraints : public ConstraintHandler
	{

	public:

		RotateConstraints(CameraState const& initial, lgal::world::Vector3 const& focus, CameraController::Camera_time_t const timeMS);

	private:

		static ConstraintHandler::Bounds computeIdealPitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus);
		static ConstraintHandler::Bounds computePitchBounds(CameraState const& initial, lgal::world::Vector3 const& focus);

	private:

		CameraState const mInitialState;

		ConstraintHandler::Bounds const mIdealPitchBounds;
		ConstraintHandler::Bounds const mPitchBounds;

		CameraState derivedUpdate(ConstraintOptions const& options) override;

	};

} } } }

#endif