#include "FreeBodyPhysics.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Physics {

	FreeBodyPhysics::FreeBodyPhysics(FreeBodyPhysics::KinematicState const& initial, Mode mode) :
		PhysicsHandler(mode),
		mKinematicState(initial)
	{}

	CameraState FreeBodyPhysics::update(CameraState const& currentState, double timeMS)
	{
		if (mMode == Mode::TRACK)
		{
			// compute the change in time
			auto deltaT = timeMS - mKinematicState.timeMS;

			// check that deltaT > 0.0 (the controller might be allocated after the frame begins at timeMS)
			if (deltaT > 0.0)
			{
				// compute the change in position, heading, and pitch
				auto deltaPos = currentState.position - mKinematicState.state.position;
				auto deltaHeading = currentState.heading - mKinematicState.state.heading;
				auto deltaPitch = currentState.pitch - mKinematicState.state.pitch;

				// compute the velocities
				auto posVel = deltaPos / deltaT;
				auto headingVel = deltaHeading / deltaT;
				auto pitchVel = deltaPitch / deltaT;

				bool inWindow = deltaT <= cPhysicsDropWindowMS;
				bool hasChanged = !(lmath::len(deltaPos) == 0.0 && deltaHeading == 0.0 && deltaPitch == 0.0);
				if (inWindow && hasChanged)	// if in the drop window, only update if the position/heading/pitch has changed
				{
					mKinematicState = { timeMS, currentState, { posVel, headingVel, pitchVel } };
				}
				else if (!inWindow)	// if not in the window, update regardless
				{
					mKinematicState = { timeMS, currentState, { posVel, headingVel, pitchVel } };
				}
			}

			// return the passed in state, we just wanted to gather information
			return currentState;
		}
		else if (mMode == Mode::APPLY)
		{
			// start by copying the initial conditions of the kinematic state
			CameraState state = mKinematicState.state;

			// compute t (the time since the release point)
			auto t = timeMS - mKinematicState.timeMS;

			// compute the change in position, heading, and pitch
			auto pos = solveIVP(state.position, mKinematicState.velocities.position, cPosDrag, t);
			auto heading = solveIVP(state.heading, mKinematicState.velocities.heading, cHeadingDrag, t);
			auto pitch = solveIVP(state.pitch, mKinematicState.velocities.pitch, cPitchDrag, t);

			// update the camera state
			state.position = pos;
			state.heading = heading;
			state.pitch = pitch;

			// return the state
			return state;
		}
		else
		{
			return currentState;
		}
	}

} } } }