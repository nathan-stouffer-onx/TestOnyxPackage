#ifndef __CAMERA_PHYSICS_HANDLER_H__
#define __CAMERA_PHYSICS_HANDLER_H__

#include "Camera/CameraState.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Physics {

	/* 
	* an abstract class to define the core elements of a physics handler. it's primary purpose is 
	* to store whether physics should be tracked or applied on the current frame and enforce that
	* any controller inheriting from PhysicsHandler must implement the function physicsUpdate
	* 
	* we also define a number of constexpr in this file. values with names of the form c*Drag specify
	* a drag constant that is applied to that attribute in the differential equation
	*                u"(t) = -k * u'(t)
	* the solution to this differential equation (with the appropriate initial values) provides a
	* smooth way to apply drag to a movement based on whether the camera was moving when the 
	* interaction completes. k follows this pattern:
	*      k = 0  => no drag
	*      k > 0  => apply some drag (motion will slow down)
	*      k >> 0 => infinite drag (immediately stop)
	*
	* cMaxTail defines a maximum value for the function f(t) = 1.0 - exp(-k * t) which maps [0, +inf)
	* to the range [0, 1) -- note that f is strictly increasing. this avoids trailing, imperceptible 
	* camera movement as t tends towards infinity.
	* 
	* the final constexpr in this header file is cPhysicsDropWindowMS. this is here because computing
	* the velocity of the camera based on the previous frame often results in the camera having
	* 0 velocity in cases where we still want the camera to move. derived classes of PhysicsController
	* should ignore updating their velocities for frames that are both in the window and do not change
	* the relevant properties the controller tracks (drop recent frames that don't change position/heading/pitch)
	*/

	// this enum describes the mode of the PhysicsHandler. in TRACK mode, the handler takes in the camera
	// state and updates its positions/velocites (kinematic state) for the values that it tracks. in APPLY 
	// mode, the handler uses the last kinematic state and smoothly applies drag until the camera slows down
	enum class Mode
	{
		TRACK,
		APPLY
	};

	class PhysicsHandler
	{

	public:

		PhysicsHandler(Mode mode = Mode::TRACK) : mMode(mode) {}
		virtual ~PhysicsHandler() {}

		virtual CameraState update(CameraState const& currentState, double timeMS) = 0;

		inline void setMode(Mode mode) { mMode = mode; }
		inline Mode getMode() const { return mMode; }

	protected:

		static constexpr double cPosDrag = 0.0063;
		static constexpr double cHeadingDrag = 0.00775;
		static constexpr double cPitchDrag = 0.00775;
		static constexpr double cRadiusDrag = 0.005;

		static constexpr double cMaxTail = 0.99;

		static constexpr double cPhysicsDropWindowMS = 25.0;

		Mode mMode;

		// function to solve the initial value problem for the differential equation a(t) = -k * v(t)
		template<typename T>
		static T solveIVP(T pos, T vel, double drag, double t, bool capTail = true)
		{
			auto tail = 1.0 - std::exp(-drag * t);
			// cap the tail of the exponential at cMaxTail
			if (capTail)
			{
				tail = std::min(cMaxTail, tail);
			}
			auto delta = vel / drag * tail;
			return pos + delta;
		}

	};

} } } }

#endif