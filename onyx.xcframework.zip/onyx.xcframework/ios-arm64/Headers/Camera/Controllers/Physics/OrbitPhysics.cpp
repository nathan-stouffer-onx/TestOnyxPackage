#include "OrbitPhysics.h"

#include "Camera/Algorithm.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Physics {

	OrbitPhysics::OrbitPhysics(lgal::world::Vector3 const& orbitPoint, OrbitPhysics::KinematicState const& initial, Mode mode) :
		PhysicsHandler(mode),
		mOrbitPoint(orbitPoint),
		mKinematicState(initial)
	{}

	CameraState OrbitPhysics::update(CameraState const& currentState, double timeMS)
	{
		if (mMode == Mode::TRACK)
		{
			// compute the change in time
			auto deltaT = timeMS - mKinematicState.timeMS;

			// check that deltaT > 0.0 (the controller might be allocated after the frame begins at timeMS)
			if (deltaT > 0.0)
			{
				// compute the current and previous radius
				auto currentRadius = lmath::len(currentState.position - mOrbitPoint);

				// compute the change in heading, pitch, and radius
				auto deltaHeading = currentState.heading - mKinematicState.state.heading;
				auto deltaPitch = currentState.pitch - mKinematicState.state.pitch;
				auto deltaRadius = currentRadius - mKinematicState.radius;

				// compute heading and pitch velocity
				auto headingVel = deltaHeading / deltaT;
				auto pitchVel = deltaPitch / deltaT;

				// compute the base of std::pow(base, x) for applying physics to the radius
				auto base = std::pow(currentRadius / mKinematicState.radius, 1.0 / deltaT);

				bool inWindow = deltaT <= cPhysicsDropWindowMS;
				bool hasChanged = !(deltaHeading == 0.0 && deltaPitch == 0.0 && deltaRadius == 0.0);
				if (inWindow && hasChanged)	// if in the drop window, only update if the heading/pitch/radius has changed
				{
					mKinematicState = { timeMS, currentState, currentRadius, base, { headingVel, pitchVel } };
				}
				else if (!inWindow)	// if not in the window, update regardless
				{
					mKinematicState = { timeMS, currentState, currentRadius, base, { headingVel, pitchVel } };
				}
			}

			// return the passed in state, we just wanted to gather information
			return currentState;
		}
		else if (mMode == Mode::APPLY)
		{
			// start by copying the initial conditions of the kinematic state
			CameraState state = mKinematicState.state;

			// compute t (the time since the release point)
			auto t = timeMS - mKinematicState.timeMS;

			// compute how much theta and rho will change based on changes the differential equations
			auto heading = solveIVP(state.heading, mKinematicState.velocities.heading, cHeadingDrag, t);
			auto pitch = solveIVP(state.pitch, mKinematicState.velocities.pitch, cPitchDrag, t);

			// compute the amount of "time" that has passed according to the solution of the differential equation
			// and use that as input for how we scale the radius
			auto radiusT = solveIVP(0.0, 1.0, cRadiusDrag, t);
			auto radius = mKinematicState.radius * std::pow(mKinematicState.base, radiusT);

			// compute the change in heading and pitch
			auto deltaHeading = heading - state.heading;
			auto deltaPitch = pitch - state.pitch;
			auto deltaRadius = radius - mKinematicState.radius;

			// compute the orbited state
			state = Math::orbit(mOrbitPoint, state, deltaHeading, deltaPitch, deltaRadius);

			return state;
		}
		else
		{
			return currentState;
		}
		
	}

} } } }