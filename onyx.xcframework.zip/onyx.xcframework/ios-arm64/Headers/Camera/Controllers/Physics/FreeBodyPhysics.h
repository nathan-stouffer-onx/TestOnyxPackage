#ifndef __FREE_BODY_PHYSICS_HANDLER_H__
#define __FREE_BODY_PHYSICS_HANDLER_H__

#include "PhysicsHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Physics {


	// physics handler that will apply drag to the camera (position/heading/pitch) as if it were
	// a free body in space. ie: the camera just slows down but continues it's tangential to it's
	// trajectory

	class FreeBodyPhysics : public PhysicsHandler
	{

	public:

		struct Velocities
		{
			lgal::world::Vector3 position = { 0.0, 0.0, 0.0 };
			world_float_t heading = 0.0;
			world_float_t pitch = 0.0;
		};

		struct KinematicState
		{
			double timeMS;
			CameraState state;
			Velocities velocities;

			// simple constructor to explicitly mark what parameters are required
			KinematicState(double timeMS, CameraState const& state, Velocities const& velocities = { { 0.0, 0.0, 0.0 }, 0.0, 0.0 }) :
				timeMS(timeMS),
				state(state),
				velocities(velocities)
			{}
		};

		virtual ~FreeBodyPhysics() {}

		FreeBodyPhysics(KinematicState const& initial, Mode mode = Mode::TRACK);

		CameraState update(CameraState const& currentState, double timeMS) override;

	protected:

		KinematicState mKinematicState;

	};

} } } }

#endif