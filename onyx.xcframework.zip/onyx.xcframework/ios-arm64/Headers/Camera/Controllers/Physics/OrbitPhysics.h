#ifndef __ORBIT_PHYSICS_HANDLER_H__
#define __ORBIT_PHYSICS_HANDLER_H__

#include "PhysicsHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Physics {

	/*
	* Physics handler that will apply drag while orbiting wrt a focus point in such a way that the 
	* focus point stays at the same spot in screen space. Physics for heading and drag are computed
	* with PhysicsHandler::solveIVP and the appropriate initial conditions
	* 
	* Radius physics is different. Instead of just applying drag to the velocity of the radius, we
	* incorporate how the distance to the focus point changes. This has the effect that we care about
	* the ratio of radii between frames, not their absolue difference. We achieve this by constructing
	* an exponential function based on the radius ratio between frames and then compute the input value
	* to that function by using PhysicsHandler::solveIVP(0, 1, cRadiusDrag, t) -- ie, travel along
	* the curve for a short time, but damp time along the way
	*/

	class OrbitPhysics : public PhysicsHandler
	{

	public:

		struct Velocities
		{
			world_float_t heading = 0.0;
			world_float_t pitch = 0.0;
		};

		struct KinematicState
		{
			double timeMS;
			CameraState state;
			world_float_t radius;
			world_float_t base;		// base of the exponential f(x) = A * std::pow(b, x) for applying radius physics
			Velocities velocities;

			// simple constructor to explicitly mark what parameters are required
			KinematicState(double timeMS, CameraState const& state, world_float_t radius,
							world_float_t base = 1.0, Velocities const& velocities = { 0.0, 0.0 }) :
				timeMS(timeMS),
				state(state),
				radius(radius),
				base(base),
				velocities(velocities)
			{}
		};

		virtual ~OrbitPhysics() {}

		OrbitPhysics(lgal::world::Vector3 const& orbitPoint, KinematicState const& initial, Mode mode = Mode::TRACK);

		CameraState update(CameraState const& currentState, double timeMS) override;

	private:

		lgal::world::Vector3 const mOrbitPoint;
		KinematicState mKinematicState;

	};

} } } }

#endif