#ifndef __IDENTITY_PHYSICS_H__
#define __IDENTITY_PHYSICS_H__

#include "Camera/CameraState.h"
#include "PhysicsHandler.h"

namespace onyx {
namespace Camera {
namespace Controllers {
namespace Physics {

	/*
	* A very simple physics handler that really doesn't do physics at all. Regardless of whether
	* the mode is TRACK or APPLY, this handler will just return the passed in state.
	*/

	class IdentityPhysics : public PhysicsHandler
	{

	public:

		IdentityPhysics() {}

		CameraState update(CameraState const& currentState, double /* timeMS */) override
		{
			if (mMode == Mode::TRACK)
			{
				mState = currentState;
				return currentState;
			}
			else if (mMode == Mode::APPLY)
			{
				return mState;
			}
			else
			{
				return currentState;
			}
		}

	private:

		CameraState mState;

	};

} } } }

#endif