#ifndef __SEQUENCE_CONTROLLER_H__
#define __SEQUENCE_CONTROLLER_H__

#include <vector>
#include <memory>
#include <string>
#include <limits>

#include "Camera/CameraController.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	/*
	* This controller is represents a sequence of other CameraControllers. As input, it takes a list of
	* controllers and the (relative) times to use them. Each frame, it computes which controller is 
	* active, and calls into that controller's update method. A controller is active if its begin time
	* is the largest time less than the current time
	* 
	* If desired, it is possible to pass in a Sequence as a Point in another Sequence. Looping can be
	* achieved by passing in the duration of the loop as loopMS.
	* 
	* NOTE: the one clunky thing about constructing a Sequence is that the begin times of Point::controller
	* must match Point::beginTimeMS
	*/

	class Sequence : public CameraController
	{

	public:

		// NOTE: Point::beginTimeMS and the controller::beginTimeMS (if it exists) must be in sync
		struct Point
		{
			// TODO possibly think of a way where we don't have to manually synce Point::beginTimeMS and controller::beginTimeMS

			Camera_time_t beginTimeMS;						// relative to the begin time of the Sequence
			std::shared_ptr<CameraController> controller;

			Point(Camera_time_t beginTimeMS, std::shared_ptr<CameraController> controller) :
				beginTimeMS(beginTimeMS), controller(controller) {}
		};

		Sequence(std::vector<Point> const& points, Camera_time_t loopMS = std::numeric_limits<Camera_time_t>::max(), 
					Camera_time_t beginMS = Utils::Timer::nowMS());

		std::string getName() const override { return "Sequence"; }

	private:

		std::vector<Point> mPoints;

		Camera_time_t mLoopTimeMS;
		Camera_time_t mBeginTimeMS;

		CameraState derivedUpdate(ControllerOptions const& options) override;

	};

} } }

#endif