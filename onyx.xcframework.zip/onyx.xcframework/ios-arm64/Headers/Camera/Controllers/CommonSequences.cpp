#include "CommonSequences.h"

#include "Animators/FlyTo.h"
#include "Animators/Slerp.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	static bool camIsFarFromLookAt(lgal::world::Vector3 camPos, lgal::world::Vector3 lookAt)
	{
		static constexpr world_float_t cLongDistApproachThresholdKm = 3000.0;
		auto dist = len(lookAt - camPos);
		return dist > cLongDistApproachThresholdKm;
	}

	static std::shared_ptr<Sequence> genApproachFollowSequence(
		Sequence::Point const& approachPoint,
		Sequence::Point const& followPoint,
		CameraController::Camera_time_t beginMS
	)
	{
		auto endOfTimeMS = std::numeric_limits<CameraController::Camera_time_t>::max();
		return std::make_shared<Sequence>(
			std::vector<Sequence::Point>({ approachPoint, followPoint }),
			endOfTimeMS,
			beginMS
		);
	}

	static Sequence::Point genApproachSeqPoint(
		CameraState const& beginState,
		CameraState const& endState,
		CameraController::Camera_time_t beginRelToSeqMS,
		CameraController::Camera_time_t durationMS
	)
	{
		std::shared_ptr<CameraController> approachAnim = nullptr;
		bool usingLongDistApproach = camIsFarFromLookAt(beginState.position, endState.position);
		if (usingLongDistApproach)
		{
			approachAnim = std::make_shared<FlyTo>(beginState, endState, durationMS, beginRelToSeqMS);
		}
		else
		{
			approachAnim = std::make_shared<Slerp>(beginState, endState, durationMS, Camera::TimeTransform::Types::LINEAR, beginRelToSeqMS);
		}

		return Sequence::Point{ beginRelToSeqMS, approachAnim };
	}

	static Sequence::Point genFollowSeqPoint(
		CameraState const& beginState, 
		CameraController::Camera_time_t beginRelToSeqMS,
		Follow::CamPosSphereCoords const& initialConfig,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		bool isCamOrientLockedToInitialState
	)
	{
		auto refreshCycleMS = Follow::cDefaultRefreshCycleMS;
		std::shared_ptr<Follow> followAnim = std::make_shared<Follow>(beginState, initialConfig, getCamPosSphereCoordsCallback,
			refreshCycleMS, beginRelToSeqMS, isCamOrientLockedToInitialState);

		return Sequence::Point{ beginRelToSeqMS, followAnim };
	}

	std::shared_ptr<Sequence> genApproachFollowSequence(
		CameraState const& beginState,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		ApproachFollowSeqConfig afSeqConfig
	)
	{
		auto initialCamPosSphereCoords = getCamPosSphereCoordsCallback();
		if (afSeqConfig.isCamOrientLocked)
		{
			initialCamPosSphereCoords.coords.heading = beginState.heading;
			initialCamPosSphereCoords.coords.pitch = beginState.pitch;
		}

		// Generate approach seq point
		CameraState const approachEndState = Follow::getFollowEndState(beginState, initialCamPosSphereCoords);
		CameraController::Camera_time_t approachBeginRelToSeqMS = 0.0;
		bool usingLongDistApproach = camIsFarFromLookAt(beginState.position, initialCamPosSphereCoords.lookAt);
		CameraController::Camera_time_t approachDurationMS = (usingLongDistApproach) ? 
			afSeqConfig.longDistApproachDurationMS : afSeqConfig.shortDistApproachDurationMS;
		auto approachPoint = genApproachSeqPoint(beginState, approachEndState, approachBeginRelToSeqMS, approachDurationMS);

		// Generate Follow seq point
		Sequence::Point followPoint = genFollowSeqPoint(approachEndState, approachDurationMS,
				initialCamPosSphereCoords, getCamPosSphereCoordsCallback, afSeqConfig.isCamOrientLocked);

		return genApproachFollowSequence(approachPoint, followPoint, afSeqConfig.beginMS);
	}
	
} } }
