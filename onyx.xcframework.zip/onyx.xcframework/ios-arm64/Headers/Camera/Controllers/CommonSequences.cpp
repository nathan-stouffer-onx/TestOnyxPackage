#include "CommonSequences.h"

#include "Animators/FlyTo.h"
#include "Animators/Slerp.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	static bool camIsFarFromLookAt(lgal::world::Vector3 camPos, lgal::world::Vector3 lookAt)
	{
		static constexpr world_float_t cLongDistApproachThresholdKm = 3000.0;
		auto dist = len(lookAt - camPos);
		return dist > cLongDistApproachThresholdKm;
	}

	static std::shared_ptr<AnimationSequence> genApproachFollowSequence(
		CameraState const &initialState,
		SharedAnimatorT const& approachPoint,
		SharedAnimatorT const& followPoint,
		CameraController::Camera_time_t beginMS
	)
	{
		auto endOfTimeMS = std::numeric_limits<CameraController::Camera_time_t>::max();
		return std::make_shared<AnimationSequence>(
			initialState,
			std::vector<SharedAnimatorT>({ approachPoint, followPoint }),
			endOfTimeMS,
			beginMS
		);
	}

	static SharedAnimatorT genApproachSeqPoint(
		CameraState const& beginState,
		CameraState const& endState,
		CameraController::Camera_time_t beginRelToSeqMS,
		CameraController::Camera_time_t durationMS
	)
	{
		SharedAnimatorT approachAnim = nullptr;
		bool usingLongDistApproach = camIsFarFromLookAt(beginState.position, endState.position);
		if (usingLongDistApproach)
		{
			approachAnim = make_animator<FlyTo>(beginState, endState, durationMS, beginRelToSeqMS);
		}
		else
		{
			approachAnim = make_animator<Slerp>(beginState, endState, durationMS, Camera::TimeTransform::Types::LINEAR, beginRelToSeqMS);
		}

		return approachAnim;
	}

	static SharedAnimatorT genFollowSeqPoint(
		CameraState const& beginState, 
		CameraController::Camera_time_t beginRelToSeqMS,
		Follow::CamPosSphereCoords const& initialConfig,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		bool isCamOrientLockedToInitialState
	)
	{
		auto refreshCycleMS = Follow::cDefaultRefreshCycleMS;
		SharedAnimatorT followAnim = make_animator<Follow>(beginState, initialConfig, getCamPosSphereCoordsCallback,
			refreshCycleMS, beginRelToSeqMS, isCamOrientLockedToInitialState);

		return followAnim;
	}

	std::shared_ptr<AnimationSequence> genApproachFollowSequence(
		CameraState const& beginState,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		ApproachFollowSeqConfig afSeqConfig
	)
	{
		auto initialCamPosSphereCoords = getCamPosSphereCoordsCallback();
		if (afSeqConfig.isCamOrientLocked)
		{
			initialCamPosSphereCoords.coords.heading = beginState.heading;
			initialCamPosSphereCoords.coords.pitch = beginState.pitch;
		}

		// Generate approach seq point
		CameraState const approachEndState = Follow::getFollowEndState(beginState, initialCamPosSphereCoords);
		CameraController::Camera_time_t approachBeginRelToSeqMS = 0.0;
		bool usingLongDistApproach = camIsFarFromLookAt(beginState.position, initialCamPosSphereCoords.lookAt);
		CameraController::Camera_time_t approachDurationMS = (usingLongDistApproach) ? 
			afSeqConfig.longDistApproachDurationMS : afSeqConfig.shortDistApproachDurationMS;
		auto approachPoint = genApproachSeqPoint(beginState, approachEndState, approachBeginRelToSeqMS, approachDurationMS);

		// Generate Follow seq point
		auto followPoint = genFollowSeqPoint(approachEndState, approachDurationMS,
				initialCamPosSphereCoords, getCamPosSphereCoordsCallback, afSeqConfig.isCamOrientLocked);

		return genApproachFollowSequence(beginState, approachPoint, followPoint, afSeqConfig.beginMS);
	}
	
} } }
