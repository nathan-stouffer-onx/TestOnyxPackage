#include "CommonSequences.h"

#include "Animators/FlyTo.h"
#include "Animators/Slerp.h"

namespace onyx::Camera::Controllers {

	bool ApproachFollowGenerator::isFarFromLookAt(lgal::world::Vector3 camPos, lgal::world::Vector3 lookAt)
	{
		static constexpr world_float_t cLongDistApproachThresholdKm = 3000.0;
		auto dist = len(lookAt - camPos);
		return dist > cLongDistApproachThresholdKm;
	}

	std::shared_ptr<AnimationSequence> ApproachFollowGenerator::genSequence(
		CameraState const &initialState,
		SharedAnimatorT const& approachPoint,
		SharedAnimatorT const& followPoint,
		CameraController::Camera_time_t beginMS
	)
	{
		auto endOfTimeMS = Animator::TimingParams::cMaxDurationMS;
		Animator::TimingParams timing(beginMS, 0, endOfTimeMS);
		return std::make_shared<AnimationSequence>(
			initialState,
			timing,
			std::vector<SharedAnimatorT>({ approachPoint, followPoint })
		);
	}

	SharedAnimatorT ApproachFollowGenerator::genApproach(
		CameraState const& beginState,
		CameraState const& endState,
		CameraController::Camera_time_t beginRelToSeqMS,
		CameraController::Camera_time_t durationMS
	)
	{
		SharedAnimatorT approachAnim = nullptr;
		bool usingLongDistApproach = isFarFromLookAt(beginState.position, endState.position);
		if (usingLongDistApproach)
		{
			approachAnim = make_animator<FlyTo>(beginState, endState, durationMS, beginRelToSeqMS);
		}
		else
		{
			approachAnim = make_animator<Slerp>(beginState, endState, durationMS, Camera::TimeTransform::Types::LINEAR, beginRelToSeqMS);
		}

		return approachAnim;
	}

	SharedAnimatorT ApproachFollowGenerator::genFollow(
		CameraState const& beginState, 
		CameraController::Camera_time_t beginRelToSeqMS,
		Follow::CamPosSphereCoords const& initialConfig,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		bool isCamOrientLockedToInitialState
	)
	{
		auto refreshCycleMS = Follow::cDefaultRefreshCycleMS;
		SharedAnimatorT followAnim = make_animator<Follow>(beginState, initialConfig, getCamPosSphereCoordsCallback,
			refreshCycleMS, beginRelToSeqMS, isCamOrientLockedToInitialState);

		return followAnim;
	}

	std::shared_ptr<AnimationSequence> ApproachFollowGenerator::genSequence(
		CameraState const& beginState,
		Follow::GetCamPosSphereCoordsCallback_t const& getCamPosSphereCoordsCallback,
		Config afSeqConfig
	)
	{
		auto initialCamPosSphereCoords = getCamPosSphereCoordsCallback();
		if (afSeqConfig.isCamOrientLocked)
		{
			initialCamPosSphereCoords.coords.heading = beginState.heading;
			initialCamPosSphereCoords.coords.pitch = beginState.pitch;
		}

		// Generate approach seq point
		CameraState const approachEndState = Follow::getFollowEndState(beginState, initialCamPosSphereCoords);
		CameraController::Camera_time_t approachBeginRelToSeqMS = 0.0;
		bool usingLongDistApproach = isFarFromLookAt(beginState.position, initialCamPosSphereCoords.lookAt);
		CameraController::Camera_time_t approachDurationMS = (usingLongDistApproach) ? 
			afSeqConfig.longDistApproachDurationMS : afSeqConfig.shortDistApproachDurationMS;
		auto approachPoint = genApproach(beginState, approachEndState, approachBeginRelToSeqMS, approachDurationMS);

		// Generate Follow seq point
		auto followPoint = genFollow(approachEndState, approachDurationMS,
				initialCamPosSphereCoords, getCamPosSphereCoordsCallback, afSeqConfig.isCamOrientLocked);

		return genSequence(beginState, approachPoint, followPoint, afSeqConfig.beginMS);
	}

	/*-----*/

	std::shared_ptr<AnimationSequence> ApproachOrbitGenerator::genSequence(CameraState const& begin, MapMath::Spherical const& beginOrbitState,
		lgal::world::Vector3 const& orbitCenter)
	{
		auto flyToDur = 3000.0;
		auto flyTo = make_animator<FlyTo>(begin, orbitCenter, beginOrbitState, flyToDur, 0);

		//auto flyToEndState = flyTo->highlights().back();
		auto flyToEndState = CameraState{ orbitCenter, beginOrbitState.heading, beginOrbitState.pitch, beginOrbitState.radius, 
			begin.fov, begin.aspect, begin.nearClip, begin.farClip };
		auto attract = make_animator<OrbitAttract>(flyToEndState, orbitCenter, 
			lmath::constants::two_pi<world_float_t>() / 60000.0, 
			std::numeric_limits<CameraController::Camera_time_t>::max(), flyToDur);

		return std::make_shared<AnimationSequence>(
			begin,
			Animator::TimingParams(Utils::Timer::nowMS(), flyToDur),
			std::vector<SharedAnimatorT>({ flyTo, attract })
		);
	}
	
}
