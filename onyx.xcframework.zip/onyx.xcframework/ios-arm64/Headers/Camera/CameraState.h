#ifndef __CAMERA_STATE_H__
#define __CAMERA_STATE_H__

#include <cmath>
#include <array>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Camera {

	static constexpr world_float_t DefaultHeading = 0.0;
	static constexpr world_float_t DefaultPitch = 0.0;
	static constexpr world_float_t DefaultNear = 20000.0;
	static constexpr world_float_t DefaultFar = 50000.0;
	static constexpr world_float_t DefaultFoV = 45.0;
	static constexpr world_float_t DefaultAspect = 1280.0 / 720.0;
	static constexpr world_float_t cMinFarPlane = 100.0;
	static constexpr world_float_t cMaxFarPlane = 150000.0;

	struct CameraState {

		lgal::world::Vector3 position;

		world_float_t heading;
		world_float_t pitch;

		world_float_t fov;
		world_float_t aspect;
		world_float_t nearClip;
		world_float_t farClip;
		
		height_float_t terrainExaggeration = height_float_t(1);

		float view[16] = { 0 };
		float proj[16] = { 0 };
		// used for project and unproject (where double vs float seems to be critical)
		double viewProj[16] = { 0 };
		double invViewProj[16] = { 0 };

		CameraState();
		CameraState(lgal::world::Vector3 const& position);
		CameraState(lgal::world::Vector3 const& position, world_float_t heading, world_float_t pitch);
		CameraState(lgal::world::Vector3 const& position, world_float_t heading, world_float_t pitch,
					world_float_t fov, world_float_t aspect);
		CameraState(lgal::world::Vector3 const& position, world_float_t heading, world_float_t pitch,
					world_float_t fov, world_float_t aspect,
					world_float_t nearClip, world_float_t farClip);
		CameraState(lgal::world::Vector3 const& lookPt, world_float_t heading, world_float_t pitch,
					world_float_t radius, world_float_t fov, world_float_t aspect,
					world_float_t nearClip, world_float_t farClip);
		CameraState(lgal::world::Vector3 const& lookPt, world_float_t heading, world_float_t pitch, world_float_t radius);
		CameraState(lgal::world::Sphere3 const& sphere);
		CameraState(lgal::world::Sphere3 const& sphere, world_float_t heading, world_float_t pitch);

		lgal::world::Vector3 lookDir() const;
		lgal::world::Vector3 upDir() const;
		lgal::world::Vector3 rightDir() const;

		lgal::world::Vector3 rayDir(lgal::world::Vector2 const& screenPos) const;

		void updateViewProj();

		static world_float_t headingTo(lgal::world::Vector2 const& from, lgal::world::Vector2 const& to);
		inline static world_float_t headingTo(CameraState const& from, CameraState const& to)
		{
			return headingTo(from.position.xy, to.position.xy);
		}

		static CameraState slerp(CameraState const& from, CameraState const& to, world_float_t t);
		static CameraState lerp(CameraState const& from, CameraState const& to, world_float_t t)
		{
			CameraState lerped = CameraState::slerp(from, to, t);
			lerped.position.x = lmath::lerp(from.position.x, to.position.x, t);
			return lerped;
		}

		// NOTE: assumes that you only want to change position/heading/pitch -- aspect ratio and such will be left alone
		static CameraState cubicHermiteSpline(CameraState const& p0, CameraState const& m0, CameraState const& p1, CameraState const& m1, world_float_t const t);

		void reset();

		inline bool isNaN(lgal::world::Vector3 const& v)
		{
			return std::isnan(v.x) || std::isnan(v.y) || std::isnan(v.z);
		}

		inline bool isValid()
		{
			return !(isNaN(position)
				|| std::isnan(heading) || std::isnan(pitch)
				|| std::isnan(fov) || std::isnan(aspect));
		}

		inline bool operator==(CameraState const& rhs) const
		{
			return position == rhs.position
					&& heading == rhs.heading && pitch == rhs.pitch
					&& aspect == rhs.aspect && fov == rhs.fov
					&& nearClip == rhs.nearClip && farClip == rhs.farClip;
		}

		inline bool operator!=(CameraState const& rhs) const
		{
			return !(*this == rhs);
		}

		struct ProjectionData
		{
			lgal::world::Vector3 position;
			bool valid;

			ProjectionData(lgal::world::Vector3 const& position, bool valid) : position(position), valid(valid) {}
		};

		ProjectionData project(lgal::world::Vector3 const& worldPos) const;
		inline ProjectionData projectExaggerated(lgal::world::Vector3 worldPos) const
		{
			worldPos.z *= terrainExaggeration;
			return project(worldPos);
		}
		lgal::gpu::Vector3 projectDirToScreen(lgal::gpu::Vector3 const& dir) const;

		// takes in normalized [-1, 1] XYZ screen coordinates 
		ProjectionData unproject(lgal::world::Vector3 const& normalizedCoords) const;

	};

} }

#endif
