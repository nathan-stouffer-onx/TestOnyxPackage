#include "CameraController.h"

#include "Camera/Algorithm.h"
#include "Camera/Controllers/Constraints/ConstraintHandler.h"
#include "Utils/MapMath.h"

namespace onyx::Camera
{

	namespace
	{

		// the maximum length of the b-leg of the following triangle
		//
		//        |*
		//        |   *
		//        |      *   f_max
		//  z_max |         *
		//        |            *
		//        | _____________ *
		//               d_max
		//
		constexpr world_float_t cMaxZ = Controllers::Constraints::ConstraintHandler::cGlobalMaxZ;
		constexpr world_float_t cMaxWalkingDistance = 2 * Tiles::cMaxExtent;	// we can see 2 root-level tile into the distance
		world_float_t cMaxFarPlane = std::sqrt(std::pow(cMaxWalkingDistance, 2) + std::pow(cMaxZ, 2));

		world_float_t SphericalFarPlane(world_float_t const z)
		{
			// calculate distance to spherical horizon
			auto constexpr radiusKm = MapMath::cEarthRadiusMeters / 1000.0;
			auto d = std::max(z * z + 2.0 * radiusKm * z, 0.0);
			auto sphericalFarClip = 2.0 * std::sqrt(d);

			world_float_t t = (z - MapMath::cMaxElevation) / (10.0 * MapMath::cMaxElevation);
			return lmath::lerpstep(sphericalFarClip, cMaxFarPlane, t);
		}

		world_float_t PlanarFarPlane(world_float_t const z, world_float_t const phi, world_float_t const fov)
		{
			world_float_t alpha = lmath::degreesToRadians(0.5 * fov);
			world_float_t zeta = std::abs(phi) + alpha;
			if (zeta >= lmath::constants::half_pi<world_float_t>())
			{
				return std::numeric_limits<world_float_t>::max();
			}
			else
			{
				world_float_t shifted = zeta - lmath::constants::half_pi<world_float_t>();
				lgal::world::Ray3 ray(lgal::world::Vector3(0, 0, z), lgal::world::Vector3(0, lmath::unitVector(shifted)));
				lgal::world::Plane plane(lgal::world::Vector3(0, 0, MapMath::cMinElevation), lgal::world::Vector3(0, 0, 1));
				
				lgal::world::Vector3 intersection = Math::pointIntersection(ray, plane);
				world_float_t length = lmath::len(intersection - ray.origin);
				return 1.1 * length * std::cos(alpha);
			}
		}

	}

	CameraState CameraController::update(CameraState const& previousState, Camera_time_t timeMS, Atlases::HeightAtlas const* atlas, height_float_t exaggeration)
	{
		return update(ControllerOptions{ previousState, timeMS, atlas, exaggeration });
	}

	CameraState CameraController::update(ControllerOptions const& options)
	{
		// call into the update method for the derived class
		CameraState nextState = derivedUpdate(options);
		nextState.terrainExaggeration = options.exaggeration;
		// update the near/far planes
		nextState = clipPlanesUpdate(nextState, options.atlas);
		// return the next state
		return nextState;
	}

	CameraState CameraController::clipPlanesUpdate(CameraState const& nextState, Atlases::HeightAtlas const* atlas)
	{
		// initially copy the current state to preserve fov and such
		CameraState state = nextState;
		
		lgal::world::Vector3 const& eye = state.position;

		// compute near clip plane
		{
			// compute the relative height of the containing tile camera
			std::shared_ptr<Tiles::HeightTile const> tile = (atlas) ? atlas->highestDetailedTile(eye.xy) : nullptr;

			// if there is no height data, just assume 0
			auto mapHeight = (tile) ? nextState.terrainExaggeration * tile->heightAt(eye.xy) : 0.f;
			auto relativeHeightKm = eye.z - mapHeight;

			// boolean indicating whether the camera might be below the maximum terrain
			auto deltaToMax = eye.z - nextState.terrainExaggeration * MapMath::mercatorDistortion(eye.xy) * MapMath::cMaxElevation;
			if (deltaToMax < 0.0)
			{
				// if we might be below the max height, set near clip based on height relative to the terrain
				state.nearClip = std::max(relativeHeightKm * 0.1, 0.001);
			}
			else
			{
				// otherwise, we can just make sure the clip plane will be above the max terrain height
				state.nearClip = deltaToMax * 0.9;
			}
		}

		// compute far clip plane
		{
			world_float_t spherical = SphericalFarPlane(eye.z);
			world_float_t planar = PlanarFarPlane(eye.z, state.pitch, state.fov);
			state.farClip = std::min(spherical, planar);

			// constrain far clip to be less than the max
			state.farClip = std::min(state.farClip, cMaxFarPlane);
		}

		return state;
	}

}