#include "CameraController.h"

#include "Camera/Controllers/Constraints/ConstraintHandler.h"
#include "Utils/MapMath.h"

namespace onyx::Camera
{

	// the maximum length of the b-leg of the following triangle
	//
	//        |*
	//        |   *
	//        |      *   f_max
	//  z_max |         *
	//        |            *
	//        | _____________ *
	//               d_max
	//
	static constexpr world_float_t cMaxZ = Controllers::Constraints::ConstraintHandler::cGlobalMaxZ;
	static constexpr world_float_t cMaxWalkingDistance = 2 * Tiles::cMaxExtent;	// we can see 2 root-level tile into the distance
	static world_float_t cMaxFarPlane = std::sqrt(std::pow(cMaxWalkingDistance, 2) + std::pow(cMaxZ, 2));

	CameraState CameraController::update(CameraState const& previousState, Camera_time_t timeMS, Atlases::HeightAtlas const* atlas, height_float_t exaggeration)
	{
		return update(ControllerOptions{ previousState, timeMS, atlas, exaggeration });
	}

	CameraState CameraController::update(ControllerOptions const& options)
	{
		// call into the update method for the derived class
		CameraState nextState = derivedUpdate(options);
		nextState.terrainExaggeration = options.exaggeration;
		// update the near/far planes
		nextState = clipPlanesUpdate(nextState, options.atlas);
		// return the next state
		return nextState;
	}

	CameraState CameraController::clipPlanesUpdate(CameraState const& nextState, Atlases::HeightAtlas const* atlas)
	{
		// initially copy the current state to preserve fov and such
		CameraState state = nextState;
		
		auto& eye = state.position;

		// compute near clip plane
		{
			// compute the relative height of the containing tile camera
			std::shared_ptr<Tiles::HeightTile const> tile = (atlas) ? atlas->highestDetailedTile(eye.xy) : nullptr;

			// if there is no height data, just assume 0
			auto mapHeight = (tile) ? nextState.terrainExaggeration * tile->heightAt(eye.xy) : 0.f;
			auto relativeHeightKm = eye.z - mapHeight;

			// boolean indicating whether the camera might be below the maximum terrain
			auto deltaToMax = eye.z - nextState.terrainExaggeration * MapMath::mercatorDistortion(eye.xy) * MapMath::cMaxElevation;
			if (deltaToMax < 0.0)
			{
				// if we might be below the max height, set near clip based on height relative to the terrain
				state.nearClip = std::max(relativeHeightKm * 0.1, 0.001);
			}
			else
			{
				// otherwise, we can just make sure the clip plane will be above the max terrain height
				state.nearClip = deltaToMax * 0.9;
			}
		}

		// compute far clip plane
		{
			// calculate distance to spherical horizon
			auto constexpr radiusKm = MapMath::cEarthRadiusMeters / 1000.0;
			auto d = std::max(eye.z * eye.z + 2.0 * radiusKm * eye.z, 0.0);
			auto sphericalFarClip = std::sqrt(d) * 2.0;

			world_float_t t = (state.position.z - MapMath::cMaxElevation) / (10.0 * MapMath::cMaxElevation - MapMath::cMaxElevation);
			state.farClip = lmath::lerpstep(sphericalFarClip, cMaxFarPlane, t);

			// constrain far clip between min and max
			state.farClip = std::clamp(state.farClip, cMinFarPlane, cMaxFarPlane);
		}

		return state;
	}

}