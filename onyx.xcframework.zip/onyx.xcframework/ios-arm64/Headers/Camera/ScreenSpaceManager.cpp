#include "ScreenSpaceManager.h"

namespace onyx {
namespace Camera {

	
	bool ScreenSpaceManager::contains(lgal::screen::Vector2 const& point, reservedArea_T& container) const
	{
		LUCID_PROFILE_SCOPE("ScreenSpaceManager::intersects");

		for (auto existing : mReservedAreas)
		{
			if (existing.contains(point))
			{
				container = existing;
				return true;
			}
		}

		return false;
	}
} }
