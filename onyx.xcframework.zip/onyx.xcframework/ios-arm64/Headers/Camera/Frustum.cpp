#include "Frustum.h"

namespace onyx {
namespace Camera {

	Frustum::Frustum(Corners const& corners) : mCorners(corners)
	{
		reset(corners);
	}

	Frustum::Frustum(CameraState const& state) : Frustum(Frustum::ComputeCorners(state)) {}

	void Frustum::reset(Corners const& corners)
	{
		// use far planes points as much as possible to avoid numerical issues with the near plane points at deep zooms
		mPlanes[Side::TOP] = makePlane3(corners.ftl, corners.ftr, corners.ntr);
		mPlanes[Side::BOTTOM] = makePlane3(corners.fbr, corners.fbl, corners.nbl);
		mPlanes[Side::LEFT] = makePlane3(corners.fbl, corners.ftl, corners.ntl);
		mPlanes[Side::RIGHT] = makePlane3(corners.ftr, corners.fbr, corners.nbr);
		mPlanes[Side::FARP] = makePlane3(corners.ftr, corners.ftl, corners.fbl);
		mPlanes[Side::NEARP] = lgal::world::Plane{ corners.ntl, -mPlanes[Side::FARP].normal };

		mCorners = corners;
	}

	bool Frustum::contains(lgal::world::Vector3 const& p) const
	{
		// iterate over planes, checking if point is outside any
		for (int i = 0; i < 6; ++i)
		{
			if (mPlanes[i].distanceTo(p) < 0)
			{
				return false;
			}
		}

		// made it through all planes, return true
		return true;
	}

	Frustum::Intersection Frustum::intersectsCheckExtremities(lgal::world::AABB3d const& box) const
	{
		Intersection result = Intersection::INSIDE;

		// iterate over each plane
		for (int i = 0; i < 6; ++i)
		{
			// get the plane and normal
			lgal::world::Plane const& plane = mPlanes[i];
			lgal::world::Vector3 const& normal = plane.normal;
			
			// get the vertex furthest along the direction of the normal
			lgal::world::Vector3 extreme = { 0, 0, 0 };
			extreme.x = (normal.x > 0) ? box.max.x : box.min.x;
			extreme.y = (normal.y > 0) ? box.max.y : box.min.y;
			extreme.z = (normal.z > 0) ? box.max.z : box.min.z;

			// test which side of the plane this point is on, if the extremity isn't in the frustum
			// then the tile isn't either
			if (plane.distanceTo(extreme) < 0)
			{
				return Intersection::OUTSIDE;
			}
			else	// in this case, the extremity is in the frustum. now compute the antiextremity to see if it intersects
			{
				// get the vertex furthest along the direction of the antinormal
				lgal::world::Vector3 antiextreme = { 0, 0, 0 };
				antiextreme.x = (normal.x < 0) ? box.max.x : box.min.x;
				antiextreme.y = (normal.y < 0) ? box.max.y : box.min.y;
				antiextreme.z = (normal.z < 0) ? box.max.z : box.min.z;

				// test which side of the plane this point is on, if the antiextremity is outside the plane
				if (plane.distanceTo(antiextreme) < 0)
				{
					result = Intersection::INTERSECT;
				}
			}
		}

		return result;
	}

	Frustum::Intersection Frustum::intersectsCheckAllVertices(lgal::world::AABB3d const& box) const
	{
		Intersection result = Intersection::INSIDE;
		int out, in;

		// for each plane do ...
		for (int i = 0; i < 6; ++i)
		{
			// reset counters for corners in and out
			out = 0; in = 0;
			// for each corner of the box do ...
			// get out of the cycle as soon as a box has corners
			// both inside and out of the frustum
			for (int k = 0; k < 8 && (in == 0 || out == 0); ++k)
			{
				// is the corner outside or inside
				(mPlanes[i].distanceTo(box.vertex(k)) < 0) ? ++out : ++in;
			}
			//if all corners are out
			if (!in)
				return Intersection::OUTSIDE;
			// if some corners are out and others are in
			else if (out)
				result = Intersection::INTERSECT;
		}
		return result;
	}

	Frustum::Corners Frustum::ComputeCorners(CameraState const& state)
	{
		Corners corners = {};

		// compute width and height of the near and far plane sections
		auto tangent = std::tan(lmath::degreesToRadians(state.fov * 0.5));
		auto nh = state.nearClip * tangent;
		auto nw = nh * state.aspect;
		auto fh = state.farClip * tangent;
		auto fw = fh * state.aspect;

		// compute camera basis -- Z axis points in the opposite direction from the look direction
		lgal::world::Vector3 X = -state.rightDir();
		lgal::world::Vector3 Y = state.upDir();
		lgal::world::Vector3 Z = -state.lookDir();

		// compute points of the look ray that intersect the near and far faces
		lgal::world::Vector3 nc = state.position - state.nearClip * Z;
		lgal::world::Vector3 fc = state.position - state.farClip * Z;

		// compute the 4 corners on the near face
		{
			lgal::world::Vector3 Ynh = Y * nh;
			lgal::world::Vector3 Xnw = X * nw;
			corners.ntl = (nc + Ynh) - Xnw;
			corners.ntr = (nc + Ynh) + Xnw;
			corners.nbl = (nc - Ynh) - Xnw;
			corners.nbr = (nc - Ynh) + Xnw;
		}

		// compute the 4 corners on the far face
		{
			lgal::world::Vector3 Yfh = Y * fh;
			lgal::world::Vector3 Xfw = X * fw;
			corners.ftl = (fc + Yfh) - Xfw;
			corners.ftr = (fc + Yfh) + Xfw;
			corners.fbl = (fc - Yfh) - Xfw;
			corners.fbr = (fc - Yfh) + Xfw;
		}

		return corners;
	}

} }