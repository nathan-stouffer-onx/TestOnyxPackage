#include "Frustum.h"

namespace onyx::Camera
{

	Frustum::Frustum(Corners const& corners) : mCorners(corners)
	{
		reset(corners);
	}

	Frustum::Frustum(CameraState const& state) : Frustum(Frustum::ComputeCorners(state)) {}

	void Frustum::reset(Corners const& corners)
	{
		mCorners = corners;

		// reset aabb
		std::vector<lgal::world::Vector3> points =
		{
			// near plane points
			corners.ntl, corners.ntr,
			corners.nbl, corners.nbr,
			// far plane points
			corners.ftl, corners.ftr,
			corners.fbl, corners.fbr,
		};
		mAABB = lmath::fit(points);

		// use far planes points as much as possible to avoid numerical issues with the near plane points at deep zooms. the
		// normal vectors should point towards the interior of the frustum (use the left hand rule because -y is north)
		mPlanes[Side::TOP] = makePlane3(corners.ftr, corners.ftl, corners.ntr);
		mPlanes[Side::BOTTOM] = makePlane3(corners.fbl, corners.fbr, corners.nbl);
		mPlanes[Side::LEFT] = makePlane3(corners.ftl, corners.fbl, corners.ntl);
		mPlanes[Side::RIGHT] = makePlane3(corners.fbr, corners.ftr, corners.nbr);
		mPlanes[Side::FARP] = makePlane3(corners.ftl, corners.ftr, corners.fbl);
		mPlanes[Side::NEARP] = lgal::world::Plane{ corners.ntl, -mPlanes[Side::FARP].normal };

		// update axes
		mAxes =
		{
			// three normals of the aabb
			lgal::world::Vector3(1, 0, 0),
			lgal::world::Vector3(0, 1, 0),
			lgal::world::Vector3(0, 0, 1),
			// five normals of the frustum
			mPlanes[Side::FARP].normal,
			mPlanes[Side::TOP].normal,
			mPlanes[Side::BOTTOM].normal,
			mPlanes[Side::LEFT].normal,
			mPlanes[Side::RIGHT].normal,
			// cross products from first basis vector
			lmath::cross(lgal::world::Vector3(1, 0, 0), mCorners.ftr - mCorners.ftl),
			lmath::cross(lgal::world::Vector3(1, 0, 0), mCorners.ftr - mCorners.fbr),
			lmath::cross(lgal::world::Vector3(1, 0, 0), mCorners.ftl - mCorners.ntl),
			lmath::cross(lgal::world::Vector3(1, 0, 0), mCorners.ftr - mCorners.ntr),
			lmath::cross(lgal::world::Vector3(1, 0, 0), mCorners.fbl - mCorners.nbl),
			lmath::cross(lgal::world::Vector3(1, 0, 0), mCorners.fbr - mCorners.nbr),
			// cross products from second basis vector
			lmath::cross(lgal::world::Vector3(0, 1, 0), mCorners.ftr - mCorners.ftl),
			lmath::cross(lgal::world::Vector3(0, 1, 0), mCorners.ftr - mCorners.fbr),
			lmath::cross(lgal::world::Vector3(0, 1, 0), mCorners.ftl - mCorners.ntl),
			lmath::cross(lgal::world::Vector3(0, 1, 0), mCorners.ftr - mCorners.ntr),
			lmath::cross(lgal::world::Vector3(0, 1, 0), mCorners.fbl - mCorners.nbl),
			lmath::cross(lgal::world::Vector3(0, 1, 0), mCorners.fbr - mCorners.nbr),
			// cross products from third basis vector
			lmath::cross(lgal::world::Vector3(0, 0, 1), mCorners.ftr - mCorners.ftl),
			lmath::cross(lgal::world::Vector3(0, 0, 1), mCorners.ftr - mCorners.fbr),
			lmath::cross(lgal::world::Vector3(0, 0, 1), mCorners.ftl - mCorners.ntl),
			lmath::cross(lgal::world::Vector3(0, 0, 1), mCorners.ftr - mCorners.ntr),
			lmath::cross(lgal::world::Vector3(0, 0, 1), mCorners.fbl - mCorners.nbl),
			lmath::cross(lgal::world::Vector3(0, 0, 1), mCorners.fbr - mCorners.nbr),
		};
	}

	bool Frustum::contains(lgal::world::Vector3 const& p) const
	{
		// iterate over planes, checking if point is outside any
		for (int i = 0; i < 6; ++i)
		{
			if (mPlanes[i].distanceTo(p) < 0)
			{
				return false;
			}
		}

		// made it through all planes, return true
		return true;
	}

	Frustum::Intersection Frustum::intersectsFast(lgal::world::AABB3d const& aabb) const
	{
		if (lmath::intersectsOrTouches(mAABB, aabb))
		{
			Intersection intersection = boxExtremitiesAgainstFrustum(aabb);
			// there may be falsely reported INTERSECT cases, perform additional checks to reduce (but not eliminate) false positives
			if (intersection == Intersection::INTERSECT)
			{
				return (Frustum::IsOutsideAnyBoxPlane(*this, aabb)) ? Intersection::OUTSIDE : Intersection::INTERSECT;
			}
			else
			{
				return intersection;
			}
		}
		else
		{
			return Intersection::OUTSIDE;
		}
	}

	Frustum::Intersection Frustum::intersects(lgal::world::AABB3d const& aabb) const
	{
		Intersection intersection = intersectsFast(aabb);
		if (intersection == Intersection::INTERSECT)
		{
			for (lgal::world::Vector3 const& axis : mAxes)
			{
				if (lmath::lenSquared(axis) > 0.0 && Frustum::Separates(axis, *this, aabb))
				{
					return Intersection::OUTSIDE;
				}
			}
			return Intersection::INTERSECT;
		}
		else
		{
			return intersection;
		}
	}

	lgal::world::Range Frustum::project(lgal::world::Vector3 const& axis) const
	{
		lgal::world::Range range{ std::numeric_limits<world_float_t>::max(), std::numeric_limits<world_float_t>::lowest() };
		std::array<lgal::world::Vector3, 8> points =
		{
			// near plane points
			mCorners.ntl, mCorners.ntr,
			mCorners.nbl, mCorners.nbr,
			// far plane points
			mCorners.ftl, mCorners.ftr,
			mCorners.fbl, mCorners.fbr,
		};
		for (lgal::world::Vector3 const& point : points)
		{
			world_float_t l = lmath::dot(point, axis);
			range.begin = std::min(range.begin, l);
			range.end = std::max(range.end, l);
		}
		return range;
	}

	Frustum::Intersection Frustum::boxExtremitiesAgainstFrustum(lgal::world::AABB3d const& box) const
	{
		Intersection result = Intersection::INSIDE;

		// iterate over each plane of the frustum
		for (int i = 0; i < 6; ++i)
		{
			// get the plane and normal
			lgal::world::Plane const& plane = mPlanes[i];
			lgal::world::Vector3 const& normal = plane.normal;
			
			// get the aabb vertex furthest along the direction of the normal
			lgal::world::Vector3 extreme = box.extremity(normal);

			// test which side of the plane this point is on, if the extremity is outside the plane then the tile is outside the frustum
			if (plane.distanceTo(extreme) < 0)
			{
				return Intersection::OUTSIDE;
			}
			else	// in this case, the extremity is in the frustum. now compute the antiextremity to see if it intersects
			{
				// get the vertex furthest along the direction of the antinormal
				lgal::world::Vector3 antiextreme = box.extremity(-normal);

				// test which side of the plane this point is on, if the antiextremity is outside the plane then the tile is outside the frustum
				if (plane.distanceTo(antiextreme) < 0)
				{
					result = Intersection::INTERSECT;
				}
			}
		}

		return result;
	}

	Frustum::Corners Frustum::ComputeCorners(CameraState const& state)
	{
		Corners corners = {};

		// compute width and height of the near and far plane sections
		auto tangent = std::tan(lmath::degreesToRadians(0.5 * state.fov));
		auto nh = state.nearClip * tangent;
		auto nw = nh * state.aspect;
		auto fh = state.farClip * tangent;
		auto fw = fh * state.aspect;

		// compute camera basis
		lgal::world::Vector3 X = state.rightDir();
		lgal::world::Vector3 Y = state.upDir();
		lgal::world::Vector3 Z = state.lookDir();

		// compute points of the look ray that intersect the near and far faces
		lgal::world::Vector3 nc = state.position + state.nearClip * Z;
		lgal::world::Vector3 fc = state.position + state.farClip * Z;

		// compute the 4 corners on the near face
		{
			lgal::world::Vector3 Ynh = Y * nh;
			lgal::world::Vector3 Xnw = X * nw;
			corners.ntl = (nc + Ynh) - Xnw;
			corners.ntr = (nc + Ynh) + Xnw;
			corners.nbl = (nc - Ynh) - Xnw;
			corners.nbr = (nc - Ynh) + Xnw;
		}

		// compute the 4 corners on the far face
		{
			lgal::world::Vector3 Yfh = Y * fh;
			lgal::world::Vector3 Xfw = X * fw;
			corners.ftl = (fc + Yfh) - Xfw;
			corners.ftr = (fc + Yfh) + Xfw;
			corners.fbl = (fc - Yfh) - Xfw;
			corners.fbr = (fc - Yfh) + Xfw;
		}

		return corners;
	}

	bool Frustum::IsOutsideAnyBoxPlane(Frustum const& frustum, lgal::world::AABB3d const& box)
	{
		Corners const& c = frustum.corners();
		std::array<lgal::world::Vector3, 8> corners = { c.ntl, c.ntr, c.nbl, c.nbr, c.ftl, c.ftr, c.fbl, c.fbr };
		for (int i = 0; i < 3; ++i)	// iterate over x, y, and z
		{
			// check plane defined by the min of the box
			{
				size_t outside = 0;
				for (lgal::world::Vector3 const& corner : corners)
				{
					outside += (corner[i] < box.min[i]) ? 1 : 0;
				}
				if (outside == 8) { return true; }
			}
			// check plane defined by the max of the box
			{
				size_t outside = 0;
				for (lgal::world::Vector3 const& corner : corners)
				{
					outside += (box.max[i] < corner[i]) ? 1 : 0;
				}
				if (outside == 8) { return true; }
			}
		}
		return false;	// fall-through to false
	}

	bool Frustum::Separates(lgal::world::Vector3 const& axis, Frustum const& frustum, lgal::world::AABB3d const& box)
	{
		lgal::world::Range frange = frustum.project(axis);
		lgal::world::Range brange = lmath::project(box, axis);
		return frange.end < brange.begin || brange.end < frange.begin;
	}

}