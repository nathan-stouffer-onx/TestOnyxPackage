#ifndef __TIME_TRANSFORM_H__
#define __TIME_TRANSFORM_H__

#include <lucid/gal/Types.h>

namespace onyx {
namespace Camera {
namespace TimeTransform {

	// enum that represents different transformations that can be applied to t that will
	// adjust how an animation behaves
	enum class Types
	{
		LINEAR,
		SMOOTHSTEP,
		QUADRATIC_EASE_OUT
	};

	// NOTE: t will be clamped to the closed interval [0, 1]
	world_float_t evaluate(Types const type, world_float_t const t);

} } }

#endif