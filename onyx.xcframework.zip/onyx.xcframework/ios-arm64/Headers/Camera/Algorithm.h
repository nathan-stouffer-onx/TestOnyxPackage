#pragma once

#include <cmath>

#include <System/OnyxException.h>
#include <lucid/gal/Types.h>

#include "CameraState.h"

// TODO (CSONYX-320): The matrix code should be deleted here once we fully support using lucid matrices
namespace onyx::Math {

	inline lgal::world::Vector3 pointIntersection(lgal::world::Ray3 const& ray, lgal::world::Plane const& plane)
	{
		// delta between the ray point and a point we know to be on the plane
		auto diff = ray.origin - plane.point;
		// distance from the ray origin to the plane
		auto dist = lmath::dot(diff, plane.normal);
		// this dot product is len(ray.direction) * cos(theta) where theta is the angle
		// between ray.direction and plane.normal
		auto scaledCos = lmath::dot(ray.direction, plane.normal);
		// amount to travel along the direction vector
		auto t = dist / scaledCos;
		// compute the point on the plane
		return ray.origin - (t * ray.direction);
	}

	template <typename T>
	inline void vec4MulMtx(T* _result, T const* _vec, T const* _mat)
	{
		for (int i = 0; i < 4; i++) {
			_result[i] =
				_vec[0] * _mat[0 * 4 + i] +
				_vec[1] * _mat[1 * 4 + i] +
				_vec[2] * _mat[2 * 4 + i] +
				_vec[3] * _mat[3 * 4 + i];
		}
	}

	inline void mulMtxDouble(double r[16], const float a[16], const float b[16])
	{
		int i, j;

		for (i = 0; i < 4; i++) {
			for (j = 0; j < 4; j++) {
				r[i * 4 + j] =
					(double)a[i * 4 + 0] * (double)b[0 * 4 + j] +
					(double)a[i * 4 + 1] * (double)b[1 * 4 + j] +
					(double)a[i * 4 + 2] * (double)b[2 * 4 + j] +
					(double)a[i * 4 + 3] * (double)b[3 * 4 + j];
			}
		}
	}

	inline int invertMatrixDouble(double invOut[16], const double m[16])
	{
		double inv[16], det;
		int i;

		inv[0] = m[5] * m[10] * m[15] - m[5] * m[11] * m[14] - m[9] * m[6] * m[15]
			+ m[9] * m[7] * m[14] + m[13] * m[6] * m[11] - m[13] * m[7] * m[10];
		inv[4] = -m[4] * m[10] * m[15] + m[4] * m[11] * m[14] + m[8] * m[6] * m[15]
			- m[8] * m[7] * m[14] - m[12] * m[6] * m[11] + m[12] * m[7] * m[10];
		inv[8] = m[4] * m[9] * m[15] - m[4] * m[11] * m[13] - m[8] * m[5] * m[15]
			+ m[8] * m[7] * m[13] + m[12] * m[5] * m[11] - m[12] * m[7] * m[9];
		inv[12] = -m[4] * m[9] * m[14] + m[4] * m[10] * m[13] + m[8] * m[5] * m[14]
			- m[8] * m[6] * m[13] - m[12] * m[5] * m[10] + m[12] * m[6] * m[9];
		inv[1] = -m[1] * m[10] * m[15] + m[1] * m[11] * m[14] + m[9] * m[2] * m[15]
			- m[9] * m[3] * m[14] - m[13] * m[2] * m[11] + m[13] * m[3] * m[10];
		inv[5] = m[0] * m[10] * m[15] - m[0] * m[11] * m[14] - m[8] * m[2] * m[15]
			+ m[8] * m[3] * m[14] + m[12] * m[2] * m[11] - m[12] * m[3] * m[10];
		inv[9] = -m[0] * m[9] * m[15] + m[0] * m[11] * m[13] + m[8] * m[1] * m[15]
			- m[8] * m[3] * m[13] - m[12] * m[1] * m[11] + m[12] * m[3] * m[9];
		inv[13] = m[0] * m[9] * m[14] - m[0] * m[10] * m[13] - m[8] * m[1] * m[14]
			+ m[8] * m[2] * m[13] + m[12] * m[1] * m[10] - m[12] * m[2] * m[9];
		inv[2] = m[1] * m[6] * m[15] - m[1] * m[7] * m[14] - m[5] * m[2] * m[15]
			+ m[5] * m[3] * m[14] + m[13] * m[2] * m[7] - m[13] * m[3] * m[6];
		inv[6] = -m[0] * m[6] * m[15] + m[0] * m[7] * m[14] + m[4] * m[2] * m[15]
			- m[4] * m[3] * m[14] - m[12] * m[2] * m[7] + m[12] * m[3] * m[6];
		inv[10] = m[0] * m[5] * m[15] - m[0] * m[7] * m[13] - m[4] * m[1] * m[15]
			+ m[4] * m[3] * m[13] + m[12] * m[1] * m[7] - m[12] * m[3] * m[5];
		inv[14] = -m[0] * m[5] * m[14] + m[0] * m[6] * m[13] + m[4] * m[1] * m[14]
			- m[4] * m[2] * m[13] - m[12] * m[1] * m[6] + m[12] * m[2] * m[5];
		inv[3] = -m[1] * m[6] * m[11] + m[1] * m[7] * m[10] + m[5] * m[2] * m[11]
			- m[5] * m[3] * m[10] - m[9] * m[2] * m[7] + m[9] * m[3] * m[6];
		inv[7] = m[0] * m[6] * m[11] - m[0] * m[7] * m[10] - m[4] * m[2] * m[11]
			+ m[4] * m[3] * m[10] + m[8] * m[2] * m[7] - m[8] * m[3] * m[6];
		inv[11] = -m[0] * m[5] * m[11] + m[0] * m[7] * m[9] + m[4] * m[1] * m[11]
			- m[4] * m[3] * m[9] - m[8] * m[1] * m[7] + m[8] * m[3] * m[5];
		inv[15] = m[0] * m[5] * m[10] - m[0] * m[6] * m[9] - m[4] * m[1] * m[10]
			+ m[4] * m[2] * m[9] + m[8] * m[1] * m[6] - m[8] * m[2] * m[5];

		det = m[0] * inv[0] + m[1] * inv[4] + m[2] * inv[8] + m[3] * inv[12];
		if (det == 0)
			return false;

		det = 1.0 / det;

		for (i = 0; i < 16; i++)
			invOut[i] = inv[i] * det;

		return true;
	}

	// function that interpolates between anchors a1 and a2 by using a C^1 cubic spline. the anchors a0 and
	// a3 are provided so the function will be C^1
	template<typename T>
	T c1CubicSpline(T const& a0, T const& a1, T const& a2, T const& a3, world_float_t const t)
	{
		// compute coefficients
		T c3 = ((a3 - a2) - a0) + a1;
		T c2 = (a0 - a1) - c3;
		T c1 = a2 - a0;
		T c0 = a1;
		// compute interpolated value
		return c0 + c1 * t + c2 * t * t + c3 * t * t * t;
	}

	// function that interpolates between p0 and p1 using cubic hermite splines -- https://en.wikipedia.org/wiki/Cubic_Hermite_spline
	// the function f(t) is defined on [0, 1] and takes the following values
	//   * f(0) = p0 and f(1) = p1
	//   * f'(0) = m0 and f'(1) = m1
	// meaning that consecutive splines will be C^1 at their boundary. this function assumes
	// a domain of [0, 1] so the actual derivatives must be scaled by the length of the 
	// interval for accurate results.
	// 
	// NOTE: this method tends to have less "wiggle" in its curve than the above function
	// c1CubicSpline has
	template<typename T>
	T cubicHermiteSpline(T const& p0, T const& m0, T const& p1, T const& m1, world_float_t const t)
	{
		world_float_t tSquared = t * t;
		world_float_t tCubed = tSquared * t;

		// compute basis values
		world_float_t b0 = 2.0 * tCubed - 3 * tSquared + 1.0;
		world_float_t b1 = tCubed - 2.0 * tSquared + t;
		world_float_t b2 = -2.0 * tCubed + 3.0 * tSquared;
		world_float_t b3 = tCubed - tSquared;

		return b0 * p0 + b1 * m0 + b2 * p1 + b3 * m1;
	}

	// function that will orbit the camera around a center (focus) point. the variables deltaHeading and deltaPitch
	// apply to the CameraState, and then we update the orbit appropriately so that the focus remains at the 
	// same spot in screen space.
	// 
	// it's probably easiest to think of the focus as an airplane with the classic pitch and yaw axes defined
	// the initial camera's right vector and the vector (0, 0, 1) (respectively). first rotate about the yaw 
	// axis and then the (new) pitch axis while keeping the camera eye in the same relative position on the orbit 
	// sphere. in the code, we actually flip the order and rotate about the original pitch axis first, and then
	// the original yaw axis -- this is so we don't have to transform the pitch axis.
	// 
	// we also adjust the radius by whatever delta is passed in and then set the look direction so that the 
	// focus stays at the same spot in screen space
	
	Camera::CameraState orbit(lgal::world::Vector3 const& focus, Camera::CameraState const& initial, world_float_t const deltaHeading, world_float_t const deltaPitch, world_float_t const deltaRadius);

}
