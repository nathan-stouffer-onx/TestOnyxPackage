#include "TimeTransform.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Camera {
namespace TimeTransform {

	world_float_t evaluate(Types const type, world_float_t const t)
	{
		world_float_t clampedT = std::clamp(t, 0.0, 1.0);
		switch (type)
		{
			case Types::LINEAR:             return clampedT;                                    break;
			case Types::SMOOTHSTEP:         return lmath::smoothstep(0.0, 1.0, clampedT);       break;
			case Types::QUADRATIC_EASE_OUT: return 1.0 - std::pow(clampedT - 1.0, 2.0);         break;
			default: ONYX_THROW("invalid enum value for Camera::TimeTransform::Type")         break;
		}
	}

} } }