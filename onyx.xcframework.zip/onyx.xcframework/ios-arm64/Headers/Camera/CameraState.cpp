#include "CameraState.h"

#include <cmath>

#include <bgfx/bgfx.h>
#include <bx/bx.h>
#include <bx/math.h>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>

#include "Camera/Algorithm.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::Camera
{

	CameraState::CameraState(lgal::world::Vector3 const& position, world_float_t heading, world_float_t pitch, world_float_t fov, world_float_t aspect, world_float_t nearClip, world_float_t farClip) :
		position(position),
		heading(heading),
		pitch(pitch),
		fov(fov),
		aspect(aspect),
		nearClip(nearClip),
		farClip(farClip)
	{
		updateViewProj();
	}

	CameraState::CameraState(lgal::world::Vector3 const& position, world_float_t heading, world_float_t pitch) :
		CameraState(position, heading, pitch, DefaultFoV, DefaultAspect, DefaultNear, DefaultFar)
	{}

	// default to north up camera state
	CameraState::CameraState(lgal::world::Vector3 const& position) :
		CameraState(position, DefaultHeading, DefaultPitch)
	{}

	CameraState::CameraState() : CameraState(lgal::world::Vector3{ 0.0, 0.0, 10000.0 }) {}

	CameraState::CameraState(lgal::world::Vector3 const& focus, world_float_t heading, world_float_t pitch, world_float_t radius, world_float_t fov, world_float_t aspect, world_float_t nearClip, world_float_t farClip) :
		heading(heading),
		pitch(pitch),
		fov(fov),
		aspect(aspect),
		nearClip(nearClip),
		farClip(farClip)
	{
		// convert the camera heading/pitch to the values a what camera at the lookPt viewing
		// the eye position would have
		auto lookPtHeading = heading + lmath::constants::pi<world_float_t>();
		auto lookPtPitch = lmath::constants::pi<world_float_t>() - pitch;

		lgal::world::Vector3 offset = MapMath::Spherical{ lookPtHeading, lookPtPitch, radius }.toEuclidean();
		position = focus + offset;

		updateViewProj();
	}

	CameraState::CameraState(lgal::world::Vector3 const& focus, world_float_t heading, world_float_t pitch, world_float_t radius) :
		CameraState(focus, heading, pitch, radius, DefaultFoV, DefaultAspect, DefaultNear, DefaultFar)
	{}
	
	CameraState::CameraState(lgal::world::Sphere3 const& sphere) :
		CameraState(sphere, DefaultHeading, DefaultPitch)
	{}

	CameraState::CameraState(lgal::world::Sphere3 const& sphere, world_float_t heading, world_float_t pitch) :
		CameraState(sphere.center, heading, pitch)
	{
		world_float_t fovRad = fov * lmath::constants::pi<world_float_t>() / 180.0;
		world_float_t dist = sphere.radius / std::sin(fovRad / 2.0);
		position = position - dist * lookDir();
	}

	lgal::world::Vector3 CameraState::lookDir() const
	{
		return MapMath::Spherical{ heading, pitch, 1.0 }.toEuclidean();
	}

	lgal::world::Vector3 CameraState::upDir() const
	{
		// set up heading/pitch for the up vector
		auto upHeading = heading;
		auto upPitch = pitch + lmath::constants::half_pi<world_float_t>();

		// adjust heading/pitch if pitch went outside the range [0, pi]
		if (upPitch > lmath::constants::pi<world_float_t>())
		{
			upHeading += lmath::constants::pi<world_float_t>();
			upPitch = lmath::constants::two_pi<world_float_t>() - upPitch;
		}

		return MapMath::Spherical{ upHeading, upPitch, 1.0 }.toEuclidean();
	}

	lgal::world::Vector3 CameraState::rightDir() const
	{
		// use up x look because north is -y
		return cross(upDir(), lookDir());
	}

	lgal::world::Vector3 CameraState::rayDir(lgal::world::Vector2 const& screenPos) const
	{
		auto fovRad = fov * lmath::constants::pi<double>() / 180.0;
		auto halfHeight = std::tan(fovRad * 0.5);
		auto halfWidth = aspect * halfHeight;

		auto forward = lookDir();
		auto right = screenPos.x * halfWidth * rightDir();
		auto up = - screenPos.y * halfHeight * upDir();

		return lmath::normalize(forward + right + up);
	}

	void CameraState::updateViewProj()
	{
		bx::mtxLookAt(view.data(), {0, 0, 0}, BgfxUtils::toBx(lookDir()), BgfxUtils::toBx(upDir()));
		bx::mtxProj(proj.data(), float(fov), float(aspect), float(nearClip), float(farClip), bgfx::getCaps()->homogeneousDepth);

		Math::mulMtxDouble(viewProj.data(), view.data(), proj.data());
		Math::invertMatrixDouble(invViewProj.data(), viewProj.data());
	}

	world_float_t CameraState::headingTo(lgal::world::Vector2 const& from, lgal::world::Vector2 const& to)
	{
		lgal::world::Vector2 delta = to - from;

		if (std::abs(delta.x) > 0.5 * Tiles::cMaxExtent)
		{
			world_float_t sign = (from.x < to.x) ? -1.0 : 1.0;
			delta.x += sign * Tiles::cMaxExtent;
		}

		world_float_t theta = std::atan2(delta.y, delta.x);
		theta += lmath::constants::half_pi<world_float_t>();	// add pi/2 to account for heading = 0 begin north
		return lmath::canonicalAngle(theta);
	}

	CameraState CameraState::slerp(CameraState const& from, CameraState const& to, world_float_t t)
	{
		// account for heading being on a circle
		world_float_t heading = lmath::closestEquivalentAngle(from.heading, to.heading);
		
		CameraState lerped;
		lerped.position.x = lmath::slerp(from.position.x, to.position.x, t, Tiles::cLeftX, Tiles::cRightX);
		lerped.position.y = lmath::lerp(from.position.y, to.position.y, t);
		lerped.position.z = lmath::lerp(from.position.z, to.position.z, t);

		lerped.heading  = lmath::lerp(from.heading, heading, t);
		lerped.pitch    = lmath::lerp(from.pitch, to.pitch, t);
		lerped.fov      = lmath::lerp(from.fov, to.fov, t);
		lerped.aspect   = lmath::lerp(from.aspect, to.aspect, t);
		lerped.nearClip = lmath::lerp(from.nearClip, to.nearClip, t);
		lerped.farClip  = lmath::lerp(from.farClip, to.farClip, t);
		lerped.terrainExaggeration = lmath::lerp(from.terrainExaggeration, to.terrainExaggeration, height_float_t(t));

		// make sure heading is in the range [0, 2pi)
		lerped.heading  = lmath::canonicalAngle(lerped.heading);
		
		return lerped;
	}

	CameraState CameraState::cubicHermiteSpline(CameraState const& p0, CameraState const& m0, CameraState const& p1, CameraState const& m1, world_float_t const t)
	{
		// set up interpolated CameraState variable
		CameraState interpolated = p1;

		// accounts for the circular nature of heading
		world_float_t heading0 = p0.heading;
		world_float_t heading1 = lmath::closestEquivalentAngle(heading0, p1.heading);

		// compute interpolated values
		interpolated.position = Math::cubicHermiteSpline(p0.position, m0.position, p1.position, m1.position, t);
		interpolated.heading = Math::cubicHermiteSpline(heading0, m0.heading, heading1, m1.heading, t);
		interpolated.pitch = Math::cubicHermiteSpline(p0.pitch, m0.pitch, p1.pitch, m1.pitch, t);

		// make sure heading is in the range [0, 2pi)
		interpolated.heading = lmath::canonicalAngle(interpolated.heading);

		return interpolated;
	}

	void CameraState::reset()
	{
		position = { 0, 0, 10000 };
		heading = DefaultHeading;
		pitch = DefaultPitch;
		if (std::isnan(fov))
		{
			fov = DefaultFoV;
		}
	}

	CameraState::ProjectionData CameraState::project(lgal::world::Vector3 const& worldPos) const
	{
		// subtract the eye position
		lgal::world::Vector3 offset = worldPos - position;

		double in[4] = { offset.x, offset.y, offset.z, 1.0 };
		double out[4];

		Math::vec4MulMtx(out, in, viewProj.data());

		if (out[3] == 0.0)
			return { { out[0], out[1], out[2] }, false };

		lgal::world::Vector3 result =
		{
			out[0] / out[3],
			-out[1] / out[3],
			out[2] / out[3],
		};

		return { result, true };
	}

	lgal::gpu::Vector3 CameraState::projectDirToScreen(lgal::gpu::Vector3 const& dir) const
	{
		float in[4] = { dir.x, dir.y, dir.z, 0.f };
		float out[4];

		// Avoiding projection for direction vector
		Math::vec4MulMtx(out, in, view.data());

		return lgal::gpu::Vector3{ out[0], -out[1], out[2] };
	}

	CameraState::ProjectionData CameraState::unproject(lgal::world::Vector3 const& normalizedCoords) const
	{
		double in[4] = { normalizedCoords.x, -normalizedCoords.y, normalizedCoords.z, 1.0 };
		double out[4];

		Math::vec4MulMtx(out, in, invViewProj.data());
		if (out[3] == 0.0)
			return { { out[0], out[1], out[2] }, false };

		lgal::world::Vector3 result =
		{
			out[0] / out[3],
			out[1] / out[3],
			out[2] / out[3],
		};

		// add back the eye position
		result = result + position;
		
		return { result, true };
	}

}