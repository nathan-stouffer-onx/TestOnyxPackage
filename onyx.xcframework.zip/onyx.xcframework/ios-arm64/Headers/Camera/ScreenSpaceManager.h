#ifndef SCREEN_SPACE_MANAGER_H
#define SCREEN_SPACE_MANAGER_H

#include <vector>

#include <lucid/gal/Types.h>
#include <lucid/Profiler.h>
#include <Utils/property.h>

namespace onyx {
namespace Camera {
	
	class ScreenSpaceManager
	{
	public:
		typedef lgal::screen::AABB2d reservedArea_T;
		typedef std::vector<reservedArea_T> reservedAreaList_T;
		void reserveRect(reservedArea_T const& rect) { mReservedAreas.push_back({ rect.min - mPadding, rect.max + mPadding }); }

		void clear() { mReservedAreas.clear(); }

		bool empty() { return mReservedAreas.empty(); }

		template<typename T>
		lmath::Intersections intersects(T const& obj, bool allowPartial = false) const;

		bool contains(lgal::screen::Vector2 const& point, reservedArea_T& container) const;

		reservedAreaList_T::const_iterator begin() const { return mReservedAreas.begin(); }
		reservedAreaList_T::const_iterator end() const { return mReservedAreas.end(); }

		GET_SET_VALUE(Padding, lgal::screen::Vector2, lgal::screen::Vector2(5, 5));

	private:
		std::vector<lgal::screen::AABB2d> mReservedAreas;
	};

	template<typename T>
	lmath::Intersections ScreenSpaceManager::intersects(T const& obj, bool allowPartial) const
	{
		LUCID_PROFILE_SCOPE("ScreenSpaceManager::intersects");

		auto result = lmath::Intersections::NONE;

		for (auto const& existing : mReservedAreas)
		{
			auto existingResult = lmath::intersects(obj, existing);
			if (existingResult == lmath::Intersections::FULL)
			{
				return lmath::Intersections::FULL;
			}
			else if (existingResult == lmath::Intersections::PARTIAL)
			{
				if (!allowPartial)
				{
					return lmath::Intersections::PARTIAL;
				}
				result = lmath::Intersections::PARTIAL;
			}
		}

		return result;
	}

} }

#endif