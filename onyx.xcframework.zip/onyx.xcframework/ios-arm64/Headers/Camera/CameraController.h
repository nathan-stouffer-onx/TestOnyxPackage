#ifndef _CAMERA_CONTROLLER_H_
#define _CAMERA_CONTROLLER_H_

#include <vector>
#include <string>
#include <memory>

#include <lucid/Types.h>

#include "Atlases/HeightAtlas.h"
#include "Utils/Timer.h"

#include "CameraState.h"

namespace onyx {
namespace Camera {

	// CameraController is an abstract class that specialized/derived camera controllers inherit from
	// 
	// It has a couple primary functions:
	//   - when CameraController::update is called, the first thing it does is call into
	//     the derived controller and get the whatever value is returned. CameraController
	//     doesn't care about how the derived controller does things, it just knows what
	//     camera state the derived controller wants
	//   - after getting the result from the derived controller, CameraController will compute the 
	//     values for the near and far clip planes
	//   - define the virtual function CameraController::highlights that derived controllers can 
	//     override to let other objects know what camera states should be highlighted (and possibly 
	//     precached). most derived controllers will leave it unimplemented.

	class CameraController
	{
	public:

		typedef time_float_t Camera_time_t;

		virtual ~CameraController() {}

		// TODO (stouff) possibly remove CameraState parameter? I think the only thing it provides us is 
		// the ability to reflect a change aspect ratio and 2D/3D in an active controller. if we
		// don't think this is a valuable feature, we can remove this from all camera update methods
		// and instead just copy aspect ratio (and co) from a begin state
		struct ControllerOptions
		{
			CameraState const& previousState;
			Camera_time_t timeMS;
			Atlases::HeightAtlas const* atlas;
			height_float_t exaggeration;

			ControllerOptions(CameraState const& _previousState, Camera_time_t _timeMS, Atlases::HeightAtlas const* _atlas, height_float_t _exaggeration) :
				previousState(_previousState), timeMS(_timeMS), atlas(_atlas), exaggeration(_exaggeration)
			{}
		};

		CameraState update(CameraState const& previousState, Camera_time_t timeMS, Atlases::HeightAtlas const* atlas, height_float_t exaggeration);
		CameraState update(ControllerOptions const& options);
		
		virtual std::string getName() const = 0;
		virtual std::string getDesc() const { return ""; };

		virtual std::vector<CameraState> highlights() const { return std::vector<CameraState>{}; }

	protected:

		// update the clip planes
		virtual CameraState clipPlanesUpdate(CameraState const& nextState, Atlases::HeightAtlas const* atlas);

	private:

		// must be overriden by derived classes
		virtual CameraState derivedUpdate(ControllerOptions const& options) = 0;
		
	};

} }

namespace onyx {
namespace Camera {
namespace Controllers {

	template<class _Controller, class... _Args>
	inline static std::shared_ptr<CameraController> make_shared(_Args&&... args)
	{
		return std::make_shared<_Controller>(args...);
	}

} } }


#endif