#pragma once

#include <array>

#include <lucid/gal/Types.h>

#include "Camera/CameraState.h"

namespace onyx::Camera
{

	class Frustum
	{
	public:

		enum class Intersection
		{
			OUTSIDE,
			INTERSECT,
			INSIDE
		};

		struct Corners
		{
			// corners of the near face
			lgal::world::Vector3 ntl, ntr, nbl, nbr;
			// corners of the far face
			lgal::world::Vector3 ftl, ftr, fbl, fbr;
		};

		Frustum(Corners const& corners);	// exists for precision in unit tests. functionally, we will always construct from a CameraState
		Frustum(CameraState const& state);

		void reset(Corners const& corners);
		inline void reset(CameraState const& state) { reset(Frustum::ComputeCorners(state)); }

		bool contains(lgal::world::Vector3 const& p) const;

		inline Intersection intersects(lgal::world::AABB3d const& box) const
		{
			return intersectsCheckExtremities(box);
		}
		
		Intersection intersectsCheckExtremities(lgal::world::AABB3d const& box) const;	// NOTE: identifies false positives
		Intersection intersectsCheckAllVertices(lgal::world::AABB3d const& box) const;	// NOTE: identifies false positives

		inline Corners const& corners() const { return mCorners; }
		inline std::array<lgal::world::Plane, 6> const& planes() { return mPlanes; }

	public:

		static Corners ComputeCorners(CameraState const& state);

	private:

		Corners mCorners;

		lgal::world::AABB3d mAABB;

		std::array<lgal::world::Plane, 6> mPlanes;

		// algorithm that determines intersection by checking the box vertices that are extreme in the 
		// direction of the plane normal and negative normal. we call the point extreme in the normal
		// direction the "extremity" and the point extreme in the negative normal the "antiextremity"
		//		- if there is a plane such that the extremity is outside the plane => OUTSIDE
		//		- if each plane's extremity/antiextremity is inside => INSIDE
		//		- all other cases => INTERSECT
		// NOTE: this is just uses the fact that we are testing a bounding box to skip checking some
		//       of the vertices that intersectsCheckAllVertices checks the long way
		Intersection boxExtremitiesAgainstFrustum(lgal::world::AABB3d const& box) const;
		
		// algorithm that determines intersection by checking
		//		- if there is a plane such that all box vertices are outside the plane => OUTSIDE
		//		- if all box vertices are inside every plane => INSIDE
		//		- all other cases => INTERSECT
		// NOTE: identifies false positives
		Intersection boxVerticesAgainstFrustum(lgal::world::AABB3d const& box) const;

		// algorithm that determines if the frustum is entirely outside any plane of the box (helps reduce false positives in above algorithms)
		static bool IsOutsideAnyBoxPlane(Frustum const& frustum, lgal::world::AABB3d const& box);

	private:

		// unscoped so we can index an array without casting
		enum Side
		{
			TOP = 0,
			BOTTOM,
			LEFT,
			RIGHT,
			NEARP,
			FARP
		};

	};

}