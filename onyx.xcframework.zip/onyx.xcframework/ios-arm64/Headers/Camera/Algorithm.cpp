#include "Algorithm.h"

namespace onyx {
namespace Math {

	Camera::CameraState orbit(lgal::world::Vector3 const& focus, Camera::CameraState const& initial, world_float_t const deltaHeading, world_float_t const deltaPitch, world_float_t const deltaRadius)
	{
		// compute position relative to the point we are orbiting around
		auto relative = initial.position - focus;
		// compute the initial orbit radius
		auto initialRadius = lmath::len(relative);

		// rotate around the pitch axis
		relative = rotateAround(relative, initial.rightDir(), -deltaPitch);
		// rotate around the yaw axis
		relative = rotateAround(relative, lgal::world::Vector3{ 0, 0, 1 }, deltaHeading);

		// compute theta
		auto theta = std::atan2(relative.y, relative.x);

		// compute phi
		// with infinite precision, the value of relative.z / initialRadius is in the range
		// [-1, 1], but with finite precision we might be slightly over. so we clamp to the
		// bounds to avoid getting NaNs
		auto clamped = std::clamp(relative.z / initialRadius, -1.0, 1.0);
		auto phi = std::acos(clamped);

		// compute radius
		auto radius = initialRadius + deltaRadius;

		// compute the transformed eye position
		relative =
		{
			radius * std::cos(theta) * std::sin(phi),
			radius * std::sin(theta) * std::sin(phi),
			radius * std::cos(phi)
		};

		// copy the initial camera state
		Camera::CameraState state = initial;

		// compute the look direction so the focus point ends up at the same point in screen space
		state.position = focus + relative;
		state.heading = state.heading + deltaHeading;
		state.pitch = state.pitch + deltaPitch;

		return state;
	}

} }