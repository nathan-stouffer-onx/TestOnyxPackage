#ifndef __SLOPE_ANGLE_RANGES_H__
#define __SLOPE_ANGLE_RANGES_H__

#include <bgfx/bgfx.h>

#include <Utils/Gradient.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx {

	class SlopeAngleRanges
	{
	public:

		SlopeAngleRanges();
		SlopeAngleRanges(Utils::Gradient const& line, std::vector<lgal::world::Range> const& ranges = {});
		~SlopeAngleRanges();

		void setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const;

		inline void setRanges(std::vector<lgal::world::Range> const& ranges) { mRanges = ranges; }

		inline bgfx::TextureHandle getTextureHandle() const { return mHandle; }

		void buildTexture();

	private:

		static constexpr uint32_t cResolution = 128;

		Utils::Gradient mColorLine;

		std::vector<lgal::world::Range> mRanges;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

		void destroyTexture();

	};

}

#endif