#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class SlopeAspectShade final : public TerrainEffectBase
	{
	public:

		SlopeAspectShade();
		~SlopeAspectShade();

		void update(Styling::SlopeAspectConfig const& config, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

	private:

		static constexpr uint32_t cResolution = 512;

		Styling::SlopeAspectConfig mConfig;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

	};

}