#include "ElevationShade.h"

#include <cstring> // for Linux memset

#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	static float MeetsMask(std::vector<lgal::gpu::Range> const& mask, height_float_t const elevation)
	{
		for (lgal::gpu::Range const& range : mask)
		{
			// check that the value is in the range and the range is not empty
			if (range.contains(elevation) && range.begin != range.end)
			{
				return 1.f;
			}
		}

		return 0.f;
	}

	ElevationShade::ElevationShade() {}

	ElevationShade::~ElevationShade()
	{
		BgfxUtils::tryDestroy(mHandle);
	}

	void ElevationShade::update(Styling::ElevationConfig const& config, lgal::height::Range const& rawExtents, Args const&)
	{
		// alias extents
		lgal::world::Range extents = rawExtents.as<world_float_t>();
		extents.begin = std::floor(extents.begin);
		extents.end = std::ceil(extents.end);

		if (config == mConfig && extents == mExtents && bgfx::isValid(mHandle)) { return; }

		mConfig = config;
		mExtents = extents;
		BgfxUtils::tryDestroy(mHandle);
		
		Utils::Gradient gradient = mConfig.gradient.scaleOpacity(mConfig.opacity);

		uint32_t size = cResolution * cResolution;
		bgfx::Memory const* mem = bgfx::alloc(size * sizeof(uint32_t));
		uint32_t* data = reinterpret_cast<uint32_t*>(mem->data);
		for (uint32_t i = 0; i < size; i++)
		{
			// compute t in [0, 1] -- sample pixel centers and compute corresponding elevation value
			time_float_t t = (time_float_t(i) + 0.5f) / time_float_t(size);
			time_float_t elevation = lmath::lerp(mExtents.begin, mExtents.end, t);

			// sample the color and write to the data buffer
			lgal::Color color = gradient.sample(elevation);
			color.a *= MeetsMask(mConfig.mask, static_cast<height_float_t>(elevation));
			*data++ = color.abgr();
		}
		mHandle = bgfx::createTexture2D(uint16_t(cResolution), uint16_t(cResolution), false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(mHandle, "ElevationShadeTexture");
	}

	void ElevationShade::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("s_ElevationShadeTexture", mHandle, cResolution, cResolution);
		shader.setParameter("u_ElevationExtents", lgal::world::Vector2(mExtents.begin, mExtents.end));
	}

}
