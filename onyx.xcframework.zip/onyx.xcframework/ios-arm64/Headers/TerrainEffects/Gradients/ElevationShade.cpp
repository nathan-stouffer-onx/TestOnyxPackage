#include "ElevationShade.h"

#include <cstring> // for Linux memset

#include "Caching/Tiles/TileCache.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	static float MeetsMask(std::vector<lgal::gpu::Range> const& mask, height_float_t const elevation)
	{
		for (lgal::gpu::Range const& range : mask)
		{
			// check that the value is in the range and the range is not empty
			if (range.contains(elevation) && range.begin != range.end)
			{
				return 1.f;
			}
		}

		return 0.f;
	}

	ElevationShade::ElevationShade() {}

	ElevationShade::~ElevationShade()
	{
		BgfxUtils::tryDestroy(mHandle);
	}

	bool ElevationShade::prepare(Args const& args)
	{
		Styling::ElevationLayer const& layer = static_cast<Styling::ElevationLayer const&>(args.layer);
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		Styling::ElevationConfig config = layer.realize(args.layerArgs);
		
		// alias extents
		Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
		lgal::world::Range extents = atlas.extents(args.onscreen.tileIds, false).as<world_float_t>();
		extents.begin = std::floor(extents.begin);
		extents.end = std::ceil(extents.end);

		if (config != mConfig || extents != mExtents || !bgfx::isValid(mHandle))
		{
			mConfig = config;
			mExtents = extents;
			BgfxUtils::tryDestroy(mHandle);

			Utils::Gradient gradient = mConfig.gradient.scaleOpacity(mConfig.opacity);

			uint32_t size = cResolution * cResolution;
			bgfx::Memory const* mem = bgfx::alloc(size * sizeof(uint32_t));
			uint32_t* data = reinterpret_cast<uint32_t*>(mem->data);
			for (uint32_t i = 0; i < size; i++)
			{
				// compute t in [0, 1] -- sample pixel centers and compute corresponding elevation value
				time_float_t t = (time_float_t(i) + 0.5f) / time_float_t(size);
				time_float_t elevation = lmath::lerp(mExtents.begin, mExtents.end, t);

				// sample the color and write to the data buffer
				lgal::Color color = gradient.sample(elevation);
				color.a *= MeetsMask(mConfig.mask, static_cast<height_float_t>(elevation));
				*data++ = color.abgr();
			}
			mHandle = bgfx::createTexture2D(uint16_t(cResolution), uint16_t(cResolution), false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
			bgfx::setName(mHandle, "ElevationGradient");
		}

		return TerrainEffectBase::Prepare(mTerrainParams, source, args.onscreen.tileIds);
	}

	void ElevationShade::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::AtlasInfo const& info = mTerrainParams.at(tileId);
		program.set("s_ElevationDem", info.handle, lgal::screen::Vector2(info.resolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_ScaleOffsetElevationDem", info.offset);

		program.set("s_ElevationGradient", mHandle, lgal::screen::Vector2(cResolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
		program.set("u_ElevationExtents", lgal::world::Vector2(mExtents.begin, mExtents.end));
	}

}
