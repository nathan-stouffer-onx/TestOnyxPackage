#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class IntersectShade final : public TerrainEffectBase
	{
	public:

		IntersectShade();
		~IntersectShade();

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;

		uint64_t state() const override { return static_cast<uint64_t>(mConfig.blendMode); }

	private:

		static constexpr size_t cElevationResolution = 256;
		static constexpr size_t cSlopeAngleResolution = 128;
		static constexpr size_t cSlopeAspectResolution = 512;

		Styling::IntersectConfig mConfig;

		DemParamsMapT mTerrainParams;

		lgal::globe::Range mExtents;

		bgfx::TextureHandle mElevationHandle = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mSlopeAngleHandle = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mSlopeAspectHandle = BGFX_INVALID_HANDLE;

		static bgfx::TextureHandle BuildElevation(Styling::IntersectConfig::MaskT const& ranges, lgal::globe::Range const& extents);
		static bgfx::TextureHandle BuildSlopeAngle(Styling::IntersectConfig::MaskT const& ranges);
		static bgfx::TextureHandle BuildSlopeAspect(Styling::IntersectConfig::MaskT const& ranges);

	};

}