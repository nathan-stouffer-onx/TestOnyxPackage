#include "SlopeAspectShade.h"

#include <Caching/Tiles/TileCache.h>

#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	static float MeetsMask(std::vector<lgal::gpu::Range> const& mask, float const theta)
	{
		for (lgal::gpu::Range const& range : mask)
		{
			// check that the value is in the range and the range is not empty
			if (range.circularContains(theta) && range.begin != range.end)
			{
				return 1.f;
			}
		}

		return 0.f;
	}

	SlopeAspectShade::SlopeAspectShade() {}

	SlopeAspectShade::~SlopeAspectShade()
	{
		BgfxUtils::tryDestroy(mHandle);
	}

	bool SlopeAspectShade::prepare(Args const& args)
	{
		Styling::SlopeAspectLayer const& layer = static_cast<Styling::SlopeAspectLayer const&>(args.layer);
		Styling::SlopeAspectConfig config = layer.realize(args.layerArgs);
		
		if (config != mConfig || !bgfx::isValid(mHandle))
		{
			mConfig = config;
			BgfxUtils::tryDestroy(mHandle);

			Utils::Gradient gradient = mConfig.gradient.scaleOpacity(mConfig.opacity);

			bgfx::Memory const* mem = bgfx::alloc(cResolution * sizeof(uint32_t));
			uint32_t* data = reinterpret_cast<uint32_t*>(mem->data);
			for (uint32_t i = 0; i < cResolution; i++)
			{
				// compute t in [0, 1] -- sample pixel centers
				time_float_t t = (time_float_t(i) + 0.5) / time_float_t(cResolution);
				time_float_t theta = t * lmath::constants::two_pi<time_float_t>();

				// sample the color and write to the data buffer
				lgal::Color color = gradient.sample(theta);
				color.a *= MeetsMask(mConfig.mask, static_cast<float>(theta));
				*data++ = color.abgr();
			}

			mHandle = bgfx::createTexture2D(uint16_t(cResolution), 1, false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
			bgfx::setName(mHandle, "SlopeAspectShadeTexture");
		}

		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		return TerrainEffectBase::Prepare(mTerrainParams, source, args.onscreen.tileIds);
	}


	void SlopeAspectShade::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::AtlasInfo const& info = mTerrainParams.at(tileId);
		program.set("s_SlopeAspectDem", info.handle, lgal::screen::Vector2(info.resolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_ScaleOffsetSlopeAspectDem", info.offset);

		program.set("s_SlopeAspectGradient", mHandle, lgal::screen::Vector2(cResolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
		program.set("u_SlopeAspectMaxNormalZ", std::cos(mConfig.minimumAngle));	// the maximum z value is the cosine of the minimum angle
	}

}