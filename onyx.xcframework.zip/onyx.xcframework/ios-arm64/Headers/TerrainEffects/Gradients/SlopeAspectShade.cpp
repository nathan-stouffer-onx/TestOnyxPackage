#include "SlopeAspectShade.h"

#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	static float MeetsMask(std::vector<lgal::gpu::Range> const& mask, float const theta)
	{
		for (lgal::gpu::Range const& range : mask)
		{
			// check that the value is in the range and the range is not empty
			if (range.circularContains(theta) && range.begin != range.end)
			{
				return 1.f;
			}
		}

		return 0.f;
	}

	SlopeAspectShade::SlopeAspectShade() {}

	SlopeAspectShade::~SlopeAspectShade()
	{
		BgfxUtils::tryDestroy(mHandle);
	}

	void SlopeAspectShade::update(Styling::SlopeAspectConfig const& config, Args const&)
	{
		if (config == mConfig && bgfx::isValid(mHandle)) { return; }

		mConfig = config;
		BgfxUtils::tryDestroy(mHandle);

		Utils::Gradient gradient = mConfig.gradient.scaleOpacity(mConfig.opacity);

		bgfx::Memory const* mem = bgfx::alloc(cResolution * sizeof(uint32_t));
		uint32_t* data = reinterpret_cast<uint32_t*>(mem->data);
		for (uint32_t i = 0; i < cResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			time_float_t t = (time_float_t(i) + 0.5) / time_float_t(cResolution);
			time_float_t theta = t * lmath::constants::two_pi<time_float_t>();

			// sample the color and write to the data buffer
			lgal::Color color = gradient.sample(theta);
			color.a *= MeetsMask(mConfig.mask, static_cast<float>(theta));
			*data++ = color.abgr();
		}

		mHandle = bgfx::createTexture2D(uint16_t(cResolution), 1, false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(mHandle, "SlopeAspectShadeTexture");
	}


	void SlopeAspectShade::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("s_SlopeAspectShadeTexture", mHandle);
		shader.setParameter("u_SlopeAspectMaxNormalZ", std::cos(mConfig.minimumAngle));	// the maximum z value is the cosine of the minimum angle
	}

}