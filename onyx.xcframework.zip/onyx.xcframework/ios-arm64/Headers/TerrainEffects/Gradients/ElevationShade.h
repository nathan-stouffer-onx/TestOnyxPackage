#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class ElevationShade final : public TerrainEffectBase
	{
	public:

		ElevationShade();
		~ElevationShade();

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;

		uint64_t state() const override { return static_cast<uint64_t>(mConfig.blendMode); }

	private:

		static constexpr uint32_t cResolution = 256;

		Styling::ElevationConfig mConfig;

		lgal::world::Range mExtents;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

		DemParamsMapT mTerrainParams;

	};

}