#include "SlopeAngleShade.h"

#include <Caching/Tiles/TileCache.h>

#include "Utils/BgfxUtils.h"

namespace onyx::TerrainEffects
{

	static float MeetsMask(std::vector<lgal::gpu::Range> const& mask, float const phi)
	{
		for (lgal::gpu::Range const& range : mask)
		{
			// check that the value is in the range and the range is not empty
			if (range.contains(phi) && range.begin != range.end)
			{
				return 1.f;
			}
		}

		return 0.f;
	}

	SlopeAngleShade::SlopeAngleShade() {}

	SlopeAngleShade::~SlopeAngleShade()
	{
		BgfxUtils::tryDestroy(mHandle);
	}

	bool SlopeAngleShade::prepare(Args const& args)
	{
		Styling::SlopeAngleLayer const& layer = static_cast<Styling::SlopeAngleLayer const&>(args.layer);
		Styling::SlopeAngleConfig config = layer.realize(args.layerArgs);

		if (config != mConfig || !bgfx::isValid(mHandle))
		{
			mConfig = config;
			BgfxUtils::tryDestroy(mHandle);

			Utils::Gradient gradient = mConfig.gradient.scaleOpacity(mConfig.opacity);

			bgfx::Memory const* mem = bgfx::alloc(cResolution * sizeof(uint32_t));
			uint32_t* data = reinterpret_cast<uint32_t*>(mem->data);
			for (uint32_t i = 0; i < cResolution; i++)
			{
				// compute t in [0, 1] -- sample pixel centers
				time_float_t t = (time_float_t(i) + 0.5) / time_float_t(cResolution);
				time_float_t phi = t * lmath::constants::half_pi<time_float_t>();

				// sample the color and write to the data buffer
				lgal::Color color = gradient.sample(phi);
				color.a *= MeetsMask(mConfig.mask, static_cast<float>(phi));
				*data++ = color.abgr();
			}

			mHandle = bgfx::createTexture2D(uint16_t(cResolution), 1, false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
			bgfx::setName(mHandle, "SlopeAngleGradient");
		}
	
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		return TerrainEffectBase::Prepare(mTerrainParams, source, args.onscreen.tileIds);
	}

	void SlopeAngleShade::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::AtlasInfo const& info = mTerrainParams.at(tileId);
		program.set("s_SlopeAngleDem", info.handle, lgal::screen::Vector2(info.resolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_ScaleOffsetSlopeAngleDem", info.offset);

		program.set("s_SlopeAngleGradient", mHandle, lgal::screen::Vector2(cResolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
	}

}