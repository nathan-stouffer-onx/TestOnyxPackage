#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class SlopeAngleShade final : public TerrainEffectBase
	{
	public:

		SlopeAngleShade();
		~SlopeAngleShade();

		void update(Styling::SlopeAngleConfig const& config, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

	private:

		static constexpr uint32_t cResolution = 128;

		Styling::SlopeAngleConfig mConfig;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

	};

}