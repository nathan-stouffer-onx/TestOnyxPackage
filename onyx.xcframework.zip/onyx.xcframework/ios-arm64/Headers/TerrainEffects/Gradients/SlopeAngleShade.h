#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class SlopeAngleShade final : public TerrainEffectBase
	{
	public:

		SlopeAngleShade();
		~SlopeAngleShade();

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;

		uint64_t state() const override { return static_cast<uint64_t>(mConfig.blendMode); }

	private:

		static constexpr uint32_t cResolution = 128;

		Styling::SlopeAngleConfig mConfig;

		DemParamsMapT mTerrainParams;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

	};

}