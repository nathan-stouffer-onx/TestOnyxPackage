#include "IntersectShade.h"

#include <cstring> // for Linux memset

#include "Caching/Tiles/TileCache.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	IntersectShade::IntersectShade() {}

	IntersectShade::~IntersectShade()
	{
		BgfxUtils::tryDestroy(mElevationHandle);
		BgfxUtils::tryDestroy(mSlopeAngleHandle);
		BgfxUtils::tryDestroy(mSlopeAspectHandle);
	}

	bool IntersectShade::prepare(Args const& args)
	{
		Styling::IntersectLayer const& layer = static_cast<Styling::IntersectLayer const&>(args.layer);
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		Styling::IntersectConfig config = layer.realize(args.layerArgs);

		Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
		lgal::globe::Range rawExtents = atlas.extents(args.onscreen.tileIds, false);
		lgal::globe::Range extents = { std::floor(rawExtents.begin), std::ceil(rawExtents.end) };

		if (config.elevationMask != mConfig.elevationMask || extents != mExtents || !bgfx::isValid(mElevationHandle))
		{
			BgfxUtils::tryDestroy(mElevationHandle);
			mElevationHandle = IntersectShade::BuildElevation(config.elevationMask, extents);
		}

		if (config.slopeAngleMask != mConfig.slopeAngleMask || !bgfx::isValid(mSlopeAngleHandle))
		{
			BgfxUtils::tryDestroy(mSlopeAngleHandle);
			mSlopeAngleHandle = IntersectShade::BuildSlopeAngle(config.slopeAngleMask);
		}

		if (config.slopeAspectMask != mConfig.slopeAspectMask || !bgfx::isValid(mSlopeAspectHandle))
		{
			BgfxUtils::tryDestroy(mSlopeAspectHandle);
			mSlopeAspectHandle = IntersectShade::BuildSlopeAspect(config.slopeAspectMask);
		}
		
		mConfig = config;
		mExtents = extents;

		return TerrainEffectBase::Prepare(mTerrainParams, source, args.onscreen.tileIds);
	}

	void IntersectShade::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::AtlasInfo const& info = mTerrainParams.at(tileId);
		program.set("s_IntersectDem", info.handle, lgal::screen::Vector2(info.resolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_ScaleOffsetIntersectDem", info.offset);

		program.set("u_IntersectTint", lgal::Color::FromABGR(mConfig.abgr));
		program.set("u_PackedIntersectParams", lgal::world::Vector4(mConfig.inverted ? 1.0f : 0.0f, std::cos(mConfig.slopeAspectMinimumAngle), mExtents.begin, mExtents.end));

		program.set(  "s_ElevationShadeDem",   mElevationHandle, lgal::screen::Vector2(  cElevationResolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
		program.set( "s_SlopeAngleShadeDem",  mSlopeAngleHandle, lgal::screen::Vector2( cSlopeAngleResolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
		program.set("s_SlopeAspectShadeDem", mSlopeAspectHandle, lgal::screen::Vector2(cSlopeAspectResolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
	}

	bgfx::TextureHandle IntersectShade::BuildElevation(Styling::IntersectConfig::MaskT const& mask, lgal::globe::Range const& extents)
	{
		size_t size = cElevationResolution * cElevationResolution;
		bgfx::Memory const* mem = bgfx::alloc(static_cast<uint32_t>(size * sizeof(uint8_t)));
		uint8_t* data = mem->data;
		std::memset(static_cast<void*>(data), 0, size * sizeof(uint8_t));	// default indicator to off
		for (size_t i = 0; i < size; ++i)
		{
			// compute t in [0, 1] -- sample pixel centers and the corresponding elevation
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(size);
			globe_float_t elevation = lmath::lerp(extents.begin, extents.end, t);

			// iterate over the ranges, only turning the indicator on if the elevation is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				*data |= (range.contains(elevation) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}

			// increment pointer
			++data;
		}

		// create texture
		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cElevationResolution), uint16_t(cElevationResolution), false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "ElevationMaskTexture");
		return handle;
	}

	bgfx::TextureHandle IntersectShade::BuildSlopeAngle(Styling::IntersectConfig::MaskT const& mask)
	{
		bgfx::Memory const* mem = bgfx::alloc(cSlopeAngleResolution * sizeof(uint8_t));
		uint8_t* data = mem->data;
		std::memset(static_cast<void*>(data), 0, cSlopeAngleResolution * sizeof(uint8_t));	// default indicator to off
		for (uint32_t i = 0; i < cSlopeAngleResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(cSlopeAngleResolution);
			globe_float_t phi = t * lmath::constants::half_pi<globe_float_t>();

			// iterate over the ranges, only turning the indicator on if the angle is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				*data |= (range.contains(phi) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}

			// increment data pointer
			++data;
		}

		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cSlopeAngleResolution), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "SlopeAngleMaskTexture");
		return handle;
	}

	bgfx::TextureHandle IntersectShade::BuildSlopeAspect(Styling::IntersectConfig::MaskT const& mask)
	{
		bgfx::Memory const* mem = bgfx::alloc(cSlopeAspectResolution * sizeof(uint8_t));
		uint8_t* data = mem->data;
		std::memset(static_cast<void*>(data), 0, cSlopeAspectResolution * sizeof(uint8_t));	// default indicator to off
		for (size_t i = 0; i < cSlopeAspectResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(cSlopeAspectResolution);
			globe_float_t theta = t * lmath::constants::two_pi<globe_float_t>();

			// iterate over the ranges, only turning the color on if theta is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				*data |= (range.circularContains(theta) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}

			// increment data pointer
			++data;
		}

		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cSlopeAspectResolution), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "SlopeAspectMaskTexture");
		return handle;
	}

}
