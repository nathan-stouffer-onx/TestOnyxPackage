#include "IntersectShade.h"

#include <cstring> // for Linux memset

#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	IntersectShade::IntersectShade() {}

	IntersectShade::~IntersectShade()
	{
		BgfxUtils::tryDestroy(mElevationHandle);
		BgfxUtils::tryDestroy(mSlopeAngleHandle);
		BgfxUtils::tryDestroy(mSlopeAspectHandle);
	}

	void IntersectShade::update(Styling::IntersectConfig const& config, lgal::height::Range const& rawExtents, Args const&)
	{
		lgal::globe::Range extents = { std::floor(rawExtents.begin), std::ceil(rawExtents.end) };

		if (config == mConfig && extents == mExtents) { return; }

		if (config.elevationMask != mConfig.elevationMask || extents != mExtents || !bgfx::isValid(mElevationHandle))
		{
			BgfxUtils::tryDestroy(mElevationHandle);
			mElevationHandle = IntersectShade::BuildElevation(config.elevationMask, extents);
		}

		if (config.slopeAngleMask != mConfig.slopeAngleMask || !bgfx::isValid(mSlopeAngleHandle))
		{
			BgfxUtils::tryDestroy(mSlopeAngleHandle);
			mSlopeAngleHandle = IntersectShade::BuildSlopeAngle(config.slopeAngleMask);
		}

		if (config.slopeAspectMask != mConfig.slopeAspectMask || !bgfx::isValid(mSlopeAspectHandle))
		{
			BgfxUtils::tryDestroy(mSlopeAspectHandle);
			mSlopeAspectHandle = IntersectShade::BuildSlopeAspect(config.slopeAspectMask);
		}
		
		mConfig = config;
		mExtents = extents;
	}

	void IntersectShade::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("u_IntersectInverted", mConfig.inverted ? 1.0f : 0.0f);
		shader.setParameter("u_IntersectTint", lgal::Color::FromABGR(mConfig.abgr));
		shader.setParameter("u_ElevationExtents", lgal::world::Vector2(mExtents.begin, mExtents.end));
		shader.setParameter("s_ElevationShadeTexture", mElevationHandle, static_cast<int>(cElevationResolution), static_cast<int>(cElevationResolution));
		shader.setParameter("s_SlopeAngleShadeTexture", mSlopeAngleHandle);
		shader.setParameter("s_SlopeAspectShadeTexture", mSlopeAspectHandle);
	}

	bgfx::TextureHandle IntersectShade::BuildElevation(Styling::IntersectConfig::MaskT const& mask, lgal::globe::Range const& extents)
	{
		size_t size = cElevationResolution * cElevationResolution;
		bgfx::Memory const* mem = bgfx::alloc(static_cast<uint32_t>(size * sizeof(uint8_t)));
		uint8_t* data = mem->data;
		std::memset(static_cast<void*>(data), 0, size * sizeof(uint8_t));	// default indicator to off
		for (size_t i = 0; i < size; ++i)
		{
			// compute t in [0, 1] -- sample pixel centers and the corresponding elevation
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(size);
			globe_float_t elevation = lmath::lerp(extents.begin, extents.end, t);

			// iterate over the ranges, only turning the indicator on if the elevation is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				*data |= (range.contains(elevation) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}

			// increment pointer
			++data;
		}

		// create texture
		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cElevationResolution), uint16_t(cElevationResolution), false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "ElevationMaskTexture");
		return handle;
	}

	bgfx::TextureHandle IntersectShade::BuildSlopeAngle(Styling::IntersectConfig::MaskT const& mask)
	{
		bgfx::Memory const* mem = bgfx::alloc(cSlopeAngleResolution * sizeof(uint8_t));
		uint8_t* data = mem->data;
		std::memset(static_cast<void*>(data), 0, cSlopeAngleResolution * sizeof(uint8_t));	// default indicator to off
		for (uint32_t i = 0; i < cSlopeAngleResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(cSlopeAngleResolution);
			globe_float_t phi = t * lmath::constants::half_pi<globe_float_t>();

			// iterate over the ranges, only turning the indicator on if the angle is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				*data |= (range.contains(phi) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}

			// increment data pointer
			++data;
		}

		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cSlopeAngleResolution), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "SlopeAngleMaskTexture");
		return handle;
	}

	bgfx::TextureHandle IntersectShade::BuildSlopeAspect(Styling::IntersectConfig::MaskT const& mask)
	{
		bgfx::Memory const* mem = bgfx::alloc(cSlopeAspectResolution * sizeof(uint8_t));
		uint8_t* data = mem->data;
		std::memset(static_cast<void*>(data), 0, cSlopeAspectResolution * sizeof(uint8_t));	// default indicator to off
		for (size_t i = 0; i < cSlopeAspectResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(cSlopeAspectResolution);
			globe_float_t theta = t * lmath::constants::two_pi<globe_float_t>();

			// iterate over the ranges, only turning the color on if theta is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				*data |= (range.circularContains(theta) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}

			// increment data pointer
			++data;
		}

		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cSlopeAspectResolution), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "SlopeAspectMaskTexture");
		return handle;
	}

}
