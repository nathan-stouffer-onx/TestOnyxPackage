#pragma once

#include <lucid/gal/Types.h>

#include "TerrainEffects/Horizon.h"
#include "TerrainEffects/TerrainEffectBase.h"
#include "Tiles/TileRenderInfo.h"

namespace onyx::TerrainEffects
{

	class ContourLine final : public TerrainEffectBase
	{
	public:

		ContourLine();

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;

		uint64_t state() const override { return static_cast<uint64_t>(mConfig.blendMode); }

	private:

		Styling::ContourLineConfig mConfig;

		DemParamsMapT mTerrainParams;

	};

}