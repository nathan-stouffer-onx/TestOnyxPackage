#pragma once

#include <lucid/gal/Types.h>

#include "TerrainEffects/Horizon.h"
#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class ContourLine final : public TerrainEffectBase
	{
	public:

		ContourLine();

		void update(Styling::ContourLineConfig const& config, size_t i, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

	private:

		Styling::ContourLineConfig mConfig;
		std::string mIndex;
		Camera::CameraState mCameraState;

		Horizon::Config mHorizonConfig;
		world_float_t mMaxPitch = lmath::constants::quarter_pi<world_float_t>();
	};

}