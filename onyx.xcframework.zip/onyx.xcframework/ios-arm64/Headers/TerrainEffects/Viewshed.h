#pragma once

#include <Shaders/v2/Program.h>

#include <Styling/Styles/ShadowConfigs.h>

#include "TerrainEffectBase.h"
#include "Pyramid/Culling.h"

namespace onyx::TerrainEffects {

	class Viewshed : public TerrainEffectBase
	{
	public:

		Viewshed();
		~Viewshed();

		virtual void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

		virtual void getLabels(std::vector<Symbol::SharedSymbol_t>& symbols) const override;

		void update(Styling::ViewshedConfig const& config, Args const& args);

		bgfx::TextureHandle getDepthHandle() const { return mCubemapDepthTexHandle[0]; }

	private:

		Styling::ViewshedConfig mConfig;
		Camera::CameraState mCameraState;
		lgal::world::Vector2 mPosition;
		lgal::world::Vector3 mEye;

		bool mCompleted = false;

		std::vector<Symbol::SharedSymbol_t> mSymbols;

		world_float_t mNearPlane;
		world_float_t mFarPlane;

		Pyramid::CullResult mCullState;

		uint16_t const mCubeDepthRes = 2048;

		Shaders::Program mDistanceProgram;

		// cubemap for viewshed/point light shadows
		bgfx::TextureHandle mCubemapDepthTexHandle[2] = { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE };
		bgfx::FrameBufferHandle mCubemapDepthFrameBufferHandle[6] = { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE };
		bgfx::Attachment mCubemapAttachments[6][2];

		void allocateFramebuffer();
		void deallocateFramebuffer();

		float mCubemapProj[16] = { };
		float mCubemapView[6][16] = { };

		void setCubeView(bgfx::ViewId viewId, int side);
		void updateLabels(Atlases::HeightAtlas const& atlas);

		static lgal::world::Vector3 const sCubemapLookDirs[6];
		static lgal::world::Vector3 const sCubemapUpDirs[6];
		static world_float_t const sCubemapHeadings[6];

	};

}
