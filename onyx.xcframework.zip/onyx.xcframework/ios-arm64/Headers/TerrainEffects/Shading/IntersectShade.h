#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class IntersectShade final : public TerrainEffectBase
	{
	public:

		IntersectShade();
		~IntersectShade();

		void update(Styling::IntersectConfig const& config, lgal::height::Range const& extents, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

	private:

		static constexpr size_t cMaxElevationResolution = 4096;
		static constexpr size_t cSlopeAngleResolution = 128;
		static constexpr size_t cSlopeAspectResolution = 512;

		Styling::IntersectConfig mConfig;

		lgal::globe::Range mExtents;

		bgfx::TextureHandle mElevationHandle = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mSlopeAngleHandle = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle mSlopeAspectHandle = BGFX_INVALID_HANDLE;

		static bgfx::TextureHandle BuildElevation(Styling::IntersectConfig::MaskT const& ranges, lgal::globe::Range const& extents);
		static bgfx::TextureHandle BuildSlopeAngle(Styling::IntersectConfig::MaskT const& ranges);
		static bgfx::TextureHandle BuildSlopeAspect(Styling::IntersectConfig::MaskT const& ranges);

	};

}