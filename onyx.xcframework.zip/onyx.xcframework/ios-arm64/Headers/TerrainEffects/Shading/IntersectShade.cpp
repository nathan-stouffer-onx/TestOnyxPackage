#include "IntersectShade.h"

#include <cstring> // for Linux memset

#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	IntersectShade::IntersectShade() {}

	IntersectShade::~IntersectShade()
	{
		BgfxUtils::tryDestroy(mElevationHandle);
		BgfxUtils::tryDestroy(mSlopeAngleHandle);
		BgfxUtils::tryDestroy(mSlopeAspectHandle);
	}

	void IntersectShade::update(Styling::IntersectConfig const& config, lgal::height::Range const& rawExtents, Args const&)
	{
		// use integer end points and make each pixel step 1 meter
		// if the range covers more than 4096m, just use 4096. we are probably zoomed out enough that it won't matter
		auto begin = std::clamp(std::floor(rawExtents.begin), static_cast<height_float_t>(MapMath::cMinHeight), static_cast<height_float_t>(MapMath::cMaxHeight));
		auto end = std::clamp(std::ceil(rawExtents.end), static_cast<height_float_t>(MapMath::cMinHeight), static_cast<height_float_t>(MapMath::cMaxHeight));
		lgal::globe::Range extents(begin, end);

		if (config == mConfig && extents == mExtents) { return; }

		if (config.elevationMask != mConfig.elevationMask || extents != mExtents)
		{
			BgfxUtils::tryDestroy(mElevationHandle);
			mElevationHandle = IntersectShade::BuildElevation(config.elevationMask, extents);
		}

		if (config.slopeAngleMask != mConfig.slopeAngleMask)
		{
			BgfxUtils::tryDestroy(mSlopeAngleHandle);
			mSlopeAngleHandle = IntersectShade::BuildSlopeAngle(config.slopeAngleMask);
		}

		if (config.slopeAspectMask != mConfig.slopeAspectMask)
		{
			BgfxUtils::tryDestroy(mSlopeAspectHandle);
			mSlopeAspectHandle = IntersectShade::BuildSlopeAspect(config.slopeAspectMask);
		}
		
		mConfig = config;
		mExtents = extents;
	}

	void IntersectShade::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("u_IntersectInverted", mConfig.inverted ? 1.0f : 0.0f);
		shader.setParameter("u_IntersectTint", lgal::Color::FromABGR(mConfig.abgr));
		shader.setParameter("u_ElevationExtents", lgal::world::Vector2(mExtents.begin, mExtents.end));
		shader.setParameter("s_ElevationShadeTexture", mElevationHandle);
		shader.setParameter("s_SlopeAngleShadeTexture", mSlopeAngleHandle);
		shader.setParameter("s_SlopeAspectShadeTexture", mSlopeAspectHandle);
	}

	bgfx::TextureHandle IntersectShade::BuildElevation(Styling::IntersectConfig::MaskT const& mask, lgal::globe::Range const& extents)
	{
		size_t size = std::min(size_t(extents.end - extents.begin) * 1000, cMaxElevationResolution);
		
		std::vector<uint8_t> indicators(size, 0x00);
		for (size_t i = 0; i < size; ++i)
		{
			// compute t in [0, 1] -- sample pixel centers and the corresponding elevation
			globe_float_t u = (globe_float_t(i) + 0.5f) / globe_float_t(size);
			globe_float_t elevation = lmath::lerp(extents.begin, extents.end, u);

			// iterate over the ranges, only turning the indicator on if the elevation is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				indicators[i] |= (range.contains(elevation) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}
		}

		// create gpu memory and free cpu memory
		bgfx::Memory const* mem = bgfx::copy(static_cast<void*>(indicators.data()), static_cast<uint32_t>(size * sizeof(uint8_t)));

		// create texture
		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(size), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "ElevationMaskTexture");
		return handle;
	}

	bgfx::TextureHandle IntersectShade::BuildSlopeAngle(Styling::IntersectConfig::MaskT const& mask)
	{
		uint8_t data[cSlopeAngleResolution] = { 0 };
		for (uint32_t i = 0; i < cSlopeAngleResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(cSlopeAngleResolution);
			globe_float_t phi = t * lmath::constants::half_pi<globe_float_t>();

			// iterate over the ranges, only turning the indicator on if the angle is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				data[i] |= (range.contains(phi) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}
		}

		bgfx::Memory const* mem = bgfx::copy((void*)data, cSlopeAngleResolution * sizeof(uint8_t));
		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cSlopeAngleResolution), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "SlopeAngleMaskTexture");
		return handle;
	}

	bgfx::TextureHandle IntersectShade::BuildSlopeAspect(Styling::IntersectConfig::MaskT const& mask)
	{
		uint8_t data[cSlopeAspectResolution] = { 0 };
		for (size_t i = 0; i < cSlopeAspectResolution; i++)
		{
			// compute t in [0, 1] -- sample pixel centers
			globe_float_t t = (globe_float_t(i) + 0.5f) / globe_float_t(cSlopeAspectResolution);
			globe_float_t theta = t * lmath::constants::two_pi<globe_float_t>();

			// iterate over the ranges, only turning the color on if theta is in one of the ranges
			for (lgal::globe::Range const& range : mask)
			{
				data[i] |= (range.circularContains(theta) && range.begin != range.end) ? 0xFF : 0x00;	// flag byte appropriately
			}
		}

		bgfx::Memory const* mem = bgfx::copy((void*)data, cSlopeAspectResolution * sizeof(uint8_t));
		bgfx::TextureHandle handle = bgfx::createTexture2D(uint16_t(cSlopeAspectResolution), 1, false, 1, bgfx::TextureFormat::R8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(handle, "SlopeAspectMaskTexture");
		return handle;
	}

}
