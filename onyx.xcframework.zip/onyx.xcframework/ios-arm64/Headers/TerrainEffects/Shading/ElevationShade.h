#pragma once

#include <bgfx/bgfx.h>

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class ElevationShade final : public TerrainEffectBase
	{
	public:

		ElevationShade();
		~ElevationShade();

		void update(Styling::ElevationConfig const& config, lgal::height::Range const& extents, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

	private:

		static constexpr size_t cMaxResolution = 4096;

		Styling::ElevationConfig mConfig;

		lgal::world::Range mExtents;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

	};

}