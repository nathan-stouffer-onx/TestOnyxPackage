#include "ElevationShade.h"

#include <cstring> // for Linux memset

#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	static float MeetsMask(std::vector<lgal::gpu::Range> const& mask, height_float_t const elevation)
	{
		for (lgal::gpu::Range const& range : mask)
		{
			// check that the value is in the range and the range is not empty
			if (range.contains(elevation) && range.begin != range.end)
			{
				return 1.f;
			}
		}

		return 0.f;
	}

	ElevationShade::ElevationShade() {}

	ElevationShade::~ElevationShade()
	{
		BgfxUtils::tryDestroy(mHandle);
	}

	void ElevationShade::update(Styling::ElevationConfig const& config, lgal::height::Range const& rawExtents, Args const&)
	{
		// use integer end points and make each pixel step 1 meter
		// if the range covers more than 4096m, just use 4096. we are probably zoomed out enough that it won't matter
		height_float_t begin = std::clamp(std::floor(rawExtents.begin), static_cast<height_float_t>(MapMath::cMinHeight), static_cast<height_float_t>(MapMath::cMaxHeight));
		height_float_t end = std::clamp(std::ceil(rawExtents.end), static_cast<height_float_t>(MapMath::cMinHeight), static_cast<height_float_t>(MapMath::cMaxHeight));
		lgal::world::Range extents(begin, end);

		if (config == mConfig && extents == mExtents) { return; }
		
		mConfig = config;
		mExtents = extents;
		BgfxUtils::tryDestroy(mHandle);
		
		Utils::Gradient gradient = mConfig.gradient.scaleOpacity(mConfig.opacity);

		size_t size = std::min(size_t(end - begin) * 1000, cMaxResolution);
		std::vector<uint32_t> data(size, 0x00000000);
		for (size_t i = 0; i < size; i++)
		{
			// compute t in [0, 1] -- sample pixel centers and compute corresponding elevation value
			height_float_t u = (height_float_t(i) + 0.5f) / height_float_t(size);
			height_float_t elevation = lmath::lerp(begin, end, u);

			// sample the color and write to the data buffer
			lgal::Color color = gradient.sample(elevation);
			color.a *= MeetsMask(mConfig.mask, elevation);
			data[i] = color.abgr();
		}

		// create gpu memory and free cpu memory
		bgfx::Memory const* mem = bgfx::copy(static_cast<void*>(data.data()), static_cast<uint32_t>(size * sizeof(uint32_t)));

		// create texture
		mHandle = bgfx::createTexture2D(uint16_t(size), 1, false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(mHandle, "ElevationShadeTexture");
	}

	void ElevationShade::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("s_ElevationShadeTexture", mHandle);
		shader.setParameter("u_ElevationExtents", lgal::world::Vector2(mExtents.begin, mExtents.end));
	}

}
