#pragma once
#if !defined(TERRAIN_EFFECT_BASE_H)
#define TERRAIN_EFFECT_BASE_H

#include <memory>

#include <lucid/gigl/Context.h>
#include <bgfx/bgfx.h>
#include <Shaders/ShaderDefinition.h>

#include "DataObjects/MapLabel.h"
#include "Camera/CameraState.h"
#include "Utils/property.h"
#include "Utils/Timer.h"

namespace onyx {
namespace TerrainEffects {

	class TerrainEffectBase {
	public:
		virtual void initialize(std::shared_ptr<lucid::gigl::Context> context) = 0;
		virtual void setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const = 0;
		virtual std::vector<std::string> getComponents() const = 0;
		DISABLE_WARNING_PUSH
		DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
		virtual void getLabels(std::vector<std::shared_ptr<DataObjects::MapLabel>>& labels) const { }
		DISABLE_WARNING_POP
		// Return True if the effect has any changes
		virtual bool update(Camera::CameraState const& cameraState, std::shared_ptr<lucid::gigl::Context> context, Utils::Timer::Map3D_time_t timeMS) = 0;
		GET_SET_PROP(Enabled, bool, true);

		virtual ~TerrainEffectBase() { }

	protected:
		virtual void propertyChanged(const char* /* propName */) { }
	};

} }

#endif