#pragma once

#include <string>
#include <unordered_map>

#include <lucid/gal/Types.h>
#include <Shaders/Program.h>
#include <Styling/Layers/Layer.h>

#include "Atlases/HeightAtlas.h"
#include "Caching/Tiles/Source.h"
#include "Camera/CameraState.h"
#include "Pyramid/Culling.h"
#include "Sprites/Spritesheet.h"
#include "Symbol/MapSymbol.h"
#include "TerrainEffects/Horizon.h"
#include "Tiles/TileId.h"
#include "Tiles/TileRenderInfo.h"

namespace onyx::TerrainEffects
{

	class TerrainEffectBase
	{
	public:

		struct Args
		{
			Styling::Layer const& layer;					// the style layer for this effect
			Camera::CameraState const& camera;				// current frame camera state
			Pyramid::CullResult const& onscreen;			// the tiles that are rendered to the screen
			Styling::Arguments layerArgs;					// the arguments that can be used to evaluate the style layer
			Horizon const& horizon;							// horizon configuration
			std::shared_ptr<Spritesheet const> sprites;		// the spritesheet
			float zoom;										// the zoom value
			float filteredZoomKm;							// the filtered zoom value in km
			time_float_t timeMS;							// current frame time
		};

	public:

		virtual ~TerrainEffectBase() { }
		
		virtual bool prepare(Args const& args) = 0;

		virtual void set(Shaders::Program& program, Tiles::TileId const& tileId) const = 0;

		virtual uint64_t state() const = 0;

		DISABLE_WARNING_PUSH
		DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
		virtual void getLabels(std::vector<Symbol::SharedSymbol_t>& symbols) const { }
		DISABLE_WARNING_POP
		
		inline void toggle(bool visible) { mIsVisible = visible; }
		inline void toggle() { mIsVisible = !mIsVisible; }

		inline bool isVisible() const { return mIsVisible; }

	protected:

		using DemParamsMapT = std::unordered_map<Tiles::TileId, Tiles::AtlasInfo>;

		static bool Prepare(DemParamsMapT& params, Caching::Source const& source, std::vector<Tiles::TileId> const& tiles);

	protected:

		bool mIsVisible = false;

	};

}