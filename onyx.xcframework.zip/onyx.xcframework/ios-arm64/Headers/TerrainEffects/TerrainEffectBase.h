#pragma once

#include <memory>
#include <string>

#include <bgfx/bgfx.h>
#include <lucid/gal/Types.h>
#include <Shaders/ShaderDefinition.h>

#include "Atlases/HeightAtlas.h"
#include "Caching/Tiles/Source.h"
#include "Symbol/MapSymbol.h"
#include "Camera/CameraState.h"
#include "Tiles/TileId.h"

namespace onyx::TerrainEffects
{

	class TerrainEffectBase
	{
	public:

		struct Args
		{
			std::string const& id;					// id of the source in the style
			Caching::Source const& source;			// cached data source
			Atlases::HeightAtlas const& atlas;		// height data for this source
			Camera::CameraState const& camera;		// current frame camera state
			time_float_t timeMS;					// current frame time
		};

	public:

		virtual ~TerrainEffectBase() { }
		
		virtual void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const = 0;

		DISABLE_WARNING_PUSH
		DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
		virtual void getLabels(std::vector<Symbol::SharedSymbol_t>& symbols) const { }
		DISABLE_WARNING_POP
		
		inline void toggle(bool visible) { mIsVisible = visible; }
		inline void toggle() { mIsVisible = !mIsVisible; }

		inline bool isVisible() const { return mIsVisible; }

	protected:

		bool mIsVisible = false;

	};

}