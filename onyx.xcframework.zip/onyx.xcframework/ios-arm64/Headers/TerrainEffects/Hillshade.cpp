#include "Hillshade.h"

namespace onyx::TerrainEffects
{

	void Hillshade::update(Styling::HillshadeConfig const& config, Args const&)
	{
		mConfig = config;
	}

	void Hillshade::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("u_HillshadeLightDir", Styling::HillshadeConfig::LightDirection(mConfig.azimuth, mConfig.altitude));
		shader.setParameter("u_HillshadeAlbedo", lgal::Color::FromABGR(mConfig.abgr));
		shader.setParameter("u_HillshadeParams", lgal::gpu::Vector2(mConfig.ambientIntensity, mConfig.exaggeration));
	}

}