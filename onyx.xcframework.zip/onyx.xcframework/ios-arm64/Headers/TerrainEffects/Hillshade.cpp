#include "Hillshade.h"

#include <Caching/Tiles/TileCache.h>

namespace onyx::TerrainEffects
{

	bool Hillshade::prepare(Args const& args)
	{
		Styling::HillshadeLayer const& layer = static_cast<Styling::HillshadeLayer const&>(args.layer);
		Styling::HillshadeConfig config = layer.realize(args.layerArgs);
		mConfig = config;

		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		return TerrainEffectBase::Prepare(mTerrainParams, source, args.onscreen.tileIds);
	}

	void Hillshade::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::AtlasInfo const& info = mTerrainParams.at(tileId);
		program.set("s_HillshadeDem", info.handle, lgal::screen::Vector2(info.resolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_ScaleOffsetHillshadeDem", info.offset);

		program.set("u_HillshadeLightDir", Styling::HillshadeConfig::LightDirection(mConfig.azimuth, mConfig.altitude));
		program.set("u_HillshadeAlbedo", lgal::Color::FromABGR(mConfig.abgr));
		program.set("u_HillshadeParams", lgal::gpu::Vector4(mConfig.ambientIntensity, mConfig.exaggeration, 0, 0));
	}

}