#include "SunShadow.h"

#include <Shaders/ShaderManager.h>

#include "Pyramid/UVOffset.h"
#include "Rendering/ViewId.h"
#include "Tiles/TileMesh.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace TerrainEffects {

	ShadowCascade::ShadowCascade(uint16_t res, int id)
	{
		mDepthFrameBufferHandle[0] = BGFX_INVALID_HANDLE;
		mDepthFrameBufferHandle[1] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[0][0] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[0][1] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[1][0] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[1][1] = BGFX_INVALID_HANDLE;
		mShadowRes = res;
		mNearPlane = 1.0;
		mCascadeId = id;
	}

	ShadowCascade::~ShadowCascade()
	{
		if (bgfx::isValid(mQuadVertsBuffer))
		{
			bgfx::destroy(mQuadVertsBuffer);
		}

		deallocateFrameBuffer();
	}

	void ShadowCascade::deallocateFrameBuffer()
	{
		for (int i = 0; i < 2; i++)
		{
			if (bgfx::isValid(mDepthFrameBufferHandle[i]))
			{
				bgfx::destroy(mDepthFrameBufferHandle[i]);
				mDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
			}

			for (int j = 0; j < 2; j++)
			{
				if (bgfx::isValid(mDepthTexHandle[i][j]))
				{
					bgfx::destroy(mDepthTexHandle[i][j]);
					mDepthTexHandle[i][j] = BGFX_INVALID_HANDLE;
				}
			}
		}
	}

	void ShadowCascade::updateDepthBuffer(lgal::world::Vector3 const& sunDir, Atlases::HeightAtlas const& atlas, Pyramid::CullResult const& tiles)
	{
		lgal::world::AABB3d terrainBounds;
		terrainBounds.min = lgal::world::Vector3(9999999);
		terrainBounds.max = lgal::world::Vector3(-9999999);

		std::map<Tiles::TileId, Tiles::TileId> readyTiles;

		for (const auto& tileId : tiles.tileIds)
		{
			//todo - maybe include the overlapping tiles here?
			if (tileId.level > mSmallestLevel + 1 || tileId.level < mBiggestLevel - 1)
				continue; //not part of this cascade, so ignore it for sizing

			Tiles::TileId readyId = tileId.moduloX();
			bool found = false;
			while (!found && readyId.level >= 0)
			{
				if (atlas.isReady(readyId))
				{
					found = true;
					readyTiles[tileId] = readyId;

					lgal::world::AABB2d planarBounds = tileId.worldBounds<world_float_t>();
					lgal::globe::Range zBounds = atlas.heightExtents(tileId);
					lgal::world::AABB3d bounds({ planarBounds.min, zBounds.begin }, { planarBounds.max, zBounds.end });
					terrainBounds = lmath::fit(terrainBounds, bounds);
				}
				else if (readyId == Tiles::TileId::Root())
				{
					break;
				}
				else
				{
					readyId = readyId.parent();
				}
			}
		}

		bx::mtxLookAt(mSunView, { 0, 0, 0 }, BgfxUtils::toBx(-sunDir), BgfxUtils::toBx(lgal::world::Vector3(0, 1, 0)));

		//make sure our min and max are still mins and maxes after we spun it around
		bx::Vec3 minBounds = BgfxUtils::toBx(terrainBounds.min);
		bx::Vec3 maxBounds = BgfxUtils::toBx(terrainBounds.max);

		bx::Vec3 center = bx::div(bx::add(minBounds, maxBounds), 2.0f);
		world_float_t radius = bx::length(bx::sub(minBounds, center));
		world_float_t farPlane = radius * 2.5 + mNearPlane;

		float left = (float)-radius;
		float right = (float)radius;
		float top = (float)radius;
		float bottom = (float)-radius;
		mFarPlane = farPlane;//radius * 2.0;
		bx::mtxOrtho(mSunProj, left, right, bottom, top, float(mNearPlane), float(mFarPlane), 0.0f, bgfx::getCaps()->homogeneousDepth);

		mEyePos = lgal::world::Vector3(center.x, center.y, center.z) + sunDir * (radius * 2.0 + mNearPlane);

		// double check that framebuffers are valid
		if (!bgfx::isValid(mDepthFrameBufferHandle[0]))
		{
			deallocateFrameBuffer();
			allocateFrameBuffer();
		}

		if (!bgfx::isValid(mDepthFrameBufferHandle[0]))
		{
			return;
		}

		uint64_t overrideState = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_G | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LESS;

		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainVSMDepth, 0);
		
		//draw the terrain
		bgfx::ViewId viewId;

		viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
		bgfx::touch(viewId);

		bgfx::setViewName(viewId, ("Sun Shadow Depth - Cascade " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(viewId, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(viewId, mSunView, mSunProj);
		bgfx::setViewFrameBuffer(viewId, mDepthFrameBufferHandle[0]);

		shader->setParameter("u_eyePos", mEyePos);
		shader->setParameter("u_NearFarFocus", lgal::gpu::Vector3(float(mNearPlane), float(mFarPlane), 0));

		for (size_t j = 0u; j < tiles.tileIds.size(); j++)
		{
			Tiles::TileId const& tileId = tiles.tileIds[j];

			auto found = readyTiles.find(tileId);
			if (found == readyTiles.end())
				continue; // not ready so dont think we want it casting shadows?
			
			Tiles::TileId& readyId = found->second;

			if (tileId.level < mBiggestLevel - 1 || tileId.level > mSmallestLevel + 1)
				continue;

			bgfx::TextureHandle tex = atlas.getTexHandle(readyId);
			int res = atlas.getResolution();
			shader->setParameter("s_heightTexture", tex, res, res);

			auto sp = shader->parameters["u_tileSize"];
			if (sp != nullptr)
			{
				float size = (float)tileId.extent();
				sp->setValue(lgal::gpu::Vector3(size, size, sp->mVec3.z));
			}

			auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(readyId, tileId);
			auto uvOffset = atlas.getUVOffset(readyId);
			auto combinedOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);

			shader->setParameter("u_ScaleOffsetHeight", combinedOffset);

			auto meshRes = uint16_t(64 >> std::max(0, tileId.level - 17));

			auto tileMin = lgal::world::Vector3(tileId.northwestCorner(), 0) - mEyePos;
			auto tileMax = lgal::world::Vector3(tileId.southeastCorner(), 1) - mEyePos;
			tileMax.z = tileId.extent();

			shader->setParameter("u_tileMin", tileMin);
			shader->setParameter("u_tileMax", tileMax);

			// compute distortions at the min/max of the tile (NOTE: possible name confusion here since the min of the tile will have the most distortion)
			auto minDistortion = MapMath::mercatorDistortion(tileId.northwestCorner());
			auto maxDistortion = MapMath::mercatorDistortion(tileId.southeastCorner());
			shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ (gpu_float_t)minDistortion, (gpu_float_t)maxDistortion, 0.0 });

			Tiles::TileMesh::Instance(meshRes)->draw(tileId, mEyePos, 0.0f, shader->programHandle, viewId, false, overrideState, true);
		}
	}

	void ShadowCascade::blurDepth(float blurAmount)
	{
		if (!bgfx::isValid(mQuadVertsBuffer))
		{
			mQuadVerts[0].m_x = 0;
			mQuadVerts[0].m_y = 1;
			mQuadVerts[0].m_u = 1;
			mQuadVerts[0].m_v = 0;

			mQuadVerts[1].m_x = 1;
			mQuadVerts[1].m_y = 1;
			mQuadVerts[1].m_u = 0;
			mQuadVerts[1].m_v = 0;

			mQuadVerts[2].m_x = 0;
			mQuadVerts[2].m_y = 0;
			mQuadVerts[2].m_u = 1;
			mQuadVerts[2].m_v = 1;

			mQuadVerts[3].m_x = 1;
			mQuadVerts[3].m_y = 1;
			mQuadVerts[3].m_u = 0;
			mQuadVerts[3].m_v = 0;

			mQuadVerts[4].m_x = 1;
			mQuadVerts[4].m_y = 0;
			mQuadVerts[4].m_u = 0;
			mQuadVerts[4].m_v = 1;

			mQuadVerts[5].m_x = 0;
			mQuadVerts[5].m_y = 0;
			mQuadVerts[5].m_u = 1;
			mQuadVerts[5].m_v = 1;

			mQuadVertsBuffer = bgfx::createVertexBuffer(bgfx::makeRef(mQuadVerts, sizeof(Rendering::VertStructs::PosColorUV) * 6), Rendering::VertStructs::PosColorUV::ms_layout);
			
			if (bgfx::getCaps()->originBottomLeft)
			{
				bx::mtxOrtho(mBlurProj, 0.0f, (float)1, 0.0f, (float)-1, 0.01f, 10.0f, 0.0f, false);
			}
			else
			{
				bx::mtxOrtho(mBlurProj, 0.0f, (float)1, (float)-1, 0.0f, 0.01f, 10.0f, 0.0f, false);
			}

			bx::mtxLookAt(mBlurView, bx::Vec3(1, 1, 1), bx::Vec3(1, 1, 0.0), bx::Vec3(0, 1, 0));
		}

		bgfx::ViewId first = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
		bgfx::ViewId second = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
		bgfx::touch(first);
				
		bgfx::setViewName(first, ("Blur X " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(first, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(first, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(first, mBlurView, mBlurProj);
		bgfx::setViewFrameBuffer(first, mDepthFrameBufferHandle[1]);
		uint64_t state = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_G | BGFX_STATE_WRITE_B | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LESS;
		bgfx::setVertexBuffer(0, mQuadVertsBuffer);

		bgfx::setState(state);
				
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::GaussianBlur, 0);
		shader->setParameter("u_tileMin", lgal::gpu::Vector3(0, 0, 0));
		shader->setParameter("u_tileMax", lgal::gpu::Vector3(1, 1, 1));
		shader->setParameter("u_GaussBlurScale", lgal::gpu::Vector3(blurAmount / mShadowRes, 0, 0));

		auto tex = shader->parameters["s_BlurTex"];
		if (tex != nullptr)
		{
			tex->setValue(mDepthTexHandle[0][0], mShadowRes, mShadowRes);
		}
		bgfx::submit(first, shader->programHandle);

		//now blur y
		bgfx::touch(second);
		if (tex != nullptr)
		{
			tex->setValue(mDepthTexHandle[1][0], mShadowRes, mShadowRes);
		}
		shader->setParameter("u_GaussBlurScale", lgal::gpu::Vector3(0, blurAmount / mShadowRes, 0));


		bgfx::setViewName(second, ("Blur Y " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(second, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(second, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(second, mBlurView, mBlurProj);
		bgfx::setViewFrameBuffer(second, mDepthFrameBufferHandle[0]);
		bgfx::setState(state);
		bgfx::setVertexBuffer(0, mQuadVertsBuffer);

		bgfx::submit(second, shader->programHandle);
	}

	void ShadowCascade::allocateFrameBuffer()
	{
		for (int i = 0; i < 2; i++)
		{
			bgfx::TextureFormat::Enum tf = bgfx::TextureFormat::RG32F;

			mDepthTexHandle[i][0] = bgfx::createTexture2D(
				uint16_t(mShadowRes)
				, uint16_t(mShadowRes)
				, false
				, 1
				, tf
				, BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP | BGFX_SAMPLER_W_CLAMP
			);

			bgfx::TextureFormat::Enum depthFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;

			mDepthTexHandle[i][1] = bgfx::createTexture2D(
				uint16_t(mShadowRes)
				, uint16_t(mShadowRes)
				, false
				, 1
				, depthFormat
				, BGFX_TEXTURE_RT_WRITE_ONLY
			);

			if (bgfx::isValid(mDepthTexHandle[i][0]) && bgfx::isValid(mDepthTexHandle[i][1]))
			{
				bgfx::setName(mDepthTexHandle[i][0], "sunShadowColorTex");
				bgfx::setName(mDepthTexHandle[i][1], "sunShadowDepthTex");
				mDepthAttachments[i][0].init(mDepthTexHandle[i][0], bgfx::Access::Write, 0);
				mDepthAttachments[i][1].init(mDepthTexHandle[i][1], bgfx::Access::Write, 0);
				mDepthFrameBufferHandle[i] = bgfx::createFrameBuffer(BX_COUNTOF(mDepthTexHandle[i]), &mDepthAttachments[i][0], true);
			}
		}
	}

}
}
