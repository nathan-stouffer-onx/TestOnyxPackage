#include "SunShadow.h"

#include "Pyramid/UVOffset.h"
#include "Rendering/ViewId.h"
#include "Tiles/TileMesh.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace TerrainEffects {

	ShadowCascade::ShadowCascade(uint16_t res, size_t id) :
		mShadowRes(res),
		mCascadeId(id)
	{
		mDepthFrameBufferHandle[0] = BGFX_INVALID_HANDLE;
		mDepthFrameBufferHandle[1] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[0][0] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[0][1] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[1][0] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[1][1] = BGFX_INVALID_HANDLE;
		mShadowRes = res;
	}

	ShadowCascade::~ShadowCascade()
	{
		if (bgfx::isValid(mQuadVertsBuffer))
		{
			bgfx::destroy(mQuadVertsBuffer);
		}

		deallocateFrameBuffer();
	}

	void ShadowCascade::deallocateFrameBuffer()
	{
		for (int i = 0; i < 2; i++)
		{
			if (bgfx::isValid(mDepthFrameBufferHandle[i]))
			{
				bgfx::destroy(mDepthFrameBufferHandle[i]);
				mDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
			}

			for (int j = 0; j < 2; j++)
			{
				if (bgfx::isValid(mDepthTexHandle[i][j]))
				{
					bgfx::destroy(mDepthTexHandle[i][j]);
					mDepthTexHandle[i][j] = BGFX_INVALID_HANDLE;
				}
			}
		}
	}

	void ShadowCascade::updateDepthBuffer(Shaders::Program& program, lgal::world::Vector3 const& sunDir, Caching::Source const& source, Pyramid::CullResult const& tiles)
	{
		lgal::world::AABB3d terrainBounds;
		terrainBounds.min = lgal::world::Vector3(9999999);
		terrainBounds.max = lgal::world::Vector3(-9999999);

		std::map<Tiles::TileId, Tiles::TileId> readyTiles;

		Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());

		for (const auto& tileId : tiles.tileIds)
		{
			//todo - maybe include the overlapping tiles here?
			if (tileId.level > mSmallestLevel + 1 || tileId.level < mBiggestLevel - 1)
				continue; //not part of this cascade, so ignore it for sizing

			Tiles::TileId readyId = tileId.moduloX();
			bool found = false;
			while (!found && readyId.level >= 0)
			{
				if (atlas.isReady(readyId))
				{
					found = true;
					readyTiles[tileId] = readyId;

					lgal::world::AABB2d planarBounds = tileId.worldBounds<world_float_t>();
					lgal::globe::Range zBounds = atlas.extents(tileId, true);
					lgal::world::AABB3d bounds({ planarBounds.min, zBounds.begin }, { planarBounds.max, zBounds.end });
					terrainBounds = lmath::fit(terrainBounds, bounds);
				}
				else if (readyId == Tiles::TileId::Root())
				{
					break;
				}
				else
				{
					readyId = readyId.parent();
				}
			}
		}

		bx::mtxLookAt(mSunView.data(), {0, 0, 0}, BgfxUtils::toBx(-sunDir), BgfxUtils::toBx(lgal::world::Vector3(0, 1, 0)));

		// make sure our min and max are still mins and maxes after we spun it around
		auto minBounds = terrainBounds.min;
		auto maxBounds = terrainBounds.max;

		auto center = 0.5 * (minBounds + maxBounds);
		world_float_t radius = lmath::len(maxBounds - center);
		world_float_t farPlane = radius * 2.5 + mNearPlane;

		float left   = static_cast<float>(-radius);
		float right  = static_cast<float>( radius);
		float top    = static_cast<float>( radius);
		float bottom = static_cast<float>(-radius);
		mFarPlane = farPlane;//radius * 2.0;
		bx::mtxOrtho(mSunProj.data(), left, right, bottom, top, static_cast<float>(mNearPlane), static_cast<float>(mFarPlane), 0.0f, bgfx::getCaps()->homogeneousDepth);

		mEyePos = center + sunDir * (radius * 2.0 + mNearPlane);

		// double check that framebuffers are valid
		if (!bgfx::isValid(mDepthFrameBufferHandle[0]))
		{
			deallocateFrameBuffer();
			allocateFrameBuffer();
		}

		if (!bgfx::isValid(mDepthFrameBufferHandle[0]))
		{
			return;
		}

		bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
		bgfx::touch(viewId);

		bgfx::setViewName(viewId, ("Sun Shadow Depth - Cascade " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(viewId, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(viewId, mSunView.data(), mSunProj.data());
		bgfx::setViewFrameBuffer(viewId, mDepthFrameBufferHandle[0]);

		Styling::RasterDemSource const& specification = static_cast<Styling::RasterDemSource const&>(*source.specification());

		for (size_t j = 0u; j < tiles.tileIds.size(); j++)
		{
			Tiles::TileId const& tileId = tiles.tileIds[j];

			auto found = readyTiles.find(tileId);
			if (found == readyTiles.end())
				continue; // not ready so dont think we want it casting shadows?
			
			Tiles::TileId& readyId = found->second;

			if (tileId.level < mBiggestLevel - 1 || tileId.level > mSmallestLevel + 1)
				continue;

			bgfx::TextureHandle tex = atlas.getTexHandle(readyId);
			int res = atlas.getResolution();
			program.set("s_Terrain", tex, lgal::screen::Vector2(res), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);

			auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(readyId, tileId);
			auto uvOffset = atlas.getUVOffset(readyId);
			auto combinedUVOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);
			program.set("u_ScaleOffsetTerrain", combinedUVOffset);

			// compute distortions at the min/max of the tile (NOTE: possible name confusion here since the min of the tile will have the most distortion in the northern hemisphere)
			auto meshRes = MapMath::meshResolution(specification.tileSize, specification.maxZoom, tileId);
			auto minDistortion = MapMath::mercatorDistortion(tileId.northwestCorner());
			auto maxDistortion = MapMath::mercatorDistortion(tileId.southeastCorner());
			program.set("u_PackedTerrainParams", lgal::world::Vector4{ minDistortion, maxDistortion, 1.0, static_cast<world_float_t>(meshRes) });

			program.set("u_TileMin", lgal::world::Vector3{ tileId.northwestCorner(), 0.0 } - mEyePos);
			program.set("u_TileMax", lgal::world::Vector3{ tileId.southeastCorner(), 0.0 } - mEyePos);

			program.set("u_PackedParams", lgal::world::Vector4(tileId.extent(), mFarPlane, 0, 0));

			uint64_t state = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_G | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | static_cast<uint64_t>(Styling::DepthTest::LESS);
			Tiles::TileMesh::Instance(meshRes)->render(viewId, program.handle(), tileId, mEyePos, 0.0f, state, true);
		}
	}

	void ShadowCascade::blurDepth(Shaders::Program& program, float blurAmount)
	{
		if (!bgfx::isValid(mQuadVertsBuffer))
		{
			mQuadVerts[0].m_x = 0;
			mQuadVerts[0].m_y = 1;
			mQuadVerts[0].m_u = 1;
			mQuadVerts[0].m_v = 0;

			mQuadVerts[1].m_x = 1;
			mQuadVerts[1].m_y = 1;
			mQuadVerts[1].m_u = 0;
			mQuadVerts[1].m_v = 0;

			mQuadVerts[2].m_x = 0;
			mQuadVerts[2].m_y = 0;
			mQuadVerts[2].m_u = 1;
			mQuadVerts[2].m_v = 1;

			mQuadVerts[3].m_x = 1;
			mQuadVerts[3].m_y = 1;
			mQuadVerts[3].m_u = 0;
			mQuadVerts[3].m_v = 0;

			mQuadVerts[4].m_x = 1;
			mQuadVerts[4].m_y = 0;
			mQuadVerts[4].m_u = 0;
			mQuadVerts[4].m_v = 1;

			mQuadVerts[5].m_x = 0;
			mQuadVerts[5].m_y = 0;
			mQuadVerts[5].m_u = 1;
			mQuadVerts[5].m_v = 1;

			mQuadVertsBuffer = bgfx::createVertexBuffer(bgfx::copy(mQuadVerts, sizeof(Rendering::VertStructs::PosColorUV) * 6), Rendering::VertStructs::PosColorUV::ms_layout);

			if (bgfx::getCaps()->originBottomLeft)
			{
				bx::mtxOrtho(mBlurProj, 0.0f, (float)1, 0.0f, (float)-1, 0.01f, 10.0f, 0.0f, false);
			}
			else
			{
				bx::mtxOrtho(mBlurProj, 0.0f, (float)1, (float)-1, 0.0f, 0.01f, 10.0f, 0.0f, false);
			}

			bx::mtxLookAt(mBlurView, bx::Vec3(1, 1, 1), bx::Vec3(1, 1, 0.0), bx::Vec3(0, 1, 0));
		}

		// blur x
		{
			bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
			bgfx::touch(viewId);
			bgfx::setViewName(viewId, ("Blur X " + std::to_string(mCascadeId)).c_str());
			bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
			bgfx::setViewRect(viewId, 0, 0, mShadowRes, mShadowRes);

			bgfx::setViewTransform(viewId, mBlurView, mBlurProj);
			bgfx::setViewFrameBuffer(viewId, mDepthFrameBufferHandle[1]);
			bgfx::setVertexBuffer(0, mQuadVertsBuffer);

			uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LEQUAL;
			bgfx::setState(state);

			program.set("u_Corners", lgal::gpu::Vector4(0, 0, 1, 1));
			program.set("u_GaussianBlurScale", lgal::gpu::Vector2(blurAmount / mShadowRes, 0));

			program.set("s_Input", mDepthTexHandle[0][0], lgal::screen::Vector2(mShadowRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
			bgfx::submit(viewId, program.handle());
		}

		// blur y
		{
			bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
			bgfx::touch(viewId);
			bgfx::setViewName(viewId, ("Blur Y " + std::to_string(mCascadeId)).c_str());
			bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
			bgfx::setViewRect(viewId, 0, 0, mShadowRes, mShadowRes);

			bgfx::setViewTransform(viewId, mBlurView, mBlurProj);
			bgfx::setViewFrameBuffer(viewId, mDepthFrameBufferHandle[0]);
			bgfx::setVertexBuffer(0, mQuadVertsBuffer);

			uint64_t state = BGFX_STATE_WRITE_RGB | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LEQUAL;
			bgfx::setState(state);

			program.set("u_Corners", lgal::gpu::Vector4(0, 0, 1, 1));
			program.set("u_GaussianBlurScale", lgal::gpu::Vector2(0, blurAmount / mShadowRes));

			program.set("s_Input", mDepthTexHandle[1][0], lgal::screen::Vector2(mShadowRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
			bgfx::submit(viewId, program.handle());
		}
	}

	void ShadowCascade::allocateFrameBuffer()
	{
		for (int i = 0; i < 2; i++)
		{
			bgfx::TextureFormat::Enum tf = bgfx::TextureFormat::RG32F;

			mDepthTexHandle[i][0] = bgfx::createTexture2D(
				uint16_t(mShadowRes)
				, uint16_t(mShadowRes)
				, false
				, 1
				, tf
				, BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP | BGFX_SAMPLER_W_CLAMP
			);

			bgfx::TextureFormat::Enum depthFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;

			mDepthTexHandle[i][1] = bgfx::createTexture2D(
				uint16_t(mShadowRes)
				, uint16_t(mShadowRes)
				, false
				, 1
				, depthFormat
				, BGFX_TEXTURE_RT_WRITE_ONLY
			);

			if (bgfx::isValid(mDepthTexHandle[i][0]) && bgfx::isValid(mDepthTexHandle[i][1]))
			{
				bgfx::setName(mDepthTexHandle[i][0], "sunShadowColorTex");
				bgfx::setName(mDepthTexHandle[i][1], "sunShadowDepthTex");
				mDepthAttachments[i][0].init(mDepthTexHandle[i][0], bgfx::Access::Write, 0);
				mDepthAttachments[i][1].init(mDepthTexHandle[i][1], bgfx::Access::Write, 0);
				mDepthFrameBufferHandle[i] = bgfx::createFrameBuffer(BX_COUNTOF(mDepthTexHandle[i]), &mDepthAttachments[i][0], true);
			}
		}
	}

}
}
