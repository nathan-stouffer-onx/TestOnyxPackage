#include "ContourLine.h"

namespace onyx::TerrainEffects
{

	ContourLine::ContourLine() {}

	void ContourLine::update(Styling::ContourLineConfig const& config, size_t i, Args const&)
	{
		mConfig = config;
		mIndex = std::to_string(i);
	}

	void ContourLine::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("u_ContourFade", mConfig.fadeRange);

		gpu_float_t toKM = Styling::ContourConfig::toKm(mConfig.contours.units);
		gpu_float_t period = mConfig.contours.period * toKM;
		gpu_float_t min = mConfig.contours.min * toKM;
		gpu_float_t max = mConfig.contours.max * toKM;
		shader.setParameter("u_ContourParams" + mIndex, lgal::gpu::Vector4(period, min, max, mConfig.width));
		shader.setParameter("u_ContourColor" + mIndex, lgal::Color::FromABGR(mConfig.abgr));
	}

}