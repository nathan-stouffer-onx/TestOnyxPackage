#include "ContourLine.h"

#include <Caching/Tiles/TileCache.h>

namespace onyx::TerrainEffects
{

	ContourLine::ContourLine() {}

	bool ContourLine::prepare(Args const& args)
	{
		Styling::ContourLineLayer const& layer = static_cast<Styling::ContourLineLayer const&>(args.layer);
		Styling::ContourLineConfig config = args.horizon.convert(layer.realize(args.layerArgs), args.filteredZoomKm);
		mConfig = config;

		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		return TerrainEffectBase::Prepare(mTerrainParams, source, args.onscreen.tileIds);
	}

	void ContourLine::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::AtlasInfo const& info = mTerrainParams.at(tileId);
		program.set("s_ContourDem", info.handle, lgal::screen::Vector2(info.resolution), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_ScaleOffsetContourDem", info.offset);

		program.set("u_ContourColor", lgal::Color::FromABGR(mConfig.abgr));
		program.set("u_ContourFade", mConfig.fadeRange);

		gpu_float_t toKM = Styling::ContourConfig::toKm(mConfig.contours.units);
		gpu_float_t period = mConfig.contours.period * toKM;
		gpu_float_t min = mConfig.contours.min * toKM;
		gpu_float_t max = mConfig.contours.max * toKM;
		program.set("u_ContourParams", lgal::gpu::Vector4(period, min, max, mConfig.width));
	}

}