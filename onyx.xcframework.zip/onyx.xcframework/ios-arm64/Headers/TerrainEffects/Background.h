#pragma once

#include <Styling/Styles/BackgroundStyle.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class Background final : public TerrainEffectBase
	{
	public:

		Background() = default;
		~Background() = default;

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;
		
		uint64_t state() const override { return static_cast<uint64_t>(mStyle.blendMode); }

	private:

		Styling::BackgroundStyle mStyle;
		lgal::world::Vector2 mDiff;
		float mZoom;
		std::shared_ptr<Spritesheet const> mSpritesheet;
		std::shared_ptr<Spritesheet::ImageAtlas const> mAtlas;

	};

}