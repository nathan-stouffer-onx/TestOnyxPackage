#include "SunShadow.h"

#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>

#include "Caching/Tiles/TileCache.h"
#include "Pyramid/UVOffset.h"
#include "Rendering/ViewId.h"
#include "Tiles/TileMesh.h"
#include "Utils/MapMath.h"

namespace onyx::TerrainEffects
{

	static constexpr world_float_t cSunAmbient = 0.3;
	static constexpr world_float_t cShadowStrength = 0.25;
	static constexpr world_float_t cShadowFadeStart = 225.0;
	static constexpr world_float_t cShadowFadeEnd = 275.0;

	SunShadow::SunShadow() :
		  mDistanceProgram(Shaders::load(Shaders::TiledEncodings::Options{ Shaders::TiledEncodings::EncodedTypes::DISTANCE, true }))
		, mGaussianBlurProgram(Shaders::load(Shaders::Handwritten::cGaussianBlur, false))
		, mSunAmbient(cSunAmbient)
		, mShadowStrength(cShadowStrength)
		, mShadowFadeStart(cShadowFadeStart)
		, mShadowFadeEnd(cShadowFadeEnd)
		, mPosition(0, 0, 0)
		, mTargetPos(0, 0, 0)
		, mIsDirty(true)
	{
		for (size_t i = 0; i < cNumCascades; ++i)
		{
			mCascades[i] = std::make_unique<ShadowCascade>(mShadowRes, i);
		}
	}

	SunShadow::~SunShadow() {}

	bool SunShadow::prepare(Args const& args)
	{
		Styling::SunlightLayer const& layer = static_cast<Styling::SunlightLayer const&>(args.layer);
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		Styling::SunlightConfig config = layer.realize(args.layerArgs);

		mSunTimeDate = JulianDate(config);
		mCameraState = args.camera;
		JulianDate julian = mSunTimeDate;
		lgal::world::Vector2 elevationPitch = calculateSunDir(julian.getJulianCentury(), julian.hours24);
		lgal::world::Vector2 pos = args.camera.position.xy;
		Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());
		setPosDir({ pos, atlas.heightAt(pos)}, elevationPitch.x, elevationPitch.y);

		Pyramid::CullResult const& tiles = args.onscreen;
		// calculate our cascade level ranges
		int levelCount = tiles.maxLevel - tiles.minLevel;
		int firstCascade = levelCount > 4 ? 1 : 0;
		mCascades[0]->setBiggestLevel(tiles.maxLevel - firstCascade);
		mCascades[0]->setSmallestLevel(tiles.maxLevel);
		int levelStep = (levelCount - firstCascade) / (mCascades.size() <= 1 ? 1 : ((int)mCascades.size() - 1));
		for (size_t i = 1; i < mCascades.size(); i++)
		{
			mCascades[i]->setBiggestLevel(mCascades[i - 1]->getBiggestLevel() - 1 - levelStep);
			mCascades[i]->setSmallestLevel(mCascades[i - 1]->getBiggestLevel() - 1);
		}
		mCascades[mCascades.size() - 1]->setBiggestLevel(tiles.minLevel);

		for (size_t i = 0; i < mCascades.size(); i++)
		{
			mCascades[i]->updateDepthBuffer(mDistanceProgram, mLocalSunDir, source, tiles);
			mCascades[i]->blurDepth(mGaussianBlurProgram, (float)mVSMParams.z);
		}

		setIsDirty(false);
		return true;
	}

	void SunShadow::setPosDir(lgal::world::Vector3 const& pos, world_float_t elevation, world_float_t azimuth)
	{
		mTargetPos = pos;

		//convert from sun direction to local vector angle
		lgal::world::Vector3 dir;
		dir.z = std::cos(elevation) * std::cos(azimuth);
		dir.y = std::cos(elevation) * std::sin(azimuth);
		dir.x = std::sin(elevation);

		world_float_t latitude = MapMath::YToLat(pos.y);
		world_float_t longitude = MapMath::XToLon(pos.x);
		lgal::world::Vector3 planetNormal;

		planetNormal.x = std::cos(lmath::degreesToRadians(latitude)) * std::cos(lmath::degreesToRadians(longitude));
		planetNormal.y = std::cos(lmath::degreesToRadians(latitude)) * std::sin(lmath::degreesToRadians(longitude));
		planetNormal.z = std::sin(lmath::degreesToRadians(latitude));

		lgal::world::Vector3 tangent;
		lgal::world::Vector3 binormal;

		tangent = lmath::cross(planetNormal, lgal::world::Vector3(1.0, 0.0, 0.0));
		tangent = lmath::normalize(tangent);

		binormal = lmath::cross(planetNormal, tangent);
		binormal = lmath::normalize(binormal);

		lgal::world::Vector3 tangentSun;
		tangentSun.x = -lmath::dot(tangent, dir);
		tangentSun.y = -lmath::dot(binormal, dir);
		tangentSun.z = lmath::dot(planetNormal, dir);

		lgal::world::Vector3 test;
		test.x = lmath::dot(tangent, planetNormal);
		test.y = lmath::dot(binormal, planetNormal);
		test.z = lmath::dot(planetNormal, planetNormal);

		//distance seems irrelevant now that ortho is properly calculated to fit the scene?
		world_float_t distance = 300.0;

		//TODO - check that these vectors are in the right order
		mLocalSunDir = tangentSun;// lmath::normalize(mTargetPos - mPosition);
		mPosition = mTargetPos + mLocalSunDir * distance;

		//mRenderCameraState.position = mPosition;

		//find up
		mViewUp = lmath::cross(mLocalSunDir, tangent);

		world_float_t heading = lmath::atan2(mLocalSunDir.y, mLocalSunDir.x);
		world_float_t pitch = lmath::acos(mLocalSunDir.z / lmath::sqrt(lmath::dot(mLocalSunDir, mLocalSunDir)));
		mRenderCameraState.heading = heading;
		mRenderCameraState.pitch = pitch;
		mRenderCameraState.fov = 45;
		mRenderCameraState.position = mPosition;
		mRenderCameraState.aspect = 1;
	}

	lgal::world::Vector2 SunShadow::calculateSunDir(world_float_t julianCentury, world_float_t localTime)
	{
		//we want a sun angle relative to the globe not a pixel, so set lat and lon to 0 when doing the sun angle calculations

		world_float_t PI = lmath::constants::pi<world_float_t>();

		world_float_t geomMeanLongSunDeg = std::fmod((280.46646 + julianCentury * (36000.76983 + julianCentury * 0.0003032)), 360.0);
		world_float_t geomMeanAnomSunDeg = 357.52911 + julianCentury * (35999.05029 - 0.0001537 * julianCentury);
		world_float_t eccentEarthOrbit = 0.016708634 - julianCentury * (0.000042037 + 0.0000001267 * julianCentury);
		world_float_t sunEqofCtr = sin(geomMeanAnomSunDeg * PI / 180.0) * (1.914602 - julianCentury * (0.004817 + 0.000014 * julianCentury)) + sin(2.0 * geomMeanAnomSunDeg * PI / 180.0) * (0.019993 - 0.000101 * julianCentury) + sin(PI / 180.0 * 3.0 * geomMeanAnomSunDeg) * 0.000289;

		world_float_t sunTrueLongDeg = geomMeanLongSunDeg + sunEqofCtr;
		world_float_t sunAppLongDeg = sunTrueLongDeg - 0.00569 - 0.00478 * sin((125.04 - 1934.136 * julianCentury) * PI / 180.0);
		world_float_t sunDeclinDeg = 180.0 / PI * asin(0.397767f * sin(sunAppLongDeg * PI / 180.0));

		world_float_t varY = 0.043031;

		world_float_t eqOfTimeMinutes = 4.0 * 180.0 / PI * (varY * sin(2.0 * PI / 180.0 * geomMeanLongSunDeg) - 2.0 * eccentEarthOrbit * sin(geomMeanAnomSunDeg * PI / 180.0) + 4.0 * eccentEarthOrbit * varY * sin(PI / 180.0 * geomMeanAnomSunDeg) * cos(2.0 * geomMeanLongSunDeg * PI / 180.0) - 0.5 * varY * varY * sin(4.0 * geomMeanLongSunDeg * PI / 180.0) - 1.25 * eccentEarthOrbit * eccentEarthOrbit * sin(2.0 * PI / 180.0 * geomMeanAnomSunDeg));

		world_float_t trueSolarTimeMinutes = std::fmod(((localTime / 24.0) * 1440.0 + eqOfTimeMinutes), 1440.0);
		world_float_t hourAngleDeg = trueSolarTimeMinutes / 4.0 < 0.0 ? trueSolarTimeMinutes / 4.0 + 180.0 : trueSolarTimeMinutes / 4.0 - 180.0;
		world_float_t solarZenithAngleDeg = 180.0 / PI * (acos(cos(sunDeclinDeg * PI / 180.0) * cos(hourAngleDeg * PI / 180.0)));
		world_float_t solarElevationAngleDeg = 90.0 - solarZenithAngleDeg;

		world_float_t solarAzimuthAngleDeg = 0.0;
		world_float_t offset = 0.0;
		world_float_t offsetSign = 1.0;
		world_float_t flip = 180.0;
		if (hourAngleDeg <= 0.0)
		{
			offset = 540.0;
			offsetSign = -1.0;
			flip = 0.0;
		}

		world_float_t inner = offset + offsetSign * 180.0 / PI * acos(-sin(PI / 180.0 * sunDeclinDeg) / sin(PI / 180.0 * solarZenithAngleDeg)) + flip;
		solarAzimuthAngleDeg = std::fmod(inner, 360.0);

		return { solarElevationAngleDeg * PI / 180.0, solarAzimuthAngleDeg * PI / 180.0 };
	}

	bgfx::TextureHandle SunShadow::getDepthHandle(int tileLevel) const
	{
		return mCascades[levelToCascade(tileLevel)]->getDepthTexHandle();
	}

	void SunShadow::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		float jc = (float)mSunTimeDate.getJulianCentury();
		program.set("u_SunTimeData", lgal::gpu::Vector3(jc, mSunTimeDate.hours24 / 24.0f, 0.0f));
		program.set("u_SunAmbient", mSunAmbient);
			
		program.set("u_SunTileMin", lgal::world::Vector3(Tiles::TileId::Root().toUVCoords<world_float_t>(tileId.northwestCorner(), Tiles::TileId::Origin::TOP_LEFT), 0));
		program.set("u_SunTileMax", lgal::world::Vector3(Tiles::TileId::Root().toUVCoords<world_float_t>(tileId.southeastCorner(), Tiles::TileId::Origin::TOP_LEFT), 0));

		//fade out from 225 to 275 camera above ground
		auto shadowFade = 1.0 - std::min(std::max(mCameraState.position.z - mShadowFadeStart, 0.0) / mShadowFadeEnd, 1.0);
		program.set("u_SunShadowFarPlane", getFarPlane(tileId.level));
		program.set("u_SunShadowBias", getBias());
		program.set("u_SunShadowStrength", mShadowStrength * shadowFade);
		program.set("u_SunShadowView", getSunView(tileId.level));
		program.set("u_SunShadowProj", getSunProj(tileId.level));
		program.set("s_SunShadowDistance", getDepthHandle(tileId.level), lgal::screen::Vector2(mShadowRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);

		auto shadowTileMin = lgal::world::Vector3(tileId.northwestCorner(), 0) - getEyePos(tileId.level);
		auto shadowTileMax = lgal::world::Vector3(tileId.southeastCorner(), 0) - getEyePos(tileId.level);
		program.set("u_SunShadowTileMin", shadowTileMin);
		program.set("u_SunShadowTileMax", shadowTileMax);
		program.set("u_SunShadowVSMParams", getVSMParams());
	
		if (mDebugMode)
			program.set("u_CascadeDebug", 1.0);
	}

	void SunShadow::setTimeDate(JulianDate jd)
	{
		if(mSunTimeDate != jd)
			setIsDirty(true);

		mSunTimeDate = jd; 
	}

	void SunShadow::setDebugMode(bool on)
	{
		mDebugMode = on;
		for (size_t i = 0; i < mCascades.size(); i++)
		{
			mCascades[i]->setDebugMode(mDebugMode);
		}
	}

}