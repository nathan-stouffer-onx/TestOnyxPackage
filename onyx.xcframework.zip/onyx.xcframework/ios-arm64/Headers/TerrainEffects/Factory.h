#pragma once

#include <memory>

#include <Styling/Layers/Layer.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

    std::unique_ptr<TerrainEffectBase> construct(Styling::Layer::Types const type);

}