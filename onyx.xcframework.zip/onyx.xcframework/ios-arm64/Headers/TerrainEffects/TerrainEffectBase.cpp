#include "TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	bool TerrainEffectBase::Prepare(DemParamsMapT& params, Caching::Source const& source, std::vector<Tiles::TileId> const& tiles)
	{
		Styling::RasterDemSource const& specification = static_cast<Styling::RasterDemSource const&>(*source.specification());
		Atlases::TileAtlas const& atlas = *source.atlas();

		params.clear();
		params.reserve(tiles.size());

		// compute render info
		bool complete = true;	// assume complete until proven otherwise
		for (Tiles::TileId const& tileId : tiles)
		{
			Tiles::TileId modulo = tileId.moduloX();
			Tiles::AtlasInfo info = Tiles::AtlasInfo::Compute(atlas, modulo, specification.range());

			bool missing = info.handle.idx == atlas.getMissingTileHandle().idx;
			complete &= !missing && (info.level == std::min(tileId.level, specification.range().end));

			params[tileId] = info;
		}
		return complete;
	}

}