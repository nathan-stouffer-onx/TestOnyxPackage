#pragma once

#include <unordered_map>

#include <Styling/Styles/RasterStyle.h>

#include "TerrainEffects/TerrainEffectBase.h"
#include "Tiles/TileId.h"
#include "Tiles/TileRenderInfo.h"

namespace onyx::TerrainEffects
{

	class Raster final : public TerrainEffectBase
	{
	public:

		Raster() = default;
		~Raster() = default;

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;
		
		uint64_t state() const override { return static_cast<uint64_t>(mStyle.blendMode); }

	private:

		Styling::RasterStyle mStyle;

		std::unordered_map<Tiles::TileId, Tiles::PseudoRasterInfo> mInfo;

	};

}