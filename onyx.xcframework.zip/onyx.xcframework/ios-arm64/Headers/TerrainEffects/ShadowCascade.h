#pragma once

#include <array>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/Program.h>

#include "Pyramid/Culling.h"
#include "Atlases/TileAtlas.h"
#include "Camera/CameraState.h"
#include "Rendering/VertStructs.h"
#include "TerrainEffects/TerrainEffectBase.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/JulianDate.h"
#include "Utils/MapMath.h"
#include "Utils/property.h"

namespace onyx::TerrainEffects
{

	// texture for directional sunlight shadow
	class ShadowCascade
	{
	public:

		ShadowCascade(uint16_t res, size_t id);
		~ShadowCascade();

		GET_SET_PROP(BiggestLevel, int, 0);
		GET_SET_PROP(SmallestLevel, int, 25);
		GET_SET_PROP(EyePos, lgal::world::Vector3, lgal::world::Vector3(0));
		GET_SET_PROP(NearPlane, world_float_t, 0.1);
		GET_SET_PROP(FarPlane, world_float_t, 1000.0);
		GET_SET_PROP(DebugMode, bool, false);
		bgfx::TextureHandle getDepthTexHandle() { return mDepthTexHandle[0][0]; }
		
		void updateDepthBuffer(Shaders::Program& program, lgal::world::Vector3 const& sunDir, Caching::Source const& source, Pyramid::CullResult const& tiles);
		void blurDepth(Shaders::Program& program, float blurAmount);

		std::array<float, 16> const& getSunProj() { return mSunProj; }
		std::array<float, 16> const& getSunView() { return mSunView; }
		void propertyChanged(const char* /* propName */) { }

	private:

		bgfx::VertexBufferHandle mQuadVertsBuffer = BGFX_INVALID_HANDLE;
		float mBlurProj[16];
		float mBlurView[16];
		Rendering::VertStructs::PosColorUV mQuadVerts[6];

		uint16_t mShadowRes;
		size_t mCascadeId;

		bgfx::TextureHandle mDepthTexHandle[2][2]; //second is to give us a flip to target for the blur
		bgfx::FrameBufferHandle mDepthFrameBufferHandle[2];
		bgfx::Attachment mDepthAttachments[2][2];
		std::array<float, 16> mSunProj;
		std::array<float, 16> mSunView;
		
		void allocateFrameBuffer();
		void deallocateFrameBuffer();
	};

}