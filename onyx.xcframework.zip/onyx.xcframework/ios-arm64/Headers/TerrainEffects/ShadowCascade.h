#ifndef _SHADOWCASCADE_H_
#define _SHADOWCASCADE_H_

#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ShaderDefinition.h>

#include "Pyramid/Culling.h"
#include "Utils/MapMath.h"
#include "Atlases/TileAtlas.h"
#include "Camera/CameraState.h"
#include "Tiles/TileRenderInfo.h"
#include "Rendering/VertStructs.h"
#include "Utils/EnumsStructs.h"
#include "Utils/property.h"

//#define CASCADE_DEBUG 1 //when set to 1, splat the full color result from the sun position rather than shadows, so we can check alignment
namespace onyx {
	class ViewportState;
namespace TerrainEffects {

	// texture for directional sunlight shadow
	class ShadowCascade
	{
	public:

		ShadowCascade(uint16_t res, int id);
		~ShadowCascade();

		GET_SET_PROP(BiggestLevel, int, 0);
		GET_SET_PROP(SmallestLevel, int, 25);
		GET_SET_PROP(EyePos, lgal::world::Vector3, lgal::world::Vector3(0));
		GET_SET_PROP(NearPlane, world_float_t, 0.1);
		GET_SET_PROP(FarPlane, world_float_t, 1000.0);
		GET_SET_PROP(DebugMode, bool, false);
		bgfx::TextureHandle getDepthTexHandle() { return mDepthTexHandle[0][0]; }
		
		void updateDepthBuffer(ViewportState* vs, lgal::world::Vector3 sunDir);
		void blurDepth(float blurAmount);

		float* getSunProj() { return &mSunProj[0]; }
		float* getSunView() { return &mSunView[0]; }
		void propertyChanged(const char* /* propName */) { }

	private:
		bgfx::VertexBufferHandle mQuadVertsBuffer = BGFX_INVALID_HANDLE;
		float mBlurProj[16];
		float mBlurView[16];
		Rendering::VertStructs::PosColorUV mQuadVerts[6];

		uint16_t mShadowRes = 4096;
		int mCascadeId = -1;
		bgfx::TextureHandle mDepthTexHandle[2][2]; //second is to give us a flip to target for the blur
		bgfx::FrameBufferHandle mDepthFrameBufferHandle[2];
		bgfx::Attachment mDepthAttachments[2][2];
		float mSunProj[16];
		float mSunView[16];
		
		void allocateFrameBuffer();
		void deallocateFrameBuffer();
	};

} }

#endif //_SUNSHADOW_H_