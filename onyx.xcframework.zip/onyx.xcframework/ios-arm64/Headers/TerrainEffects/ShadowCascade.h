#pragma once

#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ShaderDefinition.h>
#include <Shaders/v2/Program.h>

#include "Pyramid/Culling.h"
#include "Atlases/TileAtlas.h"
#include "Camera/CameraState.h"
#include "Rendering/VertStructs.h"
#include "TerrainEffects/TerrainEffectBase.h"
#include "Tiles/TileRenderInfo.h"
#include "Utils/EnumsStructs.h"
#include "Utils/MapMath.h"
#include "Utils/property.h"

namespace onyx::TerrainEffects
{

	// texture for directional sunlight shadow
	class ShadowCascade
	{
	public:

		ShadowCascade(uint16_t res, size_t id);
		~ShadowCascade();

		GET_SET_PROP(BiggestLevel, int, 0);
		GET_SET_PROP(SmallestLevel, int, 25);
		GET_SET_PROP(EyePos, lgal::world::Vector3, lgal::world::Vector3(0));
		GET_SET_PROP(NearPlane, world_float_t, 0.1);
		GET_SET_PROP(FarPlane, world_float_t, 1000.0);
		GET_SET_PROP(DebugMode, bool, false);
		bgfx::TextureHandle getDepthTexHandle() { return mDepthTexHandle[0][0]; }
		
		void updateDepthBuffer(Shaders::Program& program, lgal::world::Vector3 const& sunDir, Pyramid::CullResult const& tiles, TerrainEffectBase::Args const& args);
		void blurDepth(Shaders::Program& program, float blurAmount);

		float* getSunProj() { return &mSunProj[0]; }
		float* getSunView() { return &mSunView[0]; }
		void propertyChanged(const char* /* propName */) { }

	private:

		bgfx::VertexBufferHandle mQuadVertsBuffer = BGFX_INVALID_HANDLE;
		float mBlurProj[16];
		float mBlurView[16];
		Rendering::VertStructs::PosColorUV mQuadVerts[6];

		uint16_t mShadowRes;
		size_t mCascadeId;

		bgfx::TextureHandle mDepthTexHandle[2][2]; //second is to give us a flip to target for the blur
		bgfx::FrameBufferHandle mDepthFrameBufferHandle[2];
		bgfx::Attachment mDepthAttachments[2][2];
		float mSunProj[16];
		float mSunView[16];
		
		void allocateFrameBuffer();
		void deallocateFrameBuffer();
	};

}