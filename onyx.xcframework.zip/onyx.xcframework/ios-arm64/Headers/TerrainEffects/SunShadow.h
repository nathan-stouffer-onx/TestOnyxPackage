#ifndef _SUNSHADOW_H_
#define _SUNSHADOW_H_

#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ShaderDefinition.h>
#include <Styling/Styles/ShadowConfigs.h>

#include "Atlases/HeightAtlas.h"
#include "Camera/CameraState.h"
#include "Pyramid/Culling.h"
#include "Rendering/VertStructs.h"
#include "ShadowCascade.h"
#include "Tiles/TileRenderInfo.h"
#include "TerrainEffects/TerrainEffectBase.h"
#include "Utils/EnumsStructs.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace TerrainEffects {

	class SunShadow : public TerrainEffectBase
	{
	public:

		SunShadow();
		~SunShadow();

		void update(Styling::SunlightConfig const& config, Pyramid::CullResult const& tiles, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

		void setPosDir(lgal::world::Vector3 const& pos, world_float_t elevation, world_float_t azimuth);
		
		bool isDirty() { return mIsDirty; }
		void setIsDirty(bool dirty) { mIsDirty = dirty; }
			
		inline world_float_t getFarPlane(int tileLevel) const { return mCascades[levelToCascade(tileLevel)]->getFarPlane(); }
		inline world_float_t getNearPlane(int tileLevel) const { return mCascades[levelToCascade(tileLevel)]->getNearPlane(); }
		inline float* getSunView(int tileLevel) const { return mCascades[levelToCascade(tileLevel)]->getSunView(); }
		inline float* getSunProj(int tileLevel) const { return mCascades[levelToCascade(tileLevel)]->getSunProj(); }
		inline lgal::world::Vector3 getEyePos(int tileLevel) const { return mCascades[levelToCascade(tileLevel)]->getEyePos(); }

		uint16_t resolution() const { return mShadowRes; }

		bgfx::TextureHandle getDepthHandle(int tileLevel) const;
		bgfx::TextureHandle getDepthHandleByCascade(int cascade) const { return mCascades[cascade]->getDepthTexHandle(); }	
		
		size_t getCascadeCount() const { return mCascades.size(); }
		lgal::world::Vector3 getVSMParams() const { return mVSMParams; }
		void setVSMParams(lgal::world::Vector3 v) 
		{ 
			if (mVSMParams != v)
			{
				mVSMParams = v;
				mIsDirty = true;
			}
		}
		float getBias() const { return mShadowBias; }
		void setBias(float b) { mShadowBias = b; }
		JulianDate getTimeDate() const { return JulianDate(mConfig); }
		void setTimeDate(JulianDate jd);
		void setDebugMode(bool on);

	private:

		Styling::SunlightConfig mConfig;

		JulianDate mSunTimeDate;
		Camera::CameraState mCameraState;

		uint16_t const mShadowRes = 2048;

		world_float_t mSunMinStrength;
		world_float_t mSunAmbient;
		world_float_t mShadowStrength;
		world_float_t mShadowFadeStart;
		world_float_t mShadowFadeEnd;

		lgal::world::Vector3 mPosition;
		lgal::world::Vector3 mTargetPos;
		lgal::world::Vector3 mViewUp;
		lgal::world::Vector3 mLocalSunDir;
		Camera::CameraState mRenderCameraState;

		bool mIsDirty;

		Pyramid::CullResult mCullState;

		// TODO possibly change this from a pointer?
		std::vector<ShadowCascade*> mCascades; //idx 0 should be with the smallest tiles (highest level #), next with the next bigger range, etc

		//returns elevation and pitch
		lgal::world::Vector2 calculateSunDir(world_float_t julianCentury, world_float_t localTime);

		float mShadowBias = 0;

		lgal::world::Vector3 mVSMParams = lgal::world::Vector3(0.00002, 0.8, 1.0);//minVariance, lightBleed, blurAmount

		bool mDebugMode = false;

		inline int levelToCascade(int level) const
		{
			for (size_t i = 0; i < mCascades.size() - 1; i++)
			{
				if (mCascades[i]->getBiggestLevel() <= level && mCascades[i]->getSmallestLevel() >= level)// && mCascades[i+1]->getSmallestLevel() < level)
					return static_cast<int>(i);
			}
			return (int)(mCascades.size() - 1);
		}
	};
}
}
#endif //_SUNSHADOW_H_