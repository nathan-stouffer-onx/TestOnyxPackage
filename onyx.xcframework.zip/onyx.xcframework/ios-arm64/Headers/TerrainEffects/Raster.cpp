#include "Raster.h"

#include "Caching/Tiles/TileCache.h"
#include "Tiles/TileRenderInfo.h"

namespace onyx::TerrainEffects
{

	bool Raster::prepare(Args const& args)
	{
		// compute style information
		Styling::RasterLayer const& layer = static_cast<Styling::RasterLayer const&>(args.layer);
		Styling::RasterStyle style = layer.realize(args.layerArgs);
		mStyle = style;
		
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		Styling::RasterSource const& specification = static_cast<Styling::RasterSource const&>(*source.specification());
		Atlases::TileAtlas const& atlas = *source.atlas();

		// compute render info
		mInfo.clear();
		mInfo.reserve(args.onscreen.tileIds.size());
		bool complete = true;	// assum complete until proven otherwise
		for (Tiles::TileId const& tileId : args.onscreen.tileIds)
		{
			Tiles::AtlasInfo atlasInfo = Tiles::AtlasInfo::Compute(atlas, tileId.moduloX(), source.specification()->range(), style.opacity);
			bool missing = atlasInfo.handle.idx == atlas.getMissingTileHandle().idx;
			complete &= !missing && (atlasInfo.level == std::min(tileId.level, specification.range().end));
			mInfo[tileId] = Tiles::PseudoRasterInfo{ tileId, atlasInfo };
		}

		return complete;
	}

	void Raster::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		Tiles::PseudoRasterInfo const& info = mInfo.at(tileId);
		program.set("s_Raster", info.atlas.handle, info.atlas.resolution, false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_RasterScaleOffset", info.atlas.offset);
		program.set("u_PackedRasterParams", lgal::gpu::Vector4(info.atlas.opacity, 0, 0, 0));
	}

}