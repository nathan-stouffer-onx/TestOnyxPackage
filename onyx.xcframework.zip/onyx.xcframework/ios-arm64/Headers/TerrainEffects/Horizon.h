#pragma once

#include <lucid/gal/Types.h>

namespace onyx::TerrainEffects
{

	class Horizon
	{
	public:

		using Config = lgal::gpu::Range;

		static lgal::gpu::Vector2 realize(Config const& config, world_float_t const pitch, world_float_t const maxPitch)
		{
			world_float_t theta = std::clamp(std::abs(pitch / maxPitch), 0.0, 1.0) * lmath::constants::half_pi<world_float_t>();
			gpu_float_t t = static_cast<gpu_float_t>(std::cos(theta));
			return lgal::gpu::Vector2(lmath::lerp(config.begin, 1.0f, t), lmath::lerp(config.end, 1.1f, t));
		}

	public:

		lgal::gpu::Vector2 realizeFog(world_float_t const pitch) const { return realize(mFogConfig, pitch, mMaxPitch); }
		lgal::gpu::Vector2 realizeLineOpacity(world_float_t const pitch) const { return realize(mLineOpacityConfig, pitch, mMaxPitch); }
		lgal::gpu::Vector2 realizeFillOpacity(world_float_t const pitch) const { return realize(mFillOpacityConfig, pitch, mMaxPitch); }

		inline bool operator==(Horizon const& rhs) const
		{
			return mMaxPitch == rhs.mMaxPitch
				&& mFogConfig == rhs.mFogConfig
				&& mLineOpacityConfig == rhs.mLineOpacityConfig
				&& mFillOpacityConfig == rhs.mFillOpacityConfig;
		}

		world_float_t getMaxPitch() const { return mMaxPitch; }
		Config const& getFogConfig() const { return mFogConfig; }
		Config const& getLineOpacityConfig() const { return mLineOpacityConfig; }
		Config const& getFillOpacityConfig() const { return mFillOpacityConfig; }

		void setMaxPitch(world_float_t const pitch) { mMaxPitch = pitch; }
		void setFogConfig(Config const& config) { mFogConfig = config; }
		void setLineOpacityConfig(Config const& config) { mLineOpacityConfig = config; }
		void setFillOpacityConfig(Config const& config) { mFillOpacityConfig = config; }

	private:

		world_float_t mMaxPitch = lmath::constants::quarter_pi<world_float_t>();

		Config mFogConfig = { 0.65f, 1.0f };
		Config mLineOpacityConfig = { 0.4f, 0.55f };
		Config mFillOpacityConfig = { 0.4f, 0.55f };

	};

}