#pragma once

#include <lucid/gal/Types.h>

#include <Styling/Styles/ContourConfigs.h>
#include <Styling/Styles/FillStyle.h>
#include <Styling/Styles/FogStyle.h>
#include <Styling/Styles/LineStyle.h>

namespace onyx::TerrainEffects
{

	class Horizon
	{
	public:

		using Minimums = lgal::gpu::Vector2;
		
		static gpu_float_t convert(gpu_float_t const x, world_float_t const zoomKm)
		{
			world_float_t dist = (x <= 0.f) ? zoomKm * std::exp(x) : (1.0 + x) * zoomKm;
			return static_cast<gpu_float_t>(dist);
		}

		// converts stylesheet values to distances in world space
		static lgal::gpu::Vector2 convert(lgal::gpu::Vector2 const& input, world_float_t const zoomKm, Minimums const& minimums)
		{
			lgal::gpu::Vector2 realized = minimums;
			realized.x = std::max(realized.x, convert(input.x, zoomKm));
			realized.y = std::max(realized.y, convert(input.y, zoomKm));
			return realized;
		}

	public:
		
		inline void convert(Styling::FogStyle& style, world_float_t const zoomKm) const
		{
			style.range = convert(style.range, zoomKm, mFogMinimums);
		}

		inline void convert(Styling::ContourLineConfig& config, world_float_t const zoomKm) const
		{
			config.fadeRange = convert(config.fadeRange, zoomKm, mLineMinimums);
		}
		
		inline void convert(Styling::FillStyle::Effect& effect, world_float_t const zoomKm) const
		{
			effect.fadeRange = convert(effect.fadeRange, zoomKm, mFillMinimums);
		}

		inline void convert(Styling::LineStyle::Effect& effect, world_float_t const zoomKm) const
		{
			effect.fadeRange = convert(effect.fadeRange, zoomKm, mLineMinimums);
		}

		inline bool operator==(Horizon const& rhs) const
		{
			return mFogMinimums == rhs.mFogMinimums
				&& mLineMinimums == rhs.mLineMinimums
				&& mFillMinimums == rhs.mFillMinimums;
		}

		Minimums const& getFogMinimums() const { return mFogMinimums; }
		Minimums const& getLineMinimums() const { return mLineMinimums; }
		Minimums const& getFillMinimums() const { return mFillMinimums; }

		void setFogMinimums(Minimums const& minimums) { mFogMinimums = minimums; }
		void setLineMinimums(Minimums const& minimums) { mLineMinimums = minimums; }
		void setFillMinimums(Minimums const& minimums) { mFillMinimums = minimums; }

	private:

		Minimums mFogMinimums = { 50.0, 100.0 };
		Minimums mLineMinimums = { 15.0, 30.0 };
		Minimums mFillMinimums = { 15.0, 30.0 };

	};

}