#pragma once

#include <lucid/gal/Types.h>

#include <Styling/Styles/ContourConfigs.h>
#include <Styling/Styles/FillStyle.h>
#include <Styling/Styles/FogStyle.h>
#include <Styling/Styles/LineStyle.h>

namespace onyx::TerrainEffects
{

	class Horizon
	{
	public:

		using Minimums = lgal::gpu::Vector2;
		
		static gpu_float_t convert(gpu_float_t const x, world_float_t const zoomKm)
		{
			world_float_t dist = (x <= 0.f) ? zoomKm * std::exp(x) : (1.0 + x) * zoomKm;
			return static_cast<gpu_float_t>(dist);
		}

		// converts stylesheet values to distances in world space
		static lgal::gpu::Vector2 convert(lgal::gpu::Vector2 const& input, world_float_t const zoomKm, Minimums const& minimums)
		{
			lgal::gpu::Vector2 realized = minimums;
			realized.x = std::max(realized.x, convert(input.x, zoomKm));
			realized.y = std::max(realized.y, convert(input.y, zoomKm));
			return realized;
		}

	public:
		
		inline Styling::FogStyle convert(Styling::FogStyle const& input, world_float_t const zoomKm) const
		{
			Styling::FogStyle output = input;
			output.range = convert(output.range, zoomKm, mFogMinimums);
			return output;
		}

		inline Styling::ContourLineConfig convert(Styling::ContourLineConfig const& input, world_float_t const zoomKm) const
		{
			Styling::ContourLineConfig output = input;
			output.fadeRange = convert(output.fadeRange, zoomKm, mLineMinimums);
			return output;
		}
		
		inline Styling::FillStyle::Effect convert(Styling::FillStyle::Effect const& input, world_float_t const zoomKm) const
		{
			Styling::FillStyle::Effect output = input;
			output.fadeRange = convert(output.fadeRange, zoomKm, mFillMinimums);
			return output;
		}

		inline Styling::LineStyle::Effect convert(Styling::LineStyle::Effect const& input, world_float_t const zoomKm) const
		{
			Styling::LineStyle::Effect output = input;
			output.fadeRange = convert(output.fadeRange, zoomKm, mLineMinimums);
			return output;
		}

		inline bool operator==(Horizon const& rhs) const
		{
			return mFogMinimums == rhs.mFogMinimums
				&& mLineMinimums == rhs.mLineMinimums
				&& mFillMinimums == rhs.mFillMinimums;
		}

		Minimums const& getFogMinimums() const { return mFogMinimums; }
		Minimums const& getLineMinimums() const { return mLineMinimums; }
		Minimums const& getFillMinimums() const { return mFillMinimums; }

		void setFogMinimums(Minimums const& minimums) { mFogMinimums = minimums; }
		void setLineMinimums(Minimums const& minimums) { mLineMinimums = minimums; }
		void setFillMinimums(Minimums const& minimums) { mFillMinimums = minimums; }

	private:

		Minimums mFogMinimums = { 50.0, 100.0 };
		Minimums mLineMinimums = { 15.0, 30.0 };
		Minimums mFillMinimums = { 15.0, 30.0 };

	};

}