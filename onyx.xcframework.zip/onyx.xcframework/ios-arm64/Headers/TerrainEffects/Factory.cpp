#include "Factory.h"

#include "TerrainEffects/ContourLine.h"
#include "TerrainEffects/Gradients/ElevationShade.h"
#include "TerrainEffects/Gradients/IntersectShade.h"
#include "TerrainEffects/Gradients/SlopeAngleShade.h"
#include "TerrainEffects/Gradients/SlopeAspectShade.h"
#include "TerrainEffects/Hillshade.h"
#include "TerrainEffects/SunShadow.h"
#include "TerrainEffects/Viewshed.h"

namespace onyx::TerrainEffects
{

	std::unique_ptr<TerrainEffectBase> construct(Styling::Layer::Types const type)
	{
		using T = Styling::Layer::Types;
		switch (type)
		{
			case T::CONTOUR_LINE: return std::make_unique<TerrainEffects::ContourLine>();      break;
			case T::ELEVATION:    return std::make_unique<TerrainEffects::ElevationShade>();   break;
			case T::HILLSHADE:    return std::make_unique<TerrainEffects::Hillshade>();        break;
			case T::INTERSECT:    return std::make_unique<TerrainEffects::IntersectShade>();   break;
			case T::SLOPE_ANGLE:  return std::make_unique<TerrainEffects::SlopeAngleShade>();  break;
			case T::SLOPE_ASPECT: return std::make_unique<TerrainEffects::SlopeAspectShade>(); break;
			case T::SUNLIGHT:     return std::make_unique<TerrainEffects::SunShadow>();        break;
			case T::VIEWSHED:     return std::make_unique<TerrainEffects::Viewshed>();         break;
			default: break;
		}
		return nullptr;
	}

}