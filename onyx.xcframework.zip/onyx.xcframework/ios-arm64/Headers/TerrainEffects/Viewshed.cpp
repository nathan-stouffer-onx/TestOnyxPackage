#include "Viewshed.h"

#include <Logging/LogManager.h>
#include <Shaders/Load.h>

#include "Caching/Tiles/TileCache.h"
#include "Rendering/ViewId.h"
#include "Pyramid/UVOffset.h"
#include "Tiles/TileMesh.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"
#include "Utils/TextUtils.h"

namespace onyx::TerrainEffects {

	void Viewshed::set(Shaders::Program& program, Tiles::TileId const&) const
	{
		program.set("u_ViewshedTint", lgal::Color::FromABGR(mConfig.abgr));
		program.set("u_ViewshedRingTint", lgal::Color::FromABGR(mConfig.ringAbgr));
		program.set("u_ViewshedPos", mEye - mCameraState.position);
		program.set("s_ViewshedDistances", getDepthHandle(), lgal::screen::Vector2(mCubeDepthRes), true, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
		program.set("u_PackedViewshedParams", lgal::world::Vector4(mConfig.rangeKm * MapMath::mercatorDistortion(mPosition), mConfig.inverted ? 1 : 0, 0.005 * MapMath::mercatorDistortion(mPosition), mFarPlane));
	}

	void Viewshed::getLabels(std::vector<Symbol::SharedSymbol_t>& symbols) const
	{
		auto camHeight = mCameraState.position.z - mEye.z;
		size_t last = camHeight < 7.5f ? 16 : camHeight < 15.0f ? 8 : camHeight < 30.f ? 4 : 0;
		symbols.insert(symbols.end(), mSymbols.begin(), mSymbols.begin() + (last + 1));
	}

	Viewshed::Viewshed() :
		mNearPlane(0.0001f),
		mFarPlane(30.0f),
		mDistanceProgram(Shaders::load(Shaders::TiledEncodings::Options{ Shaders::TiledEncodings::EncodedTypes::DISTANCE, true }))
	{
		for (int i = 0; i < 6; i++)
		{
			mCubemapDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
		}
		mCubemapDepthTexHandle[0] = BGFX_INVALID_HANDLE;
		mCubemapDepthTexHandle[1] = BGFX_INVALID_HANDLE;

		auto style = std::make_shared<Styling::TextStyle>(Styling::FontFace({ "default", 15, Styling::TextFontTypes::DistanceOutlineShadowImage }), lgal::Color::FromRGBA(0xFFFFFFFF), lgal::Color::FromRGBA(0x000000FF), lgal::Color::FromRGBA(0x00000064), 0.f, Styling::Anchor::DEFAULT);
		style->haloWidth = 2.f;
		for (int i = 0; i < 17; ++i)
		{
			auto lbl = std::make_shared<Symbol::MapLabel>(Styling::Formatted(""));
			
			auto symbol = std::make_shared<Symbol::MapSymbol>(lbl, lgal::world::Vector3{ 0 }, Utils::SpaceTypes::World, "", Styling::SymbolPlacement::POINT, Symbol::MapSymbol::cNoTileId);
			mSymbols.push_back(symbol);
			mSymbols.back()->getLabel()->setStyle(style);
		}
	}

	static std::array<lgal::world::Vector2 const, 4> sDirections = { { { 1, 0 }, { 0, 1 }, { -1, 0 }, { 0, -1 } } };
	static std::array<float32_t const, 4> sDistances = { 1.0f, 0.5f, 0.25f, 0.75f };

	void Viewshed::updateLabels(Atlases::HeightAtlas const& atlas, Args const& args)
	{
		auto distortion = MapMath::mercatorDistortion(mPosition);

		MapMath::LonLat lonLat(mPosition);

		auto const& centerSymbol = mSymbols.front();
		centerSymbol->getLabel()->setText(Styling::Formatted(Utils::Text::ReadableLonLat(lonLat)));
		lgal::world::Vector3 centerPos(mPosition, atlas.heightAt(mPosition));
		centerSymbol->setAnchorPos(centerPos);
		
		std::ostringstream os;

		auto labelIdx = 1;

		for (auto const &dist : sDistances)
		{
			os.str("");
			os.clear();
			os.setf(std::ios::fixed);
			os.precision(1);

			auto rangeKm = dist * float32_t(mConfig.rangeKm * distortion);

			auto values = Utils::Text::GetDistanceLabelUnits(rangeKm, false);

			os << values.first << values.second;
			auto text = os.str();

			for (auto const& direction : sDirections)
			{
				auto const& symbol = mSymbols[labelIdx++];
				symbol->setLayerId(args.layer.id.str());
				auto offsetPos = (mPosition + (direction * world_float_t(rangeKm)));
				lgal::world::Vector3 labelPos(offsetPos.x, offsetPos.y, atlas.heightAt(offsetPos));
				symbol->getLabel()->setText(Styling::Formatted(text));
				symbol->setAnchorPos(labelPos);
			}
		}
	}

	Viewshed::~Viewshed()
	{
		deallocateFramebuffer();
	}

	bool Viewshed::prepare(Args const& args)
	{
		Styling::ViewshedLayer const& layer = static_cast<Styling::ViewshedLayer const&>(args.layer);
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer.source);
		Styling::ViewshedConfig config = layer.realize(args.layerArgs);

		// always update camera state
		mCameraState = args.camera;

		// early out if there is no work necessary
		if (mCompleted && config == mConfig) { return true; }

		Atlases::HeightAtlas const& atlas = static_cast<Atlases::HeightAtlas const&>(*source.atlas());

		lgal::world::Vector2 position = MapMath::LonLat(config.lon, config.lat).toWorldPos();
		bool needsLabelUpdate = mPosition != position || mConfig.rangeKm != config.rangeKm;

		// update configuration info
		mConfig = config;
		mPosition = position;
		mEye = { mPosition, atlas.heightAt(mPosition) + mConfig.offsetKm * MapMath::mercatorDistortion(mConfig.lat)};

		if (needsLabelUpdate)
		{
			updateLabels(atlas, args);
		}

		Styling::RasterDemSource const& specification = static_cast<Styling::RasterDemSource const&>(*source.specification());

		// cull and precache the result
		mCullState = Pyramid::cull(mEye.xy, mFarPlane, 2.0, specification.maxZoom);
		for (Tiles::TileId const& tileId : mCullState.tileIds)
		{
			Caching::TileCache::Instance()->at({ layer.source, tileId });
		}

		// early out if the height atlas doesn't even have the root tile
		if (!atlas.isReady({ 0, 0, 0 })) { return false; }

		// identify the height tiles that we have available
		std::map<Tiles::TileId, Tiles::TileId> readyTiles;
		bool allTilesHaveData = true;
		for (const auto& tileId : mCullState.tileIds)
		{
			Tiles::TileId readyId = tileId;
			bool found = false;
			while (!found && readyId.level >= 0)
			{
				if (atlas.isReady(readyId))
				{
					found = true;
					readyTiles[tileId] = readyId;
				}
				else
				{
					readyId = readyId.parent();
				}
			}
			if (!found)
			{
				allTilesHaveData = false;
			}
		}

		// if any tile is missing data, don't draw viewshed
		if (!allTilesHaveData) { return false; }

		// double check that framebuffers are valid
		if (!bgfx::isValid(mCubemapDepthFrameBufferHandle[0]))
		{
			deallocateFramebuffer();
			allocateFramebuffer();
		}

		if (!bgfx::isValid(mCubemapDepthFrameBufferHandle[0])) { return false; }

		mCompleted = true;

		// calculate the view/proj matrices
		for (int i = 0; i < 6; i++)
		{
			bx::mtxLookAt(mCubemapView[i], { 0, 0, 0 }, BgfxUtils::toBx(sCubemapLookDirs[i]), BgfxUtils::toBx(sCubemapUpDirs[i]));
		}
		bx::mtxProj(mCubemapProj, 90.0f, 1.0, float(mNearPlane), float(mFarPlane), bgfx::getCaps()->homogeneousDepth);

		for (int i = 0; i < 6; i++)
		{
			bgfx::ViewId cameraCubeDepthId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
			setCubeView(cameraCubeDepthId, i);

			for (const auto& tileId : mCullState.tileIds)
			{
				Tiles::TileId& readyId = readyTiles[tileId];
				if (tileId.level < specification.maxZoom && tileId != readyId)	// if we are using a lower detail tile, set the dirty flag
				{
					mCompleted = false;
				}

				bgfx::TextureHandle tex = atlas.getTexHandle(readyId);
				int res = atlas.getResolution();
				mDistanceProgram.set("s_Terrain", tex, lgal::screen::Vector2(res), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);

				auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(readyId, tileId);
				auto uvOffset = atlas.getUVOffset(readyId);
				auto combinedUVOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);
				mDistanceProgram.set("u_ScaleOffsetTerrain", combinedUVOffset);

				// compute distortions at the min/max of the tile (NOTE: possible name confusion here since the min of the tile will have the most distortion in the northern hemisphere)
				auto meshRes = MapMath::meshResolution(specification.tileSize, specification.maxZoom, tileId);
				auto minDistortion = MapMath::mercatorDistortion(tileId.northwestCorner());
				auto maxDistortion = MapMath::mercatorDistortion(tileId.southeastCorner());
				mDistanceProgram.set("u_PackedTerrainParams", lgal::world::Vector4{ minDistortion, maxDistortion, 1.0, static_cast<world_float_t>(meshRes) });

				mDistanceProgram.set("u_TileMin", lgal::world::Vector3{ tileId.northwestCorner(), 0.0 } - mEye);
				mDistanceProgram.set("u_TileMax", lgal::world::Vector3{ tileId.southeastCorner(), 0.0 } - mEye);

				mDistanceProgram.set("u_PackedParams", lgal::world::Vector4(tileId.extent(), mFarPlane, 0, 0));

				uint64_t state = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | static_cast<uint64_t>(Styling::DepthTest::LESS);
				Tiles::TileMesh::Instance(meshRes)->render(cameraCubeDepthId, mDistanceProgram.handle(), tileId, mEye, sCubemapHeadings[i], state, false);
			}
		}
		return true;
	}

	void Viewshed::setCubeView(bgfx::ViewId viewId, int side)
	{
		bgfx::touch(viewId);

		bgfx::setViewName(viewId, "Camera Cubemap Depth");
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(viewId, 0, 0, mCubeDepthRes, mCubeDepthRes);

		bgfx::setViewFrameBuffer(viewId, mCubemapDepthFrameBufferHandle[side]);
		bgfx::setViewTransform(viewId, mCubemapView[side], mCubemapProj);
	}

	void Viewshed::allocateFramebuffer()
	{
		{
			uint64_t flags = BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC | BGFX_TEXTURE_RT | BGFX_SAMPLER_UVW_CLAMP;
			mCubemapDepthTexHandle[0] = bgfx::createTextureCube(uint16_t(mCubeDepthRes), false, 1, bgfx::TextureFormat::R32F, flags);
		}

		{
			bgfx::TextureFormat::Enum depthFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
			mCubemapDepthTexHandle[1] = bgfx::createTextureCube(uint16_t(mCubeDepthRes), false, 1, depthFormat, BGFX_TEXTURE_RT_WRITE_ONLY);
		}

		if (bgfx::isValid(mCubemapDepthTexHandle[0]) && bgfx::isValid(mCubemapDepthTexHandle[1]))
		{
			bgfx::setName(mCubemapDepthTexHandle[0], "fboCubemapColorTex");
			bgfx::setName(mCubemapDepthTexHandle[1], "fboCubemapDepthTex");
			for (uint16_t i = 0; i < 6; i++)
			{
				mCubemapAttachments[i][0].init(mCubemapDepthTexHandle[0], bgfx::Access::Write, i);
				mCubemapAttachments[i][1].init(mCubemapDepthTexHandle[1], bgfx::Access::Write, i);
				mCubemapDepthFrameBufferHandle[i] = bgfx::createFrameBuffer(BX_COUNTOF(mCubemapDepthTexHandle), &mCubemapAttachments[i][0], true);
			}
		}
	}

	void Viewshed::deallocateFramebuffer()
	{
		for (int i = 0; i < 6; i++)
		{
			BgfxUtils::tryDestroy(mCubemapDepthFrameBufferHandle[i]);
		}
		BgfxUtils::tryDestroy(mCubemapDepthTexHandle[0]);
		BgfxUtils::tryDestroy(mCubemapDepthTexHandle[1]);
	}

	lgal::world::Vector3 const Viewshed::sCubemapLookDirs[6] =
	{
		// east       west
		{ 1, 0, 0 },  { -1, 0, 0 },
		// north      south
		{ 0, -1, 0 }, { 0, 1, 0 },
		// up         down
		{ 0, 0, 1 },  { 0, 0, -1 },
	};

	lgal::world::Vector3 const Viewshed::sCubemapUpDirs[6] =
	{
		// east       west
		{ 0, 1, 0 },  { 0, 1, 0 },
		// north      south
		{ 0, 0, 1 },  { 0, 0, -1 },
		// up         down
		{ 0, 1, 0 },  { 0, 1, 0 },
	};

	world_float_t const Viewshed::sCubemapHeadings[6] =
	{
		// east										west
		lmath::constants::half_pi<world_float_t>(),	3.0 * lmath::constants::half_pi<world_float_t>(),
		// north									south
		0.0,										lmath::constants::pi<world_float_t>(),
		// up										down
		0.0,										0.0,
	};

}