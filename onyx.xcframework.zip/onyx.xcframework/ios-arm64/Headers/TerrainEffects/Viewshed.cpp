#include "Viewshed.h"

#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>

#include "Caching/Tiles/TileCache.h"
#include "Rendering/ViewId.h"
#include "Pyramid/UVOffset.h"
#include "Tiles/TileMesh.h"
#include "Utils/BgfxUtils.h"
#include "Utils/MapMath.h"
#include "Utils/TextUtils.h"

namespace onyx {
namespace TerrainEffects {

	void Viewshed::setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const&) const
	{
		shader.setParameter("s_cubeDepth0", getDepthHandle(), int(mCubeDepthRes), int(mCubeDepthRes));
		shader.setParameter("u_viewshedPos0", mEye - mCameraState.position);
		shader.setParameter("u_viewshedInverted0", mConfig.inverted ? 1.f : 0.f);
		shader.setParameter("u_viewshedFarPlane0", mFarPlane);
		shader.setParameter("u_viewshedRange0", mConfig.rangeKm * MapMath::mercatorDistortion(mPosition));
		shader.setParameter("u_viewshedTint0", lgal::Color::FromABGR(mConfig.abgr));
		shader.setParameter("u_viewshedRingTint0", lgal::Color::FromABGR(mConfig.ringAbgr));
	}

	void Viewshed::getLabels(std::vector<DataObjects::SharedSymbol_t>& symbols) const
	{
		auto camHeight = mCameraState.position.z - mEye.z;
		size_t last = camHeight < 7.5f ? 16 : camHeight < 15.0f ? 8 : camHeight < 30.f ? 4 : 0;
		symbols.insert(symbols.end(), mSymbols.begin(), mSymbols.begin() + (last + 1));
	}

	Viewshed::Viewshed() :
		mNearPlane(0.0001f),
		mFarPlane(30.0f)
	{
		for (int i = 0; i < 6; i++)
		{
			mCubemapDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
		}
		mCubemapDepthTexHandle[0] = BGFX_INVALID_HANDLE;
		mCubemapDepthTexHandle[1] = BGFX_INVALID_HANDLE;

		auto style = std::make_shared<Styling::TextStyle>(Styling::FontFace({ "default", FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE, 15 }), lgal::Color::FromRGBA(0xFFFFFFFF), lgal::Color::FromRGBA(0x000000FF), lgal::Color::FromRGBA(0x00000064), 0.f, Styling::Anchor::DEFAULT);
		for (int i = 0; i < 17; ++i)
		{
			mSymbols.push_back(std::make_shared<DataObjects::MapSymbol>(std::make_shared<DataObjects::MapLabel>(Styling::Formatted(""), lgal::world::Vector3(0, 0, 0), Utils::SpaceTypes::World), Styling::SymbolPlacement::POINT));
			mSymbols.back()->getLabel()->setStyle(style);
		}
	}

	static std::array<lgal::world::Vector2 const, 4> sDirections = { { { 1, 0 }, { 0, 1 }, { -1, 0 }, { 0, -1 } } };
	static std::array<float32_t const, 4> sDistances = { 1.0f, 0.5f, 0.25f, 0.75f };

	void Viewshed::updateLabels(Atlases::HeightAtlas const& atlas)
	{
		auto distortion = MapMath::mercatorDistortion(mPosition);

		MapMath::LonLat lonLat(mPosition);

		auto const& centerLabel = mSymbols.front()->getLabel();
		centerLabel->setText(Styling::Formatted(Utils::Text::ReadableLonLat(lonLat)));
		lgal::world::Vector3 centerPos(mPosition, atlas.heightAt(mPosition));
		centerLabel->setMapPosition(centerPos);
		centerLabel->setAnchorPoint(centerPos);
		
		std::ostringstream os;

		auto labelIdx = 1;

		for (auto const &dist : sDistances)
		{
			os.str("");
			os.clear();
			os.setf(std::ios::fixed);
			os.precision(1);

			auto rangeKm = dist * float32_t(mConfig.rangeKm * distortion);

			auto values = Utils::Text::GetDistanceLabelUnits(rangeKm, false);

			os << values.first << values.second;
			auto text = os.str();

			for (auto const& direction : sDirections)
			{
				auto const& label = mSymbols[labelIdx++]->getLabel();
				auto offsetPos = (mPosition + (direction * world_float_t(rangeKm)));
				lgal::world::Vector3 labelPos(offsetPos.x, offsetPos.y, atlas.heightAt(offsetPos));
				label->setText(Styling::Formatted(text));
				label->setMapPosition(labelPos);
				label->setAnchorPoint(labelPos);
			}
		}
	}

	Viewshed::~Viewshed()
	{
		deallocateFramebuffer();
	}

	void Viewshed::update(Styling::ViewshedConfig const& config, Args const& args)
	{
		// always update camera state
		mCameraState = args.camera;

		// early out if there is no work necessary
		if (mCompleted && config == mConfig) { return; }

		lgal::world::Vector2 position = MapMath::LonLat(config.lon, config.lat).toWorldPos();
		bool needsLabelUpdate = mPosition != position || mConfig.rangeKm != config.rangeKm;

		// update configuration info
		mConfig = config;
		mPosition = position;
		mEye = { mPosition, args.atlas.heightAt(mPosition) + mConfig.offsetKm * MapMath::mercatorDistortion(mConfig.lat)};

		if (needsLabelUpdate)
		{
			updateLabels(args.atlas);
		}

		Styling::RasterDemSource const& specification = static_cast<Styling::RasterDemSource const&>(*args.source.specification());

		// cull and precache the result
		mCullState.reset();
		Pyramid::cull(mCullState, mEye.xy, mFarPlane, 2.0, specification.maxZoom);
		for (Tiles::TileId const& tileId : mCullState.tileIds)
		{
			Caching::TileCache::Instance()->at({ args.id, tileId });
		}

		// early out if the height atlas doesn't even have the root tile
		if (!args.atlas.isReady({ 0, 0, 0 })) { return; }

		// identify the height tiles that we have available
		std::map<Tiles::TileId, Tiles::TileId> readyTiles;
		bool allTilesHaveData = true;
		for (const auto& tileId : mCullState.tileIds)
		{
			Tiles::TileId readyId = tileId;
			bool found = false;
			while (!found && readyId.level >= 0)
			{
				if (args.atlas.isReady(readyId))
				{
					found = true;
					readyTiles[tileId] = readyId;
				}
				else
				{
					readyId = readyId.parent();
				}
			}
			if (!found)
			{
				allTilesHaveData = false;
			}
		}

		// if any tile is missing data, don't draw viewshed
		if (!allTilesHaveData) { return; }

		// double check that framebuffers are valid
		if (!bgfx::isValid(mCubemapDepthFrameBufferHandle[0]))
		{
			deallocateFramebuffer();
			allocateFramebuffer();
		}

		if (!bgfx::isValid(mCubemapDepthFrameBufferHandle[0])) { return; }

		mCompleted = true;

		uint64_t overrideState = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LESS;

		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainCubemapDepth, 0);

		// calculate the view/proj matrices
		for (int i = 0; i < 6; i++)
		{
			bx::mtxLookAt(mCubemapView[i], { 0, 0, 0 }, BgfxUtils::toBx(sCubemapLookDirs[i]), BgfxUtils::toBx(sCubemapUpDirs[i]));
		}
		bx::mtxProj(mCubemapProj, 90.0f, 1.0, float(mNearPlane), float(mFarPlane), bgfx::getCaps()->homogeneousDepth);

		for (int i = 0; i < 6; i++)
		{
			bgfx::ViewId cameraCubeDepthId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
			setCubeView(cameraCubeDepthId, i);

			shader->setParameter("u_eyePos", mEye);
			shader->setParameter("u_NearFarFocus", lgal::gpu::Vector3(float(mNearPlane), float(mFarPlane), 0));

			for (const auto& tileId : mCullState.tileIds)
			{
				Tiles::TileId& readyId = readyTiles[tileId];
				if (tileId.level < specification.maxZoom && tileId != readyId)	// if we are using a lower detail tile, set the dirty flag
				{
					mCompleted = false;
				}

				bgfx::TextureHandle tex = args.atlas.getTexHandle(readyId);
				int res = args.atlas.getResolution();
				shader->setParameter("s_heightTexture", tex, res, res);

				auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(readyId, tileId);
				auto uvOffset = args.atlas.getUVOffset(readyId);
				auto combinedUVOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);
				shader->setParameter("u_ScaleOffsetHeight", combinedUVOffset);

				auto meshRes = MapMath::meshResolution(specification, tileId);

				lgal::world::Vector3 tileMin = lgal::world::Vector3{ tileId.northwestCorner(), 0.0 } - mEye;
				lgal::world::Vector3 tileMax = lgal::world::Vector3{ tileId.southeastCorner(), 1.0 } - mEye;
				tileMax.z = tileId.extent();

				shader->setParameter("u_tileMin", tileMin);
				shader->setParameter("u_tileMax", tileMax);

				// compute distortions at the min/max of the tile (NOTE: possible name confusion here since the min of the tile will have the most distortion)
				auto minDistortion = MapMath::mercatorDistortion(tileId.northwestCorner());
				auto maxDistortion = MapMath::mercatorDistortion(tileId.southeastCorner());
				shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ (gpu_float_t)minDistortion, (gpu_float_t)maxDistortion, 0.0 });

				Tiles::TileMesh::Instance(meshRes)->draw(tileId, mEye, sCubemapHeadings[i], shader->programHandle, cameraCubeDepthId, false, overrideState);
			}
		}
	}

	void Viewshed::setCubeView(bgfx::ViewId viewId, int side)
	{
		bgfx::touch(viewId);

		bgfx::setViewName(viewId, "Camera Cubemap Depth");
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(viewId, 0, 0, mCubeDepthRes, mCubeDepthRes);

		bgfx::setViewFrameBuffer(viewId, mCubemapDepthFrameBufferHandle[side]);
		bgfx::setViewTransform(viewId, mCubemapView[side], mCubemapProj);
	}

	void Viewshed::allocateFramebuffer()
	{
		{
			uint64_t flags = BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP | BGFX_SAMPLER_W_CLAMP;
			mCubemapDepthTexHandle[0] = bgfx::createTextureCube(uint16_t(mCubeDepthRes), false, 1, bgfx::TextureFormat::R32F, flags);
		}

		{
			bgfx::TextureFormat::Enum depthFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
			mCubemapDepthTexHandle[1] = bgfx::createTextureCube(uint16_t(mCubeDepthRes), false, 1, depthFormat, BGFX_TEXTURE_RT_WRITE_ONLY);
		}

		if (bgfx::isValid(mCubemapDepthTexHandle[0]) && bgfx::isValid(mCubemapDepthTexHandle[1]))
		{
			bgfx::setName(mCubemapDepthTexHandle[0], "fboCubemapColorTex");
			bgfx::setName(mCubemapDepthTexHandle[1], "fboCubemapDepthTex");
			for (uint16_t i = 0; i < 6; i++)
			{
				mCubemapAttachments[i][0].init(mCubemapDepthTexHandle[0], bgfx::Access::Write, i);
				mCubemapAttachments[i][1].init(mCubemapDepthTexHandle[1], bgfx::Access::Write, i);
				mCubemapDepthFrameBufferHandle[i] = bgfx::createFrameBuffer(BX_COUNTOF(mCubemapDepthTexHandle), &mCubemapAttachments[i][0], true);
			}
		}
	}

	void Viewshed::deallocateFramebuffer()
	{
		for (int i = 0; i < 6; i++)
		{
			BgfxUtils::tryDestroy(mCubemapDepthFrameBufferHandle[i]);
		}
		BgfxUtils::tryDestroy(mCubemapDepthTexHandle[0]);
		BgfxUtils::tryDestroy(mCubemapDepthTexHandle[1]);
	}

	lgal::world::Vector3 const Viewshed::sCubemapLookDirs[6] =
	{
		// east       west
		{ 1, 0, 0 },  { -1, 0, 0 },
		// north      south
		{ 0, -1, 0 }, { 0, 1, 0 },
		// up         down
		{ 0, 0, 1 },  { 0, 0, -1 },
	};

	lgal::world::Vector3 const Viewshed::sCubemapUpDirs[6] =
	{
		// east       west
		{ 0, 1, 0 },  { 0, 1, 0 },
		// north      south
		{ 0, 0, 1 },  { 0, 0, -1 },
		// up         down
		{ 0, 1, 0 },  { 0, 1, 0 },
	};

	world_float_t const Viewshed::sCubemapHeadings[6] =
	{
		// east										west
		lmath::constants::half_pi<world_float_t>(),	3.0 * lmath::constants::half_pi<world_float_t>(),
		// north									south
		0.0,										lmath::constants::pi<world_float_t>(),
		// up										down
		0.0,										0.0,
	};

} }