#include "Background.h"

namespace onyx::TerrainEffects
{

	bool Background::prepare(Args const& args)
	{
		Styling::BackgroundLayer const& layer = static_cast<Styling::BackgroundLayer const&>(args.layer);
		Styling::BackgroundStyle style = layer.realize(args.layerArgs);

		mStyle = style;
		mDiff = (mStyle.pattern.max - mStyle.pattern.min).as<world_float_t>();
		mZoom = args.zoom;
		mSpritesheet = args.sprites;
		mAtlas = mSpritesheet->getImageAtlas();
		return true;
	}

	void Background::set(Shaders::Program& program, Tiles::TileId const& tileId) const
	{
		world_float_t omega = tileId.extent() / Tiles::TileId::LevelToTileExtent(static_cast<int>(mZoom));
		if (mAtlas && mAtlas->hasPage(bgfx::TextureFormat::Enum::RGBA8, 0))
		{
			program.set("s_BackgroundPatterns", mAtlas->getTexHandle(bgfx::TextureFormat::Enum::RGBA8, 0), mAtlas->getResolution(), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
			omega *= mSpritesheet->getScalar();
		}
		program.set("u_BackgroundPatternsBounds", lgal::gpu::Vector4(mStyle.pattern.min.as<gpu_float_t>(), mStyle.pattern.max.as<gpu_float_t>()));

		world_float_t constexpr scalar = 512.0;
		program.set("u_BackgroundPackedParams", lgal::world::Vector4(mStyle.opacity, scalar * omega, std::fmod(scalar * omega * tileId.x, mDiff.x), std::fmod(scalar * omega * tileId.y, mDiff.y)));
		
		program.set("u_BackgroundColor", lgal::Color::FromABGR(mStyle.abgr));
	}

}