#pragma once

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"
#include "Tiles/TileRenderInfo.h"

namespace onyx::TerrainEffects
{

	class Hillshade final : public TerrainEffectBase
	{
	public:

		Hillshade() = default;
		~Hillshade() = default;

		bool prepare(Args const& args) override;

		void set(Shaders::Program& program, Tiles::TileId const& tileId) const override;
		
		uint64_t state() const override { return static_cast<uint64_t>(mConfig.blendMode); }

	private:

		Styling::HillshadeConfig mConfig;

		DemParamsMapT mTerrainParams;

	};

}