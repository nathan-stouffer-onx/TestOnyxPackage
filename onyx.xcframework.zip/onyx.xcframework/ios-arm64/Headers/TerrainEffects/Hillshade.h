#pragma once

#include <Styling/Styles/TerrainConfigs.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx::TerrainEffects
{

	class Hillshade final : public TerrainEffectBase
	{
	public:

		Hillshade() = default;
		~Hillshade() = default;

		void update(Styling::HillshadeConfig const& config, Args const& args);

		void setParameters(Shaders::ShaderDefinition& shader, Tiles::TileId const& tileId) const override;

	private:

		Styling::HillshadeConfig mConfig;

	};

}