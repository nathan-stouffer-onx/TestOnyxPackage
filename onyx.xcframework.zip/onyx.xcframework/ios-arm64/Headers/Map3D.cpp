// Map3D.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "Map3D.h"

#include <cstdlib>
#include <iostream>
#include <functional>

#include <bx/math.h>
#include <bx/timer.h>
#include <bgfx/bgfx.h>
#include <bgfx/platform.h>
#include <bx/bx.h>
#include <bx/file.h>
#include <bx/string.h>

#include <3rdParty/sole/ourSole.h>
#include <Logging/LogManager.h>

#include "Caching/TileCache.h"
#include "Caching/TileRequester.h"
#include "Demo/DemoManager.h"
#include "Atlases/TextureAtlas.h"
#include "Height/HeightManager.h"
#include "Tiles/TileMesh.h"
#include "Events/Events.h"

#include "DataObjects/LabelManager.h"
#include "DataObjects/DashStyleManager.h"
#include "DataObjects/UserMarkupManager.h"
#include "Rendering/VertStructs.h"
#include "Drawers/Drawers.h"

#include "Shaders/ShaderParameters.h"
#include "Shaders/ShaderManager.h"
#include "Utils/jsonConversion.h"
#include "Utils/TextUtils.h"
#include "Utils/Timer.h"
#include "General/RenderTargetManager.h"
#include "Viewport/ViewportManager.h"
#include "TerrainEffects/Viewshed.h"

#include <json/ShaderLib.h>
#include "Config/ConfigManager.h"

#if defined(PLATFORM_WINDOWS)
char const* sPlatform = "Windows";
#elif defined(PLATFORM_OSX)
char const* sPlatform = "OSX";
#elif defined(PLATFORM_ANDROID)
char const* sPlatform = "Android";
#elif defined(PLATFORM_IOS)
char const* sPlatform = "iOS";
#elif defined(PLATFORM_EMSCRIPTEN)
char const* sPlatform = "Emscripten";
#else
char const* sPlatform = "Unknown";
#endif

//#define BGFX_CONFIG_DEBUG 1
//#define ENABLE_MSAA
int Map3D::mCurrentFrame = -1;

#define wayptMgr WaypointManager::Instance()
// TODO find a cleaner way to signal that something went wrong. this define just gives us
// an easy way to make sure we always return the same thing. but I think we need to change
// the architecture a bit to use some other signaling method
template<typename T>
static lucid::math::Vector<T, 3> badVec3() { return lucid::math::Vector<T, 3>(T(0.0), T(0.0), T(onyx::MapMath::cBadHeight)); }
template<typename T>
static lucid::math::Vector<T, 2> badVec2() { return lucid::math::Vector<T, 2>(T(-1000.0), T(-1000.0)); }

namespace caching = onyx::Caching;
namespace tiles = onyx::Tiles;
namespace events = onyx::Events;

Map3D::Map3D()
{
	logI("Map3D starting up.  Build date: %s %s", __DATE__, __TIME__);
	logI("Handle: 0x%x", (void*) this);
}

Map3D::~Map3D()
{
}


//TODO scott These ultimately should probably live somewhere else but will work
//			 here as a proof of concept for now.

extern const uint8_t s_robotoRegularTtf[];
extern const size_t s_robotoRegularTtf_size;

extern const uint8_t s_robotoMonoRegularTtf[];
extern const size_t s_robotoMonoRegularTtf_size;

int Map3D::init(uint32_t width, uint32_t height, void* window, bgfx::RendererType::Enum rendererType, void* device)
{
	logI("onyx Core Starting Up (%s); %d x %d", sPlatform, width, height);
#ifndef WEBGLUX_CONFIG_DEBUG //only do this on multithreaded platforms - maybe not needed? not sure...
//	bgfx::renderFrame();
#endif

	// Initialize bgfx using the native window handle and window resolution.
	bgfx::Init init;
	init.platformData.nwh = window;
	init.resolution.width = width;
	init.resolution.height = height;

#ifdef ENABLE_MSAA
	init.resolution.reset = BGFX_RESET_MSAA_X4;
#else
	init.resolution.reset = BGFX_RESET_NONE;
#endif

	//For Metal, we also need to pass "device" into pd.context
    //https://github.com/bkaradzic/bgfx/blob/master/examples/common/entry/entry_ios.mm#L180
	if (device)
	{
		init.platformData.context = device;
	}

	init.type = rendererType;

    if (init.type == bgfx::RendererType::Metal)
    {
        //For Metal, we also need to pass "device" into pd.context
        //https://github.com/bkaradzic/bgfx/blob/master/examples/common/entry/entry_ios.mm#L180
        if (device)
        {
            init.platformData.context = device;
        }
    }

	init.callback = onyx::core::FileSystem::getDefaultCallback();

	bgfx::setPlatformData(init.platformData);

	if (!bgfx::init(init))
	{
		return 1;
	}

	onyx::ConfigManager::Instance()->loadJson();

	DemoManager::Instance()->setMap3d(this);

	onyx::DataObjects::DashStyleManager::add("solid", { 0xFF });
	onyx::DataObjects::DashStyleManager::add("dotted", { 64 + 16 + 4 + 1 });
	onyx::DataObjects::DashStyleManager::add("dashed", { 0x0F });

	onyx::Rendering::VertStructs::initialize();
	onyx::Utils::Timer::initialize();
	lucid::core::Profiler::initialize();

	mPrevTimeMS = utils::Timer::nowMS();

	logI("onyx Core initializing fonts");

	FontManager::FontConfiguration config;

	config.fileName = "roboto regular";
	config.fontBytes = s_robotoRegularTtf;
	config.fontDataSize = s_robotoRegularTtf_size;

	config.typefaceIndex = 0;
	config.pixelSize = 12;
	config.fontType = FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE;
	config.glyphWidthPadding = (6 + 2);
	config.glyphHeightPadding = (6 + 2);

	onyx::Font::M3DFontManager::initialize(config);
	onyx::Font::M3DFontManager::addFontConfig({ "topoLabel", FONT_TYPE_DISTANCE_OUTLINE, 9 }, "default");
	onyx::Font::M3DFontManager::addTTF("roboto mono", s_robotoMonoRegularTtf, s_robotoMonoRegularTtf_size);

	logI("onyx Core initializing default viewports");
	// TODO maybe move to platform?
	ViewportManager::Instance()->init(width, height);
	ViewportManager::Instance()->addViewport("main", 1.0f, 1.0f, -1);

	/*
	ViewportManager::Instance()->addViewport("pip", 0.25f, 0.25f, initial, 1);
	//ViewportManager::Instance()->addViewport("pip", width * 0.5f, mHeight, pipCam);
	ViewportManager::Instance()->getViewport("pip")->hasBorder = true;
	
	//ViewportManager::Instance()->getViewport("pip")->setPosX(width / 2);
	ViewportManager::Instance()->getViewport("pip")->setPosX(50);
	ViewportManager::Instance()->getViewport("pip")->setPosY((float)(height - 50 - (height / 4)));
	*/

	initialized = true;

	logI("onyx Core initialization complete");

	/*uncomment to save out a test copy of constants json
	nlohmann::json j;
	onyx::ConfigManager::Instance()->addConstant("a:b:c", 123, onyx::ConfigHolder::ConfigType::vInt);
	onyx::ConfigManager::Instance()->to_json(j);
	std::string jText = j.dump(4);
	BgfxUtils::saveText("test.json", jText);*/

	return 0;
}

void Map3D::resize(uint32_t width, uint32_t height)
{
#ifdef ENABLE_MSAA
	bgfx::reset(width, height, BGFX_RESET_MSAA_X4);
#else
	bgfx::reset(width, height, BGFX_RESET_NONE);
#endif
	ViewportManager::Instance()->setScreenSize(width, height);
}

lucid::math::Vector<uint32_t, 2> Map3D::getScreenSize() const
{
	return ViewportManager::Instance()->getScreenSize();
}

void Map3D::setController(std::string viewportName, std::shared_ptr<onyx::Camera::CameraController>& controller)
{
	ViewportManager::Instance()->setController(viewportName, controller);
}

void Map3D::render()
{
	if (!initialized)
	{
		logE("need init");
		return;
	}

	LUCID_PROFILER_FRAME();

	{
		LUCID_PROFILE_SCOPE("render");

		auto timeMS = utils::Timer::nowMS();
		auto timeStepMS = timeMS - mPrevTimeMS;
		mPrevTimeMS = timeMS;

		bx::Vec3 timeVec = bx::Vec3((float)timeMS, (float)timeStepMS, 0);

		ShaderManager::Instance()->setAllShaderUniforms("u_time", timeVec);

		// reset view ids for render passes
		onyx::Rendering::ViewId::reset();
		// reset the blit count in all atlases
		onyx::Atlases::BlitCap::Reset();

		{
			LUCID_PROFILE_SCOPE("cache update");
			onyx::Caching::TileCache::Instance()->update();
		}

		{
			LUCID_PROFILE_SCOPE("manager updates");
			mInput->update(timeMS);
			DemoManager::Instance()->update(float(timeStepMS / 1000.0f));
			WaypointManager::Instance()->update();
			TrackerManager::Instance()->update();
			//LabelManager::Instance()->update();
		}

		{
			LUCID_PROFILE_SCOPE("viewport update");
			ViewportManager::Instance()->updateViewports(timeMS);
			ViewportManager::Instance()->drawViewportsToScreen();
		}

		{
			LUCID_PROFILE_SCOPE("rtt update");
			RenderTargetManager::Instance()->update();
		}
	}

	bgfx::dbgTextClear();
	uint16_t lineNum = 2;
	if (mShowDebugInfo)
	{
		lineNum = writeDebugInfo(0, lineNum);
	}

	if (mShowProfiling)
	{
		bgfx::dbgTextPrintf(0, lineNum++, 0x4F, "Profiling:");
		auto prof = lucid::core::Profiler::instance();
		auto sample = prof->samples();

		bool log = false;
		if (mFrameTimeHistorySeconds.primed())
		{
			auto avg = mFrameTimeHistorySeconds.avg();
			bgfx::dbgTextPrintf(20, lineNum++, 0x4F, "%0.3fms avg frame time", avg * 1000);

			if (sample->timeTotal > avg * 2.0 && sample->timeTotal > 0.01666) // If we get a frame hitch, report the profile statistics
			{
				logI("Long-running frame detected; %0.3fms (running avg %0.3fms) ", sample->timeTotal * 1000, avg * 1000);
				log = true;
			}
		}

		writeProfiling(2, lineNum, sample, log);
	}
}

uint16_t Map3D::writeDebugInfo(uint16_t x, uint16_t y)
{
	// Enable stats or debug text.
	bgfx::setDebug(showStats ? BGFX_DEBUG_STATS : BGFX_DEBUG_TEXT);

	// general bgfx info
	const bgfx::Stats* stats = bgfx::getStats();
	bgfx::dbgTextPrintf(x, y++, 0x2f, "Press F1 to toggle stats");
	bgfx::dbgTextPrintf(x, y++, 0x2f, "Backbuffer %dW x %dH in pixels, debug text %dW x %dH in characters", stats->width, stats->height, stats->textWidth, stats->textHeight);
	bgfx::dbgTextPrintf(x, y++, 0x2f, "avg frame time (ms): %f", mFrameTimeHistorySeconds.avg() * 1000.0);
	bgfx::dbgTextPrintf(x, y++, 0x2f, "avg fps: %f", 1.0 / mFrameTimeHistorySeconds.avg());

	return y;
}

uint16_t Map3D::writeProfiling(uint16_t x, uint16_t y, const lucid::core::Profiler::Sample* sample, bool log)
{
	auto callTime = sample->onlyParent->timeTotal;
	uint16_t result = 0;
	if (sample->count > 0)
	{
		uint8_t color = 0x3a;
		if (callTime == 0)
		{
			color = 0x3f;
		}
		else if (callTime * 0.75 < sample->timeTotal)
		{
			color = 0x3c;
		}
		else if (callTime * 0.5 < sample->timeTotal)
		{
			color = 0x3e;
		}
		else if (callTime * 0.25 < sample->timeTotal)
		{
			color = 0x3a;
		}
		++result;

		auto totalMs = sample->timeTotal * 1000;
		auto pct = sample->onlyParent->timeTotal > 0 ? (sample->timeTotal / sample->onlyParent->timeTotal) * 100.0 : 100;
		if (log)
		{
			std::stringstream tabBuilder;

			for (int i = 0; i < x / 2; ++i)
			{
				tabBuilder << '\t';
			}

			auto tabs = tabBuilder.str();
			logI("%s%s: %0.5fms\t(%d)\t%0.2f%%", tabs.c_str(), sample->name, totalMs, sample->count, pct);
		}

		bgfx::dbgTextPrintf(x, y, 0x3F, "%s:", sample->name);
		bgfx::dbgTextPrintf(x + 32, y, color, "%0.5fms (%d)", totalMs, sample->count);
		bgfx::dbgTextPrintf(x + 50, y, color, "%0.2f%%", pct);

		if (sample->firstChild != nullptr && sample->firstChild->count > 0)
		{
			result += writeProfiling(x + 2, y + 1, sample->firstChild, log);
		}
	}
	if (sample->nextSibling != nullptr)
	{
		result += writeProfiling(x, y + result, sample->nextSibling, log);
	}
	return result;
}

void Map3D::finishFrame()
{
	// Advance to next frame. Process submitted rendering primitives.
	mCurrentFrame = bgfx::frame();

	// compute frame time
	// QUESTION: do we need to rework this for the multithreaded render?
	auto endMS = utils::Timer::nowMS();
	auto durationSeconds = (endMS - mPrevTimeMS) / 1000.0;

	mFrameTimeHistorySeconds.insert(durationSeconds);

	events::trigger(events::EventType::FRAME);

	if (mFrameTimeHistorySeconds.primed())
	{
		// if we are well above the average and above 25 ms, trigger a long frame event
		if (durationSeconds > 2.0 * mFrameTimeHistorySeconds.avg() && durationSeconds > 0.025)
		{
			events::trigger(events::EventType::LONG_FRAME);
		}
	}
}

void Map3D::shutdown()
{
	// clean up singletons

	logI("--- Shutting down Map3D ---");
	logI("Shutting down TileCache");
	onyx::Caching::TileCache::Shutdown();

	logI("Shutting down DemoManager");
	delete DemoManager::Instance();

	logI("Shutting down ShaderManager");
	delete ShaderManager::Instance();

	logI("Shutting down TileMesh");
	onyx::Tiles::TileMesh::Shutdown();

	logI("Shutting down WaypointManager");
	WaypointManager::Shutdown();

	logI("Shutting down TrackerManager");
	TrackerManager::Shutdown();
	
	logI("Shutting down HeightManager");
	HeightManager::Shutdown();

	logI("Shutting down UserMarkupManager");
	onyx::DataObjects::UserMarkupManager::Shutdown();

	logI("Shutting down DashStyleManager");
	onyx::DataObjects::DashStyleManager::Shutdown();

	logI("Shutting down FontStyleManager");
	onyx::Style::FontStyleManager::Shutdown();

	logI("Shutting down FontManager");
	onyx::Font::M3DFontManager::Shutdown();

	logI("Shutting down RenderTargetManager");
	delete RenderTargetManager::Instance();

	logI("Shutting down ViewportManager");
	ViewportManager::Shutdown();

	logI("Shutting down FrustumDrawer");
	drawers::FrustumDrawer::shutdown();

	logI("Shutting down AABoxDrawer");
	drawers::AABoxDrawer::shutdown();

	logI("Shutting down ViewId");
	onyx::Rendering::ViewId::shutdown();

	logI("Shutting down ::events");
	events::shutdown();

	logI("Shutting down ConfigManager");
	delete onyx::ConfigManager::Instance();

	logI("Shutting down ::FileSystem");
	onyx::core::FileSystem::cleanup();

	logI("Shutting down ::BgfxUtils");
	BgfxUtils::cleanup();

	logI("Shutting down ::bgfx");
	bgfx::shutdown();

	logI("Shutting down Profiler");
	lucid::core::Profiler::shutdown();

	logI("Shutting down LogManager");
	onyx::core::LogManager::Shutdown();
}

void Map3D::toggleCulling(bool on)
{
	onyx::Viewport* vp = ViewportManager::Instance()->getViewport("main");
	if (vp != NULL)
		vp->setCullingEnabled(on);
}

void Map3D::toggleIntersectTerrain(bool on)
{
	auto* vp = ViewportManager::Instance()->getViewport("main");
	// NOTE: separating this out into two cases so we don't load shaders that don't exist
	if (on)
	{
		// toggle the individual components
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "HeightShade", false);
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeShade", false);
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeDirection", false);
		// toggle the intersection component
		vp->setIntersectTerrain(on);
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "IntersectTerrain", true);
	}
	else
	{
		// toggle the intersection component
		vp->setIntersectTerrain(on);
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "IntersectTerrain", false);
		// toggle the individual components
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "HeightShade", vp->getHeightRangesOn());
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeShade", vp->getSlopeAngleRangesOn());
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeDirection", vp->getSlopeDirRangesOn());
	}
}

bool Map3D::isIntersectTerrainOn()
{
	return ViewportManager::Instance()->getViewport("main")->getIntersectTerrain();
}

void Map3D::toggleHeightRanges(bool on)
{
	ViewportManager::Instance()->getViewport("main")->toggleHeightRanges(on);
	ViewportManager::Instance()->getViewport("main")->invalidate();
	if (!ViewportManager::Instance()->getViewport("main")->getIntersectTerrain())
	{
		ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "HeightShade", on);
	}
}

bool Map3D::isHeightRangesOn()
{
	return ViewportManager::Instance()->getViewport("main")->getHeightRangesOn();
}

void Map3D::toggleSlopeAngleRanges(bool on)
{
	ViewportManager::Instance()->getViewport("main")->toggleSlopeAngleRanges(on);
	ViewportManager::Instance()->getViewport("main")->invalidate();
	if (!ViewportManager::Instance()->getViewport("main")->getIntersectTerrain())
	{
		ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeShade", on);
	}
}

bool Map3D::isSlopeAngleRangesOn()
{
	return ViewportManager::Instance()->getViewport("main")->getSlopeAngleRangesOn();
}

void Map3D::toggleSlopeDirRanges(bool on)
{
	ViewportManager::Instance()->getViewport("main")->toggleSlopeDirRanges(on);
	ViewportManager::Instance()->getViewport("main")->invalidate();
	if (!ViewportManager::Instance()->getViewport("main")->getIntersectTerrain())
	{
		ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeDirection", on);
	}
}

bool Map3D::isSlopeDirRangesOn()
{
	return ViewportManager::Instance()->getViewport("main")->getSlopeDirRangesOn();
}

void Map3D::setHeightRanges(std::vector<lgal::world::Range> const& ranges)
{
	ViewportManager::Instance()->getViewport("main")->setHeightRanges(ranges);
}

void Map3D::setSlopeAngleRanges(std::vector<lgal::world::Range> const& ranges)
{
	ViewportManager::Instance()->getViewport("main")->setSlopeAngleRanges(ranges);
}

// 0 degrees == north, going counterclockwise
void Map3D::setSlopeDirRanges(std::vector<lgal::world::Range> const& ranges)
{
	ViewportManager::Instance()->getViewport("main")->setSlopeDirRanges(ranges);
}

void Map3D::setHeightScale(float scale)
{
	ViewportManager::Instance()->getViewport("main")->setTerrainExaggeration(scale);
}

void Map3D::setShowStats(bool b)
{
	showStats = b;

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataBool = b;
		step.stepAction = DemoAction::SetShowStats;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::setStyle(std::string const& viewport, std::shared_ptr<onyx::Styling::Style> style)
{
	ViewportManager::Instance()->getViewport(viewport)->setStyle(style);
}

void Map3D::loadShaders(std::string const& path)
{
	logI("load signatures");
	auto signatures = ShaderManager::Instance()->loadSignatures(path);
	logI("add signatures");
	ShaderManager::Instance()->addShaderSignatures(signatures);
	logI("load shaders");
	ShaderManager::Instance()->loadShaders();
	logI("shaders loaded");
}

void Map3D::initLabelManager(FontManager::FontConfiguration const& /*defaultFont*/)
{
	//LabelManager::Instance()->initialize(defaultFont);
}

std::vector<ShaderParam*> Map3D::getAllShaderParameters()
{
	return ShaderManager::Instance()->collectAllPossibleParameters();
}

void Map3D::setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, onyx::Shaders::ValueBag const& configuration)
{
	ShaderManager::Instance()->setCurrentShaderByParams(shader, params, configuration);

	DemoManager::Instance()->recordShaderState(shader);
}

std::vector<ShaderParam*> Map3D::getActiveShaderParameters(ShaderEnums::ConfigurableShaders shader)
{
	return ShaderManager::Instance()->getActiveParameters(shader);
}

lgal::world::Vector3 Map3D::unproject(int clickX, int clickY)
{
	auto vp = ViewportManager::Instance()->getViewport("main");
	return vp->unprojectPixel(clickX, clickY);
}

lgal::world::Vector2 Map3D::project(lgal::world::Vector3 const& pos)
{
	auto vp = ViewportManager::Instance()->getViewport("main");
	if (vp == NULL)
		return badVec2<world_float_t>();

	auto normalizedScreenCoords = vp->project(pos);
	return { normalizedScreenCoords.x, normalizedScreenCoords.y };
}

std::string Map3D::getWaypointUuid(int pixX, int pixY)
{
	auto pos = ViewportManager::Instance()->getViewport("main")->unprojectPixel(pixX, pixY);
	sole::uuid uuid = WaypointManager::Instance()->getWaypointUuid(lgal::toBx(pos));
	return (isNullUuid(uuid)) ? "" : uuid.str();
}

void Map3D::loadWaypoint(nlohmann::json json)
{
	WaypointManager::Instance()->addWaypoint(json);
	ViewportManager::Instance()->invalidate();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = std::string(json.dump());
		step.stepAction = DemoAction::LoadWaypoint;

		DemoManager::Instance()->addStep(step);
	}
}

WaypointManager::sharedWaypoint_t Map3D::addWaypoint(std::string uuidStr, lgal::world::Vector3 const & worldPos, lgal::Color const& color)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	return addWaypoint(uuid, worldPos, color);
}

WaypointManager::sharedWaypoint_t Map3D::addWaypoint(sole::uuid const& id, lgal::world::Vector3 const & worldPos, lgal::Color const& color)
{
	auto result = WaypointManager::Instance()->addWaypoint(id, lgal::toBx(worldPos), color);
	ViewportManager::Instance()->invalidate();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = id.str();
		step.dataVec3 = lgal::toBx(worldPos);
		step.stepAction = DemoAction::AddWaypoint; //Question - how to keep this from causing issues with account data if we run a test that adds waypoints?

		DemoManager::Instance()->addStep(step);
	}
	return result;
}

WaypointManager::sharedWaypoint_t Map3D::getWaypoint(sole::uuid const &id)
{
	return wayptMgr->getWaypoint(id);
}

void Map3D::selectWaypoint(std::string uuidStr)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->selectWaypoint(uuid);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuidStr;
		step.stepAction = DemoAction::SelectWaypoint;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::unselectWaypoint(std::string uuidStr)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->unselectWaypoint(uuid);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuidStr;
		step.stepAction = DemoAction::UnselectWaypoint;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::unselectAllWaypoints()
{
	WaypointManager::Instance()->unselectAllWaypoints();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.stepAction = DemoAction::UnselectAllWaypoints;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::moveWaypointTo(std::string uuidStr, int pixX, int pixY)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	auto prevPos = WaypointManager::Instance()->getWaypointPosition(uuid);
	auto pos = ViewportManager::Instance()->getViewport("main")->unprojectPixel(pixX, pixY);
	WaypointManager::Instance()->moveWaypointTo(uuid, lgal::toBx(pos));
	ViewportManager::Instance()->invalidate();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.moveTo = lgal::toBx(pos);
		step.dataVec3 = prevPos;
		step.dataString = uuidStr;
		step.stepAction = DemoAction::MoveWaypointTo;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::moveWaypointTo(std::string uuidStr, lgal::world::Vector3 const & pos)
{
	moveWaypointTo(sole::rebuild(uuidStr), pos);
}

void Map3D::moveWaypointTo(sole::uuid const& uuid, lgal::world::Vector3 const& pos)
{
	auto prevPos = WaypointManager::Instance()->getWaypointPosition(uuid);;
	WaypointManager::Instance()->moveWaypointTo(uuid, lgal::toBx(pos));
	ViewportManager::Instance()->invalidate();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.moveTo = lgal::toBx(pos);
		step.dataVec3 = prevPos;
		step.dataString = uuid.str();
		step.stepAction = DemoAction::MoveWaypointTo;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::setWaypointIcon(std::string uuidStr, std::string icon)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->setWaypointIcon(uuid, icon);

	if (DemoManager::Instance()->isRecording())
	{
		nlohmann::json j;
		j["uuidStr"] = uuidStr;
		j["icon"] = icon;

		DemoStep step;
		step.dataString = j.dump();
		step.stepAction = DemoAction::SetWaypointIcon;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::setWaypointIconColor(std::string uuidStr, lgal::Color color)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->setIconColor(uuid, color);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuidStr;
		step.dataVec3 = { color.r, color.g, color.b };
		step.dataFloat = color.a;
		step.stepAction = DemoAction::SetWaypointIconColor;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::setWaypointDiskColor(std::string uuidStr, lgal::Color color)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->setDiskColor(uuid, color);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuidStr;
		step.dataVec3 = { color.r, color.g, color.b };
		step.dataFloat = color.a;
		step.stepAction = DemoAction::SetWaypointDiskColor;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::setWaypointBodyColor(std::string uuidStr, lgal::Color color)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->setBodyColor(uuid, color);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuidStr;
		step.dataVec3 = { color.r, color.g, color.b };
		step.dataFloat = color.a;
		step.stepAction = DemoAction::SetWaypointBodyColor;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::setWaypointOutlineColor(std::string uuidStr, lgal::Color color)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	WaypointManager::Instance()->setOutlineColor(uuid, color);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuidStr;
		step.dataVec3 = { color.r, color.g, color.b };
		step.dataFloat = color.a;
		step.stepAction = DemoAction::SetWaypointOutlineColor;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::clearWaypoints()
{
	WaypointManager::Instance()->clearWaypoints();
}

void Map3D::deleteWaypoint(std::string uuidStr)
{
	sole::uuid uuid = sole::rebuild(uuidStr);
	deleteWaypoint(uuid);
}

void Map3D::deleteWaypoint(sole::uuid const& uuid)
{
	WaypointManager::Instance()->deleteWaypoint(uuid);
	ViewportManager::Instance()->invalidate();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = uuid.str();
		step.stepAction = DemoAction::DeleteWaypoint;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::deleteSelectedWaypoints()
{
	WaypointManager::Instance()->deleteSelectedWaypoints();

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.stepAction = DemoAction::DeleteSelectedWaypoints;

		DemoManager::Instance()->addStep(step);
	}
}

void Map3D::generateRandomWaypoints(int count)
{
	for (int i = 0; i < count; i++)
	{
		auto uuid = onyx::Utils::getUuid();
		auto x = float((rand() & 0x7FFF) - 0x3FFF) / float(0x7FFF);
		auto y = float((rand() & 0x7FFF) - 0x3FFF) / float(0x7FFF);
		auto pos = lgal::world::Vector3(x * onyx::Tiles::cMaxExtent, y * onyx::Tiles::cMaxExtent, 0);
		addWaypoint(uuid.str(), pos, 0xFFFF3300);
	}
}

Tracker* Map3D::addTracker(sole::uuid const& id, onyx::MapMath::LonLat const& coords, TrackerType type)
{
	return addTracker(id, coords.toWorldPos(), type);
}

Tracker* Map3D::addTracker(sole::uuid const& id, lgal::world::Vector2 const& worldPos, TrackerType type)
{
	return TrackerManager::Instance()->addTracker(id, worldPos, type);
}

Tracker* Map3D::getTracker(sole::uuid const& id)
{
	return TrackerManager::Instance()->getActiveTracker(id);
}

tiles::TileId Map3D::getActiveTileAtPosition(lgal::world::Vector3 const & /*worldPos*/)
{
	//TODO TileCache fix
	return { -1, -1, -1 };
//	Tile* t = mTileLayers["base"]->getTileAtPos(worldPos);
//	return t;
}

void Map3D::loadDemoJson(std::string path)
{
	std::string data = onyx::core::FileSystem::readText(path);
	size_t tempfix = data.find_last_of(']');
	data = data.substr(0, tempfix + 1);
	nlohmann::json j = nlohmann::json::parse(data);
	DemoManager::Instance()->from_json(j);
}

void Map3D::saveDemoJson(std::string path)
{
	nlohmann::json j = DemoManager::Instance()->to_json();
	std::string data = j.dump();
	onyx::core::FileSystem::saveText(path, data);
}

void Map3D::startDemo()
{
	DemoManager::Instance()->startDemo();
}

void Map3D::startRecordingDemo()
{
	if (!DemoManager::Instance()->isRecording())
		DemoManager::Instance()->startRecording();
	else
		DemoManager::Instance()->stopRecording();
}

bool Map3D::isRecordingDemo()
{
	return DemoManager::Instance()->isRecording();
}

void Map3D::setTileLod(std::string const& viewportName, float lod)
{
	mLODScaler = lod;
	auto* vp = ViewportManager::Instance()->getViewport(viewportName);
	vp->setTileLod(lod);

	if (DemoManager::Instance()->isRecording())
	{
		DemoStep step;
		step.dataString = viewportName;
		step.dataFloat = lod;
		step.stepAction = DemoAction::ChangeLod;

		DemoManager::Instance()->addStep(step);
	}
}

double Map3D::tileLoadTimeMS(std::string const& viewport) const
{
	auto vp = ViewportManager::Instance()->getViewport(viewport);
	return vp->tileLoadTimeMS();
}

std::vector<onyx::Tiles::TileId> Map3D::recentTiles(double windowMS) const
{
	return caching::TileCache::Instance()->recentTiles(windowMS);
}

float Map3D::heightAt(lgal::world::Vector2 const& pos) const
{
	return HeightManager::Instance()->heightAt(pos, false);
}

void Map3D::addLabel(lgal::world::Vector3 const & /*pos*/, std::string /*text*/)
{
	//LabelManager::Instance()->addLabel(pos, text);
}

//gathers a lot of information about the state of everything, and returns it as a big json file - pretty much anything that might be useful to know, we should probably add in here
nlohmann::json Map3D::getDebugState(bool includeTiles, bool /*includeAtlas*/, bool includeWaypoints, bool includeShaders)
{
	onyx::ViewportState* vp = ViewportManager::Instance()->getViewportState("main");
	onyx::Pyramid::CullResult const& cullRes = vp->mCullState;
	nlohmann::json j;
	j["Initialized"] = initialized;
	j["averageFPS"] = 1.0 / mFrameTimeHistorySeconds.avg();
	j["CurrentFrame"] = mCurrentFrame;
	j["RenderWidth"] = vp->getWidthPixel();
	j["RenderHeight"] = vp->getHeightPixel();
	j["TileTouchedCount"] = cullRes.touched;
	j["TileRenderCount"] = cullRes.tileIds.size();
	j["TileMinVisLevel"] = cullRes.minLevel;
	j["TileMaxVisLevel"] = cullRes.maxLevel;
	j["TileMaxExtents"] = onyx::Tiles::cMaxExtent;
	j["TileMaxSubdDepth"] = mMaxSubdDepth;

	if (includeTiles)
	{
		// TODO Fix json serialization for Tiles::LayerInfo
//		j["tileLayers"] = mTileLayers;
	}

	//TODO hook this back up
	//if (includeAtlas)
	//{
	//	for (const auto& [texType, atlas] : mTexAtlases)
	//	{
	//		int i = static_cast<int>(texType);
	//		j["textureAtlas_" + std::to_string(i)] = *atlas;
	//	}
	//	for (const auto& [vecType, atlas] : mVecAtlases)
	//	{
	//		int i = static_cast<int>(vecType);
	//		j["vectorAtlas_" + std::to_string(i)] = *atlas;
	//	}
	//}

	if (includeWaypoints)
	{
		j["waypoints"] = WaypointManager::Instance();
	}

	if (includeShaders)
	{
		j["shaderManager"] = ShaderManager::Instance();
	}
	return j;
}

void Map3D::toggleViewshed(std::string const& viewportName, bool on, bool inverted)
{
	auto vp = ViewportManager::Instance()->getViewport(viewportName);
	if (vp == nullptr)
	{
		return;
	}

	auto vpState = vp->getState();
	vpState->toggleViewshed(on, inverted);
	auto position = vp->unprojectNormalized(lgal::world::Vector2{ 0, 0 });
	vpState->setViewshedPosition(position.xy);

	if (!inverted)
	{
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "Viewshed", on);
		ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "Viewshed", on);
	}
	else
	{
		vp->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "InvertedViewshed", on);
		ShaderManager::Instance()->toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "InvertedViewshed", on);
	}
}

bool Map3D::getViewshedEnabled(std::string const& viewportName)
{
	auto vp = ViewportManager::Instance()->getViewport(viewportName);
	return vp->getState()->getViewshedEnabled();
}

//TODO redesign all of this after proof-of-concept is working
void Map3D::addViewshed(std::string const& viewportName, lgal::world::Vector2 const & pos)
{
	auto vp = ViewportManager::Instance()->getViewport(viewportName);

	if (vp == nullptr)
	{
		return;
	}

	auto vpState = vp->getState();

	vpState->addViewshed(pos);
}

void Map3D::setViewshedOffset(std::string const& viewportName, world_float_t offset)
{
	setViewportContext(viewportName, "viewshedOffset0", offset);
}

void Map3D::setViewshedPosition(std::string const& viewportName, lgal::world::Vector2 const& pos)
{
	setViewportContext(viewportName, "viewshedPosition0", pos);
}

lgal::world::Vector2 Map3D::getViewshedPosition(std::string const& viewportName)
{
	return getViewportContext<lgal::world::Vector2>(viewportName, "viewshedPosition0");
}

float Map3D::getViewshedRange(std::string const& viewportName)
{
	return (float)getViewportContext<world_float_t>(viewportName, "viewshedRange0");
}

void Map3D::setViewshedRange(std::string const& viewportName, world_float_t range)
{
	setViewportContext(viewportName, "viewshedRange0", range);
}

double Map3D::getInputSensitivity()
{
	return mInput->getSensitivity();
}

void Map3D::setInputSensitivity(double value)
{
	mInput->setSensitivity(value);
}

void Map3D::setCameraState(std::string const& viewport, cam::CameraState const& state)
{
	return ViewportManager::Instance()->getViewport(viewport)->setCameraState(state);
}

std::shared_ptr<onyx::Camera::CameraController> Map3D::getController(float x, float y) const
{
	return ViewportManager::Instance()->getController((int)x, (int)y);
}

cam::CameraState Map3D::getCameraState(float x, float y) const
{
	auto vp = ViewportManager::Instance()->getViewportByPixel((int)x, (int)y);
	if (vp == NULL)
		return cam::CameraState();
	return vp->getCameraState();
}

cam::CameraState Map3D::getCameraState(std::string const& name) const
{
	return ViewportManager::Instance()->getViewport(name)->getCameraState();
}

onyx::Pyramid::CullResult Map3D::getCullResult(std::string const& name) const
{
	return ViewportManager::Instance()->getViewportState(name)->getCullResult();
}

lgal::world::Vector3 Map3D::getViewportPosition(float x, float y)
{
	auto vp = ViewportManager::Instance()->getViewportByPixel((int)x, (int)y);
	if (vp == NULL)
		return { 0, 0, 0 };
	return { vp->getPosX(), vp->getPosY(), 0 };
}

lgal::world::Vector3 Map3D::getViewportPosition(std::string name)
{
	auto vp = ViewportManager::Instance()->getViewport(name);
	return { vp->getPosX(), vp->getPosY(), 0 };
}

lgal::world::Vector2 Map3D::getViewportSize(float x, float y)
{
	auto vp = ViewportManager::Instance()->getViewportByPixel((int)x, (int)y);
	if (vp == NULL)
		return { 0, 0 };
	return { vp->getWidthPixel(), vp->getHeightPixel() };
}

lgal::world::Vector2 Map3D::getViewportSize(std::string name)
{
	auto vp = ViewportManager::Instance()->getViewport(name);
	return { vp->getWidthPixel(), vp->getHeightPixel() };
}

void Map3D::setTopoEnable(std::string name, bool on)
{
	ViewportManager::Instance()->getViewport(name)->toggleTopo(on);
}

void Map3D::setTopoMajorColor(std::string name, lgal::Color color)
{
	ViewportManager::Instance()->getViewport(name)->setTopoMajorColor(color);
}

void Map3D::setTopoMinorColor(std::string name, lgal::Color color)
{
	ViewportManager::Instance()->getViewport(name)->setTopoMinorColor(color);
}

void Map3D::setSunlightEnable(std::string vpName, bool on)
{
	ViewportManager::Instance()->getViewport(vpName)->setSunlightEnabled(on);
}

void Map3D::setSunlightTime(std::string vpName, int year, int month, int day, float timezone, float hours24)
{
	ViewportManager::Instance()->getViewport(vpName)->setSunlightTime(year, month, day, timezone, hours24);
}

std::shared_ptr<onyx::Icon::IconRenderer> Map3D::getIconRenderer(std::string const& vpName)
{
	return ViewportManager::Instance()->getViewport(vpName)->getIconRenderer();
}

void Map3D::addDebugIconTile(std::string const& vpName, 
	onyx::Tiles::IconTile const& iconTile)
{
	ViewportManager::Instance()->getViewport(vpName)->addDebugIconTile(iconTile);
}

void Map3D::addDebugIconLayer(std::string const& vpName, 
	std::shared_ptr<onyx::Styling::SymbolLayer const> iconLayer)
{
	ViewportManager::Instance()->getViewport(vpName)->addDebugIconLayer(iconLayer);
}

