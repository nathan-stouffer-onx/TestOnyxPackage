#include "GeoJson.h"

#include <json/jsonParsing.h>

namespace onyx {
namespace GeoJson {

std::shared_ptr<Geometry> makeDeepCopy(std::shared_ptr<Geometry const> const& toCpy)
{
	if (toCpy == nullptr)
	{
		return nullptr;
	}

	auto toCpyType = toCpy->type;
	switch (toCpyType)
	{
		// Cast to derived type and dereference to use copy constructor
		case Geometry::Types::Point:
			return std::make_shared<Point>(*static_cast<Point const*>(toCpy.get()));
		case Geometry::Types::MultiPoint:
			return std::make_shared<MultiPoint>(*static_cast<MultiPoint const*>(toCpy.get()));
		case Geometry::Types::LineString:
			return std::make_shared<LineString>(*static_cast<LineString const*>(toCpy.get()));
		case Geometry::Types::MultiLineString:
			return std::make_shared<MultiLineString>(*static_cast<MultiLineString const*>(toCpy.get()));
		case Geometry::Types::Polygon:
			return std::make_shared<Polygon>(*static_cast<Polygon const*>(toCpy.get()));
		case Geometry::Types::MultiPolygon:
			return std::make_shared<MultiPolygon>(*static_cast<MultiPolygon const*>(toCpy.get()));
		case Geometry::Types::GeometryCollection:	// Not supported yet
		default:
			ONYX_ASSERT(false, "Given Geometry type is not supported");
	}
	// Should never reach this point
	return nullptr;
}

std::shared_ptr<GeoJson> makeDeepCopy(GeoJson const& toCpy)
{
	auto toCpyType = toCpy.type;
	switch (toCpyType)
	{
		case GeoJson::Types::Feature:
		{
			Feature* deepCopyPtr = new Feature{};
			auto const& derivedToCpy = static_cast<Feature const &>(toCpy);

			deepCopyPtr->bounds = toCpy.bounds;
			deepCopyPtr->geometry = makeDeepCopy(derivedToCpy.geometry);
			deepCopyPtr->properties = derivedToCpy.properties;
			return std::shared_ptr<GeoJson>{ deepCopyPtr };
		}
		break;
		case GeoJson::Types::FeatureCollection:
		{
			FeatureCollection* deepCopyPtr = new FeatureCollection{};
			auto const& derivedToCpy = static_cast<FeatureCollection const &>(toCpy);
			deepCopyPtr->bounds = toCpy.bounds;
			for (auto const& feature : derivedToCpy.features)
			{
				auto dCpy = makeDeepCopy(feature);
				ONYX_ASSERT(dCpy->type == GeoJson::Types::Feature, "A FeatureCollection cannot contain a FeatureCollection");
				deepCopyPtr->features.push_back(std::static_pointer_cast<Feature>(dCpy));
			}
			return std::shared_ptr<GeoJson>{ deepCopyPtr };
		}
		break;
		default:
			ONYX_ASSERT(false, "Given GeoJson type is not supported");

	}
}

std::shared_ptr<GeoJson> makeDeepCopy(std::shared_ptr<GeoJson const> const& toCpy)
{
	if (toCpy == nullptr)
	{
		return nullptr;
	}

	return makeDeepCopy(*toCpy);
}

inline lgal::gpu::Vector3 readVertex(std::vector<gpu_float_t> const& values)
{
	ONYX_ASSERT(values.size() >= 2 && values.size() <= 3, "GeoJson coordinates must contain 2 or 3 values");

	return lgal::gpu::Vector3 {
		values[0],
		values[1],
		values.size() == 3 ? values[2] : cInvalidHeight
	};
}

void ReadProperties(const nlohmann::json& j, std::unordered_map<std::string, vector_tile::Tile_Value> &properties)
{
	auto found = j.find("properties");
	if (found == j.end())
		return;

	for (auto& [key, entry] : (*found).items())
	{
		vector_tile::Tile_Value value;
		if (entry.is_boolean())
		{
			value.set_bool_value(entry);
			properties.emplace(key, value);
		}
		else if (entry.is_number())
		{
			if (entry.is_number_integer())
			{
				value.set_int_value(entry);
				properties.emplace(key, value);
			}
			else if (entry.is_number_float())
			{
				value.set_float_value(entry);
				properties.emplace(key, value);
			}
			else if (entry.is_number_unsigned())
			{
				value.set_uint_value(entry);
				properties.emplace(key, value);
			}
		}
		else if (entry.is_string())
		{
			value.set_string_value(entry);
			properties.emplace(key, value);
		}
	}
}

void from_json(const nlohmann::json& j, Point& point)
{
	std::vector<gpu_float_t> values;
	JsonParsing::Require(j, "coordinates", values, "coordinates are required for GeoJson Points");
	point.setPoint(readVertex(values));
}

void to_json(nlohmann::json& /* j */, const Point& /* point */)
{
	ONYX_THROW("Json serialization not implemented for GeoJson::Point");
}

void from_json(const nlohmann::json& j, MultiPoint& multiPoint)
{
	std::vector<std::vector<gpu_float_t>> values;
	JsonParsing::Require(j, "coordinates", values, "coordinates are required for GeoJson MultiPoints");

	if (values.size() < 1)
		return;

	multiPoint.positions.reserve(values.size());

	for (auto const& value : values)
	{
		multiPoint.positions.push_back(readVertex(value));
		multiPoint.boundPoint(multiPoint.positions.back());
	}
}

void to_json(nlohmann::json& /* j */, const MultiPoint& /* multiPoint */)
{
	ONYX_THROW("Json serialization not implemented for GeoJson::MultiPoint");
}

void from_json(const nlohmann::json& j, LineString& lineString)
{
	std::vector<std::vector<gpu_float_t>> values;
	JsonParsing::Require(j, "coordinates", values, "coordinates are required for GeoJson LineStrings");

	if (values.size() < 1)
		return;

	lineString.lineVertices.reserve(values.size());

	for (auto const& value : values)
	{
		lineString.lineVertices.push_back(readVertex(value));
		lineString.boundPoint(lineString.lineVertices.back());
	}
}

void to_json(nlohmann::json& j, const LineString& lineString)
{
	ONYX_ASSERT(lineString.lineVertices.size() >= 2, "in to_json for lineString, lineString should contain >= 2 vertices");
	
	nlohmann::json lsJS;
	lsJS["type"] = "LineString";
	
	for (auto const& vertex : lineString.lineVertices)
	{
		nlohmann::json jsonVert = nlohmann::json::array();
		jsonVert.push_back(vertex.x);
		jsonVert.push_back(vertex.y);
		jsonVert.push_back(vertex.z);
		lsJS["coordinates"].push_back(jsonVert);
	}

	j["geometry"] = lsJS;
}

void from_json(const nlohmann::json& j, MultiLineString& multiLineString)
{
	std::vector<std::vector<std::vector<gpu_float_t>>> lineStrings;
	JsonParsing::Require(j, "coordinates", lineStrings, "coordinates are required for GeoJson MultiLineStrings");

	if (lineStrings.size() < 1)
		return;

	size_t totalCoords = 0;
	for (auto& ls : lineStrings)
	{
		totalCoords += ls.size();
	}

	multiLineString.ranges.reserve(lineStrings.size());
	multiLineString.lineVertices.reserve(totalCoords);

	for (auto const& lineString : lineStrings)
	{
		ONYX_ASSERT(lineString.size() > 0, "Line in multi line string contains no coordinates");
		auto begin = multiLineString.lineVertices.size();
		for (auto const& coords : lineString)
		{
			multiLineString.lineVertices.push_back(readVertex(coords));
			multiLineString.boundPoint(multiLineString.lineVertices.back());
		}

		if (multiLineString.lineVertices.size() != begin)
		{
			multiLineString.ranges.push_back({ begin, multiLineString.lineVertices.size() - 1 });
		}
	}
}

void to_json(nlohmann::json& /* j */, const MultiLineString& /* multiLineString */)
{
	ONYX_THROW("Json serialization not implemented for GeoJson::MultiLineString");
}

void from_json(const nlohmann::json& j, Polygon& polygon)
{
	std::vector<std::vector<std::vector<gpu_float_t>>> polygons;
	JsonParsing::Require(j, "coordinates", polygons, "coordinates are required for GeoJson Polygons");

	if (polygons.size() < 1)
		return;

	size_t totalCoords = 0;
	for (auto& ls : polygons)
	{
		totalCoords += ls.size();
	}

	polygon.ringRanges.reserve(polygons.size());
	polygon.vertices.reserve(totalCoords);

	for (auto const& p : polygons)
	{
		ONYX_ASSERT(p.size() > 0, "Polygon in multi-polygon contains no coordinates");
		auto begin = polygon.vertices.size();
		for (auto const& coords : p)
		{
			polygon.vertices.push_back(readVertex(coords));
			polygon.boundPoint(polygon.vertices.back());
		}

		if (polygon.vertices.size() != begin)
		{
			polygon.ringRanges.push_back({ begin, polygon.vertices.size() - 1 });
		}
	}
}

void to_json(nlohmann::json& /* j */, const Polygon& /* polygon */)
{
	ONYX_THROW("Json serialization not implemented for GeoJson::Polygon");
}

void from_json(const nlohmann::json& j, MultiPolygon& multiPolygon)
{
	std::vector<std::vector<std::vector<std::vector<gpu_float_t>>>> polygons;
	JsonParsing::Require(j, "coordinates", polygons, "coordinates are required for GeoJson MultiPolygons");

	if (polygons.size() < 1)
		return;

	size_t totalRings = 0,
		totalCoords = 0;
	for (auto const& p : polygons)
	{
		totalRings += p.size();
		for (auto const & rings : p)
			totalCoords += rings.size();
	}

	multiPolygon.polygonRanges.reserve(polygons.size());
	multiPolygon.ringRanges.reserve(totalRings);
	multiPolygon.vertices.reserve(totalCoords);

	for (auto const& polygon : polygons)
	{
		auto ringBegin = multiPolygon.ringRanges.size();
		for (auto const& ring : polygon)
		{
			ONYX_ASSERT(polygon.size() > 0, "Polygon in multi-polygon contains no coordinates");
			auto vertBegin = multiPolygon.vertices.size();
			for (auto const& coords : ring)
			{
				multiPolygon.vertices.push_back(readVertex(coords));
				multiPolygon.boundPoint(multiPolygon.vertices.back());
			}

			if (multiPolygon.vertices.size() != vertBegin)
			{
				multiPolygon.ringRanges.push_back({ vertBegin, multiPolygon.vertices.size() - 1 });
			}
		}
		if (multiPolygon.ringRanges.size() != ringBegin)
		{
			multiPolygon.polygonRanges.push_back({ ringBegin, multiPolygon.ringRanges.size() - 1 });
		}
	}
}

void to_json(nlohmann::json& /* j */, const MultiPolygon& /* multiPolygon */)
{
	ONYX_THROW("Json serialization not implemented for GeoJson::MultiPolygon");
}

void from_json(const nlohmann::json& j, Feature& feature)
{
	std::string type;
	JsonParsing::Require(j, "type", type, "'type' is required for feature/feature collection");
	ONYX_ASSERT(type == "Feature", "'type' must be 'Feature' for Feature parsing; received '" + type + "' instead.");
	ReadProperties(j, feature.properties);

	JsonParsing::Require(j, "geometry", "'geometry' value not found");
	
	JsonParsing::Require(j.at("geometry"), "type", type, "'type' is required for geometry");
	auto geomType = std::fromStringView<Geometry::Types>(type);

	switch (geomType)
	{
	case Geometry::Types::Point:
		{
			auto p = new Point();
			feature.geometry.reset(p);
			j.at("geometry").get_to(*p);
		}
		break;
	case Geometry::Types::MultiPoint:
		{
			auto mp = new MultiPoint();
			feature.geometry.reset(mp);
			j.at("geometry").get_to(*mp);
		}
		break;
	case Geometry::Types::LineString:
		{
			auto ls = new LineString();
			feature.geometry.reset(ls);
			j.at("geometry").get_to(*ls);
		}
		break;
	case Geometry::Types::MultiLineString:
		{
			auto mls = new MultiLineString();
			feature.geometry.reset(mls);
			j.at("geometry").get_to(*mls);
		}
		break;

	case Geometry::Types::Polygon:
		{
			auto poly = new Polygon();
			feature.geometry.reset(poly);
			j.at("geometry").get_to(*poly);
		}
		break;

	case Geometry::Types::MultiPolygon:
		{
			auto mpoly = new MultiPolygon();
			feature.geometry.reset(mpoly);
			j.at("geometry").get_to(*mpoly);
		}
		break;

	default:
		ONYX_THROW("Unrecognized geometry type");
	}

	feature.bounds = feature.geometry->bounds;
}

void to_json(nlohmann::json& j, const Feature& feature)
{
	j["type"] = "Feature";
	
	// TODO write out properties

	auto const& geo = feature.geometry;
	if (geo == nullptr)
	{
		return;
	}

	nlohmann::json geoJS;
	switch (geo->type)
	{
	case Geometry::Types::Point:
	{
		geoJS = *std::static_pointer_cast<Point const>(geo);
	}
	break;
	case Geometry::Types::MultiPoint:
	{
		geoJS = *std::static_pointer_cast<MultiPoint const>(geo);
	}
	break;
	case Geometry::Types::LineString:
	{
		geoJS = *std::static_pointer_cast<LineString const>(geo);
	}
	break;
	case Geometry::Types::MultiLineString:
	{
		geoJS = *std::static_pointer_cast<MultiLineString const>(geo);
	}
	break;
	case Geometry::Types::Polygon:
	{
		geoJS = *std::static_pointer_cast<Polygon const>(geo);
	}
	break;
	case Geometry::Types::MultiPolygon:
	{
		geoJS = *std::static_pointer_cast<MultiPolygon const>(geo);
	}
	break;
	case Geometry::Types::GeometryCollection:
	default:
		ONYX_THROW("to_json(Feature): type not supported");
	}
	j["geometry"] = geoJS["geometry"];

}

void from_json(const nlohmann::json& j, FeatureCollection& featureCollection)
{
	std::string type;
	JsonParsing::Require(j, "type", type, "'type' is required for feature/feature collection");
	ONYX_ASSERT(type == "FeatureCollection", "'type' must be 'FeatureCollection' for FeatureCollection parsing; received '" + type + "' instead.");
	JsonParsing::Require(j, "features", "'features' not found in GeoJson string");

	lgal::gpu::AABB2d bounds{};
	for (auto& feature : j["features"])
	{
		std::shared_ptr<GeoJson> f = Parse(feature);
		ONYX_ASSERT(f->type == GeoJson::Types::Feature, "A FeatureCollection cannot contain a FeatureCollection");
		featureCollection.features.push_back(std::static_pointer_cast<Feature>(f));
		bounds = lmath::fit(f->bounds, bounds);
	}
	featureCollection.bounds = bounds;
}

void to_json(nlohmann::json& /* j */, const FeatureCollection& /* featureCollection */)
{
	ONYX_THROW("Json serialization not implemented for GeoJson::FeatureCollection");
}

bool GeoJson::is(Geometry::Types geometryType) const
{
	switch (type)
	{
		case Types::Feature:
		{
			return ((Feature const*)this)->geometry->type == geometryType;
		}
		case Types::FeatureCollection:
		{
			auto fc = (FeatureCollection const*)this;
			for (auto const& feature : fc->features)
			{
				if (feature->is(geometryType))
					return true;
			}
		}
	}
	return false;
}

std::unique_ptr<GeoJson> Parse(std::string const& geoJson)
{
	nlohmann::json j = nlohmann::json::parse(geoJson);

	return Parse(j);
}

std::unique_ptr<GeoJson> Parse(const nlohmann::json& j)
{
	std::unique_ptr<GeoJson> result;

	std::string type;
	JsonParsing::Require(j, "type", type, "'type' is required for GeoJson");
	auto featureType = std::fromStringView<GeoJson::Types>(type);
	switch (featureType)
	{
		case GeoJson::Types::Feature:
		{
			auto f = new Feature();
			result.reset(f);
			j.get_to(*f);
			f->bounds = f->geometry->bounds;
		}
		break;
	case GeoJson::Types::FeatureCollection:
		{
			auto fc = new FeatureCollection();
			result.reset(fc);
			j.get_to(*fc);
			for (auto& feature : fc->features)
			{
				fc->bounds = lmath::fit(fc->bounds, feature->bounds);
			}
		}
		break;
	}

	return result;
}

} // GeoJson
} // onyx

