#ifndef __GEO_JSON_H__
#define __GEO_JSON_H__

#include <unordered_map>
#include <string>
#include <vector>

#include <3rdParty/nlohmann/json.hpp>
#include <lucid/gal/Types.h>

#include <Utils/EnumUtils.h>

// TODO (Ronald): At some point, start separating parts of this file to separate files

namespace onyx {
namespace GeoJson {

	static constexpr gpu_float_t cInvalidHeight = -1000;

	struct Geometry {

		enum class Types
		{
			Point,
			MultiPoint,
			LineString,
			MultiLineString,
			Polygon,
			MultiPolygon,
			GeometryCollection
		};

		Geometry(Types type) : type(type) { }

		virtual ~Geometry() {}

		Types const type;

		lgal::gpu::AABB2d bounds = lgal::gpu::AABB2d::nothing();

		void boundPoint(lgal::gpu::Vector2 const &p)
		{
			lmath::fit(bounds, p);
		}

		void boundPoint(lgal::gpu::Vector3 const& p)
		{
			boundPoint(lgal::gpu::Vector2(p.x, p.y));
		}

	};

	// Note: Only makes deep copy if the immediate derived class copy constructors make deep copies
	std::shared_ptr<Geometry> makeDeepCopy(std::shared_ptr<Geometry const> const& toCpy);

	struct Point : public Geometry
	{
	public:
		Point() : Point(lgal::gpu::Vector3{ 0 }) {}

		Point(lgal::gpu::Vector3 const& p) : Geometry(Types::Point), position(p)
		{
			bounds = lgal::gpu::AABB2d{ p.xy, p.xy };
		}

		inline void setPoint(lgal::gpu::Vector3 const& p)
		{
			position = p;
			bounds = lgal::gpu::AABB2d{ p.xy, p.xy };
		}

		lgal::gpu::Vector3 position;
	};

	struct MultiPoint : public Geometry
	{
	public:
		MultiPoint() : Geometry(Types::MultiPoint) { }

		inline void addPoint(lgal::gpu::Vector3 const& p)
		{
			positions.push_back(p);
			boundPoint(p);
		}

		std::vector<lgal::gpu::Vector3> positions;
	};

	struct LineString : public Geometry
	{
	public:
		LineString() : Geometry(Types::LineString) { }

		inline void addPoint(lgal::gpu::Vector3 const& p)
		{
			lineVertices.push_back(p);
			this->boundPoint(p);
		}

		std::vector<lgal::gpu::Vector3> lineVertices;
	};

	struct MultiLineString : public Geometry
	{
	public:
		MultiLineString() : Geometry(Types::MultiLineString) { }

		// Specifies starting and ending indices of each line
		std::vector<lgal::array::Range> ranges;
		std::vector<lgal::gpu::Vector3> lineVertices;
	};

	struct Polygon : public Geometry
	{
		Polygon() : Geometry(Types::Polygon) { }

		// Specifies starting and ending indices of each ring
		std::vector<lgal::array::Range> ringRanges;
		std::vector<lgal::gpu::Vector3> vertices;
	};

	struct MultiPolygon : public Geometry
	{
	public:
		MultiPolygon() : Geometry(Types::MultiPolygon) { }
		std::vector<lgal::array::Range> ringRanges,
												polygonRanges;
		std::vector<lgal::gpu::Vector3> vertices;
	};

	struct GeoJson {
		enum class Types {
			Feature,
			FeatureCollection
		};
		GeoJson(Types type) : type(type) { }

		virtual ~GeoJson() {}

		bool is(Geometry::Types geometryType) const;

		Types const type;
		lgal::gpu::AABB2d bounds = lgal::gpu::AABB2d::nothing();
	};

	using sharedGJ_t = std::shared_ptr<GeoJson>;
	using sharedConstGJ_t = std::shared_ptr<const GeoJson>;

	// Note: Only makes deep copy if the immediate derived class copy constructors make deep copies
	std::shared_ptr<GeoJson> makeDeepCopy(std::shared_ptr<GeoJson const> const& toCpy);

	struct Feature : public GeoJson {
		Feature() : GeoJson(Types::Feature) { }
		Feature(std::shared_ptr<Geometry> g) : GeoJson(Types::Feature), geometry{ g } 
		{ 
			if (g != nullptr)
			{
				bounds = g->bounds;
			}
		}
		
		std::shared_ptr<Geometry> geometry;

		// TODO replace this once we know how we should handle properties
		std::unordered_map<std::string, std::string> properties;
	};

	struct FeatureCollection : public GeoJson {
		FeatureCollection() : GeoJson(Types::FeatureCollection) { }
		
		std::vector<std::shared_ptr<Feature>> features;
		
		// TODO replace this once we know how we should handle properties
		std::unordered_map<std::string, std::string> properties;
	};

	// Returns the derived type if convertible. Otherwise returns nullptr. Will return nullptr if gj is FeatureCollection
	template<typename T>
	std::shared_ptr<T> getGeometryFromGeoJson(std::shared_ptr<GeoJson> gj)
	{
		auto featurePtr = std::dynamic_pointer_cast<Feature>(gj);
		if (featurePtr == nullptr)
		{
			return nullptr;
		}

		auto geoPtr = featurePtr->geometry;
		if (geoPtr == nullptr)
		{
			return nullptr;
		}

		auto derivedGeoPtr = std::dynamic_pointer_cast<T, Geometry>(geoPtr);
		return derivedGeoPtr;
	}

	template<typename T>
	std::shared_ptr<T const> getGeometryFromGeoJson(std::shared_ptr<GeoJson const> gj)
	{
		auto featurePtr = std::dynamic_pointer_cast<Feature const>(gj);
		if (featurePtr == nullptr)
		{
			return nullptr;
		}

		auto geoPtr = featurePtr->geometry;
		if (geoPtr == nullptr)
		{
			return nullptr;
		}

		auto derivedGeoPtr = std::dynamic_pointer_cast<T const, Geometry const>(geoPtr);
		return derivedGeoPtr;
	}

	void from_json(const nlohmann::json& j, Point& point);
	void to_json(nlohmann::json& j, const Point& point);

	void from_json(const nlohmann::json& j, MultiPoint& multiPoint);
	void to_json(nlohmann::json& j, const	MultiPoint& multiPoint);
	void from_json(const nlohmann::json& j, LineString& lineString);
	void to_json(nlohmann::json& j, const LineString& lineString);
	void from_json(const nlohmann::json& j, MultiLineString& multiLineString);
	void to_json(nlohmann::json& j, const MultiLineString& multiLineString);
	void from_json(const nlohmann::json& j, Polygon& polygon);
	void to_json(nlohmann::json& j, const Polygon& polygon);
	void from_json(const nlohmann::json& j, MultiPolygon& multiPolygon);
	void to_json(nlohmann::json& j, const MultiPolygon& multiPolygon);

	std::shared_ptr<GeoJson> Parse(std::string const& geoJson);
	std::shared_ptr<GeoJson> Parse(const nlohmann::json& j);

	void from_json(const nlohmann::json& j, Feature& req);
	void to_json(nlohmann::json& j, const Feature& req);

	void from_json(const nlohmann::json& j, FeatureCollection& req);
	void to_json(nlohmann::json& j, const FeatureCollection& req);
	
} } 

namespace std
{

	template<>
	inline onyx::GeoJson::Geometry::Types fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::GeoJson::Geometry::Types> const nameMap = {
			{ "point",					onyx::GeoJson::Geometry::Types::Point },
			{ "multipoint",				onyx::GeoJson::Geometry::Types::MultiPoint },
			{ "linestring",				onyx::GeoJson::Geometry::Types::LineString },
			{ "multilinestring",		onyx::GeoJson::Geometry::Types::MultiLineString },
			{ "polygon",				onyx::GeoJson::Geometry::Types::Polygon },
			{ "multipolygon",			onyx::GeoJson::Geometry::Types::MultiPolygon },
			{ "geometrycollection",		onyx::GeoJson::Geometry::Types::GeometryCollection },
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum GeoJson::Geometry::Types");
	}

	inline std::string_view toStringView(onyx::GeoJson::Geometry::Types value)
	{
		static std::unordered_map<onyx::GeoJson::Geometry::Types, std::string_view> const nameMap = {
			{ onyx::GeoJson::Geometry::Types::Point,					"point" },
			{ onyx::GeoJson::Geometry::Types::MultiPoint,			"multipoint" },
			{ onyx::GeoJson::Geometry::Types::LineString,			"linestring" },
			{ onyx::GeoJson::Geometry::Types::MultiLineString,		"multilinestring" },
			{ onyx::GeoJson::Geometry::Types::Polygon,				"polygon" },
			{ onyx::GeoJson::Geometry::Types::MultiPolygon,			"multipolygon" },
			{ onyx::GeoJson::Geometry::Types::GeometryCollection,	"geometrycollection" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum GeoJson::Geometry::Types");
	}

	template<>
	inline onyx::GeoJson::GeoJson::Types fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::GeoJson::GeoJson::Types> const nameMap = {
			{ "feature",				onyx::GeoJson::GeoJson::Types::Feature },
			{ "featurecollection",		onyx::GeoJson::GeoJson::Types::FeatureCollection},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum GeoJson::GeoJson::Types");
	}

	inline std::string_view toStringView(onyx::GeoJson::GeoJson::Types value)
	{
		static std::unordered_map<onyx::GeoJson::GeoJson::Types, std::string_view> const nameMap = {
			{ onyx::GeoJson::GeoJson::Types::Feature,				"feature" },
			{ onyx::GeoJson::GeoJson::Types::FeatureCollection,		"featurecollection" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum GeoJson::GeoJson::Types");
	}

}

#endif