#include "WindParticleSystem.h"

#include <random>
#include <chrono>
#include <Logging/LogManager.h>
#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>
#include <lucid/Profiler.h>

#include "Rendering/ViewId.h"
#include "Rendering/VertStructs.h"

#include "Utils/MapMath.h"

namespace onyx::Experimental {

lgal::gpu::Vector2 WindParticleSystem::cLifeMinMax{ 0.7f, 1 };

gpu_float_t WindParticleSystem::sFBOView[16];
gpu_float_t WindParticleSystem::sFBOProj[16];

lgal::gpu::Vector4 getCamShiftedTileBounds(Tiles::TileId const& tileId, Camera::CameraState const& camera)
{
	auto tileBoundsBB = tileId.worldBounds<world_float_t>();
	tileBoundsBB = tileBoundsBB.shift(-camera.position.xy);
	
	return lgal::gpu::Vector4{ tileBoundsBB.min.as<gpu_float_t>(), tileBoundsBB.max.as<gpu_float_t>() };
}

WindParticleSystem::WindParticleSystem()
{
	// Create framebuffers for particle states
	constexpr uint64_t fBufTexFlags = BGFX_TEXTURE_RT | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT;

	{
		mStateTextures[0] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mStateTextures[0]), "Framebuffer 1 texture 1 is invalid");
		bgfx::setName(mStateTextures[0], "Wind: FB1 State Tex1");

		mParticleFBs[0] = bgfx::createFrameBuffer(1, &(mStateTextures.data()[0]), false);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mParticleFBs[0]), "Failed to initialize Wind Particle FB1");
		bgfx::setName(mParticleFBs[0], "Wind FB1");
	}

	{
		mStateTextures[1] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mStateTextures[1]), "Framebuffer 2 texture 1 is invalid");
		bgfx::setName(mStateTextures[1], "Wind: FB2 State Tex1");

		mParticleFBs[1] = bgfx::createFrameBuffer(1, &(mStateTextures.data()[1]), false);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mParticleFBs[1]), "Failed to initialize Wind Particle FB2");
		bgfx::setName(mParticleFBs[1], "Wind FB2");
	}

	// Generate vertex and index buffers
	{
		auto vertBufMem = bgfx::alloc(sizeof(Rendering::VertStructs::Pos) * 4);
		auto vertBufData = reinterpret_cast<Rendering::VertStructs::Pos*>(vertBufMem->data);
		vertBufData[0] = { lgal::gpu::Vector3{ -0.5f, -0.5f, 0 } };
		vertBufData[1] = { lgal::gpu::Vector3{ 0.5f, -0.5f, 0 } };
		vertBufData[2] = { lgal::gpu::Vector3{ -0.5f, 0.5f, 0 } };
		vertBufData[3] = { lgal::gpu::Vector3{ 0.5f, 0.5f, 0 } };
		vBuf = bgfx::createVertexBuffer(vertBufMem, Rendering::VertStructs::Pos::ms_layout);
		ONYX_DEBUG_ASSERT(bgfx::isValid(vBuf), "Vertex buffer for wind update shader is invalid");

		auto indBufMem = bgfx::alloc(sizeof(uint16_t) * 4);
		auto indBufData = reinterpret_cast<uint16_t*>(indBufMem->data);
		indBufData[0] = 0;
		indBufData[1] = 1;
		indBufData[2] = 2;
		indBufData[3] = 3;
		iBuf = bgfx::createIndexBuffer(indBufMem);
		ONYX_DEBUG_ASSERT(bgfx::isValid(iBuf), "Index buffer for wind update shader is invalid");
	}

	// Generate state update step camera matrices
	bx::mtxLookAt(sFBOView, bx::Vec3(0, 0, -1), bx::Vec3(0), bx::Vec3(0, 1, 0));
	bx::mtxOrtho(sFBOProj, 0, gpu_float_t(cTexRes), 0, gpu_float_t(cTexRes), 0.01f, 10, 0, false);

	// Load shader program
	// TODO (Ronald): Change shader program
	sUpdateProgram = std::make_unique<Shaders::Program>();
	sDrawProgram = std::make_unique<Shaders::Program>();
	*sUpdateProgram = Shaders::load(Shaders::Handwritten::cWindUpdate, false);
	*sDrawProgram = Shaders::load(Shaders::Handwritten::cWindDraw, true);

	// Generate instanced data for each particle to render
	{
		auto instanceMem = bgfx::alloc(sizeof(Rendering::VertStructs::InstanceData1) * cNumParticles);
		auto instanceData = reinterpret_cast<Rendering::VertStructs::InstanceData1*>(instanceMem->data);
		gpu_float_t uvInterval = 1.f / gpu_float_t(cTexRes);
		for (size_t i = 0; i < cTexRes; ++i)
		{
			for (size_t j = 0; j < cTexRes; ++j)
			{
				// UV coord of pixel's "middle"
				auto uvCoord = lgal::gpu::Vector4{ (gpu_float_t(i) + 0.5f) * uvInterval, (gpu_float_t(j) + 0.5f) * uvInterval, 0, 0 };
				(*instanceData++).data[0] = uvCoord;
			}
		}
		iDataHndl = bgfx::createVertexBuffer(instanceMem, Rendering::VertStructs::InstanceData1::ms_layout);
		ONYX_DEBUG_ASSERT(bgfx::isValid(iDataHndl), "Wind: Failed to initialize vertex buffer for rendering particles");
	}

	// Load up wind particle texture
	bgfx::TextureInfo info;
	mWindTexture = BgfxUtils::loadTexture(std::string(cWindFile), 0, 0, &info);
	ONYX_ASSERT(bgfx::isValid(mWindTexture), "Failed to load wind texture image");
	mWindResolution = lgal::screen::Vector2{ int32_t(info.width), int32_t(info.height) };

	mFirstUpdate = true;
}

WindParticleSystem::~WindParticleSystem()
{
	for (auto& fBufHndl : mParticleFBs)
	{
		BgfxUtils::tryDestroy(fBufHndl);
	}

	for (auto& tHndl : mStateTextures)
	{
		BgfxUtils::tryDestroy(tHndl);
	}
	BgfxUtils::tryDestroy(mWindTexture);

	BgfxUtils::tryDestroy(vBuf);
	BgfxUtils::tryDestroy(iBuf);
	BgfxUtils::tryDestroy(iDataHndl);
}

void WindParticleSystem::update(Camera::CameraState const& camera, time_float_t deltaMS)
{
	LUCID_PROFILE_SCOPE("WindParticleSystem::Update");

	// Submit render call
	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
	std::string name = "Update Wind Particles";
	bgfx::setViewName(viewId, name.c_str());

	bgfx::setViewClear(viewId, BGFX_CLEAR_NONE);
	bgfx::setViewRect(viewId, 0, 0, uint16_t(cTexRes), uint16_t(cTexRes));
	bgfx::setViewFrameBuffer(viewId, mParticleFBs[mTargetFBIdx]);
	bgfx::setViewTransform(viewId, sFBOView, sFBOProj);
	bgfx::touch(viewId);

	auto readFbIdx = !mTargetFBIdx;
	bgfx::TextureHandle stateTex = bgfx::getTexture(mParticleFBs[readFbIdx], 0);
	ONYX_DEBUG_ASSERT(bgfx::isValid(stateTex), "Wind: Update - Failed to retrieve particle state texture from FB");

	sUpdateProgram->set("s_StateTex", stateTex, lgal::screen::Vector2(cTexRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
	sUpdateProgram->set("s_WindVelocTex", mWindTexture, mWindResolution, false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
	
	sUpdateProgram->set("u_TileBounds", getCamShiftedTileBounds(cDrawTileId, camera));

	lgal::gpu::Vector4 uPackedParams{ cLifeMinMax, gpu_float_t(mFirstUpdate), gpu_float_t(deltaMS) };
	sUpdateProgram->set("u_LifeMinMaxInitDelta", uPackedParams);

	sUpdateProgram->set("u_LifeDurMS", lgal::gpu::Vector4{ cAnimDurMS, cFadeInDurMS, 0, 0 });

	sUpdateProgram->set("u_CamPos", lgal::gpu::Vector4{ camera.position.as<gpu_float_t>(), 0.f });

	bgfx::setIndexBuffer(iBuf);
	bgfx::setVertexBuffer(0, vBuf);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_PT_TRISTRIP;

	bgfx::setState(state);
	bgfx::submit(viewId, sUpdateProgram->handle());

	mFirstUpdate = false;
}

void WindParticleSystem::draw(Tiles::TileId const& tileId, Camera::CameraState const& camera, Atlases::HeightAtlas const& heightAtlas, lgal::gpu::Vector2 const screenSize, bgfx::FrameBufferHandle const colorZFrameBuffer)
{
	if (tileId != cDrawTileId)
	{
		return;
	}

	auto readFbIdx = !mTargetFBIdx;

	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::touch(viewId);
	bgfx::setViewName(viewId, "Draw wind particles");
	bgfx::setViewRect(viewId, 0, 0, uint16_t(screenSize.x), uint16_t(screenSize.y));
	bgfx::setViewFrameBuffer(viewId, colorZFrameBuffer);
	bgfx::setViewTransform(viewId, camera.view.data(), camera.proj.data());

	// Set instance buffer
	bgfx::setInstanceDataBuffer(iDataHndl, 0, cNumParticles);
	bgfx::setIndexBuffer(iBuf);
	bgfx::setVertexBuffer(0, vBuf);

	bgfx::TextureHandle stateTex = bgfx::getTexture(mParticleFBs[readFbIdx], 0);

	sDrawProgram->set("s_StateTex", stateTex, lgal::screen::Vector2(cTexRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);

	sDrawProgram->set("u_SizePx", lgal::gpu::Vector2{ gpu_float_t(cParticleSizePx) });
	sDrawProgram->set("u_ScreenSizePx", screenSize);
	sDrawProgram->set("u_TileBounds", getCamShiftedTileBounds(cDrawTileId, camera));
	
	lgal::world::Vector2 tileMidpoint = cDrawTileId.toWorldPos(lgal::tile::Vector2{ 0.5f }, Tiles::TileId::Origin::TOP_LEFT);
	auto baseHeight = gpu_float_t(world_float_t(heightAtlas.heightAt(tileMidpoint)) - camera.position.z);
	sDrawProgram->set("u_BaseElevationKm", baseHeight);

	// submit draw call
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_PT_TRISTRIP
		| BGFX_STATE_DEPTH_TEST_LEQUAL
		| BGFX_STATE_BLEND_ALPHA
		;
	bgfx::setState(state);
	bgfx::submit(viewId, sDrawProgram->handle());

	// switch texture targets
	mTargetFBIdx = !mTargetFBIdx;
}

}