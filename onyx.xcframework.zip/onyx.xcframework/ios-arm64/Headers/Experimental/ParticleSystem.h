#pragma once

#include <array>
#include <lucid/gal/Types.h>

#include "Utils/BgfxUtils.h"
#include "Camera/CameraState.h"

// TODO (Ronald): Find better units to use for precision
// Also make parameters changeable in the DebugUI

// 
// Velocity is in km/ms
// Acceleration is in km/ms^2

namespace onyx::Experimental {

class ParticleSystem
{
public:

	static void initialize();
	inline static bool isInitialized() { return initialized; }
	static void shutdown();

	static void update(time_float_t deltaMS);

	static void draw(Camera::CameraState const& cameraState, lgal::gpu::Vector2 const screenSize,
		bgfx::FrameBufferHandle const colorZFrameBuffer);


	ParticleSystem() = delete;
	~ParticleSystem() = delete;

private:

	static constexpr size_t cNumParticles = 1000000;
	static constexpr int cTexRes = 1000;

	static lgal::gpu::Vector2 cVelocityMinMax;
	static lgal::gpu::Vector2 cLifeMinMax;
	static constexpr gpu_float_t cAccel = -0.00001f;
	static constexpr time_float_t cAnimDurMS = 3000;

	static constexpr gpu_float_t cBBSize = 0.006f;

private:

	static bool targetFbIdx; // Used boolean to switch between index 0 and 1 quickly
	static std::array<bgfx::FrameBufferHandle, 2> sParticleFBs;
	static std::array<bgfx::TextureHandle, 4> sStateTextures;	// Two for each frame buffer

	//static bgfx::TextureHandle particleSeedTex;
	//static bgfx::TextureHandle particleSpriteTex;

	static gpu_float_t FBOView[16];
	static gpu_float_t FBOProj[16];

	static bgfx::VertexBufferHandle vBuf;
	static bgfx::IndexBufferHandle iBuf;

	static bgfx::VertexBufferHandle iDataHndl;

	static bool initialized;
	static bool firstUpdate;

};

}
