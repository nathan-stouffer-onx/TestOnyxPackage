#pragma once

#include <array>
#include <memory>

#include <lucid/gal/Types.h>

#include <Shaders/Program.h>

#include "Utils/BgfxUtils.h"
#include "Camera/CameraState.h"
#include "Atlases/HeightAtlas.h"

// Velocity is in km/ms
// Acceleration is in km/ms^2

namespace onyx::Experimental {

// DOI Proof of concept particle system that emits a geyser effect from old faithful
class ParticleSystem
{
public:

	ParticleSystem();
	~ParticleSystem();

	void update(time_float_t deltaMS);

	void draw(Camera::CameraState const& cameraState, Atlases::HeightAtlas const& atlas, lgal::gpu::Vector2 const screenSize, bgfx::FrameBufferHandle const colorZFrameBuffer);

private:

	static constexpr int cTexRes = 1000;
	static constexpr size_t cNumParticles = cTexRes * cTexRes;

	static lgal::gpu::Vector2 cVelocityMinMax;
	static lgal::gpu::Vector2 cLifeMinMax;
	static constexpr gpu_float_t cAccel = -1e-5f;
	static constexpr time_float_t cAnimDurMS = 3000.0;

	static constexpr gpu_float_t cBBSize = 1e-2f;

private:

	uint16_t mTargetFbIdx = 0;
	std::array<bgfx::FrameBufferHandle, 2> mParticleFBs = { { BGFX_INVALID_HANDLE ,  BGFX_INVALID_HANDLE } };
;	// Two textures per frame buffer
	std::array<bgfx::TextureHandle, 4> mStateTextures = { { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE } };

	gpu_float_t mFBOView[16] = { 0 };
	gpu_float_t mFBOProj[16] = { 0 };

	std::unique_ptr<Shaders::Program> mUpdateProgram = nullptr;
	std::unique_ptr<Shaders::Program> mDrawProgram = nullptr;

	bgfx::VertexBufferHandle mVBuf = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle mIBuf = BGFX_INVALID_HANDLE;

	bgfx::VertexBufferHandle mIDataHndl = BGFX_INVALID_HANDLE;

	bool mFirstUpdate = true;

};

}
