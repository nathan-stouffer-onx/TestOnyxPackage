#include "ParticleSystem.h"

#include <random>
#include <chrono>
#include <Logging/LogManager.h>
#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>
#include <lucid/Profiler.h>

#include "Rendering/ViewId.h"
#include "Rendering/VertStructs.h"

#include "Utils/MapMath.h"

namespace onyx::Experimental {

lgal::gpu::Vector2 ParticleSystem::cVelocityMinMax{ 0.001f, 0.006f };
lgal::gpu::Vector2 ParticleSystem::cLifeMinMax{ 0.2f, 1 };

ParticleSystem::ParticleSystem()
{
	// Create framebuffers for particle states
	uint64_t fBufTexFlags = BGFX_TEXTURE_RT | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT;
	bool destroyTexsWithFB = false;

	{
		mStateTextures[0] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mStateTextures[0]), "Framebuffer 1 texture 1 is invalid");
		bgfx::setName(mStateTextures[0], "Frame buffer 1 PosLife texture");
		mStateTextures[1] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		bgfx::setName(mStateTextures[1], "Frame buffer 1 VelocSeed texture");
		ONYX_DEBUG_ASSERT(bgfx::isValid(mStateTextures[1]), "Framebuffer 1 texture 2 is invalid");

		mParticleFBs[0] = bgfx::createFrameBuffer(2, &(mStateTextures.data()[0]), destroyTexsWithFB);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mParticleFBs[0]), "Particle state FB 1 is invalid");
		bgfx::setName(mParticleFBs[0], "Particle FB 1");
	}

	{
		mStateTextures[2] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mStateTextures[2]), "Framebuffer 2 texture 1 is invalid");
		bgfx::setName(mStateTextures[2], "Frame buffer 2 PosLife texture");
		mStateTextures[3] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mStateTextures[3]), "Framebuffer 2 texture 2 is invalid");
		bgfx::setName(mStateTextures[3], "Frame buffer 2 VelocSeed texture");

		mParticleFBs[1] = bgfx::createFrameBuffer(2, &(mStateTextures.data()[2]), destroyTexsWithFB);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mParticleFBs[1]), "Particle state FB 2 is invalid");
		bgfx::setName(mParticleFBs[1], "Particle FB 2");
	}

	// Generate vertex and index buffers
	{
		auto vertBufMem = bgfx::alloc(sizeof(Rendering::VertStructs::Pos) * 4);
		auto vertBufData = reinterpret_cast<Rendering::VertStructs::Pos*>(vertBufMem->data);
		vertBufData[0] = { lgal::gpu::Vector3{ 0 } };
		vertBufData[1] = { lgal::gpu::Vector3{ 1.f, 0, 0 } };
		vertBufData[2] = { lgal::gpu::Vector3{ 0, 1.f, 0 } };
		vertBufData[3] = { lgal::gpu::Vector3{ 1.f, 1.f, 0 } };
		mVBuf = bgfx::createVertexBuffer(vertBufMem, Rendering::VertStructs::Pos::ms_layout);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mVBuf), "Vertex buffer for particle update shader is invalid");

		auto indBufMem = bgfx::alloc(sizeof(uint16_t) * 4);
		auto indBufData = reinterpret_cast<uint16_t*>(indBufMem->data);
		indBufData[0] = 0;
		indBufData[1] = 1;
		indBufData[2] = 2;
		indBufData[3] = 3;
		mIBuf = bgfx::createIndexBuffer(indBufMem);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mIBuf), "Index buffer for particle update shader is invalid");
	}

	// Generate camera matrices
	bx::mtxLookAt(mFBOView, bx::Vec3(0, 0, -1), bx::Vec3(0), bx::Vec3(0, 1, 0));
	bx::mtxOrtho(mFBOProj, 0, gpu_float_t(cTexRes), 0, gpu_float_t(cTexRes), 0.01f, 10, 0, false);

	mUpdateProgram = std::make_unique<Shaders::Program>();
	mDrawProgram = std::make_unique<Shaders::Program>();

	*mUpdateProgram = Shaders::load(Shaders::Handwritten::cParticleUpdate, false);
	*mDrawProgram = Shaders::load(Shaders::Handwritten::cParticleDraw, true);

	// Generate instanced data
	{
		auto instanceMem = bgfx::alloc(sizeof(Rendering::VertStructs::InstanceData1) * cNumParticles);
		auto instanceData = reinterpret_cast<Rendering::VertStructs::InstanceData1*>(instanceMem->data);
		gpu_float_t uvInterval = 1.f / gpu_float_t(cTexRes);
		for (size_t i = 0; i < cTexRes; ++i)
		{
			for (size_t j = 0; j < cTexRes; ++j)
			{
				// UV coord of pixel's "middle"
				auto uvCoord = lgal::gpu::Vector4{ (gpu_float_t(i) + 0.5f) * uvInterval, (gpu_float_t(j) + 0.5f) * uvInterval, 0, 0 };
				(*instanceData++).data[0] = uvCoord;
			}
		}
		mIDataHndl = bgfx::createVertexBuffer(instanceMem, Rendering::VertStructs::InstanceData1::ms_layout);
		ONYX_DEBUG_ASSERT(bgfx::isValid(mIDataHndl), "Particle renddering instance data buffer is invalid");
	}
}

void ParticleSystem::update(time_float_t deltaMS)
{
	// Submit render call
	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
	std::string name = "Particle System State update";
	bgfx::setViewName(viewId, name.c_str());

	bgfx::setViewClear(viewId, BGFX_CLEAR_NONE);
	bgfx::setViewRect(viewId, 0, 0, uint16_t(cTexRes), uint16_t(cTexRes));
	bgfx::setViewFrameBuffer(viewId, mParticleFBs[mTargetFbIdx]);
	bgfx::setViewTransform(viewId, mFBOView, mFBOProj);
	bgfx::touch(viewId);

	auto readFbIdx = !mTargetFbIdx;
	auto posLifeTex = bgfx::getTexture(mParticleFBs[readFbIdx], 0);
	ONYX_DEBUG_ASSERT(bgfx::isValid(posLifeTex), "Update - posLifeTex is not valid texture");
	auto velocSeedTex = bgfx::getTexture(mParticleFBs[readFbIdx], 1);
	ONYX_DEBUG_ASSERT(bgfx::isValid(velocSeedTex), "Update - velocSeedTex is not valid texture");

	mUpdateProgram->set("s_PosLifeTex", posLifeTex, lgal::screen::Vector2(cTexRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
	mUpdateProgram->set("s_VelocSeedTex", velocSeedTex, lgal::screen::Vector2(cTexRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
	mUpdateProgram->set("u_InitAccelDeltaProg", lgal::gpu::Vector4{ static_cast<gpu_float_t>(mFirstUpdate), cAccel, static_cast<gpu_float_t>(deltaMS), static_cast<gpu_float_t>(deltaMS / cAnimDurMS) });
	mUpdateProgram->set("u_VelLifeMinMax", lgal::gpu::Vector4{ cVelocityMinMax, cLifeMinMax });

	bgfx::setIndexBuffer(mIBuf);
	bgfx::setVertexBuffer(0, mVBuf);

	// Set render states
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_PT_TRISTRIP;

	bgfx::setState(state);
	bgfx::submit(viewId, mUpdateProgram->handle());

	mFirstUpdate = false;
}

void ParticleSystem::draw(Camera::CameraState const& cameraState, Atlases::HeightAtlas const& atlas, lgal::gpu::Vector2 const screenSize,
	bgfx::FrameBufferHandle const colorZFrameBuffer)
{
	auto readFbIdx = !mTargetFbIdx;

	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::touch(viewId);
	bgfx::setViewName(viewId, "Draw particles");
	bgfx::setViewRect(viewId, 0, 0, uint16_t(screenSize.x), uint16_t(screenSize.y));
	bgfx::setViewFrameBuffer(viewId, colorZFrameBuffer);
	bgfx::setViewTransform(viewId, cameraState.view.data(), cameraState.proj.data());

	// Set instance buffer
	bgfx::setInstanceDataBuffer(mIDataHndl, 0, cNumParticles);
	bgfx::setIndexBuffer(mIBuf);
	bgfx::setVertexBuffer(0, mVBuf);

	auto posLifeTex = bgfx::getTexture(mParticleFBs[readFbIdx], 0);

	mDrawProgram->set("s_PosLifeTex", posLifeTex, lgal::screen::Vector2(cTexRes), false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT);
	mDrawProgram->set("u_BBSize", lgal::gpu::Vector4{ cBBSize });

	auto locLL = MapMath::LonLat{ -110.8287,44.4637 };
	lgal::world::Vector3 loc{ locLL.toWorldPos(), 0 };
	loc.z = atlas.heightAt(loc.xy) - 0.2;
	loc -= cameraState.position;
	mDrawProgram->set("u_EmitterPos", loc);

	mDrawProgram->set("u_CamUp", cameraState.upDir());
	mDrawProgram->set("u_CamRight", cameraState.rightDir());

	// submit draw call
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_PT_TRISTRIP
		| BGFX_STATE_DEPTH_TEST_LEQUAL
		| BGFX_STATE_BLEND_ALPHA
		;
	bgfx::setState(state);
	bgfx::submit(viewId, mDrawProgram->handle());

	// switch texture targets
	mTargetFbIdx = mTargetFbIdx == 0 ? 1 : 0;
}

ParticleSystem::~ParticleSystem()
{
	for (auto& fBufHndl : mParticleFBs)
	{
		BgfxUtils::tryDestroy(fBufHndl);
	}

	for (auto& tHndl : mStateTextures)
	{
		BgfxUtils::tryDestroy(tHndl);
	}

	mUpdateProgram = nullptr;
	mDrawProgram = nullptr;

	BgfxUtils::tryDestroy(mVBuf);
	BgfxUtils::tryDestroy(mIBuf);
	BgfxUtils::tryDestroy(mIDataHndl);
}

}