#include "ParticleSystem.h"

#include <random>
#include <chrono>
#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>
#include <lucid/Profiler.h>

#include "Rendering/ViewId.h"
#include "Rendering/VertStructs.h"

#include "Utils/MapMath.h"
#include "Height/HeightManager.h"

namespace onyx::Experimental {

lgal::gpu::Vector2 ParticleSystem::cVelocityMinMax{ 0.001f, 0.006f };
lgal::gpu::Vector2 ParticleSystem::cLifeMinMax{ 0.2f, 1 };

bool ParticleSystem::targetFbIdx = 0;
std::array<bgfx::FrameBufferHandle, 2> ParticleSystem::sParticleFBs = { { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE } };
std::array<bgfx::TextureHandle, 4> ParticleSystem::sStateTextures = { { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE } };

gpu_float_t ParticleSystem::FBOView[16];
gpu_float_t ParticleSystem::FBOProj[16];

//bgfx::TextureHandle ParticleSystem::particleSeedTex = BGFX_INVALID_HANDLE;
//bgfx::TextureHandle ParticleSystem::particleSpriteTex = BGFX_INVALID_HANDLE;

bgfx::VertexBufferHandle ParticleSystem::vBuf = BGFX_INVALID_HANDLE;
bgfx::IndexBufferHandle ParticleSystem::iBuf = BGFX_INVALID_HANDLE;
bgfx::VertexBufferHandle ParticleSystem::iDataHndl = BGFX_INVALID_HANDLE;

bool ParticleSystem::initialized = false;
bool ParticleSystem::firstUpdate = true;

void ParticleSystem::initialize()
{
	static_assert(cTexRes * cTexRes == cNumParticles, "Texture resolution should agree with number of particles");

	// Generate texture with random seed values
	{
		/*
		unsigned seed = (unsigned)std::chrono::system_clock::now().time_since_epoch().count();
		std::mt19937 mtEngine(seed);
		std::uniform_real_distribution<gpu_float_t> dist(0.f, 1.f);

		auto initStateMem = bgfx::alloc(sizeof(gpu_float_t) * cNumParticles);
		auto initStateData = reinterpret_cast<gpu_float_t*>(initStateMem->data);
		for (size_t i = 0; i < cNumParticles; ++i)
		{
			//(*initStateData++) = dist(mtEngine);
			(*initStateData++) = 1;
		}

		// Generate initial particle state textures
		uint64_t randTexFlags = BGFX_TEXTURE_NONE | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT;
		particleSeedTex = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::R32F, randTexFlags, initStateMem);
		ONYX_DEBUG_ASSERT(bgfx::isValid(particleSeedTex), "Random seed texture for particle system is invalid!");
		*/
	}
	// Create framebuffers for particle states
	uint64_t fBufTexFlags = BGFX_TEXTURE_RT | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT;
	bool destroyTexsWithFB = false;

	{
		sStateTextures[0] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(sStateTextures[0]), "Framebuffer 1 texture 1 is invalid");
		bgfx::setName(sStateTextures[0], "Frame buffer 1 PosLife texture");
		sStateTextures[1] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		bgfx::setName(sStateTextures[1], "Frame buffer 1 VelocSeed texture");
		ONYX_DEBUG_ASSERT(bgfx::isValid(sStateTextures[1]), "Framebuffer 1 texture 2 is invalid");

		sParticleFBs[0] = bgfx::createFrameBuffer(2, &(sStateTextures.data()[0]), destroyTexsWithFB);
		ONYX_DEBUG_ASSERT(bgfx::isValid(sParticleFBs[0]), "Particle state FB 1 is invalid");
		bgfx::setName(sParticleFBs[0], "Particle FB 1");
	}

	{
		sStateTextures[2] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(sStateTextures[2]), "Framebuffer 2 texture 1 is invalid");
		bgfx::setName(sStateTextures[2], "Frame buffer 2 PosLife texture");
		sStateTextures[3] = bgfx::createTexture2D(cTexRes, cTexRes, false, 1, bgfx::TextureFormat::RGBA32F, fBufTexFlags);
		ONYX_DEBUG_ASSERT(bgfx::isValid(sStateTextures[3]), "Framebuffer 2 texture 2 is invalid");
		bgfx::setName(sStateTextures[3], "Frame buffer 2 VelocSeed texture");

		sParticleFBs[1] = bgfx::createFrameBuffer(2, &(sStateTextures.data()[2]), destroyTexsWithFB);
		ONYX_DEBUG_ASSERT(bgfx::isValid(sParticleFBs[1]), "Particle state FB 2 is invalid");
		bgfx::setName(sParticleFBs[1], "Particle FB 2");
	}

	// Generate vertex and index buffers
	{
		auto vertBufMem = bgfx::alloc(sizeof(Rendering::VertStructs::Pos) * 4);
		auto vertBufData = reinterpret_cast<Rendering::VertStructs::Pos*>(vertBufMem->data);
		vertBufData[0] = { lgal::gpu::Vector3{ 0 } };
		vertBufData[1] = { lgal::gpu::Vector3{ 1.f, 0, 0 } };
		vertBufData[2] = { lgal::gpu::Vector3{ 0, 1.f, 0 } };
		vertBufData[3] = { lgal::gpu::Vector3{ 1.f, 1.f, 0 } };
		vBuf = bgfx::createVertexBuffer(vertBufMem, Rendering::VertStructs::Pos::ms_layout);
		ONYX_DEBUG_ASSERT(bgfx::isValid(vBuf), "Vertex buffer for particle update shader is invalid");

		auto indBufMem = bgfx::alloc(sizeof(uint16_t) * 4);
		auto indBufData = reinterpret_cast<uint16_t*>(indBufMem->data);
		indBufData[0] = 0;
		indBufData[1] = 1;
		indBufData[2] = 2;
		indBufData[3] = 3;
		iBuf = bgfx::createIndexBuffer(indBufMem);
		ONYX_DEBUG_ASSERT(bgfx::isValid(iBuf), "Index buffer for particle update shader is invalid");
	}

	// Generate camera matrices
	bx::mtxLookAt(FBOView, bx::Vec3(0, 0, -1), bx::Vec3(0), bx::Vec3(0, 1, 0));
	bx::mtxOrtho(FBOProj, 0, gpu_float_t(cTexRes), 0, gpu_float_t(cTexRes), 0.01f, 10, 0, false);

	// Generate instanced data
	{
		auto instanceMem = bgfx::alloc(sizeof(Rendering::VertStructs::InstanceData1) * cNumParticles);
		auto instanceData = reinterpret_cast<Rendering::VertStructs::InstanceData1*>(instanceMem->data);
		gpu_float_t uvInterval = 1.f / gpu_float_t(cTexRes);
		for (size_t i = 0; i < cTexRes; ++i)
		{
			for (size_t j = 0; j < cTexRes; ++j)
			{
				// UV coord of pixel's "middle"
				auto uvCoord = lgal::gpu::Vector4{ (gpu_float_t(i) + 0.5f) * uvInterval, (gpu_float_t(j) + 0.5f) * uvInterval, 0, 0 };
				(*instanceData++).data[0] = uvCoord;
			}
		}
		iDataHndl = bgfx::createVertexBuffer(instanceMem, Rendering::VertStructs::InstanceData1::ms_layout);
		ONYX_DEBUG_ASSERT(bgfx::isValid(iDataHndl), "Particle renddering instance data buffer is invalid");
	}

	initialized = true;
	firstUpdate = true;
}

void ParticleSystem::update(time_float_t deltaMS)
{
	if (!initialized) return;

	LUCID_PROFILE_SCOPE("ParticleSystem::Update");

	// Submit render call
	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Types::RenderToTexture);
	std::string name = "Particle System State update";
	bgfx::setViewName(viewId, name.c_str());

	bgfx::setViewClear(viewId, BGFX_CLEAR_NONE);
	bgfx::setViewRect(viewId, 0, 0, uint16_t(cTexRes), uint16_t(cTexRes));
	bgfx::setViewFrameBuffer(viewId, sParticleFBs[targetFbIdx]);
	bgfx::setViewTransform(viewId, FBOView, FBOProj);
	bgfx::touch(viewId);

	auto readFbIdx = !targetFbIdx;
	auto posLifeTex = bgfx::getTexture(sParticleFBs[readFbIdx], 0);
	ONYX_DEBUG_ASSERT(bgfx::isValid(posLifeTex), "Update - posLifeTex is not valid texture");
	auto velocSeedTex = bgfx::getTexture(sParticleFBs[readFbIdx], 1);
	ONYX_DEBUG_ASSERT(bgfx::isValid(velocSeedTex), "Update - velocSeedTex is not valid texture");

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::ParticleUpdate, 0);
	shader->setParameter("s_posLifeTex", posLifeTex, cTexRes, cTexRes);
	shader->setParameter("s_velocSeedTex", velocSeedTex, cTexRes, cTexRes);
	shader->setParameter("u_velLifeMinMax", lgal::gpu::Vector4{ cVelocityMinMax, cLifeMinMax });
	shader->setParameter("u_initAccelDeltaProg", lgal::gpu::Vector4{ gpu_float_t(firstUpdate), cAccel, gpu_float_t(deltaMS),
		gpu_float_t(deltaMS / cAnimDurMS) });

	bgfx::setIndexBuffer(iBuf);
	bgfx::setVertexBuffer(0, vBuf);

	// Set render states
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_PT_TRISTRIP;

	bgfx::setState(state);
	bgfx::submit(viewId, shader->programHandle);

	firstUpdate = false;

}

void ParticleSystem::draw(Camera::CameraState const& cameraState, lgal::gpu::Vector2 const screenSize,
	bgfx::FrameBufferHandle const colorZFrameBuffer)
{
	if (!initialized) return;

	LUCID_PROFILE_SCOPE("ParticleSystem::Draw");
	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::ParticleDraw, 0);

	auto readFbIdx = !targetFbIdx;

	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
	bgfx::touch(viewId);
	bgfx::setViewName(viewId, "Draw particles");
	bgfx::setViewRect(viewId, 0, 0, uint16_t(screenSize.x), uint16_t(screenSize.y));
	bgfx::setViewFrameBuffer(viewId, colorZFrameBuffer);
	bgfx::setViewTransform(viewId, cameraState.view, cameraState.proj);

	// Set instance buffer
	bgfx::setInstanceDataBuffer(iDataHndl, 0, cNumParticles);
	bgfx::setIndexBuffer(iBuf);
	bgfx::setVertexBuffer(0, vBuf);

	auto posLifeTex = bgfx::getTexture(sParticleFBs[readFbIdx], 0);

	shader->setParameter("s_posLifeTex", posLifeTex, cTexRes, cTexRes);
	shader->setParameter("u_bbSize", lgal::gpu::Vector4{ cBBSize });

	auto locLL = MapMath::LonLat{ -110.8287,44.4637 };
	lgal::world::Vector3 loc{ locLL.toWorldPos(), 0 };
	loc.z = HeightManager::Instance()->heightAt(loc.xy) - 0.2;
	loc -= cameraState.position;
	shader->setParameter("u_emitterPos", loc);

	shader->setParameter("u_camUp", cameraState.upDir());
	shader->setParameter("u_camRight", cameraState.rightDir());

	// submit draw call
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_PT_TRISTRIP
		| BGFX_STATE_DEPTH_TEST_LEQUAL
		| BGFX_STATE_BLEND_ALPHA
		;
	bgfx::setState(state);
	bgfx::submit(viewId, shader->mInstancedHandle);

	// switch texture targets
	targetFbIdx = !targetFbIdx;
}

void ParticleSystem::shutdown()
{
	for (auto& fBufHndl : sParticleFBs)
	{
		BgfxUtils::tryDestroy(fBufHndl);
	}

	for (auto& tHndl : sStateTextures)
	{
		BgfxUtils::tryDestroy(tHndl);
	}

	//BgfxUtils::tryDestroy(particleSeedTex);
	//BgfxUtils::tryDestroy(particleSpriteTex);

	BgfxUtils::tryDestroy(vBuf);
	BgfxUtils::tryDestroy(iBuf);
	BgfxUtils::tryDestroy(iDataHndl);

	initialized = false;
	firstUpdate = true;
}

}