#pragma once

#include <array>
#include <memory>

#include <lucid/gal/Types.h>

#include <Shaders/Program.h>

#include "Utils/BgfxUtils.h"
#include "Camera/CameraState.h"
#include "Tiles/TileId.h"
#include "Atlases/HeightAtlas.h"

namespace onyx::Experimental {

/**
 * An experimental wind simulation that currently only works for a specific tile
 */
class WindParticleSystem
{
public:

	WindParticleSystem();
	~WindParticleSystem();

	// TODO (Ronald): Expose this once I figure out a way to not need the camera for the update step
	void update(Camera::CameraState const& camera, time_float_t deltaMS);

	void draw(Tiles::TileId const& tileId, Camera::CameraState const& camera, Atlases:: HeightAtlas const& heightAtlas, lgal::gpu::Vector2 const screenSize, bgfx::FrameBufferHandle const colorZFrameBuffer);

public:

	static constexpr int cTexRes = 80;
	static constexpr int cNumParticles = cTexRes * cTexRes;

	const Tiles::TileId cDrawTileId = Tiles::TileId(2, 0, 1);
	static constexpr char cWindFile[] = "assets/experimental/wind/2_0_1.png";

	static lgal::gpu::Vector2 cLifeMinMax;
	static constexpr time_float_t cAnimDurMS = 10000.0;
	static constexpr time_float_t cFadeInDurMS = 1000.0;

	static constexpr screen_coord_t cParticleSizePx = 5;

	static gpu_float_t sFBOView[16];
	static gpu_float_t sFBOProj[16];

private:

	bool mTargetFBIdx = false; // Used boolean to switch between index 0 and 1 quickly
	std::array<bgfx::FrameBufferHandle, 2> mParticleFBs;
	std::array<bgfx::TextureHandle, 2> mStateTextures;
	bgfx::TextureHandle mWindTexture = BGFX_INVALID_HANDLE;
	lgal::screen::Vector2 mWindResolution = { 0 };

	std::unique_ptr<Shaders::Program> sUpdateProgram = nullptr;
	std::unique_ptr<Shaders::Program> sDrawProgram = nullptr;

	bgfx::VertexBufferHandle vBuf = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle iBuf = BGFX_INVALID_HANDLE;

	bgfx::VertexBufferHandle iDataHndl BGFX_INVALID_HANDLE;

	bool mFirstUpdate = true;

};

}
