#ifndef _UPDATER_H_
#define _UPDATER_H_
#include "lucid/gal/Types.h"

namespace onyx
{
	class Viewport;
};

namespace onyx::Experimental {

class IUpdater
{
public:
	virtual ~IUpdater() {};
	virtual void update(onyx::Viewport* vp, time_float_t timeStepMS) = 0;
};
}
#endif