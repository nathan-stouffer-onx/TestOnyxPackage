#if defined(__GLIBC__)
#	include_next <alloca.h>
#else
#	include <stdlib.h>
#endif
