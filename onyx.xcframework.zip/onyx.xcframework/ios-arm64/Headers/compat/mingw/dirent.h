// BK - MinGW dirent is super broken, using MSVC compatibility one...
#ifndef _DIRENT_H_
#	define _DIRENT_H_
#	include "../msvc/dirent.h"
#endif // _DIRENT_H_
