#ifndef __MODIFIER_BUTTONS_H__
#define __MODIFIER_BUTTONS_H__

#include <cmath>

namespace onyx {
namespace Input {

    typedef uint8_t ModifierButtonsUInt;
    enum class ModifierButtons : ModifierButtonsUInt
    {
        None = 0x0,
        Ctrl = 0x1,
        Alt = 0x2,
        Shift = 0x4,

        CtrlAlt = Ctrl | Alt,
        CtrlShift = Ctrl | Shift,
        AltShift = Alt | Shift
	};

	inline constexpr ModifierButtons operator~(ModifierButtons const a)
	{
		return static_cast<ModifierButtons>(~static_cast<ModifierButtonsUInt>(a));
	}

	inline constexpr ModifierButtons operator&(ModifierButtons const a, ModifierButtons const b)
    {
        return static_cast<ModifierButtons>(static_cast<ModifierButtonsUInt>(a) & static_cast<ModifierButtonsUInt>(b));
    }

	inline constexpr ModifierButtons operator|(ModifierButtons const a, ModifierButtons const b)
    {
        return static_cast<ModifierButtons>(static_cast<ModifierButtonsUInt>(a) | static_cast<ModifierButtonsUInt>(b));
    }
	
    inline constexpr ModifierButtons operator^(ModifierButtons const a, ModifierButtons const b)
    {
        return static_cast<ModifierButtons>(static_cast<ModifierButtonsUInt>(a) ^ static_cast<ModifierButtonsUInt>(b));
    }

	inline ModifierButtons& operator&=(ModifierButtons& a, ModifierButtons const b)
    {
        a = a & b;
        return a;
    }

	inline ModifierButtons& operator|=(ModifierButtons& a, ModifierButtons const b)
    {
        a = a | b;
        return a;
    }

	inline ModifierButtons& operator^=(ModifierButtons& a, ModifierButtons const b)
    {
        a = a ^ b;
        return a;
    }

} }

#endif