#include "Pointer.h"

#include "Utils/Timer.h"

namespace onyx {
namespace Input {

	static constexpr input_float_t cFirstTapEpsilon = 0.0005;
	static constexpr input_float_t cSecondTapEpsilon = 0.05;

	void Pointer::update(time_float_t timeMS)
	{
		// check if the taps are stale and clears if necessary
		if (mTaps.size() > 0)
		{
			auto const& back = mTaps.back();
			if (back.isUp())		// if back tap is not pressed and is stale, clear out all the taps
			{
				auto elapsed = timeMS - back.upTimeMS;
				
				bool singleTapStale = (mInteractionType == InteractionType::SINGLE_TAP) ? elapsed > cTapWindowMS : false;
				bool doubleTapStale = (mInteractionType == InteractionType::DOUBLE_TAP) ? elapsed > cDoubleTapStaleInputThresholdMS : false;
				bool tooManyTaps = mTaps.size() > 2;
				bool fallbackStale = elapsed > cStaleInputFallbackThresholdMS;
				
				if (mHasMoved || singleTapStale || doubleTapStale || tooManyTaps || fallbackStale)
				{
					reset();
				}
			}
		}

		// detect and set the interaction
		mInteractionType = detectInteractionType(timeMS, mHasMoved, mTaps);
	}

	Pointer::InteractionType Pointer::detectInteractionType(time_float_t timeMS, bool hasMoved, std::vector<Tap> const& taps)
	{
		if (taps.size() == 0)		// if there have been no taps, there is no interaction
		{
			return InteractionType::NONE;
		}
		else if (taps.size() == 1) // case for a single tap
		{
			auto const& tap = taps[0];
			if (tap.isUp())	// tap is up, test for a single tap or long press or neither
			{
				bool pastDelay = timeMS - tap.downTimeMS > cTapWindowMS;
				if (pastDelay)	// intentionally wait so that we don't fire a single tap and double tap event
				{
					if (!hasMoved)	// if the pointer moved, it wasn't a tap or long press
					{
						bool inTapWindow   = tap.upTimeMS - tap.downTimeMS < cTapWindowMS;
						bool inPressWindow = tap.upTimeMS - tap.downTimeMS > cLongPressThresholdMS;
						
						if (inPressWindow)
						{
							return InteractionType::SINGLE_TAP_LONG_PRESS;
						}
						else if (inTapWindow)
						{
							return InteractionType::SINGLE_TAP;
						}
					}
				}
				else
				{
					return InteractionType::PRE_SINGLE_TAP;
				}
			}
			else // tap is down, test for a long press or drag or neither
			{
				if (hasMoved) // if the pointer moved, it is a drag interaction
				{
					return InteractionType::SINGLE_TAP_DRAG;
				}
				else
				{
					bool inPressWindow = timeMS - tap.downTimeMS > cLongPressThresholdMS;
					if (inPressWindow)
					{
						return InteractionType::SINGLE_TAP_LONG_PRESS;
					}
				}
			}
		}
		else if (taps.size() == 2) // case for a double tap
		{
			auto const& first = taps[0];
			auto const& second = taps[1];

			bool firstInTapWindow = first.upTimeMS - first.downTimeMS < cTapWindowMS;
			bool firstNotMove = lenSquared(first.downPos - first.upPos) < cFirstTapEpsilon;
			if (firstInTapWindow && firstNotMove)	// check that the first tap meets requirements
			{
				bool matches = lenSquared(second.downPos - first.upPos) < cSecondTapEpsilon;
				if (matches)	// check that the second down position matches the first up position
				{
					if (second.isUp())	// tap is up, test for a single tap or long press or neither
					{
						if (!hasMoved)	// if the pointer moved, it wasn't a tap or long press
						{
							bool inTapWindow   = second.upTimeMS - first.downTimeMS <  cTapWindowMS;
							bool inPressWindow = second.upTimeMS - second.downTimeMS > cLongPressThresholdMS;
							if (inTapWindow)
							{
								return InteractionType::DOUBLE_TAP;
							}
							else if (inPressWindow)
							{
								return InteractionType::DOUBLE_TAP_LONG_PRESS;
							}
						}
					}
					else // tap is down, test for a long press or drag or neither
					{
						if (hasMoved) // if the pointer moved, it is a drag interaction
						{
							return InteractionType::DOUBLE_TAP_DRAG;
						}
						else
						{
							bool inPressWindow = timeMS - second.downTimeMS > cLongPressThresholdMS;
							if (inPressWindow)
							{
								return InteractionType::DOUBLE_TAP_LONG_PRESS;
							}
						}
					}
				}
			}
		}
		
		// fall through case of no interaction
		return InteractionType::NONE;
	}

	void Pointer::setPosition(lgal::input::Vector2 const &position, double newPressure)
	{
		// if the pointer hasn't moved, check to see if this position moves it
		if (getState() == ButtonState::Pressed)
		{
			if (!mHasMoved)
			{
				auto const& back = mTaps.back();
				mHasMoved = (lenSquared(back.downPos - position) > cFirstTapEpsilon);
			}
		}

		mPosition = position;
		mPressure = newPressure;
	}

	void Pointer::down(time_float_t timeMS)
	{
		ONYX_ASSERT(getState() == ButtonState::Released, "Pointer must be released");
		// create a new tap
		mTaps.push_back({ timeMS, mPosition });
		mHasMoved = false;
	}

	void Pointer::up(time_float_t timeMS)
	{
		ONYX_ASSERT(getState() == ButtonState::Pressed, "Pointer must be pressed");
		// make sure that a tap exists
		if (mTaps.size() > 0)
		{
			// if the tap is down, set it to up. otherwise, ignore
			auto& back = mTaps.back();
			if (back.isDown())
			{
				// set the back to up
				back.upTimeMS = timeMS;
				back.upPos = mPosition;
			}
		}
	}

} }