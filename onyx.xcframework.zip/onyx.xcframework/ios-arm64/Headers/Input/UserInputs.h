#ifndef _USER_INPUTS_H_
#define _USER_INPUTS_H_

#include <numeric>
#include <array>

#include <lucid/gal/Types.h>

#include "Utils/Timer.h"
#include "ButtonState.h"
#include "ModifierButtons.h"
#include "Pointer.h"
#include "Wheel.h"
#include "Camera/CameraController.h"
#include "Viewport/Viewport.h"

namespace onyx {
namespace Input {

	static constexpr input_float_t cZoomAnimationTimeMS = 400.0;
	constexpr unsigned int cMaxPointers = 4;  // Enough for 4 fingers

	struct InputState
	{
		ModifierButtons modifiers;
		ButtonState wheel;
		std::array<ButtonState, cMaxPointers> buttonState;
		std::array<Pointer::InteractionType, cMaxPointers> interactions;

		InputState(ModifierButtons modifiers, ButtonState wheel, 
				std::array<ButtonState, cMaxPointers> const& buttonState,
				std::array<Pointer::InteractionType, cMaxPointers> const& interactions) :
			modifiers(modifiers),
			wheel(wheel),
			buttonState(buttonState),
			interactions(interactions)
		{}

	};

	class UserInputs
	{
	private:
		
		double mSensitivity = 1.0;
		std::shared_ptr<Wheel> mWheel = std::make_shared<Wheel>();
		std::array<std::shared_ptr<Pointer>, cMaxPointers> mPointers;
		ModifierButtons mModifierButtonState = ModifierButtons::None;

		InputState mInputState = { mModifierButtonState, ButtonState::Released, {}, {} };
		double mInputStateUpdateTimeMS = 0.0;
		bool mShouldConstructController = true;
		bool mConstructedController = false;
		bool mPrevConstructedController = false;
		bool mFiredEvents = false;

	public:

		UserInputs();

		inline double getSensitivity() { return mSensitivity; }
		inline void setSensitivity(double value) { mSensitivity = bx::clamp(value, 0.1, 2.0); }

		inline void setModifierButton(ModifierButtons button, ButtonState state)
		{
			if (state == ButtonState::Pressed)
			{
				mModifierButtonState |= button;
			}
			else if (state == ButtonState::Released)
			{
				mModifierButtonState &= ~button;
			}
		}

		ModifierButtons getModifierButtonState() const { return mModifierButtonState; }
		
		inline std::shared_ptr<Pointer const> getPointer(uint32_t pointerId) const
		{
			return mPointers[pointerId];
		}

		inline std::shared_ptr<Pointer const> activePointer() const
		{
			for (auto& pointer : mPointers)
			{
				if (pointer->getInteractionType() != Pointer::InteractionType::NONE)
				{
					return pointer;
				}
			}
			
			return nullptr;
		}

		inline std::vector<std::shared_ptr<Pointer const>> activePointers() const
		{
			std::vector<std::shared_ptr<Pointer const>> pointers;
			for (auto& pointer : mPointers)
			{
				if (pointer->getInteractionType() != Pointer::InteractionType::NONE)
				{
					pointers.push_back(pointer);
				}
			}

			return pointers;
		}

		inline void setPointerUp(uint32_t pointerId)
		{
			mPointers[pointerId]->up();
		}

		inline void setPointerDown(uint32_t pointerId)
		{
			mPointers[pointerId]->down();
		}

		inline void setPointerPosition(uint32_t pointerId, double newX, double newY, double newPressure)
		{
			//logE("%f, %f | %f, %f, %f", newX, newY, worldPosition.x, worldPosition.y, worldPosition.z);
			mPointers[pointerId]->setPosition({ newX, newY }, newPressure);
		}

		inline void setMousePosition(double normalizedX, double normalizedY, double newPressure)
		{
			for (int i = 0; i < 2; ++i)
			{
				setPointerPosition(i, normalizedX, normalizedY, newPressure);
			}
		}

		inline std::shared_ptr<Wheel const> getWheel() const
		{
			return mWheel;
		}

		inline void addScrollClicks(double xClicks, double yClicks)
		{
			mWheel->addScrollClicks({ xClicks, yClicks });
		}

		inline lgal::input::Vector2 getScrollPosition() const { return mWheel->getScrollState().pos; }

		lgal::input::Vector2 focusPosition() const;

		void update(time_float_t timeMS);

		// method for detecting edge cases where we will not allow certain input states to transition
		// to other input states
		// 
		// NOTE: not sure how I feel about this method of enforcing this. another option would be to
		// just mark the "next" InputState with a boolean "mShouldConstruct" instead of actually 
		// preventing the transfer between states.
		static bool allowable(InputState const prev, InputState const next);

	};

} }

template<>
struct std::hash<onyx::Input::InputState> {
public:
	size_t operator()(onyx::Input::InputState const& state) const noexcept
	{
		size_t hash = 0x0;
		// pack modifier buttons state in bits 32-29 (indexing from right to left and starting at 1)
		hash |= (size_t(state.modifiers) << 28);
		// pack wheel state in bit 28
		hash |= (size_t(state.wheel) << 27);
		// pack pressed pointers into state.buttonState.size() bits
		for (size_t i = 0; i < state.buttonState.size(); i++)
		{
			hash |= (size_t(state.buttonState[i]) << (26 - i));
		}
		// pack interaction types in the remaining 27 - state.buttonState.size() bits
		// allows up to 7 pointers because Pointer::InteractionType takes up only 3 bits
		for (size_t i = 0; i < state.interactions.size(); i++)
		{
			hash |= (size_t(state.interactions[i]) << ((27 - state.buttonState.size()) - (i + 1) * 3));
		}
		return hash;
	}
};

namespace onyx {
namespace Input {

	// we have a unique hash, so just use that
	inline bool operator== (InputState const& lhs, InputState const& rhs)
	{
		std::hash<InputState> hasher;
		return hasher(lhs) == hasher(rhs);
	}

	inline bool operator!= (InputState const& lhs, InputState const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator< (InputState const& lhs, InputState const& rhs)
	{
		if (lhs.modifiers == rhs.modifiers)
		{
			if (lhs.wheel == rhs.wheel)
			{
				std::hash<InputState> hasher;
				return hasher(lhs) < hasher(rhs);
			}
			else
			{
				return lhs.wheel < rhs.wheel;
			}
		}
		else
		{
			return lhs.modifiers < rhs.modifiers;
		}
		
	}

} }

#endif