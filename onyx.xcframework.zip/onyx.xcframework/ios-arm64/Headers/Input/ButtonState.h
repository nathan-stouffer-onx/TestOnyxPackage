#ifndef __BUTTON_STATE_H__
#define __BUTTON_STATE_H__

#include <Utils/EnumUtils.h>

namespace onyx {
namespace Input {

	enum class ButtonState
	{
		Released = 0x0,
		Pressed = 0x1
	};

} }

namespace std
{

	inline std::string_view toStringView(onyx::Input::ButtonState const& value)
	{
		static std::unordered_map<onyx::Input::ButtonState, std::string_view> const nameMap =
		{
			{ onyx::Input::ButtonState::Pressed,	"Pressed" },
			{ onyx::Input::ButtonState::Released,	"Released" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Input::ButtonState");
	}

}

#endif