#ifndef __WHEEL_H__
#define __WHEEL_H__

#include <limits>

#include <lucid/gal/Types.h>
#include "ButtonState.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Input {

	static constexpr input_float_t WheelSlidingWindowMS = 350.0;

	class Wheel
	{
	public:

		struct ScrollState
		{
			lgal::input::Vector2 pos;
			ButtonState button;
			time_float_t updateTimeMS;

			ScrollState(lgal::world::Vector2 pos, ButtonState button, time_float_t updateTimeMS) :
				pos(pos),
				button(button),
				updateTimeMS(updateTimeMS)
			{}
		};

		void update(time_float_t timeMS);

		void clear();

		void addScrollClicks(lgal::input::Vector2 const& delta);

		inline ScrollState getPrevScrollState() const { return mPrevScrollState; }
		inline ScrollState getScrollState() const { return mScrollState; }

		inline ButtonState getButtonState() const { return mScrollState.button; }

	private:
		
		ScrollState mScrollState = { { 0, 0 }, ButtonState::Released, 0.0 };
		ScrollState mPrevScrollState = { { 0, 0 }, ButtonState::Released, 0.0 };

		lgal::input::Vector2 mPending = { 0, 0 };		// scroll clicks to be added on the next call to Wheel::update

	};

} }

#endif