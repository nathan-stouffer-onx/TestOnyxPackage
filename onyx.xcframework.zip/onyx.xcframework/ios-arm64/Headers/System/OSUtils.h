#pragma once

#include <chrono>
#include <string>
#include <vector>

namespace os
{
	bool exists(std::string const& path);
	bool isDirectory(std::string const& path);
	bool createDirectory(std::string const& path);

	std::vector<std::string> directoryEntries(std::string const& dir, bool listDirectories, bool listFiles);
	std::vector<std::string> subDirectories(std::string const& dir);
	std::vector<std::string> filesInDirectory(std::string const& dir);
	void cleanFilesInDirectory(std::string const& dir, bool recursive);

	void copyDirectory(std::string const& src, std::string const& dst, bool recursive);

	std::string runningProcessPath();

	time_t modifiedTime(std::string const& path);

	bool moveFile(std::string const& src, std::string const& dst);
	bool copyFile(std::string const& src, std::string const& dst);
	bool removeFile(std::string const& path);

	bool writeFile(std::string const& path, std::string const& text);

}