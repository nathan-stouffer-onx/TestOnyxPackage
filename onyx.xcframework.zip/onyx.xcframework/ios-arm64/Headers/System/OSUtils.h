#ifndef __OS_UTILS__
#define __OS_UTILS__

#include <chrono>
#include <string>
#include <vector>

namespace os
{
	bool exists(const std::string& path);
	bool isDirectory(const std::string& path);
	bool createDirectory(const std::string& path);

	std::vector<std::string> directoryEntries(const std::string& dir, bool listDirectories, bool listFiles);
	std::vector<std::string> subDirectories(const std::string& dir);
	std::vector<std::string> filesInDirectory(const std::string& dir);

	std::string runningProcessPath();

	time_t modifiedTime(const std::string& path);

	bool moveFile(const std::string& src, const std::string& dst);
	bool copyFile(const std::string& src, const std::string& dst);
	bool removeFile(const std::string& path);

	bool writeFile(const std::string& path, const std::string& text);
}

#endif
