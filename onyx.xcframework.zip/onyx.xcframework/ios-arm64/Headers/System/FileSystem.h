#pragma once

#include <string>

#include <bx/pixelformat.h>
#include <bgfx/bgfx.h>
#include <bimg/bimg.h>
#include <bx/readerwriter.h>
#include <bx/file.h>

#include <functional>

#include <tinystl/allocator.h>
#include <tinystl/vector.h>
#include <Logging/LogManager.h>

#include <Warnings.h>

namespace onyx {
namespace core {
namespace FileSystem {

	struct CallbackStub : public bgfx::CallbackI
	{
		std::function<void(char const*, uint16_t, bgfx::Fatal::Enum, char const*)> mFatalCallback;
		std::function<void(const char*, uint16_t, const char*, va_list)> mTraceVargsCallback;

		virtual ~CallbackStub()
		{
		}

		virtual void fatal(const char* _filePath, uint16_t _line, bgfx::Fatal::Enum _code, const char* _str) override;

		virtual void traceVargs(const char* _filePath, uint16_t _line, const char* _format, va_list _argList) override;

		virtual void profilerBegin(const char* /*_name*/, uint32_t /*_abgr*/, const char* /*_filePath*/, uint16_t /*_line*/) override
		{
		}

		virtual void profilerBeginLiteral(const char* /*_name*/, uint32_t /*_abgr*/, const char* /*_filePath*/, uint16_t /*_line*/) override
		{
		}

		virtual void profilerEnd() override
		{
		}

		virtual uint32_t cacheReadSize(uint64_t /*_id*/) override
		{
			return 0;
		}

		virtual bool cacheRead(uint64_t /*_id*/, void* /*_data*/, uint32_t /*_size*/) override
		{
			return false;
		}

		virtual void cacheWrite(uint64_t /*_id*/, const void* /*_data*/, uint32_t /*_size*/) override
		{
		}

		virtual void screenShot(const char* _filePath, uint32_t _width, uint32_t _height, uint32_t _pitch, const void* _data, uint32_t _size, bool _yflip) override;

		virtual void captureBegin(uint32_t /*_width*/, uint32_t /*_height*/, uint32_t /*_pitch*/, bgfx::TextureFormat::Enum /*_format*/, bool /*_yflip*/) override
		{
			BX_TRACE("Warning: using capture without callback (a.k.a. pointless).");
		}

		virtual void captureEnd() override
		{
		}

		virtual void captureFrame(const void* /*_data*/, uint32_t /*_size*/) override
		{
		}
	};

	void setPrefix(std::string const& prefix);

	// clean up memory used by methods in BgfxUtils
	void cleanup();

	// load memory from this file
	void* load(const std::string& filePath, uint32_t* _size = NULL, bool prefix = true);

	// free allocated memory (put in a method for cross-platform compatibility)
	void unload(void* ptr);

	// save or read text
	void saveText(const std::string& path, const std::string& data);

	std::vector<uint8_t> readFileBytes(const std::string& fileName);
	std::string readText(const std::string& fileName, bool prefix = true);

	std::string cwd();

	std::string appendPath(std::string const& rootDir, std::string const& subDir);

	//TODO determine if we want to keep coreSourceDirectory(); it's currently unused.
	std::string coreSourceDirectory();		// NOTE: dependent on directory structure of the repo so only works on windows/osx

	// manipulate and query directories
	bool fileExists(const std::string& fileName);
	
	void deleteMem(void* mem, void* userData);
	const bgfx::Memory* loadMem(const std::string& filePath, bool deleteWhenDone = false);

	extern bx::FileReaderI* getFileReader();
	bx::FileWriterI* getFileWriter();
	bx::AllocatorI* getAllocator();
	bgfx::CallbackI* getCallback();
	static bx::FileReaderI* s_fileReader = NULL;
	static bx::FileWriterI* s_fileWriter = NULL;
#if PLATFORM_ANDROID
	void setApp(void* app);
	void setAssetManager(void* aman);
#endif
	extern bx::AllocatorI* getDefaultAllocator();
	extern bgfx::CallbackI* getDefaultCallback();

	static bx::AllocatorI* g_allocator = getDefaultAllocator();
	static bgfx::CallbackI* g_callback = getDefaultCallback();

	bx::StringT<&g_allocator> s_currentDir;

	class FileReader : public bx::FileReader
	{
		typedef bx::FileReader super;

	public:
		virtual bool open(const bx::FilePath& _filePath, bx::Error* _err) override
		{
			bx::StringT<&g_allocator> filePath(s_currentDir);
			filePath.append(_filePath);
			return super::open(filePath.getPtr(), _err);
		}
	};

	class FileWriter : public bx::FileWriter
	{
		typedef bx::FileWriter super;

	public:
		virtual bool open(const bx::FilePath& _filePath, bool _append, bx::Error* _err) override
		{
			//String filePath(s_currentDir);
			bx::StringT<&g_allocator> filePath(s_currentDir);
			filePath.append(_filePath);
			return super::open(filePath.getPtr(), _append, _err);
		}
	};

} } }