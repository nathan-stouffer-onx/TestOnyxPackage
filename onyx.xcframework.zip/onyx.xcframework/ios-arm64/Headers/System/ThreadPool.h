#ifndef _THREAD_POOL_H_
#define _THREAD_POOL_H_

#include <functional>
#include <unordered_map>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <vector>

#include "OnyxException.h"
#include "Threading.h"
#include "lucid/Profiler.h"
#include "Utils/EnumUtils.h"
#include "Utils/Timer.h"

namespace onyx::core::Threading {

class ThreadPool
{
public:
	using Task = std::function<void()>;
	static constexpr size_t cMaxThreads = 32;

	enum class ThreadStates {
		UNKNOWN = 0,
		INITIALIZING = 1,
		IDLE = 2,
		RUNNING = 3,
		TERMINATED = 4
	};

	struct ThreadInfo {
		std::thread thread;
		thread_id_t threadId;
		time_float_t taskRunStartTime;
		ThreadStates state;
		char const* message;
		mutable bool resetProfiler = false;
		lucid::core::Profiler::Sample const* profilerStatus;
	};

	ThreadPool(std::string const& name, size_t threadCount = 8);
	~ThreadPool();

	void add(Task task);
	void setMessage(char const* message);

	char const* getThreadMessage(size_t threadIndex);
	ThreadStates getThreadState(size_t threadIndex);

	bool isTerminated() const { return !mKeepRunning; }

#if !ONYX_THREADS_ENABLED
	size_t pendingTaskCount() const { return 0; }

#else
	size_t pendingTaskCount() const { return mTasks.size(); }
#endif
	size_t runningTaskCount() const { return mRunningTaskCount; }

	size_t getThreadCount() const { return mThreadCount; }

	ThreadInfo const &getThreadStatus(size_t threadId) const
	{
		ONYX_ASSERT(threadId < mThreadCount, "Invalid thread requested");

#if defined(ONYX_THREADS_ENABLED)
		return mThreadStates[threadId];
#else
		static ThreadInfo const state = { {}, 0, 0, ThreadStates::RUNNING, nullptr, nullptr };
		return state;
#endif
	}

private:
	size_t mThreadCount;
	size_t mRunningTaskCount = 0;
	std::string const mName;
	bool mKeepRunning = true;

#if ONYX_THREADS_ENABLED
	std::vector<ThreadInfo> mThreadStates;
	std::queue<Task> mTasks;
	std::mutex mPoolLock;
	std::condition_variable mReqReadyCondition;
	std::unordered_map<thread_id_t, size_t> mThreadIdMap;

	static int32_t ThreadFunc(ThreadPool* threadPool, size_t threadIndex);
	int32_t PollQueue(size_t threadIndex);
	ThreadInfo& getThreadInfo();
#endif

};

}

namespace std
{

	inline std::string_view toStringView(onyx::core::Threading::ThreadPool::ThreadStates const& value)
	{
		static std::unordered_map<onyx::core::Threading::ThreadPool::ThreadStates, std::string_view> const nameMap = {
			{ onyx::core::Threading::ThreadPool::ThreadStates::UNKNOWN,			"unknown" },
			{ onyx::core::Threading::ThreadPool::ThreadStates::INITIALIZING,	"initializing" },
			{ onyx::core::Threading::ThreadPool::ThreadStates::IDLE,			"idle" },
			{ onyx::core::Threading::ThreadPool::ThreadStates::RUNNING,			"running" },
			{ onyx::core::Threading::ThreadPool::ThreadStates::TERMINATED,		"terminated" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Caching::TileRequester::RequestStatus");
	}

}

#endif // _THREAD_POOL_H_