#include "ThreadPool.h"

#include <Logging/LogManager.h>

#include "OnyxException.h"

#if ONYX_THREADS_ENABLED
#define LOCK(mtx) std::lock_guard lock##mtx(mtx);
#else
#define LOCK(mtx)
#endif

namespace onyx {
namespace core {
namespace Threading {

	char const* sRootProfileScope = "Task Executor Thread";

ThreadPool::ThreadPool(std::string const &name, size_t threadCount)
	: mThreadCount(threadCount)
	, mName(name)
{

#if ONYX_THREADS_ENABLED

	ONYX_ASSERT(threadCount > 0, "Thread Pool must have at least one thread");
	ONYX_ASSERT(threadCount < cMaxThreads, "Thread Pool can have at most 32 threads");

	mThreadStates.reserve(threadCount);

	for (size_t i = 0; i < threadCount; ++i)
	{
		mThreadStates.push_back({ {}, 0, 0, ThreadStates::INITIALIZING, nullptr, nullptr });

		auto& state = mThreadStates.back();
		state.thread = std::thread(ThreadPool::ThreadFunc, this, i);
	}

	do
	{
		bool ready = true;
		for (size_t i = 0; i < threadCount && ready; ++i)
		{
			ready &= mThreadStates[i].state != ThreadStates::INITIALIZING;
		}

		if (ready)
		{
			break;
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(10));
	} while (true);
#endif
}

ThreadPool::~ThreadPool()
{
	logD("ThreadPool exiting");
	mKeepRunning = false;
#if ONYX_THREADS_ENABLED
	// Wake up any sleeping threads
	mReqReadyCondition.notify_all();
	for (auto& ti : mThreadStates)
	{
		ti.thread.join();
	}

	logD("ThreadPool threads shut down");
	mThreadStates.clear();
#endif
	logD("ThreadPool shutdown complete");
}

void ThreadPool::add(Task task)
{
#if ONYX_THREADS_ENABLED
	LOCK(mPoolLock);
	mTasks.push(task);
	mReqReadyCondition.notify_one();
#else
	task();
#endif
}

void ThreadPool::setMessage(char const* message)
{
#if defined(ONYX_THREADS_ENABLED)
	auto &info = getThreadInfo();
	info.message = message;
#else
	logD(message);
#endif
}

#if defined(ONYX_THREADS_ENABLED)

char const* ThreadPool::getThreadMessage(size_t threadIndex)
{
	ONYX_DEBUG_ASSERT(threadIndex >= 0 && threadIndex < mThreadCount, "Invalid threadIndex");
	return mThreadStates[threadIndex].message;
}

ThreadPool::ThreadStates ThreadPool::getThreadState(size_t threadIndex)
{
	ONYX_DEBUG_ASSERT(threadIndex >= 0 && threadIndex < mThreadCount, "Invalid threadIndex");
	return mThreadStates[threadIndex].state;
}

int32_t ThreadPool::ThreadFunc(ThreadPool* threadPool, size_t threadIndex)
{
	ONYX_ASSERT(threadPool != nullptr, "threadPool was not specified");
	return threadPool->PollQueue(threadIndex);
}
	
int32_t ThreadPool::PollQueue(size_t threadIndex)
{
	auto& state = mThreadStates[threadIndex];
	{
		LOCK(mPoolLock);
		state.threadId = CurrentThreadId();
		mThreadIdMap.emplace(state.threadId, threadIndex);
		state.state = ThreadStates::IDLE;
		{
			LUCID_PROFILE_SCOPE(sRootProfileScope);
		}
		state.profilerStatus = const_cast<lucid::core::Profiler::Sample*>(lucid::core::Profiler::samples());
	}

	while (mKeepRunning)
	{
		std::unique_lock lock(mPoolLock);

		mReqReadyCondition.wait(lock, [=] {
			return !mTasks.empty() || !mKeepRunning;
			});
		
		if (!mKeepRunning)
		{
			break;
		}

		Task task = std::move(mTasks.front());
		mTasks.pop();
		++mRunningTaskCount;

		lock.unlock();

		state.state = ThreadStates::RUNNING;
		{
			LUCID_PROFILE_SCOPE(sRootProfileScope);
			state.taskRunStartTime = Utils::Timer::nowMS();
			task();
		}
		state.state = ThreadStates::IDLE;
		state.message = nullptr;
		LOCK(mPoolLock)
		{
			--mRunningTaskCount;
		}
	}

	return 0xDEAD;
}

ThreadPool::ThreadInfo& ThreadPool::getThreadInfo()
{
	auto index = mThreadIdMap.find(CurrentThreadId());

	ONYX_ASSERT(index != mThreadIdMap.end(), "getThreadInfo() called from thread not owned by ThreadPool");

	return mThreadStates[index->second];
}

#else // Threads not enabled

char const* ThreadPool::getThreadMessage(size_t)
{
	return nullptr;
}

ThreadPool::ThreadStates ThreadPool::getThreadState(size_t)
{
	return ThreadPool::ThreadStates::RUNNING;
}

#endif

} } }
