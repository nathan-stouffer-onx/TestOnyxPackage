#pragma once

#include <functional>
#include <mutex>
#include <unordered_map>

#include "System/Threading.h"
#include "Utils/Timer.h"

#if ONYX_TIMED_MUTEXES
#define TIMED_LOCK(mtx, name, waitTime, holdTime) onyx::core::Threading::MutexTiming::TimedLock lock##mtx(mtx, name, waitTime, holdTime);
#elif ONYX_THREADS_ENABLED
#define TIMED_LOCK(mtx, name, waitTime, holdTime) std::lock_guard lock##mtx(mtx);
#else
#define TIMED_LOCK(mtx, name, waitTime, holdTime)
#endif

namespace onyx::core::Threading::MutexTiming
{
	enum class TimePeriod
	{
		WAIT,
		HOLD
	};

#if ONYX_TIMED_MUTEXES

	struct MutexHolder
	{
		thread_id_t threadId;
		char const* name;
	};


	template <typename T>
	class TimedLock
	{

	public:
		using callbackT = std::function<void(char const*, TimedLock const*, char const*, TimePeriod)>;
		
		static callbackT sNotificationCallback;

		TimedLock(T& mutex, char const* name, time_float_t waitNotificationThreshold, time_float_t holdNotificationThreshold)
			: mName(name)
			, mWaitNotificationThreshold(waitNotificationThreshold)
			, mHoldNotificationThreshold(holdNotificationThreshold)
			, mRequestedTime(Utils::Timer::nowMS())
			, mLock(mutex)
			, mAcquiredTime(Utils::Timer::nowMS())
		{
			mWaitTime = mAcquiredTime - mRequestedTime;
			if (mWaitTime > mWaitNotificationThreshold && sNotificationCallback != nullptr)
			{
				if (sMutexHolders.find(&mutex) != sMutexHolders.end())
				{
					sNotificationCallback(mName, this, sMutexHolders[&mutex].name, TimePeriod::WAIT);
				}
			}
			sMutexHolders.emplace(&mutex, MutexHolder{ CurrentThreadId(), mName });
		}

		~TimedLock()
		{
			mHoldTime = Utils::Timer::nowMS() - mAcquiredTime;
			if (mHoldTime > mHoldNotificationThreshold && sNotificationCallback != nullptr)
			{
				sNotificationCallback(mName, this, nullptr, TimePeriod::HOLD);
			}
		}

		time_float_t getWaitTime() const { return mWaitTime; }
		time_float_t getHoldTime() const { return mHoldTime; }

	private:
		// Field declaration order is important so that everything gets
		// initialized in the correct order.
		char const* mName;
		time_float_t mWaitNotificationThreshold;
		time_float_t mHoldNotificationThreshold;
		time_float_t mRequestedTime;
		std::lock_guard<T> mLock;
		time_float_t mAcquiredTime;
		time_float_t mWaitTime = 0;
		time_float_t mHoldTime = 0;

		static std::unordered_map<void*, MutexHolder> sMutexHolders;

	};

	template <typename T>
	std::unordered_map<void*, MutexHolder> TimedLock<T>::sMutexHolders;

#else
	template <typename T>
	class TimedLock
	{

	public:
		using callbackT = std::function<void(char const*, TimedLock const*, char const*, TimePeriod)>;

		static callbackT sNotificationCallback;

		TimedLock(T&, char const*, time_float_t, time_float_t)
		{

		}

		inline time_float_t getWaitTime() const { return 0; }
		inline time_float_t getHoldTime() const { return 0; }

	};

#endif

	template <typename T>
	typename TimedLock<T>::callbackT TimedLock<T>::sNotificationCallback;


}
