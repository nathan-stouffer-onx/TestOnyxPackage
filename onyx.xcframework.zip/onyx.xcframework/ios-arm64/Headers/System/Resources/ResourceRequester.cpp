#include "ResourceRequester.h"

#include <mutex>
#include <unordered_map>

#include "System/OnyxException.h"
#include "System/Threading.h"
#include "Utils/Timer.h"

namespace onyx::core::Resources
{

ResourceCallbackFunction sCallback;

struct RequestInfo
{
	ResourceRequestCompletionCallback callback;
	time_float_t requestTimeMS;
	RequestInfo() : requestTimeMS(Utils::Timer::nowMS()) { }
	RequestInfo(ResourceRequestCompletionCallback callback) : callback(callback), requestTimeMS(Utils::Timer::nowMS()) { }
};

std::unordered_map<ResourceIdentifier, RequestInfo> sRequestMap;
std::recursive_mutex sRequestLock;

void Shutdown()
{
	LOCK(sRequestLock)

	if (sCallback != nullptr)
	{
		// Cancel all pending requests
		for (auto const& info : sRequestMap)
		{
			sCallback(info.first, ResourceRequestType::Cancel);
		}
	}

	sRequestMap.clear();

	sCallback = nullptr;
}

void setResourceCallback(ResourceCallbackFunction callback)
{
	sCallback = callback;
}

void completeResourceRequest(ResourceIdentifier const& resource, ByteArrayPtr &data, ResourceAvailability availability)
{

	RequestInfo info;
	{
		LOCK(sRequestLock);
		logD("Completing resource request: %s", resource.url.c_str());

		auto found = sRequestMap.find(resource);
		if (found == sRequestMap.end())
		{
			std::string message = "Resource was not requested: " + resource.url;
			ONYX_THROW(message);
		}
		info = std::move(found->second);
		sRequestMap.erase(found);
	}

	info.callback(std::move(data), availability);
}

bool requestResource(ResourceIdentifier const& resource, ResourceRequestCompletionCallback completionCallback, ResourceRequestType requestType)
{
	ONYX_DEBUG_ASSERT(sCallback != nullptr, "Resource request callback not set");
	
	LOCK(sRequestLock);

	auto found = sRequestMap.find(resource);

	if (found != sRequestMap.end())
	{
		return false;
	}

	sRequestMap[resource] = RequestInfo(completionCallback);

	sCallback(resource, requestType);
	return true;
}

bool isRequested(ResourceIdentifier const& resource)
{
	return sRequestMap.find(resource) != sRequestMap.end();
}

size_t pendingRequestCount()
{
	return sRequestMap.size();
}

}