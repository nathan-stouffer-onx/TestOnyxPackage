#pragma once

#include <functional>
#include <memory>
#include <string>

// TODO (scott CSONYX-145) replace this with a stream reader interface to alleviate the need to copy around bytes
#include <vector>
#include <limits>

namespace onyx::core::Resources
{
	enum class ResourceRequestType : uint32_t
	{
		Request,
		Cancel
	};

	struct ResourceIdentifier // Just in case we need a more flexibile identifier someday...
	{
		std::string url;
	};

	inline bool operator==(ResourceIdentifier const& lhs, ResourceIdentifier const& rhs)
	{
		return lhs.url == rhs.url;
	}

	using ByteArrayPtr = std::unique_ptr<std::vector<uint8_t>>;
	using ResourceCallbackFunction = std::function<void(ResourceIdentifier const &, ResourceRequestType)>;

	enum class ResourceAvailability : uint32_t
	{
		Unavailable,
		Requested,
		Pending,
		Loaded,
		Unknown = std::numeric_limits<uint32_t>::max()
	};

	using ResourceRequestCompletionCallback = std::function<void(ByteArrayPtr, ResourceAvailability)>;

	struct ResourceState
	{
		ByteArrayPtr bytes;
		ResourceAvailability availabilityState;
	};


	void setResourceCallback(ResourceCallbackFunction callback);

	void completeResourceRequest(ResourceIdentifier const &resource, ByteArrayPtr &data, ResourceAvailability availability);
	
	bool requestResource(ResourceIdentifier const& resource, ResourceRequestCompletionCallback completionCallback, ResourceRequestType requestType = ResourceRequestType::Request);

	void Shutdown();

	bool isRequested(ResourceIdentifier const& resource);

	size_t pendingRequestCount();

}

namespace std
{
	template<>
	struct hash<onyx::core::Resources::ResourceIdentifier>
	{
	public:
		inline size_t operator()(onyx::core::Resources::ResourceIdentifier const& id) const
		{
			return std::hash<std::string>()(id.url);
		}
	};
}
