#pragma once
#if !defined(__ONYX_EXCEPTION_INCLUDED)
#define __ONYX_EXCEPTION_INCLUDED
#include <stdexcept>
#include <memory>
#include <stdio.h>
#include <string>
#include <sstream>
#include <functional>
#include <Logging/LogManager.h>

#include "Utils/StringUtils.h"

#if defined(__clang__)
#if __has_feature(cxx_rtti)
#define RTTI_ENABLED
#endif
#elif defined(__GNUG__)
#if defined(__GXX_RTTI)
#define RTTI_ENABLED
#endif
#elif defined(_MSC_VER)
#if defined(_CPPRTTI)
#define RTTI_ENABLED
#endif
#endif

#define ONYX_COMBINE_HELPER(X, Y) X##Y
#define ONYX_COMBINE_MACRO(X, Y) ONYX_COMBINE_HELPER(X,Y)

#include "Warnings.h"

namespace onyx
{
	class Exception : public std::exception
	{
	private:
		std::unique_ptr<Exception> mInner;
		std::string mMessage;
		std::string mFile;
		uint32_t mLine = 0xFFFFFFFF;
	public:

DISABLE_WARNING_PUSH
DISABLE_WARNING_NOT_DEFINED
#if PLATFORM_EMSCRIPTEN
		Exception() = default;
#endif
DISABLE_WARNING_POP

		Exception(Exception const& other)
			: mMessage(other.mMessage)
			, mFile(other.mFile)
			, mLine(other.mLine)
		{
			if (other.mInner.get() != nullptr)
			{
				mInner.reset(new Exception(*(other.mInner.get())));
			}
			return;
		}

		Exception(std::string const& message)
			: mMessage(message)
		{

		}

		template<typename T>
		static Exception wrap(T const& wrapped)
		{
			return Exception(std::to_string(wrapped));
		}

		Exception(std::string const &file, uint32_t line)
			: Exception(file, line, "")
		{ }

		Exception(std::string const& file, uint32_t line, char const* message)
			: mInner(nullptr)
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		Exception(std::string const &file, uint32_t line, std::string const& message)
			: mInner(nullptr)
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		Exception(std::string const &file, uint32_t line, std::string const& message, Exception const& inner)
			: mInner(new Exception(inner))
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		Exception(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner)
			: mInner(new Exception(inner.what()))
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		const char* what() const noexcept
		{
			return mMessage.c_str();
		}

		Exception const* inner() const
		{
			return mInner.get();
		}
		
		std::string const& message() const
		{
			return mMessage;
		}

		std::string where() const
		{
			if (mFile == "")
			{
				return "";
			}

			std::ostringstream stringStream;

			std::string fileName = mFile;

			size_t filePos = mFile.find("Onyx/Onyx");
			if (filePos == std::string::npos)
			{
				filePos = mFile.find("Onyx\\Onyx");
			}
			if (filePos != std::string::npos)
			{
				fileName = fileName.substr(filePos + 6);
			}

			stringStream << std::endl << "\t at " << fileName << ": line " << mLine;
			return stringStream.str();
		}

		std::string summarize() const
		{
			std::ostringstream outStream;
			if (mInner != nullptr)
			{
				outStream << mInner->summarize();
				outStream << std::endl << "caused:" << std::endl;
			}

			outStream << mMessage << std::endl << where();

			return outStream.str();
		}
	};
	class OnyxFinally
	{
	private:
		std::function<void()> mFunction;
	public:
		OnyxFinally(std::function<void()> function)
			: mFunction(function)
		{
		}

		~OnyxFinally()
		{
			mFunction();
		}
	};

	template<>
	inline Exception Exception::wrap(std::exception const& wrapped)
	{
		return Exception(wrapped.what());
	}
}

// Utility definition to make it easy to define Exception subclasses

#define ONYX_EXCEPTION_SUBTYPE(typeName, parentClass) class typeName : public parentClass \
{   public: \
	typeName(typeName const &other) : parentClass(other) { } \
	typeName(std::string const &file, uint32_t line) : parentClass(file, line) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message) : parentClass(file, line, message) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner) : parentClass(file, line, message, inner) { } \
};

#define ONYX_EXCEPTION_TYPE(typeName) ONYX_EXCEPTION_SUBTYPE(typeName, onyx::Exception)

// Utility definitions to make it easy to throw exceptions
#if NO_ONYX_EXCEPTIONS
#define ONYX_THROW(message) logE(std::string(message));
#define ONYX_THROW_INNER(message, inner) logE(std::string(message));

#define ONYX_ASSERT(condition, message) if (!(condition)) logE(std::string(message));

#ifdef _DEBUG
#define ONYX_DEBUG_ASSERT(condition, message) if (!(condition)) logE(std::string(message));
#else
#define ONYX_DEBUG_ASSERT(condition, message)
#endif

#define ONYX_CUSTOM_THROW(type, message) logE(std::string(message));
#define ONYX_CUSTOM_THROW_INNER(type, message, inner) logE(std::string(message), inner);

#define ONYX_CUSTOM_ASSERT(condition, type, message) if (!(condition)) logE(std::string(message));

#define ONYX_TRY {
#define ONYX_CATCH } if (false) { onyx::Exception ex(__FILE__, __LINE__);
#define ONYX_CATCH_TYPE(type) } if (false) { type ex; 
#define ONYX_CUSTOM_CATCH(type) } if (false) { type ex(__FILE__, __LINE__);
#define ONYX_CATCH_ALL } if (false) {
#define ONYX_END_CATCH }
#define ONYX_RETHROW(x)
#define ONYX_CUSTOM_RETHROW(type, message)

#else
#define ONYX_THROW(message) { onyx::Exception ONYX_COMBINE_MACRO(__EX,__LINE__)(__FILE__, __LINE__, message); throw ONYX_COMBINE_MACRO(__EX,__LINE__); }

#define ONYX_THROW_INNER(message, inner) { onyx::Exception ONYX_COMBINE_MACRO(__EX,__LINE__)(__FILE__, __LINE__, message, inner); throw ONYX_COMBINE_MACRO(__EX,__LINE__); }

#define ONYX_ASSERT(condition, message) if (!(condition)) ONYX_THROW(message);
#ifdef _DEBUG
#define ONYX_DEBUG_ASSERT(condition, message) if (!(condition)) throw onyx::Exception(__FILE__, __LINE__, std::string(message));
#else
#define ONYX_DEBUG_ASSERT(condition, message)
#endif

#define ONYX_CUSTOM_THROW(type, message) throw type(__FILE__, __LINE__, std::string(message));
#define ONYX_CUSTOM_THROW_INNER(type, message, inner) throw type(__FILE__, __LINE__, std::string(message), inner);

#define ONYX_CUSTOM_ASSERT(condition, type, message) if (!(condition)) throw type(__FILE__, __LINE__, std::string(message));

#define ONYX_TRY try {
#define ONYX_CATCH } catch (onyx::Exception &ex) {
#define ONYX_CATCH_TYPE(type) } catch (type &ex) { 
#define ONYX_CUSTOM_CATCH(type) } catch (type &ex) {
#define ONYX_CATCH_ALL } catch (...) {
#define ONYX_END_CATCH }
#define ONYX_RETHROW(message) ONYX_THROW_INNER(message, ex);
#define ONYX_CUSTOM_RETHROW(type, message) ONYX_CUSTOM_THROW_INNER(type, message, ex)
#endif

#define ONYX_FINALLY onyx::OnyxFinally ONYX_COMBINE_MACRO(cleanup, __LINE__)

#endif

#define ONYX_THROW_F(message, ...) ONYX_THROW(Utils::format(message, __VA_ARGS__))
#define ONYX_THROW_INNER_F(message, inner, ...) ONYX_THROW_INNER(Utils::format(message, __VA_ARGS__), inner)
#define ONYX_ASSERT_F(condition, message, ...) ONYX_ASSERT(condition, Utils::format(message, __VA_ARGS__));
#define ONYX_DEBUG_ASSERT_F(condition, message, ...) ONYX_DEBUG_ASSERT(condition, Utils::format(message, __VA_ARGS__));
#define ONYX_CUSTOM_THROW_F(type, message, ...) ONYX_CUSTOM_THROW(type, Utils::format(message, __VA_ARGS__));
#define ONYX_CUSTOM_THROW_INNER_F(type, message, inner, ...) ONYX_CUSTOM_THROW_INNER(type, Utils::format(message, __VA_ARGS__), inner);
#define ONYX_CUSTOM_ASSERT_F(condition, type, message, ...) ONYX_CUSTOM_ASSERT(condition, type, Utils::format(message, __VA_ARGS__));
#define ONYX_RETHROW_F(message, ...) ONYX_RETHROW(Utils::format(message, __VA_ARGS__));
#define ONYX_CUSTOM_RETHROW_F(type, message, ...) ONYX_CUSTOM_RETHROW(type, Utils::format(message, __VA_ARGS__), ex)