#pragma once
#if !defined(__ONYX_EXCEPTION_INCLUDED)
#define __ONYX_EXCEPTION_INCLUDED
#include <stdexcept>
#include <memory>
#include <stdio.h>
#include <string>
#include <sstream>
#include <functional>
#include <Logging/LogManager.h>

#if defined(__clang__)
#if __has_feature(cxx_rtti)
#define RTTI_ENABLED
#endif
#elif defined(__GNUG__)
#if defined(__GXX_RTTI)
#define RTTI_ENABLED
#endif
#elif defined(_MSC_VER)
#if defined(_CPPRTTI)
#define RTTI_ENABLED
#endif
#endif

#define ONYX_COMBINE_HELPER(X, Y) X##Y
#define ONYX_COMBINE_MACRO(X, Y) ONYX_COMBINE_HELPER(X,Y)

#include "Warnings.h"

namespace OnyxUtil
{
	class OnyxException : public std::exception
	{
	private:
		std::unique_ptr<OnyxException> mInner;
		std::string mMessage;
		std::string mFile;
		uint32_t mLine = 0xFFFFFFFF;
	public:

DISABLE_WARNING_PUSH
DISABLE_WARNING_NOT_DEFINED
#if PLATFORM_EMSCRIPTEN
		OnyxException() = default;
#endif
DISABLE_WARNING_POP

		OnyxException(OnyxException const& other)
			: mMessage(other.mMessage)
			, mFile(other.mFile)
			, mLine(other.mLine)
		{
			if (other.mInner.get() != nullptr)
			{
				mInner.reset(new OnyxException(*(other.mInner.get())));
			}
			return;
		}

		OnyxException(std::string const& message)
			: mMessage(message)
		{

		}

		template<typename T>
		static OnyxException wrap(T const& wrapped)
		{
			return OnyxException(std::to_string(wrapped));
		}

		OnyxException(std::string const &file, uint32_t line)
			: OnyxException(file, line, "")
		{ }

		OnyxException(std::string const& file, uint32_t line, char const* message)
			: mInner(nullptr)
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		OnyxException(std::string const &file, uint32_t line, std::string const& message)
			: mInner(nullptr)
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		OnyxException(std::string const &file, uint32_t line, std::string const& message, OnyxException const& inner)
			: mInner(new OnyxException(inner))
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		OnyxException(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner)
			: mInner(new OnyxException(inner.what()))
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		const char* what() const noexcept
		{
			return mMessage.c_str();
		}

		OnyxException const* inner() const
		{
			return mInner.get();
		}
		
		std::string const& message() const
		{
			return mMessage;
		}

		std::string where() const
		{
			if (mFile == "")
			{
				return "";
			}

			std::ostringstream stringStream;

			std::string fileName = mFile;

			size_t filePos = mFile.find("Onyx/Onyx");
			if (filePos == std::string::npos)
			{
				filePos = mFile.find("Onyx\\Onyx");
			}
			if (filePos != std::string::npos)
			{
				fileName = fileName.substr(filePos + 6);
			}

			stringStream << std::endl << "\t at " << fileName << ": line " << mLine;
			return stringStream.str();
		}

		std::string summarize() const
		{
			std::ostringstream outStream;
			if (mInner != nullptr)
			{
				outStream << mInner->summarize();
				outStream << std::endl << "caused:" << std::endl;
			}

			outStream << mMessage << std::endl << where();

			return outStream.str();
		}
	};
	class OnyxFinally
	{
	private:
		std::function<void()> mFunction;
	public:
		OnyxFinally(std::function<void()> function)
			: mFunction(function)
		{
		}

		~OnyxFinally()
		{
			mFunction();
		}
	};

	template<>
	inline OnyxException OnyxException::wrap(std::exception const& wrapped)
	{
		return OnyxException(wrapped.what());
	}
}

// Utility definition to make it easy to define OnyxException subclasses
#ifdef PLATFORM_EMSCRIPTEN
#define ONYX_EXCEPTION_SUBTYPE(typeName, parentClass) class typeName : public parentClass \
{   public: \
	typeName() : parentClass() { } \
	typeName(typeName const &other) : parentClass(other) { } \
	typeName(std::string const &file, uint32_t line) : parentClass(file, line) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message) : parentClass(file, line, message) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner) : parentClass(file, line, message, inner) { } \
};
#else
#define ONYX_EXCEPTION_SUBTYPE(typeName, parentClass) class typeName : public parentClass \
{   public: \
	typeName(typeName const &other) : parentClass(other) { } \
	typeName(std::string const &file, uint32_t line) : parentClass(file, line) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message) : parentClass(file, line, message) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner) : parentClass(file, line, message, inner) { } \
};
#endif

#define ONYX_EXCEPTION_TYPE(typeName) ONYX_EXCEPTION_SUBTYPE(typeName, OnyxUtil::OnyxException)

// Utility definitions to make it easy to throw exceptions
#if NO_ONYX_EXCEPTIONS
#define ONYX_THROW(message) logE(std::string(message));
#define ONYX_THROW_INNER(message, inner) logE(std::string(message));

#define ONYX_ASSERT(condition, message) if (!(condition)) logE(std::string(message));
#define ONYX_DEBUG_ASSERT(condition, message) if (!(condition)) logE(std::string(message));

#define ONYX_CUSTOM_THROW(type, message) logE(std::string(message));
#define ONYX_CUSTOM_THROW_INNER(type, message, inner) logE(std::string(message), inner);

#define ONYX_CUSTOM_ASSERT(condition, type, message) if (!(condition)) logE(std::string(message));

#define ONYX_TRY {
#define ONYX_CATCH } if (false) { OnyxUtil::OnyxException ex(__FILE__, __LINE__);
// We throw std::exception in some places, which doesn't accept (string, int) in any constructor
#if PLATFORM_EMSCRIPTEN
#define ONYX_CUSTOM_CATCH(type) } if (false) { type ex;
#else
#define ONYX_CUSTOM_CATCH(type) } if (false) { type ex(__FILE__, __LINE__);
#endif
#define ONYX_CATCH_ALL } if (false) {
#define ONYX_END_CATCH }
#define ONYX_RETHROW(x)
#define ONYX_CUSTOM_RETHROW(type, message)

#else
#define ONYX_THROW(message) { OnyxUtil::OnyxException ONYX_COMBINE_MACRO(__EX,__LINE__)(__FILE__, __LINE__, message); throw ONYX_COMBINE_MACRO(__EX,__LINE__); }
#define ONYX_THROW_INNER(message, inner) { OnyxUtil::OnyxException ONYX_COMBINE_MACRO(__EX,__LINE__)(__FILE__, __LINE__, message, inner); throw ONYX_COMBINE_MACRO(__EX,__LINE__); }

#define ONYX_ASSERT(condition, message) if (!(condition)) ONYX_THROW(message);
#ifdef _DEBUG
#define ONYX_DEBUG_ASSERT(condition, message) if (!(condition)) throw OnyxUtil::OnyxException(__FILE__, __LINE__, std::string(message));
#else
#define ONYX_DEBUG_ASSERT(condition, message)
#endif

#define ONYX_CUSTOM_THROW(type, message) throw type(__FILE__, __LINE__, std::string(message));
#define ONYX_CUSTOM_THROW_INNER(type, message, inner) throw type(__FILE__, __LINE__, std::string(message), inner);

#define ONYX_CUSTOM_ASSERT(condition, type, message) if (!(condition)) throw type(__FILE__, __LINE__, std::string(message));

#define ONYX_TRY try {
#define ONYX_CATCH } catch (OnyxUtil::OnyxException &ex) {
#define ONYX_CUSTOM_CATCH(type) } catch (type &ex) {
#define ONYX_CATCH_ALL } catch (...) {
#define ONYX_END_CATCH }
#define ONYX_RETHROW(message) ONYX_THROW_INNER(message, ex);
#define ONYX_CUSTOM_RETHROW(type, message) ONYX_CUSTOM_THROW_INNER(type, message, ex)
#endif

#define ONYX_FINALLY OnyxUtil::OnyxFinally ONYX_COMBINE_MACRO(cleanup, __LINE__)

#endif