#pragma once

#if ONYX_THREADS_ENABLED
#define LOCK(mtx) std::lock_guard lock##mtx##__LINE__(mtx);
#else
#define LOCK(mtx)
#endif

namespace onyx::core::Threading {

	enum class Priority
	{
		IDLE,
		BACKGROUND,
		LOW,
		NORMAL,
		HIGH,
		REALTIME
	};

	using thread_id_t = unsigned int;

	thread_id_t CurrentThreadId();
	bool setPriority(Priority newPriority);
	void setThreadName(char const* name);

}