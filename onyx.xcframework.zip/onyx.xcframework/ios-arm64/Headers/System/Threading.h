#pragma once

#if !defined(CORE_THREADING_H)
#define CORE_THREADING_H


namespace onyx {
namespace core {
namespace Threading {

	enum class Priority
	{
		IDLE,
		BACKGROUND,
		LOW,
		NORMAL,
		HIGH,
		REALTIME
	};

	bool setPriority(Priority newPriority);

} } }

#endif