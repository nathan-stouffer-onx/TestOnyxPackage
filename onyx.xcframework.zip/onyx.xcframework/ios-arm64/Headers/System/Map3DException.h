#pragma once
#if !defined(__MAP3D_EXCEPTION_INCLUDED)
#define __MAP3D_EXCEPTION_INCLUDED
#include <stdexcept>
#include <memory>
#include <stdio.h>
#include <string>
#include <sstream>
#include <functional>
#include <Logging/LogManager.h>

#if defined(__clang__)
#if __has_feature(cxx_rtti)
#define RTTI_ENABLED
#endif
#elif defined(__GNUG__)
#if defined(__GXX_RTTI)
#define RTTI_ENABLED
#endif
#elif defined(_MSC_VER)
#if defined(_CPPRTTI)
#define RTTI_ENABLED
#endif
#endif

#include "Warnings.h"

namespace Map3DUtil
{
	class Map3DException : public std::exception
	{
	private:
		std::unique_ptr<Map3DException> mInner;
		std::string mMessage;
		std::string mFile;
		uint32_t mLine = 0xFFFFFFFF;
	public:

DISABLE_WARNING_PUSH
DISABLE_WARNING_NOT_DEFINED
#if PLATFORM_EMSCRIPTEN
		Map3DException() = default;
#endif
DISABLE_WARNING_POP

		Map3DException(Map3DException const& other)
			: mMessage(other.mMessage)
			, mFile(other.mFile)
			, mLine(other.mLine)
		{
			if (other.mInner.get() != nullptr)
			{
				mInner.reset(new Map3DException(*(other.mInner.get())));
			}
			return;
		}

		Map3DException(std::string const& message)
			: mMessage(message)
		{

		}

		template<typename T>
		static Map3DException wrap(T const& wrapped)
		{
			return Map3DException(std::to_string(wrapped));
		}

		Map3DException(std::string const &file, uint32_t line)
			: Map3DException(file, line, "")
		{ }

		Map3DException(std::string const& file, uint32_t line, char const* message)
			: mInner(nullptr)
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		Map3DException(std::string const &file, uint32_t line, std::string const& message)
			: mInner(nullptr)
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		Map3DException(std::string const &file, uint32_t line, std::string const& message, Map3DException const& inner)
			: mInner(new Map3DException(inner))
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		Map3DException(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner)
			: mInner(new Map3DException(inner.what()))
			, mMessage(message)
			, mFile(file)
			, mLine(line)
		{
			logE(message);
		}

		const char* what() const noexcept
		{
			return mMessage.c_str();
		}

		Map3DException const* inner() const
		{
			return mInner.get();
		}
		
		std::string const& message() const
		{
			return mMessage;
		}

		std::string where() const
		{
			if (mFile == "")
			{
				return "";
			}

			std::ostringstream stringStream;

			std::string fileName = mFile;

			size_t filePos = mFile.find("Map3D/Map3D");
			if (filePos == std::string::npos)
			{
				filePos = mFile.find("Map3D\\Map3D");
			}
			if (filePos != std::string::npos)
			{
				fileName = fileName.substr(filePos + 6);
			}

			stringStream << std::endl << "\t at " << fileName << ": line " << mLine;
			return stringStream.str();
		}

		std::string summarize() const
		{
			std::ostringstream outStream;
			if (mInner != nullptr)
			{
				outStream << mInner->summarize();
				outStream << std::endl << "caused:" << std::endl;
			}

			outStream << mMessage << std::endl << where();

			return outStream.str();
		}
	};
	class Map3DFinally
	{
	private:
		std::function<void()> mFunction;
	public:
		Map3DFinally(std::function<void()> function)
			: mFunction(function)
		{
		}

		~Map3DFinally()
		{
			mFunction();
		}
	};

	template<>
	inline Map3DException Map3DException::wrap(std::exception const& wrapped)
	{
		return Map3DException(wrapped.what());
	}
}

// Utility definition to make it easy to define Map3DException subclasses
#ifdef PLATFORM_EMSCRIPTEN
#define MAP3D_EXCEPTION_SUBTYPE(typeName, parentClass) class typeName : public parentClass \
{   public: \
	typeName() : parentClass() { } \
	typeName(typeName const &other) : parentClass(other) { } \
	typeName(std::string const &file, uint32_t line) : parentClass(file, line) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message) : parentClass(file, line, message) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner) : parentClass(file, line, message, inner) { } \
};
#else
#define MAP3D_EXCEPTION_SUBTYPE(typeName, parentClass) class typeName : public parentClass \
{   public: \
	typeName(typeName const &other) : parentClass(other) { } \
	typeName(std::string const &file, uint32_t line) : parentClass(file, line) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message) : parentClass(file, line, message) { } \
	typeName(std::string const &file, uint32_t line, std::string const& message, std::exception const& inner) : parentClass(file, line, message, inner) { } \
};
#endif

#define MAP3D_EXCEPTION_TYPE(typeName) MAP3D_EXCEPTION_SUBTYPE(typeName, Map3DUtil::Map3DException)

// Utility definitions to make it easy to throw exceptions
#if NO_MAP3D_EXCEPTIONS
#define MAP3D_THROW(message) logE(std::string(message));
#define MAP3D_THROW_INNER(message, inner) logE(std::string(message));

#define MAP3D_ASSERT(condition, message) if (!(condition)) logE(std::string(message));
#define MAP3D_DEBUG_ASSERT(condition, message) if (!(condition)) logE(std::string(message));

#define MAP3D_CUSTOM_THROW(type, message) logE(std::string(message));
#define MAP3D_CUSTOM_THROW_INNER(type, message, inner) logE(std::string(message), inner);

#define MAP3D_CUSTOM_ASSERT(condition, type, message) if (!(condition)) logE(std::string(message));

#define MAP3D_TRY {
#define MAP3D_CATCH } if (false) { Map3DUtil::Map3DException ex(__FILE__, __LINE__);
// We throw std::exception in some places, which doesn't accept (string, int) in any constructor
#if PLATFORM_EMSCRIPTEN
#define MAP3D_CUSTOM_CATCH(type) } if (false) { type ex;
#else
#define MAP3D_CUSTOM_CATCH(type) } if (false) { type ex(__FILE__, __LINE__);
#endif
#define MAP3D_CATCH_ALL } if (false) {
#define MAP3D_END_CATCH }
#define MAP3D_RETHROW(x)
#define MAP3D_CUSTOM_RETHROW(type, message)

#else
#define MAP3D_THROW(message) { Map3DUtil::Map3DException __EX##__LINE__(__FILE__, __LINE__, message); throw __EX##__LINE__; }
#define MAP3D_THROW_INNER(message, inner) { Map3DUtil::Map3DException __EX##__LINE__(__FILE__, __LINE__, message, inner); throw __EX##__LINE__; }

#define MAP3D_ASSERT(condition, message) if (!(condition)) MAP3D_THROW(message);
#ifdef _DEBUG
#define MAP3D_DEBUG_ASSERT(condition, message) if (!(condition)) throw Map3DUtil::Map3DException(__FILE__, __LINE__, std::string(message));
#else
#define MAP3D_DEBUG_ASSERT(condition, message)
#endif

#define MAP3D_CUSTOM_THROW(type, message) throw type(__FILE__, __LINE__, std::string(message));
#define MAP3D_CUSTOM_THROW_INNER(type, message, inner) throw type(__FILE__, __LINE__, std::string(message), inner);

#define MAP3D_CUSTOM_ASSERT(condition, type, message) if (!(condition)) throw type(__FILE__, __LINE__, std::string(message));

#define MAP3D_TRY try {
#define MAP3D_CATCH } catch (Map3DUtil::Map3DException &ex) {
#define MAP3D_CUSTOM_CATCH(type) } catch (type &ex) {
#define MAP3D_CATCH_ALL } catch (...) {
#define MAP3D_END_CATCH }
#define MAP3D_RETHROW(message) MAP3D_THROW_INNER(message, ex);
#define MAP3D_CUSTOM_RETHROW(type, message) MAP3D_CUSTOM_THROW_INNER(type, message, ex)
#endif

#define MAP3D_FINALLY Map3DUtil::Map3DFinally cleanup

#endif