#include "Threading.h"

#include <algorithm>

#include "Warnings.h"

#ifdef WIN32
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#else
#include <pthread.h>
#include <sched.h>
#endif

namespace onyx {
namespace core {
namespace Threading {

	thread_id_t CurrentThreadId()
	{
#ifdef PLATFORM_WINDOWS
		return GetCurrentThreadId();
#elif PLATFORM_ANDROID
		return pthread_self();
#elif PLATFORM_IOS | PLATFORM_OSX
		mach_port_t machTID = pthread_mach_thread_np(pthread_self());
		return machTID;
#elif PLATFORM_EMSCRIPTEN
		return pthread_self();
#endif
	}

DISABLE_WARNING_PUSH
DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
	bool setPriority(Priority newPriority)
	{

#ifdef WIN32

		auto systemPriority = newPriority == Priority::BACKGROUND ? THREAD_PRIORITY_LOWEST :
							 newPriority == Priority::LOW ? THREAD_PRIORITY_BELOW_NORMAL :
							 newPriority == Priority::NORMAL ? THREAD_PRIORITY_NORMAL :
							 newPriority == Priority::HIGH ? THREAD_PRIORITY_HIGHEST :
							 newPriority == Priority::REALTIME ? THREAD_PRIORITY_TIME_CRITICAL :
							 THREAD_PRIORITY_IDLE;

		return SetThreadPriority(GetCurrentThread(), systemPriority);

#else
		int policy;
		sched_param params;
		if (pthread_getschedparam(pthread_self(), &policy, &params) == 0)
		{
			int const min_value = sched_get_priority_min(policy);
			int const max_value = sched_get_priority_max(policy);

			if (min_value != -1)
			{
				int actual = (min_value + max_value) >> 1;
				switch (newPriority)
				{
					case Priority::IDLE:
						actual = min_value;
						break;
					case Priority::BACKGROUND:
						actual = min_value + 1;
						break;
					case Priority::LOW:
						actual = (actual + min_value) >> 1;
						break;
					case Priority::NORMAL:
						break;
					case Priority::HIGH:
						actual = (actual + max_value) >> 1;
						break;
					case Priority::REALTIME:
						actual = max_value;
						break;
				}

				actual = std::max(min_value, std::min(max_value, actual));

				if (params.sched_priority != actual)
				{
					params.sched_priority = actual;
					if (pthread_setschedparam(pthread_self(), policy, &params) != -1)
					{
						return true;
					}
				}
			}
		}

		return false;
#endif
	}
DISABLE_WARNING_POP

// Shamelessly borrowed from BGFX
void setThreadName(const char* _name)
{
#if defined(PLATFORM_WINDOWS)
	// Try to use the new thread naming API from Win10 Creators update onwards if we have it
	typedef HRESULT(WINAPI* SetThreadDescriptionProc)(HANDLE, PCWSTR);
	SetThreadDescriptionProc SetThreadDescription = reinterpret_cast<SetThreadDescriptionProc>(::GetProcAddress(GetModuleHandleA("Kernel32.dll"), "SetThreadDescription"));

	if (SetThreadDescription != nullptr)
	{
		uint32_t length = (uint32_t) strlen(_name) + 1;
		uint32_t size = length * sizeof(wchar_t);
		wchar_t* name = (wchar_t*) malloc(size);
		mbstowcs(name, _name, size - 2);
		SetThreadDescription(HANDLE(size_t(GetCurrentThreadId())), name);
		free(name);
	}
#elif defined(PLATFORM_ANDROID) || defined(PLATFORM_LINUX)
	pthread_setname_np(CurrentThreadId(), _name);
#elif defined(PLATFORM_EMSCRIPTEN)
	// Not supported by WASM as far as I can tell
#else
	pthread_setname_np(_name);
#endif // BX_PLATFORM_
}

} } }