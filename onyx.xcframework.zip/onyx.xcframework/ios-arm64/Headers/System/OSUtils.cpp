#include "OSUtils.h"

#include <fstream>
#include <iostream>
#include <unordered_set>

#if defined(PLATFORM_WINDOWS)	
#include <Windows.h>
#include <filesystem>
#include <chrono>
namespace fs = std::filesystem;
#else
#include <sys/stat.h>
#endif

#if defined(PLATFORM_OSX)
#include <unistd.h>
#include <CoreFoundation/CFBundle.h>
#include <cstdio>
#include <mach-o/dyld.h>
#include <copyfile.h>
#include <dirent.h>
#endif

#if defined(PLATFORM_LINUX)
#include <unistd.h>
#include <cstdio>
#include <dirent.h>
#endif

#include "OnyxException.h"

#if defined(PLATFORM_ANDROID) || defined(PLATFORM_EMSCRIPTEN)
#include "Warnings.h"
DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
#endif

// TODO (Ronald): I wonder how much we can reduce code/maintenance on here through std::filesystem?
// Would need to look if our linux build supports it though...

namespace os
{

    bool exists(const std::string& path)
    {
#if defined(PLATFORM_WINDOWS)
        return fs::exists(path);
#elif defined(PLATFORM_OSX)
        struct stat buffer;
        return (stat(path.c_str(), &buffer) == 0);
#elif defined(PLATFORM_LINUX)
		struct stat buffer;
		return (stat(path.c_str(), &buffer) == 0);
#else
        std::cout << "function exists not implemented on this platform\n";
        return false;
#endif
     }

    bool isDirectory(const std::string& path)
    {
#if defined(PLATFORM_WINDOWS)
        return fs::is_directory(path);
#elif defined(PLATFORM_OSX)
        struct stat info;
        // check if info was returned at all
        if (stat(path.c_str(), &info) != 0)
        {
            return false;
        }
        // check if we have a directory
        return (info.st_mode & S_IFDIR) ? true : false;
#elif defined(PLATFORM_LINUX)
		struct stat info;
		// check if info was returned at all
		if (stat(path.c_str(), &info) != 0)
		{
			return false;
		}
		// check if we have a directory
		return (info.st_mode & S_IFDIR) ? true : false;
#else
        std::cout << "function isDirectory not implemented for this platform\n";
        return false;
#endif
    }

    bool createDirectory(const std::string& path)
    {
        if (!os::exists(path))
        {
#if defined(PLATFORM_WINDOWS)
            fs::create_directory(path);
#elif defined(PLATFORM_OSX)
            int success = mkdir(path.c_str(), 0777);
            if (success == -1)
            {
				return false;
            }
#elif defined(PLATFORM_LINUX)
			int success = mkdir(path.c_str(), 0777);
			if (success == -1)
			{
				return false;
			}
#else
            std::cout << "function createDirectory not implemented for this platform\n";
            return false;
#endif
            return true;
        }
        else if (!os::isDirectory(path))
        {
            return false;
        }
        else
        {
            return true;
        }
    }

	std::unordered_set<std::string> const sParentDirectories = { ".", ".." };

	bool isParentDirectory(std::string const& dirName)
	{
		return sParentDirectories.find(dirName) != sParentDirectories.end();
	}

DISABLE_WARNING_PUSH
DISABLE_WARNING_UNUSED_VARIABLE
	std::vector<std::string> directoryEntries(const std::string& dir, bool listDirectories, bool listFiles)
	{
		bool all = listDirectories && listFiles;
		std::vector<std::string> result;
		if (os::isDirectory(dir))
		{
#if defined(PLATFORM_WINDOWS)
			for (const auto& item : fs::directory_iterator{ dir })
			{
				if (isParentDirectory(item.path().filename().string()))
				{
					continue;
				}
				if (all
					|| (item.is_directory() && listDirectories)
					|| (!item.is_directory() && listFiles))
				{
					result.push_back(item.path().filename().string());
				}
			}
#elif defined(PLATFORM_OSX)
			DIR* dirPtr;
			struct dirent* item;

			if ((dirPtr = opendir(dir.c_str())) != nullptr)
			{
				while ((item = readdir(dirPtr)) != nullptr)
				{
					if (isParentDirectory(item->d_name))
					{
						continue;
					}
					if (all
						|| (item->d_type == DT_DIR && listDirectories)
						|| (item->d_type != DT_DIR && listFiles))
					{
						result.push_back(std::string(item->d_name));
					}
				}
				closedir(dirPtr);
			}
#elif defined(PLATFORM_LINUX)
			DIR* dirPtr;
			struct dirent* item;

			if ((dirPtr = opendir(dir.c_str())) != nullptr)
			{
				while ((item = readdir(dirPtr)) != nullptr)
				{
					if (isParentDirectory(item->d_name))
					{
						continue;
					}
					if (all
						|| (item->d_type == DT_DIR && listDirectories)
						|| (item->d_type != DT_DIR && listFiles))
					{
						result.push_back(std::string(item->d_name));
					}
				}
				closedir(dirPtr);
			}
#else
			std::cout << "fileInDirectory not implemented for this platform" << std::endl;
#endif
		}
		return result;
	}
DISABLE_WARNING_POP

	std::vector<std::string> subDirectories(const std::string& dir)
	{
		return directoryEntries(dir, true, false);
	}

    std::vector<std::string> filesInDirectory(const std::string& dir)
    {
		return directoryEntries(dir, false, true);
    }

	std::string runningProcessPath()
    {
#if defined(PLATFORM_WINDOWS)
        TCHAR path[MAX_PATH];
        GetModuleFileName(nullptr, path, MAX_PATH);
        return std::string(path);
#elif defined(PLATFORM_OSX)
		uint32_t size = PATH_MAX;
		char result[size];
		_NSGetExecutablePath(result, &size);
		return std::string(result);
#elif defined(PLATFORM_LINUX)
		uint32_t size = PATH_MAX;
		char result[size];
		getcwd(result, sizeof(result));		
		return std::string(result);
#elif defined(PLATFORM_EMSCRIPTEN)
		return std::string("");
#else
		ONYX_THROW("runningProcessPath not implemented for this platform");
#endif
    }

    time_t modifiedTime(const std::string& path)
    {
        // if the file doesn't exist 
        if (!os::exists(path))
        {
            return 0;
        }

#if defined(PLATFORM_WINDOWS)
        auto modTime = fs::last_write_time(path);
        auto dur = modTime.time_since_epoch();
        return dur.count();
#elif defined(PLATFORM_OSX)
		struct stat info;
		// check if info was returned at all
		if (stat(path.c_str(), &info) != 0)
		{
			return 0;
		}
		return info.st_mtimespec.tv_sec;
#elif defined(PLATFORM_LINUX)
		struct stat info;
		// check if info was returned at all
		if (stat(path.c_str(), &info) != 0)
		{
			return 0;
		}
		return info.st_mtime;
#else
        std::cout << "modifiedTime not implemented for this platform" << std::endl;
        return 0;
#endif
    }

    bool moveFile(const std::string& src, const std::string& dst)
    {
#if defined(PLATFORM_WINDOWS)
        fs::rename(src, dst);
        return true;
#elif defined(PLATFORM_OSX)
		std::rename(src.c_str(), dst.c_str());
        return true;
#elif defined(PLATFORM_LINUX)
		std::rename(src.c_str(), dst.c_str());
		return true;
#else
        std::cout << "moveFile not implemented for this platform" << std::endl;
        return false;
#endif
    }

    bool copyFile(const std::string& src, const std::string& dst)
    {
#if defined(PLATFORM_WINDOWS)
        fs::copy_file(src, dst);
        return true;
#elif defined(PLATFORM_OSX)
		std::ifstream srcStream(src, std::ios::binary);
		std::ofstream dstStream(dst, std::ios::binary);
		dstStream << srcStream.rdbuf();
		srcStream.close();
		dstStream.close();
        return true;
#elif defined(PLATFORM_LINUX)
		std::ifstream srcStream(src, std::ios::binary);
		std::ofstream dstStream(dst, std::ios::binary);
		dstStream << srcStream.rdbuf();
		srcStream.close();
		dstStream.close();
		return true;
#else
        std::cout << "copyFile not implemented for this platform" << std::endl;
        return true;
#endif
    }

    bool writeFile(const std::string& path, const std::string& text)
    {
        std::ofstream fs(path);
        if (!fs)
        {
            std::cout << "Could not create " << path << std::endl;
            fs.close();
            return false;
        }
        else
        {
            fs << text;
            fs.close();
            return true;
        }
    }

    bool removeFile(const std::string& path)
    {
#if defined(PLATFORM_WINDOWS)
        fs::remove(path);
        return true;
#elif defined(PLATFORM_OSX)
		std::remove(path.c_str());
        return true;
#elif defined(PLATFORM_LINUX)
		std::remove(path.c_str());
		return true;
#else
        std::cout << "removeFile not implemented for this platform" << std::endl;
        return false;
#endif
    }

}
