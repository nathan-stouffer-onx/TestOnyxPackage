#include "FileSystem.h"

#include <iostream>
#include <fstream>
#include <memory>

#include <string>
#include <sstream>

#include "Warnings.h"
#include <Logging/LogManager.h>
#include "OnyxException.h"

#if defined(PLATFORM_WINDOWS)
#include <Windows.h>
#include <filesystem>
namespace fs = std::filesystem;
#else
#include <sys/stat.h>
#endif

#if defined(PLATFORM_OSX) | defined(PLATFORM_IOS)
#include <unistd.h>
#include <cstdio>
#endif

#if defined(PLATFORM_LINUX)
#include <unistd.h>
#include <cstdio>
#include <limits.h>
#include <cstring>
#endif

#if defined(PLATFORM_ANDROID)
#include <android_native_app_glue.h>
#include <android/asset_manager.h>
#include <android/log.h>

android_app* s_app = nullptr;
AAssetManager* assetManager = nullptr;

#endif

namespace onyx {
namespace core {
namespace FileSystem {

	static std::string sPrefix = "";

	void CallbackStub::fatal(const char* _filePath, uint16_t _line, bgfx::Fatal::Enum _code, const char* _str)
	{
		if (bgfx::Fatal::DebugCheck == _code)
		{
			//bx::debugBreak();
		}
		else
		{
			if (mFatalCallback != nullptr)
			{
				mFatalCallback(_filePath, _line, _code, _str);
			}
			else
			{
				logE("Fatal BGFX error: %s:%d: %s", _filePath, _line, _str);
				abort();
			}
		}
	}

	void CallbackStub::traceVargs(const char* _filePath, uint16_t _line, const char* _format, va_list _argList)
	{
		static bool force = false;	// if looking for gpu memory leaks, it is helpful to print all bgfx logs by setting this to tru

		if (mTraceVargsCallback != nullptr)
		{
			mTraceVargsCallback(_filePath, _line, _format, _argList);
		}
		else if ((strncmp(_format, "BGFX WARN", 9) == 0) ||
			(strncmp(_format, "BGFX ASSERT", 11) == 0) ||
			(strncmp(_format, "BGFX LEAK", 9) == 0) ||
			force)
		{
			char temp[2048];
			char* out = temp;
			va_list argListCopy;
			va_copy(argListCopy, _argList);
			int32_t len = bx::snprintf(out, sizeof(temp), "%s (%d): ", _filePath, _line);
			int32_t total = len + bx::vsnprintf(out + len, sizeof(temp) - len, _format, argListCopy);
			va_end(argListCopy);
			if ((int32_t)sizeof(temp) < total)
			{
				out = (char*)alloca(total + 1);
				bx::memCopy(out, temp, len);
				bx::vsnprintf(out + len, total - len, _format, _argList);
			}
			out[total] = '\0';
			logE(out);
		}
	}

	void CallbackStub::screenShot(const char* _filePath, uint32_t _width, uint32_t _height, uint32_t _pitch, const void* _data, uint32_t _size, bool _yflip)
	{
		BX_UNUSED(_filePath, _width, _height, _pitch, _data, _size, _yflip);

		const int32_t len = bx::strLen(_filePath) + 5;
		char* filePath = (char*)alloca(len);
		bx::strCopy(filePath, len, _filePath);
		bx::strCat(filePath, len, ".tga");

		bx::FileWriter writer;
		if (bx::open(&writer, filePath))
		{
			bimg::imageWriteTga(&writer, _width, _height, _pitch, _data, false, _yflip);
			bx::close(&writer);
		}
	}

DISABLE_WARNING_PUSH
DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
	static void* load(bx::FileReaderI* _reader, bx::AllocatorI* _allocator, const std::string& filePath, uint32_t* _size, bool prefix = true)
	{
		std::string name = (prefix) ? sPrefix + filePath : filePath;
#if defined(PLATFORM_WINDOWS) | defined(PLATFORM_OSX) | defined(PLATFORM_LINUX) | defined(PLATFORM_IOS) | defined(PLATFORM_EMSCRIPTEN)
		if (bx::open(_reader, name.c_str()))
		{
			uint32_t size = (uint32_t)bx::getSize(_reader);
			void* data = bx::alloc(_allocator, size);
			bx::read(_reader, data, size, nullptr);
			bx::close(_reader);
			if (_size != NULL)
			{
				*_size = size;
			}
			return data;
		}
		else
		{
			logE("Failed to open: %s.", name.c_str());
			if (_size != NULL)
			{
				*_size = 0;
			}
			return NULL;
		}
#elif defined(PLATFORM_ANDROID) // TODO can we get rid of this ifdef?
		ONYX_ASSERT(assetManager != nullptr, "onyx Core Asset Manager is not set");
		AAsset* asset = AAssetManager_open(assetManager, name.c_str(), AASSET_MODE_BUFFER);
		if (asset != NULL)
		{
			size_t size = AAsset_getLength(asset);
			void* buffer = bx::alloc(_allocator, size);
			AAsset_read(asset, buffer, size);
			if (_size != NULL)
			{
				*_size = size;
			}
			return buffer;
		}
		else
		{
			logE("Failed to load asset: %s", name.c_str());
			if (_size != NULL)
			{
				*_size = 0;
			}

			return NULL;
		}
#else
		logE("function load not implemented for this platform");
		*_size = 0;
		return NULL;
#endif
	}
DISABLE_WARNING_POP

	void* load(const std::string& filePath, uint32_t* _size, bool prefix)
	{
		//appears load may not be thread safe, adding this lock fixed a number of race condition issues in unit tests
		static std::mutex mLoadLock;
		std::lock_guard<std::mutex> lock(mLoadLock);
		return load(getFileReader(), getAllocator(), filePath, _size, prefix);
	}

	void deleteMem(void* mem, void* /*userData*/) 
	{ 
		bx::free(getAllocator(), mem);
	}

	const bgfx::Memory* loadMem(const std::string& filePath, bool deleteWhenDone)
	{
		uint32_t size;
		void* data = load(filePath, &size);
		const bgfx::Memory* mem;
		if(!deleteWhenDone)
			mem = bgfx::makeRef(data, size);
		else
			mem = bgfx::makeRef(data, size, deleteMem);
		return mem;
	}

	void unload(void* _ptr)
	{
#if defined(PLATFORM_WINDOWS)
		bx::free(getAllocator(), _ptr);
#elif defined(PLATFORM_OSX)
        bx::free(getAllocator(), _ptr);
#elif defined(PLATFORM_LINUX)
		bx::free(getAllocator(), _ptr);
#elif defined(PLATFORM_IOS)
		bx::free(getAllocator(), _ptr);
#elif defined(PLATFORM_ANDROID)
        bx::free(getAllocator(), _ptr);
#elif defined(PLATFORM_EMSCRIPTEN)
		bx::free(getAllocator(), _ptr);
#else
		logE("function unload not implemented on this platform");
#endif
	}

//TODO I think it would simplify things to define these functions in the platform-specific library glue code instead of here.
DISABLE_WARNING_PUSH
DISABLE_WARNING_UNUSED_VARIABLE
DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
	void saveText(const std::string& path, const std::string& data)
	{
		std::string name = sPrefix + path;
		const char* _data = data.c_str();
		auto _size = data.length();
#if defined(PLATFORM_WINDOWS)
		bx::FileWriterI* writer = getFileWriter();
		bx::Error err;
		if (bx::open(writer, name.c_str(), false, &err))
		{
			bx::write(writer, (void*)_data, std::int32_t(_size), &err); // cast to void to match bx api
			bx::close(writer);
		}
#elif defined(PLATFORM_OSX)
		bx::FileWriterI* writer = getFileWriter();
		bx::Error err;
		if (bx::open(writer, name.c_str(), false, &err))
		{
			bx::write(writer, (void*)_data, _size, &err); // cast to void to match bx api
			bx::close(writer);
		}
#elif defined(PLATFORM_LINUX)
		bx::FileWriterI* writer = getFileWriter();
		bx::Error err;
		if (bx::open(writer, name.c_str(), false, &err))
		{
			bx::write(writer, (void*)_data, _size, &err); // cast to void to match bx api
			bx::close(writer);
		}
#elif defined(PLATFORM_IOS)
		std::fstream fout(name.c_str(), std::ios::out | std::ios::app);
		if (fout.is_open())
		{
			fout.write(_data, _size);
			fout.close();
		}
		else
		{
			logE(std::string(path) + " could not open file", "BfgxUtils");	// TODO fix: if the file doesn't open, this is recursive
		}
#elif defined(PLATFORM_ANDROID)
		std::fstream fout(name.c_str(), std::ios::out | std::ios::app);
		if (fout.is_open())
		{
			fout.write(_data, _size);
			fout.close();
		}
		else
		{
			__android_log_print(ANDROID_LOG_ERROR, "BgfxUtils::saveText", "could not open file %s", path.c_str());
		}

#else
		logE("function saveText not implemented on this platform");
#endif
	}
DISABLE_WARNING_POP

	// I kind of hate the copying that's going on here, but this will work for now.
	std::vector<uint8_t> readFileBytes(const std::string& fileName)
	{
		uint32_t dataLength;


		std::unique_ptr<char> c((char*)load(fileName, &dataLength));
		if (c == NULL)
			ONYX_THROW("Unable to read file: " + fileName);

		std::vector<uint8_t> result;
		result.resize(dataLength);

		memcpy(result.data(), c.get(), dataLength);

		return result;
	}

	std::string readText(const std::string& fileName, bool prefix)
	{
		uint32_t dataLength;

		char* c = (char*)load(fileName, &dataLength, prefix);
		if (c == NULL)
			ONYX_THROW("Unable to read file: " + fileName);

		std::string data(c, (size_t)dataLength);
		delete c;

		return data;
	}

	std::string cwd()
	{
#if defined(PLATFORM_WINDOWS)
		TCHAR val[MAX_PATH];
		GetCurrentDirectory(MAX_PATH, val);
		return std::string(val) + "\\";
#elif defined(PLATFORM_OSX)
		char val[PATH_MAX];
		getcwd(val, sizeof(val));
		return std::string(val) + "/";
#elif defined(PLATFORM_LINUX)
		char val[PATH_MAX];
		getcwd(val, sizeof(val));
		return std::string(val) + "/";
#else
		logE("function cwd not implemented for this platform");
		return "";
#endif
	}

	std::string coreSourceDirectory()
	{
#if defined(PLATFORM_WINDOWS)
		std::string dir = __FILE__;
		auto chop = dir.find("\\src\\CoreUtils\\System\\FileSystem") + 1;		// add 1 to keep the "\"
		dir = dir.substr(0, chop);
		return dir;
#elif defined(PLATFORM_OSX)
		std::string dir = __FILE__;
		auto chop = dir.find("/src/CoreUtils/System/FileSystem") + 1;			// add 1 to keep the "/"
		dir = dir.substr(0, chop);
		return dir;
#elif defined(PLATFORM_LINUX)
		std::string dir = __FILE__;
		auto chop = dir.find("/src/CoreUtils/System/FileSystem") + 1;			// add 1 to keep the "/"
		dir = dir.substr(0, chop);
		return dir;
#else
		logE("function coreSourceDirectory not implemented for this platform");
		return "";
#endif
	}

	bool fileExists(const std::string& fileName)
	{
		std::string path = sPrefix + fileName;
#if defined(PLATFORM_WINDOWS)
		return fs::exists(path);
#elif defined(PLATFORM_OSX)
		struct stat buffer;
		return (stat(path.c_str(), &buffer) == 0);
#elif defined(PLATFORM_LINUX)
		struct stat buffer;
		return (stat(path.c_str(), &buffer) == 0);
#elif defined(PLATFORM_IOS)
		struct stat buffer;
		return (stat(path.c_str(), &buffer) == 0);
#elif defined(PLATFORM_ANDROID)
		//AAssetManager* assetManager = s_app->activity->assetManager;
		AAsset* asset = AAssetManager_open(assetManager, path.c_str(), AASSET_MODE_BUFFER);
		return asset != nullptr;
#elif defined(PLATFORM_EMSCRIPTEN)
		struct stat buffer;
		return (stat(path.c_str(), &buffer) == 0);
#else
		logE("function fileExists not implemented on this platform");
		return false;
#endif
	}

	bx::FileReaderI* getFileReader()
	{
		if (s_fileReader == NULL)
		{
			static std::mutex mtx;
			std::lock_guard<std::mutex> lock(mtx);
			if (s_fileReader == nullptr)
			{
				s_fileReader = BX_NEW(getAllocator(), FileReader);
			}
		}

		return s_fileReader;
	}

	bx::FileWriterI* getFileWriter()
	{
		if (s_fileWriter == NULL)
		{
			static std::mutex mtx;
			std::lock_guard<std::mutex> lock(mtx);
			if (s_fileWriter == nullptr)
				s_fileWriter = BX_NEW(getAllocator(), FileWriter);
		}
		return s_fileWriter;
	}

	bx::AllocatorI* getAllocator()
	{
		if (g_allocator == NULL)
			g_allocator = getDefaultAllocator();
		return g_allocator;
	}

	bgfx::CallbackI* getCallback()
	{
		return g_callback;
	}

	bx::AllocatorI* getDefaultAllocator()
	{
		BX_PRAGMA_DIAGNOSTIC_PUSH();
		BX_PRAGMA_DIAGNOSTIC_IGNORED_MSVC(4459); // warning C4459: declaration of 's_allocator' hides global declaration
		BX_PRAGMA_DIAGNOSTIC_IGNORED_CLANG_GCC("-Wshadow");
		static bx::DefaultAllocator* s_allocator = new bx::DefaultAllocator();
		//bx::AllocatorI* test = s_allocator;
		return s_allocator;
		BX_PRAGMA_DIAGNOSTIC_POP();
	}

	bgfx::CallbackI* getDefaultCallback()
	{
		BX_PRAGMA_DIAGNOSTIC_PUSH();
		BX_PRAGMA_DIAGNOSTIC_IGNORED_MSVC(4459); // warning C4459: declaration of 's_allocator' hides global declaration
		BX_PRAGMA_DIAGNOSTIC_IGNORED_CLANG_GCC("-Wshadow");
		static CallbackStub s_callback;
		return &s_callback;
		BX_PRAGMA_DIAGNOSTIC_POP();
	}

	void setPrefix(std::string const& prefix)
	{
		sPrefix = prefix;
	}

	void cleanup()
	{
		if (s_fileReader != NULL)
			delete s_fileReader;

		s_fileReader = nullptr;

		if (s_fileWriter != NULL)
			delete s_fileWriter;

		s_fileWriter = nullptr;
	}

#if defined(PLATFORM_ANDROID)
	void setApp(void* app) { s_app = (android_app*) app; }
	void setAssetManager(void* aman) { assetManager = (AAssetManager*) aman; }
#endif

} } }
