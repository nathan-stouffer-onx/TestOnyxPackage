#include "LineStyle.h"
#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"

namespace onyx {
namespace Styling {

		void LineStyle::realizeLayout(Expressions::Arguments const& args, std::shared_ptr<LineLayout const>& l)
		{
			if (l->basePtr != nullptr)
			{
				realizeLayout(args, l->basePtr);
			}

			if (l->joinType) joinType = l->joinType->evaluate(args);
			if (l->capType) capType = l->capType->evaluate(args);
		}

		void LineStyle::realizePaint(Expressions::Arguments const& args, std::shared_ptr<LinePaint const>& p)
		{
			if (p->basePtr)
			{
				realizePaint(args, p->basePtr);
			}

			if (p->color != nullptr || p->opacity != nullptr)
			{
				lgal::Color color = p->color ? p->color->evaluate(args) : lgal::Color::FromABGR(abgr);
				if (p->opacity) { color.a = p->opacity->evaluate(args); }

				abgr = color.abgr();
			}

			if (p->width) width = p->width->evaluate(args);
			if (p->dashArray) dashArray = DashArray{ p->dashArray->evaluate(args) };
		}

} }

