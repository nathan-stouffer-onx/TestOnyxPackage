#pragma once

#include <lucid/gal/Types.h>

#include "Styling/Enums.h"

namespace onyx::Styling
{

	struct ViewshedConfig
	{

		BlendMode blendMode = BlendMode::ALPHA;

		float lon = 0;
		float lat = 0;

		float rangeKm = 10.f;
		float offsetKm = 0.010f;

		uint32_t abgr = 0xFF000000;
		uint32_t ringAbgr = 0xFFFFFFFF;

		bool inverted = false;

		inline auto tie() const
		{
			return std::tie(blendMode, lon, lat, rangeKm, offsetKm, abgr, ringAbgr, inverted);
		}

		inline bool operator==(ViewshedConfig const& rhs) const
		{
			return tie() == rhs.tie();
		}

		inline bool operator!=(ViewshedConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

	struct SunlightConfig
	{

		BlendMode blendMode = BlendMode::ALPHA;

		// TODO possibly move JulianDate to here in the Styling lib?
		int year;
		int month;
		int day;
		float hour24;

		float shadowStrength;

		inline auto tie() const
		{
			return std::tie(blendMode, year, month, day, hour24, shadowStrength);
		}

		inline bool operator==(SunlightConfig const& rhs) const
		{
			return tie() == rhs.tie();
		}

		inline bool operator!=(SunlightConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

}