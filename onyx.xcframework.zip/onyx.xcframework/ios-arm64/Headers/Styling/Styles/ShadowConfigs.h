#ifndef __STYLING_SHADOW_CONFIGS_H__
#define __STYLING_SHADOW_CONFIGS_H__

#include <lucid/gal/Types.h>

namespace onyx {
namespace Styling {

	struct ViewshedConfig
	{

		float lon = 0;
		float lat = 0;

		float rangeKm = 10.f;
		float offsetKm = 0.010f;

		uint32_t abgr = 0xFF000000;
		uint32_t ringAbgr = 0xFFFFFFFF;

		bool inverted = false;

		inline bool operator==(ViewshedConfig const& rhs) const
		{
			return lon == rhs.lon
				&& lat == rhs.lat
				&& rangeKm == rhs.rangeKm
				&& offsetKm == rhs.offsetKm
				&& abgr == rhs.abgr
				&& ringAbgr == rhs.ringAbgr
				&& inverted == rhs.inverted;
		}

		inline bool operator!=(ViewshedConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

	struct SunlightConfig
	{

		// TODO possibly move JulianDate to here in the Styling lib?
		int year;
		int month;
		int day;
		float hour24;

		float shadowStrength;

		inline bool operator==(SunlightConfig const& rhs) const
		{
			return year == rhs.year
				&& month == rhs.month
				&& day == rhs.day
				&& hour24 == rhs.hour24
				&& shadowStrength == rhs.shadowStrength;
		}

		inline bool operator!=(SunlightConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

} }

#endif