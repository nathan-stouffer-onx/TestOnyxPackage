#pragma once

#include <lucid/gal/Types.h>

namespace onyx::Styling
{

	struct FogStyle
	{

		lgal::Color color = 0xFFFFFFFF;
		lgal::gpu::Vector2 range = { 0.5f, 10.0f };

	};

}