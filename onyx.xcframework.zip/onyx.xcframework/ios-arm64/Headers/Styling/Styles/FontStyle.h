#ifndef __STYLING_FONT_STYLE_H__
#define __STYLING_FONT_STYLE_H__

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>
#include <System/OnyxException.h>

#include "Styling/Enums.h"

namespace onyx {
namespace Styling {

	struct FontFace
	{
		std::string name;
		int32_t fontType;
		int32_t pixelSize;

		inline bool operator==(FontFace const& rhs) const {
			return name == rhs.name
				&& fontType == rhs.fontType
				&& pixelSize == rhs.pixelSize;
		}

		inline bool operator!=(FontFace const& rhs) const {
			return !(*this == rhs);
		}

		inline bool operator<(FontFace const& rhs) const {
			if (pixelSize != rhs.pixelSize) { return pixelSize < rhs.pixelSize; }
			if (fontType != rhs.fontType) { return fontType < rhs.fontType; }
			return name < rhs.name;
		}

		inline bool operator>(FontFace const& rhs) const {
			return rhs < *this;
		}
	};

	using TextPlacement = Placement;

	/*
	* Struct that stores values for all the available options for font styling. The general idea is that the
	* expressions in a SymbolLayer can be evaluated to produce this struct which can be encoded in a texture and 
	* style vectors on the gpu and/or be passed as shader parameters.
	*
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is
	* added to FontStyle
	*/
	struct FontStyle
	{

		FontFace font;

		lgal::Color textColor = { 0.0f, 0.0f, 0.0f, 1.0f };
		lgal::Color haloColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color dropshadowColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color strikethroughColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color overlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color underlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color backgroundColor = { 0.0f, 0.0f, 0.0f, 0.0f };

		float32_t kerningModifier = 0;

		SymbolPlacement symbolPlacement = SymbolPlacement::UNSPECIFIED;
		TextPlacement textPlacement = TextPlacement::UNSPECIFIED;
		TextStyleFlags textStyle = TextStyleFlags::NORMAL;

		FontStyle() { }

		FontStyle(FontFace const& face, lgal::Color const& textColor, lgal::Color const& haloColor, lgal::Color const& dropshadowColor, lgal::Color const& strikethroughColor, lgal::Color const& overlineColor, lgal::Color const& underlineColor, lgal::Color const& backgroundColor, float32_t kerningModifier, SymbolPlacement symbolPlacement)
			: font(face)
			, textColor(textColor)
			, haloColor(haloColor)
			, dropshadowColor(dropshadowColor)
			, strikethroughColor(strikethroughColor)
			, overlineColor(overlineColor)
			, underlineColor(underlineColor)
			, backgroundColor(backgroundColor)
			, kerningModifier(kerningModifier)
			, symbolPlacement(symbolPlacement)
		{ }

		FontStyle(FontFace const& face, lgal::Color const& textColor, lgal::Color const& haloColor, lgal::Color const& dropshadowColor, float32_t kerningModifier, SymbolPlacement symbolPlacement)
			: FontStyle(face, textColor, haloColor, dropshadowColor, 0, 0, 0, 0, kerningModifier, symbolPlacement)
		{ }

		static FontStyle empty() { return FontStyle(FontFace{ "", 0, 15 }, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0.f, SymbolPlacement::UNSPECIFIED); }

	};

	inline bool operator==(FontStyle const& lhs, FontStyle const& rhs)
	{
		return lhs.textColor == rhs.textColor		// just use 32-bit color code because this struct pretty much goes straight to the gpu in that format
			&& lhs.haloColor == rhs.haloColor
			&& lhs.dropshadowColor == rhs.dropshadowColor
			&& lhs.kerningModifier == rhs.kerningModifier
			&& lhs.font == rhs.font
			&& lhs.symbolPlacement == rhs.symbolPlacement
			&& lhs.textPlacement == rhs.textPlacement
			&& lhs.textStyle == rhs.textStyle
			&& lhs.strikethroughColor == rhs.strikethroughColor
			&& lhs.overlineColor == rhs.overlineColor
			&& lhs.underlineColor == rhs.underlineColor
			&& lhs.backgroundColor == rhs.backgroundColor
			;
	}

	inline bool operator!=(FontStyle const& lhs, FontStyle const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(FontStyle const& lhs, FontStyle const& rhs)
	{
		if (lhs.font != rhs.font)	{ return lhs.font < rhs.font; }
		if (lhs.symbolPlacement != rhs.symbolPlacement) { return lhs.symbolPlacement < rhs.symbolPlacement; }
		if (lhs.kerningModifier != rhs.kerningModifier) { return lhs.kerningModifier < rhs.kerningModifier; }
		if (lhs.haloColor != rhs.haloColor) { return lhs.haloColor < rhs.haloColor; }
		if (lhs.dropshadowColor != rhs.dropshadowColor) { return lhs.dropshadowColor < rhs.dropshadowColor; }
		if (lhs.strikethroughColor != rhs.strikethroughColor) { return lhs.strikethroughColor < rhs.strikethroughColor; }
		if (lhs.overlineColor != rhs.overlineColor) { return lhs.overlineColor < rhs.overlineColor; }
		if (lhs.underlineColor != rhs.underlineColor) { return lhs.underlineColor < rhs.underlineColor; }
		if (lhs.backgroundColor != rhs.backgroundColor) { return lhs.backgroundColor < rhs.backgroundColor; }
		if (lhs.textPlacement != rhs.textPlacement) { return lhs.textPlacement < rhs.textPlacement; }
		if (lhs.textStyle != rhs.textStyle) { return lhs.textStyle < rhs.textStyle; }
		return lhs.textColor < rhs.textColor;
	}

	inline bool operator>(FontStyle const& lhs, FontStyle const& rhs)
	{
		return rhs < lhs;
	}

} }

namespace std
{

	template<>
	struct hash<onyx::Styling::FontFace>
	{
		inline size_t operator()(onyx::Styling::FontFace const& fontFace) const
		{
			std::hash<std::string> sHasher;
			std::hash<int32_t> i32Hasher;

			return sHasher(fontFace.name) * 23
				^ i32Hasher(fontFace.fontType) * 23
				^ i32Hasher(fontFace.pixelSize) * 23;
		}
	};

	template<>
	struct hash<onyx::Styling::FontStyle>
	{
		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::FontStyle const& style) const
		{
			std::hash<onyx::Styling::FontFace> fntHasher;
			std::hash<float> fHasher;
			std::hash<uint32_t> iHasher;
			size_t hash = 0;
			hash += size_t(style.textColor.argb()) * 47;				// just use 32-bit color code because this struct pretty much goes straight to the gpu in that format
			hash += size_t(style.dropshadowColor.argb()) * 47;
			hash += size_t(style.haloColor.argb()) * 47;
			hash += size_t(style.strikethroughColor.argb()) * 47;
			hash += size_t(style.overlineColor.argb()) * 47;
			hash += size_t(style.underlineColor.argb()) * 47;
			hash += size_t(style.backgroundColor.argb()) * 47;
			hash += fntHasher(style.font) * 47;
			hash += fHasher(style.kerningModifier) * 47;
			hash += iHasher(uint32_t(style.symbolPlacement)) * 47;
			hash += iHasher(uint32_t(style.textPlacement)) * 47;
			hash += iHasher(uint32_t(style.textStyle)) * 47;
			return hash;
		}
	};

}

#endif