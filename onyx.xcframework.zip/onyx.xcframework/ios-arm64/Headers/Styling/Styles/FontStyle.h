#ifndef __STYLING_FONT_STYLE_H__
#define __STYLING_FONT_STYLE_H__

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>
#include <System/Map3DException.h>
#include <Utils/BitwiseEnumOperators.h>
#include <Utils/EnumUtils.h>

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {

	struct FontFace
	{
		std::string name;
		int32_t fontType;
		int32_t pixelSize;

		inline bool operator==(FontFace const& rhs) const {
			return name == rhs.name
				&& fontType == rhs.fontType
				&& pixelSize == rhs.pixelSize;
		}

		inline bool operator!=(FontFace const& rhs) const {
			return !(*this == rhs);
		}

		inline bool operator<(FontFace const& rhs) const {
			if (pixelSize != rhs.pixelSize) { return pixelSize < rhs.pixelSize; }
			if (fontType != rhs.fontType) { return fontType < rhs.fontType; }
			return name < rhs.name;
		}

		inline bool operator>(FontFace const& rhs) const {
			return rhs < *this;
		}
	};

	using TextPlacement = Placement;

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(TextPlacement);

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(TextStyleFlags);

	/*
	* Struct that stores values for all the available options for font styling. The general idea is that the
	* expressions in a SymbolLayer can be evaluated to produce this struct which can be encoded in a texture and 
	* style vectors on the gpu and/or be passed as shader parameters.
	*
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is
	* added to FontStyle
	*/
	struct FontStyle
	{

		enum class SymbolPlacement : uint32_t
		{
			UNSPECIFIED = 0,
			POINT = 1,
			LINE = 2,
			LINE_CENTER = 3,
			LINE_JUSTIFY = 4,
		};

		FontFace font;

		lgal::Color textColor = { 0.0f, 0.0f, 0.0f, 1.0f };
		lgal::Color outlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color dropshadowColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color strikethroughColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color overlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color underlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color backgroundColor = { 0.0f, 0.0f, 0.0f, 0.0f };

		float32_t kerningModifier = 0;

		SymbolPlacement symbolPlacement = SymbolPlacement::UNSPECIFIED;
		TextPlacement textPlacement = TextPlacement::UNSPECIFIED;
		TextStyleFlags textStyle = TextStyleFlags::NORMAL;

		FontStyle() { }

		FontStyle(FontFace const& face, lgal::Color const& textColor, lgal::Color const& outlineColor, lgal::Color const& dropshadowColor, lgal::Color const& strikethroughColor, lgal::Color const& overlineColor, lgal::Color const& underlineColor, lgal::Color const& backgroundColor, float32_t kerningModifier, SymbolPlacement symbolPlacement)
			: font(face)
			, textColor(textColor)
			, outlineColor(outlineColor)
			, dropshadowColor(dropshadowColor)
			, strikethroughColor(strikethroughColor)
			, overlineColor(overlineColor)
			, underlineColor(underlineColor)
			, backgroundColor(backgroundColor)
			, kerningModifier(kerningModifier)
			, symbolPlacement(symbolPlacement)
		{ }

		FontStyle(FontFace const& face, lgal::Color const& textColor, lgal::Color const& outlineColor, lgal::Color const& dropshadowColor, float32_t kerningModifier, SymbolPlacement symbolPlacement)
			: FontStyle(face, textColor, outlineColor, dropshadowColor, 0, 0, 0, 0, kerningModifier, symbolPlacement)
		{ }

		static FontStyle empty() { return FontStyle(FontFace{ "", 0, 15 }, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0.f, SymbolPlacement::UNSPECIFIED); }

		template<typename LayoutT>
		void realizeLayout(Expressions::Arguments const& args, LayoutT const& layout)
		{
			if (layout.basePtr != nullptr)
			{
				realizeLayout(args, *layout.basePtr);
			}

			// TODO (scott) This magic number is cribbed from font_manager.h; we'll need a way to expose
			// it to the stylesheet configuration at some point.
			// #define FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE  UINT32_C(0x00003900) // L8 + BGRA8
			auto textSize = font.pixelSize;
			if (layout.textSize) textSize = (int32_t) layout.textSize->evaluate(args);
			if (!layout.fontFace.empty()) font = FontFace{ layout.fontFace.front(), 0x00003900, textSize };
			if (layout.symbolPlacement) symbolPlacement = layout.symbolPlacement->evaluate(args);
			if (layout.textPlacement) textPlacement = layout.textPlacement->evaluate(args);
			if (layout.textStyleFlags) textStyle = layout.textStyleFlags->evaluate(args);
			if (layout.letterSpacing) kerningModifier = layout.letterSpacing->evaluate(args);
		}

		template<typename PaintT>
		void realizePaint(Expressions::Arguments const& args, PaintT const& paint)
		{
			if (paint.basePtr)
			{
				realizePaint(args, *paint.basePtr);
			}

			if (paint.color) textColor = paint.color->evaluate(args);
			if (paint.shadowColor) dropshadowColor = paint.shadowColor->evaluate(args);
			if (paint.outlineColor) outlineColor = paint.outlineColor->evaluate(args);
			if (paint.strikethroughColor) strikethroughColor = paint.strikethroughColor->evaluate(args);
			if (paint.overlineColor) overlineColor = paint.overlineColor->evaluate(args);
			if (paint.underlineColor) underlineColor = paint.underlineColor->evaluate(args);
			if (paint.backgroundColor) backgroundColor = paint.backgroundColor->evaluate(args);
		}

	};

	inline bool operator==(FontStyle const& lhs, FontStyle const& rhs)
	{
		return lhs.textColor == rhs.textColor		// just use 32-bit color code because this struct pretty much goes straight to the gpu in that format
			&& lhs.outlineColor == rhs.outlineColor
			&& lhs.dropshadowColor == rhs.dropshadowColor
			&& lhs.kerningModifier == rhs.kerningModifier
			&& lhs.font == rhs.font
			&& lhs.symbolPlacement == rhs.symbolPlacement
			&& lhs.textPlacement == rhs.textPlacement
			&& lhs.textStyle == rhs.textStyle
			&& lhs.strikethroughColor == rhs.strikethroughColor
			&& lhs.overlineColor == rhs.overlineColor
			&& lhs.underlineColor == rhs.underlineColor
			&& lhs.backgroundColor == rhs.backgroundColor
			;
	}

	inline bool operator!=(FontStyle const& lhs, FontStyle const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(FontStyle const& lhs, FontStyle const& rhs)
	{
		if (lhs.font != rhs.font)	{ return lhs.font < rhs.font; }
		if (lhs.symbolPlacement != rhs.symbolPlacement) { return lhs.symbolPlacement < rhs.symbolPlacement; }
		if (lhs.kerningModifier != rhs.kerningModifier) { return lhs.kerningModifier < rhs.kerningModifier; }
		if (lhs.outlineColor != rhs.outlineColor) { return lhs.outlineColor < rhs.outlineColor; }
		if (lhs.dropshadowColor != rhs.dropshadowColor) { return lhs.dropshadowColor < rhs.dropshadowColor; }
		if (lhs.strikethroughColor != rhs.strikethroughColor) { return lhs.strikethroughColor < rhs.strikethroughColor; }
		if (lhs.overlineColor != rhs.overlineColor) { return lhs.overlineColor < rhs.overlineColor; }
		if (lhs.underlineColor != rhs.underlineColor) { return lhs.underlineColor < rhs.underlineColor; }
		if (lhs.backgroundColor != rhs.backgroundColor) { return lhs.backgroundColor < rhs.backgroundColor; }
		if (lhs.textPlacement != rhs.textPlacement) { return lhs.textPlacement < rhs.textPlacement; }
		if (lhs.textStyle != rhs.textStyle) { return lhs.textStyle < rhs.textStyle; }
		return lhs.textColor < rhs.textColor;
	}

	inline bool operator>(FontStyle const& lhs, FontStyle const& rhs)
	{
		return rhs < lhs;
	}

} }

namespace std
{

	template<>
	struct hash<onyx::Styling::FontFace>
	{
		inline size_t operator()(onyx::Styling::FontFace const& fontFace) const
		{
			std::hash<std::string> sHasher;
			std::hash<int32_t> i32Hasher;

			return sHasher(fontFace.name) * 23
				^ i32Hasher(fontFace.fontType) * 23
				^ i32Hasher(fontFace.pixelSize) * 23;
		}
	};

	template<>
	struct hash<onyx::Styling::FontStyle>
	{
		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::FontStyle const& style) const
		{
			std::hash<onyx::Styling::FontFace> fntHasher;
			std::hash<float> fHasher;
			std::hash<uint32_t> iHasher;
			size_t hash = 0;
			hash += size_t(style.textColor.argb()) * 47;				// just use 32-bit color code because this struct pretty much goes straight to the gpu in that format
			hash += size_t(style.dropshadowColor.argb()) * 47;
			hash += size_t(style.outlineColor.argb()) * 47;
			hash += size_t(style.strikethroughColor.argb()) * 47;
			hash += size_t(style.overlineColor.argb()) * 47;
			hash += size_t(style.underlineColor.argb()) * 47;
			hash += size_t(style.backgroundColor.argb()) * 47;
			hash += fntHasher(style.font) * 47;
			hash += fHasher(style.kerningModifier) * 47;
			hash += iHasher(uint32_t(style.symbolPlacement)) * 47;
			hash += iHasher(uint32_t(style.textPlacement)) * 47;
			hash += iHasher(uint32_t(style.textStyle)) * 47;
			return hash;
		}
	};

	template<>
	inline onyx::Styling::FontStyle::SymbolPlacement fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::FontStyle::SymbolPlacement> const nameMap =
		{
			{ "unspecified",				onyx::Styling::FontStyle::SymbolPlacement::UNSPECIFIED		},
			{ "point",						onyx::Styling::FontStyle::SymbolPlacement::POINT				},
			{ "line",						onyx::Styling::FontStyle::SymbolPlacement::LINE				},
			{ "line-center",				onyx::Styling::FontStyle::SymbolPlacement::LINE_CENTER		},
			{ "line-justify",				onyx::Styling::FontStyle::SymbolPlacement::LINE_JUSTIFY		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::FontStyle::SymbolPlacement");
	}

	template<>
	inline onyx::Styling::TextStyleFlags fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::TextStyleFlags> const nameMap =
		{
			{ "normal",						onyx::Styling::TextStyleFlags::NORMAL				},
			{ "overline",					onyx::Styling::TextStyleFlags::OVERLINE			},
			{ "underline",					onyx::Styling::TextStyleFlags::UNDERLINE			},
			{ "strikethrough",				onyx::Styling::TextStyleFlags::STRIKE_THROUGH		},
			{ "background",					onyx::Styling::TextStyleFlags::BACKGROUND			},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::TextStyleFlags");
	}

	template<>
	inline onyx::Styling::TextPlacement fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::TextPlacement> const nameMap =
		{
			{ "unspecified",				onyx::Styling::TextPlacement::UNSPECIFIED			},
			{ "center",						onyx::Styling::TextPlacement::HORIZONTAL_CENTER	},
			{ "left",						onyx::Styling::TextPlacement::LEFT				},
			{ "right",						onyx::Styling::TextPlacement::RIGHT				},
			{ "top",						onyx::Styling::TextPlacement::ABOVE				},
			{ "bottom",						onyx::Styling::TextPlacement::BELOW				},
			{ "top-left",					onyx::Styling::TextPlacement::TOP_LEFT			},
			{ "top-right",					onyx::Styling::TextPlacement::TOP_RIGHT			},
			{ "bottom-left",				onyx::Styling::TextPlacement::BOTTOM_LEFT			},
			{ "bottom-right",				onyx::Styling::TextPlacement::BOTTOM_RIGHT		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::FontStyle::TextPlacement");
	}

	inline std::string_view toStringView(onyx::Styling::FontStyle::SymbolPlacement value)
	{
		static std::unordered_map<onyx::Styling::FontStyle::SymbolPlacement, std::string_view> const nameMap =
		{
			{ onyx::Styling::FontStyle::SymbolPlacement::UNSPECIFIED,			"unspecified"	},
			{ onyx::Styling::FontStyle::SymbolPlacement::POINT,				"point"			},
			{ onyx::Styling::FontStyle::SymbolPlacement::LINE,				"line"			},
			{ onyx::Styling::FontStyle::SymbolPlacement::LINE_CENTER,			"line-center"	},
			{ onyx::Styling::FontStyle::SymbolPlacement::LINE_JUSTIFY,		"line-justify"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::FontStyle::SymbolPlacement");
	}

	inline std::string_view toStringView(onyx::Styling::TextStyleFlags value)
	{
		static std::unordered_map<onyx::Styling::TextStyleFlags, std::string_view> const nameMap =
		{
			{ onyx::Styling::TextStyleFlags::NORMAL,							"normal"		},
			{ onyx::Styling::TextStyleFlags::OVERLINE,						"overline"		},
			{ onyx::Styling::TextStyleFlags::UNDERLINE,						"underline"		},
			{ onyx::Styling::TextStyleFlags::STRIKE_THROUGH,					"strikethrough"	},
			{ onyx::Styling::TextStyleFlags::BACKGROUND,						"background"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::TextStyleFlags");
	}

	inline std::string_view toStringView(onyx::Styling::TextPlacement value)
	{
		static std::unordered_map<onyx::Styling::TextPlacement, std::string_view> const nameMap =
		{
			{ onyx::Styling::TextPlacement::UNSPECIFIED,						"unspecified"	},
			{ onyx::Styling::TextPlacement::HORIZONTAL_CENTER,				"center"		},
			{ onyx::Styling::TextPlacement::LEFT,								"left"			},
			{ onyx::Styling::TextPlacement::RIGHT,							"right"			},
			{ onyx::Styling::TextPlacement::ABOVE,							"top"			},
			{ onyx::Styling::TextPlacement::BELOW,							"bottom"		},
			{ onyx::Styling::TextPlacement::TOP_LEFT,							"top-left"		},
			{ onyx::Styling::TextPlacement::TOP_RIGHT,						"top-right"		},
			{ onyx::Styling::TextPlacement::BOTTOM_LEFT,						"bottom-left"	},
			{ onyx::Styling::TextPlacement::BOTTOM_RIGHT,						"bottom-right"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::FontStyle::TextPlacement");
	}

}

namespace onyx {
namespace Utils {

	// I'd love to find a less manual way of tagging enums as "convert this using flags",
	// but this works pretty slick when it's all set up.  Considered making it part of the
	// BitwiseEnumOperators macro but the namespaces make it tricky.
	template<>
	struct EnumStringConverter<Styling::TextStyleFlags>
	{
		static Styling::TextStyleFlags convert(std::string_view const& view) {
			return Utils::flagsEnumTypeFromString<Styling::TextStyleFlags>(view);
		}
	};

	template<>
	struct EnumStringConverter<Styling::TextPlacement>
	{
		static Styling::TextPlacement convert(std::string_view const& view) {
			return Utils::flagsEnumTypeFromString<Styling::TextPlacement>(view);
		}
	};

} }

#endif