#include "Realize.h"

namespace onyx::Styling
{

	static uint32_t ABGR(Expressions::Arguments const& args, Expressions::ColorT::Ptr const& color, Expressions::NumberT::Ptr const& opacity, uint32_t abgr)
	{
		if (color || opacity)
		{
			lgal::Color initial = color ? color->evaluate(args) : lgal::Color::FromABGR(abgr);
			if (opacity) initial.a = opacity->evaluate(args);

			abgr = initial.abgr();
		}

		return abgr;
	}

	template<typename T>
	static int ToInt(T const input)
	{
		return static_cast<int>(std::round(input));
	}

	static IntersectConfig::MaskT Scale(IntersectConfig::MaskT const& input, float const conversion)
	{
		IntersectConfig::MaskT scaled;
		for (size_t i = 0; i < input.size(); ++i)
		{
			scaled.push_back(input[i] * conversion);
		}
		return scaled;
	}

	void realize(Arguments const& args, BackgroundLayout const& l, BackgroundStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, style);
		}
	}
	void realize(Arguments const& args, BackgroundPaint const& p, BackgroundStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		if (p.color || p.opacity) style.abgr = ABGR(args.expressions, p.color, p.opacity, style.abgr);
		if (p.pattern) style.pattern = p.pattern->evaluate(args.expressions);
	}

	void realize(Arguments const& args, CircleLayout const& l, CircleStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, style);
		}
	}
	void realize(Arguments const& args, CirclePaint const& p, CircleStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		if (p.radius) style.radius = p.radius->evaluate(args.expressions);
		if (p.color || p.opacity) style.abgr = ABGR(args.expressions, p.color, p.opacity, style.abgr);
		if (p.strokeWidth) style.strokeWidth = p.strokeWidth->evaluate(args.expressions);

		if (p.strokeColor != nullptr || p.strokeOpacity != nullptr)
		{
			lgal::Color color = p.strokeColor ? p.strokeColor->evaluate(args.expressions) : lgal::Color::FromABGR(style.strokeAbgr);
			if (p.strokeOpacity) { color.a = p.strokeOpacity->evaluate(args.expressions); }
			style.strokeAbgr = color.abgr();
		}
	}

	void realize(Arguments const& args, ContourLabelLayout const& l, ContourLabelConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		realize(args, l.text, config.text);

		if (l.units) config.contours.units = l.units->evaluate(args.expressions);
		if (l.period) config.contours.period = ToInt(l.period->evaluate(args.expressions));
		if (l.skipPeriod) config.contours.skipPeriod = ToInt(l.skipPeriod->evaluate(args.expressions));
		if (l.phase) config.contours.phase = ToInt(l.phase->evaluate(args.expressions));
		if (l.min) config.contours.min = ToInt(l.min->evaluate(args.expressions));
		if (l.max) config.contours.max = ToInt(l.max->evaluate(args.expressions));
	}
	void realize(Arguments const& args, ContourLabelPaint const& p, ContourLabelConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		realize(args, p.text, config.text);
	}

	void realize(Arguments const& args, ContourLineLayout const& l, ContourLineConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}
	}
	void realize(Arguments const& args, ContourLinePaint const& p, ContourLineConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (p.color || p.opacity) config.abgr = ABGR(args.expressions, p.color, p.opacity, config.abgr);
		if (p.max) config.contours.max = ToInt(p.max->evaluate(args.expressions));
		if (p.min) config.contours.min = ToInt(p.min->evaluate(args.expressions));
		if (p.period) config.contours.period = ToInt(p.period->evaluate(args.expressions));
		if (p.units) config.contours.units = p.units->evaluate(args.expressions);
		if (p.width) config.width = p.width->evaluate(args.expressions);
	}

	void realize(Arguments const& args, FillLayout const& l, FillStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, style);
		}
	}
	void realize(Arguments const& args, FillPaint const& p, FillStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		if (p.color || p.opacity) style.abgr = ABGR(args.expressions, p.color, p.opacity, style.abgr);
		if (p.pattern) style.pattern = p.pattern->evaluate(args.expressions);
	}

	void realize(Arguments const& args, HillshadeLayout const& l, HillshadeConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}
	}
	void realize(Arguments const& args, HillshadePaint const& p, HillshadeConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (p.albedo || p.opacity) config.abgr = ABGR(args.expressions, p.albedo, p.opacity, config.abgr);
		if (p.azimuth) config.azimuth = p.azimuth->evaluate(args.expressions);
		if (p.altitude) config.altitude = p.altitude->evaluate(args.expressions);
		if (p.ambientIntensity) config.ambientIntensity = p.ambientIntensity->evaluate(args.expressions);
		if (p.exaggeration) config.exaggeration = p.exaggeration->evaluate(args.expressions);
	}

	void realize(Arguments const& args, LineLayout const& l, LineStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		if (l.joinType) style.joinType = l.joinType->evaluate(args.expressions);
		if (l.capType) style.capType = l.capType->evaluate(args.expressions);
	}
	void realize(Arguments const& args, LinePaint const& p, LineStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		if (p.color || p.opacity) style.abgr = ABGR(args.expressions, p.color, p.opacity, style.abgr);
		if (p.width) style.width = p.width->evaluate(args.expressions);
		if (p.dashArray) style.dashArray = DashArray{ p.dashArray->evaluate(args.expressions) };
	}

	void realize(Arguments const& args, ElevationLayout const& l, ElevationConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		// convert from meters to km
		if (l.gradientMeters) config.gradient = l.gradientMeters->evaluate(args.expressions) * 0.001;
	}
	void realize(Arguments const& args, ElevationPaint const& p, ElevationConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (p.maskMeters) config.mask = Scale(p.maskMeters->evaluate(args.expressions), 0.001f);
		if (p.opacity) config.opacity = p.opacity->evaluate(args.expressions);
	}

	void realize(Arguments const& args, RasterLayout const& l, RasterStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, style);
		}
	}
	void realize(Arguments const& args, RasterPaint const& p, RasterStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		if (p.opacity) style.opacity = p.opacity->evaluate(args.expressions);
	}

	void realize(Arguments const& args, SlopeAngleLayout const& l, SlopeAngleConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		// convert from degrees to radians
		time_float_t deg2rad = lmath::constants::pi<time_float_t>() / 180.0;
		if (l.gradientDegrees) config.gradient = l.gradientDegrees->evaluate(args.expressions) * deg2rad;
	}
	void realize(Arguments const& args, SlopeAnglePaint const& p, SlopeAngleConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		float deg2rad = lmath::constants::pi<float>() / 180.0f;
		if (p.maskDegrees) config.mask = Scale(p.maskDegrees->evaluate(args.expressions), deg2rad);
		if (p.opacity) config.opacity = p.opacity->evaluate(args.expressions);
	}

	void realize(Arguments const& args, SlopeAspectLayout const& l, SlopeAspectConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		// convert from degrees to radians
		time_float_t deg2rad = lmath::constants::pi<time_float_t>() / 180.0;
		if (l.gradientDegrees) config.gradient = l.gradientDegrees->evaluate(args.expressions) * deg2rad;
	}
	void realize(Arguments const& args, SlopeAspectPaint const& p, SlopeAspectConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		// convert from degrees to radians
		float deg2rad = lmath::constants::pi<float>() / 180.0f;
		if (p.maskDegrees) config.mask = Scale(p.maskDegrees->evaluate(args.expressions), deg2rad);
		if (p.minimumAngleDegrees) config.minimumAngle = p.minimumAngleDegrees->evaluate(args.expressions) * deg2rad;
		if (p.opacity) config.opacity = p.opacity->evaluate(args.expressions);
	}

	void realize(Arguments const& args, ViewshedLayout const& l, ViewshedConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (l.lon) config.lon = l.lon->evaluate(args.expressions);
		if (l.lat) config.lat = l.lat->evaluate(args.expressions);
		
		// convert from meters to km
		if (l.rangeMeters) config.rangeKm = l.rangeMeters->evaluate(args.expressions) * 0.001f;
		if (l.offsetMeters) config.offsetKm = l.offsetMeters->evaluate(args.expressions) * 0.001f;
		
		if (l.inverted) config.inverted = l.inverted->evaluate(args.expressions);
	}
	void realize(Arguments const& args, ViewshedPaint const& p, ViewshedConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (p.tint || p.opacity) config.abgr = ABGR(args.expressions, p.tint, p.opacity, config.abgr);
		if (p.ringTint || p.ringOpacity) config.ringAbgr = ABGR(args.expressions, p.ringTint, p.ringOpacity, config.ringAbgr);
	}

	void realize(Arguments const& args, SunlightLayout const& l, SunlightConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (l.year) config.year = ToInt(l.year->evaluate(args.expressions));
		if (l.month) config.month = ToInt(l.month->evaluate(args.expressions));
		if (l.day) config.day = ToInt(l.day->evaluate(args.expressions));
		if (l.hour) config.hour24 = l.hour->evaluate(args.expressions);
	}
	void realize(Arguments const& args, SunlightPaint const& p, SunlightConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (p.shadowStrength) config.shadowStrength = p.shadowStrength->evaluate(args.expressions);
	}

	void realize(Arguments const& args, SymbolLayout const& l, SymbolStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		realize(args, l.text, style.text);

		if (l.symbolPlacement) style.placement = l.symbolPlacement->evaluate(args.expressions);

		if (l.iconImage != nullptr) style.icon.image = l.iconImage->evaluate(args.expressions);
		if (l.iconSize != nullptr) style.icon.size = l.iconSize->evaluate(args.expressions);
		// TODO (Ronald): This assumes that SymbolPlacement is Point for now
		if (l.iconRotAlignment != nullptr)
		{
			style.icon.orientToVpXAxis = (l.iconRotAlignment->evaluate(args.expressions) == Alignment::Map) ? false : true;
		}
		if (l.iconPitchAlignment != nullptr)
		{
			auto alignOpt = l.iconPitchAlignment->evaluate(args.expressions);
			if (alignOpt == Alignment::Auto)
			{
				style.icon.orientToVpPlane = style.icon.orientToVpXAxis;
			}
			else
			{
				style.icon.orientToVpPlane = (alignOpt == Alignment::Viewport) ? true : false;
			}
		}
		if (l.iconRotDeg != nullptr) style.icon.rotDeg = l.iconRotDeg->evaluate(args.expressions);
		if (l.iconAnchor != nullptr) style.icon.anchor = l.iconAnchor->evaluate(args.expressions);
	}
	void realize(Arguments const& args, SymbolPaint const& p, SymbolStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, style);
		}

		realize(args, p.text, style.text);

		if (p.iconColor != nullptr) style.icon.color = p.iconColor->evaluate(args.expressions);
		if (p.iconOpacity != nullptr) style.icon.opacity = p.iconOpacity->evaluate(args.expressions);
		if (p.iconTranslate != nullptr)
		{
			auto arr = p.iconTranslate->evaluate(args.expressions);
			style.icon.anchorTranslate = lgal::gpu::Vector2{ arr[0], arr[1] };
		}
		if (p.iconTranslateAnchor != nullptr) style.icon.anchorOrient = p.iconTranslateAnchor->evaluate(args.expressions);
	}

	void realize(Arguments const& args, IntersectLayout const& l, IntersectConfig& config)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		if (l.inverted) config.inverted = l.inverted->evaluate(args.expressions);
	}
	void realize(Arguments const& args, IntersectPaint const& p, IntersectConfig& config)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realize(args, *base, config);
		}

		// convert from meters to km
		if (p.elevationMaskMeters) config.elevationMask = Scale(p.elevationMaskMeters->evaluate(args.expressions), 0.001f);

		// convert from degrees to radians
		float deg2rad = lmath::constants::pi<float>() / 180.0f;
		if (p.slopeAngleMaskDegrees) config.slopeAngleMask = Scale(p.slopeAngleMaskDegrees->evaluate(args.expressions), deg2rad);
		if (p.slopeAspectMaskDegrees) config.slopeAspectMask = Scale(p.slopeAspectMaskDegrees->evaluate(args.expressions), deg2rad);

		if (p.tint || p.opacity) config.abgr = ABGR(args.expressions, p.tint, p.opacity, config.abgr);
	}

	void realize(Arguments const& args, TextLayoutComponent const& l, TextStyle& style)
	{
		// TODO (scott) This magic number is cribbed from font_manager.h; we'll need a way to expose
		// it to the stylesheet configuration at some point.
		// #define FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE  UINT32_C(0x00003900) // L8 + BGRA8
		auto textSize = style.font.pixelSize;
		if (l.textSize) textSize = (int32_t)l.textSize->evaluate(args.expressions);
		if (l.fontFace) style.font = FontFace{ l.fontFace->evaluate(args.expressions).front(), 0x00003900, textSize };
		if (l.textAnchor) style.textAnchor = l.textAnchor->evaluate(args.expressions);

		if (l.textStyleFlags) style.textStyle = l.textStyleFlags->evaluate(args.expressions);
		if (l.letterSpacing) style.kerningModifier = l.letterSpacing->evaluate(args.expressions);
	}
	void realize(Arguments const& args, TextPaintComponent const& p, TextStyle& style)
	{
		if (p.color) style.color = p.color->evaluate(args.expressions);
		if (p.shadowColor) style.dropshadowColor = p.shadowColor->evaluate(args.expressions);
		if (p.haloColor) style.haloColor = p.haloColor->evaluate(args.expressions);
		if (p.strikethroughColor) style.strikethroughColor = p.strikethroughColor->evaluate(args.expressions);
		if (p.overlineColor) style.overlineColor = p.overlineColor->evaluate(args.expressions);
		if (p.underlineColor) style.underlineColor = p.underlineColor->evaluate(args.expressions);
		if (p.backgroundColor) style.backgroundColor = p.backgroundColor->evaluate(args.expressions);
		if (p.opacity) style.opacity = p.opacity->evaluate(args.expressions);
	}

	void realize(Arguments const& args, TextLayoutComponent const& l, Text& text)
	{
		realize(args, l, text.style);

		if (l.textField) text.field = l.textField->evaluate(args.expressions);
	}
	void realize(Arguments const& args, TextPaintComponent const& p, Text& text)
	{
		realize(args, p, text.style);
	}

}