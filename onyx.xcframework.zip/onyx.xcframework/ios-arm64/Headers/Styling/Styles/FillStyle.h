#pragma once

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>
#include <Utils/EnumUtils.h>

#include "Styling/Enums.h"
#include "Styling/Types.h"

namespace onyx::Styling
{

	/*
	* Struct that stores values for all the available options for fill styling. The general idea is that the
	* expressions in a FillLayer can be evaluated to produce this struct which can be encoded in a texture and 
	* style vectors on the gpu.
	*
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is
	* added to FillStyle
	*/

	struct FillStyle
	{

		uint32_t abgr = 0xFF000000;		// just use 32-bit color code because this struct pretty much goes straight to the gpu
		ResolvedImage pattern{ "" };

		// TODO maybe require a constructor so we don't accidentally miss a parameter? for now, it's nice to have the default values
	
	public:

		struct Effect
		{
			DepthTest depthTest = DepthTest::LEQUAL;
			lgal::gpu::Vector2 fadeRange = { 2.0, 4.0 };
		};

	};

	inline bool operator==(FillStyle const& lhs, FillStyle const& rhs)
	{
		return lhs.abgr == rhs.abgr
				&& lhs.pattern == rhs.pattern;		
	}

	inline bool operator!=(FillStyle const& lhs, FillStyle const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(FillStyle const& lhs, FillStyle const& rhs)
	{
		if (lhs.abgr < rhs.abgr) { return true; }
		if (lhs.abgr > rhs.abgr) { return false; }

		if (lhs.pattern < rhs.pattern) { return true; }
		if (lhs.pattern > rhs.pattern) { return false; }

		return false;
	}

}

namespace std
{

	template<>
	struct hash<onyx::Styling::FillStyle>
	{

		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::FillStyle const& style) const
		{
			size_t hash = 0;
			hash += style.abgr * 47;
			hash += std::hash<std::string>{}(style.pattern.key);
			return hash;
		}

	};

}