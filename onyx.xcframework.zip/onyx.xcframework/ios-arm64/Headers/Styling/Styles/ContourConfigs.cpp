#include "ContourConfigs.h"

#include "Styling/Layers/Layouts/Layout.h"
#include "Styling/Layers/Paints/Paint.h"

namespace onyx {
namespace Styling {

	bool ContourConfig::contains(int elevation) const
	{
		// test that the elevation is in the appropriate range
		if (min <= elevation && elevation <= max)
		{
			int adjusted = elevation - phase;
			// test that the elevation hits the period and does not hit the skipPeriod
			if (adjusted % period == 0)
			{
				if (skipPeriod == 0)
				{
					return true;
				}
				else if (adjusted % skipPeriod != 0)
				{
					return true;
				}
			}
		}

		// fall-through case is to return false
		return false;
	}

	std::vector<int> ContourConfig::straddled(height_float_t const a, height_float_t const b) const
	{
		std::vector<int> straddled;

		// check if a and b are outside the bounds
		bool intersects = !(b <= min || a >= max);
		if (intersects)
		{
			int begin = static_cast<int>(std::ceil(a));						// beginning of possible contour range
			int end = static_cast<int>(std::floor(b));						// end of possible contour range
			int offset = (period - ((begin - phase) % period)) % period;	// offset from begin to first possible contour
			for (int candidate = begin + offset; candidate <= end; candidate += period)
			{
				if (contains(candidate))
				{
					straddled.push_back(candidate);
				}
			}
		}

		return straddled;
	}


} }