#pragma once

#include <cstdint>

#include <string>

#include "Styling/Types.h"

namespace onyx::Styling
{

	struct BackgroundStyle
	{

		ResolvedImage pattern;
		uint32_t abgr;

	};

	inline bool operator==(BackgroundStyle const& lhs, BackgroundStyle const& rhs)
	{
		return lhs.pattern == rhs.pattern
			&& lhs.abgr == rhs.abgr;
	}

	inline bool operator!=(BackgroundStyle const& lhs, BackgroundStyle const& rhs)
	{
		return !(lhs == rhs);
	}

}