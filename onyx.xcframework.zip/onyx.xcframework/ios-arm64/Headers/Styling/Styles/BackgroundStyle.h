#pragma once

#include <cstdint>

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Enums.h"

namespace onyx::Styling
{

	struct BackgroundStyle
	{

		BlendMode blendMode;
		float opacity = 1.f;
		lgal::sprite::AABB2d pattern = {};
		uint32_t abgr = 0xFF000000;		// just use 32-bit color code because this struct pretty much goes straight to the gpu

		inline auto tie() const
		{
			return std::tie(blendMode, opacity, pattern.min.x, pattern.min.y, pattern.max.x, pattern.max.y, abgr);
		}

	};

	inline bool operator==(BackgroundStyle const& lhs, BackgroundStyle const& rhs)
	{
		return lhs.tie() == rhs.tie();
	}

	inline bool operator!=(BackgroundStyle const& lhs, BackgroundStyle const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(BackgroundStyle const& lhs, BackgroundStyle const& rhs)
	{
		return lhs.tie() < rhs.tie();
	}

}