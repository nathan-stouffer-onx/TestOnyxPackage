#ifndef __STYLING_TERRAIN_CONFIGS_H__
#define __STYLING_TERRAIN_CONFIGS_H__

#include <lucid/gal/Types.h>

#include <Utils/EnumUtils.h>
#include <Utils/Gradient.h>

namespace onyx {
namespace Styling {

	struct ElevationConfig
	{
		Utils::Gradient gradient;
		std::vector<lgal::gpu::Range> mask = { { -10, 9 } };
		float opacity = 0.5f;

		inline bool operator==(ElevationConfig const& rhs) const
		{
			return gradient == rhs.gradient
				&& mask == rhs.mask
				&& opacity == rhs.opacity;
		}

		inline bool operator!=(ElevationConfig const& rhs) const
		{
			return !(*this == rhs);
		}
	};

	struct HillshadeConfig
	{

		uint32_t abgr = 0xFFFFFFFF;
		float ambientIntensity = 0.f;
		float exaggeration = 1.f;
		float azimuth = 315.f;
		float altitude = 45.f;

		inline bool operator==(HillshadeConfig const& rhs) const
		{
			return abgr == rhs.abgr
				&& ambientIntensity == rhs.ambientIntensity
				&& exaggeration == rhs.exaggeration
				&& azimuth == rhs.azimuth
				&& altitude == rhs.altitude;
		}

		inline bool operator!=(HillshadeConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	public:

		static lgal::gpu::Vector3 LightDirection(float azimuth, float altitude)
		{
			float theta = lmath::degreesToRadians(azimuth);
			float phi = lmath::degreesToRadians(90.f - altitude);
			return
			{
				-std::sin(theta) * std::sin(phi),
				std::cos(theta) * std::sin(phi),
				-std::cos(phi)
			};
		}

	};

	struct SlopeAngleConfig
	{
		Utils::Gradient gradient;
		std::vector<lgal::gpu::Range> mask = { { 0, lmath::constants::half_pi<gpu_float_t>() } };
		float opacity = 0.5f;

		inline bool operator==(SlopeAngleConfig const& rhs) const
		{
			return gradient == rhs.gradient
				&& mask == rhs.mask
				&& opacity == rhs.opacity;
		}

		inline bool operator!=(SlopeAngleConfig const& rhs) const
		{
			return !(*this == rhs);
		}
	};

	struct SlopeAspectConfig
	{
		Utils::Gradient gradient;
		std::vector<lgal::gpu::Range> mask = { { 0, lmath::constants::two_pi<gpu_float_t>() } };
		float opacity = 0.5f;
		float minimumAngle = lmath::constants::pi<float>() / 36.f; // pi/36 radians = 5 degrees

		inline bool operator==(SlopeAspectConfig const& rhs) const
		{
			return gradient == rhs.gradient
				&& mask == rhs.mask
				&& opacity == rhs.opacity
				&& minimumAngle == rhs.minimumAngle;
		}

		inline bool operator!=(SlopeAspectConfig const& rhs) const
		{
			return !(*this == rhs);
		}
	};

	struct IntersectConfig
	{

		using MaskT = std::vector<lmath::Range<float>>;

		MaskT elevationMask;
		MaskT slopeAngleMask;
		MaskT slopeAspectMask;

		uint32_t abgr;

		bool inverted = false;

		inline bool operator==(IntersectConfig const& rhs) const
		{
			return elevationMask == rhs.elevationMask
				&& slopeAngleMask == rhs.slopeAngleMask
				&& slopeAspectMask == rhs.slopeAspectMask
				&& abgr == rhs.abgr
				&& inverted == rhs.inverted;
		}

		inline bool operator!=(IntersectConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

} }

#endif