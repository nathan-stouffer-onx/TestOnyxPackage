#pragma once

#include <lucid/gal/Types.h>

#include <Utils/EnumUtils.h>
#include <Utils/Gradient.h>

#include "Styling/Enums.h"

namespace onyx::Styling
{

	struct ElevationConfig
	{
		
		BlendMode blendMode = BlendMode::ALPHA;
	
		Utils::Gradient gradient;
		std::vector<lgal::gpu::Range> mask = { { -10, 9 } };
		float opacity = 0.5f;

		inline auto tie() const { return std::tie(blendMode, gradient, mask, opacity); }
		inline bool operator==(ElevationConfig const& rhs) const { return tie() == rhs.tie(); }
		inline bool operator!=(ElevationConfig const& rhs) const { return !(*this == rhs); }
	};

	struct HillshadeConfig
	{
		
		BlendMode blendMode = BlendMode::ALPHA;

		uint32_t abgr = 0xFFFFFFFF;
		float ambientIntensity = 0.f;
		float exaggeration = 1.f;
		float azimuth = 315.f;
		float altitude = 45.f;

		inline auto tie() const { return std::tie(blendMode, abgr, ambientIntensity, exaggeration, azimuth, altitude); }
		inline bool operator==(HillshadeConfig const& rhs) const { return tie() == rhs.tie(); }
		inline bool operator!=(HillshadeConfig const& rhs) const { return !(*this == rhs); }

	public:

		static lgal::gpu::Vector3 LightDirection(float azimuth, float altitude)
		{
			float theta = lmath::degreesToRadians(azimuth);
			float phi = lmath::degreesToRadians(90.f - altitude);
			return
			{
				-std::sin(theta) * std::sin(phi),
				std::cos(theta) * std::sin(phi),
				-std::cos(phi)
			};
		}

	};

	struct SlopeAngleConfig
	{
		BlendMode blendMode = BlendMode::ALPHA;
		
		Utils::Gradient gradient;
		std::vector<lgal::gpu::Range> mask = { { 0, lmath::constants::half_pi<gpu_float_t>() } };
		float opacity = 0.5f;

		inline auto tie() const { return std::tie(blendMode, gradient, mask, opacity); }
		inline bool operator==(SlopeAngleConfig const& rhs) const { return tie() == rhs.tie(); }
		inline bool operator!=(SlopeAngleConfig const& rhs) const { return !(*this == rhs); }
	};

	struct SlopeAspectConfig
	{
		BlendMode blendMode = BlendMode::ALPHA;
		
		Utils::Gradient gradient;
		std::vector<lgal::gpu::Range> mask = { { 0, lmath::constants::two_pi<gpu_float_t>() } };
		float opacity = 0.5f;
		float minimumAngle = lmath::constants::pi<float>() / 36.f; // pi/36 radians = 5 degrees

		inline auto tie() const { return std::tie(blendMode, gradient, mask, opacity, minimumAngle); }
		inline bool operator==(SlopeAspectConfig const& rhs) const { return tie() == rhs.tie(); }
		inline bool operator!=(SlopeAspectConfig const& rhs) const { return !(*this == rhs); }
	};

	struct IntersectConfig
	{

		using MaskT = std::vector<lmath::Range<float>>;

		BlendMode blendMode = BlendMode::ALPHA;
		
		MaskT elevationMask;
		MaskT slopeAngleMask;
		MaskT slopeAspectMask;

		float slopeAspectMinimumAngle = lmath::constants::pi<float>() / 36.f; // pi/36 radians = 5 degrees

		uint32_t abgr;

		bool inverted = false;

		inline auto tie() const { return std::tie(blendMode, elevationMask, slopeAngleMask, slopeAspectMask, slopeAspectMinimumAngle, abgr, inverted); }
		inline bool operator==(IntersectConfig const& rhs) const { return tie() != rhs.tie(); }
		inline bool operator!=(IntersectConfig const& rhs) const { return !(*this == rhs); }

	};

}