#include "FillStyle.h"
#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"

namespace onyx {
namespace Styling {

	// Currently does nothing but here for completeness' sake
	void FillStyle::realizeLayout(Expressions::Arguments const& /*args*/, std::shared_ptr<FillLayout const>& /*l*/)
	{
		//if (l->basePtr != nullptr)
		//{
		//	realizeLayout(args, l->basePtr);
		//}
	}

	void FillStyle::realizePaint(Expressions::Arguments const& args, std::shared_ptr<FillPaint const>& p)
	{
		if (p->basePtr)
		{
			realizePaint(args, p->basePtr);
		}

		if (p->color != nullptr || p->opacity != nullptr)
		{
			lgal::Color color = p->color ? p->color->evaluate(args) : lgal::Color::FromABGR(abgr);
			if (p->opacity) { color.a = p->opacity->evaluate(args); }

			abgr = color.abgr();
		}
		if (p->pattern) pattern = p->pattern->evaluate(args);
	}

} }