#pragma once

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>

#include "Styling/Enums.h"
#include "Styling/Formatted.h"

namespace onyx::Styling
{

	struct FontFace
	{
		std::string name;
		int32_t fontType;
		int32_t pixelSize;

		inline bool operator==(FontFace const& rhs) const
		{
			return name == rhs.name
				&& fontType == rhs.fontType
				&& pixelSize == rhs.pixelSize;
		}

		inline bool operator!=(FontFace const& rhs) const { return !(*this == rhs); }

		inline bool operator<(FontFace const& rhs) const
		{
			if (pixelSize != rhs.pixelSize) { return pixelSize < rhs.pixelSize; }
			if (fontType != rhs.fontType) { return fontType < rhs.fontType; }
			return name < rhs.name;
		}

		inline bool operator>(FontFace const& rhs) const { return rhs < *this; }
	};

	/*
	* Struct that stores values for all the available options for font styling. The general idea is that the
	* expressions in a SymbolLayer can be evaluated to produce this struct which can be encoded in a texture and 
	* style vectors on the gpu and/or be passed as shader parameters.
	*
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is
	* added to TextStyle
	*/
	struct TextStyle
	{

		FontFace font;

		lgal::Color color = { 0.0f, 0.0f, 0.0f, 1.0f };
		lgal::Color haloColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color dropshadowColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color strikethroughColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color overlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color underlineColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		lgal::Color backgroundColor = { 0.0f, 0.0f, 0.0f, 0.0f };
		gpu_float_t opacity = 1.0f;

		float32_t kerningModifier = 0;

		lgal::gpu::Vector2 anchorTranslate = { 0 };
		TranslateAnchor anchorOrient = TranslateAnchor::MAP;
		std::vector<Anchor> anchors;

		Alignment pitchAlignment = Alignment::Auto;
		Alignment rotAlignment = Alignment::Auto;
		gpu_float_t padding = 2.f;
		bool allowOverlap = false;

		lgal::gpu::Vector2 offsetEm = { 0 };
		bool usingRadialOffset = false;

		TextStyleFlags flags = TextStyleFlags::NORMAL;
		bool keepUpright = true;

		TextStyle() { }

		TextStyle(FontFace const& face, lgal::Color const& color, lgal::Color const& haloColor, lgal::Color const& dropshadowColor, lgal::Color const& strikethroughColor, lgal::Color const& overlineColor, lgal::Color const& underlineColor, lgal::Color const& backgroundColor, float32_t kerningModifier, Anchor anchor)
			: font(face)
			, color(color)
			, haloColor(haloColor)
			, dropshadowColor(dropshadowColor)
			, strikethroughColor(strikethroughColor)
			, overlineColor(overlineColor)
			, underlineColor(underlineColor)
			, backgroundColor(backgroundColor)
			, kerningModifier(kerningModifier)
			, anchors()
		{
			anchors.push_back(anchor);
		}

		TextStyle(FontFace const& face, lgal::Color const& color, lgal::Color const& haloColor, lgal::Color const& dropshadowColor, float32_t kerningModifier, Anchor textAnchor)
			: TextStyle(face, color, haloColor, dropshadowColor, 0, 0, 0, 0, kerningModifier, textAnchor)
		{ }

		static TextStyle empty() { return TextStyle(FontFace{ "", 0, 15 }, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0.f, Anchor::UNSPECIFIED); }

		inline bool operator==(TextStyle const& rhs) const
		{
			return color == rhs.color		// just use 32-bit color code because this struct pretty much goes straight to the gpu in that format
				&& haloColor == rhs.haloColor
				&& dropshadowColor == rhs.dropshadowColor
				&& kerningModifier == rhs.kerningModifier
				&& font == rhs.font
				&& anchors == rhs.anchors
				&& flags == rhs.flags
				&& strikethroughColor == rhs.strikethroughColor
				&& overlineColor == rhs.overlineColor
				&& underlineColor == rhs.underlineColor
				&& backgroundColor == rhs.backgroundColor
				&& opacity == rhs.opacity
				&& anchorTranslate == rhs.anchorTranslate
				&& anchorOrient == rhs.anchorOrient
				&& offsetEm == rhs.offsetEm
				&& usingRadialOffset == rhs.usingRadialOffset
				&& pitchAlignment == rhs.pitchAlignment
				&& rotAlignment == rhs.rotAlignment
				&& padding == rhs.padding
				&& keepUpright == rhs.keepUpright
				&& allowOverlap == rhs.allowOverlap
				;
		}

		inline bool operator!=(TextStyle const& rhs) const { return !(*this == rhs); }

		inline bool operator<(TextStyle const& rhs) const
		{
			if (font != rhs.font) { return font < rhs.font; }
			if (kerningModifier != rhs.kerningModifier) { return kerningModifier < rhs.kerningModifier; }
			if (haloColor != rhs.haloColor) { return haloColor < rhs.haloColor; }
			if (dropshadowColor != rhs.dropshadowColor) { return dropshadowColor < rhs.dropshadowColor; }
			if (strikethroughColor != rhs.strikethroughColor) { return strikethroughColor < rhs.strikethroughColor; }
			if (overlineColor != rhs.overlineColor) { return overlineColor < rhs.overlineColor; }
			if (underlineColor != rhs.underlineColor) { return underlineColor < rhs.underlineColor; }
			if (backgroundColor != rhs.backgroundColor) { return backgroundColor < rhs.backgroundColor; }
			if (!(anchors == rhs.anchors)) { return anchors < rhs.anchors; }
			if (flags != rhs.flags) { return flags < rhs.flags; }
			if (opacity != rhs.opacity) { return opacity < rhs.opacity; }
			if (anchorTranslate != rhs.anchorTranslate) 
			{
				return anchorTranslate.x < rhs.anchorTranslate.x && anchorTranslate.y < rhs.anchorTranslate.y;
			}
			if (offsetEm != rhs.offsetEm) 
			{
				return offsetEm.x < rhs.offsetEm.x && offsetEm.y < rhs.offsetEm.y;
			}
			if (anchorOrient != rhs.anchorOrient) { return anchorOrient < rhs.anchorOrient; }
			if (usingRadialOffset != rhs.usingRadialOffset) { return usingRadialOffset < rhs.usingRadialOffset; }
			if (pitchAlignment != rhs.pitchAlignment) { return pitchAlignment < rhs.pitchAlignment; }
			if (rotAlignment != rhs.rotAlignment) { return rotAlignment < rhs.rotAlignment; }
			if (padding != rhs.padding) { return padding < rhs.padding; }
			if (keepUpright != rhs.keepUpright) { return keepUpright < rhs.keepUpright; }
			if (allowOverlap != rhs.allowOverlap) { return allowOverlap < rhs.allowOverlap; }
			return color < rhs.color;
		}

		inline bool operator>(TextStyle const& rhs) const { return rhs < *this; }

	};

	struct Text
	{
		// TODO (scott) maybe consider finding a way to safely use string_view here
		Formatted field;
		TextStyle style;

	};

}

namespace std
{

	template<>
	struct hash<onyx::Styling::FontFace>
	{
		inline size_t operator()(onyx::Styling::FontFace const& fontFace) const
		{
			std::hash<std::string> sHasher;
			std::hash<int32_t> i32Hasher;

			return sHasher(fontFace.name) * 23
				^ i32Hasher(fontFace.fontType) * 23
				^ i32Hasher(fontFace.pixelSize) * 23;
		}
	};

	template<>
	struct hash<std::vector<onyx::Styling::Anchor>>
	{
		inline size_t operator()(std::vector<onyx::Styling::Anchor> const& anchors) const
		{
			using aType = std::underlying_type_t<onyx::Styling::Anchor>;

			std::hash<aType> anchorHasher;
			
			size_t hash = 0;
			for (size_t i = 0; i < anchors.size(); ++i)
			{
				hash += anchorHasher(static_cast<aType>(anchors[i]) + static_cast<aType>(i)) * 17;
			}
			return hash;
		}
	};

	template<>
	struct hash<onyx::Styling::TextStyle>
	{
		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::TextStyle const& style) const
		{
			std::hash<onyx::Styling::FontFace> fntHasher;
			std::hash<float> fHasher;
			std::hash<bool> bHasher;
			std::hash<uint32_t> iHasher;
			std::hash<std::vector<onyx::Styling::Anchor>> anchorHasher;

			size_t hash = 0;
			hash += size_t(style.color.argb()) * 47;				// just use 32-bit color code because this struct pretty much goes straight to the gpu in that format
			hash += size_t(style.dropshadowColor.argb()) * 47;
			hash += size_t(style.haloColor.argb()) * 47;
			hash += size_t(style.strikethroughColor.argb()) * 47;
			hash += size_t(style.overlineColor.argb()) * 47;
			hash += size_t(style.underlineColor.argb()) * 47;
			hash += size_t(style.backgroundColor.argb()) * 47;
			hash += fntHasher(style.font) * 47;
			hash += fHasher(style.kerningModifier) * 47;
			hash += lmath::hashCode(style.anchorTranslate) * 47;
			hash += lmath::hashCode(style.offsetEm) * 47;
			hash += iHasher(uint32_t(style.anchorOrient)) * 47;
			hash += anchorHasher(style.anchors) * 47;
			hash += iHasher(uint32_t(style.flags)) * 47;
			hash += bHasher(uint32_t(style.usingRadialOffset)) * 47;
			hash += iHasher(uint32_t(style.pitchAlignment)) * 47;
			hash += iHasher(uint32_t(style.rotAlignment)) * 47;
			hash += fHasher(style.padding) * 47;
			hash += bHasher(style.keepUpright) * 47;
			hash += bHasher(style.allowOverlap) * 47;
			return hash;
		}
	};

}
