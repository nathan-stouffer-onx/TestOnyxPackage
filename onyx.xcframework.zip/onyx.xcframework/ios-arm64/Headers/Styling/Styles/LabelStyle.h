#ifndef STYLING_FONTSTYLE_H
#define STYLING_FONTSTYLE_H

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {

	struct LabelStyle
	{
		// TODO (scott) maybe consider finding a way to safely use string_view here
		std::string labelText;

		template<typename LayoutT>
		inline void realizeLayout(Expressions::Arguments const& args, LayoutT const& layout)
		{
			if (layout.textField != nullptr)
			{
				labelText = layout.textField->evaluate(args);
				return;
			}
			MAP3D_DEBUG_ASSERT(layout.basePtr != nullptr, "No fallthrough layout available");
			realizeLayout(args, *layout.basePtr);
		}

		template<typename PaintT>
		inline void realizePaint(Expressions::Arguments const& args, PaintT const& paint);
	};

	template<typename PaintT>
	inline void LabelStyle::realizePaint(Expressions::Arguments const&, PaintT const&) { }

} }

#endif // STYLING_FONTSTYLE_H