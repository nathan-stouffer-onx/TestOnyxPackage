#ifndef STYLING_FONTSTYLE_H
#define STYLING_FONTSTYLE_H

#include "Styling/Formatted.h"

namespace onyx {
namespace Styling {

	struct LabelStyle
	{
		// TODO (scott) maybe consider finding a way to safely use string_view here
		Formatted labelText;

	};

} }

#endif // STYLING_FONTSTYLE_H