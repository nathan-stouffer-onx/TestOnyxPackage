#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Types.h"
#include "Styling/Enums.h"

namespace onyx::Styling {

	struct IconStyle
	{
		/* layout */
		// Image name used to retrive sprite texture
		ResolvedImage image = {};
		// How much extra padding should be added when fitting to text
		lgal::gpu::Vector4 textFitPadding = { 0 };
		// Pixel amount to move icon away from offset. See description of 'icon-offset` to see how this works.
		lgal::gpu::Vector2 offsetPx = { 0 };
		// Size multiplier
		gpu_float_t sizeMultiple = 1.f;
		// CW orientation of icon in radians
		gpu_float_t rotRad = 0;
		// Additional area around AABB for symbol collision detection
		gpu_float_t padding = 2.f;
		// Tells which part of the icon should be closest to anchor before "offset" is taken into account
		Anchor anchor = Anchor::CENTER;
		// Options for resizing the icon to the text's size
		TextFitOpts textFitOpts = TextFitOpts::None;
		// Rotation alignment option (map, viewport, auto)
		Alignment rotAlignment = Alignment::Auto;
		// Pitch alignment option (map, viewport, auto)
		Alignment pitchAlignment = Alignment::Auto;
		// Allows visibility even when icon collides with other symbols
		bool allowOverlap = false;
		// Allows other symbols to be visible if they collide with this icon
		bool ignorePlacement = false;

		/* paint */
		// Does not do anything yet (more applicable once we support SDF)
		lgal::Color color = lgal::Color(0xFF000000);
		// Pixel amount of offset anchor by
		lgal::gpu::Vector2 anchorOffsetPx = { 0 };
		// Icon maximum opacity
		gpu_float_t opacity = 1.f;
		// Frame of reference at which the anchor will be offset against
		TranslateAnchor anchorOffsetFrame = TranslateAnchor::MAP;

		inline auto tie() const { return std::tie(image, textFitPadding, offsetPx, sizeMultiple, rotRad, padding, anchor, textFitOpts, rotAlignment, pitchAlignment, allowOverlap, ignorePlacement, color, anchorOffsetPx, opacity, anchorOffsetFrame); }

		bool operator==(IconStyle const& rhs) const
		{
			return this->tie() == rhs.tie();
		}

		bool operator!=(IconStyle const& rhs) const 
		{
			return !(*this == rhs);
		}
	
	};

}

namespace std {

template <>
struct hash<onyx::Styling::IconStyle>
{
	inline size_t operator()(onyx::Styling::IconStyle const& style)
	{
		hash<float> fHasher;
		hash<bool> bHasher;
		hash<string> strHasher;
		hash<uint32_t> iHasher;
		hash<lgal::Color> colorHasher;

		size_t res = 0;

		res += 23 * strHasher(style.image.key);
		res += 23 * lmath::hashCode(style.textFitPadding);
		res += 23 * lmath::hashCode(style.offsetPx);
		res += 23 * fHasher(style.sizeMultiple);
		res += 23 * fHasher(style.rotRad);
		res += 23 * fHasher(style.padding);
		res += 23 * iHasher((uint32_t)style.anchor);
		res += 23 * iHasher((uint32_t)style.textFitOpts);
		res += 23 * iHasher((uint32_t)style.rotAlignment);
		res += 23 * iHasher((uint32_t)style.pitchAlignment);
		res += 23 * bHasher(style.allowOverlap);
		res += 23 * bHasher(style.ignorePlacement);

		res += 23 * colorHasher(style.color);
		res += 23 * lmath::hashCode(style.anchorOffsetPx);
		res += 23 * fHasher(style.opacity);
		res += 23 * iHasher((uint32_t)style.anchorOffsetFrame);

		return res;
	}
};

}
