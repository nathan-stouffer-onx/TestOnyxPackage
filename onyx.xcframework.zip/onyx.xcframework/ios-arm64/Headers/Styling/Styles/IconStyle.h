#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Types.h"
#include "Styling/Enums.h"

namespace onyx::Styling
{

	struct IconStyle
	{
		// layout
		ResolvedImage image;
		lgal::gpu::Vector2 offset;
		gpu_float_t size;
		gpu_float_t rotDeg;
		Anchor anchor;
		TextFitOpts textFitOpts;
		lgal::gpu::Vector2 textFitPadding;
		bool rotateToVp;
		bool pitchToVp;

		// paint
		lgal::Color color;
		gpu_float_t opacity;
		lgal::gpu::Vector2 anchorTranslate;
		TranslateAnchor anchorOrient;

	};

}
