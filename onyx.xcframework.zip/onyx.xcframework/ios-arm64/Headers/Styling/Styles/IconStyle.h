#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Types.h"

namespace onyx::Styling
{

	struct IconStyle
	{
		// layout
		ResolvedImage image;
		gpu_float_t size;
		gpu_float_t rotDeg;
		Anchor anchor;
		bool orientToVpPlane;
		bool orientToVpXAxis;

		// paint
		lgal::Color color;
		gpu_float_t opacity;
		lgal::gpu::Vector2 anchorTranslate;
		TranslateAnchor anchorOrient;

	};

}
