#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Types.h"

namespace onyx::Styling {

	struct IconStyle
	{
		// layout
		ResolvedImage iconImage;
		gpu_float_t iconSize;
		gpu_float_t iconRotDeg;
		bool orientToVpPlane;
		bool orientToVpXAxis;
		
		// paint
		lgal::Color iconColor;
		gpu_float_t opacity;
	};

}
