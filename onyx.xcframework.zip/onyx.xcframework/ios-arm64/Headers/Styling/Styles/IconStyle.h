#ifndef STYLING_ICONSTYLE_H
#define STYLING_ICONSTYLE_H

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Types.h"

namespace onyx {
namespace Styling {

	struct IconStyle
	{
		// layout
		ResolvedImage iconImage;
		gpu_float_t iconSize;
		gpu_float_t iconRotDeg;
		bool orientToVpPlane;
		bool orientToVpXAxis;
		
		// paint
		lgal::Color iconColor;
	};

} }

#endif // STYLING_FONTSTYLE_H