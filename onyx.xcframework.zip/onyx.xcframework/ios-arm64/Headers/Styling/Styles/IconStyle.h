#ifndef STYLING_ICONSTYLE_H
#define STYLING_ICONSTYLE_H

#include <string>

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {

	struct IconStyle
	{
		lgal::Color iconColor;
		std::string iconImage;
		gpu_float_t iconSize;

		template<typename LayoutT>
		inline void realizeLayout(Expressions::Arguments const& args, LayoutT const& layout)
		{
			if (layout.basePtr != nullptr)
			{
				realizeLayout(args, *layout.basePtr);
			}
			if (layout.iconImage != nullptr) iconImage = layout.iconImage->evaluate(args);
			if (layout.iconSize != nullptr) iconSize = layout.iconSize->evaluate(args);
		}

		template<typename PaintT>
		inline void realizePaint(Expressions::Arguments const& args, PaintT const& paint)
		{
			if (paint.iconColor != nullptr)
			{
				iconColor = paint.iconColor->evaluate(args);
				return;
			}
			MAP3D_DEBUG_ASSERT(paint.basePtr != nullptr, "No fallthrough paint available");
			realizePaint(args, *paint.basePtr);
		}
	};

} }

#endif // STYLING_FONTSTYLE_H