#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include "Styling/Types.h"
#include "Styling/Enums.h"

namespace onyx::Styling
{

	struct IconStyle
	{
		/* layout */
		ResolvedImage image;
		// Pixel amount to move icon away from offset. See description of 'icon-offset` to see how this works.
		lgal::gpu::Vector2 offsetPx = 0;
		// Size multiplier
		gpu_float_t sizeMultiple = 1.f;
		// CW orientation of icon in radians
		gpu_float_t rotRad = 0;
		// Tells which part of the icon should be closest to anchor before "offset" is taken into account
		Anchor anchor = Anchor::CENTER;
		// Options for resizing the icon to the text's size
		TextFitOpts textFitOpts = TextFitOpts::None;
		// How much extra padding should be added when fitting to text?
		lgal::gpu::Vector4 textFitPadding = { 0 };
		// Additional area around AABB for symbol collision detection
		gpu_float_t padding = 2.f;

		Alignment rotAlignment = Alignment::Auto;
		Alignment pitchAlignment = Alignment::Auto;
		// Allows visibility even when icon collides with other symbols
		bool allowOverlap = false;
		// Allows other symbols to be visible if they collide with this icon
		bool ignorePlacement = false;

		/* paint */
		lgal::Color color = lgal::Color(0xFF000000);
		gpu_float_t opacity = 1.f;
		// Pixel amount of offset anchor by
		lgal::gpu::Vector2 anchorOffsetPx = { 0 };
		// Frame of reference at which the anchor will be offset against
		TranslateAnchor anchorOffsetFrame = TranslateAnchor::MAP;
	
	};

}
