#pragma once

#include "Styling/Layers/Layouts/Layout.h"
#include "Styling/Layers/Paints/Paint.h"
#include "Styling/Layers/Effects/Effect.h"
#include "Styling/Layers/Fog.h"
#include "Styling/Styles/BackgroundStyle.h"
#include "Styling/Styles/CircleStyle.h"
#include "Styling/Styles/ContourConfigs.h"
#include "Styling/Styles/FogStyle.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/IconStyle.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/RasterStyle.h"
#include "Styling/Styles/ShadowConfigs.h"
#include "Styling/Styles/SymbolStyle.h"
#include "Styling/Styles/TerrainConfigs.h"

namespace onyx::Styling
{

	void realize(Arguments const& args, Fog const& fog, FogStyle& style);

	void realize(Arguments const& args, BackgroundLayout const& l, BackgroundStyle& style);
	void realize(Arguments const& args, BackgroundPaint const& p, BackgroundStyle& style);
	void realize(Arguments const& args, BackgroundEffect const& e, BackgroundStyle& style);

	void realize(Arguments const& args, CircleLayout const& l, CircleStyle& style);
	void realize(Arguments const& args, CirclePaint const& p, CircleStyle& style);

	void realize(Arguments const& args, ContourLabelLayout const& l, ContourLabelConfig& config);
	void realize(Arguments const& args, ContourLabelPaint const& p, ContourLabelConfig& config);

	void realize(Arguments const& args, ContourLineLayout const& l, ContourLineConfig& config);
	void realize(Arguments const& args, ContourLinePaint const& p, ContourLineConfig& config);
	void realize(Arguments const& args, ContourLineEffect const& e, ContourLineConfig& config);

	void realize(Arguments const& args, ElevationLayout const& l, ElevationConfig& config);
	void realize(Arguments const& args, ElevationPaint const& p, ElevationConfig& config);
	void realize(Arguments const& args, ElevationEffect const& e, ElevationConfig& config);

	void realize(Arguments const& args, FillLayout const& l, FillStyle& style);
	void realize(Arguments const& args, FillPaint const& p, FillStyle& style);
	void realize(Arguments const& args, FillEffect const& e, FillStyle::Effect& effect);

	void realize(Arguments const& args, HillshadeLayout const& l, HillshadeConfig& config);
	void realize(Arguments const& args, HillshadePaint const& p, HillshadeConfig& config);
	void realize(Arguments const& args, HillshadeEffect const& e, HillshadeConfig& config);

	void realize(Arguments const& args, IntersectLayout const& l, IntersectConfig& config);
	void realize(Arguments const& args, IntersectPaint const& p, IntersectConfig& config);
	void realize(Arguments const& args, IntersectEffect const& e, IntersectConfig& config);

	void realize(Arguments const& args, LineLayout const& l, LineStyle& style);
	void realize(Arguments const& args, LinePaint const& p, LineStyle& style);
	void realize(Arguments const& args, LineEffect const& e, LineStyle::Effect& effect);

	void realize(Arguments const& args, RasterLayout const& l, RasterStyle& style);
	void realize(Arguments const& args, RasterPaint const& p, RasterStyle& style);
	void realize(Arguments const& args, RasterEffect const& e, RasterStyle& style);

	void realize(Arguments const& args, SlopeAngleLayout const& l, SlopeAngleConfig& config);
	void realize(Arguments const& args, SlopeAnglePaint const& p, SlopeAngleConfig& config);
	void realize(Arguments const& args, SlopeAngleEffect const& e, SlopeAngleConfig& config);

	void realize(Arguments const& args, SlopeAspectLayout const& l, SlopeAspectConfig& config);
	void realize(Arguments const& args, SlopeAspectPaint const& p, SlopeAspectConfig& config);
	void realize(Arguments const& args, SlopeAspectEffect const& e, SlopeAspectConfig& config);

	void realize(Arguments const& args, SunlightLayout const& l, SunlightConfig& config);
	void realize(Arguments const& args, SunlightPaint const& p, SunlightConfig& config);
	void realize(Arguments const& args, SunlightEffect const& e, SunlightConfig& config);

	void realize(Arguments const& args, SymbolLayout const& l, SymbolStyle& style);
	void realize(Arguments const& args, SymbolPaint const& p, SymbolStyle& style);

	void realize(Arguments const& args, TextLayoutComponent const& l, Text& text);
	void realize(Arguments const& args, TextPaintComponent const& p, Text& text);

	void realize(Arguments const& args, TextLayoutComponent const& l, TextStyle& style);
	void realize(Arguments const& args, TextPaintComponent const& p, TextStyle& style);

	void realize(Arguments const& args, ViewshedLayout const& l, ViewshedConfig& config);
	void realize(Arguments const& args, ViewshedPaint const& p, ViewshedConfig& config);
	void realize(Arguments const& args, ViewshedEffect const& e, ViewshedConfig& config);

}