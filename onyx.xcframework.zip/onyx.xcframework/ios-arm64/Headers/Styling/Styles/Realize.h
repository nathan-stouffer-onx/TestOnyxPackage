#pragma once

#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"
#include "Styling/Styles/BackgroundStyle.h"
#include "Styling/Styles/CircleStyle.h"
#include "Styling/Styles/ContourConfigs.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/FontStyle.h"
#include "Styling/Styles/IconStyle.h"
#include "Styling/Styles/LabelStyle.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/RasterStyle.h"
#include "Styling/Styles/ShadowConfigs.h"
#include "Styling/Styles/TerrainConfigs.h"

namespace onyx::Styling
{

	void realize(Arguments const& args, BackgroundLayout const& l, BackgroundStyle& style);
	void realize(Arguments const& args, BackgroundPaint const& p, BackgroundStyle& style);

	void realize(Arguments const& args, CircleLayout const& l, CircleStyle& style);
	void realize(Arguments const& args, CirclePaint const& p, CircleStyle& style);

	void realize(Arguments const& args, ContourLabelLayout const& l, ContourLabelConfig& config);

	void realize(Arguments const& args, ContourLineLayout const& l, ContourLineConfig& config);
	void realize(Arguments const& args, ContourLinePaint const& p, ContourLineConfig& config);

	void realize(Arguments const& args, FillLayout const& l, FillStyle& style);
	void realize(Arguments const& args, FillPaint const& p, FillStyle& style);

	// TODO (stouff) rename the realizeLayout/realizePaint functions when split styles into layout/paints
	// TODO (stouff) see if we can get rid of the templates and replace it with inheritance?
	
	template<typename LayoutT>
	void realizeLayout(Arguments const& args, LayoutT const& l, FontStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realizeLayout(args, *base, style);
		}

		// TODO (scott) This magic number is cribbed from font_manager.h; we'll need a way to expose
		// it to the stylesheet configuration at some point.
		// #define FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE  UINT32_C(0x00003900) // L8 + BGRA8
		auto textSize = style.font.pixelSize;
		if (l.textSize) textSize = (int32_t)l.textSize->evaluate(args.expressions);
		if (l.fontFace) style.font = FontFace{ l.fontFace->evaluate(args.expressions).front(), 0x00003900, textSize };
		
		// TODO (Ronald): One of the icon layout options relies on SymbolPlacement. This should move
		if (l.symbolPlacement) style.symbolPlacement = l.symbolPlacement->evaluate(args.expressions);

		if (l.textPlacement) style.textPlacement = l.textPlacement->evaluate(args.expressions);
		if (l.textStyleFlags) style.textStyle = l.textStyleFlags->evaluate(args.expressions);
		if (l.letterSpacing) style.kerningModifier = l.letterSpacing->evaluate(args.expressions);
	}
	template<typename PaintT>
	void realizePaint(Arguments const& args, PaintT const& p, FontStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realizePaint(args, *base, style);
		}

		if (p.color) style.textColor = p.color->evaluate(args.expressions);
		if (p.shadowColor) style.dropshadowColor = p.shadowColor->evaluate(args.expressions);
		if (p.haloColor) style.haloColor = p.haloColor->evaluate(args.expressions);
		if (p.strikethroughColor) style.strikethroughColor = p.strikethroughColor->evaluate(args.expressions);
		if (p.overlineColor) style.overlineColor = p.overlineColor->evaluate(args.expressions);
		if (p.underlineColor) style.underlineColor = p.underlineColor->evaluate(args.expressions);
		if (p.backgroundColor) style.backgroundColor = p.backgroundColor->evaluate(args.expressions);
	}

	template<typename LayoutT>
	void realizeLayout(Arguments const& args, LayoutT const& l, IconStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realizeLayout(args, *base, style);
		}

		if (l.iconImage != nullptr) style.iconImage = l.iconImage->evaluate(args.expressions);
		if (l.iconSize != nullptr) style.iconSize = l.iconSize->evaluate(args.expressions);
		// TODO (Ronald): This assumes that SymbolPlacement is Point for now
		if (l.iconRotAlignment != nullptr)
		{
			style.orientToVpXAxis = (l.iconRotAlignment->evaluate(args.expressions) == Alignment::Map) ? false : true;
		}
		if (l.iconPitchAlignment != nullptr)
		{
			auto alignOpt = l.iconPitchAlignment->evaluate(args.expressions);
			if (alignOpt == Alignment::Auto)
			{
				style.orientToVpPlane = style.orientToVpXAxis;
			}
			else
			{
				style.orientToVpPlane = (alignOpt == Alignment::Viewport) ? true : false;
			}
		}
		if (l.iconRotDeg != nullptr) style.iconRotDeg = l.iconRotDeg->evaluate(args.expressions);
	}
	template<typename PaintT>
	void realizePaint(Arguments const& args, PaintT const& p, IconStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realizePaint(args, *base, style);
		}
		
		if (p.iconColor != nullptr) style.iconColor = p.iconColor->evaluate(args.expressions);
	}

	template<typename LayoutT>
	inline void realizeLayout(Arguments const& args, LayoutT const& l, LabelStyle& style)
	{
		if (auto const& base = l.base(args.initArgs()))
		{
			realizeLayout(args, *base, style);
		}

		if (l.textField != nullptr) style.labelText = l.textField->evaluate(args.expressions);
	}
	template<typename PaintT>
	inline void realizePaint(Arguments const& args, PaintT const& p, LabelStyle& style)
	{
		if (auto const& base = p.base(args.initArgs()))
		{
			realizePaint(args, *base, style);
		}
	}

	void realize(Arguments const& args, LineLayout const& l, LineStyle& style);
	void realize(Arguments const& args, LinePaint const& p, LineStyle& style);

	void realize(Arguments const& args, ElevationLayout const& l, ElevationConfig& config);
	void realize(Arguments const& args, ElevationPaint const& p, ElevationConfig& config);

	void realize(Arguments const& args, RasterLayout const& l, RasterStyle& style);
	void realize(Arguments const& args, RasterPaint const& p, RasterStyle& style);

	void realize(Arguments const& args, SlopeAngleLayout const& l, SlopeAngleConfig& config);
	void realize(Arguments const& args, SlopeAnglePaint const& p, SlopeAngleConfig& config);

	void realize(Arguments const& args, SlopeAspectLayout const& l, SlopeAspectConfig& config);
	void realize(Arguments const& args, SlopeAspectPaint const& p, SlopeAspectConfig& config);

	void realize(Arguments const& args, ViewshedLayout const& l, ViewshedConfig& config);
	void realize(Arguments const& args, ViewshedPaint const& p, ViewshedConfig& config);

	void realize(Arguments const& args, SunlightLayout const& l, SunlightConfig& config);
	void realize(Arguments const& args, SunlightPaint const& p, SunlightConfig& config);

	void realize(Arguments const& args, IntersectLayout const& l, IntersectConfig& config);
	void realize(Arguments const& args, IntersectPaint const& p, IntersectConfig& config);

}