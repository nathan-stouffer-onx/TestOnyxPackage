#ifndef __STYLING_CIRCLE_STYLE_H__
#define __STYLING_CIRCLE_STYLE_H__

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>
#include <System/OnyxException.h>
#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Layers/Arguments.h"

namespace onyx {
namespace Styling {

	/*
	* Struct that stores values for all the available options for circle styling. The general idea is that the
	* expressions in a CircleLayer can be evaluated to produce this struct which can be encoded in a texture and 
	* style vectors on the gpu.
	*
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is
	* added to CircleStyle
	*/
	struct CircleStyle
	{

		float radius = 5.0f;
		uint32_t abgr = 0xFF000000;		// just use 32-bit color code because this struct pretty much goes straight to the gpu

		float strokeWidth = 0.0f;
		uint32_t strokeAbgr = 0xFF000000;

		// TODO maybe require a constructor so we don't accidentally miss a parameter? for now, it's nice to have the default values

	};

	inline bool operator==(CircleStyle const& lhs, CircleStyle const& rhs)
	{
		return lhs.radius == rhs.radius
			&& lhs.abgr == rhs.abgr
			&& lhs.strokeWidth == rhs.strokeWidth
			&& lhs.strokeAbgr == rhs.strokeAbgr;
	}

	inline bool operator!=(CircleStyle const& lhs, CircleStyle const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(CircleStyle const& lhs, CircleStyle const& rhs)
	{
		if (lhs.radius < rhs.radius) { return true; }
		if (lhs.radius > rhs.radius) { return false; }
		
		if (lhs.abgr < rhs.abgr) { return true; }
		if (lhs.abgr > rhs.abgr) { return false; }

		if (lhs.strokeWidth < rhs.strokeWidth) { return true; }
		if (lhs.strokeWidth > rhs.strokeWidth) { return false; }

		return lhs.strokeAbgr < rhs.strokeAbgr;
	}

	inline bool operator>(CircleStyle const& lhs, CircleStyle const& rhs)
	{
		return rhs < lhs;
	}

} }

namespace std
{

	template<>
	struct hash<onyx::Styling::CircleStyle>
	{

		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::CircleStyle const& style) const
		{
			size_t hash = 0;
			hash += std::hash<float>{}(style.radius) * 47;
			hash += style.abgr * 47;
			hash += std::hash<float>{}(style.strokeWidth) * 47;
			hash += style.strokeAbgr * 47;
			return hash;
		}

	};

}

#endif