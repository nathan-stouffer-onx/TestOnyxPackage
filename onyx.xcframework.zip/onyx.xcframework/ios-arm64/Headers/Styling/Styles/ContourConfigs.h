#ifndef __STYLING_CONTOUR_CONFIGS_H__
#define __STYLING_CONTOUR_CONFIGS_H__

#include <string>
#include <vector>

#include <lucid/gal/Types.h>
#include <lucid/math/Constants.h>

#include <Utils/EnumUtils.h>

namespace onyx {
namespace Styling {

	struct ContourConfig
	{

		enum class Units
		{
			METERS,
			FEET
		};

		Units units = Units::METERS;

		int period = 10;
		int skipPeriod = 0;

		int phase = 0;

		int min = lmath::constants::neg_inf<int>();
		int max = lmath::constants::pos_inf<int>();

		inline bool operator==(ContourConfig const& rhs) const
		{
			return units == rhs.units
				&& period == rhs.period
				&& skipPeriod == rhs.skipPeriod
				&& phase == rhs.phase
				&& min == rhs.min
				&& max == rhs.max;
		}

		inline bool operator!=(ContourConfig const& rhs) const
		{
			return !(*this == rhs);
		}

		bool contains(int elevation) const;

		std::vector<int> straddled(height_float_t const a, height_float_t const b) const;

		static inline float fromKm(Units to)
		{
			switch (to)
			{
				case Units::METERS:		return 1000.0f;		break;
				case Units::FEET:		return 3280.84f;	break;
				default:				return 1.f;
			}
		}

		static inline float toKm(Units from)
		{
			switch (from)
			{
				case Units::METERS:		return 0.001f;			break;
				case Units::FEET:		return 0.00030479999f;	break;
				default:				return 1.f;
			}
		}

	};

	struct ContourLabelConfig
	{

		ContourConfig contours;
		
		std::string suffix = "m";

		inline bool operator==(ContourLabelConfig const& rhs) const
		{
			return contours == rhs.contours
				&& suffix == rhs.suffix;
		}

		inline bool operator!=(ContourLabelConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

	struct ContourLineConfig
	{

		ContourConfig contours;

		uint32_t abgr = 0xFF000000;
		float width = 1.f;

		inline bool operator==(ContourLineConfig const& rhs) const
		{
			return contours == rhs.contours
				&& abgr == rhs.abgr
				&& width == rhs.width;
		}

		inline bool operator!=(ContourLineConfig const& rhs) const
		{
			return !(*this == rhs);
		}

	};

} }

namespace std
{

	inline std::string_view toStringView(onyx::Styling::ContourConfig::Units const units)
	{
		static std::unordered_map<onyx::Styling::ContourConfig::Units, std::string_view> const nameMap =
		{
			{ onyx::Styling::ContourConfig::Units::METERS,	"meters"	},
			{ onyx::Styling::ContourConfig::Units::FEET,	"feet"		},
		};
		return onyx::Utils::stringViewFromMap(units, nameMap, "enum Styling::ContourConfig::Units");
	}

	template<>
	inline onyx::Styling::ContourConfig::Units fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::ContourConfig::Units> const nameMap =
		{
			{ "meters",			onyx::Styling::ContourConfig::Units::METERS	},
			{ "feet",			onyx::Styling::ContourConfig::Units::FEET	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::ContourConfig::Units");
	}

}

#endif