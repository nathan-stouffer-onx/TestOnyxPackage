#pragma once

namespace onyx::Styling
{

	struct RasterStyle
	{

		float opacity;

	};

	inline bool operator==(RasterStyle const& lhs, RasterStyle const& rhs)
	{
		return lhs.opacity == rhs.opacity;
	}

	inline bool operator!=(RasterStyle const& lhs, RasterStyle const& rhs)
	{
		return !(lhs == rhs);
	}

}