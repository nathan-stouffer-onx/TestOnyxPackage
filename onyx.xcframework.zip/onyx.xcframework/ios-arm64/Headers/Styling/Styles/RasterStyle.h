#pragma once

#include "Styling/Enums.h"

namespace onyx::Styling
{

	struct RasterStyle
	{

		BlendMode blendMode = BlendMode::ALPHA;
		float opacity;

		inline auto tie() const
		{
			return std::tie(blendMode, opacity);
		}

	};

	inline bool operator==(RasterStyle const& lhs, RasterStyle const& rhs)
	{
		return lhs.tie() == rhs.tie();
	}

	inline bool operator!=(RasterStyle const& lhs, RasterStyle const& rhs)
	{
		return !(lhs == rhs);
	}

}