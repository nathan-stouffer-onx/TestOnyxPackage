#pragma once

#include <vector>

#include "Styling/Styles/IconStyle.h"
#include "Styling/Styles/TextStyle.h"

namespace onyx::Styling
{

	struct SymbolStyle
	{

		IconStyle icon;
		Text text;

		SymbolPlacement placement = SymbolPlacement::POINT;
		gpu_float_t spacing = 250.f;

	};

}