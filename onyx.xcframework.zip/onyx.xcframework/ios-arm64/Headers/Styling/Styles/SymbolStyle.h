#pragma once

#include <vector>

#include "Styling/Styles/IconStyle.h"
#include "Styling/Styles/TextStyle.h"

namespace onyx::Styling
{

	struct SymbolStyle
	{

		IconStyle icon;
		Text text;

		SymbolPlacement placement = SymbolPlacement::UNSPECIFIED;

	};

}