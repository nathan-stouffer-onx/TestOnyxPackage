#ifndef __STYLING_LINE_STYLE_H__
#define __STYLING_LINE_STYLE_H__

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>
#include <System/Map3DException.h>
#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {

	/*
	* Struct that stores a dash array on the cpu. The attribute DashArray::pattern stores the length of alternating
	* dashes and gaps. The lengths are scaled by LineStyle::width to compute the length in pixels
	* 
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is 
	* added to DashArray
	*/

	class DashArray
	{
	private:

		std::vector<float> mPattern = { 1.0f };

	public:

		static constexpr uint32_t cMaxLength = 16;	// NOTE: analogous constant in TileLineBase.json
		
		DashArray() = default;
		DashArray(std::vector<float> const& pat) { reset(pat); }

		inline std::vector<float> const& pattern() const { return mPattern; }

		void reset(std::vector<float> const& pat)
		{
			mPattern = pat;
			MAP3D_ASSERT(length() < cMaxLength, "DashArray exceeds max length");
		}

		// not the most efficient, but this isn't really called that often so I'm calling it good for now
		bool on(float x) const
		{
			// if there is not a dash pattern, default to always on
			if (mPattern.size() == 0)
			{
				return true;
			}

			float t = std::fmod(x, length());

			bool isOn = true;
			float total = mPattern[0];
			// values in DashArray::pattern alternate between on/off. iterate over the values
			// until we find the interval that contains t. then return whether that interval
			// was on or off
			for (size_t i = 1; i < mPattern.size(); i++)
			{
				if (t < total)
				{
					return isOn;
				}
				else
				{
					total += mPattern[i];
					isOn = !isOn;
				}
			}

			return isOn;
		}

		float length() const
		{
			float len = 0.f;
			for (float value : mPattern)
			{
				len += value;
			}
			return len;
		}

	};

	inline bool operator==(DashArray const& lhs, DashArray const& rhs)
	{
		// check if the patterns are different sizes
		if (lhs.pattern().size() != rhs.pattern().size())
		{
			return false;
		}

		// check for item inequality
		for (size_t i = 0; i < lhs.pattern().size(); i++)
		{
			if (lhs.pattern()[i] != rhs.pattern()[i])
			{
				return false;
			}
		}

		// passed all checks, return true
		return true;
	}

	inline bool operator!=(DashArray const& lhs, DashArray const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(DashArray const& lhs, DashArray const& rhs)
	{
		if (lhs.pattern().size() == rhs.pattern().size())
		{
			if (lhs.pattern().size() == 0) { return false; }
			else
			{
				size_t i = 0;
				for (; i < lhs.pattern().size() - 1; i++)
				{
					if (lhs.pattern()[i] < rhs.pattern()[i]) { return true; }
					if (lhs.pattern()[i] > rhs.pattern()[i]) { return false; }
				}

				return lhs.pattern()[i] < rhs.pattern()[i];
			}
		}
		else
		{
			return lhs.pattern().size() < rhs.pattern().size();
		}
	}

	inline bool operator>(DashArray const& lhs, DashArray const& rhs)
	{
		return rhs < lhs;
	}

	inline DashArray operator*(float scalar, DashArray const& dash)
	{
		std::vector<float> scaled;
		scaled.reserve(dash.pattern().size());

		for (float value : dash.pattern())
		{
			scaled.push_back(scalar * value);
		}

		return DashArray{ scaled };
	}

	/*
	* Struct that stores values for all the available options for line styling. The general idea is that the
	* expressions in a LineLayer can be evaluated to produce this struct which can be encoded in a texture and 
	* style vectors on the gpu.
	*
	* There are also convenience ==, !=, <, and hash operators. These functions must be updated if an attribute is
	* added to LineStyle
	*/

	struct LineStyle
	{

		enum class CapType : uint8_t
		{
			BUTT,
			ROUND,
			SQUARE
		};

		enum class JoinType : uint8_t
		{
			BEVEL,
			ROUND,
			MITER
		};

		uint32_t abgr = 0xFF000000;		// just use 32-bit color code because this struct pretty much goes straight to the gpu

		float width = 1.0f;

		JoinType joinType = JoinType::MITER;
		CapType capType = CapType::BUTT;

		DashArray dashArray;

		// TODO maybe require a constructor so we don't accidentally miss a parameter? for now, it's nice to have the default values

		void realizeLayout(Expressions::Arguments const& args, std::shared_ptr<LineLayout const>& l);
		void realizePaint(Expressions::Arguments const& args, std::shared_ptr<LinePaint const>& p);
	};

	inline bool operator==(LineStyle const& lhs, LineStyle const& rhs)
	{
		return lhs.abgr == rhs.abgr
			&& lhs.width == rhs.width
			&& lhs.joinType == rhs.joinType
			&& lhs.capType == rhs.capType
			&& lhs.dashArray == rhs.dashArray;
	}

	inline bool operator!=(LineStyle const& lhs, LineStyle const& rhs)
	{
		return !(lhs == rhs);
	}

	inline bool operator<(LineStyle const& lhs, LineStyle const& rhs)
	{
		if (lhs.abgr < rhs.abgr) { return true; }
		if (lhs.abgr > rhs.abgr) { return false; }

		if (lhs.width < rhs.width) { return true; }
		if (lhs.width > rhs.width) { return false; }

		if (lhs.joinType < rhs.joinType) { return true; }
		if (lhs.joinType > rhs.joinType) { return false; }

		if (lhs.capType < rhs.capType) { return true; }
		if (lhs.capType > rhs.capType) { return false; }

		return lhs.dashArray < rhs.dashArray;
	}

	inline bool operator>(LineStyle const& lhs, LineStyle const& rhs)
	{
		return rhs < lhs;
	}

} }

namespace std
{

	template<>
	struct hash<onyx::Styling::DashArray>
	{

		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::DashArray const& dash) const
		{
			std::hash<float> hasher;
			size_t hash = 0;
			for (float const length : dash.pattern())
			{
				hash += hasher(length) * 17;
			}
			return hash;
		}

	};

	template<>
	struct hash<onyx::Styling::LineStyle>
	{

		// TODO possibly update this to take advantage of 64-bit hashes
		inline size_t operator()(onyx::Styling::LineStyle const& style) const
		{
			size_t hash = 0;
			hash += style.abgr * 47;
			hash += std::hash<float>{}(style.width) * 47;
			hash += std::hash<uint8_t>{}((uint8_t)style.joinType) * 47;
			hash += std::hash<uint8_t>{}((uint8_t)style.capType) * 47;
			hash += std::hash<onyx::Styling::DashArray>{}(style.dashArray) * 47;
			return hash;
		}

	};

	template<>
	inline onyx::Styling::LineStyle::CapType fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::LineStyle::CapType> const nameMap =
		{
			{ "butt",						onyx::Styling::LineStyle::CapType::BUTT		},
			{ "round",						onyx::Styling::LineStyle::CapType::ROUND		},
			{ "square",						onyx::Styling::LineStyle::CapType::SQUARE		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::LineStyle::CapType");
	}

	inline std::string_view toStringView(onyx::Styling::LineStyle::CapType value)
	{
		static std::unordered_map<onyx::Styling::LineStyle::CapType, std::string_view> const nameMap =
		{
			{ onyx::Styling::LineStyle::CapType::BUTT,				"butt"		},
			{ onyx::Styling::LineStyle::CapType::ROUND,				"round"		},
			{ onyx::Styling::LineStyle::CapType::SQUARE,				"square"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::LineStyle::CapType");
	}

	template<>
	inline onyx::Styling::LineStyle::JoinType fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::LineStyle::JoinType> const nameMap =
		{
			{ "bevel",						onyx::Styling::LineStyle::JoinType::BEVEL		},
			{ "round",						onyx::Styling::LineStyle::JoinType::ROUND		},
			{ "miter",						onyx::Styling::LineStyle::JoinType::MITER		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::LineStyle::JoinType");
	}

	inline std::string_view toStringView(onyx::Styling::LineStyle::JoinType value)
	{
		static std::unordered_map<onyx::Styling::LineStyle::JoinType, std::string_view> const nameMap =
		{
			{ onyx::Styling::LineStyle::JoinType::BEVEL,				"bevel"		},
			{ onyx::Styling::LineStyle::JoinType::ROUND,				"round"		},
			{ onyx::Styling::LineStyle::JoinType::MITER,				"miter"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::LineStyle::JoinType");
	}

}

#endif