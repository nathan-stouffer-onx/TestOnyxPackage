#ifndef __STYLING_FORMATTED_H__
#define __STYLING_FORMATTED_H__

#include <memory>
#include <string>
#include <vector>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Styling {

	struct Formatted
	{

		struct Options
		{
			float fontScale = 1.f;
			std::unique_ptr<std::vector<std::string>> font = nullptr;
			std::unique_ptr<lgal::Color> color = nullptr;

			// custom copy constructor and copy assignment operator are necessary because we are using std::unique_ptr to
			// store whether font/color exist
			Options() = default;
			Options(float const _fontScale, std::unique_ptr<std::vector<std::string>> _font, std::unique_ptr<lgal::Color> _color) :
				fontScale(_fontScale), font(std::move(_font)), color(std::move(_color)) {}
			Options(Options const& rhs) : fontScale(rhs.fontScale)
			{
				font = (rhs.font) ? std::make_unique<std::vector<std::string>>(*rhs.font) : nullptr;
				color = (rhs.color) ? std::make_unique<lgal::Color>(*rhs.color) : nullptr;
			}
			Options& operator=(Options const& rhs)
			{
				fontScale = rhs.fontScale;
				font = (rhs.font) ? std::make_unique<std::vector<std::string>>(*rhs.font) : nullptr;
				color = (rhs.color) ? std::make_unique<lgal::Color>(*rhs.color) : nullptr;
				return *this;
			}

			inline bool operator==(Options const& rhs) const
			{
				return fontScale == rhs.fontScale
					&& (font == rhs.font || (font && rhs.font && (*font == *rhs.font)))
					&& (color == rhs.color || (color && rhs.color && (*color == *rhs.color)));
			}

			inline bool operator!=(Options const& rhs) const
			{
				return !(*this == rhs);
			}

		};

		struct Segment
		{
			std::string text = "";
			Options options;

			Segment() = default;
			Segment(std::string const& _text) : Segment(_text, {}) {}
			Segment(std::string const& _text, Options&& _options) : text(_text), options(std::move(_options)) {}

			inline bool operator==(Segment const& rhs) const
			{
				return text == rhs.text && options == rhs.options;
			}

			inline bool operator!=(Segment const& rhs) const
			{
				return !(*this == rhs);
			}
		};

		std::vector<Segment> segments;

		Formatted() : Formatted("") {}
		explicit Formatted(std::string const& input) : Formatted(std::vector<Segment>{ Segment(input) }) {}
		Formatted(std::vector<Segment>&& _segments) : segments(std::move(_segments)) {}

		size_t length() const
		{
			size_t len = 0;
			for (Segment const& seg : segments)
			{
				len += seg.text.length();
			}
			return len;
		}

		inline bool isEmpty() const
		{
			static Formatted empty("");
			return segments.empty() || *this == empty;
		}

		inline bool operator==(Formatted const& rhs) const
		{
			if (segments.size() != rhs.segments.size())
			{
				return false;
			}

			for (size_t i = 0; i < segments.size(); ++i)
			{
				if (segments[i] != rhs.segments[i])
				{
					return false;
				}
			}
			
			// passed all tests, return true
			return true;
		}

		inline bool operator!=(Formatted const& rhs) const
		{
			return !(*this == rhs);
		}
	};

} }

#endif