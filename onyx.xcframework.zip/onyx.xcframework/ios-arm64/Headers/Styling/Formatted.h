#pragma once

#include <memory>
#include <string>
#include <vector>

#include <lucid/gal/Types.h>
#include <Utils/StringUtils.h>

namespace onyx::Styling
{

class Formatted
{
public:

	struct Options
	{
		float fontScale = 1.f;
		std::unique_ptr<std::vector<std::string>> font = nullptr;
		std::unique_ptr<lgal::Color> color = nullptr;

		// custom copy constructor and copy assignment operator are necessary because we are using std::unique_ptr to
		// store whether font/color exist
		Options() = default;
		Options(float const _fontScale, std::unique_ptr<std::vector<std::string>> _font, std::unique_ptr<lgal::Color> _color) :fontScale(_fontScale), font(std::move(_font)), color(std::move(_color)) {}
		Options(Options const& rhs) : fontScale(rhs.fontScale)
		{
			font = (rhs.font) ? std::make_unique<std::vector<std::string>>(*rhs.font) : nullptr;
			color = (rhs.color) ? std::make_unique<lgal::Color>(*rhs.color) : nullptr;
		}
		Options& operator=(Options const& rhs)
		{
			fontScale = rhs.fontScale;
			font = (rhs.font) ? std::make_unique<std::vector<std::string>>(*rhs.font) : nullptr;
			color = (rhs.color) ? std::make_unique<lgal::Color>(*rhs.color) : nullptr;
			return *this;
		}

		inline bool operator==(Options const& rhs) const
		{
			return fontScale == rhs.fontScale
				&& (font == rhs.font || (font && rhs.font && (*font == *rhs.font)))
				&& (color == rhs.color || (color && rhs.color && (*color == *rhs.color)));
		}

		inline bool operator!=(Options const& rhs) const
		{
			return !(*this == rhs);
		}

	};

	struct InputSegment
	{
		uint32_t bIdx, size;
		Options options;
	};

	class Segment
	{
	
	public:

		Segment() = default;
		explicit Segment(std::string_view const& _text) : Segment(_text, {}) {}
		explicit Segment(std::string_view const& _text, Options&& _options) : mText(_text), mOptions(std::move(_options)) {}

		inline bool operator==(Segment const& rhs) const
		{
			return mText == rhs.mText && mOptions == rhs.mOptions;
		}

		inline bool operator!=(Segment const& rhs) const { return !(*this == rhs); }

		inline std::string_view const& getText() const { return mText; }
		inline void setText(std::string_view const& view) { mText = view; }

		inline Options const& getOptions() const { return mOptions; }
		inline void setOptions(Options const& options) { mOptions = options; }

	private:

		std::string_view mText = "";
		Options mOptions;

	};
	
public:

	Formatted() : Formatted("") {}
	Formatted(std::string const& input) : mFullText(input) 
	{
		if (!input.empty()) { mSegments.push_back({ Segment{std::string_view(mFullText)} }); }
	}
	Formatted(std::string const& input, std::vector<InputSegment>&& _segments);
	Formatted(Formatted const& rhs);
	Formatted& operator=(Formatted const& rhs);
	
	inline std::vector<Segment> const& getSegments() const { return mSegments; }

	inline std::string const& getFullText() const { return mFullText; }

	inline size_t strLength() const { return mFullText.length(); }

	inline bool isEmpty() const { return mFullText.empty(); }

	bool operator==(Formatted const& rhs) const;

	inline bool operator!=(Formatted const& rhs) const { return !(*this == rhs); }

	Formatted operator+(Formatted const& rhs) const;

	inline void toUppercase() { Utils::toUpperInPlace(mFullText); }
	inline void toLowercase() { Utils::toLowerInPlace(mFullText); }

private:
	
	std::vector<Segment> mSegments;
	std::string mFullText = "";

	// Adds a segment. No-op if InputSegment text is empty. Will expand the previous segment's view instead if the input segment's options and the previous segments options are the same. Make sure that mFullText is properly set before using this.
	void addSegment(InputSegment&& inputS);

	// Appends a vector of segments. Make sure that mFullText is properly updated before using this.
	void addSegments(std::vector<Segment> const& segments);

};

}