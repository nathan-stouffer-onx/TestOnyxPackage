#ifndef __SPRITE_H__
#define __SPRITE_H__

#include <string>
#include <vector>
#include <lucid/gal/Types.h>

namespace onyx {
namespace Styling {

struct SpriteIndex
{
	// Required index data
	std::string name = "";
	uint32_t width = 0;
	uint32_t height = 0;
	uint32_t x = 0;
	uint32_t y = 0;
	float pixelRatio = 1;
	
	lgal::array::AABB2d content = lgal::array::AABB2d::nothing();
	std::vector<lgal::array::Vector2> stretchX;
	std::vector<lgal::array::Vector2> stretchY;
};

struct Sprite
{
	std::string name = "";
	std::vector<SpriteIndex> indices;

	// TODO (Ronald): add max icon resolution metadata

	bool isEmpty() const { return name == ""; }
};

} }

#endif