#pragma once

#include <cstdint>

#include <Utils/BitwiseEnumOperators.h>
#include <Utils/EnumUtils.h>

namespace onyx::Styling {

	enum class Alignment
	{
		Auto,
		Map,
		Viewport
	};

	enum class Justify
	{
		AUTO = 0,
		LEFT = 1,
		CENTER = 2,
		RIGHT = 3
	};

	enum class TextFitOpts : uint32_t
	{
		None = 0x0,
		Width = 0x1,
		Height = 0x2,
		Both = Width | Height
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(TextFitOpts);

	enum class Transform
	{
		NONE = 0,
		UPPERCASE,
		LOWERCASE
	};

	enum class SymbolPlacement : uint32_t
	{
		UNSPECIFIED = 0,
		POINT = 1,
		LINE = 2,
		LINE_CENTER = 3,
		LINE_JUSTIFY = 4,
	};

	enum class Anchor : uint32_t
	{
		CENTER = 0x0,
		VERTICAL_CENTER = 0x0,
		HORIZONTAL_CENTER = 0x0,
		BELOW = 0x1,	// above/below are mutually exclusive; either one will override VERTICAL_CENTER
		ABOVE = 0x2,
		LEFT = 0x4,	// left/right are mutually exclusive; either will override HORIZONTAL_CENTER
		RIGHT = 0x8,
		DEFAULT = 0x0,
		TOP_LEFT = ABOVE | LEFT,
		TOP_RIGHT = ABOVE | RIGHT,
		BOTTOM_LEFT = BELOW | LEFT,
		BOTTOM_RIGHT = BELOW | RIGHT,
		VERTICAL_FLAGS = BELOW | ABOVE,
		HORIZONTAL_FLAGS = RIGHT | LEFT,
		UNSPECIFIED = 0xFFFFFFFF
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(Anchor);

	/// special style effect (can be combined)
	enum class TextStyleFlags : uint32_t
	{
		NORMAL			= 0x0,
		OVERLINE		= 0x1,
		UNDERLINE		= 0x2,
		STRIKE_THROUGH	= 0x4,
		BACKGROUND		= 0x8,
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(TextStyleFlags);

	enum class TranslateAnchor
	{
		MAP,
		VIEWPORT
	};

}

namespace std {

	template<>
	inline onyx::Styling::TextFitOpts fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::TextFitOpts> const nameMap =
		{
			{ "both",						onyx::Styling::TextFitOpts::Both	},
			{ "height",						onyx::Styling::TextFitOpts::Height	},
			{ "width",						onyx::Styling::TextFitOpts::Width	},
			{ "none",						onyx::Styling::TextFitOpts::None	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::SymbolLayout::TextFitOpts");
	}

	inline std::string_view toStringView(onyx::Styling::TextFitOpts value)
	{
		static std::unordered_map<onyx::Styling::TextFitOpts, std::string_view> const nameMap =
		{
			{ onyx::Styling::TextFitOpts::Both,				"both"		},
			{ onyx::Styling::TextFitOpts::Height,			"height"	},
			{ onyx::Styling::TextFitOpts::Width,			"width"		},
			{ onyx::Styling::TextFitOpts::None,				"none"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::SymbolLayout::TextFitOpts");
	}

	template<>
	inline onyx::Styling::SymbolPlacement fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::SymbolPlacement> const nameMap =
		{
			{ "unspecified",				onyx::Styling::SymbolPlacement::UNSPECIFIED		},
			{ "point",						onyx::Styling::SymbolPlacement::POINT			},
			{ "line",						onyx::Styling::SymbolPlacement::LINE			},
			{ "line-center",				onyx::Styling::SymbolPlacement::LINE_CENTER		},
			{ "line-justify",				onyx::Styling::SymbolPlacement::LINE_JUSTIFY	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::SymbolPlacement");
	}

	inline std::string_view toStringView(onyx::Styling::SymbolPlacement value)
	{
		static std::unordered_map<onyx::Styling::SymbolPlacement, std::string_view> const nameMap =
		{
			{ onyx::Styling::SymbolPlacement::UNSPECIFIED,			"unspecified"	},
			{ onyx::Styling::SymbolPlacement::POINT,				"point"			},
			{ onyx::Styling::SymbolPlacement::LINE,					"line"			},
			{ onyx::Styling::SymbolPlacement::LINE_CENTER,			"line-center"	},
			{ onyx::Styling::SymbolPlacement::LINE_JUSTIFY,			"line-justify"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::SymbolPlacement");
	}

	template<>
	inline onyx::Styling::TextStyleFlags fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::TextStyleFlags> const nameMap =
		{
			{ "normal",						onyx::Styling::TextStyleFlags::NORMAL				},
			{ "overline",					onyx::Styling::TextStyleFlags::OVERLINE			},
			{ "underline",					onyx::Styling::TextStyleFlags::UNDERLINE			},
			{ "strikethrough",				onyx::Styling::TextStyleFlags::STRIKE_THROUGH		},
			{ "background",					onyx::Styling::TextStyleFlags::BACKGROUND			},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::TextStyleFlags");
	}

	inline std::string_view toStringView(onyx::Styling::TextStyleFlags value)
	{
		static std::unordered_map<onyx::Styling::TextStyleFlags, std::string_view> const nameMap =
		{
			{ onyx::Styling::TextStyleFlags::NORMAL,						"normal"		},
			{ onyx::Styling::TextStyleFlags::OVERLINE,						"overline"		},
			{ onyx::Styling::TextStyleFlags::UNDERLINE,						"underline"		},
			{ onyx::Styling::TextStyleFlags::STRIKE_THROUGH,				"strikethrough"	},
			{ onyx::Styling::TextStyleFlags::BACKGROUND,					"background"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::TextStyleFlags");
	}

	template<>
	inline onyx::Styling::Anchor fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Anchor> const nameMap =
		{
			{ "unspecified",				onyx::Styling::Anchor::UNSPECIFIED		},
			{ "center",						onyx::Styling::Anchor::CENTER			},
			{ "left",						onyx::Styling::Anchor::LEFT				},
			{ "right",						onyx::Styling::Anchor::RIGHT			},
			{ "top",						onyx::Styling::Anchor::ABOVE			},
			{ "bottom",						onyx::Styling::Anchor::BELOW			},
			{ "top-left",					onyx::Styling::Anchor::TOP_LEFT			},
			{ "top-right",					onyx::Styling::Anchor::TOP_RIGHT		},
			{ "bottom-left",				onyx::Styling::Anchor::BOTTOM_LEFT		},
			{ "bottom-right",				onyx::Styling::Anchor::BOTTOM_RIGHT		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Anchor");
	}

	inline std::string_view toStringView(onyx::Styling::Anchor value)
	{
		static std::unordered_map<onyx::Styling::Anchor, std::string_view> const nameMap =
		{
			{ onyx::Styling::Anchor::UNSPECIFIED,						"unspecified"	},
			{ onyx::Styling::Anchor::HORIZONTAL_CENTER,					"center"		},
			{ onyx::Styling::Anchor::LEFT,								"left"			},
			{ onyx::Styling::Anchor::RIGHT,								"right"			},
			{ onyx::Styling::Anchor::ABOVE,								"top"			},
			{ onyx::Styling::Anchor::BELOW,								"bottom"		},
			{ onyx::Styling::Anchor::TOP_LEFT,							"top-left"		},
			{ onyx::Styling::Anchor::TOP_RIGHT,							"top-right"		},
			{ onyx::Styling::Anchor::BOTTOM_LEFT,						"bottom-left"	},
			{ onyx::Styling::Anchor::BOTTOM_RIGHT,						"bottom-right"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Anchor");
	}

	template<>
	inline onyx::Styling::Alignment fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Alignment> const nameMap =
		{
			{ "auto",						onyx::Styling::Alignment::Auto		},
			{ "map",						onyx::Styling::Alignment::Map		},
			{ "viewport",					onyx::Styling::Alignment::Viewport	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Alignment");
	}

	inline std::string_view toStringView(onyx::Styling::Alignment value)
	{
		static std::unordered_map<onyx::Styling::Alignment, std::string_view> const nameMap =
		{
			{ onyx::Styling::Alignment::Auto,			"auto"		},
			{ onyx::Styling::Alignment::Map,			"map"		},
			{ onyx::Styling::Alignment::Viewport,		"viewport"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Alignment");
	}

	template<>
	inline onyx::Styling::Justify fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Justify> const nameMap =
		{
			{ "auto",						onyx::Styling::Justify::AUTO	},
			{ "left",						onyx::Styling::Justify::LEFT	},
			{ "center",						onyx::Styling::Justify::CENTER	},
			{ "right",						onyx::Styling::Justify::RIGHT	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Justify");
	}

	template<>
	inline onyx::Styling::Transform fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Transform> const nameMap =
		{
			{ "none",						onyx::Styling::Transform::NONE		},
			{ "uppercase",					onyx::Styling::Transform::UPPERCASE	},
			{ "lowercase",					onyx::Styling::Transform::LOWERCASE	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Transform");
	}

	template<>
	inline onyx::Styling::TranslateAnchor fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::TranslateAnchor> const nameMap =
		{
			{ "map",						onyx::Styling::TranslateAnchor::MAP			},
			{ "viewport",					onyx::Styling::TranslateAnchor::VIEWPORT	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::TranslateAnchor");
	}

}

namespace onyx::Utils {

	// I'd love to find a less manual way of tagging enums as "convert this using flags",
	// but this works pretty slick when it's all set up.  Considered making it part of the
	// BitwiseEnumOperators macro but the namespaces make it tricky.
	template<>
	struct EnumStringConverter<Styling::TextFitOpts>
	{
		static Styling::TextFitOpts convert(std::string_view const& view) {
			return Utils::flagsEnumTypeFromString<Styling::TextFitOpts>(view);
		}
	};

	template<>
	struct EnumStringConverter<Styling::TextStyleFlags>
	{
		static Styling::TextStyleFlags convert(std::string_view const& view) {
			return Utils::flagsEnumTypeFromString<Styling::TextStyleFlags>(view);
		}
	};

	template<>
	struct EnumStringConverter<Styling::Anchor>
	{
		static Styling::Anchor convert(std::string_view const& view) {
			return Utils::flagsEnumTypeFromString<Styling::Anchor>(view);
		}
	};

}

