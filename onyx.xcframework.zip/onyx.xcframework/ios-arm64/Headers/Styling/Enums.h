#ifndef __STYLE_ENUMS_H__
#define __STYLE_ENUMS_H__

#include <cstdint>

namespace onyx {
namespace Styling {

enum class Placement : uint32_t
{
	VERTICAL_CENTER = 0x0,
	HORIZONTAL_CENTER = 0x0,
	BELOW = 0x1,	// above/below are mutually exclusive; either one will override VERTICAL_CENTER
	ABOVE = 0x2,
	LEFT = 0x4,	// left/right are mutually exclusive; either will override HORIZONTAL_CENTER
	RIGHT = 0x8,
	DEFAULT = 0x0,
	TOP_LEFT = ABOVE | LEFT,
	TOP_RIGHT = ABOVE | RIGHT,
	BOTTOM_LEFT = BELOW | LEFT,
	BOTTOM_RIGHT = BELOW | RIGHT,
	VERTICAL_FLAGS = BELOW | ABOVE,
	HORIZONTAL_FLAGS = RIGHT | LEFT,
	UNSPECIFIED = 0xFFFFFFFF
};

/// special style effect (can be combined)
enum class TextStyleFlags : uint32_t
{
	NORMAL			= 0x0,
	OVERLINE		= 0x1,
	UNDERLINE		= 0x2,
	STRIKE_THROUGH	= 0x4,
	BACKGROUND		= 0x8,
};

} }

#endif