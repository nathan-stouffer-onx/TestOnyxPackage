#ifndef __STYLING_SOURCE_OPERATORS_H__
#define __STYLING_SOURCE_OPERATORS_H__

#include "Source.h"
#include "TiledSources/RasterSource.h"
#include "TiledSources/RasterDemSource.h"
#include "TiledSources/VectorSource.h"
#include "GeojsonSource.h"

namespace onyx {
namespace Styling {

	inline bool operator==(Source const& lhs, Source const& rhs)
	{
		if (lhs.type == rhs.type)
		{
			switch (lhs.type)
			{
				case Source::Types::UNKNOWN:    return false;                                                                                                       break;
				case Source::Types::RASTER:     return RasterSource::equals(static_cast<RasterSource const&>(lhs),       static_cast<RasterSource const&>(rhs));    break;
				case Source::Types::RASTER_DEM: return RasterDemSource::equals(static_cast<RasterDemSource const&>(lhs), static_cast<RasterDemSource const&>(rhs)); break;
				case Source::Types::VECTOR:     return VectorSource::equals(static_cast<VectorSource const&>(lhs),       static_cast<VectorSource const&>(rhs));    break;
				case Source::Types::GEOJSON:
				default:                       return false;
			}
		}
		else
		{
			return false;
		}
	}

	inline bool operator!=(Source const& lhs, Source const& rhs)
	{
		return !(lhs == rhs);
	}

} }

#endif