#ifndef __STYLING_SOURCE_OPERATORS_H__
#define __STYLING_SOURCE_OPERATORS_H__

#include <System/Map3DException.h>

#include "Source.h"
#include "TiledSources/RasterSource.h"
#include "TiledSources/RasterDemSource.h"
#include "TiledSources/VectorSource.h"
#include "GeojsonSource.h"

namespace onyx {
namespace Styling {

	inline bool operator==(Source const& lhs, Source const& rhs)
	{
		if (lhs.type == rhs.type)
		{
			switch (lhs.type)
			{
				case Source::Type::UNKNOWN:    return false;                                                                                                       break;
				case Source::Type::RASTER:     return RasterSource::equals(static_cast<RasterSource const&>(lhs),       static_cast<RasterSource const&>(rhs));    break;
				case Source::Type::RASTER_DEM: return RasterDemSource::equals(static_cast<RasterDemSource const&>(lhs), static_cast<RasterDemSource const&>(rhs)); break;
				case Source::Type::VECTOR:     return VectorSource::equals(static_cast<VectorSource const&>(lhs),       static_cast<VectorSource const&>(rhs));    break;
				case Source::Type::GEOJSON:
				default:                       MAP3D_THROW("Cannot equate Source::Type::" + std::string(std::toStringView(lhs.type)))                                                                               break;
			}
		}
		else
		{
			return false;
		}
	}

	inline bool operator!=(Source const& lhs, Source const& rhs)
	{
		return !(lhs == rhs);
	}

} }

#endif