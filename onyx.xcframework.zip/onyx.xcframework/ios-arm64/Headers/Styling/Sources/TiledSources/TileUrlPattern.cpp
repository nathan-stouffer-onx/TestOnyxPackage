#include "TileUrlPattern.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Styling {

	std::string TileUrlPattern::ParseBase(std::string const& pattern)
	{
		auto chop = pattern.find("{z}");
		ONYX_ASSERT(chop != std::string::npos, "TileUrlPattern " + pattern + " must contain {z}");
		std::string base = pattern.substr(0, chop);
		return base;
	}

	std::string TileUrlPattern::ParsePostZ(std::string const& pattern)
	{
		auto begChop = pattern.find("{z}") + 3;		// add three to bypass {z}
		auto endChop = pattern.find("{x}");
		ONYX_ASSERT(begChop != std::string::npos, "TileUrlPattern " + pattern + " must contain {z}");
		ONYX_ASSERT(endChop != std::string::npos, "TileUrlPattern " + pattern + " must contain {x}");
		std::string postZ = pattern.substr(begChop, endChop - begChop);
		return postZ;
	}

	std::string TileUrlPattern::ParsePostX(std::string const& pattern)
	{
		auto begChop = pattern.find("{x}") + 3;	// add three to bypass {x}
		auto endChop = pattern.find("{y}");
		ONYX_ASSERT(begChop != std::string::npos, "TileUrlPattern " + pattern + " must contain {x}");
		ONYX_ASSERT(endChop != std::string::npos, "TileUrlPattern " + pattern + " must contain {y}");
		std::string postX = pattern.substr(begChop, endChop - begChop);
		return postX;
	}

	std::string TileUrlPattern::ParsePostY(std::string const& pattern)
	{
		auto chop = pattern.find("{y}") + 3;		// add three to bypass {y}
		ONYX_ASSERT(chop != std::string::npos, "TileUrlPattern " + pattern + " must contain {y}");
		std::string ext = pattern.substr(chop);
		return ext;
	}

	TileUrlPattern::TileUrlPattern(std::string const& pattern) :
		base(TileUrlPattern::ParseBase(pattern)),
		postZ(TileUrlPattern::ParsePostZ(pattern)),
		postX(TileUrlPattern::ParsePostX(pattern)),
		postY(TileUrlPattern::ParsePostY(pattern))
	{}

	std::string TileUrlPattern::pattern() const
	{
		return base + "{z}" + postZ + "{x}" + postX + "{y}" + postY;
	}

	std::string TileUrlPattern::url(int z, int x, int y) const
	{
		return base + std::to_string(z) + postZ + std::to_string(x) + postX + std::to_string(y) + postY;
	}

} }