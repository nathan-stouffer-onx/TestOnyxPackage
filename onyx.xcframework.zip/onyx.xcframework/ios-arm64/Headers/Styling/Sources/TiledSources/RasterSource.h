#ifndef __STYLING_RASTER_SOURCE_H__
#define __STYLING_RASTER_SOURCE_H__

#include "TiledSource.h"

namespace onyx {
namespace Styling {

	struct RasterSource : public TiledSource
	{

		uint32_t tileSize = 512;		// NOTE: currently following mapbox by defaulting to 512. maybe switch to 256 sometime?

		RasterSource() : TiledSource(Type::RASTER) {}
		RasterSource(Type t) : TiledSource(t) {}

		virtual ~RasterSource() = default;

		static inline bool equals(RasterSource const& lhs, RasterSource const& rhs)
		{
			return TiledSource::equals(lhs, rhs)
				&& lhs.tileSize == rhs.tileSize;
		}

	};

} }

#endif