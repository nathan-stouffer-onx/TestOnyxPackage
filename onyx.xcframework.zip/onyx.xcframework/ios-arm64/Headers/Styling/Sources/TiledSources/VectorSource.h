#ifndef __STYLING_VECTOR_SOURCE_H__
#define __STYLING_VECTOR_SOURCE_H__

#include "TiledSource.h"

namespace onyx {
namespace Styling {

	struct VectorSource final : public TiledSource
	{

		std::string promoteId = "";

		VectorSource() : TiledSource(Type::VECTOR) {}

		static inline bool equals(VectorSource const& lhs, VectorSource const& rhs)
		{
			return TiledSource::equals(lhs, rhs)
				&& lhs.promoteId == rhs.promoteId;
		}

	};

} }

#endif