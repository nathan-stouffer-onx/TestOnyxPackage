#ifndef __STYLING_TILED_SOURCE_H__
#define __STYLING_TILED_SOURCE_H__

#include <lucid/gal/Types.h>

#include "Styling/Sources/Source.h"
#include "Styling/Sources/TiledSources/TileUrlPattern.h"

namespace onyx {
namespace Styling {

	struct TiledSource : public Source
	{

		enum class Scheme
		{
			XYZ,
			TMS
		};

		Scheme scheme = Scheme::XYZ;

		std::vector<TileUrlPattern> tiles = { TileUrlPattern() };

		// analogue of "volatile" in stylesheets -- volatile is a C++ keyword
		bool cache = true;

		TiledSource() = default;
		TiledSource(Source::Types t) : Source(t) {}

		virtual ~TiledSource() = default;

		// returns a random value of tiles to use as the TileUrlPattern
		TileUrlPattern const& pattern() const;

	protected:

		static inline bool equals(TiledSource const& lhs, TiledSource const& rhs)
		{
			return Source::equals(lhs, rhs)
				&& lhs.scheme == rhs.scheme
				&& lhs.tiles == rhs.tiles
				&& lhs.cache == rhs.cache
				&& lhs.expirationMS == rhs.expirationMS;
		}

	};

} }

namespace std
{

	template<>
	inline onyx::Styling::TiledSource::Scheme fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::TiledSource::Scheme> const nameMap =
		{
			{ "xyz", onyx::Styling::TiledSource::Scheme::XYZ },
			{ "tms", onyx::Styling::TiledSource::Scheme::TMS },
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::TiledSource::Scheme");
	}

	inline std::string_view toStringView(onyx::Styling::TiledSource::Scheme value)
	{
		static std::unordered_map<onyx::Styling::TiledSource::Scheme, std::string_view> const nameMap =
		{
			{ onyx::Styling::TiledSource::Scheme::XYZ,	"xyz" },
			{ onyx::Styling::TiledSource::Scheme::TMS,	"tms" },
		};

		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::TiledSource::Encoding");
	}

}

#endif