#ifndef __STYLING_RASTER_DEM_SOURCE_H__
#define __STYLING_RASTER_DEM_SOURCE_H__

#include "RasterSource.h"
#include "TileUrlPattern.h"

namespace onyx {
namespace Styling {

	struct RasterDemSource final : public RasterSource
	{

		enum class Encoding
		{
			UNKNOWN,
			TERRARIUM,
			MAPBOX,
			TINY_DEM
		};

		Encoding encoding = Encoding::UNKNOWN;		// NOTE: differs from mapbox default

		RasterDemSource() : RasterSource(Type::RASTER_DEM) {}

		static inline bool equals(RasterDemSource const& lhs, RasterDemSource const& rhs)
		{
			return RasterSource::equals(lhs, rhs)
				&& lhs.encoding == rhs.encoding;
		}

		static inline size_t PaddedLength(Encoding encoding)
		{
			switch (encoding)
			{
				case Encoding::TERRARIUM:	return 256; break;
				case Encoding::MAPBOX:		return 514; break;
				case Encoding::TINY_DEM:	return 514; break;
				default:					return 0;
			}
		}

		static inline size_t Padding(Encoding encoding)
		{
			switch (encoding)
			{
				case Encoding::TERRARIUM:	return 0; break;
				case Encoding::MAPBOX:		return 1; break;
				case Encoding::TINY_DEM:	return 1; break;
				default:					return 0;
			}
		}

		static inline size_t Length(Encoding encoding)
		{
			return PaddedLength(encoding) - Padding(encoding) - Padding(encoding);
		}

	};

} }


namespace std
{

	template<>
	inline onyx::Styling::RasterDemSource::Encoding fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::RasterDemSource::Encoding> const nameMap =
		{
			{ "unknown",				onyx::Styling::RasterDemSource::Encoding::UNKNOWN		},
			{ "terrarium",				onyx::Styling::RasterDemSource::Encoding::TERRARIUM	},
			{ "mapbox",					onyx::Styling::RasterDemSource::Encoding::MAPBOX		},
			{ "tiny-dem",				onyx::Styling::RasterDemSource::Encoding::TINY_DEM	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::RasterDemSource::Encoding");
	}

	inline std::string_view toStringView(onyx::Styling::RasterDemSource::Encoding value)
	{
		static std::unordered_map<onyx::Styling::RasterDemSource::Encoding, std::string_view> const nameMap =
		{
			{ onyx::Styling::RasterDemSource::Encoding::UNKNOWN,					"unknown"	},
			{ onyx::Styling::RasterDemSource::Encoding::TERRARIUM,				"terrarium"	},
			{ onyx::Styling::RasterDemSource::Encoding::MAPBOX,					"mapbox"	},
			{ onyx::Styling::RasterDemSource::Encoding::TINY_DEM,					"tiny-dem"	},
		};

		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::RasterDemSource::Encoding");
	}

}
#endif