#include "TiledSource.h"

#include <random>

#include <json/jsonParsing.h>

using namespace lucid::gal;

namespace onyx {
namespace Styling {

	TileUrlPattern const& TiledSource::pattern() const
	{
		size_t size = tiles.size();
		if (size == 1)
		{
			return tiles[0];
		}
		else
		{
			return tiles[rand() % size];
		}
	}

} }