#ifndef __STYLING_TILE_URL_PATTERN_H__
#define __STYLING_TILE_URL_PATTERN_H__

#include <string>
#include <vector>

namespace onyx {
namespace Styling {

	/*
	* A struct to represent a pattern for a url that the viewer can use to request tiled data. TileUrlPattern constructs
	* the pattern from the string passed in the constructor. It expects to find '{z}', '{x}', and '{y}' as substrings in
	* the value passed in to the constructor.
	*/

	struct TileUrlPattern
	{
		std::string const base;
		std::string const postZ;
		std::string const postX;
		std::string const postY;

		TileUrlPattern() = default;
		TileUrlPattern(std::string const& pattern);

		std::string pattern() const;

		// NOTE: using ints because TileId uses ints -- this way we don't have to cast
		std::string url(int z, int x, int y) const;

		inline bool operator==(TileUrlPattern const& rhs) const
		{
			return base == rhs.base
				&& postZ == rhs.postZ
				&& postX == rhs.postX
				&& postY == rhs.postY;
		}

		inline bool operator!=(TileUrlPattern const& rhs) const
		{
			return !(*this == rhs);
		}

		static std::string ParseBase(std::string const& pattern);
		static std::string ParsePostZ(std::string const& pattern);
		static std::string ParsePostX(std::string const& pattern);
		static std::string ParsePostY(std::string const& pattern);

	};

	inline bool operator==(std::vector<TileUrlPattern> const& lhs, std::vector<TileUrlPattern> const& rhs)
	{
		if (lhs.size() == rhs.size())
		{
			for (size_t i = 0; i < lhs.size(); i++)
			{
				if (lhs[i] != rhs[i])
				{
					return false;
				}
			}

			// made it through the whole loop, return true
			return true;
		}
		else
		{
			return false;
		}
	}

} }

#endif