#ifndef __STYLING_SOURCE_H__
#define __STYLING_SOURCE_H__

#include <lucid/gal/Types.h>
#include <Utils/EnumUtils.h>

namespace onyx {
namespace Styling {

	/*
	* A class to represent a Source in a stylesheet. There are a number of different types of sources that all inherit
	* from this class. They are pretty self-explanatory and map nicely to the Source types listed at this link:
	* https://docs.mapbox.com/mapbox-gl-js/style-spec/sources/
	*/

	struct Source
	{

		typedef int zoom_level_t;

		enum class Type
		{
			UNKNOWN,
			VECTOR,
			RASTER,
			RASTER_DEM,
			GEOJSON
		};

		Type type = Type::UNKNOWN;

		zoom_level_t maxZoom = 22;
		zoom_level_t minZoom = 0;

		lgal::world::AABB2d bounds = { { -180, -85.051129 }, { 180, 85.051129 } };

		bool internal = false;

		// number of milliseconds to keep this layer in the in-memory cache
		double expirationMS = std::numeric_limits<double>::max();

		Source() = default;
		Source(Type t) : type(t) {}

		virtual ~Source() = default;

		inline bool isRaster() const { return type == Type::RASTER || type == Type::RASTER_DEM; }
		inline bool isVector() const { return type == Type::VECTOR || type == Type::GEOJSON; }
		inline bool isHeight() const { return type == Type::RASTER_DEM; }

		inline lgal::Range range() const { return { minZoom, maxZoom }; }

	protected:

		static inline bool equals(Source const& lhs, Source const& rhs)
		{
			return lhs.type == rhs.type
				&& lhs.maxZoom == rhs.maxZoom
				&& lhs.minZoom == rhs.minZoom
				&& lhs.bounds == rhs.bounds
				&& lhs.internal == rhs.internal
				&& lhs.expirationMS == rhs.expirationMS;
		}

	};

	

} }

namespace std
{

	template<>
	inline onyx::Styling::Source::Type fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Source::Type> const nameMap =
		{
			{ "raster",					onyx::Styling::Source::Type::RASTER		},
			{ "raster-dem",				onyx::Styling::Source::Type::RASTER_DEM	},
			{ "vector",					onyx::Styling::Source::Type::VECTOR		},
			{ "geojson",				onyx::Styling::Source::Type::GEOJSON		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Source::Type");
	}

	inline std::string_view toStringView(onyx::Styling::Source::Type value)
	{
		static std::unordered_map<onyx::Styling::Source::Type, std::string_view> const nameMap =
		{
			{ onyx::Styling::Source::Type::RASTER,			"raster"		},
			{ onyx::Styling::Source::Type::RASTER_DEM,		"raster-dem"	},
			{ onyx::Styling::Source::Type::VECTOR,			"vector"		},
			{ onyx::Styling::Source::Type::GEOJSON,			"geojson"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Source::Type");
	}

}

#endif