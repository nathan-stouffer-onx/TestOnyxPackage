#pragma once

#include <bitset>
#include <string>
#include <unordered_map>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

#include <lucid/gal/Types.h>
#include <Utils/EnumUtils.h>
#include <Utils/UUID.h>

#include "Styling/Types.h"

namespace onyx::Styling
{

	using FeatureStatesT = std::unordered_map<FeatureIdT, FeatureStateT>;
	using LayerStatesT = std::unordered_map<std::string, std::shared_ptr<FeatureStatesT>>;

	/*
	* A class to represent a Source in a stylesheet. There are a number of different types of sources that all inherit
	* from this class. They are pretty self-explanatory and map nicely to the Source types listed at this link:
	* https://docs.mapbox.com/mapbox-gl-js/style-spec/sources/
	*/

	struct Source
	{

		typedef int zoom_level_t;

		enum class Types
		{
			UNKNOWN,
			VECTOR,
			RASTER,
			RASTER_DEM,
			GEOJSON
		};

		struct Bounds
		{
			using CollectionT = std::vector<lgal::world::AABB2d>;
			using const_iterator = CollectionT::const_iterator;

			Bounds() : Bounds(CollectionT{}) {}
			Bounds(CollectionT const& boxes) : mBoxes(boxes), mAABB(lmath::fit<std::vector>(boxes)) {}

			inline lgal::world::AABB2d const& aabb() const { return mAABB; }

			inline const_iterator begin() const { return mBoxes.begin(); }
			inline const_iterator end() const { return mBoxes.end(); }

			inline bool operator==(Bounds const& rhs) const
			{
				if (mBoxes.size() != rhs.mBoxes.size())
				{
					return false;
				}
				else
				{
					for (size_t i = 0; i < mBoxes.size(); ++i)
					{
						if (mBoxes[i] != rhs.mBoxes[i])
						{
							return false;
						}
					}
				}
				
				// made it through all checks; return true
				return true;
			}

			static inline Bounds Default()
			{
				lgal::world::AABB2d box = { { -180, -85.051129 }, { 180, 85.051129 } };
				return Bounds{ std::vector<lgal::world::AABB2d>{ box } };
			}

		private:

			CollectionT mBoxes;
			lgal::world::AABB2d mAABB;

		};

		Types type = Types::UNKNOWN;

		zoom_level_t maxZoom = 22;
		zoom_level_t minZoom = 0;

		Bounds bounds = Bounds::Default();

		bool internal = false;

		// number of milliseconds to keep this layer in the in-memory cache
		double expirationMS = std::numeric_limits<double>::max();

		// store feature state -- only applicable for VECTOR/GEOJSON sources
		LayerStatesT states;

		Source() = default;
		Source(Types t) : type(t) {}

		virtual ~Source() = default;

		inline bool isTiled() const { return !(type == Types::GEOJSON || type == Types::UNKNOWN); }
		inline bool isLocal() const { return type == Types::GEOJSON || internal; }

		inline bool isRaster() const { return type == Types::RASTER || type == Types::RASTER_DEM; }
		inline bool isVector() const { return type == Types::VECTOR || type == Types::GEOJSON; }
		inline bool isHeight() const { return type == Types::RASTER_DEM; }

		inline lgal::Range range() const { return { minZoom, maxZoom }; }

		inline lgal::world::AABB2d aabb() const { return bounds.aabb(); }

		inline lmath::Intersections intersects(lgal::world::AABB2d const& aabb) const
		{
			lmath::Intersections intersection = lmath::Intersections::NONE;
			for (lgal::world::AABB2d const& box : bounds)
			{
				lmath::Intersections current = lmath::intersects(box, aabb);
				if (current == lmath::Intersections::FULL)	// early out if it is a full intersetion
				{
					return current;
				}
				else if (current == lmath::Intersections::PARTIAL)
				{
					intersection = current;
				}
			}
			
			// made it through loop, return value
			return intersection;
		}

	protected:

		static inline bool equals(Source const& lhs, Source const& rhs)
		{
			return lhs.type == rhs.type
				&& lhs.maxZoom == rhs.maxZoom
				&& lhs.minZoom == rhs.minZoom
				&& lhs.bounds == rhs.bounds
				&& lhs.internal == rhs.internal
				&& lhs.expirationMS == rhs.expirationMS;
		}

	};

}

namespace std
{

	template<>
	inline onyx::Styling::Source::Types fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Source::Types> const nameMap =
		{
			{ "raster",					onyx::Styling::Source::Types::RASTER		},
			{ "raster-dem",				onyx::Styling::Source::Types::RASTER_DEM	},
			{ "vector",					onyx::Styling::Source::Types::VECTOR		},
			{ "geojson",				onyx::Styling::Source::Types::GEOJSON		},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Source::Type");
	}

	inline std::string_view toStringView(onyx::Styling::Source::Types value)
	{
		static std::unordered_map<onyx::Styling::Source::Types, std::string_view> const nameMap =
		{
			{ onyx::Styling::Source::Types::RASTER,			"raster"		},
			{ onyx::Styling::Source::Types::RASTER_DEM,		"raster-dem"	},
			{ onyx::Styling::Source::Types::VECTOR,			"vector"		},
			{ onyx::Styling::Source::Types::GEOJSON,			"geojson"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Source::Type");
	}

}