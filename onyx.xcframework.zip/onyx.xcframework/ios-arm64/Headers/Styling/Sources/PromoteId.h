#ifndef __STYLING_PROMOTE_ID_H__
#define __STYLING_PROMOTE_ID_H__

#include <string>
#include <unordered_map>

namespace onyx {
namespace Styling {

	struct PromoteId final
	{
	private:

		enum class Types
		{
			STRING,
			MAP
		};

	public:

		PromoteId() : PromoteId("") {}
		explicit PromoteId(std::string const& id) : mType(Types::STRING), mId(id) {}
		explicit PromoteId(std::unordered_map<std::string, std::string> const& ids) : mType(Types::MAP), mIds(ids) {}

		PromoteId& operator=(PromoteId const& rhs)
		{
			mType = rhs.mType;
			switch (mType)
			{
				case Types::STRING:		mId = rhs.mId;			break;
				case Types::MAP:		mIds = rhs.mIds;		break;
				default:										break;
			}
			return *this;
		}

		std::string key(std::string const& layer) const
		{
			switch (mType)
			{
				case Types::STRING:		return keyFromString(layer);	break;
				case Types::MAP:		return keyFromMap(layer);		break;
				default:				return "";
			}
		}

		inline bool operator==(PromoteId const& rhs) const
		{
			switch (mType)
			{
				case Types::STRING:		return stringEquals(rhs);	break;
				case Types::MAP:		return mapEquals(rhs);		break;
				default:				return false;
			}
		}

		inline bool operator!=(PromoteId const& rhs) const
		{
			return !(*this == rhs);
		}

	private:

		std::string keyFromString(std::string const&) const
		{
			return mId;
		}

		std::string keyFromMap(std::string const& layer) const
		{
			auto found = mIds.find(layer);
			return (found == mIds.end()) ? "id" : found->second;
		}

		bool stringEquals(PromoteId const& rhs) const
		{
			return mId == rhs.mId;
		}

		bool mapEquals(PromoteId const& rhs) const
		{
			return mIds == rhs.mIds;
		}

	private:

		Types mType;

		std::string mId;
		std::unordered_map<std::string, std::string> mIds;
	
	};

} }

#endif