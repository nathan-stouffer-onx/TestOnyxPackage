#ifndef __STYLING_GEOJSON_SOURCE_H__
#define __STYLING_GEOJSON_SOURCE_H__

#include <3rdParty/nlohmann/json.hpp>
#include <3rdParty/sole/ourSole.h>

#include "Source.h"
#include <GeoJson/GeoJson.h>

namespace onyx {
namespace Styling {

	struct GeojsonSource final : public Source
	{

		// TODO possibly add a whole bunch of geojson-specific attributes (ie cluster*, generateId)? depends on whether onX will use those

		std::string promoteId = "";

		// TODO (stouff) set this up to be a unique_ptr? -- it is currently a hole in a Style's ability to completely control
		// write access to it's members
		std::shared_ptr<GeoJson::GeoJson const> data = nullptr;

		// Controls where the gj will go in UserMarkupManager
		bool runtimeEdit = false;

		GeojsonSource() : Source(Type::GEOJSON) {}
		GeojsonSource(std::shared_ptr<const GeoJson::GeoJson> _data) : Source(Type::GEOJSON)
		{
			this->bounds = _data->bounds.as<world_float_t>();
			data = _data;
		}

	};

} }

#endif