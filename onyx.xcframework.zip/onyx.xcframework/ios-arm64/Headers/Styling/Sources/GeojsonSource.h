#ifndef __STYLING_GEOJSON_SOURCE_H__
#define __STYLING_GEOJSON_SOURCE_H__

#include <3rdParty/nlohmann/json.hpp>

#include <GeoJson/GeoJson.h>

#include "Styling/Sources/Source.h"
#include "Styling/Sources/PromoteId.h"

namespace onyx {
namespace Styling {

	struct GeojsonSource final : public Source
	{

		// this is intentionally left as empty string to match the stylesheet requirement that layers referencing
		// non-vector sources have a blank source-layer property
		static char constexpr cLayerName[]  = "";

		// TODO possibly add a whole bunch of geojson-specific attributes (ie cluster*, generateId)? depends on whether onX will use those

		PromoteId promoteId = PromoteId("id");

		std::unique_ptr<GeoJson::GeoJson const> data = nullptr;

		GeojsonSource() : Source(Types::GEOJSON) {}
		GeojsonSource(std::unique_ptr<GeoJson::GeoJson const> _data) : Source(Types::GEOJSON)
		{
			maxZoom = 15;
			bounds = Source::Bounds{ std::vector<lgal::world::AABB2d>{ _data->bounds.as<world_float_t>() } };
			data = std::move(_data);
		}

	};

} }

#endif