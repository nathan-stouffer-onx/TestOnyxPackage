#pragma once

#include <array>
#include <memory>
#include <string>
#include <unordered_map>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

#include <lucid/gal/Types.h>
#include <lucid/gigl/Context.h>

#include <Utils/BitwiseEnumOperators.h>
#include <Utils/Gradient.h>

#include "Styling/Expressions/Dependencies.h"
#include "Styling/Formatted.h"
#include "Styling/Types.h"

namespace onyx::Styling::Expressions
{

	struct Arguments;
	struct InitArgs;

	class ExpressionBase
	{
	public:
		ExpressionBase(Dependencies defaultDependencies = Dependencies::NONE)
			: mDefaultDependencies(defaultDependencies)
		{}

		virtual std::vector<ExpressionBase const*> children(InitArgs const& args) const = 0;

		Dependencies dependencies(InitArgs const& args) const
		{
			if (mStaleDependencies)
			{
				mDependencies = mDefaultDependencies;
				for (auto& child : children(args))
				{
					mDependencies = mDependencies | child->dependencies(args);
				}
				mStaleDependencies = false;
			}
			return mDependencies;
		}

		void invalidateDependenciesCache()
		{
			mDependencies = Expressions::Dependencies::UNSET;
			mStaleDependencies = true;
		}

	private:

		bool mutable mStaleDependencies = true;
		mutable Dependencies mDependencies = Dependencies::UNSET;
		Dependencies const mDefaultDependencies = Dependencies::NONE;

	};

	template<typename T>
	class TypedExpressionBase : public ExpressionBase
	{
	public:

		TypedExpressionBase(Dependencies defaultDependencies = Dependencies::NONE) : ExpressionBase(defaultDependencies) { }

		virtual ~TypedExpressionBase() {}

		virtual T evaluate(Arguments const& args) const = 0;
	};


	template<typename OutputT>
	using ExpressionType = TypedExpressionBase<OutputT>;

	template<typename OutputT>
	using ExpressionPtr = std::unique_ptr<ExpressionType<OutputT> const>;

	template<typename OutputT>
	using SharedExpressionPtr = std::shared_ptr<ExpressionType<OutputT> const>;

	// -------------------------------------------------------------------------------------
	// Handy common-pattern expression types
	// -------------------------------------------------------------------------------------
	template<typename OutputT>
	class NoChildType : public TypedExpressionBase<OutputT>
	{
	public:
		NoChildType(Dependencies defaultDependencies = Dependencies::NONE)
			: TypedExpressionBase<OutputT>(defaultDependencies)
		{}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override { return {}; }

	};
	
	template<typename OutputT, typename ArgumentT>
	class OneArgExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		OneArgExpressionBase(ExpressionPtr<ArgumentT> &arg, Dependencies defaultDependencies = Dependencies::NONE)
			: TypedExpressionBase<OutputT>(defaultDependencies)
			, mArg(std::move(arg)) {}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			return { mArg.get() };
		}

	protected:
		ExpressionPtr<ArgumentT> const mArg;
	};

	template<typename OutputT, typename ArgumentT>
	class TwoArgExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		using ExprPtr = ExpressionPtr<ArgumentT>;

		TwoArgExpressionBase(ExprPtr &lhs, ExprPtr&rhs, Dependencies defaultDependencies = Dependencies::NONE)
			: TypedExpressionBase<OutputT>(defaultDependencies)
			, mLHS(std::move(lhs))
			, mRHS(std::move(rhs))
		{}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			return { mLHS.get(), mRHS.get() };
		}

	protected:
		ExprPtr const mLHS;
		ExprPtr const mRHS;
	};

	template<typename OutputT, typename ArgumentT>
	class ArgListExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		ArgListExpressionBase(std::vector<ExpressionPtr<ArgumentT>>&& expressions, Dependencies defaultDependencies = Dependencies::NONE)
			: TypedExpressionBase<OutputT>(defaultDependencies)
			, mExpressions(std::move(expressions)) {}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(mExpressions.size());
			for (auto const& expr : mExpressions)
			{
				target.push_back(expr.get());
			}
			return target;
		}

	protected:
		std::vector<ExpressionPtr<ArgumentT>> const mExpressions;
	};

	template<typename OutputT>
	class ConstantExpressionBase : public NoChildType<OutputT>
	{
	public:
		ConstantExpressionBase(OutputT value, Dependencies defaultDependencies = Dependencies::NONE)
			: NoChildType<OutputT>(defaultDependencies)
			, mValue(value) { }

		OutputT evaluate(Arguments const&) const override
		{
			return mValue;
		}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override { return {}; }

	protected:
		OutputT const mValue;
	};

	// -------------------------------------------------------------------------------------
	// Handy Instantiated/typed expression types
	// -------------------------------------------------------------------------------------

	template<typename OutputT>
	struct InstantiateExpressionTypes
	{
		using Type = ExpressionType<OutputT>;
		using Ptr = ExpressionPtr<OutputT>;
		using SharedPtr = SharedExpressionPtr<OutputT>;
		using NoChildType = NoChildType<OutputT>;
		using OneArgType = OneArgExpressionBase<OutputT, OutputT>;
		using TwoArgType = TwoArgExpressionBase<OutputT, OutputT>;
		using ArgListType = ArgListExpressionBase<OutputT, OutputT>;
		using ConstantType = ConstantExpressionBase<OutputT>;
	};

	// using statements to instantiate template of a base class that returns the specified type
	// https://docs.mapbox.com/mapbox-gl-js/style-spec/types/
	using BooleanT = InstantiateExpressionTypes<bool>;
	using ColorT = InstantiateExpressionTypes<lgal::Color>;
	using FormattedT = InstantiateExpressionTypes<Formatted>;
	using NumberT = InstantiateExpressionTypes<float>;
	using RangeT = InstantiateExpressionTypes<lgal::gpu::Range>;
	using ResolvedImageT = InstantiateExpressionTypes<ResolvedImage>;
	using StringT = InstantiateExpressionTypes<std::string>;
	using GradientT = InstantiateExpressionTypes<Utils::Gradient>;

	template<typename OutputEnumT>
	using EnumT = InstantiateExpressionTypes<OutputEnumT>;

	template<typename OutputT>
	using ArrayT = InstantiateExpressionTypes<std::vector<OutputT>>;

	using BooleanArrayT = ArrayT<bool>;
	using ColorArrayT = ArrayT<lgal::Color>;
	using NumberArrayT = ArrayT<float>;
	using RangeArrayT = ArrayT<lgal::gpu::Range>;
	using StringArrayT = ArrayT<std::string>;
	
	namespace primitives {

		struct ExpressionTypes
		{

			enum { TYPE_COUNT = 10 };

			static lucid::gigl::PrimitiveInfo const infos[TYPE_COUNT];

			// Deleting this constructor forces a compile error if someone tries to use a context
			// to store/retrieve something that is unsupported.
			template<class T>	struct Type { Type() = delete; enum { VALUE = 0 }; };

		};

		template<> struct ExpressionTypes::Type<lucid::gigl::primitives::UNKNOWN		> { enum { VALUE = 0 }; };
		template<> struct ExpressionTypes::Type<lucid::gigl::primitives::UNDEFINED		> { enum { VALUE = 1 }; };
		template<> struct ExpressionTypes::Type<BooleanT::SharedPtr						> { enum { VALUE = 2 }; };
		template<> struct ExpressionTypes::Type<ColorT::SharedPtr						> { enum { VALUE = 3 }; };
		template<> struct ExpressionTypes::Type<FormattedT::SharedPtr					> { enum { VALUE = 4 }; };
		template<> struct ExpressionTypes::Type<GradientT::SharedPtr					> { enum { VALUE = 5 }; };
		template<> struct ExpressionTypes::Type<NumberT::SharedPtr						> { enum { VALUE = 6 }; };
		template<> struct ExpressionTypes::Type<RangeT::SharedPtr						> { enum { VALUE = 7 }; };
		template<> struct ExpressionTypes::Type<ResolvedImageT::SharedPtr				> { enum { VALUE = 8 }; };
		template<> struct ExpressionTypes::Type<StringT::SharedPtr						> { enum { VALUE = 9 }; };

	}

	using ExpressionContext = lucid::gigl::FlexContext<primitives::ExpressionTypes>;

	// default values for constants
	static constexpr bool             cDefaultBoolean  = false;
	static constexpr lgal::Color      cDefaultColor    = 0xFF000000;
	static constexpr float            cDefaultNumber   = 0;
	static constexpr std::string_view cDefaultString   = "";

	template <typename OutputT>
	class ContextExpression final : public InstantiateExpressionTypes<OutputT>::Type
	{
	public:
		ContextExpression(std::string const &contextName)
			: InstantiateExpressionTypes<OutputT>::Type(Dependencies::CONTEXT)
			, mContextName(contextName)
		{}

		OutputT evaluate(Arguments const& args) const override;
		
		std::vector<ExpressionBase const*> children(InitArgs const& args) const override;

	private:
		std::string const mContextName;
	};

	struct Arguments
	{
		using PropertiesT = Styling::PropertiesT;
		using FeatureStateT = Styling::FeatureStateT;

		PropertiesT const& properties;
		FeatureStateT const& state;
		world_float_t zoom;
		world_float_t heading;	// in degrees
		world_float_t pitch;	// in degrees
		std::shared_ptr<ExpressionContext const> const context;

		Arguments(PropertiesT const& _properties, FeatureStateT const& _state, world_float_t _zoom, world_float_t _heading, world_float_t _pitch, std::shared_ptr<ExpressionContext const> _context = nullptr) :
			properties(_properties),
			state(_state), 
			zoom(_zoom),
			heading(_heading),
			pitch(_pitch),
			context(_context)
		{}

		Arguments(world_float_t _zoom, world_float_t _heading, world_float_t _pitch, std::shared_ptr<ExpressionContext const> _context = nullptr) :
			Arguments(sProperties, sState, _zoom, _heading, _pitch, _context)
		{}

		static Arguments Default()
		{
			return { sProperties, sState, 0.0, 0.0, 0.0, nullptr };
		}

	private:

		static PropertiesT sProperties;
		static FeatureStateT sState;

	};

	struct InitArgs
	{
		std::shared_ptr<ExpressionContext const> const context;
		InitArgs(std::shared_ptr<ExpressionContext const> const& _context)
			: context(_context)
		{ }
		
	};

	template<typename OutputT>
	OutputT ContextExpression<OutputT>::evaluate(Arguments const& args) const
	{
		typename InstantiateExpressionTypes<OutputT>::SharedPtr expr;
		args.context->getTo(mContextName, expr);
		OutputT result = expr->evaluate(args);
		return result;
	}

	template<typename OutputT>
	std::vector<ExpressionBase const*> ContextExpression<OutputT>::children(InitArgs const& args) const
	{
		typename InstantiateExpressionTypes<OutputT>::SharedPtr expr;
		args.context->getTo(mContextName, expr);
		return { expr.get() };
	}

	// This isn't the most performant way to gather dependencies, but it saves a whole lot of redundant boilerplate,
	// and I suspect that the compiler will be able to optimize a lot of it away with loop unrolling.
	inline Dependencies dependencies(InitArgs const& args, std::vector<ExpressionBase const*> const& expressions)
	{
		auto result = Dependencies::NONE;
		for (auto const& expr : expressions)
		{
			if (expr != nullptr)
			{
				result |= expr->dependencies(args);
				if (result == Dependencies::ALL)
				{
					break;
				}
			}
		}
		return result;
	}

	inline std::vector<ExpressionBase const*> concat(std::vector<ExpressionBase const*> const& lhs, std::vector<ExpressionBase const*> const& rhs)
	{
		std::vector<ExpressionBase const*> exprs;
		exprs.reserve(lhs.size() + rhs.size());
		exprs.insert(exprs.end(), lhs.begin(), lhs.end());
		exprs.insert(exprs.end(), rhs.begin(), rhs.end());
		return exprs;
	}

}