#ifndef __STYLING_EXPRESSIONS_H__
#define __STYLING_EXPRESSIONS_H__

#include <string>
#include <unordered_map>
#include <memory>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

#include <Utils/BitwiseEnumOperators.h>
#include <lucid/gal/Types.h>
#include <lucid/gigl/Context.h>

#include "Styling/Layers/Declarations.h"
#include "ModificationFlags.h"

namespace onyx {
namespace Styling {
namespace Expressions {

	struct Arguments;
	struct ValidationArguments;

	class ExpressionBase
	{
	public:
		ExpressionBase(ModificationFlags defaultModificationFlags = ModificationFlags::NONE)
			: mDefaultFlags(defaultModificationFlags)
		{

		}

		virtual void getChildren(std::vector<ExpressionBase const*>& /*target*/, ValidationArguments const& /*args*/) const { };

		ModificationFlags getModificationFlags() const { return mFlags; }

		ModificationFlags gatherModificationFlags(ValidationArguments const &args, bool force = false) const
		{
			if ((mFlags  == ModificationFlags::UNSET) || force)
			{
				mFlags = mDefaultFlags;
				std::vector<ExpressionBase const*> children;
				getChildren(children, args);
				for (auto& child : children)
				{
					mFlags = mFlags | child->gatherModificationFlags(args);
				}
			}

			return mFlags;
		}

	private:
		mutable ModificationFlags mFlags = ModificationFlags::UNSET;
		ModificationFlags const mDefaultFlags = ModificationFlags::NONE;
	};

	template<typename T>
	class TypedExpressionBase : public ExpressionBase
	{
	public:

		TypedExpressionBase(ModificationFlags defaultModificationFlags = ModificationFlags::NONE) : ExpressionBase(defaultModificationFlags) { }

		virtual ~TypedExpressionBase() {}

		virtual T evaluate(Arguments const& args) const = 0;
	};


	template<typename OutputT>
	using ExpressionType = TypedExpressionBase<OutputT>;

	template<typename OutputT>
	using ExpressionPtr = std::unique_ptr<ExpressionType<OutputT> const>;

	template<typename OutputT>
	using SharedExpressionPtr = std::shared_ptr<ExpressionType<OutputT> const>;

	// -------------------------------------------------------------------------------------
	// Handy common-pattern expression types
	// -------------------------------------------------------------------------------------
	template<typename OutputT, typename ArgumentT>
	class OneArgExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		OneArgExpressionBase(ExpressionPtr<ArgumentT> &arg, ModificationFlags defaultModificationFlags = ModificationFlags::NONE)
			: TypedExpressionBase<OutputT>(defaultModificationFlags)
			, mArg(std::move(arg)) {}

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const&) const override
		{
			target.push_back(mArg.get());
		}

	protected:
		ExpressionPtr<ArgumentT> const mArg;
	};

	template<typename OutputT, typename ArgumentT>
	class TwoArgExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		using ExprPtr = ExpressionPtr<ArgumentT>;

		TwoArgExpressionBase(ExprPtr &lhs, ExprPtr&rhs, ModificationFlags defaultModificationFlags = ModificationFlags::NONE)
			: TypedExpressionBase<OutputT>(defaultModificationFlags)
			, mLHS(std::move(lhs))
			, mRHS(std::move(rhs))
		{}

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const&) const override
		{
			target.push_back(mLHS.get());
			target.push_back(mRHS.get());
		}

	protected:
		ExprPtr const mLHS;
		ExprPtr const mRHS;
	};

	template<typename OutputT, typename ArgumentT>
	class ArgListExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		ArgListExpressionBase(std::vector<ExpressionPtr<ArgumentT>>&& expressions, ModificationFlags defaultModificationFlags = ModificationFlags::NONE)
			: TypedExpressionBase<OutputT>(defaultModificationFlags)
			, mExpressions(std::move(expressions)) {}

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const&) const override
		{
			for (auto const& expr : mExpressions)
			{
				target.push_back(expr.get());
			}
		}

	protected:
		std::vector<ExpressionPtr<ArgumentT>> const mExpressions;
	};

	template<typename OutputT>
	class ConstantExpressionBase : public TypedExpressionBase<OutputT>
	{
	public:
		ConstantExpressionBase(OutputT value, ModificationFlags defaultModificationFlags = ModificationFlags::NONE)
			: TypedExpressionBase<OutputT>(defaultModificationFlags)
			, mValue(value) { }

		OutputT evaluate(Arguments const&) const override
		{
			return mValue;
		}

		void getChildren(std::vector<ExpressionBase const*>&, ValidationArguments const&) const override { }

	protected:
		OutputT const mValue;
	};

	// -------------------------------------------------------------------------------------
	// Handy Instantiated/typed expression types
	// -------------------------------------------------------------------------------------

	template<typename OutputT>
	struct InstantiateExpressionTypes
	{
		using Type = ExpressionType<OutputT>;
		using Ptr = ExpressionPtr<OutputT>;
		using SharedPtr = SharedExpressionPtr<OutputT>;
		using OneArgType = OneArgExpressionBase<OutputT, OutputT>;
		using TwoArgType = TwoArgExpressionBase<OutputT, OutputT>;
		using ArgListType = ArgListExpressionBase<OutputT, OutputT>;
		using ConstantType = ConstantExpressionBase<OutputT>;
	};

	// using statements to instantiate template of a base class that returns the specified type
	// https://docs.mapbox.com/mapbox-gl-js/style-spec/types/
	using BooleanT = InstantiateExpressionTypes<bool>;
	using ColorT = InstantiateExpressionTypes<lgal::Color>;
	using NumberT = InstantiateExpressionTypes<float>;
	using StringT = InstantiateExpressionTypes<std::string>;

	template<typename OutputEnumT>
	using EnumT = InstantiateExpressionTypes<OutputEnumT>;

	template<typename OutputT>
	using ArrayT = InstantiateExpressionTypes<std::vector<OutputT>>;

	using BooleanArrayT = ArrayT<bool>;
	using ColorArrayT = ArrayT<lgal::Color>;
	using NumberArrayT = ArrayT<float>;
	using StringArrayT = ArrayT<std::string>;
	
	namespace primitives {

		struct StyleTypes
		{

			enum { TYPE_COUNT = 19 };

			static lucid::gigl::PrimitiveInfo const infos[TYPE_COUNT];

			// Deleting this constructor forces a compile error if someone tries to use a context
			// to store/retrieve something that is unsupported.
			template<class T>	struct Type { Type() = delete; enum { VALUE = 0 }; };
			template<>			struct Type<	lucid::gigl::primitives::UNKNOWN		> { enum { VALUE =  0 }; };
			template<>			struct Type<	lucid::gigl::primitives::UNDEFINED		> { enum { VALUE =  1 }; };
			template<>			struct Type<	BooleanT::SharedPtr						> { enum { VALUE =  2 }; };
			template<>			struct Type<	ColorT::SharedPtr						> { enum { VALUE =  3 }; };
			template<>			struct Type<	NumberT::SharedPtr						> { enum { VALUE =  4 }; };
			template<>			struct Type<	StringT::SharedPtr						> { enum { VALUE =  5 }; };
			template<>			struct Type<	std::shared_ptr<BackgroundPaint const>	> { enum { VALUE =  6 }; };
			template<>			struct Type<	std::shared_ptr<RasterPaint	    const>	> { enum { VALUE =  7 }; };
			template<>			struct Type<	std::shared_ptr<LinePaint	    const>	> { enum { VALUE =  8 }; };
			template<>			struct Type<	std::shared_ptr<FillPaint	    const>	> { enum { VALUE =  9 }; };
			template<>			struct Type<	std::shared_ptr<SymbolPaint	    const>	> { enum { VALUE = 10 }; };
			template<>			struct Type<	std::shared_ptr<ContourPaint    const>	> { enum { VALUE = 11 }; };
			template<>			struct Type<	std::shared_ptr<BackgroundLayout const>	> { enum { VALUE = 12 }; };
			template<>			struct Type<	std::shared_ptr<RasterLayout	const>	> { enum { VALUE = 13 }; };
			template<>			struct Type<	std::shared_ptr<LineLayout		const>	> { enum { VALUE = 14 }; };
			template<>			struct Type<	std::shared_ptr<FillLayout		const>	> { enum { VALUE = 15 }; };
			template<>			struct Type<	std::shared_ptr<SymbolLayout	const>	> { enum { VALUE = 16 }; };
			template<>			struct Type<	std::shared_ptr<IntervalLayout	const>	> { enum { VALUE = 17 }; };
			template<>			struct Type<	std::shared_ptr<ContourLayout	const>	> { enum { VALUE = 18 }; };
		};

	}

	using StyleContext = lucid::gigl::FlexContext<primitives::StyleTypes>;

	// default values for constants
	static constexpr bool             cDefaultBoolean = false;
	static constexpr lgal::Color      cDefaultColor   = 0xFF000000;
	static constexpr float            cDefaultNumber  = 0;
	static constexpr std::string_view cDefaultString  = "";

	template <typename OutputT>
	class ContextExpression final : public InstantiateExpressionTypes<OutputT>::Type
	{
	public:
		ContextExpression(std::string const &contextName)
			: InstantiateExpressionTypes<OutputT>::Type(ModificationFlags::CONTEXT)
			, mContextName(contextName)
		{
		}

		OutputT evaluate(Arguments const& args) const override;
		
		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const& args) const override;

	private:
		std::string const mContextName;
	};

	struct Arguments
	{
		using PropertiesT = std::unordered_map<std::string, vector_tile::Tile_Value>;

		PropertiesT const& properties;
		// TODO (stouff) include feature state here
		world_float_t zoom;
		world_float_t pitch;	// in degrees
		std::shared_ptr<StyleContext const> const context;
		Arguments(PropertiesT const& _properties, world_float_t _zoom, world_float_t _pitch, std::shared_ptr<StyleContext const> _context = nullptr) :
			properties(_properties),
			zoom(_zoom),
			pitch(_pitch),
			context(_context)
		{}

	};

	struct ValidationArguments
	{
		std::shared_ptr<StyleContext const> const context;
		ValidationArguments(std::shared_ptr<StyleContext const>& _context)
			: context(_context)
		{ }

		template <typename T>
		Expressions::ModificationFlags getBaseFlags(T* derived, Expressions::ValidationArguments const& args) const
		{
			if (derived->base.empty())
			{
				return Expressions::ModificationFlags::NONE;
			}
			
			if (derived->basePtr == nullptr)
			{
				// If validation has succeeded, this should be guaranteed to exist in the context
				context->getTo(derived->base, derived->basePtr);
			}
			return derived->basePtr->initialize(args);
		}
	};

	template<typename OutputT>
	OutputT ContextExpression<OutputT>::evaluate(Arguments const& args) const
	{
		typename InstantiateExpressionTypes<OutputT>::SharedPtr expr;
		args.context->getTo(mContextName, expr);
		OutputT result = expr->evaluate(args);
		return result;
	}

	template<typename OutputT>
	void ContextExpression<OutputT>::getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const& args) const
	{
		typename InstantiateExpressionTypes<OutputT>::SharedPtr expr;
		args.context->getTo(mContextName, expr);
		target.push_back(expr.get());
	}

} } }

#endif