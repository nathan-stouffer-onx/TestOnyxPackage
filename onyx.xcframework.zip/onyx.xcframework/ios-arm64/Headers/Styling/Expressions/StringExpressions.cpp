#include "StringExpressions.h"

#include <algorithm>

#include <System/Map3DException.h>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {

	std::string Get::evaluate(Arguments const& args) const
	{
		Arguments::PropertiesT::const_iterator iter = args.properties.find(mKey);
		if (iter != args.properties.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_string_value())
			{
				return val.string_value();
			}
			else
			{
				MAP3D_THROW("Tile value for " + mKey + " must be a string but is a " + val.GetTypeName());
			}
		}

		// return default value
		return std::string(cDefaultString);
	}

	std::string Downcase::evaluate(Arguments const& args) const
	{
		std::string ret = mArg->evaluate(args);
		std::transform(ret.begin(), ret.end(), ret.begin(), 
			[](unsigned char c) { return static_cast<std::string::value_type>(std::tolower(c)); }
		);
		return ret;
	}

	std::string Upcase::evaluate(Arguments const& args) const
	{
		std::string ret = mArg->evaluate(args);
		std::transform(ret.begin(), ret.end(), ret.begin(),
			[](unsigned char c) { return static_cast<std::string::value_type>(std::toupper(c)); }
		);
		return ret;
	}

	std::string Slice::evaluate(Arguments const& args) const
	{
		// evaluate input expression
		std::string const input = mInput->evaluate(args);

		// compute beginning and end of the ranges
		size_t begin = Slice::Clamp(static_cast<IndexT>(mBegin->evaluate(args)), input);
		size_t end = Slice::Clamp(static_cast<IndexT>((mEnd) ? mEnd->evaluate(args) : input.size()), input);

		if (begin < end)
		{
			std::string ret;
			ret.reserve(end - begin);
			for (size_t i = begin; i < end; ++i)
			{
				ret.push_back(input[i]);
			}
			return ret;
		}
		else
		{
			return "";
		}
	}

	size_t Slice::Clamp(IndexT pos, std::string const& input)
	{
		if (pos < 0)
		{
			size_t offset = static_cast<size_t>(std::abs(pos));
			if (offset < input.size())
			{
				return input.size() - offset;
			}
			else
			{
				return 0;
			}
		}
		else if (static_cast<size_t>(pos) < input.size())	 // cast is safe because of previous if-statement
		{
			return static_cast<size_t>(pos);
		}
		else
		{
			return input.size();
		}
	}

} } } }