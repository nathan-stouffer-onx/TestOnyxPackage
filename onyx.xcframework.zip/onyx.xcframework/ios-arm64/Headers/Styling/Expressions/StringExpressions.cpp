#include "StringExpressions.h"

#include <algorithm>

#include <System/OnyxException.h>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {

	static void StripUnnecessaryZeros(std::string& str)
	{
		str.erase(str.find_last_not_of('0') + 1, std::string::npos);
		str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	}

	static std::string At(std::string const& key, std::unordered_map<std::string, vector_tile::Tile_Value> const& values, std::string const& fallback)
	{
		Arguments::PropertiesT::const_iterator iter = values.find(key);
		if (iter != values.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_bool_value())
			{
				return (val.bool_value()) ? "true" : "false";
			}
			else if (val.has_double_value())
			{
				std::string str = std::to_string(val.double_value());
				StripUnnecessaryZeros(str);
				return str;
			}
			else if (val.has_float_value())
			{
				std::string str = std::to_string(val.float_value());
				StripUnnecessaryZeros(str);
				return str;
			}
			else if (val.has_int_value())
			{
				return std::to_string(val.int_value());
			}
			else if (val.has_sint_value())
			{
				return std::to_string(val.sint_value());
			}
			else if (val.has_string_value())
			{
				return val.string_value();
			}
			else if (val.has_uint_value())
			{
				return std::to_string(val.uint_value());
			}
			else
			{
				ONYX_THROW("Conversion from " + val.GetTypeName() + " to string not supported");
			}
		}

		// return fallback value
		return fallback;
	}

	std::string Concat::evaluate(Arguments const& args) const
	{
		std::ostringstream str;
		for (StringT::Ptr const& input : mInputs)
		{
			str << input->evaluate(args);
		}
		return str.str();
	}

	std::string Downcase::evaluate(Arguments const& args) const
	{
		std::string ret = mArg->evaluate(args);
		std::transform(ret.begin(), ret.end(), ret.begin(), 
			[](unsigned char c) { return static_cast<std::string::value_type>(std::tolower(c)); }
		);
		return ret;
	}

	std::string FeatureState::evaluate(Arguments const& args) const
	{
		return At(mKey, args.state, mFallback->evaluate(args));
	}

	std::string FromColor::evaluate(Arguments const& args) const
	{
		lgal::Color color = mArg->evaluate(args);
		std::ostringstream str;
		str << "rgba(";
		str << int(color.r * 255.f) << ", ";
		str << int(color.g * 255.f) << ", ";
		str << int(color.b * 255.f) << ", ";
		str << color.a;
		str << ")";
		return str.str();
	}

	std::string FromNumber::evaluate(Arguments const& args) const
	{
		std::string str = std::to_string(mArg->evaluate(args));
		StripUnnecessaryZeros(str);
		return str;
	}

	std::string Get::evaluate(Arguments const& args) const
	{
		return At(mKey, args.properties, mFallback->evaluate(args));
	}

	size_t Slice::Clamp(IndexT pos, std::string const& input)
	{
		if (pos < 0)
		{
			size_t offset = static_cast<size_t>(std::abs(pos));
			if (offset < input.size())
			{
				return input.size() - offset;
			}
			else
			{
				return 0;
			}
		}
		else if (static_cast<size_t>(pos) < input.size())	 // cast is safe because of previous if-statement
		{
			return static_cast<size_t>(pos);
		}
		else
		{
			return input.size();
		}
	}

	std::string Slice::evaluate(Arguments const& args) const
	{
		// evaluate input expression
		std::string const input = mInput->evaluate(args);

		// compute beginning and end of the ranges
		size_t begin = Slice::Clamp(static_cast<IndexT>(mBegin->evaluate(args)), input);
		size_t end = Slice::Clamp(static_cast<IndexT>((mEnd) ? mEnd->evaluate(args) : input.size()), input);

		if (begin < end)
		{
			std::string ret;
			ret.reserve(end - begin);
			for (size_t i = begin; i < end; ++i)
			{
				ret.push_back(input[i]);
			}
			return ret;
		}
		else
		{
			return "";
		}
	}

	std::string Upcase::evaluate(Arguments const& args) const
	{
		std::string ret = mArg->evaluate(args);
		std::transform(ret.begin(), ret.end(), ret.begin(),
			[](unsigned char c) { return static_cast<std::string::value_type>(std::toupper(c)); }
		);
		return ret;
	}

} } } }