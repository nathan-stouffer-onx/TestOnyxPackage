#ifndef __STYLING_ASSERTS_EXPRESSIONS_H__
#define __STYLING_ASSERTS_EXPRESSIONS_H__

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {

	template<typename OutputT>
	class TypeAssertion final : public InstantiateExpressionTypes<OutputT>::OneArgType
	{
	public:

		using InstantiatedT = InstantiateExpressionTypes<OutputT>;

		TypeAssertion(typename InstantiatedT::Ptr input) : InstantiatedT::OneArgType(input) {}

		OutputT evaluate(Arguments const& args) const override
		{
			return this->mArg->evaluate(args);
		}

	};

	using BooleanAssertion = TypeAssertion<bool>;
	using ColorAssertion = TypeAssertion<lgal::Color>;
	using NumberAssertion = TypeAssertion<float>;
	using StringAssertion = TypeAssertion<std::string>;

} } }

#endif