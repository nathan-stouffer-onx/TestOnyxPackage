#include "ColorExpressions.h"

#include <System/Map3DException.h>

#include "Styling/Parse/ColorString.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Color {

	lgal::Color Get::evaluate(Arguments const& args) const
	{
		Arguments::PropertiesT::const_iterator iter = args.properties.find(mKey);
		if (iter != args.properties.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_string_value())
			{
				std::string const& str = val.string_value();
				return Parse::color(str);
			}
			else
			{
				MAP3D_THROW("Tile value for " + mKey + " must be a string but is a " + val.GetTypeName());
			}
		}
			
		// return default value
		return cDefaultColor;
	}

} } } }