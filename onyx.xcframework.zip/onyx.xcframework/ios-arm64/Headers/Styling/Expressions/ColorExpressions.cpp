#include "ColorExpressions.h"

#include <System/OnyxException.h>

#include "Styling/Parse/ColorString.h"

namespace onyx::Styling::Expressions::Color
{

	static lgal::Color At(std::string const& key, std::unordered_map<std::string, vector_tile::Tile_Value> const& values, lgal::Color const& fallback) 
	{
		Arguments::PropertiesT::const_iterator iter = values.find(key);
		if (iter != values.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_string_value())
			{
				std::string const& str = val.string_value();
				return Parse::color(str);
			}
			else
			{
				ONYX_THROW("Conversion from " + val.GetTypeName() + " to color not supported");
			}
		}
			
		// return fallback value
		return fallback;
	}

	lgal::Color FeatureState::evaluate(Arguments const& args) const
	{
		return At(mKey, args.state, mFallback ? mFallback->evaluate(args) : cDefaultColor);
	}

	lgal::Color FromString::evaluate(Arguments const& args) const
	{
		return Parse::color(mArg->evaluate(args));
	}

	lgal::Color Get::evaluate(Arguments const& args) const
	{
		return At(mKey, args.properties, mFallback ? mFallback->evaluate(args) : cDefaultColor);
	}

}