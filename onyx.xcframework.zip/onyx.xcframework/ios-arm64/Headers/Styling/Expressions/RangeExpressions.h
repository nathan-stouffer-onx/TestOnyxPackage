#pragma once

#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx::Styling::Expressions::Range
{

	class AmorphousRange final : public TwoArgExpressionBase<lgal::gpu::Range, float>
	{
	public:
		AmorphousRange(NumberT::Ptr begin, NumberT::Ptr end) : TwoArgExpressionBase<lgal::gpu::Range, float>(begin, end) {}
		lgal::gpu::Range evaluate(Arguments const& args) const override
		{
			return lgal::gpu::Range(mLHS->evaluate(args), mRHS->evaluate(args));
		}
	};

	using Case = Decision::CaseRange;
	using Constant = RangeT::ConstantType;
	using Context = ContextExpression<lgal::gpu::Range>;
	using Match = Decision::MatchRange;
	using Step = Interpolation::StepRange;

	inline RangeT::Ptr construct(lgal::gpu::Range const& range)
	{
		return std::make_unique<Constant const>(range);
	}

}