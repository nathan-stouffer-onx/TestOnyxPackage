#ifndef __STYLING_ARRAY_EXPRESSIONS_H__
#define __STYLING_ARRAY_EXPRESSIONS_H__

#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Array {

	template<typename T>
	class Constant final : public ArrayT<T>::NoChildType
	{
	public:
	
		Constant(std::vector<T> const& array) : mArray(array) {}
	
		std::vector<T> evaluate(Arguments const&) const override
		{
			return mArray;
		}
	
	private:
	
		std::vector<T> const mArray;
	
	};

	template<typename T>
	class AmorphousArray final : public ArgListExpressionBase<std::vector<T>, T>
	{
	public:

		AmorphousArray(std::vector<ExpressionPtr<T>>&& expressions) : ArgListExpressionBase<std::vector<T>, T>(std::move(expressions)) {}

		std::vector<T> evaluate(Arguments const& args) const override
		{
			std::vector<T> result;
			result.reserve(this->mExpressions.size());
			for (ExpressionPtr<T> const& expr : this->mExpressions)
			{
				result.push_back(expr->evaluate(args));
			}
			return result;
		}
	};

	template<typename T> using Case = Decision::CaseArray<T>;
	template<typename T> using Match = Decision::MatchArray<T>;
	template<typename T> using Step = Interpolation::StepArray<T>;
	
	using Interpolate = Interpolation::Interpolate<std::vector<float>>;

	template<typename OutputEnumT>
	class DynamicEnum final : public OneArgExpressionBase<std::vector<OutputEnumT>, std::vector<std::string>>
	{
	public:

		DynamicEnum(StringArrayT::Ptr expr) : OneArgExpressionBase<std::vector<OutputEnumT>, std::vector<std::string>>(expr) {}

		std::vector<OutputEnumT> evaluate(Arguments const& args) const override
		{
			std::vector<std::string> const strings = this->mArg->evaluate(args);

			std::vector<OutputEnumT> result;
			result.reserve(strings.size());
			for (std::string_view const view : strings)
			{
				result.push_back(Utils::EnumStringConverter<OutputEnumT>::convert(view));
			}
			return result;
		}

	};

	template<typename T>
	inline typename ArrayT<T>::Ptr construct(std::vector<T> const& array)
	{
		return std::make_unique<Constant<T>>(array);
	}

} } } }

#endif