#ifndef __STYLING_ARRAY_EXPRESSIONS_H__
#define __STYLING_ARRAY_EXPRESSIONS_H__

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Array {

	template<typename T>
	class Constant final : public ArrayT<T>::Type
	{
	public:

		Constant(std::vector<T> const& array) : mArray(array) {}

		std::vector<T> evaluate(Arguments const&) const override
		{
			return mArray;
		}

	private:

		std::vector<T> const mArray;

	};

	template<typename T> using Step = Interpolation::StepArray<T>;
	template<typename T> using Case = Decision::CaseArray<T>;
	template<typename T> using Match = Decision::MatchArray<T>;

	template<typename T>
	inline typename ArrayT<T>::Ptr construct(std::vector<T> const& array)
	{
		return std::make_unique<Constant<T>>(array);
	}

} } } }

#endif