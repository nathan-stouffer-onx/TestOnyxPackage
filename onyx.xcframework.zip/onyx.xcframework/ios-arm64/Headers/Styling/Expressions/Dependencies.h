#ifndef __STYLING_EXPRESSIONS_DEPENDENCIES_H__
#define __STYLING_EXPRESSIONS_DEPENDENCIES_H__

#include <lucid/gal/Types.h>
#include <Utils/BitwiseEnumOperators.h>

namespace onyx {
namespace Styling {
namespace Expressions {
	
	enum class Dependencies : uint32_t
	{
		NONE			= 0,
		ZOOM			= 0x1,
		HEADING			= 0x2,
		PITCH			= 0x4,
		CONTEXT			= 0x8,
		FEATURE			= 0x10,
		FEATURE_STATE	= 0x20,
		DEVICE_DPI		= 0x40,
		ALL				= ZOOM | HEADING | PITCH | CONTEXT | FEATURE | FEATURE_STATE | DEVICE_DPI,
		UNSET			= 0xFFFFFFFF
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(Dependencies);

} } }

#endif // __STYLING_EXPRESSIONS_DEPENDENCIES_H__