#ifndef __STYLING_EXPRESSIONS_DEPENDENCIES_H__
#define __STYLING_EXPRESSIONS_DEPENDENCIES_H__

#include <lucid/gal/Types.h>
#include <Utils/BitwiseEnumOperators.h>

namespace onyx {
namespace Styling {
namespace Expressions {
	
	enum class Dependencies : uint32_t
	{
		NONE			= 0x00,
		ZOOM			= 0x01,
		HEADING			= 0x02,
		PITCH			= 0x04,
		CENTER_DISTANCE	= 0x08,
		CONTEXT			= 0x10,
		FEATURE			= 0x20,
		FEATURE_STATE	= 0x40,
		DEVICE_DPI		= 0x80,
		CAMERA			= ZOOM | HEADING | PITCH | CENTER_DISTANCE,
		ALL				= ZOOM | HEADING | PITCH | CENTER_DISTANCE | CONTEXT | FEATURE | FEATURE_STATE | DEVICE_DPI,
		UNSET			= 0xFFFFFFFF
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(Dependencies);

} } }

#endif // __STYLING_EXPRESSIONS_DEPENDENCIES_H__