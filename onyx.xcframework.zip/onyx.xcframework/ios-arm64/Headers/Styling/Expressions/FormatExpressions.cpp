#include "FormatExpressions.h"

#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Format {

	std::vector<ExpressionBase const*> AmorphousFormatted::children(InitArgs const&) const
	{
		std::vector<ExpressionBase const*> target;
		target.reserve(mSegments.size() * 4);
		for (auto const& segment : mSegments)
		{
			target.push_back(segment.text.get());
			if (segment.options.fontScale) { target.push_back(segment.options.fontScale.get()); }
			if (segment.options.font) { target.push_back(segment.options.font.get()); }
			if (segment.options.color) { target.push_back(segment.options.color.get()); }
		}
		return target;
	}

	Formatted AmorphousFormatted::evaluate(Arguments const& args) const
	{
		std::vector<Formatted::Segment> segments;
		segments.reserve(mSegments.size());
		for (auto const& amorphous : mSegments)
		{
			Formatted::Segment segment;
			segment.text = amorphous.text->evaluate(args);
			if (amorphous.options.fontScale) { segment.options.fontScale = amorphous.options.fontScale->evaluate(args); }
			if (amorphous.options.font) { segment.options.font = std::make_unique<std::vector<std::string>>(amorphous.options.font->evaluate(args)); }
			if (amorphous.options.color) { segment.options.color = std::make_unique<lgal::Color>(amorphous.options.color->evaluate(args)); }
			segments.push_back(std::move(segment));
		}
		return Formatted(std::move(segments));
	}

	FormattedT::Ptr construct(std::string const& str)
	{
		return construct(String::construct(str));
	}

	FormattedT::Ptr construct(StringT::Ptr str)
	{
		AmorphousFormatted::Segment segment{ std::move(str), AmorphousFormatted::Options() };
		std::vector<AmorphousFormatted::Segment> segments;
		segments.push_back(std::move(segment));
		return std::make_unique<AmorphousFormatted const>(std::move(segments));
	}

} } } }