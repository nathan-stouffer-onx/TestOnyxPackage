#include "NumberExpressions.h"

#include <System/Map3DException.h>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Number {

	float Get::evaluate(Arguments const& args) const
	{
		Arguments::PropertiesT::const_iterator iter = args.properties.find(mKey);
		if (iter != args.properties.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_int_value())
			{
				return static_cast<float>(val.int_value());
			}
			else if (val.has_sint_value())
			{
				return static_cast<float>(val.sint_value());
			}
			else if (val.has_uint_value())
			{
				return static_cast<float>(val.uint_value());
			}
			else if (val.has_float_value())
			{
				return val.float_value();
			}
			else if (val.has_double_value())
			{
				return static_cast<float>(val.double_value());
			}
			else
			{
				MAP3D_THROW("Tile value for " + mKey + " must be a number but is a " + val.GetTypeName());
				return 0.f;
			}
		}

		// return default value
		return cDefaultNumber;
	}

	float IndexOf::evaluate(Arguments const& args) const
	{
		// evaluate keyword/input expressions
		std::string keyword = mKeyword->evaluate(args);
		std::string input = mInput->evaluate(args);
		size_t begin = (mBegin) ? static_cast<size_t>(mBegin->evaluate(args)) : 0;

		size_t pos = input.find(keyword, begin);
		return (pos == std::string::npos) ? -1.0f : pos;
	}

} } } }