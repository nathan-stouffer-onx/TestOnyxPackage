#include "NumberExpressions.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Number {

	static float At(std::string const& key, std::unordered_map<std::string, vector_tile::Tile_Value> const& values, float const fallback)
	{
		Arguments::PropertiesT::const_iterator iter = values.find(key);
		if (iter != values.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_bool_value())
			{
				return (val.bool_value()) ? 1.f : 0.f;
			}
			else if (val.has_double_value())
			{
				return static_cast<float>(val.double_value());
			}
			else if (val.has_float_value())
			{
				return val.float_value();
			}
			else if (val.has_int_value())
			{
				return static_cast<float>(val.int_value());
			}
			else if (val.has_sint_value())
			{
				return static_cast<float>(val.sint_value());
			}
			else if (val.has_string_value())
			{
				return std::stof(val.string_value());
			}
			else if (val.has_uint_value())
			{
				return static_cast<float>(val.uint_value());
			}
			else
			{
				ONYX_THROW("Conversion from " + val.GetTypeName() + " to number not supported");
			}
		}

		// return fallback value
		return fallback;
	}

	float FeatureState::evaluate(Arguments const& args) const
	{
		return At(mKey, args.state, mFallback->evaluate(args));
	}

	float Get::evaluate(Arguments const& args) const
	{
		return At(mKey, args.properties, mFallback->evaluate(args));
	}

	float IndexOf::evaluate(Arguments const& args) const
	{
		// evaluate keyword/input expressions
		std::string keyword = mKeyword->evaluate(args);
		std::string input = mInput->evaluate(args);
		size_t begin = (mBegin) ? static_cast<size_t>(mBegin->evaluate(args)) : 0;

		size_t pos = input.find(keyword, begin);
		return (pos == std::string::npos) ? -1.0f : pos;
	}

} } } }