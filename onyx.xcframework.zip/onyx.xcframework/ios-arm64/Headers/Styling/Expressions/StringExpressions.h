#ifndef __STYLING_STRING_EXPRESSIONS_H__
#define __STYLING_STRING_EXPRESSIONS_H__

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {
	
	using Asserts = StringAssertion;
	using Case = Decision::CaseString;

	class Concat final : public StringT::Type
	{
	public:

		Concat(std::vector<StringT::Ptr>&& inputs) : mInputs(std::move(inputs)) {}

		std::string evaluate(Arguments const& args) const override;

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(mInputs.size());
			for (StringT::Ptr const& input : mInputs)
			{
				target.push_back(input.get());
			}
			return target;
		}

	private:

		std::vector<StringT::Ptr> const mInputs;

	};

	class Constant final : public StringT::NoChildType
	{
	public:

		Constant(std::string const& value) : mValue(value) {}
		Constant(std::string_view const value) : mValue(value) {}

		std::string evaluate(Arguments const&) const override
		{
			return mValue;
		}

	private:

		std::string const mValue;

	};
	
	using Context = ContextExpression<std::string>;

	class Downcase final : public StringT::OneArgType
	{
	public:

		Downcase(StringT::Ptr input) : StringT::OneArgType(input) {}

		std::string evaluate(Arguments const& args) const override;
	};

	class FeatureState final : public StringT::OneArgType
	{
	public:
		FeatureState(std::string const& key, StringT::Ptr fallback) : StringT::OneArgType(fallback, Dependencies::FEATURE_STATE), mKey(key) { }
		std::string evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		StringT::Ptr const& mFallback = mArg;
	};

	class FromBoolean final : public OneArgExpressionBase<std::string, bool>
	{
	public:
		FromBoolean(BooleanT::Ptr input) : OneArgExpressionBase<std::string, bool>(input) {}
		std::string evaluate(Arguments const& args) const override
		{
			return (mArg->evaluate(args)) ? "true" : "false";
		}
	};

	class FromColor final : public OneArgExpressionBase<std::string, lgal::Color>
	{
	public:
		FromColor(ColorT::Ptr input) : OneArgExpressionBase<std::string, lgal::Color>(input) {}
		std::string evaluate(Arguments const& args) const override;
	};

	class FromNumber final : public OneArgExpressionBase<std::string, float>
	{
	public:
		FromNumber(NumberT::Ptr input) : OneArgExpressionBase<std::string, float>(input) {}
		std::string evaluate(Arguments const& args) const override;
	};

	class FromString final : public OneArgExpressionBase<std::string, std::string>
	{
	public:
		FromString(StringT::Ptr input) : OneArgExpressionBase<std::string, std::string>(input) {}
		std::string evaluate(Arguments const& args) const override
		{
			return mArg->evaluate(args);
		}
	};

	class Get final : public StringT::OneArgType
	{
	public:
		Get(std::string const& key, StringT::Ptr fallback) : StringT::OneArgType(fallback, Dependencies::FEATURE), mKey(key) { }
		std::string evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		StringT::Ptr const& mFallback = mArg;
	};

	using Match = Decision::MatchString;

	class Slice final : public StringT::Type
	{
	public:

		using IndexT = int;

	public:

		// NOTE: slice range is [begin, end)
		Slice(StringT::Ptr input, NumberT::Ptr begin, NumberT::Ptr end = nullptr) :
			mInput(std::move(input)),
			mBegin(std::move(begin)),
			mEnd(std::move(end))
		{}

		std::string evaluate(Arguments const& args) const override;

	public:

		static size_t Clamp(IndexT pos, std::string const& input);

		std::vector<ExpressionBase const*> children(InitArgs const& /*args*/) const override
		{
			return { mInput.get(), mBegin.get(), mEnd.get() };
		}

	private:

		StringT::Ptr const mInput;
		NumberT::Ptr const mBegin;
		NumberT::Ptr const mEnd;

	};

	using Step = Interpolation::StepString;

	class Upcase final : public StringT::OneArgType
	{
	public:

		Upcase(StringT::Ptr input) : StringT::OneArgType(input) {}

		std::string evaluate(Arguments const& args) const override;
	};
	
	inline StringT::Ptr construct(std::string_view const str)
	{
		return std::make_unique<Constant const>(str);
	}

} } } }

#endif