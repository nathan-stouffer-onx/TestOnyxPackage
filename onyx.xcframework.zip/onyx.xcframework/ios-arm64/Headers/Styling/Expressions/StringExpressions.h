#ifndef __STYLING_STRING_EXPRESSIONS_H__
#define __STYLING_STRING_EXPRESSIONS_H__

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {

	using Context = ContextExpression<std::string>;

	class Constant final : public StringT::Type
	{
	public:

		Constant(std::string const& value) : mValue(value) {}
		Constant(std::string_view const value) : mValue(value) {}

		std::string evaluate(Arguments const&) const override
		{
			return mValue;
		}

	private:

		std::string const mValue;

	};

	class Get final : public StringT::Type
	{
	public:

		Get(std::string const& key) : StringT::Type(ModificationFlags::FEATURE), mKey(key) { }

		std::string evaluate(Arguments const& args) const override;

	private:

		std::string const mKey;
	};

	// TODO (stouff) implement concat expression

	class Downcase final : public StringT::OneArgType
	{
	public:

		Downcase(StringT::Ptr input) : StringT::OneArgType(input) {}

		std::string evaluate(Arguments const& args) const override;
	};

	class Upcase final : public StringT::OneArgType
	{
	public:

		Upcase(StringT::Ptr input) : StringT::OneArgType(input) {}

		std::string evaluate(Arguments const& args) const override;
	};

	class Slice final : public StringT::Type
	{
	public:

		using IndexT = int;

	public:

		// NOTE: slice range is [begin, end)
		Slice(StringT::Ptr input, NumberT::Ptr begin, NumberT::Ptr end = nullptr) :
			mInput(std::move(input)),
			mBegin(std::move(begin)),
			mEnd(std::move(end))
		{}

		std::string evaluate(Arguments const& args) const override;

	public:

		static size_t Clamp(IndexT pos, std::string const& input);

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const& /*args*/) const override
		{
			target.push_back(mInput.get());
			target.push_back(mBegin.get());
			target.push_back(mEnd.get());
		}

	private:

		StringT::Ptr const mInput;
		NumberT::Ptr const mBegin;
		NumberT::Ptr const mEnd;

	};

	using Step = Interpolation::StepString;
	using Case = Decision::CaseString;
	using Match = Decision::MatchString;
	
	inline StringT::Ptr construct(std::string_view const str)
	{
		return std::make_unique<Constant const>(str);
	}

} } } }

#endif