#include "Expressions.h"

namespace lgigl = lucid::gigl;
namespace prim = lucid::gigl::primitives;

namespace onyx::Styling::Expressions
{

	Arguments::PropertiesT Arguments::sProperties;
	Arguments::FeatureStateT Arguments::sState;

}

namespace onyx::Styling::Expressions::primitives
{

	lgigl::PrimitiveInfo const ExpressionTypes::infos[ExpressionTypes::TYPE_COUNT] =
	{
		{ prim::GiglTypes::Type<prim::UNKNOWN							>::VALUE,	"<unknown>"				},
		{ prim::GiglTypes::Type<prim::UNDEFINED							>::VALUE,	"<undefined>"			},
		{ ExpressionTypes::Type<BooleanT::SharedPtr						>::VALUE,	"Boolean Expression"	},
		{ ExpressionTypes::Type<ColorT::SharedPtr						>::VALUE,	"Color Expression"		},
		{ ExpressionTypes::Type<FormattedT::SharedPtr					>::VALUE,	"Formatted Expression"	},
		{ ExpressionTypes::Type<GradientT::SharedPtr					>::VALUE,	"Gradient Expression"	},
		{ ExpressionTypes::Type<NumberT::SharedPtr						>::VALUE,	"Number Expression"		},
		{ ExpressionTypes::Type<RangeT::SharedPtr						>::VALUE,	"Range Expression"		},
		{ ExpressionTypes::Type<ResolvedImageT::SharedPtr				>::VALUE,	"Image Expression"		},
		{ ExpressionTypes::Type<StringT::SharedPtr						>::VALUE,	"String Expression"		},
	};

}