#ifndef __STYLING_DECISION_EXPRESSIONS_H__
#define __STYLING_DECISION_EXPRESSIONS_H__

#include <cmath>

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Decision {

	template<typename OutputT>
	class Case final : public ExpressionType<OutputT>
	{
	public:

		using OutputExpressionT = typename InstantiateExpressionTypes<OutputT>::Ptr;

		struct Pair
		{
			BooleanT::Ptr condition;
			OutputExpressionT output;
		};

	public:

		Case(std::vector<Pair>&& pairs, OutputExpressionT fallback) : mPairs(std::move(pairs)), mFallback(std::move(fallback)) {}

		OutputT evaluate(Arguments const& args) const override
		{
			// iterate over pairs searching for an expression that evaluates to true
			for (Pair const& pair : mPairs)
			{
				if (pair.condition->evaluate(args))
				{
					return pair.output->evaluate(args);
				}
			}

			// resort to fallback if no expression is true
			return mFallback->evaluate(args);
		}

		std::vector<ExpressionBase const*> children(InitArgs const& /*args*/) const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(mPairs.size());
			for (Pair const& pair : mPairs)
			{
				target.push_back(pair.condition.get());
				target.push_back(pair.output.get());
			}
			target.push_back(mFallback.get());
			return target;
		}

	private:

		std::vector<Pair> const mPairs;
		OutputExpressionT const mFallback;

	};

	using CaseBoolean = Case<bool>;
	using CaseColor = Case<lgal::Color>;
	using CaseFormatted = Case<Formatted>;
	using CaseNumber = Case<float>;
	using CaseRange = Case<lgal::gpu::Range>;
	using CaseResolvedImage = Case<ResolvedImage>;
	using CaseString = Case<std::string>;
	using CaseGradient = Case<Utils::Gradient>;

	template<typename T>
	using CaseArray = Case<std::vector<T>>;

	template<typename OutputT>
	class Matcher
	{
	public:

		virtual ~Matcher() {}

		virtual OutputT match(Arguments const& args) const = 0;

		virtual std::vector<ExpressionBase const*> getExpressions() const = 0;

	};

	template<typename InputT, typename OutputT>
	class DerivedMatcher final : public Matcher<OutputT>
	{
	public:

		using Labels = std::vector<InputT>;
		using InputExprT = typename InstantiateExpressionTypes<InputT>::Ptr;
		using OutputExprT = typename InstantiateExpressionTypes<OutputT>::Ptr;

		struct Pair
		{
			Labels labels;
			OutputExprT output;
		};

	public:

		DerivedMatcher(InputExprT input, std::vector<Pair>&& pairs, OutputExprT fallback) : mInput(std::move(input)), mPairs(std::move(pairs)), mFallback(std::move(fallback)) {}

		OutputT match(Arguments const& args) const override
		{
			InputT input = mInput->evaluate(args);
			for (Pair const& pair : mPairs)
			{
				for (InputT const& label : pair.labels)
				{
					if (input == label)
					{
						return pair.output->evaluate(args);
					}
				}
			}

			return mFallback->evaluate(args);
		}

		std::vector<ExpressionBase const*> getExpressions() const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(mPairs.size() + 2);
			target.push_back(mInput.get());
			for (auto const& pair : mPairs)
			{
				target.push_back(pair.output.get());
			}
			target.push_back(mFallback.get());
			return target;
		}

	private:

		InputExprT const mInput;
		std::vector<Pair> const mPairs;
		OutputExprT const mFallback;

	};

	template<typename OutputT>
	class Match final : public ExpressionType<OutputT>
	{
	public:

		Match(std::unique_ptr<Matcher<OutputT> const> matcher) : mMatcher(std::move(matcher)) {}

		OutputT evaluate(Arguments const& args) const override
		{
			return mMatcher->match(args);
		}

		std::vector<ExpressionBase const*> children(InitArgs const& /* args */) const override
		{
			return mMatcher->getExpressions();
		}

	private:

		std::unique_ptr<Matcher<OutputT> const> const mMatcher;

	};

	using MatchBoolean = Match<bool>;
	using MatchColor = Match<lgal::Color>;
	using MatchFormatted = Match<Formatted>;
	using MatchNumber = Match<float>;
	using MatchRange = Match<lgal::gpu::Range>;
	using MatchResolvedImage = Match<ResolvedImage>;
	using MatchString = Match<std::string>;
	using MatchGradient = Match<Utils::Gradient>;

	template<typename T>
	using MatchArray = Match<std::vector<T>>;

} } } }

#endif