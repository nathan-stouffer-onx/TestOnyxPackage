#ifndef __STYLING_FORMAT_EXPRESSIONS_H__
#define __STYLING_FORMAT_EXPRESSIONS_H__

#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Format {

	class AmorphousFormatted final : public FormattedT::Type
	{
	public:

		struct Options
		{
			NumberT::Ptr fontScale = nullptr;
			StringArrayT::Ptr font = nullptr;
			ColorT::Ptr color = nullptr;
		};

		struct Segment
		{
			StringT::Ptr text;
			Options options;
		};

	public:

		AmorphousFormatted(std::vector<Segment>&& segments) : FormattedT::Type(Dependencies::NONE), mSegments(std::move(segments)) {}
		
		std::vector<ExpressionBase const*> children(InitArgs const& args) const override;
		Formatted evaluate(Arguments const& args) const override;
	
	private:
	
		std::vector<Segment> mSegments;
	
	};

	using Case = Decision::CaseFormatted;
	using Context = ContextExpression<Formatted>;
	using Match = Decision::MatchFormatted;
	using Step = Interpolation::StepFormatted;

	FormattedT::Ptr construct(std::string const& formatted);
	FormattedT::Ptr construct(StringT::Ptr str);

} } } }

#endif