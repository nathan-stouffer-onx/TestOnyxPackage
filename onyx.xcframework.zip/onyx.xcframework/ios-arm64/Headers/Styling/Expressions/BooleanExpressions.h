#ifndef __STYLING_BOOLEAN_EXPRESSIONS_H__
#define __STYLING_BOOLEAN_EXPRESSIONS_H__

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {

	class All final : public BooleanT::ArgListType
	{
	public:
		All(std::vector<BooleanT::Ptr>&& expressions) : BooleanT::ArgListType(std::move(expressions)) {}
		bool evaluate(Arguments const& args) const override
		{
			if (mExpressions.empty())
			{
				return false;
			}
			else
			{
				for (BooleanT::Ptr const& expr : mExpressions)
				{
					if (!expr->evaluate(args))
						return false;
				}
				return true;
			}
		}
	};

	class Any final : public BooleanT::ArgListType
	{
	public:
		Any(std::vector<BooleanT::Ptr>&& expressions) : BooleanT::ArgListType(std::move(expressions)) {}
		bool evaluate(Arguments const& args) const override
		{
			if (mExpressions.empty())
			{
				return false;
			}
			else
			{
				for (BooleanT::Ptr const& expr : mExpressions)
				{
					if (expr->evaluate(args))
						return true;
				}
				return false;
			}
		}
	};

	using Asserts = BooleanAssertion;
	using Case = Decision::CaseBoolean;
	using Context = ContextExpression<bool>;
	using Constant = BooleanT::ConstantType;

	template <typename ExpressionT>
	class Equals final : public TwoArgExpressionBase<bool, ExpressionT>
	{
	public:
		Equals(ExpressionPtr<ExpressionT> lhs, ExpressionPtr<ExpressionT> rhs) : TwoArgExpressionBase<bool, ExpressionT>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			auto lhs = this->mLHS->evaluate(args);
			auto rhs = this->mRHS->evaluate(args);
			return lhs == rhs;
		}
	};

	class FeatureState final : public BooleanT::OneArgType
	{
	public:
		FeatureState(std::string const& key, BooleanT::Ptr fallback) : BooleanT::OneArgType(fallback, Dependencies::FEATURE_STATE), mKey(key) { }
		bool evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		BooleanT::Ptr const& mFallback = mArg;
	};

	class FromBoolean final : public OneArgExpressionBase<bool, bool>
	{
	public:
		FromBoolean(BooleanT::Ptr input) : OneArgExpressionBase<bool, bool>(input) {}
		bool evaluate(Arguments const& args) const override
		{
			return mArg->evaluate(args);
		}
	};

	class FromNumber final : public OneArgExpressionBase<bool, float>
	{
	public:
		FromNumber(NumberT::Ptr input) : OneArgExpressionBase<bool, float>(input) {}
		bool evaluate(Arguments const& args) const override;
	};

	class FromString final : public OneArgExpressionBase<bool, std::string>
	{
	public:
		FromString(StringT::Ptr input) : OneArgExpressionBase<bool, std::string>(input) {}
		bool evaluate(Arguments const& args) const override;
	};

	class Get final : public BooleanT::OneArgType
	{
	public:
		Get(std::string const& key, BooleanT::Ptr fallback) : BooleanT::OneArgType(fallback, Dependencies::FEATURE),  mKey(key) { }
		bool evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		BooleanT::Ptr const& mFallback = mArg;
	};

	class Has final : public BooleanT::NoChildType
	{
	public:
		Has(std::string const& key) : BooleanT::NoChildType(Dependencies::FEATURE),  mKey(key) { }
		bool evaluate(Arguments const& args) const override
		{
			Arguments::PropertiesT::const_iterator iter = args.properties.find(mKey);
			return iter != args.properties.end();
		}
	private:
		std::string const mKey;
	};

	using Match = Decision::MatchBoolean;

	// NOTE: I would have chose Not but 'not' is a preprocessor macro in some compilers
	class Negate final : public BooleanT::OneArgType
	{
	public:
		Negate(BooleanT::Ptr expression) : BooleanT::OneArgType(expression) {}
		bool evaluate(Arguments const& args) const override
		{
			return !mArg->evaluate(args);
		}
	};

	template <typename ExpressionT>
	class NotEquals final : public TwoArgExpressionBase<bool, ExpressionT>
	{
	public:
		NotEquals(ExpressionPtr<ExpressionT> lhs, ExpressionPtr<ExpressionT> rhs) : TwoArgExpressionBase<bool, ExpressionT>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return this->mLHS->evaluate(args) != this->mRHS->evaluate(args);
		}
	};

	class NumberGEQ final : public TwoArgExpressionBase<bool, float>
	{
	public:
		NumberGEQ(NumberT::Ptr lhs, NumberT::Ptr rhs) : TwoArgExpressionBase<bool, float>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) >= mRHS->evaluate(args);
		}
	};

	class NumberGreaterThan final : public TwoArgExpressionBase<bool, float>
	{
	public:
		NumberGreaterThan(NumberT::Ptr lhs, NumberT::Ptr rhs) : TwoArgExpressionBase<bool, float>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) > mRHS->evaluate(args);
		}
	};

	class NumberLessThan final : public TwoArgExpressionBase<bool, float>
	{
	public:
		NumberLessThan(NumberT::Ptr lhs, NumberT::Ptr rhs) : TwoArgExpressionBase<bool, float>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) < mRHS->evaluate(args);
		}
	};

	class NumberLEQ final : public TwoArgExpressionBase<bool, float>
	{
	public:
		NumberLEQ(NumberT::Ptr lhs, NumberT::Ptr rhs) : TwoArgExpressionBase<bool, float>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) <= mRHS->evaluate(args);
		}
	};
	
	using Step = Interpolation::StepBoolean;

	class StringGEQ final : public TwoArgExpressionBase<bool, std::string>
	{
	public:
		StringGEQ(StringT::Ptr lhs, StringT::Ptr rhs) : TwoArgExpressionBase<bool, std::string>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args).compare(mRHS->evaluate(args)) >= 0;
		}
	};

	class StringGreaterThan final : public TwoArgExpressionBase<bool, std::string>
	{
	public:
		StringGreaterThan(StringT::Ptr lhs, StringT::Ptr rhs) : TwoArgExpressionBase<bool, std::string>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args).compare(mRHS->evaluate(args)) > 0;
		}
	};

	class StringLessThan final : public TwoArgExpressionBase<bool, std::string>
	{
	public:
		StringLessThan(StringT::Ptr lhs, StringT::Ptr rhs) : TwoArgExpressionBase<bool, std::string>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args).compare(mRHS->evaluate(args)) < 0;
		}
	};

	class StringLEQ final : public TwoArgExpressionBase<bool, std::string>
	{
	public:
		StringLEQ(StringT::Ptr lhs, StringT::Ptr rhs) : TwoArgExpressionBase<bool, std::string>(lhs, rhs) {}
		bool evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args).compare(mRHS->evaluate(args)) <= 0;
		}
	};

	inline BooleanT::Ptr construct(bool value)
	{
		return std::make_unique<Constant const>(value);
	}

} } } }

#endif