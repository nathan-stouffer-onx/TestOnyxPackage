#include "BooleanExpressions.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {

	template<typename T>
	static bool IsNotZero(T const x)
	{
		return x != T(0);
	}
	
	static bool At(std::string const& key, std::unordered_map<std::string, vector_tile::Tile_Value> const& values, bool const fallback)
	{
		Arguments::PropertiesT::const_iterator iter = values.find(key);
		if (iter != values.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_bool_value())
			{
				return val.bool_value();
			}
			else if (val.has_double_value())
			{
				return IsNotZero(val.double_value());
			}
			else if (val.has_float_value())
			{
				return IsNotZero(val.float_value());
			}
			else if (val.has_int_value())
			{
				return IsNotZero(val.int_value());
			}
			else if (val.has_sint_value())
			{
				return IsNotZero(val.sint_value());
			}
			else if (val.has_string_value())
			{
				return val.string_value() != "";
			}
			else if (val.has_uint_value())
			{
				return IsNotZero(val.uint_value());
			}
			else
			{
				ONYX_THROW("Conversion from " + val.GetTypeName() + " to boolean not supported");
			}
		}

		// return fallback value
		return fallback;
	}

	bool FeatureState::evaluate(Arguments const& args) const
	{
		return At(mKey, args.state, mFallback->evaluate(args));
	}

	bool FromNumber::evaluate(Arguments const& args) const
	{
		return IsNotZero(mArg->evaluate(args));
	}

	bool FromString::evaluate(Arguments const& args) const
	{
		return mArg->evaluate(args) != "";
	}

	bool Get::evaluate(Arguments const& args) const
	{
		return At(mKey, args.properties, mFallback->evaluate(args));
	}

} } } }