#include "BooleanExpressions.h"

#include <System/Map3DException.h>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {

	bool Get::evaluate(Arguments const& args) const
	{
		Arguments::PropertiesT::const_iterator iter = args.properties.find(mKey);
		if (iter != args.properties.end())
		{
			vector_tile::Tile_Value const& val = iter->second;
			if (val.has_bool_value())
			{
				return val.bool_value();
			}
			else
			{
				MAP3D_THROW("Tile value for " + mKey + "  must be a boolean but is a " + val.GetTypeName());
			}
		}

		// return default value
		return cDefaultBoolean;
	}

} } } }