#ifndef __STYLING_INTERPOLATION_EXPRESSIONS_H__
#define __STYLING_INTERPOLATION_EXPRESSIONS_H__

#include <cmath>

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Interpolation {

	/*
	* Abstract base class that declares a function with the ability to interpolate between two Stops.
	* Derived classes implement this function in different manners (eg step, linear, exponential)
	*/

	template<typename T>
	class Interpolator
	{
	public:

		struct Stop
		{
			float input;
			T output;
		};

	public:

		virtual ~Interpolator() {}

		virtual T interpolate(Stop const& left, Stop const& right, float input) const = 0;

	};

	template<typename T>
	class StepInterpolator final : public Interpolator<T>
	{
	public:

		using typename Interpolator<T>::Stop;

		T interpolate(Stop const& left, Stop const& /* right */, float /* input */) const override
		{
			return left.output;
		}

	};

	template<typename T>
	class LinearInterpolator final : public Interpolator<T>
	{
	public:

		using typename Interpolator<T>::Stop;

		T interpolate(Stop const& left, Stop const& right, float input) const override
		{
			float t = (input - left.input) / (right.input - left.input);
			return lmath::lerp(left.output, right.output, t);
		}

	};

	// Full template specialization of LinearInterpolator for vectors
	template<> class LinearInterpolator<std::vector<float>> final : public Interpolator<std::vector<float>>
	{
	public:

		using typename Interpolator<std::vector<float>>::Stop;

		std::vector<float> interpolate(Stop const& left, Stop const& right, float input) const override
		{
			size_t size = std::max(left.output.size(), right.output.size());

			std::vector<float> output;
			output.reserve(size);

			float t = (input - left.input) / (right.input - left.input);
			for (size_t i = 0; i < size; ++i)
			{
				// assign left and right based on array length (if one array isn't long enough, this will be idempotent on the tail
				// of the longer array)
				float l = (i < left.output.size()) ? left.output[i] : right.output[i];
				float r = (i < right.output.size()) ? right.output[i] : left.output[i];
				output.push_back(lmath::lerp(l, r, t));
			}

			return output;
		}

	};

	template<typename T>
	class ExponentialInterpolator final : public Interpolator<T>
	{
	public:

		using typename Interpolator<T>::Stop;

		ExponentialInterpolator(float base) : mBase(base) {}

		T interpolate(Stop const& left, Stop const& right, float input) const override
		{
			if (mBase == 1.f)
			{
				float t = (input - left.input) / (right.input - left.input);
				return lmath::lerp(left.output, right.output, t);
			}
			else
			{
				return lmath::exponerp(mBase, { left.input, left.output }, { right.input, right.output }, input);
			}
		}

	private:

		float const mBase;

	};

	// Full template specialization of ExponentialInterpolator for colors
	template<> class ExponentialInterpolator<lgal::Color> final : public Interpolator<lgal::Color>
	{
	public:

		using typename Interpolator<lgal::Color>::Stop;

		ExponentialInterpolator(float base) : mBase(base) {}

		lgal::Color interpolate(Stop const& left, Stop const& right, float input) const override
		{
			if (mBase == 1.f)
			{
				float t = (input - left.input) / (right.input - left.input);
				return lmath::lerp(left.output, right.output, t);
			}
			else
			{
				lgal::Color color = 
				{
					lmath::exponerp(mBase, { left.input, left.output.r }, { right.input, right.output.r }, input),
					lmath::exponerp(mBase, { left.input, left.output.g }, { right.input, right.output.g }, input),
					lmath::exponerp(mBase, { left.input, left.output.b }, { right.input, right.output.b }, input),
					lmath::exponerp(mBase, { left.input, left.output.a }, { right.input, right.output.a }, input)
				};
				return color;
			}
		}

	private:

		float const mBase;

	};

	// Full template specialization of ExponentialInterpolator for vectors
	template<> class ExponentialInterpolator<std::vector<float>> final : public Interpolator<std::vector<float>>
	{
	public:

		using typename Interpolator<std::vector<float>>::Stop;

		ExponentialInterpolator(float base) : mBase(base) {}

		std::vector<float> interpolate(Stop const& left, Stop const& right, float input) const override
		{
			size_t size = std::max(left.output.size(), right.output.size());

			std::vector<float> output;
			output.reserve(size);
			
			float t = (input - left.input) / (right.input - left.input);
			for (size_t i = 0; i < size; ++i)
			{
				// assign left and right based on array length (if one array isn't long enough, this will be idempotent on the tail
				// of the longer array)
				float l = (i < left.output.size()) ? left.output[i] : right.output[i];
				float r = (i < right.output.size()) ? right.output[i] : left.output[i];
				if (mBase == 1.f)
				{
					output.push_back(lmath::lerp(l, r, t));
				}
				else
				{
					output.push_back(lmath::exponerp(mBase, { left.input, l }, { right.input, r }, input));
				}
			}

			return output;
		}

	private:

		float const mBase;

	};

	/*
	* Templated class to consolidate logic of selecting stops to use when interpolating
	*/

	template<typename T>
	class Interpolate : public TypedExpressionBase<T>
	{
	public:

		struct Stop
		{
			float input;
			std::unique_ptr<TypedExpressionBase<T> const> output;
		};

	public:

		Interpolate(std::unique_ptr<Interpolator<T> const> interpolator, NumberT::Ptr input, std::vector<Stop>&& stops) :
			mInterpolator(std::move(interpolator)),
			mInput(std::move(input)),
			mStops(std::move(stops))
		{}

		T evaluate(Arguments const& args) const override
		{
			float input = mInput->evaluate(args);
			if (input < mStops.front().input || mStops.size() == 1)	// return the front
			{
				return mStops.front().output->evaluate(args);
			}
			else if (input < mStops.back().input)	// stop range contains input, find pair to interpolate
			{
				size_t i = precedingIndex(input);

				Stop const& lhs = mStops[i];
				Stop const& rhs = mStops[i + 1];

				typename Interpolator<T>::Stop lhsEvaluated = { lhs.input, lhs.output->evaluate(args) };
				typename Interpolator<T>::Stop rhsEvaluated = { rhs.input, rhs.output->evaluate(args) };

				return mInterpolator->interpolate(lhsEvaluated, rhsEvaluated, input);
			}
			else // return the back
			{
				return mStops.back().output->evaluate(args);
			}
		}

		std::vector<ExpressionBase const*> children(InitArgs const& /* args */) const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(mStops.size());
			for (auto const& stop : mStops)
			{
				target.push_back(stop.output.get());
			}
			return target;
		}

	private:

		std::unique_ptr<Interpolator<T> const> const mInterpolator;
		NumberT::Ptr const mInput;
		std::vector<Stop> const mStops;

		// should only be called if we know input is the inside the time range spanned by mStops
		size_t precedingIndex(float input) const
		{
			for (size_t i = 0; i + 1 < mStops.size(); ++i)
			{
				if (mStops[i].input <= input && input < mStops[i + 1].input)
				{
					return i;
				}
			}

			return std::numeric_limits<size_t>::max();
		}

	};

	using InterpolateColor = Interpolate<lgal::Color>;
	using InterpolateNumber = Interpolate<float>;
	using InterpolateNumberArray = Interpolate<std::vector<float>>;

	/*
	* Convenience class to denote a Step interpolator
	*/

	template<typename T>
	class Step : public Interpolate<T>
	{
	public:

		using typename Interpolate<T>::Stop;

		Step(std::unique_ptr<StepInterpolator<T> const> step, NumberT::Ptr input, std::vector<Stop>&& stops) :
			Interpolate<T>(std::move(step), std::move(input), std::move(stops)) {}

	};

	using StepBoolean = Step<bool>;
	using StepColor = Step<lgal::Color>;
	using StepFormatted = Step<Formatted>;
	using StepNumber = Step<float>;
	using StepRange = Step<lgal::gpu::Range>;
	using StepResolvedImage = Step<ResolvedImage>;
	using StepString = Step<std::string>;
	using StepGradient = Step<Utils::Gradient>;

	template<typename T>
	using StepArray = Step<std::vector<T>>;

} } } }

#endif