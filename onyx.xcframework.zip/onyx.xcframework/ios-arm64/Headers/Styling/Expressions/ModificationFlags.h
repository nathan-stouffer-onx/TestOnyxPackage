#ifndef STYLING_EXPRESSIONS_MODIFICATIONFLAGS_H
#define STYLING_EXPRESSIONS_MODIFICATIONFLAGS_H

#include <lucid/gal/Types.h>
#include <Utils/BitwiseEnumOperators.h>

namespace onyx {
namespace Styling {
namespace Expressions {

	enum class ModificationFlags : uint32_t {
		NONE		= 0,
		ZOOM		= 0x1,
		PITCH		= 0x2,
		CONTEXT		= 0x4,
		FEATURE		= 0x8,
		ALL			= ZOOM | PITCH | CONTEXT | FEATURE,
		UNSET		= 0xFFFFFFFF
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(ModificationFlags);

} } }

#endif // STYLING_EXPRESSIONS_MODIFICATIONFLAGS_H