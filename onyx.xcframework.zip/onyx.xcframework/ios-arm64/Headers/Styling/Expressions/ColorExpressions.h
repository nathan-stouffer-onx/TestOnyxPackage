#ifndef __STYLING_COLOR_EXPRESSIONS_H__
#define __STYLING_COLOR_EXPRESSIONS_H__

#include <memory>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Color {

	using Asserts = ColorAssertion;
	using Case = Decision::CaseColor;
	using Context = ContextExpression<lgal::Color>;
	using Constant = ColorT::ConstantType;

	class ExplicitHSL final : public ColorT::Type
	{
	public:

		ExplicitHSL(NumberT::Ptr h, NumberT::Ptr s, NumberT::Ptr l) :
			ColorT::Type(Dependencies::NONE), mH(std::move(h)), mS(std::move(s)), mL(std::move(l))
		{}

		lgal::Color evaluate(Arguments const& args) const override
		{
			float h = lmath::degreesToRadians(mH->evaluate(args));
			float s = mS->evaluate(args) / 100.f;
			float l = mL->evaluate(args) / 100.f;
			return lgal::HSL{ h, s, l, 1.f };
		}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			return { mH.get(), mS.get(), mL.get() };
		}

	private:

		NumberT::Ptr mH;
		NumberT::Ptr mS;
		NumberT::Ptr mL;

	};

	class ExplicitHSLA final : public ColorT::Type
	{
	public:

		ExplicitHSLA(NumberT::Ptr h, NumberT::Ptr s, NumberT::Ptr l, NumberT::Ptr a) :
			ColorT::Type(Dependencies::NONE), mH(std::move(h)), mS(std::move(s)), mL(std::move(l)), mA(std::move(a))
		{}

		lgal::Color evaluate(Arguments const& args) const override
		{
			float h = lmath::degreesToRadians(mH->evaluate(args));
			float s = mS->evaluate(args) / 100.f;
			float l = mL->evaluate(args) / 100.f;
			float a = mA->evaluate(args);
			return lgal::HSL{ h, s, l, a };
		}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			return { mH.get(), mS.get(), mL.get(), mA.get() };
		}

	private:

		NumberT::Ptr mH;
		NumberT::Ptr mS;
		NumberT::Ptr mL;
		NumberT::Ptr mA;

	};

	class ExplicitRGB final : public ColorT::Type
	{
	public:

		ExplicitRGB(NumberT::Ptr r, NumberT::Ptr g, NumberT::Ptr b) :
			ColorT::Type(Dependencies::NONE), mR(std::move(r)), mG(std::move(g)), mB(std::move(b))
		{}

		lgal::Color evaluate(Arguments const& args) const override
		{
			float r = mR->evaluate(args) / 255.f;
			float g = mG->evaluate(args) / 255.f;
			float b = mB->evaluate(args) / 255.f;
			return lgal::Color{ r, g, b, 1.f };
		}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			return { mR.get(), mG.get(), mB.get() };
		}

	private:

		NumberT::Ptr mR;
		NumberT::Ptr mG;
		NumberT::Ptr mB;

	};

	class ExplicitRGBA final : public ColorT::Type
	{
	public:

		ExplicitRGBA(NumberT::Ptr r, NumberT::Ptr g, NumberT::Ptr b, NumberT::Ptr a) :
			ColorT::Type(Dependencies::NONE), mR(std::move(r)), mG(std::move(g)), mB(std::move(b)), mA(std::move(a))
		{}

		lgal::Color evaluate(Arguments const& args) const override
		{
			float r = mR->evaluate(args) / 255.f;
			float g = mG->evaluate(args) / 255.f;
			float b = mB->evaluate(args) / 255.f;
			float a = mA->evaluate(args);
			return lgal::Color{ r, g, b, a };
		}

		std::vector<ExpressionBase const*> children(InitArgs const&) const override
		{
			return { mR.get(), mG.get(), mB.get(), mA.get() };
		}

	private:

		NumberT::Ptr mR;
		NumberT::Ptr mG;
		NumberT::Ptr mB;
		NumberT::Ptr mA;

	};

	class FeatureState final : public ColorT::OneArgType
	{
	public:
		FeatureState(std::string const& key, ColorT::Ptr fallback) : ColorT::OneArgType(fallback, Dependencies::FEATURE_STATE), mKey(key) { }
		lgal::Color evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		ColorT::Ptr const& mFallback = mArg;
	};

	class FromColor final : public OneArgExpressionBase<lgal::Color, lgal::Color>
	{
	public:
		FromColor(ColorT::Ptr input) : OneArgExpressionBase<lgal::Color, lgal::Color>(input) {}
		lgal::Color evaluate(Arguments const& args) const override
		{
			return mArg->evaluate(args);
		}
	};

	class FromString final : public OneArgExpressionBase<lgal::Color, std::string>
	{
	public:
		FromString(StringT::Ptr input) : OneArgExpressionBase<lgal::Color, std::string>(input) {}
		lgal::Color evaluate(Arguments const& args) const override;
	};

	class Get final : public ColorT::OneArgType
	{
	public:
		Get(std::string const& key, ColorT::Ptr fallback) : ColorT::OneArgType(fallback, Dependencies::FEATURE), mKey(key) { }
		lgal::Color evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		ColorT::Ptr const& mFallback = mArg;
	};

	using Interpolate = Interpolation::Interpolate<lgal::Color>;
	using Match = Decision::MatchColor;
	using Step = Interpolation::StepColor;

	inline ColorT::Ptr construct(lgal::Color color)
	{
		return std::make_unique<Constant const>(color);
	}

} } } }

#endif