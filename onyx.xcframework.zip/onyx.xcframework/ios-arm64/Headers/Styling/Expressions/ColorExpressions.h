#ifndef __STYLING_COLOR_EXPRESSIONS_H__
#define __STYLING_COLOR_EXPRESSIONS_H__

#include <memory>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Color {

	using Context = ContextExpression<lgal::Color>;
	using Constant = ColorT::ConstantType;

	class Get final : public ColorT::Type
	{
	public:

		Get(std::string const& key) : ColorT::Type(ModificationFlags::FEATURE), mKey(key) { }

		lgal::Color evaluate(Arguments const& args) const override;

	private:

		std::string const mKey;
	};

	using Interpolate = Interpolation::Interpolate<lgal::Color>;

	using Step = Interpolation::StepColor;
	using Case = Decision::CaseColor;
	using Match = Decision::MatchColor;

	inline ColorT::Ptr construct(lgal::Color color)
	{
		return std::make_unique<Constant const>(color);
	}

} } } }

#endif