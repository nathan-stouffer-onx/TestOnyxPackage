#ifndef __STYLING_ENUM_EXPRESSIONS_H__
#define __STYLING_ENUM_EXPRESSIONS_H__

#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Enum {

	template<typename OutputEnumT>
	class Constant final : public EnumT<OutputEnumT>::NoChildType
	{
	public:

		Constant(OutputEnumT value) : mValue(value) {}

		OutputEnumT evaluate(Arguments const&) const override
		{
			return mValue;
		}

	private:

		OutputEnumT const mValue;

	};

	template<typename OutputEnumT>
	class Dynamic final : public OneArgExpressionBase<OutputEnumT, std::string>
	{
	public:

		Dynamic(StringT::Ptr expr) : OneArgExpressionBase<OutputEnumT, std::string>(expr) {}

		OutputEnumT evaluate(Arguments const& args) const override
		{
			std::string const view = this->mArg->evaluate(args);
			return Utils::EnumStringConverter<OutputEnumT>::convert(view);
		}

	};

	template<typename OutputEnumT>
	inline typename EnumT<OutputEnumT>::Ptr construct(OutputEnumT value)
	{
		return std::make_unique<Constant<OutputEnumT> const>(value);
	}

} } } }

#endif