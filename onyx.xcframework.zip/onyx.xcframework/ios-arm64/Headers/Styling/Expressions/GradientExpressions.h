#ifndef __STYLING_GRADIENT_EXPRESSIONS_H__
#define __STYLING_GRADIENT_EXPRESSIONS_H__

#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Gradient {

	using Case = Decision::CaseGradient;
	using Constant = GradientT::ConstantType;
	using Context = ContextExpression<Utils::Gradient>;
	using Match = Decision::MatchGradient;
	using Step = Interpolation::StepGradient;

	inline GradientT::Ptr construct(Utils::Gradient const& gradient)
	{
		return std::make_unique<Constant const>(gradient);
	}

} } } }

#endif