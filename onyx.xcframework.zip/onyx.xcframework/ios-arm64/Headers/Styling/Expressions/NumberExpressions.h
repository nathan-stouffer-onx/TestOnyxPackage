#pragma once

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx::Styling::Expressions::Number
{

	class Abs final : public NumberT::OneArgType
	{
	public:

		Abs(NumberT::Ptr input) : NumberT::OneArgType(input) {}

		float evaluate(Arguments const& args) const override
		{
			return std::abs(mArg->evaluate(args));
		}

	};

	using Asserts = NumberAssertion;
	using Case = Decision::CaseNumber;
	using Context = ContextExpression<float>;
	using Constant = NumberT::ConstantType;

	class DistanceFromCenter final : public NumberT::NoChildType
	{
	public:

		DistanceFromCenter() : NumberT::NoChildType(Dependencies::CENTER_DISTANCE) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.centerDistance);
		}

	};

	class Divide final : public NumberT::TwoArgType
	{
	public:

		Divide(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) / mRHS->evaluate(args);
		}
	};

	class Exponentiate final : public NumberT::TwoArgType
	{
	public:

		Exponentiate(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			return std::pow(mLHS->evaluate(args), mRHS->evaluate(args));
		}
	};

	class FeatureState final : public NumberT::OneArgType
	{
	public:
		FeatureState(std::string const& key, NumberT::Ptr fallback) : NumberT::OneArgType(fallback, Dependencies::FEATURE_STATE), mKey(key) { }
		float evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		NumberT::Ptr const& mFallback = mArg;
	};

	class FromBoolean final : public OneArgExpressionBase<float, bool>
	{
	public:
		FromBoolean(BooleanT::Ptr input) : OneArgExpressionBase<float, bool>(input) {}
		float evaluate(Arguments const& args) const override
		{
			return (mArg->evaluate(args)) ? 1.f : 0.f;
		}
	};

	class FromNumber final : public OneArgExpressionBase<float, float>
	{
	public:
		FromNumber(NumberT::Ptr input) : OneArgExpressionBase<float, float>(input) {}
		float evaluate(Arguments const& args) const override
		{
			return mArg->evaluate(args);
		}
	};

	class FromString final : public OneArgExpressionBase<float, std::string>
	{
	public:
		FromString(StringT::Ptr input) : OneArgExpressionBase<float, std::string>(input) {}
		float evaluate(Arguments const& args) const override
		{
			return std::stof(mArg->evaluate(args));
		}
	};

	class Get final : public NumberT::OneArgType
	{
	public:
		Get(std::string const& key, NumberT::Ptr fallback) : NumberT::OneArgType(fallback, Dependencies::FEATURE), mKey(key) { }
		float evaluate(Arguments const& args) const override;
	private:
		std::string const mKey;
		NumberT::Ptr const& mFallback = mArg;
	};

	class Heading final : public NumberT::NoChildType
	{
	public:

		Heading() : NumberT::NoChildType(Dependencies::HEADING) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.heading);
		}
	};

	// NOTE: The return value is of type float so that this expression integrates nicely with other NumberT
	// expressions. We should be working with values small enough that floating point precision will never
	// be an issue
	class IndexOf final : public NumberT::Type
	{
	public:

		IndexOf(StringT::Ptr keyword, StringT::Ptr input, NumberT::Ptr begin = nullptr) :
			mKeyword(std::move(keyword)),
			mInput(std::move(input)),
			mBegin(std::move(begin))
		{}

		float evaluate(Arguments const& args) const override;

		std::vector<ExpressionBase const*> children(InitArgs const& /*args*/) const override
		{
			return { mKeyword.get(), mInput.get(), mBegin.get() };
		}

	private:

		StringT::Ptr const mKeyword;
		StringT::Ptr const mInput;
		NumberT::Ptr const mBegin;

	};

	using Interpolate = Interpolation::InterpolateNumber;

	// NOTE: The return value is of type float so that this expression integrates nicely with other NumberT
	// expressions. We should be working with values small enough that floating point precision will never
	// be an issue
	class Length final : public OneArgExpressionBase<float, std::string>
	{
	public:

		Length(StringT::Ptr input) : OneArgExpressionBase<float, std::string>(input) {}

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(mArg->evaluate(args).size());
		}
	};

	using Match = Decision::MatchNumber;

	class Modulo final : public NumberT::TwoArgType
	{
	public:

		Modulo(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			int mod = static_cast<int>(mLHS->evaluate(args)) % static_cast<int>(mRHS->evaluate(args));
			return static_cast<float>(mod);
		}
	};

	class Pitch final : public NumberT::NoChildType
	{
	public:

		Pitch() : NumberT::NoChildType(Dependencies::PITCH) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.pitch);
		}

	};

	class DpiScalar final : public NumberT::NoChildType
	{
	public:
		DpiScalar() : NumberT::NoChildType(Dependencies::DEVICE_DPI) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.dpiScalar);
		}
	};

	class Product final : public NumberT::Type
	{
	public:

		Product(NumberT::Ptr term0, NumberT::Ptr term1, std::vector<NumberT::Ptr>&& additional = {}) :
			mTerm0(std::move(term0)),
			mTerm1(std::move(term1)),
			mAdditionalTerms(std::move(additional))
		{}

		float evaluate(Arguments const& args) const override
		{
			float product = mTerm0->evaluate(args) * mTerm1->evaluate(args);
			for (NumberT::Ptr const& term : mAdditionalTerms)
			{
				product *= term->evaluate(args);
			}
			return product;
		}

		std::vector<ExpressionBase const*> children(InitArgs const& /*args*/) const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(2 + mAdditionalTerms.size());
			target.push_back(mTerm0.get());
			target.push_back(mTerm1.get());
			for (auto const& term : mAdditionalTerms)
			{
				target.push_back(term.get());
			}
			return target;
		}
	private:

		NumberT::Ptr const mTerm0;
		NumberT::Ptr const mTerm1;

		std::vector<NumberT::Ptr> const mAdditionalTerms;

	};

	using Step = Interpolation::StepNumber;

	class Subtract final : public NumberT::TwoArgType
	{
	public:

		Subtract(NumberT::Ptr term) : Subtract(std::make_unique<Constant>(0.f), std::move(term)) {}
		Subtract(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) - mRHS->evaluate(args);
		}
	};

	class Sum final : public NumberT::Type
	{
	public:

		Sum(NumberT::Ptr term0, NumberT::Ptr term1, std::vector<NumberT::Ptr>&& additional = {}) :
			mTerm0(std::move(term0)),
			mTerm1(std::move(term1)),
			mAdditionalTerms(std::move(additional))
		{}

		float evaluate(Arguments const& args) const override
		{
			float sum = mTerm0->evaluate(args) + mTerm1->evaluate(args);
			for (NumberT::Ptr const& term : mAdditionalTerms)
			{
				sum += term->evaluate(args);
			}
			return sum;
		}

		std::vector<ExpressionBase const*> children(InitArgs const& /*args*/) const override
		{
			std::vector<ExpressionBase const*> target;
			target.reserve(2 + mAdditionalTerms.size());
			target.push_back(mTerm0.get());
			target.push_back(mTerm1.get());
			for (auto const& term : mAdditionalTerms)
			{
				target.push_back(term.get());
			}
			return target;
		}
	private:

		NumberT::Ptr const mTerm0;
		NumberT::Ptr const mTerm1;

		std::vector<NumberT::Ptr> const mAdditionalTerms;

	};

	class Zoom final : public NumberT::NoChildType
	{
	public:

		Zoom() : NumberT::NoChildType(Dependencies::ZOOM) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.zoom);
		}

	};

	inline NumberT::Ptr construct(float value)
	{
		return std::make_unique<Constant const>(value);
	}

}