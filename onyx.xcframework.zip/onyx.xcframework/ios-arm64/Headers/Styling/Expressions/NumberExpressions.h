#ifndef __STYLING_NUMBER_EXPRESSIONS_H__
#define __STYLING_NUMBER_EXPRESSIONS_H__

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Number {

	using Context = ContextExpression<float>;
	using Constant = NumberT::ConstantType;

	class Pitch final : public NumberT::Type
	{
	public:

		Pitch() : NumberT::Type(ModificationFlags::PITCH) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.pitch);
		}

	};

	class Zoom final : public NumberT::Type
	{
	public:

		Zoom() : NumberT::Type(ModificationFlags::ZOOM) { }

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(args.zoom);
		}

	};

	// TODO (stouff) implement DistanceFromCenter expression

	class Get final : public NumberT::Type
	{
	public:

		Get(std::string const& key) : NumberT::Type(ModificationFlags::FEATURE), mKey(key) { }

		float evaluate(Arguments const& args) const override;

	private:

		std::string const mKey;
	};

	// NOTE: The return value is of type float so that this expression integrates nicely with other NumberT
	// expressions. We should be working with values small enough that floating point precision will never
	// be an issue
	class IndexOf final : public NumberT::Type
	{
	public:

		IndexOf(StringT::Ptr keyword, StringT::Ptr input, NumberT::Ptr begin = nullptr) :
			mKeyword(std::move(keyword)),
			mInput(std::move(input)),
			mBegin(std::move(begin))
		{}

		float evaluate(Arguments const& args) const override;

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const& /*args*/) const override
		{
			target.push_back(mKeyword.get());
			target.push_back(mInput.get());
			target.push_back(mBegin.get());
		}

	private:

		StringT::Ptr const mKeyword;
		StringT::Ptr const mInput;
		NumberT::Ptr const mBegin;

	};

	// NOTE: The return value is of type float so that this expression integrates nicely with other NumberT
	// expressions. We should be working with values small enough that floating point precision will never
	// be an issue
	class Length final : public OneArgExpressionBase<float, std::string>
	{
	public:

		Length(StringT::Ptr input) : OneArgExpressionBase<float, std::string>(input) {}

		float evaluate(Arguments const& args) const override
		{
			return static_cast<float>(mArg->evaluate(args).size());
		}
	};

	using Interpolate = Interpolation::InterpolateNumber;
	using Step = Interpolation::StepNumber;
	using Case = Decision::CaseNumber;
	using Match = Decision::MatchNumber;

	class Subtract final : public NumberT::TwoArgType
	{
	public:

		Subtract(NumberT::Ptr term) : Subtract(std::make_unique<Constant>(0.f), std::move(term)) {}
		Subtract(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) - mRHS->evaluate(args);
		}
	};

	class Product final : public NumberT::Type
	{
	public:

		Product(NumberT::Ptr term0, NumberT::Ptr term1, std::vector<NumberT::Ptr>&& additional = {}) :
			mTerm0(std::move(term0)),
			mTerm1(std::move(term1)),
			mAdditionalTerms(std::move(additional))
		{}

		float evaluate(Arguments const& args) const override
		{
			float product = mTerm0->evaluate(args) * mTerm1->evaluate(args);
			for (NumberT::Ptr const& term : mAdditionalTerms)
			{
				product *= term->evaluate(args);
			}
			return product;
		}

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const& /*args*/) const override
		{
			target.push_back(mTerm0.get());
			target.push_back(mTerm1.get());
			for (auto const& term : mAdditionalTerms)
			{
				target.push_back(term.get());
			}
		}
	private:

		NumberT::Ptr const mTerm0;
		NumberT::Ptr const mTerm1;

		std::vector<NumberT::Ptr> const mAdditionalTerms;

	};

	class Divide final : public NumberT::TwoArgType
	{
	public:

		Divide(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			return mLHS->evaluate(args) / mRHS->evaluate(args);
		}
	};

	class Modulo final : public NumberT::TwoArgType
	{
	public:

		Modulo(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			int mod = static_cast<int>(mLHS->evaluate(args)) % static_cast<int>(mRHS->evaluate(args));
			return static_cast<float>(mod);
		}
	};

	class Exponentiate final : public NumberT::TwoArgType
	{
	public:

		Exponentiate(NumberT::Ptr term0, NumberT::Ptr term1) : NumberT::TwoArgType(term0, term1) {}

		float evaluate(Arguments const& args) const override
		{
			return std::pow(mLHS->evaluate(args), mRHS->evaluate(args));
		}
	};

	class Sum final : public NumberT::Type
	{
	public:

		Sum(NumberT::Ptr term0, NumberT::Ptr term1, std::vector<NumberT::Ptr>&& additional = {}) :
			mTerm0(std::move(term0)),
			mTerm1(std::move(term1)),
			mAdditionalTerms(std::move(additional))
		{}

		float evaluate(Arguments const& args) const override
		{
			float product = mTerm0->evaluate(args) + mTerm1->evaluate(args);
			for (NumberT::Ptr const& term : mAdditionalTerms)
			{
				product += term->evaluate(args);
			}
			return product;
		}

		void getChildren(std::vector<ExpressionBase const*>& target, ValidationArguments const& /*args*/) const override
		{
			target.push_back(mTerm0.get());
			target.push_back(mTerm1.get());
			for (auto const& term : mAdditionalTerms)
			{
				target.push_back(term.get());
			}
		}
	private:

		NumberT::Ptr const mTerm0;
		NumberT::Ptr const mTerm1;

		std::vector<NumberT::Ptr> const mAdditionalTerms;

	};

	inline NumberT::Ptr construct(float value)
	{
		return std::make_unique<Constant const>(value);
	}

} } } }

#endif