#pragma once

#include "Styling/Expressions/Expressions.h"

namespace onyx::Styling::Expressions::Data
{

	template<typename OutputT>
	class FeatureStateBase : public InstantiateExpressionTypes<OutputT>::OneArgType
	{
	public:

		FeatureStateBase(std::string const& key, ExpressionPtr<OutputT>& fallback) : InstantiateExpressionTypes<OutputT>::OneArgType(fallback, Dependencies::FEATURE_STATE), mKey(key) {}
		virtual ~FeatureStateBase() {}

		bool defaults(Arguments const& args) const override final
		{
			bool exists = args.state.find(mKey) != args.state.end();
			if (exists)
			{
				return false;
			}
			else
			{
				return (mFallback) ? mFallback->defaults(args) : true;
			}
		}

	protected:
		std::string const mKey;
		ExpressionPtr<OutputT> const& mFallback = this->mArg;
	};

	template<typename OutputT>
	class GetBase : public InstantiateExpressionTypes<OutputT>::OneArgType
	{
	public:

		GetBase(std::string const& key, ExpressionPtr<OutputT>& fallback) : InstantiateExpressionTypes<OutputT>::OneArgType(fallback, Dependencies::FEATURE), mKey(key) {}
		virtual ~GetBase() {}

		bool defaults(Arguments const& args) const override final
		{
			bool exists = args.properties.find(mKey) != args.properties.end();
			if (exists)
			{
				return false;
			}
			else
			{
				return (mFallback) ? mFallback->defaults(args) : true;
			}
		}
		
	protected:
		std::string const mKey;
		ExpressionPtr<OutputT> const& mFallback = this->mArg;
	};

}