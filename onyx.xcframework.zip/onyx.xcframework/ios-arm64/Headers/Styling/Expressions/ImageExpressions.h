#ifndef __STYLING_IMAGE_EXPRESSIONS_H__
#define __STYLING_IMAGE_EXPRESSIONS_H__

#include "Styling/Expressions/AssertionExpressions.h"
#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/InterpolationExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Image {

	class AmorphousImage final : public OneArgExpressionBase<ResolvedImage, std::string>
	{
	public:
		AmorphousImage(StringT::Ptr input) : OneArgExpressionBase<ResolvedImage, std::string>(input) {}
		ResolvedImage evaluate(Arguments const& args) const override
		{
			return ResolvedImage(mArg->evaluate(args));
		}
	};

	using Case = Decision::CaseResolvedImage;
	using Constant = ResolvedImageT::ConstantType;
	using Context = ContextExpression<ResolvedImage>;
	using Match = Decision::MatchResolvedImage;
	using Step = Interpolation::StepResolvedImage;

	inline ResolvedImageT::Ptr construct(ResolvedImage const& img)
	{
		return std::make_unique<Constant const>(img);
	}

	inline ResolvedImageT::Ptr construct(std::string const& img)
	{
		return construct(ResolvedImage(img));
	}

} } } }

#endif