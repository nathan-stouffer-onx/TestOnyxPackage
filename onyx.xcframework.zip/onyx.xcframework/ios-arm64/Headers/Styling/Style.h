#ifndef __STYLING_STYLE_H__
#define __STYLING_STYLE_H__

#include <deque>
#include <set>
#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

#include "Styling/Sources/Source.h"
#include "Styling/Terrain.h"
#include "Styling/Layers/Layer.h"
#include "Styling/Layers/Iterators.h"
#include "Expressions/Expressions.h"

namespace onyx {
namespace Styling {

	/*
	* A class to represent a map style. A Style contains information about data sources, layers, spritesheets, and fonts.
	* Sources and Layers can each be one of a couple different types. Layers must reference an existing source in a Style.
	* For ease of use, a Style exposes read-access to Layers broken down by layer type via the templated function
	* Style::layers that returns an object that can be used in a range-based for loop.
	*/
	class Style
	{
	public:

		using SourcesT = std::unordered_map<std::string, std::shared_ptr<Source const>>;
		using LayersT = std::vector<std::shared_ptr<Layer>>;
		
	public:

		uint32_t mVersion = 0;
		std::string mName;
		std::string mSprite;
		std::string mGlyphs;

		Style();

		void update();

		void addSource(std::string const& name, std::unique_ptr<Source> source);
		void removeSource(std::string const& name);

		void setTerrain(std::unique_ptr<Terrain> terrain) { mHasDirtyTerrain = true; mTerrain = std::move(terrain); }

		void addLayer(std::unique_ptr<Layer> layer);
		void addLayer(std::unique_ptr<Layer> layer, std::string const& beforeId);

		void removeLayer(std::string const& id);

		void toggle(std::string const& layerId);
		void toggle(std::string const& layerId, LayoutBase::Visibility visibility);

		void index() const;

		// throws an exception when it finds an invalid style
		void validate() const;

		bool hasSource(std::string const& name) const { return mSources.find(name) != mSources.end(); }
		bool hasLayer(std::string const& layerId) const { return mLayerIndex.find(layerId) != mLayerIndex.end(); }
		bool hasTerrain() const { return mTerrain != nullptr; }

		inline bool hasDirtySources() const { return mHasDirtySources; }
		inline bool hasDirtyLayers() const { return mHasDirtyLayers; }
		inline bool hasDirtyTerrain() const { return mHasDirtyTerrain; }
		inline bool isDirty() const { return hasDirtySources() || hasDirtyLayers() || hasDirtyTerrain(); }

		inline std::set<std::string> const& dirtyLayerIds() const { return mDirtyLayerIds; }
		inline std::set<std::string> const& dirtySourceNames() const { return mDirtySourceNames; }

		inline std::shared_ptr<Expressions::StyleContext const> getContext() const { return mContext; }
		
		// read access to all sources and layers
		SourcesT const& sources() const { return mSources; }

		std::vector<std::string> activeSources() const;

		template<typename LayerT>
		FilteredLayerRange<LayerT> layers() const { return FilteredLayerRange<LayerT>(mLayers); }

		// fully specialized default for all layers
		FilteredLayerRange<Layer> layers() const { return FilteredLayerRange<Layer>(mLayers); }

		std::shared_ptr<Source const> const& source(std::string const& name) const { return mSources.at(name); }

		std::shared_ptr<Layer const> layer(std::string const& layerId) const { index(); return mLayerIndex.layer(layerId); }
		std::shared_ptr<Layer const> layer(size_t i) const { return mLayers[i]; }

		std::shared_ptr<Terrain const> terrain() const { return mTerrain; }

		inline size_t layerCount() const { return mLayers.size(); }

		inline bool hasName()   const { return mName   != ""; }
		inline bool hasSprite() const { return mSprite != ""; }
		inline bool hasGlyphs() const { return mGlyphs != ""; }

		template<typename OutputT>
		void addContextExpression(std::string const& key, typename Expressions::InstantiateExpressionTypes<OutputT>::Ptr expr)
		{
			mContext->add(key, Expressions::SharedExpressionPtr<OutputT>(std::move(expr)));
		}

		template<typename T>
		void addContextEntry(std::string const& key, std::unique_ptr<T> value)
		{
			mContext->add(key, std::shared_ptr<T>(std::move(value)));
		}

	private:

		SourcesT mSources;
		LayersT mLayers;
		std::shared_ptr<Terrain> mTerrain = nullptr;

		bool mHasDirtySources = true;
		bool mHasDirtyLayers = true;
		bool mHasDirtyTerrain = true;

		std::set<std::string> mDirtyLayerIds;
		std::set<std::string> mDirtySourceNames;

		/*
		* An internal class that keeps an index from layer ids to layer pointers. The index is computed
		* lazily when necessary. It must be explicitly invalidated by the owning Style.
		*/
		class LayerIndex
		{
		public:

			using IndexT = std::unordered_map<std::string, LayersT::const_iterator>;
			using const_iterator = IndexT::const_iterator;

			LayerIndex(LayersT const& layers) :
				mLayers(layers),
				mIndexed(false)
			{
				index();
			}

			inline LayerIndex::IndexT::const_iterator find(std::string const& layerId) const
			{
				index();
				return mIndex.find(layerId);
			}

			inline LayersT::const_iterator at(std::string const& layerId) const
			{
				index();
				return mIndex.at(layerId);
			}

			inline std::shared_ptr<Layer> const& layer(std::string const& layerId) const
			{
				return *at(layerId);
			}

			inline void invalidate() { mIndexed = false; }

			void index() const
			{
				if (!mIndexed)
				{
					mIndex.clear();

					for (auto it = mLayers.begin(); it != mLayers.end(); ++it)
					{
						std::shared_ptr<Layer> const& layer = *it;
						mIndex.insert({ layer->id, it });
					}

					mIndexed = true;
				}
			}
			
			const_iterator begin() const { index(); return mIndex.begin(); }
			const_iterator end()   const { index(); return mIndex.end(); }

		private:

			// const reference to the layers owned by the Style
			LayersT const& mLayers;

			// index into the collection layers
			IndexT mutable mIndex;

			bool mutable mIndexed;

		};

		LayerIndex mutable mLayerIndex;

		std::shared_ptr<Layer> layer(std::string const& layerId)
		{
			return std::const_pointer_cast<Layer>(static_cast<Style const&>(*this).layer(layerId));
		}

		std::shared_ptr<Expressions::StyleContext> const mContext;

		void verifyExpressionTree(std::deque<Expressions::ExpressionBase const*>& ancestors, Expressions::ExpressionBase const* current, Expressions::ValidationArguments args) const;

		void validate(Terrain const& terrain) const;
		void validate(SourcedLayer const& layer) const;
		void validate(BackgroundLayer const& layer) const;
		void validate(RasterLayer const& layer) const;
		void validate(LineLayer const& layer) const;
		void validate(FillLayer const& layer) const;
		void validate(SymbolLayer const& layer) const;
		void validate(ContourLayer const& layer) const;

		template<typename T>
		void validateExpressionType() const
		{
			auto cxt = getContext();
			Expressions::ValidationArguments const args = { cxt };

			std::list<std::string> keys;
			mContext->getKeys(keys);

			std::deque<Expressions::ExpressionBase const*> ancestors;

			for (auto const& key : keys)
			{
				if (mContext->lookup(key).is<typename Expressions::InstantiateExpressionTypes<T>::SharedPtr>())
				{
					typename Expressions::InstantiateExpressionTypes<T>::SharedPtr expr;
					mContext->getTo(key, expr);
					verifyExpressionTree(ancestors, expr.get(), args);
				}
			}
		}

	};

} }

#endif