#pragma once

#include <deque>
#include <functional>
#include <memory>
#include <queue>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

#include "Expressions/Expressions.h"
#include "Styling/Sources/Source.h"
#include "Styling/Terrain.h"
#include "Styling/Layers/Fog.h"
#include "Styling/Layers/Skydome.h"
#include "Styling/Layers/Layer.h"
#include "Styling/Layers/Iterators.h"
#include "Styling/Layers/Layouts/LayoutContext.h"
#include "Styling/Layers/Paints/PaintContext.h"
#include "Styling/Layers/Effects/EffectContext.h"

namespace onyx::Styling
{

	/*
	* A class to represent a map style. A Style contains information about data sources, layers, spritesheets, and fonts.
	* Sources and Layers can each be one of a couple different types. Layers must reference an existing source in a Style.
	* For ease of use, a Style exposes read-access to Layers broken down by layer type via the templated function
	* Style::layers that returns an object that can be used in a range-based for loop.
	*/
	class Style
	{
	public:

		using SourcesT = std::unordered_map<std::string, std::shared_ptr<Source>>;
		using LayersT = std::vector<std::shared_ptr<Layer>>;
		
	public:

		// TODO probably move these to be private
		uint32_t mVersion = 0;
		std::string mName;
		std::string mGlyphs;

		Style();
		Style(std::unique_ptr<Expressions::ExpressionContext> expressions, std::unique_ptr<LayoutContext> layouts, std::unique_ptr<PaintContext> paints, std::unique_ptr<EffectContext> effects);

		void update();

		void addSource(std::string const& name, std::unique_ptr<Source> source);
		void removeSource(std::string const& name);

		inline void queueFeatureState(Feature const& feature, std::string const& key, Value const& value) { setFeatureState(feature, key, value); }

		void setTerrain(std::unique_ptr<Terrain> terrain);

		void setFog(Fog&& fog);
		
		void setSkydome(Skydome&& skydome);

		void addLayer(std::unique_ptr<Layer> layer);
		void addLayer(std::unique_ptr<Layer> layer, std::string const& beforeId);
		void addLayer(std::unique_ptr<Layer> layer, size_t const beforeIdx);

		void replaceLayer(std::unique_ptr<Layer> layer);

		void removeLayer(std::string const& id);

		void toggle(std::string const& layerId);
		void toggle(std::string const& layerId, LayoutBase::Visibility visibility);

		void toggleGroup(std::string const& group, LayoutBase::Visibility const visibility);

		void index() const;

		void flushTasks();

		// throws an exception when it finds an invalid style
		void validate() const;
		void toggleValidation(bool enabled) { mValidationEnabled = enabled; }
		bool isValidationEnabled() const { return mValidationEnabled; }

		bool hasSource(std::string const& name) const { return mSources.find(name) != mSources.end(); }
		bool hasLayer(std::string const& layerId) const { return mLayerIndex.find(layerId) != mLayerIndex.end(); }
		bool hasTerrain() const { return mTerrain != nullptr; }

		inline bool hasQueuedTasks() const { return !mQueuedTasks.empty(); }

		inline bool hasDirtySources() const { return mHasDirtySources; }
		inline bool hasDirtyLayers() const { return mHasDirtyLayers; }
		inline bool hasDirtyTerrain() const { return mHasDirtyTerrain; }
		inline bool hasDirtyFog() const { return mHasDirtyFog; }
		inline bool hasDirtySkydome() const { return mHasDirtySkydome; }
		inline bool isDirty() const { return hasDirtySources() || hasDirtyLayers() || hasDirtyTerrain() || hasDirtyFog() || hasDirtySkydome(); }

		inline bool hasToggledLayers() const { return mHasToggledLayers; }

		inline std::set<std::string> const& dirtySourceNames() const { return mDirtySourceNames; }

		inline std::set<std::string> const& addedLayerIds() const { return mAddedLayerIds; }
		inline std::set<std::string> const& editedLayerIds() const { return mEditedLayerIds; }
		inline std::set<std::string> const& removedLayerIds() const { return mRemovedLayerIds; }

		inline std::shared_ptr<Expressions::ExpressionContext const> getExpressionContext() const { return mExpressionContext; }
		inline std::shared_ptr<LayoutContext const> getLayoutContext() const { return mLayoutContext; }
		inline std::shared_ptr<PaintContext const> getPaintContext() const { return mPaintContext; }
		inline std::shared_ptr<EffectContext const> getEffectContext() const { return mEffectContext; }
		
		inline InitArgs initArgs() const { return InitArgs{ { mExpressionContext }, *mLayoutContext, *mPaintContext, *mEffectContext };  }

		// read access to all sources and layers
		SourcesT const& sources() const { return mSources; }

		std::vector<std::string> activeSources() const;
		std::vector<std::string> activeSources(float const zoom) const;

		std::set<std::string> layerGroups() const;

		template<typename LayerT>
		FilteredLayerRange<LayerT, TypedPredicate<LayerT>> layers() const { return FilteredLayerRange<LayerT, TypedPredicate<LayerT>>(mLayers, TypedPredicate<LayerT>()); }
		FilteredLayerRange<Layer, TypedPredicate<Layer>> layers() const { return FilteredLayerRange<Layer, TypedPredicate<Layer>>(mLayers, TypedPredicate<Layer>()); }

		template<typename LayerT>
		FilteredLayerRange<LayerT, VisiblePredicate<LayerT>> visibleLayers() const { return FilteredLayerRange<LayerT, VisiblePredicate<LayerT>>(mLayers, VisiblePredicate<LayerT>()); }
		FilteredLayerRange<Layer, VisiblePredicate<Layer>> visibleLayers() const { return FilteredLayerRange<Layer, VisiblePredicate<Layer>>(mLayers, VisiblePredicate<Layer>()); }

		template<typename LayerT>
		FilteredLayerRange<LayerT, VisibleRangePredicate<LayerT>> visibleLayers(float zoom) const { return FilteredLayerRange<LayerT, VisibleRangePredicate<LayerT>>(mLayers, VisibleRangePredicate<LayerT>(zoom)); }
		FilteredLayerRange<Layer, VisibleRangePredicate<Layer>> visibleLayers(float zoom) const { return FilteredLayerRange<Layer, VisibleRangePredicate<Layer>>(mLayers, VisibleRangePredicate<Layer>(zoom)); }

		template<typename LayerT>
		FilteredLayerRange<LayerT, VisibleRangeVectorPredicate<LayerT>> visibleVectorLayers(float zoom) const { return FilteredLayerRange<LayerT, VisibleRangeVectorPredicate<LayerT>>(mLayers, VisibleRangeVectorPredicate<LayerT>(zoom)); }
		FilteredLayerRange<Layer, VisibleRangeVectorPredicate<Layer>> visibleVectorLayers(float zoom) const { return FilteredLayerRange<Layer, VisibleRangeVectorPredicate<Layer>>(mLayers, VisibleRangeVectorPredicate<Layer>(zoom)); }

		template<typename LayerT>
		FilteredLayerRange<LayerT, VisibleRangeShaderPredicate<LayerT>> visibleShaderLayers(float zoom) const { return FilteredLayerRange<LayerT, VisibleRangeShaderPredicate<LayerT>>(mLayers, VisibleRangeShaderPredicate<LayerT>(zoom)); }
		FilteredLayerRange<Layer, VisibleRangeShaderPredicate<Layer>> visibleShaderLayers(float zoom) const { return FilteredLayerRange<Layer, VisibleRangeShaderPredicate<Layer>>(mLayers, VisibleRangeShaderPredicate<Layer>(zoom)); }

		std::shared_ptr<Source const> source(std::string const& name) const { return mSources.at(name); }

		std::shared_ptr<Layer const> layer(std::string const& layerId) const { index(); return mLayerIndex.layer(layerId); }
		std::shared_ptr<Layer const> layer(size_t i) const { return mLayers[i]; }

		std::shared_ptr<Terrain const> terrain() const { return mTerrain; }
		Fog const& fog() const { return mFog; }
		Skydome const& skydome() const { return mSkydome; }

		inline size_t layerCount() const { return mLayers.size(); }

		inline bool hasName() const { return !mName.empty(); }
		inline bool hasSpriteUrl() const { return !mSpritesheetUrl.empty(); }
		inline bool hasGlyphs() const { return !mGlyphs.empty(); }

		inline void addSpritesheetUrl(std::string const& url) { mSpritesheetUrl = url; }
		std::string const& spritesheetUrl() const { return mSpritesheetUrl; }

		// TODO [ONYX-126] Thread-safe editing of context
		//template<typename OutputT>
		//void addExpressionContextEntry(std::string const& key, Expressions::ExpressionPtr<OutputT> expr)
		//{
		//	mExpressionContext->add(key, Expressions::SharedExpressionPtr<OutputT>(std::move(expr)));
		//	markContextLayersAsEdited();
		//
		//	if (mValidationEnabled) { validate(); }
		//}

	public:

		static char constexpr cCircularExpressionMessage[] = "Circular expression reference detected -- check usages of context";
		static char constexpr cCircularLayoutMessage[] = "Circular layout reference detected -- check usages of layout context";
		static char constexpr cCircularPaintMessage[] = "Circular paint reference detected -- check usages of paint context";
		static char constexpr cCircularEffectMessage[] = "Circular effect reference detected -- check usages of effect context";

	private:

		SourcesT mSources;
		LayersT mLayers;
		
		std::shared_ptr<Terrain> mTerrain = nullptr;

		Fog mFog;
		Skydome mSkydome;

		std::string mSpritesheetUrl = "";

		bool mHasDirtySources = true;
		bool mHasDirtyLayers = true;
		bool mHasDirtyTerrain = true;
		bool mHasDirtyFog = true;
		bool mHasDirtySkydome = true;
		
		bool mHasToggledLayers = true;

		bool mValidationEnabled = true;

		std::set<std::string> mDirtySourceNames;
		
		std::set<std::string> mAddedLayerIds;
		std::set<std::string> mEditedLayerIds;
		std::set<std::string> mRemovedLayerIds;

		/*
		* An internal class that keeps an index from layer ids to layer pointers. The index is computed
		* lazily when necessary. It must be explicitly invalidated by the owning Style.
		*/
		class LayerIndex
		{
		public:

			using IndexT = std::unordered_map<std::string, LayersT::const_iterator>;
			using const_iterator = IndexT::const_iterator;

			LayerIndex(LayersT const* layers) :
				mLayers(layers),
				mIndexed(false)
			{
				index();
			}

			LayerIndex(LayerIndex const&) = delete;
			LayerIndex& operator=(LayerIndex const&) = delete;

			LayerIndex(LayerIndex&&) noexcept : mIndexed(false) {}
			LayerIndex& operator=(LayerIndex&&) noexcept
			{
				mIndexed = false;
				return *this;
			}

			inline LayerIndex::IndexT::const_iterator find(std::string const& layerId) const
			{
				index();
				return mIndex.find(layerId);
			}

			inline LayersT::const_iterator at(std::string const& layerId) const
			{
				index();
				return mIndex.at(layerId);
			}

			inline std::shared_ptr<Layer> const& layer(std::string const& layerId) const
			{
				return *at(layerId);
			}

			inline void invalidate() { mIndexed = false; }

			void index() const
			{
				if (!mIndexed)
				{
					mIndex.clear();

					for (auto it = mLayers->begin(); it != mLayers->end(); ++it)
					{
						std::shared_ptr<Layer> const& layer = *it;
						mIndex.insert({ layer->id, it });
					}

					mIndexed = true;
				}
			}
			
			const_iterator begin() const { index(); return mIndex.begin(); }
			const_iterator end()   const { index(); return mIndex.end(); }

		private:

			// const reference to the layers owned by the Style
			LayersT const* mLayers;

			// index into the collection layers
			IndexT mutable mIndex;

			bool mutable mIndexed;

		};

		LayerIndex mutable mLayerIndex;

		void setFeatureState(Feature const& feature, std::string const& key, Value const& value, bool queue = true);
		void addLayer(std::unique_ptr<Layer> layer, LayersT::const_iterator before);

		std::shared_ptr<Expressions::ExpressionContext const> mExpressionContext;
		std::shared_ptr<LayoutContext const> mLayoutContext;
		std::shared_ptr<PaintContext const> mPaintContext;
		std::shared_ptr<EffectContext const> mEffectContext;

		using QueuedTaskT = std::function<void()>;
		std::queue<QueuedTaskT> mQueuedTasks;

		void markContextLayersAsEdited();

		void validateExpressionContext() const;
		void validateLayoutContext() const;
		void validatePaintContext() const;
		void validateEffectContext() const;

		void validate(Terrain const& terrain) const;
		void validate(Layer const& layer) const;
		void validate(SourcedLayer const& layer) const;

		template<typename T>
		static void ValidateExpressionContext(std::shared_ptr<Expressions::ExpressionContext const> const& ctx)
		{
			using ExprT = typename Expressions::InstantiateExpressionTypes<T>::SharedPtr;
			Expressions::InitArgs const args(ctx);

			std::list<std::string> keys;
			ctx->getKeys(keys);

			std::deque<Expressions::ExpressionBase const*> ancestors;
			for (auto const& key : keys)
			{
				if (ctx->lookup(key).is<ExprT>())
				{
					ExprT expr;
					ctx->getTo(key, expr);
					ONYX_ASSERT(Style::IsExpressionTree(ancestors, expr.get(), args), cCircularExpressionMessage);
				}
			}
		}
		
		static bool IsExpressionTree(std::deque<Expressions::ExpressionBase const*>& ancestors, Expressions::ExpressionBase const* current, Expressions::InitArgs args);

		template<typename T>
		static void ValidateLayoutContext(InitArgs const& args)
		{
			using LayoutT = std::shared_ptr<T const>;

			std::list<std::string> keys;
			args.layouts.getKeys(keys);

			std::deque<std::string_view> ancestors;
			for (auto const& key : keys)
			{
				if (args.layouts.lookup(key).is<LayoutT>())
				{
					LayoutT layout;
					args.layouts.getTo(key, layout);
					ONYX_ASSERT(Style::IsContextTree(ancestors, layout, args.layouts), cCircularLayoutMessage);
					layout->validate(args);
				}
			}
		}

		template<typename T>
		static void ValidatePaintContext(InitArgs const& args)
		{
			using PaintT = std::shared_ptr<T const>;

			std::list<std::string> keys;
			args.paints.getKeys(keys);

			std::deque<std::string_view> ancestors;
			for (auto const& key : keys)
			{
				if (args.paints.lookup(key).is<PaintT>())
				{
					PaintT paint;
					args.paints.getTo(key, paint);
					ONYX_ASSERT(Style::IsContextTree(ancestors, paint, args.paints), cCircularPaintMessage);
					paint->validate(args);
				}
			}
		}

		template<typename T>
		static void ValidateEffectContext(InitArgs const& args)
		{
			using EffectT = std::shared_ptr<T const>;

			std::list<std::string> keys;
			args.effects.getKeys(keys);

			std::deque<std::string_view> ancestors;
			for (auto const& key : keys)
			{
				if (args.effects.lookup(key).is<EffectT>())
				{
					EffectT effect;
					args.effects.getTo(key, effect);
					ONYX_ASSERT(Style::IsContextTree(ancestors, effect, args.effects), cCircularEffectMessage);
					effect->validate(args);
				}
			}
		}

		template<typename T, typename U>
		static bool IsContextTree(std::deque<std::string_view>& descendants, std::shared_ptr<T const> const current, U const& context)
		{
			if (current->baseId.empty()) { return true; }

			auto it = std::find(descendants.begin(), descendants.end(), current->baseId);
			if (it != descendants.end()) { return false; }

			descendants.push_back(current->baseId);
			std::shared_ptr<T const> base;
			context.getTo(current->baseId, base);
			ONYX_ASSERT(base.get(), "Referenced non-existent base Layout");
			return IsContextTree(descendants, base, context);
		}

	};

}