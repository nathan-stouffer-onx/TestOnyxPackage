#ifndef __STYLING_TERRAIN_H__
#define __STYLING_TERRAIN_H__

#include <string>

#include <System/OnyxException.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/NumberExpressions.h"

namespace onyx {
namespace Styling {

	/*
	* Struct to represent terrain in the stylesheet. Currently supports one data source
	*/

	struct Terrain
	{

		std::string source;

		Expressions::NumberT::Ptr exaggeration = Expressions::Number::construct(1.0f);

		inline bool operator==(Terrain const& rhs) const
		{
			return source == rhs.source && exaggeration == rhs.exaggeration;
		}
		
		inline bool operator!=(Terrain const& rhs) const
		{
			return !(*this == rhs);
		}

		void validate() const
		{
			ONYX_ASSERT(source != "", "Source cannot be the empty string");
		}

		static Terrain none()
		{
			return Terrain();
		}

	};

} }

#endif