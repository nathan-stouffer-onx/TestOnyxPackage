#include "Paint.h"

namespace onyx::Styling
{

	BackgroundPaint::BackgroundPaint()
	{
		ADD_OPERATIONS(color);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(pattern);
	}

	CirclePaint::CirclePaint()
	{
		ADD_OPERATIONS(color);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(radius);
		ADD_OPERATIONS(strokeColor);
		ADD_OPERATIONS(strokeOpacity);
		ADD_OPERATIONS(strokeWidth);
		ADD_OPERATIONS(translate);
		ADD_OPERATIONS(translateAnchor);
	}

	ContourLabelPaint::ContourLabelPaint() = default;

	ContourLinePaint::ContourLinePaint()
	{
		ADD_OPERATIONS(color);
		ADD_OPERATIONS(max);
		ADD_OPERATIONS(min);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(period);
		ADD_OPERATIONS(units);
		ADD_OPERATIONS(width);
	}

	ElevationPaint::ElevationPaint()
	{
		ADD_OPERATIONS(maskMeters);
		ADD_OPERATIONS(opacity);
	}

	FillPaint::FillPaint()
	{
		ADD_OPERATIONS(antialias);
		ADD_OPERATIONS(color);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(outlineColor);
		ADD_OPERATIONS(pattern);
		ADD_OPERATIONS(translate);
		ADD_OPERATIONS(translateAnchor);
	}

	HillshadePaint::HillshadePaint()
	{
		ADD_OPERATIONS(altitude);
		ADD_OPERATIONS(albedo);
		ADD_OPERATIONS(ambientIntensity);
		ADD_OPERATIONS(azimuth);
		ADD_OPERATIONS(exaggeration);
		ADD_OPERATIONS(opacity);
	}

	IntersectPaint::IntersectPaint()
	{
		ADD_OPERATIONS(elevationMaskMeters);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(slopeAngleMaskDegrees);
		ADD_OPERATIONS(slopeAspectMaskDegrees);
		ADD_OPERATIONS(slopeAspectMinimumAngleDegrees);
		ADD_OPERATIONS(tint);
	}

	LinePaint::LinePaint()
	{
		ADD_OPERATIONS(blur);
		ADD_OPERATIONS(casingColor);
		ADD_OPERATIONS(casingOpacity);
		ADD_OPERATIONS(casingWidth);
		ADD_OPERATIONS(color);
		ADD_OPERATIONS(dashArray);
		ADD_OPERATIONS(gapWidth);
		ADD_OPERATIONS(offset);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(pattern);
		ADD_OPERATIONS(translate);
		ADD_OPERATIONS(translateAnchor);
		ADD_OPERATIONS(width);
	}

	RasterPaint::RasterPaint()
	{
		ADD_OPERATIONS(brightnessMax);
		ADD_OPERATIONS(brightnessMin);
		ADD_OPERATIONS(contrast);
		ADD_OPERATIONS(hueRotate);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(saturation);
	}

	SlopeAnglePaint::SlopeAnglePaint()
	{
		ADD_OPERATIONS(maskDegrees);
		ADD_OPERATIONS(opacity);
	}

	SlopeAspectPaint::SlopeAspectPaint()
	{
		ADD_OPERATIONS(maskDegrees);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(minimumAngleDegrees);
	}

	SunlightPaint::SunlightPaint()
	{
		ADD_OPERATIONS(shadowStrength);
	}

	SymbolPaint::SymbolPaint()
	{
		ADD_OPERATIONS(iconColor);
		ADD_OPERATIONS(iconImageCrossFade);
		ADD_OPERATIONS(iconOpacity);
		ADD_OPERATIONS(iconTranslate);
		ADD_OPERATIONS(iconTranslateAnchor);
	}

	ViewshedPaint::ViewshedPaint()
	{
		ADD_OPERATIONS(tint);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(ringTint);
		ADD_OPERATIONS(ringOpacity);
	}

}