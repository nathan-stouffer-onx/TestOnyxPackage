#include "PaintComponents.h"

namespace onyx::Styling
{

	TextPaintComponent::TextPaintComponent()
	{
		ADD_OPERATIONS(color);
		ADD_OPERATIONS(haloBlur);
		ADD_OPERATIONS(haloColor);
		ADD_OPERATIONS(haloWidth);
		ADD_OPERATIONS(opacity);
		ADD_OPERATIONS(translate);
		ADD_OPERATIONS(translateAnchor);
		ADD_OPERATIONS(shadowColor);
		ADD_OPERATIONS(strikethroughColor);
		ADD_OPERATIONS(overlineColor);
		ADD_OPERATIONS(underlineColor);
		ADD_OPERATIONS(backgroundColor);
	}

}