#pragma once

#include <lucid/gal/Types.h>

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/ExpressionOwner.h"
#include "Styling/Layers/Paints/PaintComponents.h"
#include "Styling/Styles/ContourConfigs.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/SymbolStyle.h"

namespace onyx::Styling
{

	/*
	* Structs to represent Paint structures for each type of style layer that can be drawn on the map
	*/

	// base struct to define a Paint structure
	struct PaintBase : public ExpressionOwner
	{

		PaintBase() = default;
		virtual ~PaintBase() = default;

		virtual void validate(InitArgs const& args) const = 0;

		virtual Expressions::Dependencies dependencies(InitArgs const& args) const = 0;

		std::string baseId;
	};

	// This template struct lets us use the curiously-recurring-template pattern to have a
	// strongly-typed shared pointer to a "derived" class based on the template.  Also allows
	// us to use InitArgs::BaseFlags template function that will retrieve that
	// pointer from the style context.
	template<typename T>
	struct Paint : public PaintBase
	{
		virtual ~Paint() = default;

		std::shared_ptr<T const> const& base(InitArgs const& args) const
		{
			if (!baseId.empty() && !mBasePtr)
			{
				args.paints.getTo(baseId, mBasePtr);
			}
			return mBasePtr;
		}

		void setBase(std::shared_ptr<T const> const& base) { mBasePtr = base; }

		void validate(InitArgs const& args) const override final
		{
			// make sure that the base class exists and is of the correct type
			{
				base(args);
			}
			for (Expressions::ExpressionBase const* expr : expressions())
			{
				// for now, the only validation that occurs is that we reference valid context expressions
				// (which we confirm by getting the children)
				if (expr)
				{
					expr->children(args.expressions);
				}
			}
		}

		Expressions::Dependencies dependencies(InitArgs const& args) const override final
		{
			Expressions::Dependencies deps = Expressions::dependencies(args.expressions, expressions());
			if (auto const& base = this->base(args))
			{
				deps |= base->dependencies(args);
			}
			return deps;
		}

	private:
		std::shared_ptr<T const> mutable mBasePtr;
	};

	struct BackgroundPaint final : public Paint<BackgroundPaint>
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::ResolvedImageT::Ptr pattern = Expressions::Image::construct("");

		BackgroundPaint();
	};

	struct CirclePaint final : public Paint<CirclePaint>
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr radius = Expressions::Number::construct(5.f);
		Expressions::ColorT::Ptr strokeColor = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr strokeOpacity = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr strokeWidth = Expressions::Number::construct(0.f);
		Expressions::NumberArrayT::Ptr translate = Expressions::Array::construct<float>({ 0.0f, 0.0f });
		Expressions::EnumT<TranslateAnchor>::Ptr translateAnchor = Expressions::Enum::construct(TranslateAnchor::MAP);

		CirclePaint();
	};

	struct ContourLabelPaint final : public Paint<ContourLabelPaint>
	{
		TextPaintComponent text;

		ContourLabelPaint();

		void nullify() override
		{
			text.nullify();
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return text.expressions();
		}
	};

	struct ContourLinePaint final : public Paint<ContourLinePaint>
	{
		
		// NOTE: use this adjusted value instead of maximum because casting from
		// max int -> float -> int results in a -max int. 100 was chosen somewhat
		// arbitrarily, but it works and I don't think the actual number matters
		// too much
		static constexpr int cIntBound = std::numeric_limits<int>::max() - 100;

		Expressions::ColorT::Ptr color = Expressions::Color::construct(0xFF000000);
		Expressions::NumberT::Ptr max = Expressions::Number::construct(float(cIntBound));
		Expressions::NumberT::Ptr min = Expressions::Number::construct(float(-cIntBound));
		Expressions::NumberT::Ptr period = Expressions::Number::construct(10.f);
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::EnumT<ContourConfig::Units>::Ptr units = Expressions::Enum::construct(ContourConfig::Units::METERS);
		Expressions::NumberT::Ptr width = Expressions::Number::construct(1.f);

		ContourLinePaint();
	};

	struct ElevationPaint final : public Paint<ElevationPaint>
	{
		Expressions::RangeArrayT::Ptr maskMeters = Expressions::Array::construct<lgal::gpu::Range>({ { -11000.f, 9000.f } });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);

		ElevationPaint();
	};

	struct FillPaint final : public Paint<FillPaint>
	{
		Expressions::BooleanT::Ptr antialias = Expressions::Boolean::construct(true);
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::ColorT::Ptr outlineColor = nullptr;
		Expressions::ResolvedImageT::Ptr pattern = Expressions::Image::construct("");
		Expressions::NumberArrayT::Ptr translate = Expressions::Array::construct<float>({ 0.0f, 0.0f });
		Expressions::EnumT<TranslateAnchor>::Ptr translateAnchor = Expressions::Enum::construct(TranslateAnchor::MAP);

		FillPaint();
	};

	struct HillshadePaint final : public Paint<HillshadePaint>
	{
		Expressions::NumberT::Ptr altitude = Expressions::Number::construct(45.f);
		Expressions::ColorT::Ptr albedo = Expressions::Color::construct(0xFFFFFFFF);
		Expressions::NumberT::Ptr ambientIntensity = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr azimuth = Expressions::Number::construct(315.f);
		Expressions::NumberT::Ptr exaggeration = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);

		HillshadePaint();
	};

	struct IntersectPaint final : public Paint<IntersectPaint>
	{
		Expressions::RangeArrayT::Ptr elevationMaskMeters = Expressions::Array::construct<lgal::gpu::Range>({ { -11000.f, 9000.f } });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::RangeArrayT::Ptr slopeAngleMaskDegrees = Expressions::Array::construct<lgal::gpu::Range>({ { 0.f, 90.f } });
		Expressions::RangeArrayT::Ptr slopeAspectMaskDegrees = Expressions::Array::construct<lgal::gpu::Range>({ { 0.f, 360.f } });
		Expressions::NumberT::Ptr slopeAspectMinimumAngleDegrees = Expressions::Number::construct(0.f);
		Expressions::ColorT::Ptr tint = Expressions::Color::construct(0xFF000000);

		IntersectPaint();
	};

	struct LinePaint final : public Paint<LinePaint>
	{
		Expressions::NumberT::Ptr blur = Expressions::Number::construct(0.f);
		Expressions::ColorT::Ptr casingColor = Expressions::Color::construct(0xFFFFFFFF);
		Expressions::NumberT::Ptr casingOpacity = Expressions::Number::construct(1.0f);
		Expressions::NumberT::Ptr casingWidth = Expressions::Number::construct(0.0f);
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberArrayT::Ptr dashArray = Expressions::Array::construct<float>({ 1.0f });
		Expressions::NumberT::Ptr gapWidth = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr offset = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::ResolvedImageT::Ptr pattern = Expressions::Image::construct("");
		Expressions::NumberArrayT::Ptr translate = Expressions::Array::construct<float>({ 0.0f, 0.0f });
		Expressions::EnumT<TranslateAnchor>::Ptr translateAnchor = Expressions::Enum::construct(TranslateAnchor::MAP);
		Expressions::NumberT::Ptr width = Expressions::Number::construct(1.0f);
		
		LinePaint();
	};

	struct RasterPaint final : public Paint<RasterPaint>
	{
		Expressions::NumberT::Ptr brightnessMax = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr brightnessMin = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr contrast = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr hueRotate = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.0f);
		Expressions::NumberT::Ptr saturation = Expressions::Number::construct(0.f);

		RasterPaint();
	};

	struct SlopeAnglePaint final : public Paint<SlopeAnglePaint>
	{
		Expressions::RangeArrayT::Ptr maskDegrees = Expressions::Array::construct<lgal::gpu::Range>({ { 0.f, 90.f } });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);

		SlopeAnglePaint();
	};

	struct SlopeAspectPaint final : public Paint<SlopeAspectPaint>
	{
		Expressions::RangeArrayT::Ptr maskDegrees = Expressions::Array::construct<lgal::gpu::Range>({ { 0.f, 360.f } });
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr minimumAngleDegrees = Expressions::Number::construct(5.f);

		SlopeAspectPaint();
	};

	struct SunlightPaint final : public Paint<SunlightPaint>
	{
		Expressions::NumberT::Ptr shadowStrength = Expressions::Number::construct(0.5f);

		SunlightPaint();
	};

	struct SymbolPaint : public Paint<SymbolPaint>
	{
		TextPaintComponent text;

		Expressions::ColorT::Ptr iconColor = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 0.0f });
		Expressions::NumberT::Ptr iconImageCrossFade = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr iconOpacity = Expressions::Number::construct(1.f);
		Expressions::NumberArrayT::Ptr iconTranslate = Expressions::Array::construct<float>({ 0.0f, 0.0f });
		Expressions::EnumT<TranslateAnchor>::Ptr iconTranslateAnchor = Expressions::Enum::construct(TranslateAnchor::MAP);

		SymbolPaint();

		void nullify() override
		{
			ExpressionOwner::nullify();
			text.nullify();
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return Expressions::concat(ExpressionOwner::expressions(), text.expressions());
		}
	};

	struct ViewshedPaint final : public Paint<ViewshedPaint>
	{
		Expressions::ColorT::Ptr tint = Expressions::Color::construct(0xFF000000);
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.f);
		Expressions::ColorT::Ptr ringTint = Expressions::Color::construct(0xFFFFFFFF);
		Expressions::NumberT::Ptr ringOpacity = Expressions::Number::construct(1.f);

		ViewshedPaint();
	};

}
