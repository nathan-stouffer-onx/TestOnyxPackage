#pragma once

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/FormatExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/ExpressionOwner.h"

namespace onyx::Styling
{

	struct TextPaintComponent final : public ExpressionOwner
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 1.0f, 1.0f, 1.0f, 1.0f });
		Expressions::NumberT::Ptr haloBlur = Expressions::Number::construct(0);
		Expressions::ColorT::Ptr haloColor = Expressions::Color::construct(0x00000000);
		Expressions::NumberT::Ptr haloWidth = Expressions::Number::construct(0);
		Expressions::NumberT::Ptr opacity = nullptr;
		Expressions::NumberArrayT::Ptr translate = Expressions::Array::construct<float>({ 0, 0 });
		Expressions::EnumT<TranslateAnchor>::Ptr translateAnchor = Expressions::Enum::construct(TranslateAnchor::MAP);

		Expressions::ColorT::Ptr shadowColor = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 0.2f });
		Expressions::ColorT::Ptr strikethroughColor = Expressions::Color::construct(0);
		Expressions::ColorT::Ptr overlineColor = Expressions::Color::construct(0);
		Expressions::ColorT::Ptr underlineColor = Expressions::Color::construct(0);
		Expressions::ColorT::Ptr backgroundColor = Expressions::Color::construct(0);

		TextPaintComponent();
	};

}