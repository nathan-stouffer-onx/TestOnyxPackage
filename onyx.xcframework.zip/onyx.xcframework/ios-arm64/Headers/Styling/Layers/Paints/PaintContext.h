#ifndef __STYLING_PAINT_CONTEXT_H__
#define __STYLING_PAINT_CONTEXT_H__

#include <lucid/gigl/Context.h>
#include <lucid/gigl/Primitive.h>

#include "Styling/Layers/Declarations.h"

namespace onyx {
namespace Styling {

	namespace primitives {

		struct PaintTypes
		{

			enum { TYPE_COUNT = 17 };

			static lucid::gigl::PrimitiveInfo const infos[TYPE_COUNT];

			// Deleting this constructor forces a compile error if someone tries to use a context
			// to store/retrieve something that is unsupported.
			template<class T>	struct Type { Type() = delete; enum { VALUE = 0 }; };

		};

		template<> struct PaintTypes::Type<lucid::gigl::primitives::UNKNOWN            > { enum { VALUE = 0 }; };
		template<> struct PaintTypes::Type<lucid::gigl::primitives::UNDEFINED          > { enum { VALUE = 1 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<BackgroundPaint       const>> { enum { VALUE = 2 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<CirclePaint           const>> { enum { VALUE = 3 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<ContourLabelPaint     const>> { enum { VALUE = 4 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<ContourLinePaint      const>> { enum { VALUE = 5 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<ElevationPaint        const>> { enum { VALUE = 6 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<FillPaint             const>> { enum { VALUE = 7 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<HillshadePaint        const>> { enum { VALUE = 8 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<IntersectPaint        const>> { enum { VALUE = 9 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<LinePaint             const>> { enum { VALUE = 10 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<RasterPaint           const>> { enum { VALUE = 11 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<SlopeAnglePaint       const>> { enum { VALUE = 12 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<SlopeAspectPaint      const>> { enum { VALUE = 13 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<SunlightPaint         const>> { enum { VALUE = 14 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<SymbolPaint           const>> { enum { VALUE = 15 }; };
		template<> struct PaintTypes::Type<std::shared_ptr<ViewshedPaint         const>> { enum { VALUE = 16 }; };

	}

	using PaintContext = lucid::gigl::FlexContext<primitives::PaintTypes>;

} }

#endif