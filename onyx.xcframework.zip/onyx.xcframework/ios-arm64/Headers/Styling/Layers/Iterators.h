#ifndef __STYLING_LAYER_ITERATORS_H__
#define __STYLING_LAYER_ITERATORS_H__

#include <memory>

#include "Styling/Layers/Layer.h"

namespace onyx {
namespace Styling {

	// NOTE: we expect PredicateT to be a callable that takes in a Layer const& and returns a boolean
	template<typename FilteredLayerT, typename PredicateT>
	class FilteredLayerIterator
	{
	private:

		/*
		* iterate forward until one of the following conditions is true
		*     1. we are at the end
		*     2. the iterator points to a layer of the specified type
		*/
		void slide()
		{
			size_t diff = mEnd - mPos;
			for (size_t i = 0; i < diff && !mPredicate(**mPos); ++i)
			{
				++mPos;
			}
		}

	public:

		using LayersT = std::vector<std::shared_ptr<Layer>>;

	public:

		FilteredLayerIterator(LayersT::const_iterator pos, LayersT::const_iterator end, PredicateT predicate) : mPos(pos), mEnd(end), mPredicate(predicate)
		{
			slide();
		}

		inline bool operator==(FilteredLayerIterator const& rhs) const { return mPos == rhs.mPos; }
		inline bool operator!=(FilteredLayerIterator const& rhs) const { return !(*this == rhs); }

		inline std::shared_ptr<FilteredLayerT const> operator*() const
		{
			return std::static_pointer_cast<FilteredLayerT const>(*mPos);
		}

		inline FilteredLayerIterator& operator++()
		{
			// go ahead and increment immediately
			++mPos;

			// slide forward until we hit the end or an iterator of the correct type
			slide();

			// return the iterator we landed at
			return *this;
		}

		inline FilteredLayerIterator operator++(int)
		{
			FilteredLayerIterator ret = *this;
			++(*this);
			return ret;
		}

		inline FilteredLayerIterator operator+(size_t diff) const
		{
			FilteredLayerIterator ret = *this;
			for (size_t i = 0; i < diff; ++i)
			{
				++ret;
			}
			return ret;
		}

	private:

		LayersT::const_iterator mPos;
		LayersT::const_iterator mEnd;

		PredicateT const mPredicate;

	};

	template<typename T> struct TypedPredicate { TypedPredicate() = delete; };

	template<> struct TypedPredicate<Layer> { bool operator()(Layer const&) const { return true; } };
	template<> struct TypedPredicate<SourcedLayer> { bool operator()(Layer const& layer) const { return layer.isSourced(); } };
	template<> struct TypedPredicate<BackgroundLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::BACKGROUND; } };
	template<> struct TypedPredicate<ContourLabelLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::CONTOUR_LABEL; } };
	template<> struct TypedPredicate<ContourLineLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::CONTOUR_LINE; } };
	template<> struct TypedPredicate<CircleLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::CIRCLE; } };
	template<> struct TypedPredicate<ElevationLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::ELEVATION; } };
	template<> struct TypedPredicate<FillLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::FILL; } };
	template<> struct TypedPredicate<IntersectLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::INTERSECT; } };
	template<> struct TypedPredicate<LineLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::LINE; } };
	template<> struct TypedPredicate<RasterLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::RASTER; } };
	template<> struct TypedPredicate<SlopeAngleLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::SLOPE_ANGLE; } };
	template<> struct TypedPredicate<SlopeAspectLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::SLOPE_ASPECT; } };
	template<> struct TypedPredicate<SunlightLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::SUNLIGHT; } };
	template<> struct TypedPredicate<SymbolLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::SYMBOL; } };
	template<> struct TypedPredicate<ViewshedLayer> { bool operator()(Layer const& layer) const { return layer.type == Layer::Types::VIEWSHED; } };

	template<typename LayerT>
	struct VisiblePredicate
	{
	private:
		TypedPredicate<LayerT> const mPredicate;
	public:
		VisiblePredicate() : mPredicate(TypedPredicate<LayerT>()) {}
		bool operator()(Layer const& layer) const { return layer.isVisible() && mPredicate(layer); }
	};

	template<typename LayerT>
	struct VisibleRangePredicate
	{
	private:
		VisiblePredicate<LayerT> const mPredicate;
		float const mZoom;
	public:
		VisibleRangePredicate(float const zoom) : mPredicate(VisiblePredicate<LayerT>()), mZoom(zoom) {}
		bool operator()(Layer const& layer) const { return mPredicate(layer) && layer.range().contains(mZoom); }
	};

	template<typename LayerT, typename PredicateT>
	class FilteredLayerRange
	{
	public:

		using LayersT = std::vector<std::shared_ptr<Layer>>;
		using iterator = FilteredLayerIterator<LayerT, PredicateT>;

	public:

		FilteredLayerRange(iterator begin, iterator end) :
			mBegin(begin), mEnd(end)
		{}

		FilteredLayerRange(LayersT const& layers, PredicateT predicate) :
			FilteredLayerRange{
				iterator(layers.begin(), layers.end(), predicate),
				iterator(layers.end(), layers.end(), predicate)
			}
		{}

		inline std::shared_ptr<LayerT const> operator[](size_t i) const
		{
			return *(mBegin + i);
		}

		size_t size() const
		{
			size_t size = 0;
			for (iterator it = mBegin; it != mEnd; ++it)
			{
				++size;
			}
			return size;
		}

		inline iterator begin() const { return mBegin; }
		inline iterator end()   const { return mEnd; }

	private:

		iterator mBegin;
		iterator mEnd;

	};

} }

#endif