#ifndef __STYLING_LAYER_ITERATORS_H__
#define __STYLING_LAYER_ITERATORS_H__

#include <memory>

#include "Styling/Layers/Layer.h"

namespace onyx {
namespace Styling {

	template<typename FilteredLayerT>
	class FilteredLayerIterator
	{
	private:

		// returns whether the layer passes the filter. we delete generic function so it can't be used
		template<typename T> static inline bool passes                 (std::shared_ptr<Layer const> const&) = delete;
		template<>           static inline bool passes<Layer>          (std::shared_ptr<Layer const> const&)       { return true; }
		template<>           static inline bool passes<SourcedLayer>   (std::shared_ptr<Layer const> const& layer) { return layer->isSourced(); }
		template<>           static inline bool passes<BackgroundLayer>(std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::BACKGROUND; }
		template<>           static inline bool passes<RasterLayer>    (std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::RASTER; }
		template<>           static inline bool passes<FillLayer>      (std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::FILL;}
		template<>           static inline bool passes<LineLayer>      (std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::LINE; }
		template<>           static inline bool passes<SymbolLayer>    (std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::SYMBOL; }
		//template<>           static inline bool passes<CircleLayer>    (std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::CIRCLE; }
		template<>           static inline bool passes<ContourLayer>   (std::shared_ptr<Layer const> const& layer) { return layer->type == Layer::Type::CONTOUR; }
	
		/*
		* iterate forward until one of the following conditions is true
		*     1. we are at the end
		*     2. the iterator points to a layer of the specified type
		*/
		void slide()
		{
			size_t diff = mEnd - mPos;
			for (size_t i = 0; i < diff && !FilteredLayerIterator::passes<FilteredLayerT>(*mPos); ++i)
			{
				++mPos;
			}
		}

	public:

		using LayersT = std::vector<std::shared_ptr<Layer>>;

	public:

		FilteredLayerIterator(LayersT::const_iterator pos, LayersT::const_iterator end) : mPos(pos), mEnd(end)
		{
			slide();
		}

		inline bool operator==(FilteredLayerIterator const& rhs) const { return mPos == rhs.mPos; }
		inline bool operator!=(FilteredLayerIterator const& rhs) const { return !(*this == rhs); }

		inline std::shared_ptr<FilteredLayerT const> operator*() const
		{
			return std::static_pointer_cast<FilteredLayerT const>(*mPos);
		}

		inline FilteredLayerIterator& operator++()
		{
			// go ahead and increment immediately
			++mPos;

			// slide forward until we hit the end or an iterator of the correct type
			slide();

			// return the iterator we landed at
			return *this;
		}

		inline FilteredLayerIterator operator++(int)
		{
			FilteredLayerIterator ret = *this;
			++(*this);
			return ret;
		}

		inline FilteredLayerIterator operator+(size_t diff) const
		{
			FilteredLayerIterator ret = *this;
			for (size_t i = 0; i < diff; ++i)
			{
				++ret;
			}
			return ret;
		}

	private:

		LayersT::const_iterator mPos;
		LayersT::const_iterator mEnd;

	};

	template<typename LayerT>
	class FilteredLayerRange
	{
	public:

		using LayersT = std::vector<std::shared_ptr<Layer>>;
		using iterator = FilteredLayerIterator<LayerT>;

	public:

		FilteredLayerRange(iterator begin, iterator end) :
			mBegin(begin), mEnd(end)
		{}

		FilteredLayerRange(LayersT const& layers) :
			FilteredLayerRange{
				iterator(layers.begin(), layers.end()),
				iterator(layers.end(), layers.end())
			}
		{}

		inline std::shared_ptr<LayerT const> operator[](size_t i) const
		{
			return *(mBegin + i);
		}

		size_t size() const
		{
			size_t size = 0;
			for (iterator it = mBegin; it != mEnd; ++it)
			{
				++size;
			}
			return size;
		}

		inline iterator begin() const { return mBegin; }
		inline iterator end()   const { return mEnd; }

	private:

		iterator mBegin;
		iterator mEnd;

	};

} }

#endif