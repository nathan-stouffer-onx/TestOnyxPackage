#ifndef STYLING_LAYERS_STYLEDBASE_H
#define STYLING_LAYERS_STYLEDBASE_H

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {

	struct StyledBase
	{
		virtual ~StyledBase() = default;

		virtual Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& /* args */) const { return modificationFlags; };
		
		mutable Expressions::ModificationFlags modificationFlags = Expressions::ModificationFlags::NONE;

		// This isn't the most performant way to gather modification flags, but it saves a whole lot of redundant boilerplate,
		// and I suspect that the compiler will be able to optimize a lot of it away with loop unrolling.
		inline static Expressions::ModificationFlags evalModificationFlags(Expressions::ValidationArguments const& args, std::vector<Expressions::ExpressionBase const*> const& expressions)
		{
			auto result = Expressions::ModificationFlags::NONE;
			for (auto const& expr : expressions)
			{
				if (expr != nullptr)
				{
					result |= expr->gatherModificationFlags(args);
					if (result == Expressions::ModificationFlags::ALL)
					{
						break;
					}
				}
			}
			return result;
		}
	};

} }




#endif