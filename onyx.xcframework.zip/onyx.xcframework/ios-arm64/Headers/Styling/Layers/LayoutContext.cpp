#include "LayoutContext.h"

namespace lgigl = lucid::gigl;
namespace prim = lucid::gigl::primitives;

namespace onyx {
namespace Styling {
namespace primitives {

	lgigl::PrimitiveInfo const LayoutTypes::infos[LayoutTypes::TYPE_COUNT] =
	{
		{ prim::GiglTypes::Type<    prim::UNKNOWN									>::VALUE,              "<unknown>" },
		{ prim::GiglTypes::Type<    prim::UNDEFINED									>::VALUE,            "<undefined>" },
		{ LayoutTypes::Type<		std::shared_ptr<BackgroundLayout		const>	>::VALUE,       "BackgroundLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<CircleLayout			const>	>::VALUE,           "CircleLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<ContourLabelLayout		const>	>::VALUE,     "ContourLabelLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<ContourLineLayout		const>	>::VALUE,          "ContourLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<ElevationLayout			const>	>::VALUE,        "ElevationLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<FillLayout				const>	>::VALUE,             "FillLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<IntersectLayout			const>	>::VALUE,        "IntersectLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<LineLayout				const>	>::VALUE,             "LineLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<RasterLayout			const>	>::VALUE,           "RasterLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<SlopeAngleLayout		const>	>::VALUE,       "SlopeAngleLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<SlopeAspectLayout		const>	>::VALUE,      "SlopeAspectLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<SunlightLayout			const>	>::VALUE,         "SunlightLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<SymbolLayout			const>	>::VALUE,           "SymbolLayout" },
		{ LayoutTypes::Type<		std::shared_ptr<ViewshedLayout			const>	>::VALUE,         "ViewshedLayout" },
	};

} } }