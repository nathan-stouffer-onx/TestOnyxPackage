#ifndef __STYLING_LAYER_ARGUMENTS_H__
#define __STYLING_LAYER_ARGUMENTS_H__

#include "Styling/Expressions/Expressions.h"
#include "Styling/Layers/LayoutContext.h"
#include "Styling/Layers/PaintContext.h"

namespace onyx {
namespace Styling {

	struct InitArgs
	{
		Expressions::InitArgs const expressions;
		LayoutContext const& layouts;
		PaintContext const& paints;
	};

	struct Arguments
	{
		Expressions::Arguments const expressions;
		std::shared_ptr<LayoutContext const> const layouts;
		std::shared_ptr<PaintContext const> const paints;

		InitArgs initArgs() const
		{
			return { { expressions.context }, *layouts, *paints };
		}

		static Arguments Default()
		{
			return { Expressions::Arguments::Default(), nullptr, nullptr };
		}

	};

} }

#endif