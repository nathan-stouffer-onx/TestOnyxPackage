#pragma once

#include "Styling/Expressions/Expressions.h"
#include "Styling/Layers/Layouts/LayoutContext.h"
#include "Styling/Layers/Paints/PaintContext.h"
#include "Styling/Layers/Effects/EffectContext.h"

namespace onyx::Styling
{

	struct InitArgs
	{
		Expressions::InitArgs const expressions;
		LayoutContext const& layouts;
		PaintContext const& paints;
		EffectContext const& effects;
	};

	struct Arguments
	{
		Expressions::Arguments const expressions;
		std::shared_ptr<LayoutContext const> const layouts;
		std::shared_ptr<PaintContext const> const paints;
		std::shared_ptr<EffectContext const> const effects;

		InitArgs initArgs() const
		{
			return { { expressions.context }, *layouts, *paints, *effects };
		}

		static Arguments Default()
		{
			return { Expressions::Arguments::Default(), nullptr, nullptr, nullptr };
		}

	};

}