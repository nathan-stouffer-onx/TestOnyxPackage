#pragma once

#include <memory>
#include <string>

#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Layers/Arguments.h"
#include "Styling/Layers/Effects/Effect.h"
#include "Styling/Layers/Layouts/Layout.h"
#include "Styling/Layers/Paints/Paint.h"
#include "Styling/Sources/Source.h"
#include "Styling/Styles/CircleStyle.h"
#include "Styling/Styles/ContourConfigs.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/IconStyle.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/ShadowConfigs.h"
#include "Styling/Styles/TerrainConfigs.h"
#include "Styling/Styles/Realize.h"

namespace onyx::Styling
{

	/*
	* A class to represent a Style Layer that is rendered on the map. Layers can be a number of different types and the bulk
	* of their definition is in the Layout and Paint members
	*/
	struct Layer
	{

		typedef int zoom_level_t;

		using types_int_t = uint32_t;

		// When adding a new layer type, there are a number of things that should be updated:
		//   - Types enum
		//   - Derived layer/layout/paint class
		//   - Styling/Layers/Declarations.h
		//   - Styling/Layers.Iterators.h
		//   - Contexts for layout/paint
		enum Types : types_int_t
		{
			UNKNOWN       = 0x0000,
			BACKGROUND    = 0x0001,
			CIRCLE        = 0x0002,
			CONTOUR_LABEL = 0x0004,
			CONTOUR_LINE  = 0x0008,
			ELEVATION     = 0x0010,
			FILL          = 0x0020,
			HILLSHADE     = 0x0040,
			INTERSECT     = 0x0080,
			LINE          = 0x0100,
			RASTER        = 0x0200,
			SLOPE_ANGLE   = 0x0400,
			SLOPE_ASPECT  = 0x0800,
			SUNLIGHT      = 0x1000,
			SYMBOL        = 0x2000,
			VIEWSHED      = 0x4000,
		};

		inline static bool isDpiDependent(Types type)
		{
			types_int_t constexpr mask = Types::CIRCLE | Types::CONTOUR_LABEL | Types::LINE | Types::SYMBOL;
			return (type & mask) != 0;
		}

		std::string id = "";

		Types type = Types::UNKNOWN;

		zoom_level_t minZoom = 0;
		zoom_level_t maxZoom = 24;

		Expressions::BooleanT::Ptr filter = Expressions::Boolean::construct(true);

		std::vector<std::string> groups;

		std::shared_ptr<LayoutBase> layout;

		std::shared_ptr<PaintBase> paint;

		std::shared_ptr<EffectBase> effect;

		size_t elementCap = std::numeric_limits<size_t>::max();

		Layer() = delete;
		virtual ~Layer() = default;

		inline bool isElementOf(std::string const& group) const { return std::find(groups.begin(), groups.end(), group) != groups.end(); }

		inline bool isVisible() const { return layout->visibility == LayoutBase::Visibility::VISIBLE; }
		inline bool isSourced() const { return type != Types::UNKNOWN && type != Types::BACKGROUND; }
		
		inline bool isVector() const
		{ 
			types_int_t constexpr mask = Types::CIRCLE | Types::CONTOUR_LABEL | Types::FILL | Types::LINE | Types::SYMBOL;
			return (type & mask) != 0;
		}
		
		inline bool isShader() const
		{
			using T = Types;
			types_int_t constexpr mask = T::BACKGROUND | T::CONTOUR_LINE | T::ELEVATION | T::HILLSHADE | T::INTERSECT | T::RASTER | T::SLOPE_ANGLE | T::SLOPE_ASPECT | T::SUNLIGHT | T::VIEWSHED;
			return (type & mask) != 0;
		}

		inline lmath::Range<float> range() const { return { static_cast<float>(minZoom), static_cast<float>(maxZoom) }; }
		
		// NOTE: We should be careful to only call this method when a layer is not being edited. If that happens,
		// the application may crash from dereferencing invalid memory or the result may be incorrect
		Expressions::Dependencies dependencies(InitArgs const& args) const;

		// NOTE: this should be called whenever a layer property gets edited
		void invalidateDependenciesCache();

		void validate(InitArgs const& args) const;

	protected:

		Expressions::Dependencies mutable mDependencies = Expressions::Dependencies::UNSET;
		bool mutable mStaleDependencies = true;
		
		Layer(Types _type, std::shared_ptr<LayoutBase> _layout, std::shared_ptr<PaintBase> _paint, std::shared_ptr<EffectBase> _effect) :
			type(_type), layout(_layout), paint(_paint), effect(_effect)
		{}

		template<typename T, typename V>
		static std::shared_ptr<T> downcast(V value)
		{
			std::shared_ptr<T> cast = std::dynamic_pointer_cast<T>(value);
			ONYX_ASSERT(cast != nullptr, "attempted downcast to invalid type");
			return cast;
		}

	};

	struct SourcedLayer : public Layer
	{
		// name of the data source used to define this layer
		std::string source = "";

		// name of the layer to use in a vector tile source -- required for vector tile sources and prohibited
		// for all other source types
		std::string sourceLayer = "";

		// const pointer to FeatureStates -- only relevant for vector layers
		std::shared_ptr<FeatureStatesT const> states = nullptr;

		virtual ~SourcedLayer() = default;

		virtual void validate(Source const& src) const = 0;

	protected:

		SourcedLayer(Types _type, std::shared_ptr<LayoutBase> _layout, std::shared_ptr<PaintBase> _paint, std::shared_ptr<EffectBase> _effect) : Layer(_type, _layout, _paint, _effect) {}
	};

	struct BackgroundLayer final : public Layer
	{
		BackgroundLayer() : Layer(Types::BACKGROUND, std::make_shared<BackgroundLayout>(), std::make_shared<BackgroundPaint>(), std::make_shared<BackgroundEffect>()) {}

		BackgroundStyle realize(Arguments const& args) const
		{
			BackgroundStyle style;
			Styling::realize(args, *getLayout(), style);
			Styling::realize(args, *getPaint(), style);
			Styling::realize(args, *getEffect(), style);
			return style;
		}

		std::shared_ptr<BackgroundLayout const> getLayout() const { return Layer::downcast<BackgroundLayout const>(layout); }
		std::shared_ptr<BackgroundPaint  const> getPaint()  const { return Layer::downcast<BackgroundPaint  const>(paint); }
		std::shared_ptr<BackgroundEffect const> getEffect() const { return Layer::downcast<BackgroundEffect const>(effect); }

		std::shared_ptr<BackgroundLayout> getLayout() { return Layer::downcast<BackgroundLayout>(layout); }
		std::shared_ptr<BackgroundPaint>  getPaint() { return Layer::downcast<BackgroundPaint>(paint); }
		std::shared_ptr<BackgroundEffect> getEffect() { return Layer::downcast<BackgroundEffect>(effect); }
	};

	template<typename LayoutT, typename PaintT, typename EffectT>
	struct StyledLayer : public SourcedLayer
	{
		std::shared_ptr<LayoutT const> getLayout() const { return Layer::downcast<LayoutT const>(layout); }
		std::shared_ptr<PaintT  const> getPaint()  const { return Layer::downcast<PaintT  const>(paint); }
		std::shared_ptr<EffectT const> getEffect() const { return Layer::downcast<EffectT const>(effect); }

		std::shared_ptr<LayoutT> getLayout() { return Layer::downcast<LayoutT>(layout); }
		std::shared_ptr<PaintT>  getPaint() { return Layer::downcast<PaintT>(paint); }
		std::shared_ptr<EffectT> getEffect() { return Layer::downcast<EffectT>(effect); }
		
		virtual ~StyledLayer() = default;

	protected:

		StyledLayer(Types _type) : SourcedLayer(_type, std::make_shared<LayoutT>(), std::make_shared<PaintT>(), std::make_shared<EffectT>()) {}
		StyledLayer(Types _type, std::shared_ptr<LayoutT> const& _layout, std::shared_ptr<PaintT> const& _paint, std::shared_ptr<EffectT> const& _effect) : SourcedLayer(_type, _layout, _paint, _effect) {}
	};

	struct CircleLayer final : public StyledLayer<CircleLayout, CirclePaint, CircleEffect>
	{
		CircleLayer() : StyledLayer<CircleLayout, CirclePaint, CircleEffect>(Types::CIRCLE) {}

		void validate(Source const& src) const override;

		CircleStyle realize(Arguments const& args) const
		{
			CircleStyle style;
			Styling::realize(args, *getLayout(), style);
			Styling::realize(args, *getPaint(), style);
			return style;
		}

	};

	struct ContourLabelLayer final : public StyledLayer<ContourLabelLayout, ContourLabelPaint, ContourLabelEffect>
	{
		ContourLabelLayer() : StyledLayer<ContourLabelLayout, ContourLabelPaint, ContourLabelEffect>(Types::CONTOUR_LABEL) {}

		void validate(Source const& src) const override;

		ContourLabelConfig realize(Arguments const& args) const
		{
			ContourLabelConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			return config;
		}
	};

	struct ContourLineLayer final : public StyledLayer<ContourLineLayout, ContourLinePaint, ContourLineEffect>
	{
		ContourLineLayer() : StyledLayer<ContourLineLayout, ContourLinePaint, ContourLineEffect>(Types::CONTOUR_LINE) {}

		void validate(Source const& src) const override;

		ContourLineConfig realize(Arguments const& args) const
		{
			ContourLineConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}
	};

	struct ElevationLayer final : public StyledLayer<ElevationLayout, ElevationPaint, ElevationEffect>
	{
		ElevationLayer() : StyledLayer<ElevationLayout, ElevationPaint, ElevationEffect>(Types::ELEVATION) {}
		
		void validate(Source const& src) const override;

		ElevationConfig realize(Arguments const& args) const
		{
			ElevationConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}
	};

	struct FillLayer final : public StyledLayer<FillLayout, FillPaint, FillEffect>
	{
		FillLayer() : StyledLayer<FillLayout, FillPaint, FillEffect>(Types::FILL) {}

		void validate(Source const& src) const override;

		float sortKey(Arguments const& args) const;

		FillStyle realize(Arguments const& args) const
		{
			FillStyle style;
			Styling::realize(args, *getLayout(), style);
			Styling::realize(args, *getPaint(), style);
			return style;
		}

		FillStyle::Effect effect(Arguments const& args) const
		{
			FillStyle::Effect effect;
			Styling::realize(args, *getEffect(), effect);
			return effect;
		}

	};

	struct HillshadeLayer final : public StyledLayer<HillshadeLayout, HillshadePaint, HillshadeEffect>
	{
		HillshadeLayer() : StyledLayer<HillshadeLayout, HillshadePaint, HillshadeEffect>(Types::HILLSHADE) {}

		void validate(Source const& src) const override;

		HillshadeConfig realize(Arguments const& args) const
		{
			HillshadeConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}

	};

	struct IntersectLayer final : public StyledLayer<IntersectLayout, IntersectPaint, IntersectEffect>
	{
		IntersectLayer() : StyledLayer<IntersectLayout, IntersectPaint, IntersectEffect>(Types::INTERSECT) {}

		void validate(Source const& src) const override;

		IntersectConfig realize(Arguments const& args) const
		{
			IntersectConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}

	};

	struct LineLayer final : public StyledLayer<LineLayout, LinePaint, LineEffect>
	{
		LineLayer() : StyledLayer<LineLayout, LinePaint, LineEffect>(Types::LINE) {}

		void validate(Source const& src) const override;

		float sortKey(Arguments const& args) const;

		LineStyle realize(Arguments const& args) const
		{
			LineStyle style;
			Styling::realize(args, *getLayout(), style);
			Styling::realize(args, *getPaint(), style);
			return style;
		}

		LineStyle::Effect effect(Arguments const& args) const
		{
			LineStyle::Effect effect;
			Styling::realize(args, *getEffect(), effect);
			return effect;
		}

	};

	struct RasterLayer final : public StyledLayer<RasterLayout, RasterPaint, RasterEffect>
	{

		RasterLayer() : StyledLayer<RasterLayout, RasterPaint, RasterEffect>(Types::RASTER) {}
		
		void validate(Source const& src) const override;

		RasterStyle realize(Arguments const& args) const
		{
			RasterStyle style;
			Styling::realize(args, *getLayout(), style);
			Styling::realize(args, *getPaint(), style);
			Styling::realize(args, *getEffect(), style);
			return style;
		}

	};

	struct SlopeAngleLayer final : public StyledLayer<SlopeAngleLayout, SlopeAnglePaint, SlopeAngleEffect>
	{
		SlopeAngleLayer() : StyledLayer<SlopeAngleLayout, SlopeAnglePaint, SlopeAngleEffect>(Types::SLOPE_ANGLE) {}

		void validate(Source const& src) const override;

		SlopeAngleConfig realize(Arguments const& args) const
		{
			SlopeAngleConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}
	};

	struct SlopeAspectLayer final : public StyledLayer<SlopeAspectLayout, SlopeAspectPaint, SlopeAspectEffect>
	{
		SlopeAspectLayer() : StyledLayer<SlopeAspectLayout, SlopeAspectPaint, SlopeAspectEffect>(Types::SLOPE_ASPECT) {}

		void validate(Source const& src) const override;

		SlopeAspectConfig realize(Arguments const& args) const
		{
			SlopeAspectConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}
	};

	struct SunlightLayer final : public StyledLayer<SunlightLayout, SunlightPaint, SunlightEffect>
	{
		SunlightLayer() : StyledLayer<SunlightLayout, SunlightPaint, SunlightEffect>(Types::SUNLIGHT) {}

		void validate(Source const& src) const override;

		SunlightConfig realize(Arguments const& args) const
		{
			SunlightConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}

	};

	struct SymbolLayer final : public StyledLayer<SymbolLayout, SymbolPaint, SymbolEffect>
	{
		SymbolLayer() : StyledLayer<SymbolLayout, SymbolPaint, SymbolEffect>(Types::SYMBOL) {}

		void validate(Source const& src) const override;

		float sortKey(Arguments const& args) const;

		SymbolStyle realize(Arguments const& args) const
		{
			SymbolStyle style;
			Styling::realize(args, *getLayout(), style);
			Styling::realize(args, *getPaint(), style);
			return style;
		}

	};

	struct ViewshedLayer final : public StyledLayer<ViewshedLayout, ViewshedPaint, ViewshedEffect>
	{
		ViewshedLayer() : StyledLayer<ViewshedLayout, ViewshedPaint, ViewshedEffect>(Types::VIEWSHED) {}

		void validate(Source const& src) const override;

		ViewshedConfig realize(Arguments const& args) const
		{
			ViewshedConfig config;
			Styling::realize(args, *getLayout(), config);
			Styling::realize(args, *getPaint(), config);
			Styling::realize(args, *getEffect(), config);
			return config;
		}
	};

}

namespace std
{

	template<>
	inline onyx::Styling::Layer::Types fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Layer::Types> const nameMap =
		{
			{ "background",					onyx::Styling::Layer::Types::BACKGROUND			},
			{ "circle",						onyx::Styling::Layer::Types::CIRCLE				},
			{ "contour-label",				onyx::Styling::Layer::Types::CONTOUR_LABEL		},
			{ "contour-line",				onyx::Styling::Layer::Types::CONTOUR_LINE		},
			{ "elevation",					onyx::Styling::Layer::Types::ELEVATION			},
			{ "fill",						onyx::Styling::Layer::Types::FILL				},
			{ "hillshade",					onyx::Styling::Layer::Types::HILLSHADE			},
			{ "intersect",					onyx::Styling::Layer::Types::INTERSECT			},
			{ "line",						onyx::Styling::Layer::Types::LINE				},
			{ "raster",						onyx::Styling::Layer::Types::RASTER				},
			{ "slope-angle",				onyx::Styling::Layer::Types::SLOPE_ANGLE		},
			{ "slope-aspect",				onyx::Styling::Layer::Types::SLOPE_ASPECT		},
			{ "sunlight",					onyx::Styling::Layer::Types::SUNLIGHT			},
			{ "symbol",						onyx::Styling::Layer::Types::SYMBOL				},
			{ "viewshed",					onyx::Styling::Layer::Types::VIEWSHED			},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Layer::Type");
	}

	inline std::string_view toStringView(onyx::Styling::Layer::Types value)
	{
		static std::unordered_map<onyx::Styling::Layer::Types, std::string_view> const nameMap =
		{
			{ onyx::Styling::Layer::Types::BACKGROUND,				"background"			},
			{ onyx::Styling::Layer::Types::CIRCLE,					"circle"				},
			{ onyx::Styling::Layer::Types::CONTOUR_LABEL,			"contour-label"			},
			{ onyx::Styling::Layer::Types::CONTOUR_LINE,			"contour-line"			},
			{ onyx::Styling::Layer::Types::ELEVATION,				"elevation",			},
			{ onyx::Styling::Layer::Types::FILL,					"fill"					},
			{ onyx::Styling::Layer::Types::HILLSHADE,				"hillshade",			},
			{ onyx::Styling::Layer::Types::INTERSECT,				"intersect",			},
			{ onyx::Styling::Layer::Types::LINE,					"line"					},
			{ onyx::Styling::Layer::Types::RASTER,					"raster"				},
			{ onyx::Styling::Layer::Types::SLOPE_ANGLE,				"slope-angle",			},
			{ onyx::Styling::Layer::Types::SLOPE_ASPECT,			"slope-aspect",			},
			{ onyx::Styling::Layer::Types::SUNLIGHT,				"sunlight",				},
			{ onyx::Styling::Layer::Types::SYMBOL,					"symbol"				},
			{ onyx::Styling::Layer::Types::VIEWSHED,				"viewshed",				},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Layer::Type");
	}

}