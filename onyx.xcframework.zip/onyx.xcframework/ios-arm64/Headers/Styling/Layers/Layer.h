#ifndef __STYLING_LAYER_H__
#define __STYLING_LAYER_H__

#include <memory>
#include <string>

#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Layers/Arguments.h"
#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"
#include "Styling/Sources/Source.h"
#include "Styling/Styles/CircleStyle.h"
#include "Styling/Styles/ContourConfigs.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/IconStyle.h"
#include "Styling/Styles/LabelStyle.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/ShadowConfigs.h"
#include "Styling/Styles/TerrainConfigs.h"
#include "Styling/Styles/Realize.h"

namespace onyx {
namespace Styling {

	/*
	* A class to represent a Style Layer that is rendered on the map. Layers can be a number of different types and the bulk
	* of their definition is in the Layout and Paint members
	*/
	struct Layer
	{

		typedef int zoom_level_t;

		// When adding a new layer type, there are a number of things that should be updated:
		//   - Types enum
		//   - Derived layer/layout/paint class
		//   - Styling/Layers/Declarations.h
		//   - Styling/Layers.Iterators.h
		//   - Contexts for layout/paint
		enum class Types
		{
			UNKNOWN,
			BACKGROUND,
			CIRCLE,
			CONTOUR_LABEL,
			CONTOUR_LINE,
			ELEVATION,
			FILL,
			HILLSHADE,
			INTERSECT,
			LINE,
			RASTER,
			SLOPE_ANGLE,
			SLOPE_ASPECT,
			SUNLIGHT,
			SYMBOL,
			VIEWSHED
		};

		std::string id = "";

		Types type = Types::UNKNOWN;

		zoom_level_t maxZoom = 24;
		zoom_level_t minZoom = 0;

		Expressions::BooleanT::Ptr filter = Expressions::Boolean::construct(true);

		std::vector<std::string> groups;

		std::shared_ptr<LayoutBase> layout;

		std::shared_ptr<PaintBase> paint;

		size_t elementCap = std::numeric_limits<size_t>::max();

		Layer() = delete;
		virtual ~Layer() = default;

		inline bool isElementOf(std::string const& group) const { return std::find(groups.begin(), groups.end(), group) != groups.end(); }

		inline bool isVisible() const { return layout->visibility == LayoutBase::Visibility::VISIBLE; }
		inline bool isSourced() const { return type != Types::UNKNOWN && type != Types::BACKGROUND; }
		inline bool isVector()  const { return type == Types::CIRCLE || type == Types::FILL || type == Types::LINE || type == Types::SYMBOL; }
		
		inline bool isShaderLayer() const
		{
			return type == Types::BACKGROUND
				|| type == Types::CONTOUR_LINE
				|| type == Types::ELEVATION
				|| type == Types::HILLSHADE
				|| type == Types::INTERSECT
				|| type == Types::RASTER
				|| type == Types::SLOPE_ANGLE
				|| type == Types::SLOPE_ASPECT
				|| type == Types::SUNLIGHT
				|| type == Types::VIEWSHED;
		}

		inline lmath::Range<float> range() const { return { static_cast<float>(minZoom), static_cast<float>(maxZoom) }; }
		
		// NOTE: We should be careful to only call this method when a layer is not being edited. If that happens,
		// the application may crash from dereferencing invalid memory or the result may be incorrect
		Expressions::Dependencies dependencies(InitArgs const& args) const;

		// NOTE: this should be called whenever a layer property gets edited
		void invalidateDependenciesCache();

		void validate(InitArgs const& args) const;

	protected:

		Expressions::Dependencies mutable mDependencies = Expressions::Dependencies::UNSET;
		bool mutable mStaleDependencies = true;
		
		Layer(Types _type, std::shared_ptr<LayoutBase> _layout, std::shared_ptr<PaintBase> _paint) :
			type(_type), layout(_layout), paint(_paint)
		{}

		template<typename T, typename V>
		static std::shared_ptr<T> downcast(V value)
		{
			std::shared_ptr<T> cast = std::dynamic_pointer_cast<T>(value);
			ONYX_ASSERT(cast != nullptr, "attempted downcast to invalid type");
			return cast;
		}

	};

	struct SourcedLayer : public Layer
	{
		// name of the data source used to define this layer
		std::string source = "";

		// name of the layer to use in a vector tile source -- required for vector tile sources and prohibited
		// for all other source types
		std::string sourceLayer = "";

		// const pointer to FeatureStates -- only relevant for vector layers
		std::shared_ptr<FeatureStatesT const> states = nullptr;

		virtual ~SourcedLayer() = default;

		virtual void validate(Source const& src) const = 0;

	protected:

		SourcedLayer(Types _type, std::shared_ptr<LayoutBase> _layout, std::shared_ptr<PaintBase> _paint) : Layer(_type, _layout, _paint) {}
	};

	struct BackgroundLayer final : public Layer
	{
		BackgroundLayer() : Layer(Types::BACKGROUND, std::make_shared<BackgroundLayout>(), std::make_shared<BackgroundPaint>()) {}

		BackgroundStyle realizeBackgroundStyle(Arguments const& args) const
		{
			BackgroundStyle style;
			realize(args, *getLayout(), style);
			realize(args, *getPaint(), style);
			return style;
		}

		std::shared_ptr<BackgroundLayout const> getLayout() const { return Layer::downcast<BackgroundLayout const>(layout); }
		std::shared_ptr<BackgroundPaint  const> getPaint()  const { return Layer::downcast<BackgroundPaint  const>(paint); }

		std::shared_ptr<BackgroundLayout> getLayout() { return Layer::downcast<BackgroundLayout>(layout); }
		std::shared_ptr<BackgroundPaint>  getPaint() { return Layer::downcast<BackgroundPaint>(paint); }
	};

	template<typename LayoutT, typename PaintT>
	struct StyledLayer : public SourcedLayer
	{
		std::shared_ptr<LayoutT const> getLayout() const { return Layer::downcast<LayoutT const>(layout); }
		std::shared_ptr<PaintT  const> getPaint()  const { return Layer::downcast<PaintT  const>(paint); }

		std::shared_ptr<LayoutT> getLayout() { return Layer::downcast<LayoutT>(layout); }
		std::shared_ptr<PaintT>  getPaint() { return Layer::downcast<PaintT>(paint); }
		
		virtual ~StyledLayer() = default;

	protected:

		StyledLayer(Types _type) : SourcedLayer(_type, std::make_shared<LayoutT>(), std::make_shared<PaintT>()) {}
		StyledLayer(Types _type, std::shared_ptr<LayoutT> const& _layout, std::shared_ptr<PaintT> const& _paint) : SourcedLayer(_type, _layout, _paint) {}
	};

	struct CircleLayer final : public StyledLayer<CircleLayout, CirclePaint>
	{
		CircleLayer() : StyledLayer<CircleLayout, CirclePaint>(Types::CIRCLE) {}

		void validate(Source const& src) const override;

		CircleStyle realizeCircleStyle(Arguments const& args) const
		{
			CircleStyle style;
			realize(args, *getLayout(), style);
			realize(args, *getPaint(), style);
			return style;
		}

	};

	struct ContourLabelLayer final : public StyledLayer<ContourLabelLayout, ContourLabelPaint>
	{
		ContourLabelLayer() : StyledLayer<ContourLabelLayout, ContourLabelPaint>(Types::CONTOUR_LABEL) {}

		void validate(Source const& src) const override;

		FontStyle realizeFontStyle(Arguments const& args) const
		{
			FontStyle style;
			realizeLayout(args, *getLayout(), style);
			realizePaint(args, *getPaint(), style);
			return style;
		}

		ContourLabelConfig realizeContourLabelConfig(Arguments const& args) const
		{
			ContourLabelConfig config;
			realize(args, *getLayout(), config);
			return config;
		}
	};

	struct ContourLineLayer final : public StyledLayer<ContourLineLayout, ContourLinePaint>
	{
		ContourLineLayer() : StyledLayer<ContourLineLayout, ContourLinePaint>(Types::CONTOUR_LINE) {}

		void validate(Source const& src) const override;

		ContourLineConfig realizeContourLineConfig(Arguments const& args) const
		{
			ContourLineConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}
	};

	struct ElevationLayer final : public StyledLayer<ElevationLayout, ElevationPaint>
	{
		ElevationLayer() : StyledLayer<ElevationLayout, ElevationPaint>(Types::ELEVATION) {}
		
		void validate(Source const& src) const override;

		ElevationConfig realizeElevationConfig(Arguments const& args) const
		{
			ElevationConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}
	};

	struct FillLayer final : public StyledLayer<FillLayout, FillPaint>
	{
		FillLayer() : StyledLayer<FillLayout, FillPaint>(Types::FILL) {}

		void validate(Source const& src) const override;

		FillStyle realizeFillStyle(Arguments const& args) const
		{
			FillStyle style;
			realize(args, *getLayout(), style);
			realize(args, *getPaint(), style);
			return style;
		}

	};

	struct HillshadeLayer final : public StyledLayer<HillshadeLayout, HillshadePaint>
	{
		HillshadeLayer() : StyledLayer<HillshadeLayout, HillshadePaint>(Types::HILLSHADE) {}

		void validate(Source const& src) const override;

		HillshadeConfig realizeHillshadeConfig(Arguments const& args) const
		{
			HillshadeConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}

	};

	struct IntersectLayer final : public StyledLayer<IntersectLayout, IntersectPaint>
	{
		IntersectLayer() : StyledLayer<IntersectLayout, IntersectPaint>(Types::INTERSECT) {}

		void validate(Source const& src) const override;

		IntersectConfig realizeIntersectConfig(Arguments const& args) const
		{
			IntersectConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}

	};

	struct LineLayer final : public StyledLayer<LineLayout, LinePaint>
	{
		LineLayer() : StyledLayer<LineLayout, LinePaint>(Types::LINE) {}

		void validate(Source const& src) const override;

		LineStyle realizeLineStyle(Arguments const& args) const
		{
			LineStyle style;
			realize(args, *getLayout(), style);
			realize(args, *getPaint(), style);
			return style;
		}
	};

	struct RasterLayer final : public StyledLayer<RasterLayout, RasterPaint>
	{

		RasterLayer() : StyledLayer<RasterLayout, RasterPaint>(Types::RASTER) {}
		
		void validate(Source const& src) const override;

		RasterStyle realizeRasterStyle(Arguments const& args) const
		{
			RasterStyle style;
			realize(args, *getLayout(), style);
			realize(args, *getPaint(), style);
			return style;
		}

	};

	struct SlopeAngleLayer final : public StyledLayer<SlopeAngleLayout, SlopeAnglePaint>
	{
		SlopeAngleLayer() : StyledLayer<SlopeAngleLayout, SlopeAnglePaint>(Types::SLOPE_ANGLE) {}

		void validate(Source const& src) const override;

		SlopeAngleConfig realizeSlopeAngleConfig(Arguments const& args) const
		{
			SlopeAngleConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}
	};

	struct SlopeAspectLayer final : public StyledLayer<SlopeAspectLayout, SlopeAspectPaint>
	{
		SlopeAspectLayer() : StyledLayer<SlopeAspectLayout, SlopeAspectPaint>(Types::SLOPE_ASPECT) {}

		void validate(Source const& src) const override;

		SlopeAspectConfig realizeSlopeAspectConfig(Arguments const& args) const
		{
			SlopeAspectConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}
	};

	struct SunlightLayer final : public StyledLayer<SunlightLayout, SunlightPaint>
	{
		SunlightLayer() : StyledLayer<SunlightLayout, SunlightPaint>(Types::SUNLIGHT) {}

		void validate(Source const& src) const override;

		SunlightConfig realizeSunlightConfig(Arguments const& args) const
		{
			SunlightConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}

	};

	struct SymbolLayer final : public StyledLayer<SymbolLayout, SymbolPaint>
	{
		SymbolLayer() : StyledLayer<SymbolLayout, SymbolPaint>(Types::SYMBOL) {}

		void validate(Source const& src) const override;

		template<typename LayoutT, typename PaintT>
		static FontStyle realizeFontStyle(Arguments const& args, LayoutT const& layout, PaintT const& paint)
		{
			FontStyle style;
			realizeLayout<LayoutT>(args, layout, style);
			realizePaint<PaintT>(args, paint, style);
			return style;
		}

		template<typename LayoutT, typename PaintT>
		static LabelStyle realizeLabelStyle(Arguments const& args, LayoutT const& layout, PaintT const& paint)
		{
			LabelStyle style;
			realizeLayout<LayoutT>(args, layout, style);
			realizePaint<PaintT>(args, paint, style);
			return style;
		}

		template<typename LayoutT, typename PaintT>
		static IconStyle realizeIconStyle(Arguments const& args, LayoutT const& layout, PaintT const& paint)
		{
			IconStyle style;
			realizeLayout<LayoutT>(args, layout, style);
			realizePaint<PaintT>(args, paint, style);
			return style;
		}

		FontStyle realizeFontStyle(Arguments const& args) const
		{
			return SymbolLayer::realizeFontStyle(args, *getLayout(), *getPaint());
		}

		LabelStyle realizeLabelStyle(Arguments const& args) const
		{
			return SymbolLayer::realizeLabelStyle(args, *getLayout(), *getPaint());
		}

		IconStyle realizeIconStyle(Arguments const& args) const
		{
			return SymbolLayer::realizeIconStyle(args, *getLayout(), *getPaint());
		}
	};

	struct ViewshedLayer final : public StyledLayer<ViewshedLayout, ViewshedPaint>
	{
		ViewshedLayer() : StyledLayer<ViewshedLayout, ViewshedPaint>(Types::VIEWSHED) {}

		void validate(Source const& src) const override;

		ViewshedConfig realizeViewshedConfig(Arguments const& args) const
		{
			ViewshedConfig config;
			realize(args, *getLayout(), config);
			realize(args, *getPaint(), config);
			return config;
		}
	};

} }

namespace std
{

	template<>
	inline onyx::Styling::Layer::Types fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Layer::Types> const nameMap =
		{
			{ "background",					onyx::Styling::Layer::Types::BACKGROUND			},
			{ "circle",						onyx::Styling::Layer::Types::CIRCLE				},
			{ "contour-label",				onyx::Styling::Layer::Types::CONTOUR_LABEL		},
			{ "contour-line",				onyx::Styling::Layer::Types::CONTOUR_LINE		},
			{ "elevation",					onyx::Styling::Layer::Types::ELEVATION			},
			{ "fill",						onyx::Styling::Layer::Types::FILL				},
			{ "hillshade",					onyx::Styling::Layer::Types::HILLSHADE			},
			{ "intersect",					onyx::Styling::Layer::Types::INTERSECT			},
			{ "line",						onyx::Styling::Layer::Types::LINE				},
			{ "raster",						onyx::Styling::Layer::Types::RASTER				},
			{ "slope-angle",				onyx::Styling::Layer::Types::SLOPE_ANGLE		},
			{ "slope-aspect",				onyx::Styling::Layer::Types::SLOPE_ASPECT		},
			{ "sunlight",					onyx::Styling::Layer::Types::SUNLIGHT			},
			{ "symbol",						onyx::Styling::Layer::Types::SYMBOL				},
			{ "viewshed",					onyx::Styling::Layer::Types::VIEWSHED			},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Layer::Type");
	}

	inline std::string_view toStringView(onyx::Styling::Layer::Types value)
	{
		static std::unordered_map<onyx::Styling::Layer::Types, std::string_view> const nameMap =
		{
			{ onyx::Styling::Layer::Types::BACKGROUND,				"background"			},
			{ onyx::Styling::Layer::Types::CIRCLE,					"circle"				},
			{ onyx::Styling::Layer::Types::CONTOUR_LABEL,			"contour-label"			},
			{ onyx::Styling::Layer::Types::CONTOUR_LINE,			"contour-line"			},
			{ onyx::Styling::Layer::Types::ELEVATION,				"elevation",			},
			{ onyx::Styling::Layer::Types::FILL,					"fill"					},
			{ onyx::Styling::Layer::Types::HILLSHADE,				"hillshade",			},
			{ onyx::Styling::Layer::Types::INTERSECT,				"intersect",			},
			{ onyx::Styling::Layer::Types::LINE,					"line"					},
			{ onyx::Styling::Layer::Types::RASTER,					"raster"				},
			{ onyx::Styling::Layer::Types::SLOPE_ANGLE,				"slope-angle",			},
			{ onyx::Styling::Layer::Types::SLOPE_ASPECT,			"slope-aspect",			},
			{ onyx::Styling::Layer::Types::SUNLIGHT,				"sunlight",				},
			{ onyx::Styling::Layer::Types::SYMBOL,					"symbol"				},
			{ onyx::Styling::Layer::Types::VIEWSHED,				"viewshed",				},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Layer::Type");
	}

}

#endif