#ifndef __STYLING_LAYER_H__
#define __STYLING_LAYER_H__

#include <memory>
#include <string>

#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/LabelStyle.h"
#include "Styling/Styles/IconStyle.h"

namespace onyx {
namespace Styling {

	/*
	* A class to represent a Style Layer that is rendered on the map. Layers can be a number of different types and the bulk
	* of their definition is in the Layout and Paint members
	*/
	struct Layer
	{

		typedef int zoom_level_t;

		// TODO possibly have HEATMAP, HILLSHADE, and SKY as well
		enum class Type
		{
			UNKNOWN,
			BACKGROUND,
			RASTER,
			FILL,
			LINE,
			SYMBOL,
			CIRCLE,
			CONTOUR
		};

		std::string id = "";

		Type type = Type::UNKNOWN;

		zoom_level_t maxZoom = 24;
		zoom_level_t minZoom = 0;

		Expressions::BooleanT::Ptr filter = Expressions::Boolean::construct(true);

		std::shared_ptr<LayoutBase> layout;

		std::shared_ptr<PaintBase> paint;

		size_t elementCap = std::numeric_limits<size_t>::max();

		Layer() = delete;
		virtual ~Layer() = default;

		inline bool isVisible() const { return layout->visibility == LayoutBase::Visibility::VISIBLE; }
		inline bool isSourced() const { return type != Type::UNKNOWN && type != Type::BACKGROUND; }

		void initialize(Expressions::ValidationArguments const& args)
		{
			modificationFlags = layout->initialize(args) | paint->initialize(args);
		}

		Expressions::ModificationFlags modificationFlags = Expressions::ModificationFlags::NONE;

	protected:
		
		Layer(Type _type, std::shared_ptr<LayoutBase> _layout, std::shared_ptr<PaintBase> _paint) :
			type(_type), layout(_layout), paint(_paint)
		{}

		template<typename T, typename V>
		static std::shared_ptr<T> downcast(V value)
		{
			std::shared_ptr<T> cast = std::dynamic_pointer_cast<T>(value);
			MAP3D_ASSERT(cast != nullptr, "attempted downcast to invalid type");
			return cast;
		}

	};

	struct SourcedLayer : public Layer
	{
		// name of the data source used to define this layer
		std::string source = "";

		// name of the layer to use in a vector tile source -- required for vector tile sources and prohibited
		// for all other source types
		std::string sourceLayer = "";

		virtual ~SourcedLayer() = default;

	protected:

		SourcedLayer(Type _type, std::shared_ptr<LayoutBase> _layout, std::shared_ptr<PaintBase> _paint) : Layer(_type, _layout, _paint) {}
	};

	struct BackgroundLayer final : public Layer
	{
		BackgroundLayer() : Layer(Type::BACKGROUND, std::make_shared<BackgroundLayout>(), std::make_shared<BackgroundPaint>()) {}

		std::shared_ptr<BackgroundLayout const> getLayout() const { return Layer::downcast<BackgroundLayout const>(layout); }
		std::shared_ptr<BackgroundPaint  const> getPaint()  const { return Layer::downcast<BackgroundPaint  const>(paint); }

		std::shared_ptr<BackgroundLayout> getLayout() { return Layer::downcast<BackgroundLayout>(layout); }
		std::shared_ptr<BackgroundPaint>  getPaint() { return Layer::downcast<BackgroundPaint>(paint); }
	};

	template<typename LayoutT, typename PaintT>
	struct StyledLayer : public SourcedLayer
	{
		std::shared_ptr<LayoutT const> getLayout() const { return Layer::downcast<LayoutT const>(layout); }
		std::shared_ptr<PaintT  const> getPaint()  const { return Layer::downcast<PaintT  const>(paint); }

		std::shared_ptr<LayoutT> getLayout() { return Layer::downcast<LayoutT>(layout); }
		std::shared_ptr<PaintT>  getPaint() { return Layer::downcast<PaintT>(paint); }
		
		virtual ~StyledLayer() = default;

	protected:

		StyledLayer(Type _type) : SourcedLayer(_type, std::make_shared<LayoutT>(), std::make_shared<PaintT>()) {}
	};

	struct RasterLayer final : public StyledLayer<RasterLayout, RasterPaint>
	{

		RasterLayer() : StyledLayer<RasterLayout, RasterPaint>(Type::RASTER) {}

	};

	struct LineLayer final : public StyledLayer<LineLayout, LinePaint>
	{
		LineLayer() : StyledLayer<LineLayout, LinePaint>(Type::LINE) {}

		LineStyle realizeLineStyle(Expressions::Arguments const& args) const
		{
			auto l = getLayout();
			auto p = getPaint();

			LineStyle style;
			style.realizeLayout(args, l);
			style.realizePaint(args, p);
			return style;
		}
	};

	struct FillLayer final : public StyledLayer<FillLayout, FillPaint>
	{
		FillLayer() : StyledLayer<FillLayout, FillPaint>(Type::FILL) {}

		FillStyle realizeFillStyle(Expressions::Arguments const& args) const
		{
			auto l = getLayout();
			auto p = getPaint();

			FillStyle style;
			style.realizeLayout(args, l);
			style.realizePaint(args, p);
			return style;
		}

	};

	struct SymbolLayer final : public StyledLayer<SymbolLayout, SymbolPaint>
	{
		SymbolLayer() : StyledLayer<SymbolLayout, SymbolPaint>(Type::SYMBOL) {}

		template<typename LayoutT, typename PaintT>
		static FontStyle realizeFontStyle(Expressions::Arguments const& args, LayoutT const& layout, PaintT const& paint)
		{
			FontStyle style;

			style.realizeLayout<LayoutT>(args, layout);
			style.realizePaint<PaintT>(args, paint);
			return style;
		}

		template<typename LayoutT, typename PaintT>
		static LabelStyle realizeLabelStyle(Expressions::Arguments const& args, LayoutT const& layout, PaintT const& paint)
		{
			LabelStyle style;

			style.realizeLayout<LayoutT>(args, layout);
			style.realizePaint<PaintT>(args, paint);
			return style;
		}

		template<typename LayoutT, typename PaintT>
		static IconStyle realizeIconStyle(Expressions::Arguments const& args, LayoutT const& layout, PaintT const& paint)
		{
			IconStyle style;

			style.realizeLayout<LayoutT>(args, layout);
			style.realizePaint<PaintT>(args, paint);
			return style;
		}

		FontStyle realizeFontStyle(Expressions::Arguments const& args) const
		{
			return SymbolLayer::realizeFontStyle(args, *getLayout(), *getPaint());
		}

		LabelStyle realizeLabelStyle(Expressions::Arguments const& args) const
		{
			return SymbolLayer::realizeLabelStyle(args, *getLayout(), *getPaint());
		}

		IconStyle realizeIconStyle(Expressions::Arguments const& args) const
		{
			return SymbolLayer::realizeIconStyle(args, *getLayout(), *getPaint());
		}
	};

	struct ContourLayer final : public StyledLayer<ContourLayout, ContourPaint>
	{
		ContourLayer() : StyledLayer<ContourLayout, ContourPaint>(Type::CONTOUR) {}

		FontStyle realizeFontStyle(Expressions::Arguments const& args) const
		{
			return SymbolLayer::realizeFontStyle(args, *getLayout(), *getPaint());
		}

		FontStyle realizeInterval(Expressions::Arguments const& args, size_t index) const
		{
			auto l = getLayout();
			auto p = getPaint();
			MAP3D_ASSERT(index < l->intervalLayouts.size(), "Invalid contour interval index requested");
			return SymbolLayer::realizeFontStyle(args, l->intervalLayouts[index], p->intervalPaints[index]);
		}
	};

} }

namespace std
{

	template<>
	inline onyx::Styling::Layer::Type fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::Layer::Type> const nameMap =
		{
			{ "background",					onyx::Styling::Layer::Type::BACKGROUND	},
			{ "raster",						onyx::Styling::Layer::Type::RASTER		},
			{ "fill",						onyx::Styling::Layer::Type::FILL			},
			{ "line",						onyx::Styling::Layer::Type::LINE			},
			{ "symbol",						onyx::Styling::Layer::Type::SYMBOL		},
			{ "circle",						onyx::Styling::Layer::Type::CIRCLE		},
			{ "contour",					onyx::Styling::Layer::Type::CONTOUR		},

		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::Layer::Type");
	}

	inline std::string_view toStringView(onyx::Styling::Layer::Type value)
	{
		static std::unordered_map<onyx::Styling::Layer::Type, std::string_view> const nameMap =
		{
			{ onyx::Styling::Layer::Type::BACKGROUND,			"background"	},
			{ onyx::Styling::Layer::Type::RASTER,				"raster"		},
			{ onyx::Styling::Layer::Type::FILL,				"fill"			},
			{ onyx::Styling::Layer::Type::LINE,				"line"			},
			{ onyx::Styling::Layer::Type::SYMBOL,				"symbol"		},
			{ onyx::Styling::Layer::Type::CIRCLE,				"circle"		},
			{ onyx::Styling::Layer::Type::CONTOUR,			"contour"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::Layer::Type");
	}

}

#endif