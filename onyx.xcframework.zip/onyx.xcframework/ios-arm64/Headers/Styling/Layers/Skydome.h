#pragma once

#include <lucid/gal/Types.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"

namespace onyx::Styling
{

	struct Skydome
	{

		Expressions::ColorT::Ptr skyColor = Expressions::Color::construct(0xFF5d9fca);
		Expressions::ColorT::Ptr hazeColor = Expressions::Color::construct(0xFFFFFFFF);
		Expressions::NumberT::Ptr alpha = Expressions::Number::construct(0.7f);
		Expressions::NumberT::Ptr bandPow = Expressions::Number::construct(10.0f);

	};

}