#ifndef STYLING_LAYER_DECLARATIONS_H
#define STYLING_LAYER_DECLARATIONS_H

namespace onyx {
namespace Styling {

	// Paint structs
	struct BackgroundPaint;
	struct RasterPaint;
	struct LinePaint;
	struct FillPaint;
	struct SymbolPaint;
	struct ContourPaint;

	// Layout structs
	struct BackgroundLayout;
	struct RasterLayout;
	struct LineLayout;
	struct FillLayout;
	struct SymbolLayout;
	struct IntervalLayout;
	struct ContourLayout;

} }

#endif //STYLING_LAYER_DECLARATIONS_H