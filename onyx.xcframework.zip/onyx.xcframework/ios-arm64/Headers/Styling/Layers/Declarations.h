#ifndef __STYLING_LAYER_DECLARATIONS_H__
#define __STYLING_LAYER_DECLARATIONS_H__

namespace onyx {
namespace Styling {

	/*
	* These forward declarations should be kept in sync with the layout and paint classes. The declarations
	* are necessary for contexts to work properly since we have the following circular dependency:
	*		context -> layouts/paints -> initialization args -> context
	* Additional uses for these forward declarations should be used judiciously
	*/

	// Layout structs
	struct BackgroundLayout;
	struct CircleLayout;
	struct ContourLabelLayout;
	struct ContourLineLayout;
	struct ElevationLayout;
	struct FillLayout;
	struct HillshadeLayout;
	struct IntersectLayout;
	struct LineLayout;
	struct RasterLayout;
	struct SlopeAngleLayout;
	struct SlopeAspectLayout;
	struct SunlightLayout;
	struct SymbolLayout;
	struct ViewshedLayout;

	// Paint structs
	struct BackgroundPaint;
	struct CirclePaint;
	struct ContourLabelPaint;
	struct ContourLinePaint;
	struct ElevationPaint;
	struct FillPaint;
	struct HillshadePaint;
	struct IntersectPaint;
	struct LinePaint;
	struct RasterPaint;
	struct SlopeAnglePaint;
	struct SlopeAspectPaint;
	struct SunlightPaint;
	struct SymbolPaint;
	struct ViewshedPaint;

} }

#endif // __STYLING_LAYER_DECLARATIONS_H__