#pragma once

namespace onyx::Styling
{

	/*
	* These forward declarations should be kept in sync with the layout/paint/effect classes. The declarations
	* are necessary for contexts to work properly since we have the following circular dependency:
	*		context -> layouts/paints/effects -> initialization args -> context
	* Additional uses for these forward declarations should be used judiciously
	*/

	// Layout structs
	struct BackgroundLayout;
	struct CircleLayout;
	struct ContourLabelLayout;
	struct ContourLineLayout;
	struct ElevationLayout;
	struct FillLayout;
	struct HillshadeLayout;
	struct IntersectLayout;
	struct LineLayout;
	struct RasterLayout;
	struct SlopeAngleLayout;
	struct SlopeAspectLayout;
	struct SunlightLayout;
	struct SymbolLayout;
	struct ViewshedLayout;

	// Paint structs
	struct BackgroundPaint;
	struct CirclePaint;
	struct ContourLabelPaint;
	struct ContourLinePaint;
	struct ElevationPaint;
	struct FillPaint;
	struct HillshadePaint;
	struct IntersectPaint;
	struct LinePaint;
	struct RasterPaint;
	struct SlopeAnglePaint;
	struct SlopeAspectPaint;
	struct SunlightPaint;
	struct SymbolPaint;
	struct ViewshedPaint;

	// Effect structs
	struct BackgroundEffect;
	struct CircleEffect;
	struct ContourLabelEffect;
	struct ContourLineEffect;
	struct ElevationEffect;
	struct FillEffect;
	struct HillshadeEffect;
	struct IntersectEffect;
	struct LineEffect;
	struct RasterEffect;
	struct SlopeAngleEffect;
	struct SlopeAspectEffect;
	struct SunlightEffect;
	struct SymbolEffect;
	struct ViewshedEffect;

}