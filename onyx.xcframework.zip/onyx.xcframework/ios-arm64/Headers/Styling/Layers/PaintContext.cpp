#include "PaintContext.h"

namespace lgigl = ::lucid::gigl;
namespace prim = ::lucid::gigl::primitives;

namespace onyx {
namespace Styling {
namespace primitives {

	lgigl::PrimitiveInfo const PaintTypes::infos[PaintTypes::TYPE_COUNT] =
	{
		{ prim::GiglTypes::Type<prim::UNKNOWN								>::VALUE,            "<unknown>" },
		{ prim::GiglTypes::Type<prim::UNDEFINED								>::VALUE,          "<undefined>" },
		{ PaintTypes::Type<std::shared_ptr<BackgroundPaint			const>	>::VALUE,      "BackgroundPaint" },
		{ PaintTypes::Type<std::shared_ptr<CirclePaint				const>	>::VALUE,          "CirclePaint" },
		{ PaintTypes::Type<std::shared_ptr<ContourLabelPaint		const>	>::VALUE,    "ContourLabelPaint" },
		{ PaintTypes::Type<std::shared_ptr<ContourLinePaint			const>	>::VALUE,     "ContourLinePaint" },
		{ PaintTypes::Type<std::shared_ptr<ElevationPaint			const>	>::VALUE,       "ElevationPaint" },
		{ PaintTypes::Type<std::shared_ptr<FillPaint				const>	>::VALUE,            "FillPaint" },
		{ PaintTypes::Type<std::shared_ptr<IntersectPaint			const>	>::VALUE,       "IntersectPaint" },
		{ PaintTypes::Type<std::shared_ptr<LinePaint				const>	>::VALUE,            "LinePaint" },
		{ PaintTypes::Type<std::shared_ptr<RasterPaint				const>	>::VALUE,          "RasterPaint" },
		{ PaintTypes::Type<std::shared_ptr<SlopeAnglePaint			const>	>::VALUE,      "SlopeAnglePaint" },
		{ PaintTypes::Type<std::shared_ptr<SlopeAspectPaint			const>	>::VALUE,     "SlopeAspectPaint" },
		{ PaintTypes::Type<std::shared_ptr<SunlightPaint			const>	>::VALUE,        "SunlightPaint" },
		{ PaintTypes::Type<std::shared_ptr<SymbolPaint				const>	>::VALUE,          "SymbolPaint" },
		{ PaintTypes::Type<std::shared_ptr<ViewshedPaint			const>	>::VALUE,        "ViewshedPaint" },
	};

} } }