#include "Layer.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Styling {
	
	// computes the sort key and walks up the layout hierarchy to correctly compute overrides
	template<typename LayoutT>
	float SortKey(Arguments const& args, LayoutT const& l)
	{
		float key = 0.f;
		if (auto const& base = l.base(args.initArgs())) { key = SortKey(args, *base); }
		if (l.sortKey) { key = l.sortKey->evaluate(args.expressions); }
		return key;
	}

	Expressions::Dependencies Layer::dependencies(InitArgs const& args) const
	{
		if (mStaleDependencies)
		{
			mDependencies = layout->dependencies(args) | paint->dependencies(args) | filter->dependencies(args.expressions);
			mStaleDependencies = false;
		}
		return mDependencies;
	}

	void Layer::invalidateDependenciesCache()
	{
		mDependencies = Expressions::Dependencies::UNSET;
		mStaleDependencies = true;
	}

	void Layer::validate(InitArgs const& args) const
	{
		// validate the filter
		filter->children(args.expressions);
		// validate layout/paint
		layout->validate(args);
		paint->validate(args);
	}

	static inline void VerifyVectorLayer(Source const& src, SourcedLayer const& layer)
	{
		if (src.type == Source::Types::VECTOR)
		{
			ONYX_ASSERT(layer.sourceLayer != "", "Layer referencing a VECTOR source must have a 'sourceLayer' property");
		}
		else
		{
			ONYX_ASSERT(layer.sourceLayer == "", "Layer not referencing a VECTOR source must not have a 'sourceLayer' property");
		}
	}

	void CircleLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::VECTOR || src.type == Source::Types::GEOJSON, "CIRCLE layer must reference a VECTOR or GEOJSON source");
	}

	void ContourLabelLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "CONTOUR_LABEL layer must reference a RASTER_DEM source");
	}

	void ContourLineLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "CONTOUR_LINE layer must reference a RASTER_DEM source");
	}

	void ElevationLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "ELEVATION layer must reference a RASTER_DEM source");
	}

	void FillLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::VECTOR || src.type == Source::Types::GEOJSON, "FILL layer must reference a VECTOR or GEOJSON source");
	}

	float FillLayer::sortKey(Arguments const& args) const
	{
		return SortKey(args, *getLayout());
	}

	void HillshadeLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "HILLSHADE layer must reference a RASTER_DEM source");
	}

	void IntersectLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "INTERSECT layer must reference a RASTER_DEM source");
	}

	void LineLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::VECTOR || src.type == Source::Types::GEOJSON, "LINE layer must reference a VECTOR or GEOJSON source");
	}

	float LineLayer::sortKey(Arguments const& args) const
	{
		return SortKey(args, *getLayout());
	}

	void RasterLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER, "RASTER layer must reference a RASTER source");
	}

	void SlopeAngleLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "SLOPE_ANGLE layer must reference a RASTER_DEM source");
	}

	void SlopeAspectLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "SLOPE_ASPECT layer must reference a RASTER_DEM source");
	}

	void SunlightLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "SUNLIGHT layer must reference a RASTER_DEM source");
	}

	void SymbolLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::VECTOR || src.type == Source::Types::GEOJSON, "SYMBOL layer must reference a VECTOR or GEOJSON source");
	}

	float SymbolLayer::sortKey(Arguments const& args) const
	{
		return SortKey(args, *getLayout());
	}

	void ViewshedLayer::validate(Source const& src) const
	{
		VerifyVectorLayer(src, *this);
		ONYX_ASSERT(src.type == Source::Types::RASTER_DEM, "VIEWSHED layer must reference a RASTER_DEM source");
	}

} }