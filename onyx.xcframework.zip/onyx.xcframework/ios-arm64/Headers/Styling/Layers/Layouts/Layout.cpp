#include "Layout.h"

namespace onyx::Styling
{
	BackgroundLayout::BackgroundLayout() = default;

	CircleLayout::CircleLayout()
	{
		ADD_OPERATIONS(sortKey);
	}

	ContourLabelLayout::ContourLabelLayout()
	{
		ADD_OPERATIONS(period);
		ADD_OPERATIONS(skipPeriod);
		ADD_OPERATIONS(min);
		ADD_OPERATIONS(max);
		ADD_OPERATIONS(phase);
	}

	ContourLineLayout::ContourLineLayout() = default;

	ElevationLayout::ElevationLayout()
	{
		ADD_OPERATIONS(gradientMeters);
	}

	FillLayout::FillLayout()
	{
		ADD_OPERATIONS(sortKey);
	}

	HillshadeLayout::HillshadeLayout() = default;

	IntersectLayout::IntersectLayout()
	{
		ADD_OPERATIONS(inverted);
	}

	LineLayout::LineLayout()
	{
		ADD_OPERATIONS(joinType);
		ADD_OPERATIONS(capType);
		ADD_OPERATIONS(sortKey);
	}

	RasterLayout::RasterLayout() = default;

	SlopeAngleLayout::SlopeAngleLayout()
	{
		ADD_OPERATIONS(gradientDegrees);
	}

	SlopeAspectLayout::SlopeAspectLayout()
	{
		ADD_OPERATIONS(gradientDegrees);
	}

	SunlightLayout::SunlightLayout()
	{
		ADD_OPERATIONS(year);
		ADD_OPERATIONS(month);
		ADD_OPERATIONS(day);
		ADD_OPERATIONS(hour);
	}

	SymbolLayout::SymbolLayout()
	{
		ADD_OPERATIONS(sortKey);
		ADD_OPERATIONS(symbolAvoidEdges);
		ADD_OPERATIONS(symbolPlacement);
		ADD_OPERATIONS(symbolSpacing);
		ADD_OPERATIONS(symbolZOrder);
		ADD_OPERATIONS(iconAllowOverlap);
		ADD_OPERATIONS(iconAnchor);
		ADD_OPERATIONS(iconIgnorePlacement);
		ADD_OPERATIONS(iconImage);
		ADD_OPERATIONS(iconOffset);
		ADD_OPERATIONS(iconPadding);
		ADD_OPERATIONS(iconPitchAlignment);
		ADD_OPERATIONS(iconRotAlignment);
		ADD_OPERATIONS(iconRotDeg);
		ADD_OPERATIONS(iconSize);
		ADD_OPERATIONS(iconTextFit);
		ADD_OPERATIONS(iconTextFitPadding);
	}

	ViewshedLayout::ViewshedLayout()
	{
		ADD_OPERATIONS(lon);
		ADD_OPERATIONS(lat);
		ADD_OPERATIONS(rangeMeters);
		ADD_OPERATIONS(offsetMeters);
		ADD_OPERATIONS(inverted);
	}

}