#include "LayoutComponents.h"

namespace onyx::Styling
{

	TextLayoutComponent::TextLayoutComponent()
	{
		ADD_OPERATIONS(allowOverlap);
		ADD_OPERATIONS(anchor);
		ADD_OPERATIONS(field);
		ADD_OPERATIONS(fontFace);
		ADD_OPERATIONS(ignorePlacement);
		ADD_OPERATIONS(justify);
		ADD_OPERATIONS(keepUpright);
		ADD_OPERATIONS(letterSpacing);
		ADD_OPERATIONS(lineHeight);
		ADD_OPERATIONS(maxAngleDegrees);
		ADD_OPERATIONS(maxWidth);
		ADD_OPERATIONS(offset);
		ADD_OPERATIONS(optional);
		ADD_OPERATIONS(padding);
		ADD_OPERATIONS(pitchAlignment);
		ADD_OPERATIONS(radialOffset);
		ADD_OPERATIONS(rotationAlignment);
		ADD_OPERATIONS(size);
		ADD_OPERATIONS(transform);
		ADD_OPERATIONS(variableAnchor);
		ADD_OPERATIONS(flags);
	}

}