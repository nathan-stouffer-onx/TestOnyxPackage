#pragma once

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/FormatExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/ExpressionOwner.h"

namespace onyx::Styling
{

	struct TextLayoutComponent final : public ExpressionOwner
	{
		
		Expressions::BooleanT::Ptr allowOverlap = Expressions::Boolean::construct(false);
		Expressions::EnumT<Anchor>::Ptr anchor = Expressions::Enum::construct(Anchor::HORIZONTAL_CENTER);
		Expressions::FormattedT::Ptr field = Expressions::Format::construct("");
		Expressions::StringArrayT::Ptr fontFace;
		Expressions::BooleanT::Ptr ignorePlacement = Expressions::Boolean::construct(false);
		Expressions::EnumT<Justify>::Ptr justify = Expressions::Enum::construct(Justify::CENTER);
		Expressions::BooleanT::Ptr keepUpright = Expressions::Boolean::construct(true);
		Expressions::NumberT::Ptr letterSpacing = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr lineHeight = Expressions::Number::construct(1.2f);
		Expressions::NumberT::Ptr maxAngleDegrees = Expressions::Number::construct(45);
		Expressions::NumberT::Ptr maxWidth = Expressions::Number::construct(10);
		Expressions::NumberArrayT::Ptr offset = Expressions::Array::construct<float>({ 0, 0 });
		Expressions::BooleanT::Ptr optional = Expressions::Boolean::construct(false);
		Expressions::NumberT::Ptr padding = Expressions::Number::construct(2);
		Expressions::EnumT<Alignment>::Ptr pitchAlignment = Expressions::Enum::construct(Alignment::Auto);
		Expressions::NumberT::Ptr radialOffset = Expressions::Number::construct(0);
		Expressions::EnumT<Alignment>::Ptr rotationAlignment = Expressions::Enum::construct(Alignment::Auto);
		Expressions::NumberT::Ptr size = Expressions::Number::construct(16.f);
		Expressions::EnumT<Transform>::Ptr transform = Expressions::Enum::construct(Transform::NONE);
		Expressions::ArrayT<Anchor>::Ptr variableAnchor = nullptr;

		Expressions::EnumT<TextStyleFlags>::Ptr flags = Expressions::Enum::construct(TextStyleFlags::NORMAL);

		TextLayoutComponent();
	};

}