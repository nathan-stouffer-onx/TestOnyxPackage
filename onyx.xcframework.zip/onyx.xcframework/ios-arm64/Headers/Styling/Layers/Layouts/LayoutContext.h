#ifndef __STYLING_LAYOUT_CONTEXT_H__
#define __STYLING_LAYOUT_CONTEXT_H__

#include <lucid/gigl/Context.h>
#include <lucid/gigl/Primitive.h>

#include "Styling/Layers/Declarations.h"

namespace onyx {
namespace Styling {

	namespace primitives {

		struct LayoutTypes
		{

			enum { TYPE_COUNT = 17 };

			static lucid::gigl::PrimitiveInfo const infos[TYPE_COUNT];

			// Deleting this constructor forces a compile error if someone tries to use a context
			// to store/retrieve something that is unsupported.
			template<class T>	struct Type { Type() = delete; enum { VALUE = 0 }; };
		};

		template<> struct LayoutTypes::Type<	lucid::gigl::primitives::UNKNOWN				> { enum { VALUE = 0 }; };
		template<> struct LayoutTypes::Type<	lucid::gigl::primitives::UNDEFINED				> { enum { VALUE = 1 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<BackgroundLayout		const>	> { enum { VALUE = 2 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<CircleLayout			const>	> { enum { VALUE = 3 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<ContourLabelLayout		const>	> { enum { VALUE = 4 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<ContourLineLayout		const>	> { enum { VALUE = 5 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<ElevationLayout			const>	> { enum { VALUE = 6 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<FillLayout				const>	> { enum { VALUE = 7 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<HillshadeLayout			const>	> { enum { VALUE = 8 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<IntersectLayout			const>	> { enum { VALUE = 9 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<LineLayout				const>	> { enum { VALUE = 10 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<RasterLayout			const>	> { enum { VALUE = 11 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<SlopeAngleLayout		const>	> { enum { VALUE = 12 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<SlopeAspectLayout		const>	> { enum { VALUE = 13 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<SunlightLayout			const>	> { enum { VALUE = 14 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<SymbolLayout			const>	> { enum { VALUE = 15 }; };
		template<> struct LayoutTypes::Type<	std::shared_ptr<ViewshedLayout			const>	> { enum { VALUE = 16 }; };

	}

	using LayoutContext = lucid::gigl::FlexContext<primitives::LayoutTypes>;

} }

#endif