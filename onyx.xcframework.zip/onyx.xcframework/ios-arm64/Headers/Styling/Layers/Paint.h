#ifndef __STYLING_PAINT_H__
#define __STYLING_PAINT_H__

#include <lucid/gal/Types.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"

#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/FontStyle.h"
#include "StyledBase.h"

namespace onyx {
namespace Styling {

	/*
	* Structs to represent Paint structures for each type of style layer that can be drawn on the map
	*/

	// base struct to define a Paint structure
	struct PaintBase : public StyledBase
	{
		std::string base;
		PaintBase() = default;
		virtual ~PaintBase() = default;
	};

	// This template struct lets us use the curiously-recurring-template pattern to have a
	// strongly-typed shared pointer to a "derived" class based on the template.  Also allows
	// us to use ValidationArguments::getBaseFlags template function that will retrieve that
	// pointer from the style context.
	template<typename T>
	struct Paint : public PaintBase
	{
		mutable std::shared_ptr<T const> basePtr;
		virtual ~Paint() = default;
	};

	// Paint struct for a background layer
	struct BackgroundPaint final : public Paint<BackgroundPaint>
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr opacity = nullptr;
		// TODO support background pattern

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const &args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					color.get(),
					opacity.get()
				});

			return modificationFlags;
		}
		BackgroundPaint() = default;
	};

	// Paint struct for a raster layer
	struct RasterPaint final : public Paint<RasterPaint>
	{
		Expressions::NumberT::Ptr opacity = Expressions::Number::construct(1.0f);

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					opacity.get()
				});

			return modificationFlags;
		}

		RasterPaint() = default;
	};

	// Paint struct for a line layer
	struct LinePaint final : public Paint<LinePaint>
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr opacity = nullptr;
		Expressions::NumberT::Ptr width = Expressions::Number::construct(1.0f);
		Expressions::NumberArrayT::Ptr dashArray = Expressions::Array::construct<float>({ 1.0f });

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					color.get(),
					width.get(),
					dashArray.get(),
					opacity.get()
				});

			return modificationFlags;
		}

		LinePaint() = default;
	};

	// Paint struct for a fill layer
	struct FillPaint final : public Paint<FillPaint>
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 1.0f });
		Expressions::NumberT::Ptr opacity = nullptr;
		Expressions::StringT::Ptr pattern = Expressions::String::construct("");

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					color.get(),
					pattern.get(),
					opacity.get()
				});

			return modificationFlags;
		}

		FillPaint() = default;
	};

	template<typename T>
	struct TextPaint : public Paint<T>
	{
		Expressions::ColorT::Ptr color = Expressions::Color::construct({ 1.0f, 1.0f, 1.0f, 1.0f });
		Expressions::ColorT::Ptr shadowColor = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 0.2f });
		Expressions::ColorT::Ptr outlineColor = Expressions::Color::construct({ 0.f, 0, 0, 0 });
		Expressions::ColorT::Ptr strikethroughColor = Expressions::Color::construct(0);
		Expressions::ColorT::Ptr overlineColor = Expressions::Color::construct(0);
		Expressions::ColorT::Ptr underlineColor = Expressions::Color::construct(0);
		Expressions::ColorT::Ptr backgroundColor = Expressions::Color::construct(0);

		template <typename DerivedT>
		Expressions::ModificationFlags textModificationFlags(Expressions::ValidationArguments const& args) const
		{
			auto baseFlags = args.getBaseFlags((DerivedT*) this, args);
			this->modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					color.get(),
					shadowColor.get(),
					outlineColor.get(),
					strikethroughColor.get(),
					overlineColor.get(),
					underlineColor.get(),
					backgroundColor.get(),
				});

			return this->modificationFlags;
		}
	};

	struct SymbolPaint final : public TextPaint<SymbolPaint>
	{
		Expressions::ColorT::Ptr iconColor = Expressions::Color::construct({ 0.0f, 0.0f, 0.0f, 0.0f });
		Expressions::NumberT::Ptr iconOpacity = Expressions::Number::construct(1.f);
		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			modificationFlags = textModificationFlags<SymbolPaint>(args);
			return modificationFlags;
		}
	};

	struct ContourPaint final : public TextPaint<ContourPaint>
	{
		std::vector<SymbolPaint> intervalPaints;
		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			modificationFlags = textModificationFlags<ContourPaint>(args);
			return modificationFlags;
		}

	};

} }

#endif