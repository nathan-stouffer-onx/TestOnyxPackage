#pragma once

#include <vector>

#include <Utils/EnumUtils.h>

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/FormatExpressions.h"
#include "Styling/Expressions/GradientExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/Arguments.h"
#include "Styling/Layers/ExpressionOwner.h"
#include "Styling/Layers/LayoutComponents.h"
#include "Styling/Styles/ContourConfigs.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/ShadowConfigs.h"
#include "Styling/Styles/SymbolStyle.h"
#include "Styling/Styles/TerrainConfigs.h"

#define ExprEnum(enumType, varName, defaultValue) Expressions::EnumT<enumType>::Ptr varName = Expressions::Enum::construct(enumType::defaultValue);

namespace onyx::Styling
{

	/*
	* Structs to represent Layout structures for each type of style layer that can be drawn on the map
	*/

	// base struct to define a Layout structure
	struct LayoutBase : public ExpressionOwner
	{
		// TODO maybe just store this as a bool? for now, keeping with the enum pattern for consistency
		enum class Visibility
		{
			VISIBLE,
			NONE
		};

		LayoutBase() = default;
		virtual ~LayoutBase() = default;

		std::string baseId;
		Visibility visibility = Visibility::VISIBLE;

		virtual void validate(InitArgs const& args) const = 0;

		virtual Expressions::Dependencies dependencies(InitArgs const& args) const = 0;

	};

	// This template struct lets us use the curiously-recurring-template pattern to have a
	// strongly-typed shared pointer to a "derived" class based on the template.  Also allows
	// us to use InitArgs::BaseFlags template function that will retrieve that
	// pointer from the style context.
	template<typename T>
	struct Layout : public LayoutBase
	{
		virtual ~Layout() = default;

		std::shared_ptr<T const> const& base(InitArgs const& args) const
		{
			if (!baseId.empty() && !mBasePtr)
			{
				args.layouts.getTo(baseId, mBasePtr);
			}
			return mBasePtr;
		}

		void setBase(std::shared_ptr<T const> const& base) { mBasePtr = base; }

		void validate(InitArgs const& args) const override
		{
			// make sure that the base class exists and is of the correct type
			{
				base(args);
			}
			for (Expressions::ExpressionBase const* expr : expressions())
			{
				// for now, the only validation that occurs is that we reference valid context expressions
				// (which we confirm by getting the children)
				if (expr)
				{
					expr->children(args.expressions);
				}
			}
		}

		Expressions::Dependencies dependencies(InitArgs const& args) const override
		{
			Expressions::Dependencies deps = Expressions::dependencies(args.expressions, expressions());
			if (auto const& base = this->base(args))
			{
				deps |= base->dependencies(args);
			}
			return deps;
		}

	private:
		std::shared_ptr<T const> mutable mBasePtr = nullptr;
	};

	struct BackgroundLayout final : public Layout<BackgroundLayout>
	{
		BackgroundLayout() = default;

		void nullify() override {}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return {};
		}

	};

	struct CircleLayout final : public Layout<CircleLayout>
	{
		Expressions::NumberT::Ptr sortKey = nullptr;

		CircleLayout() = default;

		void nullify() override { sortKey = nullptr; }

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return { sortKey.get() };
		}
	};

	struct ContourLabelLayout final : public Layout<ContourLabelLayout>
	{

		// NOTE: use this adjusted value instead of maximum because casting from
		// max int -> float -> int results in a -max int. 100 was chosen somewhat
		// arbitrarily, but it works and I don't think the actual number matters
		// too much
		static constexpr int cIntBound = std::numeric_limits<int>::max() - 100;

		ContourLabelLayout() = default;

		TextLayoutComponent text;

		ExprEnum(ContourConfig::Units, units, METERS);
		Expressions::NumberT::Ptr period = Expressions::Number::construct(10.f);
		Expressions::NumberT::Ptr skipPeriod = Expressions::Number::construct(0.0f);
		Expressions::NumberT::Ptr min = Expressions::Number::construct(float(-cIntBound));
		Expressions::NumberT::Ptr max = Expressions::Number::construct(float(cIntBound));
		Expressions::NumberT::Ptr phase = Expressions::Number::construct(0.f);

		void nullify() override
		{
			text.nullify();
			period = nullptr;
			skipPeriod = nullptr;
			min = nullptr;
			max = nullptr;
			phase = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			std::vector<Expressions::ExpressionBase const*> exprs =
			{
				units.get(),
				period.get(),
				skipPeriod.get(),
				min.get(),
				max.get(),
				phase.get(),
			};
			return Expressions::concat(exprs, text.expressions());
		}

	};

	struct ContourLineLayout final : public Layout<ContourLineLayout>
	{
		ContourLineLayout() = default;
		void nullify() override {}
		std::vector<Expressions::ExpressionBase const*> expressions() const override { return {}; }
	};

	struct ElevationLayout final : public Layout<ElevationLayout>
	{

		ElevationLayout() = default;

		Expressions::GradientT::Ptr gradientMeters = Expressions::Gradient::construct(Utils::Gradient());
		// TODO add sampling enum expression?

		void nullify() override
		{
			gradientMeters = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				gradientMeters.get(),
			};
		}

	};

	struct FillLayout final : public Layout<FillLayout>
	{
		Expressions::NumberT::Ptr sortKey = nullptr;

		FillLayout() = default;

		void nullify() override { sortKey = nullptr; }

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return { sortKey.get() };
		}
	};

	struct HillshadeLayout final : public Layout<HillshadeLayout>
	{
		HillshadeLayout() = default;
		void nullify() override { }
		std::vector<Expressions::ExpressionBase const*> expressions() const override { return { }; }
	};

	struct IntersectLayout final : public Layout<IntersectLayout>
	{
		Expressions::BooleanT::Ptr inverted = Expressions::Boolean::construct(false);

		IntersectLayout() = default;

		void nullify() override
		{
			inverted = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				inverted.get(),
			};
		}
	};

	struct LineLayout final : public Layout<LineLayout>
	{
		ExprEnum(LineStyle::JoinType, joinType, MITER);
		ExprEnum(LineStyle::CapType, capType, BUTT);
		Expressions::NumberT::Ptr sortKey = nullptr;

		void nullify() override
		{
			joinType = nullptr;
			capType = nullptr;
			sortKey = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return { joinType.get(), capType.get(), sortKey.get() };
		}

		LineLayout() = default;
	};

	struct RasterLayout final : public Layout<RasterLayout>
	{
		RasterLayout() = default;

		void nullify() override {}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return {};
		}
	};

	struct SlopeAngleLayout final : public Layout<SlopeAngleLayout>
	{

		SlopeAngleLayout() = default;

		Expressions::GradientT::Ptr gradientDegrees = Expressions::Gradient::construct(Utils::Gradient());
		// TODO add sampling enum expression?

		void nullify() override
		{
			gradientDegrees = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				gradientDegrees.get(),
			};
		}

	};

	struct SlopeAspectLayout final : public Layout<SlopeAspectLayout>
	{

		SlopeAspectLayout() = default;

		Expressions::GradientT::Ptr gradientDegrees = Expressions::Gradient::construct(Utils::Gradient());
		// TODO add sampling enum expression?

		void nullify() override
		{
			gradientDegrees = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				gradientDegrees.get(),
			};
		}

	};

	struct SunlightLayout final : public Layout<SunlightLayout>
	{

		SunlightLayout() = default;

		Expressions::NumberT::Ptr year = Expressions::Number::construct(2000);
		Expressions::NumberT::Ptr month = Expressions::Number::construct(0);
		Expressions::NumberT::Ptr day = Expressions::Number::construct(0);
		Expressions::NumberT::Ptr hour = Expressions::Number::construct(0);

		void nullify() override
		{
			year = nullptr;
			month = nullptr;
			day = nullptr;
			hour = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				year.get(),
				month.get(),
				day.get(),
				hour.get(),
			};
		}

	};

	struct SymbolLayout final : public Layout<SymbolLayout>
	{
		
		enum class SymbolZOrderOpts
		{
			Auto,
			ViewportY,
			Source
		};

		Expressions::NumberT::Ptr sortKey = nullptr;
		Expressions::BooleanT::Ptr symbolAvoidEdges = Expressions::Boolean::construct(false);
		ExprEnum(SymbolPlacement, symbolPlacement, POINT);
		Expressions::NumberT::Ptr symbolSpacing = Expressions::Number::construct(250);
		ExprEnum(SymbolZOrderOpts, symbolZOrder, Auto);

		Expressions::BooleanT::Ptr iconAllowOverlap = Expressions::Boolean::construct(false);
		ExprEnum(Anchor, iconAnchor, HORIZONTAL_CENTER);
		Expressions::BooleanT::Ptr iconIgnorePlacement = Expressions::Boolean::construct(false);
		Expressions::ResolvedImageT::Ptr iconImage = Expressions::Image::construct("");	// name of image in spritesheet
		Expressions::NumberArrayT::Ptr iconOffset = Expressions::Array::construct<float>({ 0, 0 });
		Expressions::NumberT::Ptr iconPadding = Expressions::Number::construct(2);
		ExprEnum(Alignment, iconPitchAlignment, Auto);
		ExprEnum(Alignment, iconRotAlignment, Auto);
		Expressions::NumberT::Ptr iconRotDeg = Expressions::Number::construct(0);
		Expressions::NumberT::Ptr iconSize = Expressions::Number::construct(1);
		ExprEnum(TextFitOpts, iconTextFit, None);
		Expressions::NumberArrayT::Ptr iconTextFitPadding = Expressions::Array::construct<float>({ 0, 0, 0, 0 });

		TextLayoutComponent text;

		SymbolLayout() = default;
		
		void nullify() override
		{
			text.nullify();
			sortKey = nullptr;
			symbolAvoidEdges = nullptr;
			symbolPlacement = nullptr;
			symbolSpacing = nullptr;
			symbolZOrder = nullptr;
			iconAllowOverlap = nullptr;
			iconAnchor = nullptr;
			iconIgnorePlacement = nullptr;
			iconImage = nullptr;
			iconOffset = nullptr;
			iconPadding = nullptr;
			iconPitchAlignment = nullptr;
			iconRotAlignment = nullptr;
			iconRotDeg = nullptr;
			iconSize = nullptr;
			iconTextFit = nullptr;
			iconTextFitPadding = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			std::vector<Expressions::ExpressionBase const*> exprs =
			{
				sortKey.get(),
				symbolAvoidEdges.get(),
				symbolPlacement.get(),
				symbolSpacing.get(),
				symbolZOrder.get(),
				iconAllowOverlap.get(),
				iconAnchor.get(),
				iconIgnorePlacement.get(),
				iconImage.get(),
				iconOffset.get(),
				iconPadding.get(),
				iconPitchAlignment.get(),
				iconRotAlignment.get(),
				iconRotDeg.get(),
				iconSize.get(),
				iconTextFit.get(),
				iconTextFitPadding.get(),
			};
			return Expressions::concat(exprs, text.expressions());
		}

	};

	struct ViewshedLayout final : public Layout<ViewshedLayout>
	{

		ViewshedLayout() = default;

		Expressions::NumberT::Ptr lon = Expressions::Number::construct(0.f);
		Expressions::NumberT::Ptr lat = Expressions::Number::construct(0.f);

		// units are in meters
		Expressions::NumberT::Ptr rangeMeters = Expressions::Number::construct(10000.f);
		Expressions::NumberT::Ptr offsetMeters = Expressions::Number::construct(10.f);
		Expressions::BooleanT::Ptr inverted = Expressions::Boolean::construct(false);

		void nullify() override
		{
			lon = nullptr;
			lat = nullptr;
			rangeMeters = nullptr;
			offsetMeters = nullptr;
			inverted = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				lon.get(),
				lat.get(),
				rangeMeters.get(),
				offsetMeters.get(),
				inverted.get(),
			};
		}

	};

}

namespace std
{

	template<>
	inline onyx::Styling::LayoutBase::Visibility fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::LayoutBase::Visibility> const nameMap =
		{
			{ "visible",					onyx::Styling::LayoutBase::Visibility::VISIBLE	},
			{ "none",						onyx::Styling::LayoutBase::Visibility::NONE	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::LayoutBase::Visibility");
	}

	inline std::string_view toStringView(onyx::Styling::LayoutBase::Visibility value)
	{
		static std::unordered_map<onyx::Styling::LayoutBase::Visibility, std::string_view> const nameMap =
		{
			{ onyx::Styling::LayoutBase::Visibility::VISIBLE,			"visible"	},
			{ onyx::Styling::LayoutBase::Visibility::NONE,				"none"			},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::LayoutBase::Visibility");
	}

	

	template<>
	inline onyx::Styling::SymbolLayout::SymbolZOrderOpts fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::SymbolLayout::SymbolZOrderOpts> const nameMap =
		{
			{ "auto",						onyx::Styling::SymbolLayout::SymbolZOrderOpts::Auto			},
			{ "source",						onyx::Styling::SymbolLayout::SymbolZOrderOpts::Source		},
			{ "viewporty",					onyx::Styling::SymbolLayout::SymbolZOrderOpts::ViewportY	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::SymbolLayout::SymbolZOrderOpts");
	}

	inline std::string_view toStringView(onyx::Styling::SymbolLayout::SymbolZOrderOpts value)
	{
		static std::unordered_map<onyx::Styling::SymbolLayout::SymbolZOrderOpts, std::string_view> const nameMap =
		{
			{ onyx::Styling::SymbolLayout::SymbolZOrderOpts::Auto,				"auto"		},
			{ onyx::Styling::SymbolLayout::SymbolZOrderOpts::Source,			"source"	},
			{ onyx::Styling::SymbolLayout::SymbolZOrderOpts::ViewportY,			"viewporty"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::SymbolLayout::SymbolZOrderOpts");
	}

}

#undef ExprEnum