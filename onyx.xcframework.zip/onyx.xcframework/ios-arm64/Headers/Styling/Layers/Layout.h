#ifndef __STYLING_LAYOUT_H__
#define __STYLING_LAYOUT_H__

#include <Utils/EnumUtils.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Styles/LineStyle.h"
#include "Styling/Styles/FillStyle.h"
#include "Styling/Styles/FontStyle.h"
#include "Styling/Enums.h"
#include "StyledBase.h"

#define ExprEnum(enumType, varName, defaultValue) Expressions::EnumT<enumType>::Ptr varName = Expressions::Enum::construct(enumType::defaultValue);

namespace onyx {
namespace Styling {

	/*
	* Structs to represent Layout structures for each type of style layer that can be drawn on the map
	*/

	// base struct to define a Layout structure
	struct LayoutBase : public StyledBase
	{
		// TODO maybe just store this as a bool? for now, keeping with the enum pattern for consistency
		enum class Visibility
		{
			VISIBLE,
			NONE
		};
		
		std::string base;
		Visibility visibility = Visibility::VISIBLE;

		LayoutBase() = default;
		virtual ~LayoutBase() = default;
	};

	// This template struct lets us use the curiously-recurring-template pattern to have a
	// strongly-typed shared pointer to a "derived" class based on the template.  Also allows
	// us to use ValidationArguments::getBaseFlags template function that will retrieve that
	// pointer from the style context.
	template<typename T>
	struct Layout : public LayoutBase
	{
		mutable std::shared_ptr<T const> basePtr;
		virtual ~Layout() = default;
	};

	// Layout struct for a background layer
	struct BackgroundLayout final : public Layout<BackgroundLayout>
	{
		BackgroundLayout() = default;
	};

	// Layout struct for a raster layer
	struct RasterLayout final : public Layout<RasterLayout>
	{
		RasterLayout() = default;
	};

	// Layout struct for a line layer
	struct LineLayout final : public Layout<LineLayout>
	{
		ExprEnum(LineStyle::JoinType, joinType, MITER);
		ExprEnum(LineStyle::CapType, capType, BUTT);

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					joinType.get(),
					capType.get()
				});
			return modificationFlags;
		}

		LineLayout() = default;
	};

	// Layout struct for a fill layer
	struct FillLayout final : public Layout<FillLayout>
	{
		FillLayout() = default;
	};

	template<typename T>
	struct TextLayout : public Layout<T>
	{
		Expressions::StringT::Ptr textField = Expressions::String::construct("");
		ExprEnum(FontStyle::SymbolPlacement, symbolPlacement, POINT);
		ExprEnum(TextPlacement, textPlacement, UNSPECIFIED);
		ExprEnum(TextStyleFlags, textStyleFlags, NORMAL);

		Expressions::NumberT::Ptr textSize = Expressions::Number::construct(10.f);
		Expressions::NumberT::Ptr letterSpacing = Expressions::Number::construct(1.f);

		std::vector<std::string> fontFace;

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			this->modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					textField.get(),
					symbolPlacement.get(),
					textPlacement.get(),
					textStyleFlags.get(),
					textSize.get(),
					letterSpacing.get()
				});
			return this->modificationFlags;
		}
		TextLayout() = default;
	};

	// Layout struct for a symbol layer
	struct SymbolLayout final : public TextLayout<SymbolLayout>
	{
		SymbolLayout() = default;

		Expressions::StringT::Ptr iconImage = Expressions::String::construct("");	// name of image in sprite

		lgal::gpu::Vector2 iconOffset = { 0, 0 }; // TODO (scott) Do we want to add vector expressions here, or just use offsetX/offsetY?
		Expressions::NumberT::Ptr iconSize = Expressions::Number::construct(1);
		
		using IconPlacement = Placement;

		enum class PitchAlignOpts
		{
			Map,
			Viewport,
			Auto
		};

		enum class TextFitOpts
		{
			None,
			Width,
			Height,
			Both
		};

		enum class SymbolZOrderOpts
		{
			Auto,
			ViewportY,
			Source
		};

		ExprEnum(IconPlacement, iconAnchor, HORIZONTAL_CENTER);
		ExprEnum(PitchAlignOpts, iconPitchAlignment, Auto);
		ExprEnum(TextFitOpts, iconTextFit, None);
		ExprEnum(SymbolZOrderOpts, symbolZOrder, Auto);

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | StyledBase::evalModificationFlags(args,
				{
					iconAnchor.get(),
					iconPitchAlignment.get(),
					iconTextFit.get(),
					symbolZOrder.get(),
				});
			return modificationFlags;
		}
	};

	struct IntervalLayout : public TextLayout<IntervalLayout>
	{
		Expressions::NumberT::Ptr interval = Expressions::Number::construct(1.f);

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | TextLayout::initialize(args);
			modificationFlags |= StyledBase::evalModificationFlags(args,
				{
					interval.get()
				});
				
			return modificationFlags;
		}

	};

	struct ContourLayout final : public TextLayout<ContourLayout>
	{
		ContourLayout() = default;
		std::vector<IntervalLayout> intervalLayouts;
		Expressions::BooleanT::Ptr showTileInfo = Expressions::Boolean::construct(false);

		Expressions::ModificationFlags initialize(Expressions::ValidationArguments const& args) const override
		{
			auto baseFlags = args.getBaseFlags(this, args);
			modificationFlags = baseFlags | TextLayout::initialize(args);
			modificationFlags |= StyledBase::evalModificationFlags(args,
				{
					showTileInfo.get()
				});
				
			return modificationFlags;
		}
	};

} }

namespace std
{

	template<>
	inline onyx::Styling::LayoutBase::Visibility fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::LayoutBase::Visibility> const nameMap =
		{
			{ "visible",					onyx::Styling::LayoutBase::Visibility::VISIBLE	},
			{ "none",						onyx::Styling::LayoutBase::Visibility::NONE	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::LayoutBase::Visibility");
	}

	inline std::string_view toStringView(onyx::Styling::LayoutBase::Visibility value)
	{
		static std::unordered_map<onyx::Styling::LayoutBase::Visibility, std::string_view> const nameMap =
		{
			{ onyx::Styling::LayoutBase::Visibility::VISIBLE,			"visible"	},
			{ onyx::Styling::LayoutBase::Visibility::NONE,			"none"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::LayoutBase::Visibility");
	}

	template<>
	inline onyx::Styling::SymbolLayout::PitchAlignOpts fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::SymbolLayout::PitchAlignOpts> const nameMap =
		{
			{ "auto",						onyx::Styling::SymbolLayout::PitchAlignOpts::Auto},
			{ "map",						onyx::Styling::SymbolLayout::PitchAlignOpts::Map},
			{ "viewport",					onyx::Styling::SymbolLayout::PitchAlignOpts::Viewport},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::SymbolLayout::PitchAlignOpts");
	}

	inline std::string_view toStringView(onyx::Styling::SymbolLayout::PitchAlignOpts value)
	{
		static std::unordered_map<onyx::Styling::SymbolLayout::PitchAlignOpts, std::string_view> const nameMap =
		{
			{ onyx::Styling::SymbolLayout::PitchAlignOpts::Auto,			"auto"		},
			{ onyx::Styling::SymbolLayout::PitchAlignOpts::Map,			"map"		},
			{ onyx::Styling::SymbolLayout::PitchAlignOpts::Viewport,		"viewport"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::SymbolLayout::PitchAlignOpts");
	}

	template<>
	inline onyx::Styling::SymbolLayout::TextFitOpts fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::SymbolLayout::TextFitOpts> const nameMap =
		{
			{ "both",						onyx::Styling::SymbolLayout::TextFitOpts::Both	},
			{ "height",						onyx::Styling::SymbolLayout::TextFitOpts::Height	},
			{ "width",						onyx::Styling::SymbolLayout::TextFitOpts::Width	},
			{ "none",						onyx::Styling::SymbolLayout::TextFitOpts::None	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::SymbolLayout::TextFitOpts");
	}

	inline std::string_view toStringView(onyx::Styling::SymbolLayout::TextFitOpts value)
	{
		static std::unordered_map<onyx::Styling::SymbolLayout::TextFitOpts, std::string_view> const nameMap =
		{
			{ onyx::Styling::SymbolLayout::TextFitOpts::Both,				"both"		},
			{ onyx::Styling::SymbolLayout::TextFitOpts::Height,			"height"	},
			{ onyx::Styling::SymbolLayout::TextFitOpts::Width,			"width"		},
			{ onyx::Styling::SymbolLayout::TextFitOpts::None,				"none"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::SymbolLayout::TextFitOpts");
	}

	template<>
	inline onyx::Styling::SymbolLayout::SymbolZOrderOpts fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Styling::SymbolLayout::SymbolZOrderOpts> const nameMap =
		{
			{ "auto",						onyx::Styling::SymbolLayout::SymbolZOrderOpts::Auto		},
			{ "source",						onyx::Styling::SymbolLayout::SymbolZOrderOpts::Source		},
			{ "viewporty",					onyx::Styling::SymbolLayout::SymbolZOrderOpts::ViewportY	},
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Styling::SymbolLayout::SymbolZOrderOpts");
	}

	inline std::string_view toStringView(onyx::Styling::SymbolLayout::SymbolZOrderOpts value)
	{
		static std::unordered_map<onyx::Styling::SymbolLayout::SymbolZOrderOpts, std::string_view> const nameMap =
		{
			{ onyx::Styling::SymbolLayout::SymbolZOrderOpts::Auto,				"auto"		},
			{ onyx::Styling::SymbolLayout::SymbolZOrderOpts::Source,				"source"	},
			{ onyx::Styling::SymbolLayout::SymbolZOrderOpts::ViewportY,			"viewporty"	},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Styling::SymbolLayout::SymbolZOrderOpts");
	}

}

#undef ExprEnum

#endif