#pragma once

#include <lucid/gal/Types.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"

namespace onyx::Styling
{

	struct Fog
	{

		Expressions::ColorT::Ptr color = Expressions::Color::construct(0xFFE3EFF7);
		Expressions::NumberArrayT::Ptr range = Expressions::Array::construct<float>({ 0.05f, 10.0f });

	};

}