#pragma once

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/FormatExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/ExpressionOwner.h"

#define ENUM_EXPR(enumType, varName, defaultValue) Expressions::EnumT<enumType>::Ptr varName = Expressions::Enum::construct(enumType::defaultValue);

namespace onyx::Styling
{

	struct TextLayoutComponent final : public ExpressionOwner
	{
		
		// TODO (stouff) remove text prefix from member names
		Expressions::BooleanT::Ptr textAllowOverlap = Expressions::Boolean::construct(false);
		ENUM_EXPR(Anchor, textAnchor, HORIZONTAL_CENTER);
		Expressions::FormattedT::Ptr textField = Expressions::Format::construct("");
		Expressions::StringArrayT::Ptr fontFace;
		Expressions::BooleanT::Ptr textIgnorePlacement = Expressions::Boolean::construct(false);
		ENUM_EXPR(Justify, textJustify, CENTER);
		Expressions::BooleanT::Ptr textKeepUpright = Expressions::Boolean::construct(true);
		Expressions::NumberT::Ptr letterSpacing = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr textLineHeight = Expressions::Number::construct(1.2f);
		Expressions::NumberT::Ptr textMaxAngleDegrees = Expressions::Number::construct(45);
		Expressions::NumberT::Ptr textMaxWidth = Expressions::Number::construct(10);
		Expressions::NumberArrayT::Ptr textOffset = Expressions::Array::construct<float>({ 0, 0 });
		Expressions::BooleanT::Ptr textOptional = Expressions::Boolean::construct(false);
		Expressions::NumberT::Ptr textPadding = Expressions::Number::construct(2);
		ENUM_EXPR(Alignment, textPitchAlignment, Auto);
		Expressions::NumberT::Ptr textRadialOffset = Expressions::Number::construct(0);
		ENUM_EXPR(Alignment, textRotationAlignment, Auto);
		Expressions::NumberT::Ptr textSize = Expressions::Number::construct(10.f);
		ENUM_EXPR(Transform, textTransform, NONE);
		Expressions::ArrayT<Anchor>::Ptr textVariableAnchor = Expressions::Array::construct<Anchor>({ Anchor::CENTER });

		ENUM_EXPR(TextStyleFlags, textStyleFlags, NORMAL);

		TextLayoutComponent() = default;

		void nullify() override
		{
			textAllowOverlap = nullptr;
			textAnchor = nullptr;
			textField = nullptr;
			fontFace = nullptr;
			textIgnorePlacement = nullptr;
			textJustify = nullptr;
			textKeepUpright = nullptr;
			letterSpacing = nullptr;
			textLineHeight = nullptr;
			textMaxAngleDegrees = nullptr;
			textMaxWidth = nullptr;
			textOffset = nullptr;
			textOptional = nullptr;
			textPadding = nullptr;
			textPitchAlignment = nullptr;
			textRadialOffset = nullptr;
			textRotationAlignment = nullptr;
			textSize = nullptr;
			textTransform = nullptr;
			textVariableAnchor = nullptr;
			textStyleFlags = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				textAllowOverlap.get(),
				textAnchor.get(),
				textField.get(),
				fontFace.get(),
				textIgnorePlacement.get(),
				textJustify.get(),
				textKeepUpright.get(),
				letterSpacing.get(),
				textLineHeight.get(),
				textMaxAngleDegrees.get(),
				textMaxWidth.get(),
				textOffset.get(),
				textOptional.get(),
				textPadding.get(),
				textPitchAlignment.get(),
				textRadialOffset.get(),
				textRotationAlignment.get(),
				textSize.get(),
				textTransform.get(),
				textVariableAnchor.get(),
				textStyleFlags.get(),
			};
		}

	};

}

#undef ENUM_EXPR