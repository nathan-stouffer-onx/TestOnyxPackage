#pragma once

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/BooleanExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/FormatExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/ExpressionOwner.h"

namespace onyx::Styling
{

	struct TextLayoutComponent final : public ExpressionOwner
	{
		
		Expressions::BooleanT::Ptr allowOverlap = Expressions::Boolean::construct(false);
		Expressions::EnumT<Anchor>::Ptr anchor = Expressions::Enum::construct(Anchor::HORIZONTAL_CENTER);
		Expressions::FormattedT::Ptr field = Expressions::Format::construct("");
		Expressions::StringArrayT::Ptr fontFace;
		Expressions::BooleanT::Ptr ignorePlacement = Expressions::Boolean::construct(false);
		Expressions::EnumT<Justify>::Ptr justify = Expressions::Enum::construct(Justify::CENTER);
		Expressions::BooleanT::Ptr keepUpright = Expressions::Boolean::construct(true);
		Expressions::NumberT::Ptr letterSpacing = Expressions::Number::construct(1.f);
		Expressions::NumberT::Ptr lineHeight = Expressions::Number::construct(1.2f);
		Expressions::NumberT::Ptr maxAngleDegrees = Expressions::Number::construct(45);
		Expressions::NumberT::Ptr maxWidth = Expressions::Number::construct(10);
		Expressions::NumberArrayT::Ptr offset = Expressions::Array::construct<float>({ 0, 0 });
		Expressions::BooleanT::Ptr optional = Expressions::Boolean::construct(false);
		Expressions::NumberT::Ptr padding = Expressions::Number::construct(2);
		Expressions::EnumT<Alignment>::Ptr pitchAlignment = Expressions::Enum::construct(Alignment::Auto);
		Expressions::NumberT::Ptr radialOffset = Expressions::Number::construct(0);
		Expressions::EnumT<Alignment>::Ptr rotationAlignment = Expressions::Enum::construct(Alignment::Auto);
		Expressions::NumberT::Ptr size = Expressions::Number::construct(10.f);
		Expressions::EnumT<Transform>::Ptr transform = Expressions::Enum::construct(Transform::NONE);
		Expressions::ArrayT<Anchor>::Ptr variableAnchor = Expressions::Array::construct<Anchor>({ Anchor::CENTER });

		Expressions::EnumT<TextStyleFlags>::Ptr flags = Expressions::Enum::construct(TextStyleFlags::NORMAL);

		TextLayoutComponent() = default;

		void nullify() override
		{
			allowOverlap = nullptr;
			anchor = nullptr;
			field = nullptr;
			fontFace = nullptr;
			ignorePlacement = nullptr;
			justify = nullptr;
			keepUpright = nullptr;
			letterSpacing = nullptr;
			lineHeight = nullptr;
			maxAngleDegrees = nullptr;
			maxWidth = nullptr;
			offset = nullptr;
			optional = nullptr;
			padding = nullptr;
			pitchAlignment = nullptr;
			radialOffset = nullptr;
			rotationAlignment = nullptr;
			size = nullptr;
			transform = nullptr;
			variableAnchor = nullptr;
			flags = nullptr;
		}

		std::vector<Expressions::ExpressionBase const*> expressions() const override
		{
			return
			{
				allowOverlap.get(),
				anchor.get(),
				field.get(),
				fontFace.get(),
				ignorePlacement.get(),
				justify.get(),
				keepUpright.get(),
				letterSpacing.get(),
				lineHeight.get(),
				maxAngleDegrees.get(),
				maxWidth.get(),
				offset.get(),
				optional.get(),
				padding.get(),
				pitchAlignment.get(),
				radialOffset.get(),
				rotationAlignment.get(),
				size.get(),
				transform.get(),
				variableAnchor.get(),
				flags.get(),
			};
		}

	};

}