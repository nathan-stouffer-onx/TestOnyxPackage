#include "Effect.h"

namespace onyx::Styling
{

	BackgroundEffect::BackgroundEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	CircleEffect::CircleEffect()
	{
		ADD_OPERATIONS(blendMode);
		ADD_OPERATIONS(depthTest);
		ADD_OPERATIONS(fadeRange);
	}

	ContourLabelEffect::ContourLabelEffect() = default;

	ContourLineEffect::ContourLineEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	ElevationEffect::ElevationEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	FillEffect::FillEffect()
	{
		ADD_OPERATIONS(blendMode);
		ADD_OPERATIONS(depthTest);
		ADD_OPERATIONS(fadeRange);
		ADD_OPERATIONS(zOffset);
	}

	HillshadeEffect::HillshadeEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	IntersectEffect::IntersectEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	LineEffect::LineEffect()
	{
		ADD_OPERATIONS(blendMode);
		ADD_OPERATIONS(depthTest);
		ADD_OPERATIONS(fadeRange);
		ADD_OPERATIONS(zOffset);
	}

	RasterEffect::RasterEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	SlopeAngleEffect::SlopeAngleEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	SlopeAspectEffect::SlopeAspectEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	SunlightEffect::SunlightEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

	SymbolEffect::SymbolEffect() = default;

	ViewshedEffect::ViewshedEffect()
	{
		ADD_OPERATIONS(blendMode);
	}

}