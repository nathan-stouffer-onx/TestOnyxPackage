#include "Effect.h"

namespace onyx::Styling
{

	BackgroundEffect::BackgroundEffect() = default;

	CircleEffect::CircleEffect() = default;

	ContourLabelEffect::ContourLabelEffect() = default;

	ContourLineEffect::ContourLineEffect() = default;

	ElevationEffect::ElevationEffect() = default;

	FillEffect::FillEffect()
	{
		ADD_OPERATIONS(depthTest);
		ADD_OPERATIONS(fadeRange);
		ADD_OPERATIONS(zOffset);
	}

	HillshadeEffect::HillshadeEffect() = default;

	IntersectEffect::IntersectEffect() = default;

	LineEffect::LineEffect()
	{
		ADD_OPERATIONS(depthTest);
		ADD_OPERATIONS(fadeRange);
		ADD_OPERATIONS(zOffset);
	}

	RasterEffect::RasterEffect() = default;

	SlopeAngleEffect::SlopeAngleEffect() = default;

	SlopeAspectEffect::SlopeAspectEffect() = default;

	SunlightEffect::SunlightEffect() = default;

	SymbolEffect::SymbolEffect() = default;

	ViewshedEffect::ViewshedEffect() = default;

}