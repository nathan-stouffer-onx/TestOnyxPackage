#include "EffectContext.h"

namespace lgigl = ::lucid::gigl;
namespace prim = ::lucid::gigl::primitives;

namespace onyx::Styling::primitives
{

	lgigl::PrimitiveInfo const EffectTypes::infos[EffectTypes::TYPE_COUNT] =
	{
		{ prim::GiglTypes::Type<prim::UNKNOWN									>::VALUE,            "<unknown>" },
		{ prim::GiglTypes::Type<prim::UNDEFINED									>::VALUE,          "<undefined>" },
		{ EffectTypes::Type<std::shared_ptr<BackgroundEffect			const>	>::VALUE,      "BackgroundEffect" },
		{ EffectTypes::Type<std::shared_ptr<CircleEffect				const>	>::VALUE,          "CircleEffect" },
		{ EffectTypes::Type<std::shared_ptr<ContourLabelEffect			const>	>::VALUE,    "ContourLabelEffect" },
		{ EffectTypes::Type<std::shared_ptr<ContourLineEffect			const>	>::VALUE,     "ContourLineEffect" },
		{ EffectTypes::Type<std::shared_ptr<ElevationEffect				const>	>::VALUE,       "ElevationEffect" },
		{ EffectTypes::Type<std::shared_ptr<FillEffect					const>	>::VALUE,            "FillEffect" },
		{ EffectTypes::Type<std::shared_ptr<HillshadeEffect				const>	>::VALUE,       "HillshadeEffect" },
		{ EffectTypes::Type<std::shared_ptr<IntersectEffect				const>	>::VALUE,       "IntersectEffect" },
		{ EffectTypes::Type<std::shared_ptr<LineEffect					const>	>::VALUE,            "LineEffect" },
		{ EffectTypes::Type<std::shared_ptr<RasterEffect				const>	>::VALUE,          "RasterEffect" },
		{ EffectTypes::Type<std::shared_ptr<SlopeAngleEffect			const>	>::VALUE,      "SlopeAngleEffect" },
		{ EffectTypes::Type<std::shared_ptr<SlopeAspectEffect			const>	>::VALUE,     "SlopeAspectEffect" },
		{ EffectTypes::Type<std::shared_ptr<SunlightEffect				const>	>::VALUE,        "SunlightEffect" },
		{ EffectTypes::Type<std::shared_ptr<SymbolEffect				const>	>::VALUE,          "SymbolEffect" },
		{ EffectTypes::Type<std::shared_ptr<ViewshedEffect				const>	>::VALUE,        "ViewshedEffect" },
	};

}