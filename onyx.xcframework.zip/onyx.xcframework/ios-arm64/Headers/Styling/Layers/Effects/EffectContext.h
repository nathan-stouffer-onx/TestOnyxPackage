#pragma once

#include <lucid/gigl/Context.h>
#include <lucid/gigl/Primitive.h>

#include "Styling/Layers/Declarations.h"

namespace onyx::Styling
{

	namespace primitives
	{

		struct EffectTypes
		{

			enum { TYPE_COUNT = 17 };

			static lucid::gigl::PrimitiveInfo const infos[TYPE_COUNT];

			// Deleting this constructor forces a compile error if someone tries to use a context
			// to store/retrieve something that is unsupported.
			template<class T>	struct Type { Type() = delete; enum { VALUE = 0 }; };

		};

		template<> struct EffectTypes::Type<lucid::gigl::primitives::UNKNOWN             > { enum { VALUE = 0 }; };
		template<> struct EffectTypes::Type<lucid::gigl::primitives::UNDEFINED           > { enum { VALUE = 1 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<BackgroundEffect       const>> { enum { VALUE = 2 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<CircleEffect           const>> { enum { VALUE = 3 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<ContourLabelEffect     const>> { enum { VALUE = 4 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<ContourLineEffect      const>> { enum { VALUE = 5 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<ElevationEffect        const>> { enum { VALUE = 6 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<FillEffect             const>> { enum { VALUE = 7 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<HillshadeEffect        const>> { enum { VALUE = 8 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<IntersectEffect        const>> { enum { VALUE = 9 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<LineEffect             const>> { enum { VALUE = 10 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<RasterEffect           const>> { enum { VALUE = 11 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<SlopeAngleEffect       const>> { enum { VALUE = 12 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<SlopeAspectEffect      const>> { enum { VALUE = 13 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<SunlightEffect         const>> { enum { VALUE = 14 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<SymbolEffect           const>> { enum { VALUE = 15 }; };
		template<> struct EffectTypes::Type<std::shared_ptr<ViewshedEffect         const>> { enum { VALUE = 16 }; };

	}

	using EffectContext = lucid::gigl::FlexContext<primitives::EffectTypes>;

}