#pragma once

#include <lucid/gal/Types.h>

#include "Styling/Enums.h"
#include "Styling/Expressions/Expressions.h"
#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/ColorExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/ImageExpressions.h"
#include "Styling/Expressions/NumberExpressions.h"
#include "Styling/Expressions/StringExpressions.h"
#include "Styling/Layers/ExpressionOwner.h"

namespace onyx::Styling
{

	/*
	* Structs to represent Effect structures for each type of style layer that can be drawn on the map
	*/

	// base struct to define a Effect structure
	struct EffectBase : public ExpressionOwner
	{

		EffectBase() = default;
		virtual ~EffectBase() = default;

		virtual void validate(InitArgs const& args) const = 0;

		virtual Expressions::Dependencies dependencies(InitArgs const& args) const = 0;

		std::string baseId;
	};

	// This template struct lets us use the curiously-recurring-template pattern to have a
	// strongly-typed shared pointer to a "derived" class based on the template.  Also allows
	// us to use InitArgs::BaseFlags template function that will retrieve that
	// pointer from the style context.
	template<typename T>
	struct Effect : public EffectBase
	{
		virtual ~Effect() = default;

		std::shared_ptr<T const> const& base(InitArgs const& args) const
		{
			if (!baseId.empty() && !mBasePtr)
			{
				args.effects.getTo(baseId, mBasePtr);
			}
			return mBasePtr;
		}

		void setBase(std::shared_ptr<T const> const& base) { mBasePtr = base; }

		void validate(InitArgs const& args) const override final
		{
			// make sure that the base class exists and is of the correct type
			{
				base(args);
			}
			for (Expressions::ExpressionBase const* expr : expressions())
			{
				// for now, the only validation that occurs is that we reference valid context expressions
				// (which we confirm by getting the children)
				if (expr)
				{
					expr->children(args.expressions);
				}
			}
		}

		Expressions::Dependencies dependencies(InitArgs const& args) const override final
		{
			Expressions::Dependencies deps = Expressions::dependencies(args.expressions, expressions());
			if (auto const& base = this->base(args))
			{
				deps |= base->dependencies(args);
			}
			return deps;
		}

	private:
		std::shared_ptr<T const> mutable mBasePtr;
	};

	struct BackgroundEffect final : public Effect<BackgroundEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);

		BackgroundEffect();
	};

	struct CircleEffect final : public Effect<CircleEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		Expressions::EnumT<DepthTest>::Ptr depthTest = Expressions::Enum::construct(DepthTest::LEQUAL);
		Expressions::NumberArrayT::Ptr fadeRange = Expressions::Array::construct<float>({ 2.0, 4.0 });

		CircleEffect();
	};

	struct ContourLabelEffect final : public Effect<ContourLabelEffect>
	{
		ContourLabelEffect();
	};

	struct ContourLineEffect final : public Effect<ContourLineEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		Expressions::NumberArrayT::Ptr fadeRange = Expressions::Array::construct<float>({ 2.0, 4.0 });

		ContourLineEffect();
	};

	struct ElevationEffect final : public Effect<ElevationEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);

		ElevationEffect();
	};

	struct FillEffect final : public Effect<FillEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		Expressions::EnumT<DepthTest>::Ptr depthTest = Expressions::Enum::construct(DepthTest::LEQUAL);
		Expressions::NumberArrayT::Ptr fadeRange = Expressions::Array::construct<float>({ 2.0, 4.0 });
		Expressions::NumberT::Ptr zOffset = Expressions::Number::construct(0.f);

		FillEffect();
	};

	struct HillshadeEffect final : public Effect<HillshadeEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
	
		HillshadeEffect();
	};

	struct IntersectEffect final : public Effect<IntersectEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		
		IntersectEffect();
	};

	struct LineEffect final : public Effect<LineEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		Expressions::EnumT<DepthTest>::Ptr depthTest = Expressions::Enum::construct(DepthTest::LEQUAL);
		Expressions::NumberArrayT::Ptr fadeRange = Expressions::Array::construct<float>({ 2.0, 4.0 });
		Expressions::NumberT::Ptr zOffset = Expressions::Number::construct(0.f);

		LineEffect();
	};

	struct RasterEffect final : public Effect<RasterEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);

		RasterEffect();
	};

	struct SlopeAngleEffect final : public Effect<SlopeAngleEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		
		SlopeAngleEffect();
	};

	struct SlopeAspectEffect final : public Effect<SlopeAspectEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		
		SlopeAspectEffect();
	};

	struct SunlightEffect final : public Effect<SunlightEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		
		SunlightEffect();
	};

	struct SymbolEffect : public Effect<SymbolEffect>
	{
		SymbolEffect();
	};

	struct ViewshedEffect final : public Effect<ViewshedEffect>
	{
		Expressions::EnumT<BlendMode>::Ptr blendMode = Expressions::Enum::construct(BlendMode::ALPHA);
		
		ViewshedEffect();
	};

}