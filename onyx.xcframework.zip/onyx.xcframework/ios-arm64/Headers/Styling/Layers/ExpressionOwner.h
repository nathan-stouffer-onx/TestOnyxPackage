#pragma once

#include <memory>
#include <vector>

#include "Styling/Layers/Arguments.h"

namespace onyx::Styling
{

	struct ExpressionOwner
	{

		virtual ~ExpressionOwner() = default;

		virtual void nullify()
		{
			for (auto& operations : mOperations)
			{
				operations.reset();
			}
		}

		virtual std::vector<Expressions::ExpressionBase const*> expressions() const
		{
			std::vector<Expressions::ExpressionBase const*> exprs;
			for (auto& operations : mOperations)
			{
				exprs.push_back(operations.get());
			}
			return exprs;
		}

	protected:

		struct Operations
		{
			std::function<void()> reset;
			std::function<Expressions::ExpressionBase const*()> get;
		};

		std::vector<Operations> mOperations;

	};

}

// for use in derived classes
#define ADD_OPERATIONS(member) mOperations.push_back({ [&]() { member.reset(); }, [&]() { return member.get(); } });