#pragma once

#include "Styling/Layers/Arguments.h"

namespace onyx::Styling
{

	struct ExpressionOwner
	{

		virtual ~ExpressionOwner() = default;

		virtual std::vector<Expressions::ExpressionBase const*> expressions() const = 0;

		virtual void nullify() = 0;

	};

}