#pragma once

#include <string>
#include <unordered_map>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

#include <Utils/UUID.h>

namespace onyx::Styling
{
	using FeatureIdT = Utils::UUID;

	struct Feature
	{
		std::string source;
		std::string sourceLayer;
		FeatureIdT id;

		Feature() = default;
		Feature(std::string const& _source, FeatureIdT _id) : Feature(_source, "", _id) {}
		Feature(std::string const& _source, std::string const& _sourceLayer, FeatureIdT _id) : source(_source), sourceLayer(_sourceLayer), id(_id) {}
	};

	using Value = vector_tile::Tile_Value;
	using PropertiesT = std::unordered_map<std::string, Value>;
	using FeatureStateT = std::unordered_map<std::string, Value>;

	struct ResolvedImage
	{
		std::string key;

		ResolvedImage() = default;
		explicit ResolvedImage(std::string const& _key) : key(_key) {}

		inline bool operator==(ResolvedImage const& rhs) const { return key == rhs.key; }
		inline bool operator!=(ResolvedImage const& rhs) const { return !(*this == rhs); }

		inline bool operator<(ResolvedImage const& rhs) const { return key < rhs.key; }
		inline bool operator>(ResolvedImage const& rhs) const { return key > rhs.key; }

	};

}