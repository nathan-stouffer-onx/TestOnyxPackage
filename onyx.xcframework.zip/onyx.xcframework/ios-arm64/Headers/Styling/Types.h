#ifndef __STYLING_TYPES_H__
#define __STYLING_TYPES_H__

#include <string>
#include <unordered_map>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

namespace onyx {
namespace Styling {

	using PropertiesT = std::unordered_map<std::string, vector_tile::Tile_Value>;
	using FeatureStateT = std::unordered_map<std::string, vector_tile::Tile_Value>;

	struct ResolvedImage
	{
		std::string key;

		ResolvedImage() = default;
		explicit ResolvedImage(std::string const& _key) : key(_key) {}

		inline bool operator==(ResolvedImage const& rhs) const { return key == rhs.key; }
		inline bool operator!=(ResolvedImage const& rhs) const { return !(*this == rhs); }

		inline bool operator<(ResolvedImage const& rhs) const { return key < rhs.key; }
		inline bool operator>(ResolvedImage const& rhs) const { return key > rhs.key; }

	};

} }

#endif