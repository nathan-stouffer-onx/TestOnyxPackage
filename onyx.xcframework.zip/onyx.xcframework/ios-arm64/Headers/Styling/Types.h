#pragma once

#include <string>
#include <unordered_map>

#include <Warnings.h>

#include <3rdParty/nlohmann/json.hpp>
#include <Utils/UUID.h>

namespace onyx::Styling
{
	using FeatureIdT = Utils::UUID;

	struct Feature
	{

		enum class Types
		{
			UNKNOWN,
			POINT,
			LINESTRING,
			POLYGON
		};

		std::string source;
		std::string sourceLayer;
		FeatureIdT id;

		Feature() = default;
		Feature(std::string const& _source, FeatureIdT _id) : Feature(_source, "", _id) {}
		Feature(std::string const& _source, std::string const& _sourceLayer, FeatureIdT _id) : source(_source), sourceLayer(_sourceLayer), id(_id) {}

	};

	inline bool operator==(Feature const &lhs, Feature const& rhs)
	{
		return lhs.id == rhs.id
			&& lhs.source == rhs.source
			&& lhs.sourceLayer == rhs.sourceLayer;
	}

	using Value = nlohmann::json;
	using PropertiesT = std::unordered_map<std::string, Value>;
	using FeatureStateT = std::unordered_map<std::string, Value>;

	struct ResolvedImage
	{
		std::string key;

		ResolvedImage() = default;
		explicit ResolvedImage(std::string const& _key) : key(_key) {}

		inline bool operator==(ResolvedImage const& rhs) const { return key == rhs.key; }
		inline bool operator!=(ResolvedImage const& rhs) const { return !(*this == rhs); }

		inline bool operator<(ResolvedImage const& rhs) const { return key < rhs.key; }
		inline bool operator>(ResolvedImage const& rhs) const { return key > rhs.key; }

	};

}