#ifndef __STYLING_LAYER_JSON_PARSING_H__
#define __STYLING_LAYER_JSON_PARSING_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Layers/Layer.h"
#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"
#include "Styling/Styles/LineStyle.h"

namespace onyx {
namespace Styling {

#define DESERIALIZE_LAYER_TYPE(layerT, layoutT, paintT) \
	void from_json(nlohmann::json const& j, layerT& layer);\
	void from_json(nlohmann::json const& j, layoutT& layout);\
	void from_json(nlohmann::json const& j, paintT& paint);

	void from_json(nlohmann::json const& j, Layer& layer);
	void from_json(nlohmann::json const& j, SourcedLayer& layer);

	void from_json(nlohmann::json const& j, Layer::Type& type);

	void from_json(nlohmann::json const& j, LayoutBase::Visibility& visibility);

	void from_json(nlohmann::json const& j, BackgroundLayer& layer);

	void from_json(nlohmann::json const& j, BackgroundLayout& layout);
	void from_json(nlohmann::json const& j, BackgroundPaint& paint);

	void from_json(nlohmann::json const& j, SourcedLayer& layer);

	void from_json(nlohmann::json const& j, RasterLayer& layer);

	void from_json(nlohmann::json const& j, RasterLayout& layout);
	void from_json(nlohmann::json const& j, RasterPaint& paint);

	void from_json(nlohmann::json const& j, LineLayer& layer);

	void from_json(nlohmann::json const& j, LineLayout& layout);
	void from_json(nlohmann::json const& j, LinePaint& paint);

	DESERIALIZE_LAYER_TYPE(SymbolLayer, SymbolLayout, SymbolPaint);

	void from_json(nlohmann::json const& j, IntervalLayout& layout);

	DESERIALIZE_LAYER_TYPE(ContourLayer, ContourLayout, ContourPaint);

	DESERIALIZE_LAYER_TYPE(FillLayer, FillLayout, FillPaint);

} }

#endif