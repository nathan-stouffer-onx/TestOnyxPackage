#ifndef __STYLING_LAYER_JSON_PARSING_H__
#define __STYLING_LAYER_JSON_PARSING_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Layers/Layer.h"
#include "Styling/Layers/Layout.h"
#include "Styling/Layers/Paint.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Layer& layer);
	void from_json(nlohmann::json const& j, SourcedLayer& layer);

	void from_json(nlohmann::json const& j, Layer::Types& type);

	void from_json(nlohmann::json const& j, LayoutBase& layout);
	void from_json(nlohmann::json const& j, LayoutBase::Visibility& visibility);

	void from_json(nlohmann::json const& j, PaintBase& paint);

	void from_json(nlohmann::json const& j, BackgroundLayer& layer);
	void from_json(nlohmann::json const& j, BackgroundLayout& layout);
	void from_json(nlohmann::json const& j, BackgroundPaint& paint);

	void from_json(nlohmann::json const& j, SourcedLayer& layer);

	void from_json(nlohmann::json const& j, CircleLayer& layer);
	void from_json(nlohmann::json const& j, CircleLayout& layout);
	void from_json(nlohmann::json const& j, CirclePaint& paint);

	void from_json(nlohmann::json const& j, ContourLabelLayer& layer);
	void from_json(nlohmann::json const& j, ContourLabelLayout& layout);
	void from_json(nlohmann::json const& j, ContourLabelPaint& paint);

	void from_json(nlohmann::json const& j, ContourLineLayer& layer);
	void from_json(nlohmann::json const& j, ContourLineLayout& layout);
	void from_json(nlohmann::json const& j, ContourLinePaint& paint);

	void from_json(nlohmann::json const& j, ElevationLayer& layer);
	void from_json(nlohmann::json const& j, ElevationLayout& layout);
	void from_json(nlohmann::json const& j, ElevationPaint& paint);

	void from_json(nlohmann::json const& j, FillLayer& layer);
	void from_json(nlohmann::json const& j, FillLayout& layout);
	void from_json(nlohmann::json const& j, FillPaint& paint);

	void from_json(nlohmann::json const& j, IntersectLayer& layer);
	void from_json(nlohmann::json const& j, IntersectLayout& layout);
	void from_json(nlohmann::json const& j, IntersectPaint& paint);

	void from_json(nlohmann::json const& j, LineLayer& layer);
	void from_json(nlohmann::json const& j, LineLayout& layout);
	void from_json(nlohmann::json const& j, LinePaint& paint);

	void from_json(nlohmann::json const& j, RasterLayer& layer);
	void from_json(nlohmann::json const& j, RasterLayout& layout);
	void from_json(nlohmann::json const& j, RasterPaint& paint);

	void from_json(nlohmann::json const& j, SlopeAngleLayer& layer);
	void from_json(nlohmann::json const& j, SlopeAngleLayout& layout);
	void from_json(nlohmann::json const& j, SlopeAnglePaint& paint);

	void from_json(nlohmann::json const& j, SlopeAspectLayer& layer);
	void from_json(nlohmann::json const& j, SlopeAspectLayout& layout);
	void from_json(nlohmann::json const& j, SlopeAspectPaint& paint);

	void from_json(nlohmann::json const& j, SunlightLayer& layer);
	void from_json(nlohmann::json const& j, SunlightLayout& layout);
	void from_json(nlohmann::json const& j, SunlightPaint& paint);

	void from_json(nlohmann::json const& j, SymbolLayer& layer);
	void from_json(nlohmann::json const& j, SymbolLayout& layout);
	void from_json(nlohmann::json const& j, SymbolPaint& paint);

	void from_json(nlohmann::json const& j, ViewshedLayer& layer);
	void from_json(nlohmann::json const& j, ViewshedLayout& layout);
	void from_json(nlohmann::json const& j, ViewshedPaint& paint);

} }

#endif