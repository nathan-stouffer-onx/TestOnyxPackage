#include "StyleJson.h"

#include <deque>

#include <json/jsonParsing.h>

#include <System/OnyxException.h>

#include "Styling/Parse/Factory/SourceFactory.h"
#include "Styling/Parse/Factory/LayerFactory.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/LayerJson.h"
#include "Styling/Parse/MiscJson.h"
#include "Styling/Parse/SourceJson.h"
#include "Styling/Terrain.h"

namespace lucid {
namespace gigl {

	template<typename T>
	static onyx::Styling::Expressions::SharedExpressionPtr<T> parse_expr(nlohmann::json const& j)
	{
		return onyx::Styling::Expressions::Factory::expr<T>(j);
	}

	void from_json(nlohmann::json const& j, onyx::Styling::Expressions::ExpressionContext& expressions)
	{
		ONYX_ASSERT(j.is_object(), "'expressions' must be an object");
		for (auto const& [key, value] : j.items())
		{
			ONYX_ASSERT(value.is_object(), "'expressions' entries must be objects with \"type\" : \"expression\" pairs");
			for (auto const& expr : value.items())
			{
				auto const& typeKey = expr.key();
				if (typeKey == "boolean" || typeKey == "bool")
				{
					expressions.add(key, parse_expr<bool>(expr.value()));
				}
				else if (typeKey == "color")
				{
					expressions.add(key, parse_expr<lgal::Color>(expr.value()));
				}
				else if (typeKey == "format")
				{
					expressions.add(key, parse_expr<onyx::Styling::Formatted>(expr.value()));
				}
				else if (typeKey == "gradient")
				{
					expressions.add(key, parse_expr<onyx::Utils::Gradient>(expr.value()));
				}
				else if (typeKey == "image")
				{
					expressions.add(key, parse_expr<onyx::Styling::ResolvedImage>(expr.value()));
				}
				else if (typeKey == "number")
				{
					expressions.add(key, parse_expr<float>(expr.value()));
				}
				else if (typeKey == "range")
				{
					expressions.add(key, parse_expr<lgal::gpu::Range>(expr.value()));
				}
				else if (typeKey == "string")
				{
					expressions.add(key, parse_expr<std::string>(expr.value()));
				}
				else
				{
					logD(std::string("Unrecognized expression type: '" + typeKey + "'.  Types must be one of 'boolean', 'color', 'format', 'gradient', 'image', 'number', 'range', 'string'.  Case sensitive."));
				}
			}
		}
	}

	template <typename T>
	static std::shared_ptr<T const> parse_item(nlohmann::json const& j)
	{
		auto ptr = new T();
		auto result = std::unique_ptr<T const>(ptr);
		from_json(j, *ptr);
		return result;
	}

	void from_json(nlohmann::json const& j, onyx::Styling::LayoutContext& layouts)
	{
		ONYX_ASSERT(j.is_object(), "layouts must be an object");
		for (auto const& [key, value] : j.items())
		{
			ONYX_ASSERT(value.is_object(), "Layout entries must be objects with \"type\" : \"layout\" pairs");
			for (auto const& layout : value.items())
			{
				auto const& typeKey = layout.key();
				if (typeKey == "background-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::BackgroundLayout>(layout.value()));
				}
				else if (typeKey == "contour-label-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::ContourLabelLayout>(layout.value()));
				}
				else if (typeKey == "contour-line-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::ContourLineLayout>(layout.value()));
				}
				else if (typeKey == "elevation-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::ElevationLayout>(layout.value()));
				}
				else if (typeKey == "fill-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::FillLayout>(layout.value()));
				}
				else if (typeKey == "hillshade-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::HillshadeLayout>(layout.value()));
				}
				else if (typeKey == "intersect-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::IntersectLayout>(layout.value()));
				}
				else if (typeKey == "line-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::LineLayout>(layout.value()));
				}
				else if (typeKey == "raster-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::RasterLayout>(layout.value()));
				}
				else if (typeKey == "slope-angle-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::SlopeAngleLayout>(layout.value()));
				}
				else if (typeKey == "slope-aspect-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::SlopeAspectLayout>(layout.value()));
				}
				else if (typeKey == "sunlight-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::SunlightLayout>(layout.value()));
				}
				else if (typeKey == "symbol-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::SymbolLayout>(layout.value()));
				}
				else if (typeKey == "viewshed-layout")
				{
					layouts.add(key, parse_item<onyx::Styling::ViewshedLayout>(layout.value()));
				}
				else
				{
					logD(std::string("Unrecognized layout type: '" + typeKey + "'.  Types must be of the form '<layer-type>-layout'. Case sensitive."));
				}
			}
		}
	}

	void from_json(nlohmann::json const& j, onyx::Styling::PaintContext& paints)
	{
		ONYX_ASSERT(j.is_object(), "paints must be an object");
		for (auto const& [key, value] : j.items())
		{
			ONYX_ASSERT(value.is_object(), "Paint entries must be objects with \"type\" : \"paint\" pairs");
			for (auto const& paint : value.items())
			{
				auto const& typeKey = paint.key();
				if (typeKey == "background-paint")
				{
					paints.add(key, parse_item<onyx::Styling::BackgroundPaint>(paint.value()));
				}
				else if (typeKey == "contour-label-paint")
				{
					paints.add(key, parse_item<onyx::Styling::ContourLabelPaint>(paint.value()));
				}
				else if (typeKey == "contour-line-paint")
				{
					paints.add(key, parse_item<onyx::Styling::ContourLinePaint>(paint.value()));
				}
				else if (typeKey == "elevation-paint")
				{
					paints.add(key, parse_item<onyx::Styling::ElevationPaint>(paint.value()));
				}
				else if (typeKey == "fill-paint")
				{
					paints.add(key, parse_item<onyx::Styling::FillPaint>(paint.value()));
				}
				else if (typeKey == "hillshade-paint")
				{
					paints.add(key, parse_item<onyx::Styling::HillshadePaint>(paint.value()));
				}
				else if (typeKey == "intersect-paint")
				{
					paints.add(key, parse_item<onyx::Styling::IntersectPaint>(paint.value()));
				}
				else if (typeKey == "line-paint")
				{
					paints.add(key, parse_item<onyx::Styling::LinePaint>(paint.value()));
				}
				else if (typeKey == "raster-paint")
				{
					paints.add(key, parse_item<onyx::Styling::RasterPaint>(paint.value()));
				}
				else if (typeKey == "slope-angle-paint")
				{
					paints.add(key, parse_item<onyx::Styling::SlopeAnglePaint>(paint.value()));
				}
				else if (typeKey == "slope-aspect-paint")
				{
					paints.add(key, parse_item<onyx::Styling::SlopeAspectPaint>(paint.value()));
				}
				else if (typeKey == "sunlight-paint")
				{
					paints.add(key, parse_item<onyx::Styling::SunlightPaint>(paint.value()));
				}
				else if (typeKey == "symbol-paint")
				{
					paints.add(key, parse_item<onyx::Styling::SymbolPaint>(paint.value()));
				}
				else if (typeKey == "viewshed-paint")
				{
					paints.add(key, parse_item<onyx::Styling::ViewshedPaint>(paint.value()));
				}
				else
				{
					logD(std::string("Unrecognized paint type: '" + typeKey + "'.  Types must be of the form '<layer-type>-paint'.  Case sensitive."));
				}
			}
		}
	}

} }

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Expressions::ExpressionContext& expressions)
	{
		lucid::gigl::from_json(j, expressions);
	}

	void from_json(nlohmann::json const& j, LayoutContext& layouts)
	{
		lucid::gigl::from_json(j, layouts);
	}

	void from_json(nlohmann::json const& j, PaintContext& paints)
	{
		lucid::gigl::from_json(j, paints);
	}

	void from_json(nlohmann::json const& j, Style& style)
	{
		std::unique_ptr<Expressions::ExpressionContext> expressions = std::make_unique<Expressions::ExpressionContext>();
		std::unique_ptr<LayoutContext> layouts = std::make_unique<LayoutContext>();
		std::unique_ptr<PaintContext> paints = std::make_unique<PaintContext>();
		
		JsonParsing::SetIfFound(j, "expressions", *expressions);
		JsonParsing::SetIfFound(j, "layouts", *layouts);
		JsonParsing::SetIfFound(j, "paints", *paints);

		// re-assigning style overwrites any existing data -- this is intentional
		style = Style{ std::move(expressions), std::move(layouts), std::move(paints) };

		style.mVersion = JsonParsing::Require<uint32_t>(j, "version", "stylesheet root failed to have version");
		style.mName = JsonParsing::Get<std::string>(j, "name", "");
		
		auto spriteUrl = JsonParsing::Get<std::string>(j, "sprite", "");
		if (spriteUrl != "")
		{
			style.addSpritesheetUrl(spriteUrl);
		}

		style.mGlyphs = JsonParsing::Get<std::string>(j, "glyphs", "");

		nlohmann::json const& sources = JsonParsing::Require<nlohmann::json::object_t>(j, "sources", "stylesheet root failed to have sources");
		for (auto const& item : sources.items())
		{
			style.addSource(item.key(), Factory::source(item.value()));
		}

		if (j.contains("terrain"))
		{
			std::unique_ptr<Terrain> terrain = std::make_unique<Terrain>();
			from_json(j["terrain"], *terrain);
			style.setTerrain(std::move(terrain));
		}

		nlohmann::json const& layers = JsonParsing::Require<nlohmann::json::array_t>(j, "layers", "stylesheet root failed to have layers");
		for (auto const& layer : layers)
		{
			style.addLayer(Factory::layer(layer));
		}

		if (style.isValidationEnabled())
		{
			style.validate();
		}
		style.index();
	}

} }