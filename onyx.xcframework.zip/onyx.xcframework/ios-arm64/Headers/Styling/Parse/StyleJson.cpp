#include "StyleJson.h"

#include <deque>

#include <System/Map3DException.h>
#include <json/jsonParsing.h>

#include "Styling/Terrain.h"
#include "Factory/SourceFactory.h"
#include "Factory/LayerFactory.h"
#include "SourceJson.h"
#include "TerrainJson.h"
#include "LayerJson.h"
#include "Factory/ExpressionFactory.h"

namespace expr = onyx::Styling::Expressions;

namespace onyx {
namespace Styling {

	template <typename T>
	std::unique_ptr<T const> parse_item(nlohmann::json const& j)
	{
		auto ptr = new T();
		auto result = std::unique_ptr<T const>(ptr);
		from_json(j, *ptr);

		return result;
	}

	void load_context(nlohmann::json const &j, Style& style)
	{
		if (j.size() < 1)
		{
			return; // Nothing to do; empty context
		}
		
		MAP3D_ASSERT(j.is_object(), "Context must be an object");

		auto context = style.getContext();

		for (auto const &entry : j.items())
		{
			auto const& key = entry.key();
			MAP3D_ASSERT(!context->exists(key), std::string("Context Key '") + key + "' is already defined");
			auto const &value = entry.value();
			MAP3D_ASSERT(value.is_object(), "Context entries must be objects with \"type\" : \"expression\" pairs");
			for (auto const &expr : value.items())
			{
				auto const& typeKey = expr.key();
				/* ----- Context Expressions ---------------------------------------- */
				if (typeKey == "color")
				{
					style.addContextExpression<lgal::Color>(key, Expressions::Factory::expr<lgal::Color>(expr.value()));
				}
				else if (typeKey == "number")
				{
					style.addContextExpression<float>(key, Expressions::Factory::expr<float>(expr.value()));
				}
				else if (typeKey == "boolean" || typeKey == "bool")
				{
					style.addContextExpression<bool>(key, Expressions::Factory::expr<bool>(expr.value()));
				}
				else if (typeKey == "string")
				{
					style.addContextExpression<std::string>(key, Expressions::Factory::expr<std::string>(expr.value()));
				}
				/* ----- Context Paint styles -------------------------------------- */
				else if (typeKey == "background-paint")
				{
					style.addContextEntry(key, parse_item<BackgroundPaint>(expr.value()));
				}
				else if (typeKey == "raster-paint")
				{
					style.addContextEntry(key, parse_item<RasterPaint>(expr.value()));
				}
				else if (typeKey == "line-paint")
				{
					style.addContextEntry(key, parse_item<LinePaint>(expr.value()));
				}
				else if (typeKey == "fill-paint")
				{
					style.addContextEntry(key, parse_item<FillPaint>(expr.value()));
				}
				else if (typeKey == "symbol-paint")
				{
					style.addContextEntry(key, parse_item<SymbolPaint>(expr.value()));
				}
				else if (typeKey == "contour-paint")
				{
					style.addContextEntry(key, parse_item<ContourPaint>(expr.value()));
				}
				/* ----- Context Layout styles -------------------------------------- */
				else if (typeKey == "background-layout")
				{
					style.addContextEntry(key, parse_item<BackgroundLayout>(expr.value()));
				}
				else if (typeKey == "contour-layout")
				{
					style.addContextEntry(key, parse_item<ContourLayout>(expr.value()));
				}
				else if (typeKey == "fill-layout")
				{
					style.addContextEntry(key, parse_item<FillLayout>(expr.value()));
				}
				else if (typeKey == "interval-layout")
				{
					style.addContextEntry(key, parse_item<IntervalLayout>(expr.value()));
				}
				else if (typeKey == "line-layout")
				{
					style.addContextEntry(key, parse_item<LineLayout>(expr.value()));
				}
				else if (typeKey == "raster-layout")
				{
					style.addContextEntry(key, parse_item<RasterLayout>(expr.value()));
				}
				else if (typeKey == "symbol-layout")
				{
					style.addContextEntry(key, parse_item<SymbolLayout>(expr.value()));
				}
				else
				{
					logD(std::string("Unrecognized expression type: '" + typeKey + "'.  Types must be one of 'color', 'number', 'boolean', 'string'.  Case sensitive."));
				}
			}
		}
	}

	void from_json(nlohmann::json const& j, Style& style)
	{
		style.mVersion = JsonParsing::Require<uint32_t>(j, "version", "stylesheet root failed to have version");

		style.mName   = JsonParsing::Get<std::string>(j, "name", "");
		style.mSprite = JsonParsing::Get<std::string>(j, "sprite", "");
		style.mGlyphs = JsonParsing::Get<std::string>(j, "glyphs", "");

		auto context = j.find("context");
		if (context != j.end())
		{
			load_context(j.at("context"), style);
		}

		nlohmann::json const& sources = JsonParsing::Require<nlohmann::json::object_t>(j, "sources", "stylesheet root failed to have sources");
		for (auto const& item : sources.items())
		{
			style.addSource(item.key(), Factory::source(item.value()));
		}

		if (j.contains("terrain"))
		{
			std::unique_ptr<Terrain> terrain = std::make_unique<Terrain>();
			from_json(j["terrain"], *terrain);
			style.setTerrain(std::move(terrain));
		}

		nlohmann::json const& layers = JsonParsing::Require<nlohmann::json::array_t>(j, "layers", "stylesheet root failed to have layers");
		for (auto const& layer : layers)
		{
			style.addLayer(Factory::layer(layer));
		}

		style.validate();
		style.index();
	}

} }