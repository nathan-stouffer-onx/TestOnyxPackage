#include "ColorString.h"

#include <System/OnyxException.h>

namespace onyx {
namespace Styling {
namespace Parse {

	static inline bool BeginsWith(std::string_view const str, std::string_view const prefix)
	{
		return str.rfind(prefix, 0) == 0;
	}

	lgal::Color shorthex(std::string_view const str)
	{
		std::string_view chars = str.substr(1, 3);
		std::ostringstream hexStream;
		hexStream << "#" << chars[0] << chars[0] << chars[1] << chars[1] << chars[2] << chars[2];
		return hex(hexStream.str());
	}
	lgal::Color hex(std::string_view const str)
	{
		std::string_view hex = str.substr(1, 6);
		lgal::Color color = lgal::Color::FromARGB((std::stoul(std::string(hex), nullptr, 16)) | 0xFF000000);
		return color;
	}

	lgal::Color hexAlpha(std::string_view const str)
	{
		std::string_view hex = str.substr(1, 8);
		return lgal::Color::FromRGBA(uint32_t(std::stoul(std::string(hex), nullptr, 16)));
	}

	lgal::Color rgb(std::string_view const str)
	{
		// remove rgb(
		std::string_view chopped = str.substr(4);

		// parse and remove r component
		size_t delim = chopped.find(",");
		std::string_view r = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove g component
		delim = chopped.find(",");
		std::string_view g = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse b component
		delim = chopped.find(")");
		std::string_view b = chopped.substr(0, delim);
		
		lgal::Color color =
		{
			std::stoi(std::string(r)) / 255.f,
			std::stoi(std::string(g)) / 255.f,
			std::stoi(std::string(b)) / 255.f,
			1.0
		};

		return color;
	}
	lgal::Color rgba(std::string_view const str)
	{
		// remove rgba(
		std::string_view chopped = str.substr(5);

		// parse and remove r component
		size_t delim = chopped.find(",");
		std::string_view r = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove g component
		delim = chopped.find(",");
		std::string_view g = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove b component
		delim = chopped.find(",");
		std::string_view b = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse a component
		delim = chopped.find(")");
		std::string_view a = chopped.substr(0, delim);

		lgal::Color color =
		{
			std::stoi(std::string(r)) / 255.f,
			std::stoi(std::string(g)) / 255.f,
			std::stoi(std::string(b)) / 255.f,
			(float)std::stod(std::string(a))
		};

		return color;
	}

	lgal::Color hsl(std::string_view const str)
	{
		// remove hls(
		std::string_view chopped = str.substr(4);

		// parse and remove h component
		size_t delim = chopped.find(",");
		std::string_view hString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove l component
		delim = chopped.find("%");
		std::string_view sString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 3);

		// parse b component
		delim = chopped.find(")");
		std::string_view vString = chopped.substr(0, delim);

		float h = (float)std::stod(std::string(hString)) * lmath::constants::pi<float>() / 180.0f;
		float s = (float)std::stod(std::string(sString)) / 100.0f;
		float v = (float)std::stod(std::string(vString)) / 100.0f;

		lgal::Color color = lgal::HSL{ h, s, v, 1.0f };
		return color;
	}
	lgal::Color hsla(std::string_view const str)
	{
		// remove hlsa(
		std::string_view chopped = str.substr(5);

		// parse and remove h component
		size_t delim = chopped.find(",");
		std::string_view hString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove l component
		delim = chopped.find("%");
		std::string_view sString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 3);

		// parse and remove b component
		delim = chopped.find("%");
		std::string_view vString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 3);

		// parse a component
		delim = chopped.find(")");
		std::string_view aString = chopped.substr(0, delim);

		float h = (float)std::stod(std::string(hString)) * lmath::constants::pi<float>() / 180.f;
		float s = (float)std::stod(std::string(sString)) / 100.f;
		float v = (float)std::stod(std::string(vString)) / 100.f;
		float a = (float)std::stod(std::string(aString));

		lgal::Color color = lgal::HSL{ h, s, v, a };
		return color;
	}

	lgal::Color color(std::string_view const str)
	{
		if (BeginsWith(str, "#"))
		{
			switch (str.length())
			{
				case 4: return shorthex(str); break;
				case 7: return hex(str);      break;
				case 9: return hexAlpha(str); break;
				default: ONYX_THROW("Invalid string length while parsing hex string"); break;
			}
		}
		else if (BeginsWith(str, "rgba"))
		{
			return rgba(str);
		}
		else if (BeginsWith(str, "rgb"))
		{
			return rgb(str);
		}
		else if (BeginsWith(str, "hsla"))
		{
			return hsla(str);
		}
		else if (BeginsWith(str, "hsl"))
		{
			return hsl(str);
		}

		ONYX_THROW("invalid color string");
		return 0xFF000000;
	}

	std::string str(lgal::Color const& color)
	{
		std::ostringstream os;
		os << "rgba(" << int(color.r * 255.f) << ", " << int(color.g * 255.f) << ", " << int(color.b * 255.f) << ", " << color.a << ")";
		return os.str();
	}

} } }
