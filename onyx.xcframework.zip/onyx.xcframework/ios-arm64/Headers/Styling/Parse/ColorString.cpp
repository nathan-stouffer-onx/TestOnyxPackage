#include "ColorString.h"

#include <unordered_map>

#include <System/OnyxException.h>
#include <Utils/StringUtils.h>

namespace onyx {
namespace Styling {
namespace Parse {

	static inline bool BeginsWith(std::string_view const str, std::string_view const prefix)
	{
		return str.rfind(prefix, 0) == 0;
	}

	lgal::Color shorthex(std::string_view const str)
	{
		std::string_view chars = str.substr(1, 3);
		std::ostringstream hexStream;
		hexStream << "#" << chars[0] << chars[0] << chars[1] << chars[1] << chars[2] << chars[2];
		return hex(hexStream.str());
	}
	lgal::Color hex(std::string_view const str)
	{
		std::string_view hex = str.substr(1, 6);
		lgal::Color color = lgal::Color::FromARGB((std::stoul(std::string(hex), nullptr, 16)) | 0xFF000000);
		return color;
	}

	lgal::Color hexAlpha(std::string_view const str)
	{
		std::string_view hex = str.substr(1, 8);
		return lgal::Color::FromRGBA(uint32_t(std::stoul(std::string(hex), nullptr, 16)));
	}

	lgal::Color rgb(std::string_view const str)
	{
		// remove rgb(
		std::string_view chopped = str.substr(4);

		// parse and remove r component
		size_t delim = chopped.find(",");
		std::string_view r = chopped.substr(0, delim);
		chopped = Utils::trim(chopped.substr(delim + 1));

		// parse and remove g component
		delim = chopped.find(",");
		std::string_view g = chopped.substr(0, delim);
		chopped = Utils::trim(chopped.substr(delim + 1));

		// parse b component
		delim = chopped.find(")");
		std::string_view b = chopped.substr(0, delim);
		
		lgal::Color color =
		{
			std::stoi(std::string(r)) / 255.f,
			std::stoi(std::string(g)) / 255.f,
			std::stoi(std::string(b)) / 255.f,
			1.0
		};

		return color;
	}
	lgal::Color rgba(std::string_view const str)
	{
		// remove rgba(
		std::string_view chopped = str.substr(5);

		// parse and remove r component
		size_t delim = chopped.find(",");
		std::string_view r = chopped.substr(0, delim);
		chopped = Utils::trim(chopped.substr(delim + 1));

		// parse and remove g component
		delim = chopped.find(",");
		std::string_view g = chopped.substr(0, delim);
		chopped = Utils::trim(chopped.substr(delim + 1));

		// parse and remove b component
		delim = chopped.find(",");
		std::string_view b = chopped.substr(0, delim);
		chopped = Utils::trim(chopped.substr(delim + 1));

		// parse a component
		delim = chopped.find(")");
		std::string_view a = chopped.substr(0, delim);

		lgal::Color color =
		{
			std::stoi(std::string(r)) / 255.f,
			std::stoi(std::string(g)) / 255.f,
			std::stoi(std::string(b)) / 255.f,
			(float)std::stod(std::string(a))
		};

		return color;
	}

	lgal::Color hsl(std::string_view const str)
	{
		// remove hls(
		std::string_view chopped = str.substr(4);

		// parse and remove h component
		size_t delim = chopped.find(",");
		std::string_view hString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove l component
		delim = chopped.find("%");
		std::string_view sString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 3);

		// parse b component
		delim = chopped.find(")");
		std::string_view vString = chopped.substr(0, delim);

		float h = (float)std::stod(std::string(hString)) * lmath::constants::pi<float>() / 180.0f;
		float s = (float)std::stod(std::string(sString)) / 100.0f;
		float v = (float)std::stod(std::string(vString)) / 100.0f;

		lgal::Color color = lgal::HSL{ h, s, v, 1.0f };
		return color;
	}
	lgal::Color hsla(std::string_view const str)
	{
		// remove hlsa(
		std::string_view chopped = str.substr(5);

		// parse and remove h component
		size_t delim = chopped.find(",");
		std::string_view hString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 2);

		// parse and remove l component
		delim = chopped.find("%");
		std::string_view sString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 3);

		// parse and remove b component
		delim = chopped.find("%");
		std::string_view vString = chopped.substr(0, delim);
		chopped = chopped.substr(delim + 3);

		// parse a component
		delim = chopped.find(")");
		std::string_view aString = chopped.substr(0, delim);

		float h = (float)std::stod(std::string(hString)) * lmath::constants::pi<float>() / 180.f;
		float s = (float)std::stod(std::string(sString)) / 100.f;
		float v = (float)std::stod(std::string(vString)) / 100.f;
		float a = (float)std::stod(std::string(aString));

		lgal::Color color = lgal::HSL{ h, s, v, a };
		return color;
	}

	lgal::Color html(std::string_view const str)
	{
		static std::unordered_map<std::string, lgal::Color> const sColors =
		{
			{ "aliceblue",				0xFFF0F8FF	},
			{ "antiquewhite",			0xFFFAEBD7	},
			{ "aqua",					0xFF00FFFF	},
			{ "aquamarine",				0xFF7FFFD4	},
			{ "azure",					0xFFF0FFFF	},
			{ "beige",					0xFFF5F5DC	},
			{ "bisque",					0xFFFFE4C4	},
			{ "black",					0xFF000000	},
			{ "blanchedalmond",			0xFFFFEBCD	},
			{ "blue",					0xFF0000FF	},
			{ "blueviolet",				0xFF8A2BE2	},
			{ "brown",					0xFFA52A2A	},
			{ "burlywood",				0xFFDEB887	},
			{ "cadetblue",				0xFF5F9EA0	},
			{ "chartreuse",				0xFF7FFF00	},
			{ "chocolate",				0xFFD2691E	},
			{ "coral",					0xFFFF7F50	},
			{ "cornflowerblue",			0xFF6495ED	},
			{ "cornsilk",				0xFFFFF8DC	},
			{ "crimson",				0xFFDC143C	},
			{ "cyan",					0xFF00FFFF	},
			{ "darkblue",				0xFF00008B	},
			{ "darkcyan",				0xFF008B8B	},
			{ "darkgoldenrod",			0xFFB8860B	},
			{ "darkgray",				0xFFA9A9A9	},
			{ "darkgrey",				0xFFA9A9A9	},
			{ "darkgreen",				0xFF006400	},
			{ "darkkhaki",				0xFFBDB76B	},
			{ "darkmagenta",			0xFF8B008B	},
			{ "darkolivegreen",			0xFF556B2F	},
			{ "darkorange",				0xFFFF8C00	},
			{ "darkorchid",				0xFF9932CC	},
			{ "darkred",				0xFF8B0000	},
			{ "darksalmon",				0xFFE9967A	},
			{ "darkseagreen",			0xFF8FBC8F	},
			{ "darkslateblue",			0xFF483D8B	},
			{ "darkslategray",			0xFF2F4F4F	},
			{ "darkslategrey",			0xFF2F4F4F	},
			{ "darkturquoise",			0xFF00CED1	},
			{ "darkviolet",				0xFF9400D3	},
			{ "deeppink",				0xFFFF1493	},
			{ "deepskyblue",			0xFF00BFFF	},
			{ "dimgray",				0xFF696969	},
			{ "dimgrey",				0xFF696969	},
			{ "dodgerblue",				0xFF1E90FF	},
			{ "firebrick",				0xFFB22222	},
			{ "floralwhite",			0xFFFFFAF0	},
			{ "forestgreen",			0xFF228B22	},
			{ "fuchsia",				0xFFFF00FF	},
			{ "gainsboro",				0xFFDCDCDC	},
			{ "ghostwhite",				0xFFF8F8FF	},
			{ "gold",					0xFFFFD700	},
			{ "goldenrod",				0xFFDAA520	},
			{ "gray",					0xFF808080	},
			{ "grey",					0xFF808080	},
			{ "green",					0xFF008000	},
			{ "greenyellow",			0xFFADFF2F	},
			{ "honeydew",				0xFFF0FFF0	},
			{ "hotpink",				0xFFFF69B4	},
			{ "indianred",				0xFFCD5C5C	},
			{ "indigo",					0xFF4B0082	},
			{ "ivory",					0xFFFFFFF0	},
			{ "khaki",					0xFFF0E68C	},
			{ "lavender",				0xFFE6E6FA	},
			{ "lavenderblush",			0xFFFFF0F5	},
			{ "lawngreen",				0xFF7CFC00	},
			{ "lemonchiffon",			0xFFFFFACD	},
			{ "lightblue",				0xFFADD8E6	},
			{ "lightcoral",				0xFFF08080	},
			{ "lightcyan",				0xFFE0FFFF	},
			{ "lightgoldenrodyellow",	0xFFFAFAD2	},
			{ "lightgray",				0xFFD3D3D3	},
			{ "lightgrey",				0xFFD3D3D3	},
			{ "lightgreen",				0xFF90EE90	},
			{ "lightpink",				0xFFFFB6C1	},
			{ "lightsalmon",			0xFFFFA07A	},
			{ "lightseagreen",			0xFF20B2AA	},
			{ "lightskyblue",			0xFF87CEFA	},
			{ "lightslategray",			0xFF778899	},
			{ "lightslategrey",			0xFF778899	},
			{ "lightsteelblue",			0xFFB0C4DE	},
			{ "lightyellow",			0xFFFFFFE0	},
			{ "lime",					0xFF00FF00	},
			{ "limegreen",				0xFF32CD32	},
			{ "linen",					0xFFFAF0E6	},
			{ "magenta",				0xFFFF00FF	},
			{ "maroon",					0xFF800000	},
			{ "mediumaquamarine",		0xFF66CDAA	},
			{ "mediumblue",				0xFF0000CD	},
			{ "mediumorchid",			0xFFBA55D3	},
			{ "mediumpurple",			0xFF9370DB	},
			{ "mediumseagreen",			0xFF3CB371	},
			{ "mediumslateblue",		0xFF7B68EE	},
			{ "mediumspringgreen",		0xFF00FA9A	},
			{ "mediumturquoise",		0xFF48D1CC	},
			{ "mediumvioletred",		0xFFC71585	},
			{ "midnightblue",			0xFF191970	},
			{ "mintcream",				0xFFF5FFFA	},
			{ "mistyrose",				0xFFFFE4E1	},
			{ "moccasin",				0xFFFFE4B5	},
			{ "navajowhite",			0xFFFFDEAD	},
			{ "navy",					0xFF000080	},
			{ "oldlace",				0xFFFDF5E6	},
			{ "olive",					0xFF808000	},
			{ "olivedrab",				0xFF6B8E23	},
			{ "orange",					0xFFFFA500	},
			{ "orangered",				0xFFFF4500	},
			{ "orchid",					0xFFDA70D6	},
			{ "palegoldenrod",			0xFFEEE8AA	},
			{ "palegreen",				0xFF98FB98	},
			{ "paleturquoise",			0xFFAFEEEE	},
			{ "palevioletred",			0xFFDB7093	},
			{ "papayawhip",				0xFFFFEFD5	},
			{ "peachpuff",				0xFFFFDAB9	},
			{ "peru",					0xFFCD853F	},
			{ "pink",					0xFFFFC0CB	},
			{ "plum",					0xFFDDA0DD	},
			{ "powderblue",				0xFFB0E0E6	},
			{ "purple",					0xFF800080	},
			{ "rebeccapurple",			0xFF663399	},
			{ "red",					0xFFFF0000	},
			{ "rosybrown",				0xFFBC8F8F	},
			{ "royalblue",				0xFF4169E1	},
			{ "saddlebrown",			0xFF8B4513	},
			{ "salmon",					0xFFFA8072	},
			{ "sandybrown",				0xFFF4A460	},
			{ "seagreen",				0xFF2E8B57	},
			{ "seashell",				0xFFFFF5EE	},
			{ "sienna",					0xFFA0522D	},
			{ "silver",					0xFFC0C0C0	},
			{ "skyblue",				0xFF87CEEB	},
			{ "slateblue",				0xFF6A5ACD	},
			{ "slategray",				0xFF708090	},
			{ "slategrey",				0xFF708090	},
			{ "snow",					0xFFFFFAFA	},
			{ "springgreen",			0xFF00FF7F	},
			{ "steelblue",				0xFF4682B4	},
			{ "tan",					0xFFD2B48C	},
			{ "teal",					0xFF008080	},
			{ "thistle",				0xFFD8BFD8	},
			{ "tomato",					0xFFFF6347	},
			{ "turquoise",				0xFF40E0D0	},
			{ "violet",					0xFFEE82EE	},
			{ "wheat",					0xFFF5DEB3	},
			{ "white",					0xFFFFFFFF	},
			{ "whitesmoke",				0xFFF5F5F5	},
			{ "yellow",					0xFFFFFF00	},
			{ "yellowgreen",			0xFF9ACD32	},
		};

		std::string lower(str);
		std::transform(lower.begin(), lower.end(), lower.begin(), [](char c) { return static_cast<char>(std::tolower(c)); });
		auto found = sColors.find(lower);
		if (found != sColors.end())
		{
			return found->second;
		}
		else
		{
			ONYX_THROW("invalid color string");
			return 0xFF000000;
		}
	}

	lgal::Color color(std::string_view const str)
	{
		if (BeginsWith(str, "#"))
		{
			switch (str.length())
			{
				case 4: return shorthex(str); break;
				case 7: return hex(str);      break;
				case 9: return hexAlpha(str); break;
				default: ONYX_THROW("Invalid string length while parsing hex string"); break;
			}
		}
		else if (BeginsWith(str, "rgba"))
		{
			return rgba(str);
		}
		else if (BeginsWith(str, "rgb"))
		{
			return rgb(str);
		}
		else if (BeginsWith(str, "hsla"))
		{
			return hsla(str);
		}
		else if (BeginsWith(str, "hsl"))
		{
			return hsl(str);
		}
		else 
		{
			return html(str);
		}
	}

	std::string str(lgal::Color const& color)
	{
		std::ostringstream os;
		os << "rgba(" << int(color.r * 255.f) << ", " << int(color.g * 255.f) << ", " << int(color.b * 255.f) << ", " << color.a << ")";
		return os.str();
	}

} } }
