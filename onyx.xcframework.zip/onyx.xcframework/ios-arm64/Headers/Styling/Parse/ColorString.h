#ifndef __STYLING_COLOR_STRING_H__
#define __STYLING_COLOR_STRING_H__

#include <string>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Styling {
namespace Parse {

	lgal::Color shorthex(std::string_view const str);
	lgal::Color hex     (std::string_view const str);
	lgal::Color hexAlpha(std::string_view const str);
	lgal::Color rgb     (std::string_view const str);
	lgal::Color rgba    (std::string_view const str);
	lgal::Color hsl     (std::string_view const str);
	lgal::Color hsla    (std::string_view const str);
	lgal::Color color   (std::string_view const str);

	std::string str(lgal::Color const& color);

} } }

#endif