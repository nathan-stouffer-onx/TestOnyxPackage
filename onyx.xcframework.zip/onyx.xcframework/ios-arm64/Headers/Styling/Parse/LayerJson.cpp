#include "LayerJson.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/ExpressionJson.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Layer& layer)
	{
		JsonParsing::Require(j, "id", layer.id, "Layer is missing required key 'id'");
		JsonParsing::Require(j, "type", layer.type, "Layer is missing required key 'type'");
		JsonParsing::SetIfFound(j, "maxzoom", layer.maxZoom);
		JsonParsing::SetIfFound(j, "minzoom", layer.minZoom);
		JsonParsing::SetIfFound(j, "filter", layer.filter);
		JsonParsing::SetIfFound(j, "groups", layer.groups);
	}
	void from_json(nlohmann::json const& j, Layer::Types& type)
	{
		type = std::fromStringView<Layer::Types>(std::string(j));
	}
	void from_json(nlohmann::json const& j, LayoutBase& layout)
	{
		JsonParsing::SetIfFound(j, "visibility", layout.visibility);
		JsonParsing::SetIfFound(j, "base", layout.baseId);
		if (!layout.baseId.empty()) { layout.nullify(); }
	}
	void from_json(nlohmann::json const& j, LayoutBase::Visibility& visibility)
	{
		visibility = std::fromStringView<LayoutBase::Visibility>(std::string(j));
	}
	void from_json(nlohmann::json const& j, PaintBase& paint)
	{
		JsonParsing::SetIfFound(j, "base", paint.baseId);
		if (!paint.baseId.empty()) { paint.nullify(); }
	}
	void from_json(nlohmann::json const& j, EffectBase& effect)
	{
		JsonParsing::SetIfFound(j, "base", effect.baseId);
		if (!effect.baseId.empty()) { effect.nullify(); }
	}
	
	void from_json(nlohmann::json const& j, SourcedLayer& layer)
	{
		from_json(j, static_cast<Layer&>(layer));
		JsonParsing::Require(j, "source", layer.source, "SourcedLayer is missing required key 'source'");
		JsonParsing::SetIfFound(j, "source-layer", layer.sourceLayer);
	}

	void from_json(nlohmann::json const& j, BackgroundLayer& layer)
	{
		from_json(j, static_cast<Layer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect",  *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, BackgroundLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
	}
	void from_json(nlohmann::json const& j, BackgroundPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "background-color", paint.color);
		JsonParsing::SetIfFound(j, "background-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "background-pattern", paint.pattern);
	}
	void from_json(nlohmann::json const& j, BackgroundEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	void from_json(nlohmann::json const& j, CircleLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, CircleLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "circle-sort-key", layout.sortKey);
	}
	void from_json(nlohmann::json const& j, CirclePaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "circle-color", paint.color);
		JsonParsing::SetIfFound(j, "circle-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "circle-radius", paint.radius);
		JsonParsing::SetIfFound(j, "circle-stroke-color", paint.strokeColor);
		JsonParsing::SetIfFound(j, "circle-stroke-opacity", paint.strokeOpacity);
		JsonParsing::SetIfFound(j, "circle-stroke-width", paint.strokeWidth);
		JsonParsing::SetIfFound(j, "circle-translate", paint.translate);
		JsonParsing::SetIfFound(j, "circle-translate-anchor", paint.translateAnchor);
	}
	void from_json(nlohmann::json const& j, CircleEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	// Contour label layer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, ContourLabelLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());

		JsonParsing::SetIfFound(j, "elementCap", layer.elementCap);
	}
	void from_json(nlohmann::json const& j, ContourLabelLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		from_json(j, layout.text);

		JsonParsing::SetIfFound(j, "contour-label-units", layout.units);
		JsonParsing::SetIfFound(j, "contour-label-period", layout.period);
		JsonParsing::SetIfFound(j, "contour-label-skip-period", layout.skipPeriod);
		JsonParsing::SetIfFound(j, "contour-label-min", layout.min);
		JsonParsing::SetIfFound(j, "contour-label-max", layout.max);
		JsonParsing::SetIfFound(j, "contour-label-phase", layout.phase);
	}
	void from_json(nlohmann::json const& j, ContourLabelPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		from_json(j, paint.text);
	}
	void from_json(nlohmann::json const& j, ContourLabelEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	// Contour line layer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, ContourLineLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, ContourLineLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
	}
	void from_json(nlohmann::json const& j, ContourLinePaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "contour-line-color", paint.color);
		JsonParsing::SetIfFound(j, "contour-line-max", paint.max);
		JsonParsing::SetIfFound(j, "contour-line-min", paint.min);
		JsonParsing::SetIfFound(j, "contour-line-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "contour-line-period", paint.period);
		JsonParsing::SetIfFound(j, "contour-line-units", paint.units);
		JsonParsing::SetIfFound(j, "contour-line-width", paint.width);
	}
	void from_json(nlohmann::json const& j, ContourLineEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
		JsonParsing::SetIfFound(j, "contour-line-fade-range", effect.fadeRange);
	}

	void from_json(nlohmann::json const& j, ElevationLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, ElevationLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "elevation-gradient", layout.gradientMeters);
	}
	void from_json(nlohmann::json const& j, ElevationPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "elevation-mask", paint.maskMeters);
		JsonParsing::SetIfFound(j, "elevation-opacity", paint.opacity);
	}
	void from_json(nlohmann::json const& j, ElevationEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	// FillLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, FillLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, FillLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "fill-sort-key", layout.sortKey);
	}
	void from_json(nlohmann::json const& j, FillPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "fill-antialias", paint.antialias);
		JsonParsing::SetIfFound(j, "fill-color", paint.color);
		JsonParsing::SetIfFound(j, "fill-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "fill-outline-color", paint.outlineColor);
		JsonParsing::SetIfFound(j, "fill-pattern", paint.pattern);
	}
	void from_json(nlohmann::json const& j, FillEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
		JsonParsing::SetIfFound(j, "fill-depth-test", effect.depthTest);
		JsonParsing::SetIfFound(j, "fill-fade-range", effect.fadeRange);
	}

	// HillshadeLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, HillshadeLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, HillshadeLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
	}
	void from_json(nlohmann::json const& j, HillshadePaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "hillshade-altitude", paint.altitude);
		JsonParsing::SetIfFound(j, "hillshade-albedo", paint.albedo);
		JsonParsing::SetIfFound(j, "hillshade-ambient-intensity", paint.ambientIntensity);
		JsonParsing::SetIfFound(j, "hillshade-azimuth", paint.azimuth);
		JsonParsing::SetIfFound(j, "hillshade-exaggeration", paint.exaggeration);
		JsonParsing::SetIfFound(j, "hillshade-opacity", paint.opacity);
	}
	void from_json(nlohmann::json const& j, HillshadeEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	void from_json(nlohmann::json const& j, IntersectLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, IntersectLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "intersect-inverted", layout.inverted);
	}
	void from_json(nlohmann::json const& j, IntersectPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "intersect-elevation-mask", paint.elevationMaskMeters);
		JsonParsing::SetIfFound(j, "intersect-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "intersect-slope-angle-mask", paint.slopeAngleMaskDegrees);
		JsonParsing::SetIfFound(j, "intersect-slope-aspect-mask", paint.slopeAspectMaskDegrees);
		JsonParsing::SetIfFound(j, "intersect-tint", paint.tint);
	}
	void from_json(nlohmann::json const& j, IntersectEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	// LineLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, LineLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, LineLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "line-cap", layout.capType);
		JsonParsing::SetIfFound(j, "line-join", layout.joinType);
		JsonParsing::SetIfFound(j, "line-sort-key", layout.sortKey);
	}
	void from_json(nlohmann::json const& j, LinePaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "line-blur", paint.blur);
		JsonParsing::SetIfFound(j, "line-casing-color", paint.casingColor);
		JsonParsing::SetIfFound(j, "line-casing-opacity", paint.casingOpacity);
		JsonParsing::SetIfFound(j, "line-casing-width", paint.casingWidth);
		JsonParsing::SetIfFound(j, "line-color", paint.color);
		JsonParsing::SetIfFound(j, "line-dasharray", paint.dashArray);
		JsonParsing::SetIfFound(j, "line-gap-width", paint.gapWidth);
		JsonParsing::SetIfFound(j, "line-offset", paint.offset);
		JsonParsing::SetIfFound(j, "line-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "line-pattern", paint.pattern);
		JsonParsing::SetIfFound(j, "line-translate", paint.translate);
		JsonParsing::SetIfFound(j, "line-translate-anchor", paint.translateAnchor);
		JsonParsing::SetIfFound(j, "line-width", paint.width);
	}
	void from_json(nlohmann::json const& j, LineEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
		JsonParsing::SetIfFound(j, "line-depth-test", effect.depthTest);
		JsonParsing::SetIfFound(j, "line-fade-range", effect.fadeRange);
	}

	void from_json(nlohmann::json const& j, RasterLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, RasterLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
	}
	void from_json(nlohmann::json const& j, RasterPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "raster-brightness-max", paint.brightnessMax);
		JsonParsing::SetIfFound(j, "raster-brightness-min", paint.brightnessMin);
		JsonParsing::SetIfFound(j, "raster-contrast", paint.contrast);
		JsonParsing::SetIfFound(j, "raster-hue-rotate", paint.hueRotate);
		JsonParsing::SetIfFound(j, "raster-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "raster-saturation", paint.saturation);
	}
	void from_json(nlohmann::json const& j, RasterEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	void from_json(nlohmann::json const& j, SlopeAngleLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, SlopeAngleLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "slope-angle-gradient", layout.gradientDegrees);
	}
	void from_json(nlohmann::json const& j, SlopeAnglePaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "slope-angle-mask", paint.maskDegrees);
		JsonParsing::SetIfFound(j, "slope-angle-opacity", paint.opacity);
	}
	void from_json(nlohmann::json const& j, SlopeAngleEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	void from_json(nlohmann::json const& j, SlopeAspectLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, SlopeAspectLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "slope-aspect-gradient", layout.gradientDegrees);
	}
	void from_json(nlohmann::json const& j, SlopeAspectPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "slope-aspect-mask", paint.maskDegrees);
		JsonParsing::SetIfFound(j, "slope-aspect-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "slope-aspect-minimum-angle", paint.minimumAngleDegrees);
	}
	void from_json(nlohmann::json const& j, SlopeAspectEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}
	
	void from_json(nlohmann::json const& j, SunlightLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, SunlightLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "sunlight-year", layout.year);
		JsonParsing::SetIfFound(j, "sunlight-month", layout.month);
		JsonParsing::SetIfFound(j, "sunlight-day", layout.day);
		JsonParsing::SetIfFound(j, "sunlight-hour", layout.hour);
	}
	void from_json(nlohmann::json const& j, SunlightPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "sunlight-shadow-strength", paint.shadowStrength);
	}
	void from_json(nlohmann::json const& j, SunlightEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	// SymbolLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, SymbolLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());

		// TODO remove; debug configuration
		layer.elementCap = 10;
	}
	void from_json(nlohmann::json const& j, SymbolLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		from_json(j, layout.text);

		JsonParsing::SetIfFound(j, "symbol-avoid-edges", layout.symbolAvoidEdges);
		JsonParsing::SetIfFound(j, "symbol-placement", layout.symbolPlacement);
		JsonParsing::SetIfFound(j, "symbol-sort-key", layout.sortKey);
		JsonParsing::SetIfFound(j, "symbol-spacing", layout.symbolSpacing);
		JsonParsing::SetIfFound(j, "symbol-z-order", layout.symbolZOrder);

		JsonParsing::SetIfFound(j, "icon-allow-overlap", layout.iconAllowOverlap);
		JsonParsing::SetIfFound(j, "icon-anchor", layout.iconAnchor);
		JsonParsing::SetIfFound(j, "icon-ignore-placement", layout.iconIgnorePlacement);
		JsonParsing::SetIfFound(j, "icon-image", layout.iconImage);
		JsonParsing::SetIfFound(j, "icon-offset", layout.iconOffset);
		JsonParsing::SetIfFound(j, "icon-padding", layout.iconPadding);
		JsonParsing::SetIfFound(j, "icon-pitch-alignment", layout.iconPitchAlignment);
		JsonParsing::SetIfFound(j, "icon-rotate", layout.iconRotDeg);
		JsonParsing::SetIfFound(j, "icon-rotation-alignment", layout.iconRotAlignment);
		JsonParsing::SetIfFound(j, "icon-size", layout.iconSize);
		JsonParsing::SetIfFound(j, "icon-text-fit", layout.iconTextFit);
		JsonParsing::SetIfFound(j, "icon-text-fit-padding", layout.iconTextFitPadding);
	}
	void from_json(nlohmann::json const& j, SymbolPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		from_json(j, paint.text);

		JsonParsing::SetIfFound(j, "icon-color", paint.iconColor);
		JsonParsing::SetIfFound(j, "icon-image-cross-fade", paint.iconImageCrossFade);
		JsonParsing::SetIfFound(j, "icon-opacity", paint.iconOpacity);
		JsonParsing::SetIfFound(j, "icon-translate", paint.iconTranslate);
		JsonParsing::SetIfFound(j, "icon-translate-anchor", paint.iconTranslateAnchor);
	}
	void from_json(nlohmann::json const& j, SymbolEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	void from_json(nlohmann::json const& j, ViewshedLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
		JsonParsing::SetIfFound(j, "effect", *layer.getEffect());
	}
	void from_json(nlohmann::json const& j, ViewshedLayout& layout)
	{
		from_json(j, static_cast<LayoutBase&>(layout));
		JsonParsing::SetIfFound(j, "viewshed-lon", layout.lon);
		JsonParsing::SetIfFound(j, "viewshed-lat", layout.lat);
		JsonParsing::SetIfFound(j, "viewshed-range", layout.rangeMeters);
		JsonParsing::SetIfFound(j, "viewshed-offset", layout.offsetMeters);
		JsonParsing::SetIfFound(j, "viewshed-inverted", layout.inverted);
	}
	void from_json(nlohmann::json const& j, ViewshedPaint& paint)
	{
		from_json(j, static_cast<PaintBase&>(paint));
		JsonParsing::SetIfFound(j, "viewshed-tint", paint.tint);
		JsonParsing::SetIfFound(j, "viewshed-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "viewshed-ring-tint", paint.ringTint);
		JsonParsing::SetIfFound(j, "viewshed-ring-opacity", paint.ringOpacity);
	}
	void from_json(nlohmann::json const& j, ViewshedEffect& effect)
	{
		from_json(j, static_cast<EffectBase&>(effect));
	}

	void from_json(nlohmann::json const& j, TextLayoutComponent& layout)
	{
		JsonParsing::SetIfFound(j, "text-allow-overlap", layout.allowOverlap);
		JsonParsing::SetIfFound(j, "text-anchor", layout.anchor);
		JsonParsing::SetIfFound(j, "text-field", layout.field);
		JsonParsing::SetIfFound(j, "text-font", layout.fontFace);
		JsonParsing::SetIfFound(j, "text-ignore-placement", layout.ignorePlacement);
		JsonParsing::SetIfFound(j, "text-justify", layout.justify);
		JsonParsing::SetIfFound(j, "text-keep-upright", layout.keepUpright);
		JsonParsing::SetIfFound(j, "text-letter-spacing", layout.letterSpacing);
		JsonParsing::SetIfFound(j, "text-line-height", layout.lineHeight);
		JsonParsing::SetIfFound(j, "text-max-angle", layout.maxAngleDegrees);
		JsonParsing::SetIfFound(j, "text-max-width", layout.maxWidth);
		JsonParsing::SetIfFound(j, "text-offset", layout.offset);
		JsonParsing::SetIfFound(j, "text-optional", layout.optional);
		JsonParsing::SetIfFound(j, "text-padding", layout.padding);
		JsonParsing::SetIfFound(j, "text-pitch-alignment", layout.pitchAlignment);
		JsonParsing::SetIfFound(j, "text-radial-offset", layout.radialOffset);
		JsonParsing::SetIfFound(j, "text-rotation-alignment", layout.rotationAlignment);
		JsonParsing::SetIfFound(j, "text-size", layout.size);
		JsonParsing::SetIfFound(j, "text-transform", layout.transform);
		JsonParsing::SetIfFound(j, "text-variable-anchor", layout.variableAnchor);

		JsonParsing::SetIfFound(j, "text-flags", layout.flags);
	}
	void from_json(nlohmann::json const& j, TextPaintComponent& paint)
	{
		JsonParsing::SetIfFound(j, "text-color", paint.color);
		JsonParsing::SetIfFound(j, "text-halo-blur", paint.haloBlur);
		JsonParsing::SetIfFound(j, "text-halo-color", paint.haloColor);
		JsonParsing::SetIfFound(j, "text-halo-width", paint.haloWidth);
		JsonParsing::SetIfFound(j, "text-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "text-translate", paint.translate);
		JsonParsing::SetIfFound(j, "text-translate-anchor", paint.translateAnchor);

		JsonParsing::SetIfFound(j, "text-shadow-color", paint.shadowColor);
		JsonParsing::SetIfFound(j, "text-strikethrough-color", paint.strikethroughColor);
		JsonParsing::SetIfFound(j, "text-overline-color", paint.overlineColor);
		JsonParsing::SetIfFound(j, "text-underline-color", paint.underlineColor);
		JsonParsing::SetIfFound(j, "text-background-color", paint.backgroundColor);
	}

} }
