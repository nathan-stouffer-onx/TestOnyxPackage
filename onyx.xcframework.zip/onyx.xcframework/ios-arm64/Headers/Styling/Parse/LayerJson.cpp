#include "LayerJson.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/ExpressionJson.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Layer& layer)
	{
		JsonParsing::Require(j, "id", layer.id, "Layer is missing required key 'id'");
		JsonParsing::Require(j, "type", layer.type, "Layer is missing required key 'type'");
		JsonParsing::SetIfFound(j, "maxzoom", layer.maxZoom);
		JsonParsing::SetIfFound(j, "minzoom", layer.minZoom);
		JsonParsing::SetIfFound(j, "filter", layer.filter);
	}
	void from_json(nlohmann::json const& j, SourcedLayer& layer)
	{
		from_json(j, static_cast<Layer&>(layer));
		JsonParsing::Require(j, "source", layer.source, "SourcedLayer is missing required key 'source'");
		JsonParsing::SetIfFound(j, "source-layer", layer.sourceLayer);
	}

	void from_json(nlohmann::json const& j, Layer::Type& type)
	{
		type = std::fromStringView<Layer::Type>(std::string(j));
	}
	void from_json(nlohmann::json const& j, LayoutBase::Visibility& visibility)
	{
		visibility = std::fromStringView<LayoutBase::Visibility>(std::string(j));
	}

	void from_json(nlohmann::json const& j, BackgroundLayer& layer)
	{
		from_json(j, static_cast<Layer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
	}

	void from_json(nlohmann::json const& j, BackgroundLayout& layout)
	{
		JsonParsing::SetIfFound(j, "base", layout.base);
		JsonParsing::SetIfFound(j, "visibility", layout.visibility);
	}
	void from_json(nlohmann::json const& j, BackgroundPaint& paint)
	{
		JsonParsing::SetIfFound(j, "base", paint.base);
		if (!paint.base.empty())
		{
			paint.color = nullptr;
			paint.opacity = nullptr;
		}

		JsonParsing::SetIfFound(j, "background-color", paint.color);
		JsonParsing::SetIfFound(j, "background-opacity", paint.opacity);
	}

	void from_json(nlohmann::json const& j, RasterLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
	}

	void from_json(nlohmann::json const& j, RasterLayout& layout)
	{
		JsonParsing::SetIfFound(j, "base", layout.base);
		JsonParsing::SetIfFound(j, "visibility", layout.visibility);
	}
	void from_json(nlohmann::json const& j, RasterPaint& paint)
	{
		JsonParsing::SetIfFound(j, "base", paint.base);
		if (!paint.base.empty())
		{
			paint.opacity = nullptr;
		}

		JsonParsing::SetIfFound(j, "raster-opacity", paint.opacity);
	}

	// LineLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, LineLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));

		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint", *layer.getPaint());
	}
	void from_json(nlohmann::json const& j, LineLayout& layout)
	{
		JsonParsing::SetIfFound(j, "base", layout.base);
		if (!layout.base.empty())
		{
			layout.capType = nullptr;
			layout.joinType = nullptr;
		}
		JsonParsing::SetIfFound(j, "visibility", layout.visibility);
		JsonParsing::SetIfFound(j, "line-cap", layout.capType);
		JsonParsing::SetIfFound(j, "line-join", layout.joinType);
	}
	void from_json(nlohmann::json const& j, LinePaint& paint)
	{
		JsonParsing::SetIfFound(j, "base", paint.base);
		if (!paint.base.empty())
		{
			paint.color = nullptr;
			paint.opacity = nullptr;
			paint.width = nullptr;
			paint.dashArray = nullptr;
		}
		JsonParsing::SetIfFound(j, "line-color", paint.color);
		JsonParsing::SetIfFound(j, "line-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "line-width", paint.width);
		JsonParsing::SetIfFound(j, "line-dasharray", paint.dashArray);
	}

	// Text layer/paint serialization
	// ------------------------------------------
	template<typename T>
	void readTextLayout(nlohmann::json const& j, T& layout)
	{
		JsonParsing::SetIfFound(j, "base", layout.base);
		if (!layout.base.empty())
		{
			layout.textField = nullptr;
			layout.textSize = nullptr;
			layout.symbolPlacement = nullptr;
			layout.textPlacement = nullptr;
			layout.letterSpacing = nullptr;
			layout.textStyleFlags = nullptr;
		}

		JsonParsing::SetIfFound(j, "text-field", layout.textField);
		JsonParsing::SetIfFound(j, "text-size", layout.textSize);
		JsonParsing::SetIfFound(j, "text-font", layout.fontFace);
		JsonParsing::SetIfFound(j, "symbol-placement", layout.symbolPlacement);
		JsonParsing::SetIfFound(j, "text-placement", layout.textPlacement);
		JsonParsing::SetIfFound(j, "text-letter-spacing", layout.letterSpacing);
		JsonParsing::SetIfFound(j, "text-style", layout.textStyleFlags);
	}

	template<typename T>
	void readTextPaint(nlohmann::json const& j, T& paint)
	{
		JsonParsing::SetIfFound(j, "base", paint.base);
		if (!paint.base.empty())
		{
			paint.color = nullptr;
			paint.shadowColor = nullptr;
			paint.outlineColor = nullptr;
			paint.strikethroughColor = nullptr;
			paint.overlineColor = nullptr;
			paint.underlineColor = nullptr;
			paint.backgroundColor = nullptr;
		}

		JsonParsing::SetIfFound(j, "text-color", paint.color);
		JsonParsing::SetIfFound(j, "text-halo-color", paint.outlineColor);
		JsonParsing::SetIfFound(j, "text-shadow-color", paint.shadowColor);
		JsonParsing::SetIfFound(j, "text-strikethrough-color", paint.strikethroughColor);
		JsonParsing::SetIfFound(j, "text-overline-color", paint.overlineColor);
		JsonParsing::SetIfFound(j, "text-underline-color", paint.underlineColor);
		JsonParsing::SetIfFound(j, "text-background-color", paint.backgroundColor);

	}
	
	// SymbolLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, SymbolLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());

		// TODO remove; debug configuration
		layer.elementCap = 10;
	}
	void from_json(nlohmann::json const& j, SymbolLayout& layout)
	{
		readTextLayout(j, layout);
		if (!layout.base.empty())
		{
			layout.iconAnchor = nullptr;
			layout.iconPitchAlignment = nullptr;
			layout.iconTextFit = nullptr;
			layout.symbolZOrder = nullptr;
		}
		JsonParsing::SetIfFound(j, "icon-image", layout.iconImage);
		// TODO (scott) wire up vector parsing
//		JsonParsing::SetIfFound(j, "icon-offset", layout.iconOffset);
		JsonParsing::SetIfFound(j, "icon-size", layout.iconSize);
		JsonParsing::SetIfFound(j, "icon-anchor", layout.iconAnchor);
		JsonParsing::SetIfFound(j, "icon-pitch-alignment", layout.iconPitchAlignment);
		JsonParsing::SetIfFound(j, "icon-text-fit", layout.iconTextFit);
		JsonParsing::SetIfFound(j, "symbol-z-order", layout.symbolZOrder);
	}
	void from_json(nlohmann::json const& j, SymbolPaint& paint)
	{
		readTextPaint(j, paint);
	}

	// Height contour layer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, IntervalLayout& layout)
	{
		readTextLayout(j, layout);
		if (!layout.base.empty())
		{
			JsonParsing::SetIfFound(j, "interval", layout.interval);
		}
		else
		{
			JsonParsing::Require(j, "interval", layout.interval, "`interval` must be required for contour layer interval layouts");
		}
	}

	void from_json(nlohmann::json const& j, ContourLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());

		JsonParsing::SetIfFound(j, "elementCap", layer.elementCap);
	}
	void from_json(nlohmann::json const& j, ContourLayout& layout)
	{
		readTextLayout(j, layout);
		if (!layout.base.empty())
		{
			layout.showTileInfo = nullptr;
			JsonParsing::SetIfFound(j, "intervalLayouts", layout.intervalLayouts);
		}
		else
		{
			JsonParsing::Require(j, "intervalLayouts", layout.intervalLayouts, "'intervalLayouts' must be specified for Contour layer layouts");
		}
		JsonParsing::SetIfFound(j, "showTileInfo", layout.showTileInfo);
	}
	void from_json(nlohmann::json const& j, ContourPaint& paint)
	{
		readTextPaint(j, paint);
		if (paint.base.empty())
		{
			JsonParsing::Require(j, "intervalPaints", paint.intervalPaints, "'intervalPaints' must be specified for Contour layers");
		}
		else
		{
			JsonParsing::SetIfFound(j, "intervalPaints", paint.intervalPaints);
		}
	}

	// FillLayer and related json parsing
	// ------------------------------------------
	void from_json(nlohmann::json const& j, FillLayer& layer)
	{
		from_json(j, static_cast<SourcedLayer&>(layer));
		JsonParsing::SetIfFound(j, "layout", *layer.getLayout());
		JsonParsing::SetIfFound(j, "paint",  *layer.getPaint());
	}

	void from_json(nlohmann::json const& j, FillLayout& layout)
	{
		JsonParsing::SetIfFound(j, "base", layout.base);
		JsonParsing::SetIfFound(j, "visibility", layout.visibility);
	}
	void from_json(nlohmann::json const& j, FillPaint& paint)
	{
		JsonParsing::SetIfFound(j, "base", paint.base);
		if (!paint.base.empty())
		{
			paint.color = nullptr;
			paint.opacity = nullptr;
			paint.pattern = nullptr;
		}
		JsonParsing::SetIfFound(j, "fill-color", paint.color);
		JsonParsing::SetIfFound(j, "fill-opacity", paint.opacity);
		JsonParsing::SetIfFound(j, "fill-pattern", paint.pattern);
	}

} }
