#ifndef __STYLING_SOURCE_JSON_PARSING_H__
#define __STYLING_SOURCE_JSON_PARSING_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Sources/Source.h"
#include "Styling/Sources/GeojsonSource.h"
#include "Styling/Sources/PromoteId.h"
#include "Styling/Sources/TiledSources/TiledSource.h"
#include "Styling/Sources/TiledSources/RasterSource.h"
#include "Styling/Sources/TiledSources/RasterDemSource.h"
#include "Styling/Sources/TiledSources/VectorSource.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Source& src);

	void from_json(nlohmann::json const& j, Source::Types& type);

	void from_json(nlohmann::json const& j, Source::Bounds& bounds);

	void from_json(nlohmann::json const& j, PromoteId& id);

	void from_json(nlohmann::json const& j, GeojsonSource& src);

	void from_json(nlohmann::json const& j, TiledSource& src);

	void from_json(nlohmann::json const& j, TiledSource::Scheme& scheme);

	// deviates from from_json to avoid function naming issues with ShaderLib. this from json parses differently
	// TODO possibly consolidate these functions along with lucids from json functions
	void from_stylesheet_json(nlohmann::json const& j, lgal::world::AABB2d& box);

	void from_json(nlohmann::json const& j, std::vector<TileUrlPattern>& patterns);

	void from_json(nlohmann::json const& j, RasterSource& src);

	void from_json(nlohmann::json const& j, RasterDemSource& src);

	void from_json(nlohmann::json const& j, RasterDemSource::Encoding& encoding);

	void from_json(nlohmann::json const& j, VectorSource& src);

} }

#endif