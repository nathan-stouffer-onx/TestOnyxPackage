#ifndef __STYLING_SOURCE_JSON_PARSING_H__
#define __STYLING_SOURCE_JSON_PARSING_H__

#include <3rdParty/nlohmann/json.hpp>

#include "../Sources/Source.h"
#include "../Sources/GeojsonSource.h"
#include "../Sources/TiledSources/TiledSource.h"
#include "../Sources/TiledSources/RasterSource.h"
#include "../Sources/TiledSources/RasterDemSource.h"
#include "../Sources/TiledSources/VectorSource.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Source& src);

	void from_json(nlohmann::json const& j, Source::Type& type);

	void from_json(nlohmann::json const& j, GeojsonSource& src);

	void from_json(nlohmann::json const& j, TiledSource& src);

	void from_json(nlohmann::json const& j, TiledSource::Scheme& scheme);

	// deviates from to/from_json to avoid function naming issues with ShaderLib. this to/from json serializes differently
	// TODO possibly consolidate these functions along with lucids to/from json functions
	void from_stylesheet_json(nlohmann::json const& j, lgal::world::AABB2d& box);
	void from_stylesheet_json(std::string const& j, lgal::world::AABB2d& box);

	void from_json(nlohmann::json const& j, std::vector<TileUrlPattern>& patterns);

	void from_json(nlohmann::json const& j, RasterSource& src);

	void from_json(nlohmann::json const& j, RasterDemSource& src);

	void from_json(nlohmann::json const& j, RasterDemSource::Encoding& encoding);

	void from_json(nlohmann::json const& j, VectorSource& src);

} }

#endif