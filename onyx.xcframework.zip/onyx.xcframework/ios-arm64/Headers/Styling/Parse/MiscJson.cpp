#include "MiscJson.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/ExpressionJson.h"

namespace onyx::Styling
{

	void from_json(nlohmann::json const& j, Fog& fog)
	{
		JsonParsing::SetIfFound(j, "color", fog.color);
		JsonParsing::SetIfFound(j, "range", fog.range);
	}

	void from_json(nlohmann::json const& j, Skydome& skydome)
	{
		JsonParsing::SetIfFound(j, "sky-color", skydome.skyColor);
		JsonParsing::SetIfFound(j, "haze-color", skydome.hazeColor);
		JsonParsing::SetIfFound(j, "alpha", skydome.alpha);
		JsonParsing::SetIfFound(j, "band-pow", skydome.bandPow);
	}

	void from_json(nlohmann::json const& j, Terrain& terrain)
	{
		JsonParsing::Require(j, "source", terrain.source, "Terrain failed to have source property");
		JsonParsing::SetIfFound(j, "exaggeration", terrain.exaggeration);
	}

	void from_json(nlohmann::json const& j, Spritesheet& sprite)
	{
		// For each top level object in j
		for (auto const& iter : j.items())
		{
			SpriteIndex idx;
			auto const& idxJson = iter.value();

			// Parse the sprite idx object
			idx.name = iter.key();
			uint32_t width, height, x, y;
			JsonParsing::Require(idxJson, "width", width, "Sprite idx missing width");
			JsonParsing::Require(idxJson, "height", height, "Sprite idx missing height");
			idx.sizePx = { gpu_float_t(width), gpu_float_t(height) };
			JsonParsing::Require(idxJson, "x", x, "Sprite idx missing x");
			JsonParsing::Require(idxJson, "y", y, "Sprite idx missing y");
			idx.loc = lgal::screen::Vector2(x, y);
			JsonParsing::Require(idxJson, "pixelRatio", idx.pixelRatio, "Sprite idx missing pixelRatio");
			idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
			idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };

			if (idxJson.contains("content"))
			{
				auto const& intArr = idxJson["content"];
				ONYX_ASSERT(intArr.size() == 4, "content should be array of 4 ints");
				idx.content = {
					lgal::array::Vector2{ uint32_t(intArr[0]), uint32_t(intArr[1]) },
					lgal::array::Vector2{ uint32_t(intArr[2]), uint32_t(intArr[3]) }
				};
			}
			else
			{
				idx.content = { { 0, 0 }, { width, height } };
			}

			if (idxJson.contains("stretchX"))
			{
				std::vector<lgal::array::Vector2> stretchX;
				stretchX.reserve(2);
				for (auto const& xIter : idxJson["stretchX"].items())
				{
					auto const& intArr = xIter.value();
					ONYX_ASSERT(intArr.size() == 2, "Size of items in stretchX array should be 2");
					stretchX.push_back({ uint32_t(intArr[0]), uint32_t(intArr[1]) });
				}

				switch (stretchX.size())
				{
					case 1: // 9-patch
						{
							auto const& first = stretchX.front();
							idx.offsets1.x = gpu_float_t(first.x);
							idx.offsets1.y = gpu_float_t(first.x);
							idx.offsets1.z = gpu_float_t(first.x);
							idx.offsets1.w = gpu_float_t(first.y);
							break;
						}
					case 2: // 15-patch
						{
							auto const& first = stretchX.front();
							auto const& last = stretchX.back();
							idx.offsets1.x = gpu_float_t(first.x);
							idx.offsets1.y = gpu_float_t(first.y);
							idx.offsets1.z = gpu_float_t(last.x);
							idx.offsets1.w = gpu_float_t(last.y);
							break;
						}
					default:
						ONYX_THROW("sprite stretchX can only have 0, 1, or 2 stretch regions");
				}
			}

			if (idxJson.contains("stretchY"))
			{
				std::vector<lgal::array::Vector2> stretchY;
				stretchY.reserve(2);
				for (auto const& yIter : idxJson["stretchY"].items())
				{
					auto const& intArr = yIter.value();
					ONYX_ASSERT(intArr.size() == 2, "Size of items in stretchY array should be 2");
					stretchY.push_back({ intArr[0], intArr[1] });
				}

				switch (stretchY.size())
				{
					case 1: // 9-patch
					{
						auto const& first = stretchY.front();
						idx.offsets2.y = gpu_float_t(first.x);
						idx.offsets2.z = gpu_float_t(first.y);
						break;
					}
					default:
						ONYX_THROW("sprite stretchY can only have 0 or 1 stretch regions");
				}
			}

			sprite.indices.emplace(idx.name, idx);
		}
	}

}

namespace onyx::Styling::Expressions::Format
{

	void from_json(nlohmann::json const& j, AmorphousFormatted::Options& options)
	{
		JsonParsing::SetIfFound(j, "font-scale", options.fontScale);
		JsonParsing::SetIfFound(j, "text-font", options.font);
		JsonParsing::SetIfFound(j, "text-color", options.color);
	}

}