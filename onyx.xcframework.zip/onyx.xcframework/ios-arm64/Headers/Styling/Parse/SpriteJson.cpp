#include "SpriteJson.h"

#include <System/Map3DException.h>
#include <json/jsonParsing.h>

namespace onyx {
namespace Styling {

void from_json(nlohmann::json const& j, Sprite& sprite)
{
	// For each top level object in j
	for (auto const& iter : j.items())
	{
		SpriteIndex idx;
		auto const& idxJson = iter.value();

		// Parse the sprite idx object
		idx.name = iter.key();
		JsonParsing::Require(idxJson, "width", idx.width, "Sprite idx missing width");
		JsonParsing::Require(idxJson, "height", idx.height, "Sprite idx missing height");
		JsonParsing::Require(idxJson, "x", idx.x, "Sprite idx missing x");
		JsonParsing::Require(idxJson, "y", idx.y, "Sprite idx missing y");
		JsonParsing::Require(idxJson, "pixelRatio", idx.pixelRatio, "Sprite idx missing pixelRatio");

		if (idxJson.contains("content"))
		{
			auto const& intArr = idxJson["content"];
			MAP3D_ASSERT(intArr.size() == 4, "content should be array of 4 ints");
			idx.content = {
				lgal::array::Vector2{ uint32_t(intArr[0]), uint32_t(intArr[1]) },
				lgal::array::Vector2{ uint32_t(intArr[2]), uint32_t(intArr[3]) }
			};
		}

		if (idxJson.contains("stretchX"))
		{
			for (auto const& xIter : idxJson["stretchX"].items())
			{
				auto const& intArr = xIter.value();
				MAP3D_ASSERT(intArr.size() == 2, "Size of items in stretchX array should be 2")
				idx.stretchX.push_back({ uint32_t(intArr[0]), uint32_t(intArr[1]) });
			}
		}

		if (idxJson.contains("stretchY"))
		{
			for (auto const& yIter : idxJson["stretchY"].items())
			{
				auto const& intArr = yIter.value();
				MAP3D_ASSERT(intArr.size() == 2, "Size of items in stretchY array should be 2")
				idx.stretchY.push_back({ intArr[0], intArr[1] });
			}
		}

		sprite.indices.push_back(idx);
	}
}

} }

