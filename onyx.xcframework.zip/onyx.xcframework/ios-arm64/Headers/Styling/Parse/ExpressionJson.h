#ifndef __STYLING_EXPRESSION_JSON_PARSING_H__
#define __STYLING_EXPRESSION_JSON_PARSING_H__

#include <vector>

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Expressions/EnumExpressions.h"
#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
	
	void from_json(nlohmann::json const& j, BooleanT::Ptr      & expr);
	void from_json(nlohmann::json const& j, ColorT::Ptr        & expr);
	void from_json(nlohmann::json const& j, FormattedT::Ptr    & expr);
	void from_json(nlohmann::json const& j, NumberT::Ptr       & expr);
	void from_json(nlohmann::json const& j, RangeT::Ptr        & expr);
	void from_json(nlohmann::json const& j, ResolvedImageT::Ptr& expr);
	void from_json(nlohmann::json const& j, StringT::Ptr       & expr);
	void from_json(nlohmann::json const& j, GradientT::Ptr     & expr);

	template<typename OutputEnumT>
	void from_json(nlohmann::json const& j, ExpressionPtr<OutputEnumT>& expr)
	{
		StringT::Ptr str = nullptr;
		from_json(j, str);
		if (str)
		{
			expr = std::make_unique<Enum::Dynamic<OutputEnumT> const>(std::move(str));
		}
	}

	void from_json(nlohmann::json const& j, BooleanArrayT::Ptr& expr);
	void from_json(nlohmann::json const& j, ColorArrayT::Ptr  & expr);
	void from_json(nlohmann::json const& j, NumberArrayT::Ptr & expr);
	void from_json(nlohmann::json const& j, RangeArrayT::Ptr  & expr);
	void from_json(nlohmann::json const& j, StringArrayT::Ptr & expr);

	template<typename OutputEnumT>
	void from_json(nlohmann::json const& j, ExpressionPtr<std::vector<OutputEnumT>>& expr)
	{
		StringArrayT::Ptr str = nullptr;
		from_json(j, str);
		if (str)
		{
			expr = std::make_unique<Array::DynamicEnum<OutputEnumT> const>(std::move(str));
		}
	}

} } }

#endif