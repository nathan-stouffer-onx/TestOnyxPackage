#ifndef __SPRITE_JSON_H__
#define __SPRITE_JSON_H__

#include <3rdParty/nlohmann/json.hpp>

#include "../Sprite.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Sprite& sprite);

} }

#endif
