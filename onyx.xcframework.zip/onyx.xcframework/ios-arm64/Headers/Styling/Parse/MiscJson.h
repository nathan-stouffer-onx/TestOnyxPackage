#ifndef __STYLING_MISC_JSON_H__
#define __STYLING_MISC_JSON_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Spritesheet.h"
#include "Styling/Terrain.h"
#include "Styling/Expressions/FormatExpressions.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Terrain& terrain);
	
	void from_json(nlohmann::json const& j, Spritesheet& sprite);

} }

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Format {

	void from_json(nlohmann::json const& j, AmorphousFormatted::Options& options);

} } } }

#endif