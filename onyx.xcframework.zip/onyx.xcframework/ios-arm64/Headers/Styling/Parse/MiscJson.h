#pragma once

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Layers/Fog.h"
#include "Styling/Layers/Skydome.h"
#include "Styling/Spritesheet.h"
#include "Styling/Terrain.h"
#include "Styling/Expressions/FormatExpressions.h"

namespace onyx::Styling
{

	void from_json(nlohmann::json const& j, Fog& fog);

	void from_json(nlohmann::json const& j, Skydome& skydome);

	void from_json(nlohmann::json const& j, Terrain& terrain);
	
	void from_json(nlohmann::json const& j, Spritesheet& sprite);

}

namespace onyx::Styling::Expressions::Format
{

	void from_json(nlohmann::json const& j, AmorphousFormatted::Options& options);

}