#include "ExpressionJson.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {

	void from_json(nlohmann::json const& j, BooleanT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::boolean(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, ColorT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::color(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, FormattedT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::format(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, NumberT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::number(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, RangeT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::range(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, ResolvedImageT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::image(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, StringT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::string(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, GradientT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::gradient(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, BooleanArrayT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::booleans(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, ColorArrayT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::colors(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, NumberArrayT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::numbers(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}
	
	void from_json(nlohmann::json const& j, RangeArrayT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::ranges(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

	void from_json(nlohmann::json const& j, StringArrayT::Ptr& expr)
	{
		auto constructed = Expressions::Factory::strings(j);
		if (constructed)
		{
			expr = std::move(constructed);
		}
	}

} } }