#pragma once

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Style.h"

namespace lucid::gigl
{

	void from_json(nlohmann::json const& j, onyx::Styling::Expressions::ExpressionContext& expressions);

	void from_json(nlohmann::json const& j, onyx::Styling::LayoutContext& layouts);
	void from_json(nlohmann::json const& j, onyx::Styling::PaintContext& paints);
	void from_json(nlohmann::json const& j, onyx::Styling::EffectContext& effects);

}

namespace onyx::Styling
{

	void from_json(nlohmann::json const& j, Expressions::ExpressionContext& expressions);

	void from_json(nlohmann::json const& j, LayoutContext& layouts);
	void from_json(nlohmann::json const& j, PaintContext& paints);
	void from_json(nlohmann::json const& j, EffectContext& effects);

	void from_json(nlohmann::json const& j, Style& style);

}