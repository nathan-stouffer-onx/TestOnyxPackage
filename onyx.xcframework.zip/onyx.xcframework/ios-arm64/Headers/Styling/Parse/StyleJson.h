#ifndef __STYLING_STYLE_JSON_PARSING_H__
#define __STYLING_STYLE_JSON_PARSING_H__

#include <3rdParty/nlohmann/json.hpp>

#include "../Style.h"

namespace onyx {
namespace Styling {

	void load_context(nlohmann::json const& j, Style &style);
	void from_json(nlohmann::json const& j, Style& style);

} }

#endif