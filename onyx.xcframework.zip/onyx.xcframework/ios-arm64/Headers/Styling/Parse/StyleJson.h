#ifndef __STYLING_STYLE_JSON_PARSING_H__
#define __STYLING_STYLE_JSON_PARSING_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Style.h"

namespace lucid {
namespace gigl {

	void from_json(nlohmann::json const& j, onyx::Styling::Expressions::ExpressionContext& expressions);

	void from_json(nlohmann::json const& j, onyx::Styling::LayoutContext& layouts);
	void from_json(nlohmann::json const& j, onyx::Styling::PaintContext& paints);

} }

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Expressions::ExpressionContext& expressions);

	void from_json(nlohmann::json const& j, LayoutContext& layouts);
	void from_json(nlohmann::json const& j, PaintContext& paints);

	void from_json(nlohmann::json const& j, Style& style);

} }

#endif