#ifndef __STYLING_TERRAIN_JSON_H__
#define __STYLING_TERRAIN_JSON_H__

#include <3rdParty/nlohmann/json.hpp>

#include "../Terrain.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Terrain& terrain);

} }

#endif