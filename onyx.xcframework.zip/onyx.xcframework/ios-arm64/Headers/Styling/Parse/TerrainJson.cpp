#include "TerrainJson.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/ExpressionJson.h"

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Terrain& terrain)
	{
		JsonParsing::Require(j, "source", terrain.source, "Terrain failed to have source property");
		JsonParsing::SetIfFound(j, "exaggeration", terrain.exaggeration);
	}

} }