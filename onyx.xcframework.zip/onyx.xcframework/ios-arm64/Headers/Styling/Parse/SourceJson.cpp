#include "SourceJson.h"

#include <limits>

#include <json/jsonParsing.h>

namespace onyx {
namespace Styling {

	void from_json(nlohmann::json const& j, Source& src)
	{
		JsonParsing::Require(j, "type", src.type, "Source is missing required key 'type'");
		JsonParsing::SetIfFound(j, "maxzoom", src.maxZoom);
		JsonParsing::SetIfFound(j, "minzoom", src.minZoom);
		JsonParsing::SetIfFound(j, "bounds", src.bounds);
		JsonParsing::SetIfFound(j, "internal", src.internal);
		JsonParsing::SetIfFound(j, "expirationMS", src.expirationMS);
	}

	void from_json(nlohmann::json const& j, Source::Types& type)
	{
		type = std::fromStringView<Source::Types>(std::string(j));
	}

	void from_json(nlohmann::json const& j, Source::Bounds& bounds)
	{
		std::vector<lgal::world::AABB2d> boxes;
		nlohmann::json::array_t arr = j;
		if (arr[0].is_array())
		{
			boxes.resize(arr.size());
			for (size_t i = 0; i < arr.size(); ++i)
			{
				from_stylesheet_json(arr[i], boxes[i]);
			}
		}
		else
		{
			boxes.resize(1);
			from_stylesheet_json(arr, boxes.front());
		}
		bounds = Source::Bounds{ boxes };
	}

	void from_json(nlohmann::json const& j, PromoteId& id)
	{
		if (j.is_string())
		{
			id = PromoteId(std::string(j));
		}
		else if (j.is_object())
		{
			std::unordered_map<std::string, std::string> ids;
			for (auto const& [key, value] : j.items())
			{
				ids.insert({ key, value });
			}
			id = PromoteId(ids);
		}
	}

	void from_json(nlohmann::json const& j, GeojsonSource& src)
	{
		from_json(j, static_cast<Source&>(src));
		JsonParsing::Require(j, "data", "GeojsonSource is missing required key 'data'");
		src.data = GeoJson::Parse(j["data"]);
		JsonParsing::SetIfFound(j, "promoteId", src.promoteId);
	}

	void from_json(nlohmann::json const& j, TiledSource& src)
	{
		from_json(j, static_cast<Source&>(src));
		JsonParsing::Require(j, "tiles", src.tiles, "TiledSource is missing required key 'tiles'");
		JsonParsing::SetIfFound(j, "scheme", src.scheme);
		JsonParsing::SetIfFound(j, "volatile", src.cache);
	}

	void from_json(nlohmann::json const& j, TiledSource::Scheme& scheme)
	{
		scheme = std::fromStringView<TiledSource::Scheme>(std::string(j));
	}

	void from_stylesheet_json(nlohmann::json const& j, lgal::world::AABB2d& box)
	{
		box.min = { j[0], j[1] };
		box.max = { j[2], j[3] };
	}

	void from_json(nlohmann::json const& j, std::vector<TileUrlPattern>& patterns)
	{
		patterns.clear();
		for (auto const& url : j)
		{
			patterns.push_back(TileUrlPattern(url));
		}
	}

	void from_json(nlohmann::json const& j, RasterSource& src)
	{
		from_json(j, static_cast<TiledSource&>(src));
		JsonParsing::SetIfFound(j, "tileSize", src.tileSize);
	}

	void from_json(nlohmann::json const& j, RasterDemSource& src)
	{
		from_json(j, static_cast<RasterSource&>(src));
		JsonParsing::Require(j, "encoding", src.encoding, "DEM source is missing required key 'encoding'");
	}

	void from_json(nlohmann::json const& j, RasterDemSource::Encoding& encoding)
	{
		encoding = std::fromStringView<RasterDemSource::Encoding>(std::string(j));
	}

	void from_json(nlohmann::json const& j, VectorSource& src)
	{
		from_json(j, static_cast<TiledSource&>(src));
		JsonParsing::SetIfFound(j, "promoteId", src.promoteId);
	}

} }