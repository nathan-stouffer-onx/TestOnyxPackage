#include "ColorExpressionFactory.h"

#include <System/Map3DException.h>

#include "Styling/Parse/Factory/ExpressionFactory.h"
#include "Styling/Parse/Factory/InterpolationFactory.h"
#include "Styling/Parse/Factory/ContextFactory.h"
#include "Styling/Parse/Factory/MatcherFactory.h"
#include "Styling/Parse/ColorString.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Color {
namespace Factory {

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<lgal::Color>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.is_string(), "Constant Color expression must be a string");
		std::string str = j;
		lgal::Color color = Parse::color(str);
		return std::make_unique<Constant const>(color);
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Get must have 2 elements");
		MAP3D_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		MAP3D_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		return std::make_unique<Get const>(str);
	}

	std::unique_ptr<Interpolate const> interpolate(nlohmann::json const& j)
	{
		return Interpolation::Factory::interpolate<lgal::Color>(j);
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<lgal::Color>(j);
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<lgal::Color>(j);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<lgal::Color> const> matcher = Decision::Factory::matcher<lgal::Color>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

} } } } }
