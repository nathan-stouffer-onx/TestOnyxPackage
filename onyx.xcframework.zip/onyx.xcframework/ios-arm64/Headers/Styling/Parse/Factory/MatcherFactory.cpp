#include "MatcherFactory.h"

#include <System/Map3DException.h>

#include "Styling/Parse/Factory/ExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Decision {
namespace Factory {

	InputType type(nlohmann::json const& j)
	{
		// determine label type
		nlohmann::json const& label = j[2];
		if (label.is_number())
		{
			return InputType::NUMBER;
		}
		else if (label.is_string())
		{
			return InputType::STRING;
		}
		else if (label.is_array())
		{
			nlohmann::json const& first = label[0];
			if (first.is_number())
			{
				return InputType::NUMBER;
			}
			else if (first.is_string())
			{
				return InputType::STRING;
			}
		}

		MAP3D_THROW("invalid label specified");
		return InputType::UNKNOWN;
	}

} } } } }