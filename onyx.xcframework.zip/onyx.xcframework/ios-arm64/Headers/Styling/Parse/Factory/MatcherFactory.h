#ifndef __STYLING_MATCHER_FACTORY_H__
#define __STYLING_MATCHER_FACTORY_H__

#include <memory>
#include <vector>

#include <3rdParty/nlohmann/json.hpp>
#include <System/Map3DException.h>

#include "Styling/Expressions/DecisionExpressions.h"
#include "Styling/Parse/Factory/ExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Decision {
namespace Factory {

	template<typename OutputT>
	inline std::unique_ptr<Case<OutputT> const> cases(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "case", "First value in an Case expression must be 'case'");
		MAP3D_ASSERT(j.size() >= 2, "Case expression does not have enough arguments");
		MAP3D_ASSERT(j.size() % 2 == 0, "Case expression must have an even number of elements");

		std::vector<typename Case<OutputT>::Pair> pairs;
		pairs.reserve(j.size() - 2);
		for (size_t i = 1; i + 1 < j.size(); i += 2)
		{
			pairs.push_back({ Expressions::Factory::boolean(j[i]), Expressions::Factory::expr<OutputT>(j[i + 1]) });
		}

		return std::make_unique<Case<OutputT> const>(std::move(pairs), Expressions::Factory::expr<OutputT>(j.back()));
	}

	enum class InputType
	{
		UNKNOWN,
		NUMBER,
		STRING
	};

	InputType type(nlohmann::json const& j);

	template<typename T>
	inline std::vector<T> arr(nlohmann::json const& j)
	{
		if (j.is_array())
		{
			return j;
		}
		else
		{
			return std::vector<T>{ j };
		}
	}

	template<typename InputT, typename OutputT>
	std::unique_ptr<Matcher<OutputT> const> specializedMatcher(nlohmann::json const& j)
	{
		std::vector<typename Decision::DerivedMatcher<InputT, OutputT>::Pair> pairs;
		pairs.reserve(j.size() - 3);
		for (size_t i = 2; i + 1 < j.size(); i += 2)
		{
			std::vector<InputT> labels = arr<InputT>(j[i]);
			ExpressionPtr<OutputT> output = Expressions::Factory::expr<OutputT>(j[i + 1]);
			pairs.push_back({ labels, std::move(output) });
		}

		ExpressionPtr<OutputT> fallback = Expressions::Factory::expr<OutputT>(j.back());
		return std::make_unique<Decision::DerivedMatcher<InputT, OutputT>>(Expressions::Factory::expr<InputT>(j[1]), std::move(pairs), std::move(fallback));
	}

	template<typename OutputT>
	std::unique_ptr<Matcher<OutputT> const> matcher(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "match", "First value in an Match expression must be 'match'");
		MAP3D_ASSERT(j.size() >= 5, "Match expression does not have enough arguments");
		MAP3D_ASSERT(j.size() % 2 == 1, "Match expression must have an odd number of elements");

		Decision::Factory::InputType type = Decision::Factory::type(j);
		switch (type)
		{
			case InputType::NUMBER: return specializedMatcher<float,       OutputT>(j); break;
			case InputType::STRING: return specializedMatcher<std::string, OutputT>(j); break;
			case InputType::UNKNOWN: // fall-through to default
			default:
				MAP3D_THROW("Unkown matcher input type");
				return nullptr;
		}
	}

} } } } }

#endif