#include "BooleanExpressionFactory.h"

#include <System/Map3DException.h>

#include "Styling/Parse/Factory/ExpressionFactory.h"
#include "Styling/Parse/Factory/InterpolationFactory.h"
#include "Styling/Parse/Factory/MatcherFactory.h"
#include "ContextFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {
namespace Factory {

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<bool>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.is_boolean(), "Constant Boolean expression must be a boolean");
		bool value = j;
		return std::make_unique<Constant const>(value);
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Get must have 2 elements");
		MAP3D_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		MAP3D_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		return std::make_unique<Get const>(str);
	}

	std::unique_ptr<Has const> has(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Get must have 2 elements");
		MAP3D_ASSERT(j[0] == "has", "First element of Has expression must be 'has'");
		MAP3D_ASSERT(j[1].is_string(), "Second element of Has expression must be a string");
		std::string const& str = j[1];
		return std::make_unique<Has const>(str);
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<bool>(j);
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<bool>(j);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<bool> const> matcher = Decision::Factory::matcher<bool>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<All const> all(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "all", "First value in a All expression must be 'all'");

		std::vector<BooleanT::Ptr> expressions;
		for (size_t i = 1; i < j.size(); ++i)
		{
			expressions.push_back(Expressions::Factory::boolean(j[i]));
		}
		return std::make_unique<All const>(std::move(expressions));
	}

	std::unique_ptr<Any const> any(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "any", "First value in a Any expression must be 'any'");

		std::vector<BooleanT::Ptr> expressions;
		for (size_t i = 1; i < j.size(); ++i)
		{
			expressions.push_back(Expressions::Factory::boolean(j[i]));
		}
		return std::make_unique<Any const>(std::move(expressions));
	}

	std::unique_ptr<Negate const> negate(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Negate expression must have exactly 2 elements");
		MAP3D_ASSERT(j[0] == "!", "First value in a Negate expression must be '!'");
		return std::make_unique<Negate const>(Expressions::Factory::boolean(j[1]));
	}

	// parse Equals expressions -----------------------------------------------------------------------

	std::unique_ptr<Equals<bool> const> booleanEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "BooleanEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "==", "First value in a BooleanEquals expression must be '=='");
		auto lhs = Expressions::Factory::boolean(j[1]);
		auto rhs = Expressions::Factory::boolean(j[2]);
		return std::make_unique<Equals<bool> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<Equals<lgal::Color> const> colorEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "ColorEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "==", "First value in a ColorEquals expression must be '=='");
		auto lhs = Expressions::Factory::color(j[1]);
		auto rhs = Expressions::Factory::color(j[2]);
		return std::make_unique<Equals<lgal::Color> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<Equals<float> const> numberEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "NumberEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "==", "First value in a NumberEquals expression must be '=='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<Equals<float> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<Equals<std::string> const> stringEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "StringEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "==", "First value in a StringEquals expression must be '=='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<Equals<std::string> const>(std::move(lhs), std::move(rhs));
	}

	// parse NotEquals expressions --------------------------------------------------------------------------

	std::unique_ptr<NotEquals<bool> const> booleanNotEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "BooleanNotEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "!=", "First value in a BooleanNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::boolean(j[1]);
		auto rhs = Expressions::Factory::boolean(j[2]);
		return std::make_unique<NotEquals<bool> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NotEquals<lgal::Color> const> colorNotEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "ColorNotEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "!=", "First value in a ColorNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::color(j[1]);
		auto rhs = Expressions::Factory::color(j[2]);
		return std::make_unique<NotEquals<lgal::Color> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NotEquals<float> const> numberNotEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "NumberNotEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "!=", "First value in a NumberNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NotEquals<float> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NotEquals<std::string> const> stringNotEquals(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "StringNotEquals expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "!=", "First value in a StringNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<NotEquals<std::string> const>(std::move(lhs), std::move(rhs));
	}

	// parse comparison expressions for numbers --------------------------------------------------------------

	std::unique_ptr<NumberLessThan const> numberLessThan(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "NumberLessThan expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "<", "First value in a NumberLessThan expression must be '<'");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberLessThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NumberGreaterThan const> numberGreaterThan(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "NumberGreaterThan expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == ">", "First value in a NumberGreaterThan expression must be '>'");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberGreaterThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NumberLEQ const> numberLEQ(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "NumberLEQ expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "<=", "First value in a NumberLEQ expression must be '<='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberLEQ const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NumberGEQ const> numberGEQ(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "NumberGEQ expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == ">=", "First value in a NumberGEQ expression must be '>='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberGEQ const>(std::move(lhs), std::move(rhs));
	}

	// parse comparison expressions for strings --------------------------------------------------------------

	std::unique_ptr<StringLessThan const> stringLessThan(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "StringLessThan expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "<", "First value in a StringLessThan expression must be '<'");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringLessThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<StringGreaterThan const> stringGreaterThan(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "StringGreaterThan expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == ">", "First value in a StringGreaterThan expression must be '>'");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringGreaterThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<StringLEQ const> stringLEQ(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "StringLEQ expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == "<=", "First value in a StringLEQ expression must be '<='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringLEQ const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<StringGEQ const> stringGEQ(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3, "StringGEQ expression must have exactly 3 elements");
		MAP3D_ASSERT(j[0] == ">=", "First value in a StringGEQ expression must be '>='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringGEQ const>(std::move(lhs), std::move(rhs));
	}

} } } } }