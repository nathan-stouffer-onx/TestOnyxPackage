#ifndef __STYLING_BOOLEAN_EXPRESSION_FACTORY_H__
#define __STYLING_BOOLEAN_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/BooleanExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {
namespace Factory {

	std::unique_ptr<Context	 const> context (nlohmann::json const& j);
	std::unique_ptr<Constant const> constant(nlohmann::json const& j);
	std::unique_ptr<Get      const> get     (nlohmann::json const& j);
	std::unique_ptr<Has      const> has     (nlohmann::json const& j);
	std::unique_ptr<Step     const> step    (nlohmann::json const& j);
	std::unique_ptr<Case     const> cases   (nlohmann::json const& j);	// deviated from pattern for function name cases because 'case' is C++ syntax
	std::unique_ptr<Match    const> match   (nlohmann::json const& j);
	std::unique_ptr<All      const> all     (nlohmann::json const& j);
	std::unique_ptr<Any      const> any     (nlohmann::json const& j);
	std::unique_ptr<Negate   const> negate  (nlohmann::json const& j);
	
	std::unique_ptr<Equals<				bool> const> booleanEquals(nlohmann::json const& j);
	std::unique_ptr<Equals<		 lgal::Color> const> colorEquals  (nlohmann::json const& j);
	std::unique_ptr<Equals<			   float> const> numberEquals (nlohmann::json const& j);
	std::unique_ptr<Equals<		 std::string> const> stringEquals (nlohmann::json const& j);

	std::unique_ptr<NotEquals<			bool> const> booleanNotEquals(nlohmann::json const& j);
	std::unique_ptr<NotEquals<	 lgal::Color> const> colorNotEquals(nlohmann::json const& j);
	std::unique_ptr<NotEquals<		   float> const> numberNotEquals(nlohmann::json const& j);
	std::unique_ptr<NotEquals<	 std::string> const> stringNotEquals(nlohmann::json const& j);

	std::unique_ptr<NumberLessThan    const> numberLessThan   (nlohmann::json const& j);
	std::unique_ptr<NumberGreaterThan const> numberGreaterThan(nlohmann::json const& j);
	std::unique_ptr<NumberLEQ         const> numberLEQ        (nlohmann::json const& j);
	std::unique_ptr<NumberGEQ         const> numberGEQ        (nlohmann::json const& j);

	std::unique_ptr<StringLessThan    const> stringLessThan(nlohmann::json const& j);
	std::unique_ptr<StringGreaterThan const> stringGreaterThan(nlohmann::json const& j);
	std::unique_ptr<StringLEQ         const> stringLEQ(nlohmann::json const& j);
	std::unique_ptr<StringGEQ         const> stringGEQ(nlohmann::json const& j);

} } } } }

#endif