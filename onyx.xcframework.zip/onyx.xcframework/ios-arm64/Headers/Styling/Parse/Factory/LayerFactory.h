#ifndef __STYLING_LAYER_FACTORY_H__
#define __STYLING_LAYER_FACTORY_H__

#include <memory>

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Layers/Layer.h"

namespace onyx {
namespace Styling {
namespace Factory {

	// factory function for Layers
	std::unique_ptr<Layer> layer(nlohmann::json const& json);

} } }

#endif