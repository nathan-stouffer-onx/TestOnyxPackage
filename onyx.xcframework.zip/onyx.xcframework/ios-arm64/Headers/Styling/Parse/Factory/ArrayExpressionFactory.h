#ifndef __STYLING_ARRAY_EXPRESSION_FACTORY_H__
#define __STYLING_ARRAY_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>

#include <System/Map3DException.h>

#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Parse/Factory/InterpolationFactory.h"
#include "Styling/Parse/Factory/MatcherFactory.h"
#include "Styling/Parse/ColorString.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Array {
namespace Factory {

	template<typename T>
	std::unique_ptr<Constant<T> const> constant(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.is_array(), "Constant Array expression is not an array");
		MAP3D_ASSERT(j.size() > 0, "Constant Array expression is empty");
		std::vector<T> array;
		j.get_to(array);
		return std::make_unique<Constant<T> const>(array);
	}

	// template specialization for color
	template<> std::unique_ptr<Constant<lgal::Color> const> constant(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.is_array(), "Constant Array expression is not an array");
		MAP3D_ASSERT(j.size() > 0, "Constant Array expression is empty");
		std::vector<std::string> strings;
		j.get_to(strings);
		std::vector<lgal::Color> colors;
		colors.reserve(strings.size());
		for (std::string const& str : strings)
		{
			colors.push_back(Parse::color(str));
		}
		return std::make_unique<Constant<lgal::Color> const>(colors);
	}

	template<typename T>
	std::unique_ptr<Constant<T> const> literal(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "literal", "First value in a Literal expression must be 'literal'");
		MAP3D_ASSERT(j.size() == 2, "Literal expression must have exactly 2 elements");
		return constant<T>(j[1]);
	}

	template<typename T>
	std::unique_ptr<Interpolation::Step<std::vector<T>> const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<std::vector<T>>(j);
	}

	template<typename T>
	std::unique_ptr<Decision::Case<std::vector<T>> const> cases(nlohmann::json const& j)	// deviated from pattern for function name cases because 'case' is C++ syntax
	{
		return Decision::Factory::cases<std::vector<T>>(j);
	}

	template<typename T>
	std::unique_ptr<Decision::Match<std::vector<T>> const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<std::vector<T>> const> matcher = Decision::Factory::matcher<std::vector<T>>(j);
		return std::make_unique<Decision::Match<std::vector<T>> const>(std::move(matcher));
	}

} } } } }

#endif