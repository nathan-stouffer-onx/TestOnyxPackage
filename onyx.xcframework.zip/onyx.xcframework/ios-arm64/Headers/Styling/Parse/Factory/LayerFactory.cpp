#include "LayerFactory.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/LayerJson.h"

namespace onyx {
namespace Styling {
namespace Factory {

	template<typename T>
	static inline std::unique_ptr<Layer> ConstructLayer(nlohmann::json const& j)
	{
		std::unique_ptr<T> layer = std::make_unique<T>();
		from_json(j, *layer);
		return layer;
	}

	std::unique_ptr<Layer> layer(nlohmann::json const& json)
	{
		Layer::Types type = Layer::Types::UNKNOWN;
		JsonParsing::Require(json, "type", type, "Layer is missing required key 'type'");

		switch (type)
		{
			case Layer::Types::BACKGROUND:			return ConstructLayer<BackgroundLayer>(json);			break;
			case Layer::Types::CIRCLE:				return ConstructLayer<CircleLayer>(json);				break;
			case Layer::Types::CONTOUR_LABEL:		return ConstructLayer<ContourLabelLayer>(json);			break;
			case Layer::Types::CONTOUR_LINE:		return ConstructLayer<ContourLineLayer>(json);			break;
			case Layer::Types::ELEVATION:			return ConstructLayer<ElevationLayer>(json);			break;
			case Layer::Types::FILL:				return ConstructLayer<FillLayer>(json);					break;
			case Layer::Types::INTERSECT:			return ConstructLayer<IntersectLayer>(json);			break;
			case Layer::Types::LINE:				return ConstructLayer<LineLayer>(json);					break;
			case Layer::Types::RASTER:				return ConstructLayer<RasterLayer>(json);				break;
			case Layer::Types::SLOPE_ANGLE:			return ConstructLayer<SlopeAngleLayer>(json);			break;
			case Layer::Types::SLOPE_ASPECT:		return ConstructLayer<SlopeAspectLayer>(json);			break;
			case Layer::Types::SUNLIGHT:			return ConstructLayer<SunlightLayer>(json);				break;
			case Layer::Types::SYMBOL:				return ConstructLayer<SymbolLayer>(json);				break;
			case Layer::Types::VIEWSHED:			return ConstructLayer<ViewshedLayer>(json);				break;
			default:								ONYX_THROW("Layer::Type not found");					break;
		}

		return std::unique_ptr<Layer>(nullptr);
	}

} } }