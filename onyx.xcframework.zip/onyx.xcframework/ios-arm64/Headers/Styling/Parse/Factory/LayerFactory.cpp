#include "LayerFactory.h"

#include <json/jsonParsing.h>

#include "Styling/Parse/LayerJson.h"

namespace onyx {
namespace Styling {
namespace Factory {

	template<typename T>
	static inline std::unique_ptr<Layer> ConstructLayer(nlohmann::json const& j)
	{
		std::unique_ptr<T> layer = std::make_unique<T>();
		from_json(j, *layer);
		return layer;
	}

	std::unique_ptr<Layer> layer(nlohmann::json const& json)
	{
		Layer::Type type = Layer::Type::UNKNOWN;
		JsonParsing::Require(json, "type", type, "Layer is missing required key 'type'");

		switch (type)
		{
			case Layer::Type::BACKGROUND:	return ConstructLayer<BackgroundLayer>(json);	break;
			case Layer::Type::RASTER:		return ConstructLayer<RasterLayer>(json);		break;
			case Layer::Type::LINE:			return ConstructLayer<LineLayer>(json);			break;
			case Layer::Type::FILL:			return ConstructLayer<FillLayer>(json);			break;
			case Layer::Type::SYMBOL:		return ConstructLayer<SymbolLayer>(json);		break;
			case Layer::Type::CONTOUR:		return ConstructLayer<ContourLayer>(json);		break;
			default:                        MAP3D_THROW("Layer::Type not found");			break;
		}

		return std::unique_ptr<Layer>(nullptr);
	}

} } }