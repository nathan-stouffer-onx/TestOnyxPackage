#ifndef __STYLING_SOURCE_FACTORY_H__
#define __STYLING_SOURCE_FACTORY_H__

#include <memory>

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Sources/Source.h"

namespace onyx {
namespace Styling {
namespace Factory {

	// factory function for Sources
	std::unique_ptr<Source> source(nlohmann::json const& json);

} } }

#endif