#include "StringExpressionFactory.h"

#include <System/Map3DException.h>

#include "Styling/Parse/Factory/ExpressionFactory.h"
#include "Styling/Parse/Factory/InterpolationFactory.h"
#include "Styling/Parse/Factory/MatcherFactory.h"
#include "ContextFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {
namespace Factory {

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<std::string>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.is_string(), "Constant String expression must be a string");
		std::string str = j;
		return std::make_unique<Constant const>(str);
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Get must have 2 elements");
		MAP3D_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		MAP3D_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		return std::make_unique<Get const>(str);
	}

	std::unique_ptr<Downcase const> downcase(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Downcase must have 2 elements");
		MAP3D_ASSERT(j[0] == "downcase", "First element of Downcase expression must be 'downcase'");
		return std::make_unique<Downcase const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<Upcase const> upcase(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Upcase must have 2 elements");
		MAP3D_ASSERT(j[0] == "upcase", "First element of Upcase expression must be 'upcase'");
		return std::make_unique<Upcase const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<Slice const> slice(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3 || j.size() == 4, "Slice must have 3 or 4 elements");
		MAP3D_ASSERT(j[0] == "slice", "First element of Slice expression must be 'slice'");

		auto input = Expressions::Factory::string(j[1]);
		auto begin = Expressions::Factory::number(j[2]);
		auto end = (j.size() == 4) ? Expressions::Factory::number(j[3]) : nullptr;

		return std::make_unique<Slice const>(std::move(input), std::move(begin), std::move(end));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<std::string>(j);
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<std::string>(j);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<std::string> const> matcher = Decision::Factory::matcher<std::string>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

} } } } }