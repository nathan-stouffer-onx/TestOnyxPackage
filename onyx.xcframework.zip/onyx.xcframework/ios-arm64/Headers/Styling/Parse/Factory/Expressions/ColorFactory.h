#pragma once

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/ColorExpressions.h"

namespace onyx::Styling::Expressions::Color::Factory
{

	std::unique_ptr<Asserts      const> asserts     (nlohmann::json const& j);
	std::unique_ptr<Case         const> cases       (nlohmann::json const& j);	// deviated from pattern for function name cases because 'case' is C++ syntax
	std::unique_ptr<Coalesce     const> coalesce    (nlohmann::json const& j);
	std::unique_ptr<Context		 const> context     (nlohmann::json const& j);
	std::unique_ptr<Constant     const> constant    (nlohmann::json const& j);
	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j);
	std::unique_ptr<FromColor    const> fromColor   (nlohmann::json const& j);
	std::unique_ptr<FromString   const> fromString  (nlohmann::json const& j);
	std::unique_ptr<Get          const> get         (nlohmann::json const& j);
	std::unique_ptr<ExplicitHSL  const> hsl         (nlohmann::json const& j);
	std::unique_ptr<ExplicitHSLA const> hsla        (nlohmann::json const& j);
	std::unique_ptr<Interpolate  const> interpolate (nlohmann::json const& j);
	std::unique_ptr<Match        const> match       (nlohmann::json const& j);
	std::unique_ptr<ExplicitRGB  const> rgb         (nlohmann::json const& j);
	std::unique_ptr<ExplicitRGBA const> rgba        (nlohmann::json const& j);
	std::unique_ptr<Step         const> step        (nlohmann::json const& j);

}