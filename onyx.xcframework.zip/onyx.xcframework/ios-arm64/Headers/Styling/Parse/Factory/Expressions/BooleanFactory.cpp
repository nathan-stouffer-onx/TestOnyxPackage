#include "BooleanFactory.h"

#include <array>

#include <System/OnyxException.h>

#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {
namespace Factory {

	using Parsers = Expressions::Factory::Parsers;

	std::string_view prefix(nlohmann::json const& j)
	{
		static std::array<std::string_view, 6> sComparisons = { "!=", "==", "<", "<=", ">=", ">" };
		std::string const& name = j[0];
		bool contains = std::find(sComparisons.begin(), sComparisons.end(), name) != sComparisons.end();
		if (contains)
		{
			// make sure the expression is of the correct form
			ONYX_ASSERT(j.size() == 3, "Comparison expression must have exactly 3 elements");

			// compute the available parsers
			Parsers lhs = Expressions::Factory::available(j[1]);
			Parsers rhs = Expressions::Factory::available(j[2]);

			// compute if there are any exact expressions
			bool lhsExact = Expressions::Factory::isExact(lhs);
			bool rhsExact = Expressions::Factory::isExact(rhs);

			Parsers parser = Parsers::NONE;
			Parsers stringAmbiguity = Parsers::COLOR | Parsers::FORMAT | Parsers::IMAGE | Parsers::STRING;

			if (lhsExact && rhsExact)	// if both are exact and identify the same type, make sure they are the same and use either one
			{
				if (lhs != rhs)
				{
					ONYX_THROW("Attempting to compare two non-equal types");
				}
				else
				{
					parser = lhs;
				}
			}
			else if (lhsExact)			// if only the lhs is exact, make sure the rhs can convert and use the lhs
			{
				ONYX_ASSERT((lhs & rhs) != Parsers::NONE, "Attempting to compare two types that cannot be parsed to the same type");
				parser = lhs;
			}
			else if (rhsExact)			// if only the rhs is exact, make sure the lhs can convert and use the rhs
			{
				ONYX_ASSERT((lhs & rhs) != Parsers::NONE, "Attempting to compare two types that cannot be parsed to the same type");
				parser = rhs;
			}
			else if (lhs == stringAmbiguity)	// if the lhs could be either a string/format/color, assume a string and make sure the rhs can be parsed as a string
			{
				ONYX_ASSERT((rhs & Parsers::STRING) != Parsers::NONE, "Attempting to compare type to string that cannot be parsed to a string");
				parser = Parsers::STRING;
			}
			else if (rhs == stringAmbiguity)	// if the rhs could be either a string/format/color, assume a string and make sure the lhs can be parsed as a string
			{
				ONYX_ASSERT((lhs & Parsers::STRING) != Parsers::NONE, "Attempting to compare type to string that cannot be parsed to a string");
				parser = Parsers::STRING;
			}

			switch (parser)
			{
				case Parsers::NONE:    ONYX_THROW("Invalid expression"); break;
				case Parsers::BOOLEAN: return "boolean";                 break;
				case Parsers::COLOR:   return "color";			       break;
				case Parsers::NUMBER:  return "number";                  break;
				case Parsers::STRING:  return "string";                  break;
				case Parsers::ALL:     // intentionally fall through to default
				default: ONYX_THROW("Return types are ambiguous for comparison operator");
			}
		}

		// default to no prefix
		return "";
	}

	std::unique_ptr<All const> all(nlohmann::json const& j)
	{
		ONYX_ASSERT(j[0] == "all", "First value in a All expression must be 'all'");

		std::vector<BooleanT::Ptr> expressions;
		for (size_t i = 1; i < j.size(); ++i)
		{
			expressions.push_back(Expressions::Factory::boolean(j[i]));
		}
		return std::make_unique<All const>(std::move(expressions));
	}

	std::unique_ptr<Any const> any(nlohmann::json const& j)
	{
		ONYX_ASSERT(j[0] == "any", "First value in a Any expression must be 'any'");

		std::vector<BooleanT::Ptr> expressions;
		for (size_t i = 1; i < j.size(); ++i)
		{
			expressions.push_back(Expressions::Factory::boolean(j[i]));
		}
		return std::make_unique<Any const>(std::move(expressions));
	}

	std::unique_ptr<Asserts const> asserts(nlohmann::json const& j)
	{
		// TODO to avoid forcing carto to maintain two sets of stylsheets, we have disabled this assertion;
		// re-enable once carto moves fallback values inside "feature-state" expressions
		//ONYX_ASSERT(j.size() == 2, "Boolean assertion must have 2 elements");
		ONYX_ASSERT(j[0] == "boolean", "First element of Boolean assertion expression must be 'boolean'");
		return std::make_unique<Asserts const>(Expressions::Factory::boolean(j[1]));
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<bool>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_boolean(), "Constant Boolean expression must be a boolean");
		bool value = j;
		return std::make_unique<Constant const>(value);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<bool>(j);
	}

	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "FeatureState must have 2 or 3 elements");
		ONYX_ASSERT(j[0] == "feature-state", "First element of FeatureState expression must be 'feature-state'");
		ONYX_ASSERT(j[1].is_string(), "Second element of FeatureState expression must be a string");
		std::string const& str = j[1];
		BooleanT::Ptr fallback = (j.size() == 3) ? Expressions::Factory::boolean(nlohmann::json::array({ "to-boolean", j[2] })) : Boolean::construct(cDefaultBoolean);
		return std::make_unique<FeatureState const>(str, std::move(fallback));
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "Get must have 2 or 3 elements");
		ONYX_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		ONYX_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		BooleanT::Ptr fallback = (j.size() == 3) ? Expressions::Factory::boolean(nlohmann::json::array({ "to-boolean", j[2] })) : Boolean::construct(cDefaultBoolean);
		return std::make_unique<Get const>(str, std::move(fallback));
	}

	std::unique_ptr<Has const> has(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Has must have 2 elements");
		ONYX_ASSERT(j[0] == "has", "First element of Has expression must be 'has'");
		ONYX_ASSERT(j[1].is_string(), "Second element of Has expression must be a string");
		std::string const& str = j[1];
		return std::make_unique<Has const>(str);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<bool> const> matcher = Decision::Factory::matcher<bool>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Negate const> negate(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Negate expression must have exactly 2 elements");
		ONYX_ASSERT(j[0] == "!", "First value in a Negate expression must be '!'");
		return std::make_unique<Negate const>(Expressions::Factory::boolean(j[1]));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<bool>(j);
	}

	// parse Equals expressions -----------------------------------------------------------------------

	std::unique_ptr<Equals<bool> const> booleanEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "BooleanEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "==", "First value in a BooleanEquals expression must be '=='");
		auto lhs = Expressions::Factory::boolean(j[1]);
		auto rhs = Expressions::Factory::boolean(j[2]);
		return std::make_unique<Equals<bool> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<Equals<lgal::Color> const> colorEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "ColorEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "==", "First value in a ColorEquals expression must be '=='");
		auto lhs = Expressions::Factory::color(j[1]);
		auto rhs = Expressions::Factory::color(j[2]);
		return std::make_unique<Equals<lgal::Color> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<Equals<float> const> numberEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "NumberEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "==", "First value in a NumberEquals expression must be '=='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<Equals<float> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<Equals<std::string> const> stringEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "StringEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "==", "First value in a StringEquals expression must be '=='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<Equals<std::string> const>(std::move(lhs), std::move(rhs));
	}

	// parse NotEquals expressions --------------------------------------------------------------------------

	std::unique_ptr<NotEquals<bool> const> booleanNotEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "BooleanNotEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "!=", "First value in a BooleanNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::boolean(j[1]);
		auto rhs = Expressions::Factory::boolean(j[2]);
		return std::make_unique<NotEquals<bool> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NotEquals<lgal::Color> const> colorNotEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "ColorNotEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "!=", "First value in a ColorNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::color(j[1]);
		auto rhs = Expressions::Factory::color(j[2]);
		return std::make_unique<NotEquals<lgal::Color> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NotEquals<float> const> numberNotEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "NumberNotEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "!=", "First value in a NumberNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NotEquals<float> const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NotEquals<std::string> const> stringNotEquals(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "StringNotEquals expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "!=", "First value in a StringNotEquals expression must be '!='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<NotEquals<std::string> const>(std::move(lhs), std::move(rhs));
	}

	// parse comparison expressions for numbers --------------------------------------------------------------

	std::unique_ptr<NumberLessThan const> numberLessThan(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "NumberLessThan expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "<", "First value in a NumberLessThan expression must be '<'");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberLessThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NumberGreaterThan const> numberGreaterThan(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "NumberGreaterThan expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == ">", "First value in a NumberGreaterThan expression must be '>'");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberGreaterThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NumberLEQ const> numberLEQ(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "NumberLEQ expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "<=", "First value in a NumberLEQ expression must be '<='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberLEQ const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<NumberGEQ const> numberGEQ(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "NumberGEQ expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == ">=", "First value in a NumberGEQ expression must be '>='");
		auto lhs = Expressions::Factory::number(j[1]);
		auto rhs = Expressions::Factory::number(j[2]);
		return std::make_unique<NumberGEQ const>(std::move(lhs), std::move(rhs));
	}

	// parse comparison expressions for strings --------------------------------------------------------------

	std::unique_ptr<StringLessThan const> stringLessThan(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "StringLessThan expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "<", "First value in a StringLessThan expression must be '<'");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringLessThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<StringGreaterThan const> stringGreaterThan(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "StringGreaterThan expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == ">", "First value in a StringGreaterThan expression must be '>'");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringGreaterThan const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<StringLEQ const> stringLEQ(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "StringLEQ expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "<=", "First value in a StringLEQ expression must be '<='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringLEQ const>(std::move(lhs), std::move(rhs));
	}
	std::unique_ptr<StringGEQ const> stringGEQ(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3, "StringGEQ expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == ">=", "First value in a StringGEQ expression must be '>='");
		auto lhs = Expressions::Factory::string(j[1]);
		auto rhs = Expressions::Factory::string(j[2]);
		return std::make_unique<StringGEQ const>(std::move(lhs), std::move(rhs));
	}

	std::unique_ptr<FromBoolean const> fromBoolean(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToBoolean must have 2 elements");
		ONYX_ASSERT(j[0] == "to-boolean", "First element of to-boolean expression must be 'to-boolean'");
		return std::make_unique<FromBoolean const>(Expressions::Factory::boolean(j[1]));
	}

	std::unique_ptr<FromNumber const> fromNumber(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToBoolean must have 2 elements");
		ONYX_ASSERT(j[0] == "to-boolean", "First element of to-boolean expression must be 'to-boolean'");
		return std::make_unique<FromNumber const>(Expressions::Factory::number(j[1]));
	}

	std::unique_ptr<FromString const> fromString(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToBoolean must have 2 elements");
		ONYX_ASSERT(j[0] == "to-boolean", "First element of to-boolean expression must be 'to-boolean'");
		return std::make_unique<FromString const>(Expressions::Factory::string(j[1]));
	}

} } } } }