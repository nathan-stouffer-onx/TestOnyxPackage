#include "GradientFactory.h"

#include <System/OnyxException.h>

#include "Styling/Parse/ColorString.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Gradient {
namespace Factory {

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<Utils::Gradient>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Gradient expression must be an array");
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "Gradient expression must have exactly 2 or 3 elements");
		ONYX_ASSERT(j[0] == "gradient", "First element of Gradient expression must be 'gradient'");
		ONYX_ASSERT(j[1].is_array(), "Second element of Gradient expression must be an array");
		
		time_float_t period = 0.0;
		if (j.size() == 3)
		{
			ONYX_ASSERT(j[2].is_number(), "Third element of Gradient expression must be a number");
			period = j[2];
		}
		
		ONYX_ASSERT(j[1].size() % 2 == 0, "Gradient stops must have an even number of elements")
		nlohmann::json arr = j[1];
		std::vector<Utils::Gradient::Stop> stops;
		for (size_t i = 0; i < arr.size(); i += 2)
		{
			ONYX_ASSERT(arr[i].is_number(), "Even element of stops must be a number");
			ONYX_ASSERT(arr[i + 1].is_string(), "Odd element of stops must be a color in string form");
			std::string const& color = arr[i + 1];
			stops.push_back({ arr[i], Parse::color(color) });
		}

		Utils::Gradient gradient(stops, period);
		return std::make_unique<Constant const>(gradient);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<Utils::Gradient>(j);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<Utils::Gradient> const> matcher = Decision::Factory::matcher<Utils::Gradient>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<Utils::Gradient>(j);
	}

} } } } }