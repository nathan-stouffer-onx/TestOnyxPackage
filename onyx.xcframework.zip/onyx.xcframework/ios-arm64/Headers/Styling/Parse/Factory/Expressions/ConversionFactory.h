#ifndef __STYLING_CONVERSION_EXPRESSIONS_H__
#define __STYLING_CONVERSION_EXPRESSIONS_H__

#include <string>

#include <3rdParty/nlohmann/json.hpp>

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Factory {

	/*
	* Function that returns the appropriate suffix to use. If an operand is known to return only one type (eg %),
	* it is called exact. Many times, it cannot be uniquely determined what type an operand will return. We have
	* the following situations
	*   * operation is not to-*                            => "" as the suffix
	*   * operation is to-*
	*      * if the operand is exact                       => return "from-<TYPE>" as suffix
	*      * if the operand is a "get" expression          => return "from-get" as suffix
	*      * otherwise                                     => throw exception (ambiguous input type to conversion)
	*/
	std::string_view suffix(nlohmann::json const& j);

} } } }

#endif