#ifndef __STYLING_BOOLEAN_EXPRESSION_FACTORY_H__
#define __STYLING_BOOLEAN_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/BooleanExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Boolean {
namespace Factory {

	/*
	* Function that returns the appropriate operator prefix to use.The types on either side of the operator are inferred based
	* on the operand. If an operand is known to return only one type (eg %), it is called exact.
	* Many times, it cannot be uniquely determined what type an operand will return. We have the following situations
	*   * both sides are exact and those types are equal                       => return type as the prefix
	*   * both sides are exact and those types are not equal                   => throw exception (invalid operator)
	*   * one side is exact and the other side can convert to that type        => return the known type
	*   * one side is string or color and the other side can convert to string => return string as the type
	*/
	std::string_view prefix(nlohmann::json const& j);

	std::unique_ptr<All          const> all         (nlohmann::json const& j);
	std::unique_ptr<Any          const> any         (nlohmann::json const& j);
	std::unique_ptr<Asserts      const> asserts     (nlohmann::json const& j);
	std::unique_ptr<Case         const> cases       (nlohmann::json const& j);	// deviated from pattern for function name cases because 'case' is C++ syntax
	std::unique_ptr<Constant     const> constant    (nlohmann::json const& j);
	std::unique_ptr<Context	     const> context     (nlohmann::json const& j);
	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j);
	std::unique_ptr<Get          const> get         (nlohmann::json const& j);
	std::unique_ptr<Has          const> has         (nlohmann::json const& j);
	std::unique_ptr<Match        const> match       (nlohmann::json const& j);
	std::unique_ptr<Negate       const> negate      (nlohmann::json const& j);
	std::unique_ptr<Step         const> step        (nlohmann::json const& j);
	
	std::unique_ptr<Equals<				bool> const> booleanEquals(nlohmann::json const& j);
	std::unique_ptr<Equals<		 lgal::Color> const> colorEquals  (nlohmann::json const& j);
	std::unique_ptr<Equals<			   float> const> numberEquals (nlohmann::json const& j);
	std::unique_ptr<Equals<		 std::string> const> stringEquals (nlohmann::json const& j);

	std::unique_ptr<NotEquals<			bool> const> booleanNotEquals(nlohmann::json const& j);
	std::unique_ptr<NotEquals<	 lgal::Color> const> colorNotEquals(nlohmann::json const& j);
	std::unique_ptr<NotEquals<		   float> const> numberNotEquals(nlohmann::json const& j);
	std::unique_ptr<NotEquals<	 std::string> const> stringNotEquals(nlohmann::json const& j);

	std::unique_ptr<NumberLessThan    const> numberLessThan   (nlohmann::json const& j);
	std::unique_ptr<NumberGreaterThan const> numberGreaterThan(nlohmann::json const& j);
	std::unique_ptr<NumberLEQ         const> numberLEQ        (nlohmann::json const& j);
	std::unique_ptr<NumberGEQ         const> numberGEQ        (nlohmann::json const& j);

	std::unique_ptr<StringLessThan    const> stringLessThan(nlohmann::json const& j);
	std::unique_ptr<StringGreaterThan const> stringGreaterThan(nlohmann::json const& j);
	std::unique_ptr<StringLEQ         const> stringLEQ(nlohmann::json const& j);
	std::unique_ptr<StringGEQ         const> stringGEQ(nlohmann::json const& j);

	std::unique_ptr<FromBoolean const> fromBoolean(nlohmann::json const& j);
	std::unique_ptr<FromString  const> fromString (nlohmann::json const& j);
	std::unique_ptr<FromNumber  const> fromNumber (nlohmann::json const& j);

} } } } }

#endif