#ifndef __STYLING_EXPRESSION_FACTORY_H__
#define __STYLING_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>
#include <Utils/BitwiseEnumOperators.h>

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Factory {

	BooleanT::Ptr boolean(nlohmann::json const& j);
	ColorT::Ptr color(nlohmann::json const& j);
	FormattedT::Ptr format(nlohmann::json const& j);
	NumberT::Ptr number(nlohmann::json const& j);
	ResolvedImageT::Ptr image(nlohmann::json const& j);
	RangeT::Ptr range(nlohmann::json const& j);
	StringT::Ptr string(nlohmann::json const& j);
	GradientT::Ptr gradient(nlohmann::json const& j);

	BooleanArrayT::Ptr booleans(nlohmann::json const& j);
	ColorArrayT::Ptr colors(nlohmann::json const& j);
	NumberArrayT::Ptr numbers(nlohmann::json const& j);
	RangeArrayT::Ptr ranges(nlohmann::json const& j);
	StringArrayT::Ptr strings(nlohmann::json const& j);

	// delete generic template so that it can never be used
	template<typename OutputT> inline ExpressionPtr<OutputT>                       expr(nlohmann::json const& j) = delete;
	template<>                 inline ExpressionPtr<bool>                          expr(nlohmann::json const& j) { return boolean(j); }
	template<>                 inline ExpressionPtr<lgal::Color>                   expr(nlohmann::json const& j) { return color(j); }
	template<>                 inline ExpressionPtr<Formatted>                     expr(nlohmann::json const& j) { return format(j); }
	template<>                 inline ExpressionPtr<float>                         expr(nlohmann::json const& j) { return number(j); }
	template<>                 inline ExpressionPtr<lgal::gpu::Range>              expr(nlohmann::json const& j) { return range(j); }
	template<>                 inline ExpressionPtr<ResolvedImage>                 expr(nlohmann::json const& j) { return image(j); }
	template<>                 inline ExpressionPtr<std::string>                   expr(nlohmann::json const& j) { return string(j); }
	template<>                 inline ExpressionPtr<Utils::Gradient>               expr(nlohmann::json const& j) { return gradient(j); }
	template<>                 inline ExpressionPtr<std::vector<bool>>             expr(nlohmann::json const& j) { return booleans(j); }
	template<>                 inline ExpressionPtr<std::vector<lgal::Color>>      expr(nlohmann::json const& j) { return colors(j); }
	template<>                 inline ExpressionPtr<std::vector<float>>            expr(nlohmann::json const& j) { return numbers(j); }
	template<>                 inline ExpressionPtr<std::vector<lgal::gpu::Range>> expr(nlohmann::json const& j) { return ranges(j); }
	template<>                 inline ExpressionPtr<std::vector<std::string>>      expr(nlohmann::json const& j) { return strings(j); }

	bool isFeatureState(nlohmann::json const& j);
	bool isGet(nlohmann::json const& j);

	// enum that denotes what types of parsers that know how to work with a given expression
	using parsers_int_t = uint16_t;
	enum class Parsers : parsers_int_t
	{
		NONE          = 0x0,
		BOOLEAN       = 0x1,
		COLOR         = 0x2,
		FORMAT        = 0x4,
		IMAGE         = 0x8,
		NUMBER        = 0x10,
		RANGE         = 0x20,
		STRING        = 0x40,
		GRADIENT      = 0x80,
		BOOLEAN_ARRAY = 0x100,
		COLOR_ARRAY   = 0x200,
		NUMBER_ARRAY  = 0x400,
		RANGE_ARRY    = 0x800,
		STRING_ARRAY  = 0x1000,
		ALL           = BOOLEAN | COLOR | FORMAT | IMAGE | NUMBER | RANGE | STRING | GRADIENT | BOOLEAN_ARRAY | COLOR_ARRAY | NUMBER_ARRAY | RANGE_ARRY | STRING_ARRAY
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(Parsers);

	// function to return the factory functions that have parsers available to deal with the given json
	Parsers available(nlohmann::json const& j);

	inline bool isExact(Parsers parsers)
	{
		return parsers_int_t(parsers) && !(parsers_int_t(parsers) & (parsers_int_t(parsers) - 1));
	}

} } } }

#endif