#ifndef __STYLING_INTERPOLATION_FACTORY_H__
#define __STYLING_INTERPOLATION_FACTORY_H__

#include <memory>
#include <vector>

#include <3rdParty/nlohmann/json.hpp>
#include <System/OnyxException.h>

#include "Styling/Expressions/InterpolationExpressions.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Interpolation {
namespace Factory {

	template<typename OutputT>
	std::unique_ptr<Step<OutputT> const> step(nlohmann::json const& j)
	{
		ONYX_ASSERT(j[0] == "step", "First value in an Step expression must be 'step'");
		ONYX_ASSERT(j.size() >= 3, "Step expression does not have enough arguments");
		ONYX_ASSERT(j.size() % 2 == 1, "Step expression must have an odd number of elements");

		std::vector<typename Step<OutputT>::Stop> stops;
		stops.reserve(j.size() - 2);
		stops.push_back({ std::numeric_limits<float>::lowest(), Expressions::Factory::expr<OutputT>(j[2]) });
		float constexpr prevInput = std::numeric_limits<float>::lowest();
		for (size_t i = 3; i < j.size(); i += 2)
		{
			float input = j[i];
			ONYX_ASSERT(input > prevInput, "Step stop pairs must be arranged with input values in strictly ascending order");
			stops.push_back({ input, Expressions::Factory::expr<OutputT>(j[i + 1]) });
		}

		std::unique_ptr<StepInterpolator<OutputT> const> interpolator = std::make_unique<StepInterpolator<OutputT> const>();
		NumberT::Ptr input = Expressions::Factory::number(j[1]);
		return std::make_unique<Step<OutputT> const>(std::move(interpolator), std::move(input), std::move(stops));
	}

	template<typename OutputT>
	std::unique_ptr<Interpolator<OutputT> const> interpolator(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() > 0, "Interpolator must have more than one element");

		std::string const& type = j[0];
		if (type == "linear")
		{
			ONYX_ASSERT(j.size() == 1, "Linear interpolator must have exactly one element");
			ONYX_ASSERT(j[0] == "linear", "First element of linear interpolator must be 'linear'");
			return std::make_unique<LinearInterpolator<OutputT> const>();
		}
		else if (type == "exponential")
		{
			ONYX_ASSERT(j.size() == 2, "Exponential interpolator must have exactly two elements");
			ONYX_ASSERT(j[0] == "exponential", "First element of exponential interpolator must be 'exponential'");
			float base = j[1];
			return std::make_unique<ExponentialInterpolator<OutputT> const>(base);
		}
		else
		{
			ONYX_THROW("Unrecognized interpolator type");
			return nullptr;
		}
	}

	template<typename OutputT>
	std::unique_ptr<Interpolate<OutputT> const> interpolate(nlohmann::json const& j)
	{
		ONYX_ASSERT(j[0] == "interpolate", "First value in an Interpolate expression must be 'interpolate'");
		ONYX_ASSERT(j.size() >= 5, "Interpolate expression does not have enough arguments");
		ONYX_ASSERT(j.size() % 2 == 1, "Interpolate expression must have an odd number of elements");

		std::vector<typename Interpolation::Interpolate<OutputT>::Stop> stops;
		stops.reserve(j.size() - 3);
		stops.push_back({ j[3], Expressions::Factory::expr<OutputT>(j[4]) });
		float prevInput = j[3];
		for (size_t i = 5; i < j.size(); i += 2)
		{
			float input = j[i];
			ONYX_ASSERT(input > prevInput, "Interpolate stop pairs must be arranged with input values in strictly ascending order");
			stops.push_back({ input, Expressions::Factory::expr<OutputT>(j[i + 1]) });
		}

		std::unique_ptr<Interpolator<OutputT> const> interpolator = Factory::interpolator<OutputT>(j[1]);
		NumberT::Ptr input = Expressions::Factory::number(j[2]);
		return std::make_unique<Interpolate<OutputT> const>(std::move(interpolator), std::move(input), std::move(stops));
	}

} } } } }

#endif