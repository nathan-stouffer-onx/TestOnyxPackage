#include "StringFactory.h"

#include <System/OnyxException.h>

#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {
namespace Factory {

	std::unique_ptr<Asserts const> asserts(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "String assertion must have 2 elements");
		ONYX_ASSERT(j[0] == "string", "First element of String assertion expression must be 'string'");
		return std::make_unique<Asserts const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<std::string>(j);
	}

	std::unique_ptr<Concat const> concat(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() > 1, "Concat must have at least 2 elements");
		ONYX_ASSERT(j[0] == "concat", "First element of Concat expression must be 'concat'");
		std::vector<StringT::Ptr> inputs;
		inputs.reserve(j.size() - 1);
		for (size_t i = 1; i < j.size(); ++i)
		{
			nlohmann::json conversion = nlohmann::json::array_t{ nlohmann::json("to-string"), j[i] };
			inputs.push_back(Expressions::Factory::string(conversion));
		}
		return std::make_unique<Concat const>(std::move(inputs));
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_string(), "Constant String expression must be a string");
		std::string str = j;
		return std::make_unique<Constant const>(str);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<std::string>(j);
	}

	std::unique_ptr<Downcase const> downcase(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Downcase must have 2 elements");
		ONYX_ASSERT(j[0] == "downcase", "First element of Downcase expression must be 'downcase'");
		return std::make_unique<Downcase const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "FeatureState must have 2 or 3 elements");
		ONYX_ASSERT(j[0] == "feature-state", "First element of FeatureState expression must be 'feature-state'");
		ONYX_ASSERT(j[1].is_string(), "Second element of FeatureState expression must be a string");
		std::string const& str = j[1];
		StringT::Ptr fallback = (j.size() == 3) ? Expressions::Factory::string(nlohmann::json::array({ "to-string", j[2] })) : String::construct(cDefaultString);
		return std::make_unique<FeatureState const>(str, std::move(fallback));
	}

	std::unique_ptr<FromBoolean const> fromBoolean(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToString must have 2 elements");
		ONYX_ASSERT(j[0] == "to-string", "First element of to-string expression must be 'to-string'");
		return std::make_unique<FromBoolean const>(Expressions::Factory::boolean(j[1]));
	}

	std::unique_ptr<FromColor const> fromColor(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToString must have 2 elements");
		ONYX_ASSERT(j[0] == "to-string", "First element of to-string expression must be 'to-string'");
		return std::make_unique<FromColor const>(Expressions::Factory::color(j[1]));
	}

	std::unique_ptr<FromNumber const> fromNumber(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToString must have 2 elements");
		ONYX_ASSERT(j[0] == "to-string", "First element of to-string expression must be 'to-string'");
		return std::make_unique<FromNumber const>(Expressions::Factory::number(j[1]));
	}

	std::unique_ptr<FromString const> fromString(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToString must have 2 elements");
		ONYX_ASSERT(j[0] == "to-string", "First element of to-string expression must be 'to-string'");
		return std::make_unique<FromString const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<GeometryType const> geometryType(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 1, "GeometryType must have 1 element");
		ONYX_ASSERT(j[0] == "geometry-type", "First element of geometry-type expression must be 'geometry-type'");
		return std::make_unique<GeometryType const>();
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "Get must have 2 or 3 elements");
		ONYX_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		ONYX_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		StringT::Ptr fallback = (j.size() == 3) ? Expressions::Factory::string(nlohmann::json::array({ "to-string", j[2] })) : String::construct(cDefaultString);
		return std::make_unique<Get const>(str, std::move(fallback));
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<std::string> const> matcher = Decision::Factory::matcher<std::string>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Slice const> slice(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 3 || j.size() == 4, "Slice must have 3 or 4 elements");
		ONYX_ASSERT(j[0] == "slice", "First element of Slice expression must be 'slice'");

		auto input = Expressions::Factory::string(j[1]);
		auto begin = Expressions::Factory::number(j[2]);
		auto end = (j.size() == 4) ? Expressions::Factory::number(j[3]) : nullptr;

		return std::make_unique<Slice const>(std::move(input), std::move(begin), std::move(end));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<std::string>(j);
	}

	std::unique_ptr<Upcase const> upcase(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Upcase must have 2 elements");
		ONYX_ASSERT(j[0] == "upcase", "First element of Upcase expression must be 'upcase'");
		return std::make_unique<Upcase const>(Expressions::Factory::string(j[1]));
	}

} } } } }