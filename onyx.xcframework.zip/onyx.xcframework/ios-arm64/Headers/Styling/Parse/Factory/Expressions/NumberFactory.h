#ifndef __STYLING_NUMBER_EXPRESSION_FACTORY_H__
#define __STYLING_NUMBER_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/NumberExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Number {
namespace Factory {

	std::unique_ptr<Abs          const> abs         (nlohmann::json const& j);
	std::unique_ptr<Asserts      const> asserts     (nlohmann::json const& j);
	std::unique_ptr<Case         const> cases       (nlohmann::json const& j);	// deviated from pattern for function name cases because 'case' is C++ syntax
	std::unique_ptr<Constant     const> constant    (nlohmann::json const& j);
	std::unique_ptr<Context		 const> context		(nlohmann::json const& j);
	std::unique_ptr<Divide       const> divide      (nlohmann::json const& j);
	std::unique_ptr<Exponentiate const> exponentiate(nlohmann::json const& j);
	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j);
	std::unique_ptr<FromBoolean  const> fromBoolean (nlohmann::json const& j);
	std::unique_ptr<FromString   const> fromString  (nlohmann::json const& j);
	std::unique_ptr<FromNumber   const> fromNumber  (nlohmann::json const& j);
	std::unique_ptr<Get          const> get         (nlohmann::json const& j);
	std::unique_ptr<Heading      const> heading     (nlohmann::json const& j);
	std::unique_ptr<IndexOf      const> indexof     (nlohmann::json const& j);
	std::unique_ptr<Interpolate  const> interpolate (nlohmann::json const& j);
	std::unique_ptr<Length       const> length      (nlohmann::json const& j);
	std::unique_ptr<Match        const> match       (nlohmann::json const& j);
	std::unique_ptr<Modulo       const> modulo      (nlohmann::json const& j);
	std::unique_ptr<Pitch        const> pitch       (nlohmann::json const& j);
	std::unique_ptr<Product      const> product     (nlohmann::json const& j);
	std::unique_ptr<Step         const> step        (nlohmann::json const& j);
	std::unique_ptr<Subtract     const> subtract    (nlohmann::json const& j);
	std::unique_ptr<Sum          const> sum         (nlohmann::json const& j);
	std::unique_ptr<Zoom         const> zoom        (nlohmann::json const& j);

} } } } }

#endif