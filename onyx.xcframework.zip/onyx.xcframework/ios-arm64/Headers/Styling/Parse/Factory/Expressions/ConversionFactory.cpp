#include "ConversionFactory.h"

#include <System/OnyxException.h>

#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Factory {

	std::string_view suffix(nlohmann::json const& j)
	{
		static std::array<std::string_view, 4> sConversions = { "to-boolean", "to-color", "to-number", "to-string" };
		std::string const& name = j[0];
		bool contains = std::find(sConversions.begin(), sConversions.end(), name) != sConversions.end();
		if (contains)
		{
			// make sure the expression is of the correct form
			ONYX_ASSERT(j.size() == 2, "Conversion expression must have exactly 2 elements");

			if (Expressions::Factory::isFeatureState(j[1]))
			{
				return "-from-feature-state";
			}
			else if (Expressions::Factory::isGet(j[1]))
			{
				return "-from-get";
			}
			else
			{
				// compute the available parser
				Parsers parser = Expressions::Factory::available(j[1]);
				// prefer strings to color/format/image
				if (parser == (Parsers::FORMAT | Parsers::IMAGE | Parsers::STRING))
				{
					return "-from-string";
				}
				else if (parser == (Parsers::COLOR | Parsers::FORMAT | Parsers::IMAGE | Parsers::STRING))
				{
					return "-from-string";
				}
				// test for non-ambiguous input type
				switch (parser)
				{
					case Parsers::NONE:    ONYX_THROW("Invalid expression");	break;
					case Parsers::BOOLEAN: return "-from-boolean";			break;
					case Parsers::COLOR:   return "-from-color";				break;
					case Parsers::NUMBER:  return "-from-number";				break;
					case Parsers::STRING:  return "-from-string";				break;
					case Parsers::ALL:     // intentionally fall through to default
					default: ONYX_THROW("Return type is ambiguous for conversion operator");
				}
			}
		}

		// default to no suffix
		return "";
	}

} } } }