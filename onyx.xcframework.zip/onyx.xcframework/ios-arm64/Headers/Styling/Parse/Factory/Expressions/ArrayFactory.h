#pragma once

#include <3rdParty/nlohmann/json.hpp>

#include <System/OnyxException.h>

#include "Styling/Expressions/ArrayExpressions.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/ColorString.h"

namespace onyx::Styling::Expressions::Array::Factory
{

	template<typename T>
	std::unique_ptr<AmorphousArray<T> const> amorphousArray(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Amorphous Array expression is not an array");
		ONYX_ASSERT(j.size() > 0, "Amorphous Array expression is empty");
		std::vector<ExpressionPtr<T>> expressions;
		expressions.reserve(j.size());
		for (nlohmann::json const& item : j)
		{
			expressions.push_back(Expressions::Factory::expr<T>(item));
		}
		return std::make_unique<AmorphousArray<T> const>(std::move(expressions));
	}

	template<typename T>
	std::unique_ptr<Decision::Case<std::vector<T>> const> cases(nlohmann::json const& j)	// deviated from pattern for function name cases because 'case' is C++ syntax
	{
		return Decision::Factory::cases<std::vector<T>>(j);
	}

	template<typename T>
	std::unique_ptr<Constant<T> const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Constant Array expression is not an array");
		ONYX_ASSERT(j.size() > 0, "Constant Array expression is empty");
		std::vector<T> array;
		j.get_to(array);
		return std::make_unique<Constant<T> const>(array);
	}

	// template specialization for color
	template<> std::unique_ptr<Constant<lgal::Color> const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Constant Array expression is not an array");
		ONYX_ASSERT(j.size() > 0, "Constant Array expression is empty");
		std::vector<std::string> strings;
		j.get_to(strings);
		std::vector<lgal::Color> colors;
		colors.reserve(strings.size());
		for (std::string const& str : strings)
		{
			colors.push_back(Parse::color(str));
		}
		return std::make_unique<Constant<lgal::Color> const>(colors);
	}

	std::unique_ptr<Interpolation::InterpolateNumberArray const> interpolate(nlohmann::json const& j)
	{
		return Interpolation::Factory::interpolate<std::vector<float>>(j);
	}

	template<typename T>
	std::unique_ptr<Constant<T> const> literal(nlohmann::json const& j)
	{
		ONYX_ASSERT(j[0] == "literal", "First value in a Literal expression must be 'literal'");
		ONYX_ASSERT(j.size() == 2, "Literal expression must have exactly 2 elements");
		return constant<T>(j[1]);
	}

	template<typename T>
	std::unique_ptr<Decision::Match<std::vector<T>> const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<std::vector<T>> const> matcher = Decision::Factory::matcher<std::vector<T>>(j);
		return std::make_unique<Decision::Match<std::vector<T>> const>(std::move(matcher));
	}

	template<typename T>
	std::unique_ptr<Interpolation::Step<std::vector<T>> const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<std::vector<T>>(j);
	}

}