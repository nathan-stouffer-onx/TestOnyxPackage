#ifndef __STYLING_CONTEXT_FACTORY_H__
#define __STYLING_CONTEXT_FACTORY_H__

#include <memory>
#include <vector>

#include <3rdParty/nlohmann/json.hpp>
#include <System/OnyxException.h>

#include "Styling/Expressions/Expressions.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Context {
namespace Factory {

	template<typename OutputT>
	std::unique_ptr<ContextExpression<OutputT> const> read(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Get must have 2 elements");
		ONYX_ASSERT(j[0] == "context", "First element of Context expression must be 'context'");
		ONYX_ASSERT(j[1].is_string(), "Second element of Context expression must be a string");
		std::string const &str = j[1];
		return std::make_unique<ContextExpression<OutputT> const>(str);
	}

} } } } }

#endif