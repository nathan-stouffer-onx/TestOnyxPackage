#ifndef __STYLING_STRING_EXPRESSION_FACTORY_H__
#define __STYLING_STRING_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/StringExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace String {
namespace Factory {

	std::unique_ptr<Asserts      const> asserts     (nlohmann::json const& j);
	std::unique_ptr<Case         const> cases       (nlohmann::json const& j);	// deviated from pattern for function name cases because 'case' is C++ syntax
	std::unique_ptr<Constant     const> constant    (nlohmann::json const& j);
	std::unique_ptr<Context      const> context     (nlohmann::json const& j);
	std::unique_ptr<Concat       const> concat      (nlohmann::json const& j);
	std::unique_ptr<Downcase     const> downcase    (nlohmann::json const& j);
	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j);
	std::unique_ptr<FromBoolean  const> fromBoolean (nlohmann::json const& j);
	std::unique_ptr<FromColor    const> fromColor   (nlohmann::json const& j);
	std::unique_ptr<FromString   const> fromString  (nlohmann::json const& j);
	std::unique_ptr<FromNumber   const> fromNumber  (nlohmann::json const& j);
	std::unique_ptr<Get          const> get         (nlohmann::json const& j);
	std::unique_ptr<Match        const> match       (nlohmann::json const& j);
	std::unique_ptr<Slice        const> slice       (nlohmann::json const& j);
	std::unique_ptr<Step         const> step        (nlohmann::json const& j);
	std::unique_ptr<Upcase       const> upcase      (nlohmann::json const& j);

} } } } }

#endif