#include "FormatFactory.h"

#include <System/OnyxException.h>
#include <json/jsonParsing.h>

#include "Styling/Parse/ColorString.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"
#include "Styling/Parse/MiscJson.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Format {
namespace Factory {

	std::unique_ptr<AmorphousFormatted const> amorphousFormatted(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Format expression must be an array");
		ONYX_ASSERT(j.size() >= 2, "Format expression must have at least two elements");
		ONYX_ASSERT(j[0] == "format", "First element of Format expression must be 'format'");

		std::vector<AmorphousFormatted::Segment> segments;
		for (size_t i = 1; i < j.size(); ++i)
		{
			nlohmann::json const& str = j[i];
			AmorphousFormatted::Options options;
			if (i + 1 < j.size())
			{
				nlohmann::json const& next = j[i + 1];
				if (next.is_object())
				{
					options = next;
					++i;
				}
			}
			segments.push_back({ Expressions::Factory::string(str), std::move(options) });
		}

		return std::make_unique<AmorphousFormatted const>(std::move(segments));
	}
	
	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<Formatted>(j);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<Formatted>(j);
	}

	std::unique_ptr<AmorphousFormatted const> fromString(nlohmann::json const& j)
	{
		AmorphousFormatted::Segment segment{ Expressions::Factory::string(j), AmorphousFormatted::Options() };
		std::vector<AmorphousFormatted::Segment> segments;
		segments.push_back(std::move(segment));
		return std::make_unique<AmorphousFormatted const>(std::move(segments));
	}
	
	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<Formatted> const> matcher = Decision::Factory::matcher<Formatted>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<Formatted>(j);
	}

} } } } }