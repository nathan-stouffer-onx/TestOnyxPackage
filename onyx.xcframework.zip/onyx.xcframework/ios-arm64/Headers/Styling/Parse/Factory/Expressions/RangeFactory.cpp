#include "RangeFactory.h"

#include <System/OnyxException.h>

#include "Styling/Parse/ColorString.h"
#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"

namespace onyx::Styling::Expressions::Range::Factory
{

	std::unique_ptr<AmorphousRange const> amorphousRange(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Range expression must be an array");
		ONYX_ASSERT(j.size() == 3, "Range expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "range", "First element of Range expression must be 'range'");
		return std::make_unique<AmorphousRange const>(Expressions::Factory::number(j[1]), Expressions::Factory::number(j[2]));
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<lgal::gpu::Range>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_array(), "Range expression must be an array");
		ONYX_ASSERT(j.size() == 3, "Range expression must have exactly 3 elements");
		ONYX_ASSERT(j[0] == "range", "First element of Range expression must be 'range'");
		ONYX_ASSERT(j[1].is_number(), "Second element of Range expression must be a number");
		ONYX_ASSERT(j[2].is_number(), "Third element of Range expression must be a number");

		lgal::gpu::Range range(j[1], j[2]);
		return std::make_unique<Constant const>(range);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<lgal::gpu::Range>(j);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<lgal::gpu::Range> const> matcher = Decision::Factory::matcher<lgal::gpu::Range>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<lgal::gpu::Range>(j);
	}

}