#include "ColorFactory.h"

#include <System/OnyxException.h>

#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/ColorString.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Color {
namespace Factory {

	std::unique_ptr<Asserts const> asserts(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Color assertion must have 2 elements");
		ONYX_ASSERT(j[0] == "color", "First element of Color assertion expression must be 'color'");
		return std::make_unique<Asserts const>(Expressions::Factory::color(j[1]));
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<lgal::Color>(j);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<lgal::Color>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_string(), "Constant Color expression must be a string");
		std::string str = j;
		lgal::Color color = Parse::color(str);
		return std::make_unique<Constant const>(color);
	}

	std::unique_ptr<FeatureState const> featureState(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "FeatureState must have 2 or 3 elements");
		ONYX_ASSERT(j[0] == "feature-state", "First element of FeatureState expression must be 'feature-state'");
		ONYX_ASSERT(j[1].is_string(), "Second element of FeatureState expression must be a string");
		std::string const& str = j[1];
		ColorT::Ptr fallback = (j.size() == 3) ? Expressions::Factory::color(nlohmann::json::array({ "to-color", j[2] })) : Color::construct(cDefaultColor);
		return std::make_unique<FeatureState const>(str, std::move(fallback));
	}

	std::unique_ptr<FromColor const> fromColor(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToColor must have 2 elements");
		ONYX_ASSERT(j[0] == "to-color", "First element of to-color expression must be 'to-color'");
		return std::make_unique<FromColor const>(Expressions::Factory::color(j[1]));
	}

	std::unique_ptr<FromString const> fromString(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "ToColor must have 2 elements");
		ONYX_ASSERT(j[0] == "to-color", "First element of to-color expression must be 'to-color'");
		return std::make_unique<FromString const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2 || j.size() == 3, "Get must have 2 or 3 elements");
		ONYX_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		ONYX_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		ColorT::Ptr fallback = (j.size() == 3) ? Expressions::Factory::color(nlohmann::json::array({ "to-color", j[2] })) : Color::construct(cDefaultColor);
		return std::make_unique<Get const>(str, std::move(fallback));
	}

	std::unique_ptr<ExplicitHSL const> hsl(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 4, "HSL must have 4 elements");
		ONYX_ASSERT(j[0] == "hsl", "First element of HSL expression must be 'hsl'");
		auto h = Expressions::Factory::number(j[1]);
		auto s = Expressions::Factory::number(j[2]);
		auto l = Expressions::Factory::number(j[3]);
		return std::make_unique<ExplicitHSL const>(std::move(h), std::move(s), std::move(l));
	}

	std::unique_ptr<ExplicitHSLA const> hsla(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 5, "HSLA must have 5 elements");
		ONYX_ASSERT(j[0] == "hsla", "First element of HSLA expression must be 'hsla'");
		auto h = Expressions::Factory::number(j[1]);
		auto s = Expressions::Factory::number(j[2]);
		auto l = Expressions::Factory::number(j[3]);
		auto a = Expressions::Factory::number(j[4]);
		return std::make_unique<ExplicitHSLA const>(std::move(h), std::move(s), std::move(l), std::move(a));
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<lgal::Color> const> matcher = Decision::Factory::matcher<lgal::Color>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Interpolate const> interpolate(nlohmann::json const& j)
	{
		return Interpolation::Factory::interpolate<lgal::Color>(j);
	}

	std::unique_ptr<ExplicitRGB const> rgb(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 4, "RGB must have 4 elements");
		ONYX_ASSERT(j[0] == "rgb", "First element of RGB expression must be 'rgb'");
		auto r = Expressions::Factory::number(j[1]);
		auto g = Expressions::Factory::number(j[2]);
		auto b = Expressions::Factory::number(j[3]);
		return std::make_unique<ExplicitRGB const>(std::move(r), std::move(g), std::move(b));
	}
	
	std::unique_ptr<ExplicitRGBA const> rgba(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 5, "RGBA must have 5 elements");
		ONYX_ASSERT(j[0] == "rgba", "First element of RGBA expression must be 'rgba'");
		auto r = Expressions::Factory::number(j[1]);
		auto g = Expressions::Factory::number(j[2]);
		auto b = Expressions::Factory::number(j[3]);
		auto a = Expressions::Factory::number(j[4]);
		return std::make_unique<ExplicitRGBA const>(std::move(r), std::move(g), std::move(b), std::move(a));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<lgal::Color>(j);
	}

} } } } }
