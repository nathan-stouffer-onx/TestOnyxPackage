#include "ImageFactory.h"

#include <System/OnyxException.h>

#include "Styling/Parse/Factory/Expressions/ExpressionFactory.h"
#include "Styling/Parse/Factory/Expressions/InterpolationFactory.h"
#include "Styling/Parse/Factory/Expressions/MatcherFactory.h"
#include "Styling/Parse/Factory/Expressions/ContextFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Image {
namespace Factory {

	std::unique_ptr<AmorphousImage const> amorphousImage(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.size() == 2, "Image expression must have 2 elements");
		ONYX_ASSERT(j[0] == "image", "First element of Image expression must be 'image'");
		return std::make_unique<AmorphousImage const>(Expressions::Factory::string(j[1]));
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<ResolvedImage>(j);
	}

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<ResolvedImage>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		ONYX_ASSERT(j.is_string(), "Constant Image expression must be a string");
		std::string str = j;
		return std::make_unique<Constant const>(ResolvedImage(str));
	}

	std::unique_ptr<AmorphousImage const> fromString(nlohmann::json const& j)
	{
		return std::make_unique<AmorphousImage const>(Expressions::Factory::string(j));
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<ResolvedImage> const> matcher = Decision::Factory::matcher<ResolvedImage>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<ResolvedImage>(j);
	}

} } } } }