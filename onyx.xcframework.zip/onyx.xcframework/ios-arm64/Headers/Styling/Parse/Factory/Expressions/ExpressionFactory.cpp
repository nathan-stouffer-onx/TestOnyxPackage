#include "ExpressionFactory.h"

#include <functional>
#include <unordered_map>
#include <unordered_set>

#include <Logging/LogManager.h>
#include <System/OnyxException.h>

#include "Styling/Parse/Factory/Expressions/ArrayFactory.h"
#include "Styling/Parse/Factory/Expressions/BooleanFactory.h"
#include "Styling/Parse/Factory/Expressions/ColorFactory.h"
#include "Styling/Parse/Factory/Expressions/FormatFactory.h"
#include "Styling/Parse/Factory/Expressions/ConversionFactory.h"
#include "Styling/Parse/Factory/Expressions/GradientFactory.h"
#include "Styling/Parse/Factory/Expressions/ImageFactory.h"
#include "Styling/Parse/Factory/Expressions/NumberFactory.h"
#include "Styling/Parse/Factory/Expressions/RangeFactory.h"
#include "Styling/Parse/Factory/Expressions/StringFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Factory {

	using BooleanFunc = std::function<BooleanT::Ptr(nlohmann::json const&)>;
	using ColorFunc = std::function<ColorT::Ptr(nlohmann::json const&)>;
	using FormatFunc = std::function<FormattedT::Ptr(nlohmann::json const&)>;
	using NumberFunc = std::function<NumberT::Ptr(nlohmann::json const&)>;
	using RangeFunc = std::function<RangeT::Ptr(nlohmann::json const&)>;
	using ResolvedImageFunc = std::function<ResolvedImageT::Ptr(nlohmann::json const&)>;
	using StringFunc = std::function<StringT::Ptr(nlohmann::json const&)>;
	using GradientFunc = std::function<GradientT::Ptr(nlohmann::json const&)>;

	template<typename PrimitiveT>
	using ArrayFunc = std::function<typename ArrayT<PrimitiveT>::Ptr(nlohmann::json const&)>;

	using BooleanArrayFunc = ArrayFunc<bool>;
	using ColorArrayFunc = ArrayFunc<lgal::Color>;
	using NumberArrayFunc = ArrayFunc<float>;
	using RangeArrayFunc = ArrayFunc<lgal::gpu::Range>;
	using StringArrayFunc = ArrayFunc<std::string>;

	static BooleanFunc GetBooleanFunc(nlohmann::json const& j)
	{
		if (j.is_boolean()) { return &Boolean::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, BooleanFunc> const sFunctions =
			{
				{ "!",                             &Boolean::Factory::negate },
				{ "all",                           &Boolean::Factory::all },
				{ "any",                           &Boolean::Factory::any },
				{ "boolean",                       &Boolean::Factory::asserts },
				{ "case",                          &Boolean::Factory::cases },
				{ "context",                       &Boolean::Factory::context },
				{ "feature-state",                 &Boolean::Factory::featureState },
				{ "get",                           &Boolean::Factory::get },
				{ "has",                           &Boolean::Factory::has },
				{ "match",                         &Boolean::Factory::match },
				{ "step",                          &Boolean::Factory::step },
				{ "to-boolean-from-boolean",       &Boolean::Factory::fromBoolean },
				{ "to-boolean-from-feature-state", &Boolean::Factory::fromBoolean },
				{ "to-boolean-from-get",           &Boolean::Factory::fromBoolean },
				{ "to-boolean-from-string",        &Boolean::Factory::fromString },
				{ "to-boolean-from-number",        &Boolean::Factory::fromNumber },
				{ "boolean==",                     &Boolean::Factory::booleanEquals },
				{ "color==",                       &Boolean::Factory::colorEquals },
				{ "number==",                      &Boolean::Factory::numberEquals },
				{ "string==",                      &Boolean::Factory::stringEquals },
				{ "boolean!=",                     &Boolean::Factory::booleanNotEquals },
				{ "color!=",                       &Boolean::Factory::colorNotEquals },
				{ "number!=",                      &Boolean::Factory::numberNotEquals },
				{ "string!=",                      &Boolean::Factory::stringNotEquals },
				{ "number<",                       &Boolean::Factory::numberLessThan },
				{ "number>",                       &Boolean::Factory::numberGreaterThan },
				{ "number<=",                      &Boolean::Factory::numberLEQ },
				{ "number>=",                      &Boolean::Factory::numberGEQ },
				{ "string<",                       &Boolean::Factory::stringLessThan },
				{ "string>",                       &Boolean::Factory::stringGreaterThan },
				{ "string<=",                      &Boolean::Factory::stringLEQ },
				{ "string>=",                      &Boolean::Factory::stringGEQ },
			};

			// compute prefix and suffix (may be blank)
			std::string_view prefix = Boolean::Factory::prefix(j);
			std::string_view suffix = Factory::suffix(j);

			std::string name = std::string(prefix) + std::string(j[0]) + std::string(suffix);
			auto iter = sFunctions.find(name);
			BooleanFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}
		
		return nullptr;
	}

	static ColorFunc GetColorFunc(nlohmann::json const& j)
	{
		if (j.is_string()) { return &Color::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, ColorFunc> const sFunctions =
			{
				{ "case",                        &Color::Factory::cases },
				{ "color",                       &Color::Factory::asserts },
				{ "context",	                 &Color::Factory::context },
				{ "feature-state",               &Color::Factory::featureState },
				{ "get",                         &Color::Factory::get },
				{ "hsl",                         &Color::Factory::hsl },
				{ "hsla",                        &Color::Factory::hsla },
				{ "interpolate",                 &Color::Factory::interpolate },
				{ "match",                       &Color::Factory::match },
				{ "rgb",                         &Color::Factory::rgb },
				{ "rgba",                        &Color::Factory::rgba },
				{ "step",                        &Color::Factory::step },
				{ "to-color-from-color",         &Color::Factory::fromColor },
				{ "to-color-from-feature-state", &Color::Factory::fromColor },
				{ "to-color-from-get",           &Color::Factory::fromColor },
				{ "to-color-from-string",        &Color::Factory::fromString },
			};

			// add suffix (might be blank)
			std::string_view suffix = Factory::suffix(j);

			std::string name = std::string(j[0]) + std::string(suffix);
			auto iter = sFunctions.find(name);
			ColorFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static NumberFunc GetNumberFunc(nlohmann::json const& j)
	{
		if (j.is_number()) { return &Number::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, NumberFunc> const sFunctions =
			{
				{ "-",                            &Number::Factory::subtract },
				{ "*",                            &Number::Factory::product },
				{ "/",                            &Number::Factory::divide },
				{ "%",                            &Number::Factory::modulo },
				{ "^",                            &Number::Factory::exponentiate },
				{ "+",                            &Number::Factory::sum },
				{ "abs",                          &Number::Factory::abs },
				{ "case",                         &Number::Factory::cases },
				{ "context",	                  &Number::Factory::context },
				{ "feature-state",                &Number::Factory::featureState },
				{ "get",                          &Number::Factory::get },
				{ "heading",                      &Number::Factory::heading },
				{ "index-of",                     &Number::Factory::indexof },
				{ "interpolate",                  &Number::Factory::interpolate },
				{ "length",                       &Number::Factory::length },
				{ "match",                        &Number::Factory::match },
				{ "number",                       &Number::Factory::asserts },
				{ "pitch",                        &Number::Factory::pitch },
				{ "dpi-scalar",                    &Number::Factory::dpiScalar },
				{ "step",                         &Number::Factory::step },
				{ "to-number-from-boolean",       &Number::Factory::fromBoolean },
				{ "to-number-from-feature-state", &Number::Factory::fromNumber },
				{ "to-number-from-get",           &Number::Factory::fromNumber },
				{ "to-number-from-string",        &Number::Factory::fromString },
				{ "to-number-from-number",        &Number::Factory::fromNumber },
				{ "zoom",                         &Number::Factory::zoom },
			};

			// add suffix (might be blank)
			std::string_view suffix = Factory::suffix(j);

			std::string const& name = std::string(j[0]) + std::string(suffix);
			auto iter = sFunctions.find(name);
			NumberFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static StringFunc GetStringFunc(nlohmann::json const& j)
	{
		if (j.is_string()) { return &String::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, StringFunc> const sFunctions =
			{
				{ "case",                         &String::Factory::cases },
				{ "concat",                       &String::Factory::concat },
				{ "context",                      &String::Factory::context },
				{ "downcase",                     &String::Factory::downcase },
				{ "feature-state",                &String::Factory::featureState },
				{ "get",                          &String::Factory::get },
				{ "match",                        &String::Factory::match },
				{ "slice",                        &String::Factory::slice },
				{ "step",                         &String::Factory::step },
				{ "string",                       &String::Factory::asserts },
				{ "to-string-from-boolean",       &String::Factory::fromBoolean },
				{ "to-string-from-color",         &String::Factory::fromColor },
				{ "to-string-from-feature-state", &String::Factory::fromString },
				{ "to-string-from-get",           &String::Factory::fromString },
				{ "to-string-from-string",        &String::Factory::fromString },
				{ "to-string-from-number",        &String::Factory::fromNumber },
				{ "upcase",                       &String::Factory::upcase },
			};

			// add suffix (might be blank)
			std::string_view suffix = Factory::suffix(j);

			std::string name = std::string(j[0]) + std::string(suffix);
			auto iter = sFunctions.find(name);
			StringFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static RangeFunc GetRangeFunc(nlohmann::json const& j)
	{
		if (j.is_array())
		{
			static std::unordered_map<std::string_view, RangeFunc> const sFunctions =
			{
				{ "case",    &Range::Factory::cases },
				{ "context", &Range::Factory::context },
				{ "range",   &Range::Factory::amorphousRange },
				{ "match",   &Range::Factory::match },
				{ "step",    &Range::Factory::step },
			};

			std::string name = j[0];
			auto iter = sFunctions.find(name);
			RangeFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static ResolvedImageFunc GetResolvedImageFunc(nlohmann::json const& j)
	{
		if (j.is_string()) { return &Image::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, ResolvedImageFunc> const sFunctions =
			{
				{ "case",    &Image::Factory::cases },
				{ "context", &Image::Factory::context },
				{ "image",   &Image::Factory::amorphousImage },
				{ "match",   &Image::Factory::match },
				{ "step",    &Image::Factory::step },
			};

			std::string const& name = std::string(j[0]);
			auto iter = sFunctions.find(name);
			if (iter != sFunctions.end())	// if we have a factory function, return it
			{
				return iter->second;
			}
			else // if we don't have a function, test if this is a string expression
			{
				return (GetStringFunc(j)) ? &Image::Factory::fromString : nullptr;
			}
		}

		return nullptr;
	}

	static GradientFunc GetGradientFunc(nlohmann::json const& j)
	{
		if (j.is_array())
		{
			static std::unordered_map<std::string_view, GradientFunc> const sFunctions =
			{
				{ "case",     &Gradient::Factory::cases },
				{ "context",  &Gradient::Factory::context },
				{ "gradient", &Gradient::Factory::constant },
				{ "match",    &Gradient::Factory::match },
				{ "step",     &Gradient::Factory::step },
			};

			std::string name = j[0];
			auto iter = sFunctions.find(name);
			GradientFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static FormatFunc GetFormatFunc(nlohmann::json const& j)
	{
		if (j.is_string()) { return &Format::Factory::fromString; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, FormatFunc> const sFunctions =
			{
				{ "case",                        &Format::Factory::cases },
				{ "context",	                 &Format::Factory::context },
				{ "format",                      &Format::Factory::amorphousFormatted },
				{ "match",                       &Format::Factory::match },
				{ "step",                        &Format::Factory::step },
			};

			std::string name = std::string(j[0]);
			auto iter = sFunctions.find(name);
			if (iter != sFunctions.end())	// if we have a factory function, return it
			{
				return iter->second;
			}
			else // if we don't have a function, test if this is a string expression
			{
				return (GetStringFunc(j)) ? &Format::Factory::fromString : nullptr;
			}
		}

		return nullptr;
	}

	template<typename OutputT> static bool ParsesPrimitive(nlohmann::json const& j) = delete;
	template<> bool ParsesPrimitive<bool>            (nlohmann::json const& j) { return j.is_boolean(); }
	template<> bool ParsesPrimitive<lgal::Color>     (nlohmann::json const& j) { return j.is_string(); }
	template<> bool ParsesPrimitive<float>           (nlohmann::json const& j) { return j.is_number(); }
	template<> bool ParsesPrimitive<std::string>     (nlohmann::json const& j) { return j.is_string(); }

	template<typename PrimitiveT>
	using ArrayMapT = std::unordered_map<std::string_view, ArrayFunc<PrimitiveT>>;

	template<typename T>
	ArrayMapT<T> ArrayFunctionsBase()
	{
		return
		{
			{ "case",    &Array::Factory::cases<T> },
			{ "match",   &Array::Factory::match<T> },
			{ "step",    &Array::Factory::step<T> },
		};
	}

	template<typename PrimitiveT>
	ArrayMapT<PrimitiveT> PrimitiveArrayFunctionsBase()
	{
		ArrayMapT<PrimitiveT> funcs = ArrayFunctionsBase<PrimitiveT>();
		funcs.insert({ "literal", &Array::Factory::literal<PrimitiveT> });
		return funcs;
	}

	// NOTE: for some unknown reason, declaring the function like the commented section means the template specialization cannot recognize the base
	// template. The more verbose version works so I am leaving it there for now
	// template<typename PrimitiveT>
	// ArrayMapT<PrimitiveT> ArrayFunctions()
	template<typename PrimitiveT>
	std::unordered_map<std::string_view, std::function<typename std::unique_ptr<ExpressionType<std::vector<PrimitiveT>> const>(nlohmann::json const&)>> PrimitiveArrayFunctions()
	{
		return PrimitiveArrayFunctionsBase<PrimitiveT>();
	}
	
	template<>
	ArrayMapT<float> PrimitiveArrayFunctions()
	{
		ArrayMapT<float> funcs = PrimitiveArrayFunctionsBase<float>();
		funcs.insert({ "interpolate", &Array::Factory::interpolate });
		return funcs;
	}

	template<typename PrimitiveT>
	static ArrayFunc<PrimitiveT> GetPrimitiveArrayFunc(nlohmann::json const& j)
	{
		if (j.is_array())
		{
			ONYX_ASSERT(j.size() > 0, "Array expression is empty");

			bool primitives = true;
			for (auto const& item : j)
			{
				if (!ParsesPrimitive<PrimitiveT>(item)) { primitives = false; }
			}
			if (primitives) { return &Array::Factory::constant<PrimitiveT>; }
			
			static ArrayMapT<PrimitiveT> const sFunctions = PrimitiveArrayFunctions<PrimitiveT>();

			std::string const& name = j[0];
			auto it = sFunctions.find(name);
			return (it != sFunctions.end()) ? it->second : nullptr;
		}

		return nullptr;
	}

	template<typename T>
	static ArrayFunc<T> GetNonPrimitiveArrayFunc(nlohmann::json const& j)
	{
		if (j.is_array())
		{
			ONYX_ASSERT(j.size() > 0, "Array expression is empty");

			bool expressions = true;
			for (auto const& item : j)
			{
				if (!item.is_array()) { expressions = false; }
			}
			if (expressions) { return &Array::Factory::amorphousArray<T>; }

			static ArrayMapT<T> const sFunctions = ArrayFunctionsBase<T>();

			std::string const& name = j[0];
			auto it = sFunctions.find(name);
			return (it != sFunctions.end()) ? it->second : nullptr;
		}

		return nullptr;
	}

	BooleanT::Ptr boolean(nlohmann::json const& j)
	{
		BooleanFunc func = GetBooleanFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid Boolean expression");
			return nullptr;
		}
	}

	ColorT::Ptr color(nlohmann::json const& j)
	{
		ColorFunc func = GetColorFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid Color expression");
			return nullptr;
		}
	}

	FormattedT::Ptr format(nlohmann::json const& j)
	{
		FormatFunc func = GetFormatFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid Format expression");
			return nullptr;
		}
	}


	NumberT::Ptr number(nlohmann::json const& j)
	{
		NumberFunc func = GetNumberFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid Number expression");
			return nullptr;
		}
	}

	ResolvedImageT::Ptr image(nlohmann::json const& j)
	{
		ResolvedImageFunc func = GetResolvedImageFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid ResolvedImage expression");
			return nullptr;
		}
	}

	RangeT::Ptr range(nlohmann::json const& j)
	{
		RangeFunc func = GetRangeFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid Range expression");
			return nullptr;
		}
	}

	StringT::Ptr string(nlohmann::json const& j)
	{
		StringFunc func = GetStringFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid String expression");
			return nullptr;
		}
	}

	GradientT::Ptr gradient(nlohmann::json const& j)
	{
		GradientFunc func = GetGradientFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid Gradient expression");
			return nullptr;
		}
	}

	BooleanArrayT::Ptr booleans(nlohmann::json const& j)
	{
		BooleanArrayFunc func = GetPrimitiveArrayFunc<bool>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid BooleanArray expression");
			return nullptr;
		}
	}

	ColorArrayT::Ptr colors(nlohmann::json const& j)
	{
		ColorArrayFunc func = GetPrimitiveArrayFunc<lgal::Color>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid ColorArray expression");
			return nullptr;
		}
	}

	NumberArrayT::Ptr numbers(nlohmann::json const& j)
	{
		NumberArrayFunc func = GetPrimitiveArrayFunc<float>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid NumberArray expression");
			return nullptr;
		}
	}

	RangeArrayT::Ptr ranges(nlohmann::json const& j)
	{
		RangeArrayFunc func = GetNonPrimitiveArrayFunc<lgal::gpu::Range>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid RangeArray expression");
			return nullptr;
		}
	}

	StringArrayT::Ptr strings(nlohmann::json const& j)
	{
		StringArrayFunc func = GetPrimitiveArrayFunc<std::string>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			ONYX_THROW("Invalid StringArray expression");
			return nullptr;
		}
	}

	bool isFeatureState(nlohmann::json const& j)
	{
		if (j.is_array() && j.size() == 2)
		{
			auto key = j[0];
			if (key.is_string())
			{
				std::string str = key;
				return str == "feature-state";
			}
		}

		// default to false
		return false;
	}

	bool isGet(nlohmann::json const& j)
	{
		if (j.is_array() && j.size() == 2)
		{
			auto key = j[0];
			if (key.is_string())
			{
				std::string str = key;
				return str == "get";
			}
		}

		// default to false
		return false;
	}

	Parsers available(nlohmann::json const& j)
	{
		Parsers parsers = Parsers::NONE;
		parsers |= (GetBooleanFunc(j) != nullptr) ? Parsers::BOOLEAN : Parsers::NONE;	// whether we have a function to parse this as a boolean
		parsers |= (GetColorFunc(j) != nullptr) ? Parsers::COLOR : Parsers::NONE;	// whether we have a function to parse this as a color
		parsers |= (GetFormatFunc(j) != nullptr) ? Parsers::FORMAT : Parsers::NONE;	// whether we have a function to parse this as a format
		parsers |= (GetResolvedImageFunc(j) != nullptr) ? Parsers::IMAGE : Parsers::NONE;	// whether we have a function to parse this as an image
		parsers |= (GetNumberFunc(j) != nullptr) ? Parsers::NUMBER : Parsers::NONE;	// whether we have a function to parse this as a number
		parsers |= (GetRangeFunc(j) != nullptr) ? Parsers::RANGE : Parsers::NONE;	// whether we have a function to parse this as a range
		parsers |= (GetStringFunc(j) != nullptr) ? Parsers::STRING : Parsers::NONE;	// whether we have a function to parse this as a string
		parsers |= (GetGradientFunc(j) != nullptr) ? Parsers::GRADIENT : Parsers::NONE;	// whether we have a function to parse this as a gradient
		parsers |= (GetPrimitiveArrayFunc<bool>(j) != nullptr) ? Parsers::BOOLEAN_ARRAY : Parsers::NONE;	// whether we have a function to parse this as a boolean array
		parsers |= (GetPrimitiveArrayFunc<lgal::Color>(j) != nullptr) ? Parsers::COLOR_ARRAY : Parsers::NONE;	// whether we have a function to parse this as a color array
		parsers |= (GetPrimitiveArrayFunc<float>(j) != nullptr) ? Parsers::NUMBER_ARRAY : Parsers::NONE;	// whether we have a function to parse this as a number array
		parsers |= (GetNonPrimitiveArrayFunc<lgal::gpu::Range>(j) != nullptr) ? Parsers::RANGE_ARRY : Parsers::NONE;	// whether we have a function to parse this as a range array
		parsers |= (GetPrimitiveArrayFunc<std::string>(j) != nullptr) ? Parsers::STRING_ARRAY : Parsers::NONE;	// whether we have a function to parse this as a string array
		return parsers;
	}

} } } }