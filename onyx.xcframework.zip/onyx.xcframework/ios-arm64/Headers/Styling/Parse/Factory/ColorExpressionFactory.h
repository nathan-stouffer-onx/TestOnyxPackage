#ifndef __STYLING_COLOR_EXPRESSION_FACTORY_H__
#define __STYLING_COLOR_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>

#include "Styling/Expressions/ColorExpressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Color {
namespace Factory {

	std::unique_ptr<Context		const> context    (nlohmann::json const& j);
	std::unique_ptr<Constant    const> constant   (nlohmann::json const& j);
	std::unique_ptr<Get         const> get        (nlohmann::json const& j);
	std::unique_ptr<Interpolate const> interpolate(nlohmann::json const& j);
	std::unique_ptr<Step        const> step       (nlohmann::json const& j);
	std::unique_ptr<Case        const> cases      (nlohmann::json const& j);	// deviated from pattern for function name cases because 'case' is C++ syntax
	std::unique_ptr<Match       const> match      (nlohmann::json const& j);

} } } } }

#endif