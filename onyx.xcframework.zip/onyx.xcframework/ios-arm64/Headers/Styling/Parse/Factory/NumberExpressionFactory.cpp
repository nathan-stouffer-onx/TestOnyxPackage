#include "NumberExpressionFactory.h"

#include <System/Map3DException.h>

#include "Styling/Parse/Factory/ExpressionFactory.h"
#include "Styling/Parse/Factory/InterpolationFactory.h"
#include "Styling/Parse/Factory/ContextFactory.h"
#include "Styling/Parse/Factory/MatcherFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Number {
namespace Factory {

	std::unique_ptr<Context	const> context(nlohmann::json const& j)
	{
		return Expressions::Context::Factory::read<float>(j);
	}

	std::unique_ptr<Constant const> constant(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.is_number(), "Constant math expression must be a number");
		double value = 0.0;
		j.get_to(value);
		return std::make_unique<Constant const>(static_cast<float>(value));
	}

	std::unique_ptr<Pitch const> pitch(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "pitch", "First value in a Pitch expression must be 'pitch'");
		MAP3D_ASSERT(j.size() == 1, "Pitch expression must have exactly one element");
		return std::make_unique<Pitch>();
	}

	std::unique_ptr<Zoom const> zoom(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "zoom", "First value in a Zoom expression must be 'zoom'");
		MAP3D_ASSERT(j.size() == 1, "Zoom expression must have exactly one element");
		return std::make_unique<Zoom>();
	}

	std::unique_ptr<Get const> get(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Get must have 2 elements");
		MAP3D_ASSERT(j[0] == "get", "First element of Get expression must be 'get'");
		MAP3D_ASSERT(j[1].is_string(), "Second element of Get expression must be a string");
		std::string const& str = j[1];
		return std::make_unique<Get const>(str);
	}

	std::unique_ptr<IndexOf const> indexof(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 3 || j.size() == 4, "IndexOf must have 3 or 4 elements");
		MAP3D_ASSERT(j[0] == "index-of", "First element of IndexOf expression must be 'index-of'");

		auto keyword = Expressions::Factory::string(j[1]);
		auto input = Expressions::Factory::string(j[2]);
		auto begin = (j.size() == 4) ? Expressions::Factory::number(j[3]) : nullptr;
		return std::make_unique<IndexOf const>(std::move(keyword), std::move(input), std::move(begin));
	}

	std::unique_ptr<Length const> length(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j.size() == 2, "Length must have 2 elements");
		MAP3D_ASSERT(j[0] == "length", "First element of Length expression must be 'length'");
		return std::make_unique<Length const>(Expressions::Factory::string(j[1]));
	}
	
	std::unique_ptr<Interpolate const> interpolate(nlohmann::json const& j)
	{
		return Interpolation::Factory::interpolate<float>(j);
	}

	std::unique_ptr<Step const> step(nlohmann::json const& j)
	{
		return Interpolation::Factory::step<float>(j);
	}

	std::unique_ptr<Case const> cases(nlohmann::json const& j)
	{
		return Decision::Factory::cases<float>(j);
	}

	std::unique_ptr<Match const> match(nlohmann::json const& j)
	{
		std::unique_ptr<Decision::Matcher<float> const> matcher = Decision::Factory::matcher<float>(j);
		return std::make_unique<Match const>(std::move(matcher));
	}

	std::unique_ptr<Subtract const> subtract(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "-", "First value in a Subtract expression must be '-'");
		MAP3D_ASSERT(j.size() == 2 || j.size() == 3, "Subtract expression must have exactly 2 or 3 elements");

		if (j.size() == 2)
		{
			auto term = Expressions::Factory::number(j[1]);
			return std::make_unique<Subtract const>(std::move(term));
		}
		else
		{
			auto term0 = Expressions::Factory::number(j[1]);
			auto term1 = Expressions::Factory::number(j[2]);
			return std::make_unique<Subtract const>(std::move(term0), std::move(term1));
		}
	}

	std::unique_ptr<Product const> product(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "*", "First value in a Product expression must be '*'");
		MAP3D_ASSERT(j.size() >= 3, "Product expression must have at least 3 elements");

		auto term0 = Expressions::Factory::number(j[1]);
		auto term1 = Expressions::Factory::number(j[2]);
		std::vector<NumberT::Ptr> additional;
		for (size_t i = 3; i < j.size(); ++i)
		{
			additional.push_back(Expressions::Factory::number(j[i]));
		}
		return std::make_unique<Product const>(std::move(term0), std::move(term1), std::move(additional));
	}

	std::unique_ptr<Divide const> divide(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "/", "First value in a Divide expression must be '/'");
		MAP3D_ASSERT(j.size() == 3, "Divide expression must have exactly 3 elements");

		auto term0 = Expressions::Factory::number(j[1]);
		auto term1 = Expressions::Factory::number(j[2]);
		return std::make_unique<Divide const>(std::move(term0), std::move(term1));
	}

	std::unique_ptr<Modulo const> modulo(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "%", "First value in a Modulo expression must be '%'");
		MAP3D_ASSERT(j.size() == 3, "Modulo expression must have exactly 3 elements");

		auto term0 = Expressions::Factory::number(j[1]);
		auto term1 = Expressions::Factory::number(j[2]);
		return std::make_unique<Modulo const>(std::move(term0), std::move(term1));
	}

	std::unique_ptr<Exponentiate const> exponentiate(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "^", "First value in a Exponentiate expression must be '^'");
		MAP3D_ASSERT(j.size() == 3, "Exponentiate expression must have exactly 3 elements");

		auto term0 = Expressions::Factory::number(j[1]);
		auto term1 = Expressions::Factory::number(j[2]);
		return std::make_unique<Exponentiate const>(std::move(term0), std::move(term1));
	}

	std::unique_ptr<Sum const> sum(nlohmann::json const& j)
	{
		MAP3D_ASSERT(j[0] == "+", "First value in a Sum expression must be '+'");
		MAP3D_ASSERT(j.size() >= 3, "Sum expression must have at least 3 elements");

		auto term0 = Expressions::Factory::number(j[1]);
		auto term1 = Expressions::Factory::number(j[2]);
		std::vector<NumberT::Ptr> additional;
		for (size_t i = 3; i < j.size(); ++i)
		{
			additional.push_back(Expressions::Factory::number(j[i]));
		}
		return std::make_unique<Sum const>(std::move(term0), std::move(term1), std::move(additional));
	}

} } } } }