#include "SourceFactory.h"

#include <json/jsonParsing.h>

#include "Styling/Sources/TiledSources/RasterSource.h"
#include "Styling/Sources/TiledSources/RasterDemSource.h"
#include "Styling/Sources/TiledSources/VectorSource.h"
#include "Styling/Sources/GeojsonSource.h"

#include "Styling/Parse/SourceJson.h"

namespace onyx {
namespace Styling {
namespace Factory {

	template<typename T>
	static inline std::unique_ptr<Source> ConstructSource(nlohmann::json const& j)
	{
		std::unique_ptr<T> source = std::make_unique<T>();
		from_json(j, *source);
		return source;
	}

	std::unique_ptr<Source> source(nlohmann::json const& json)
	{
		Source source;
		from_json(json, source);

		switch (source.type)
		{
			case Source::Types::RASTER:     return ConstructSource<RasterSource>(json);    break;
			case Source::Types::RASTER_DEM: return ConstructSource<RasterDemSource>(json); break;
			case Source::Types::VECTOR:     return ConstructSource<VectorSource>(json);    break;
			case Source::Types::GEOJSON:    return ConstructSource<GeojsonSource>(json);   break;
			default:                       ONYX_THROW("Source::Type not found")          break;
		}

		return std::unique_ptr<Source>(nullptr);
	}

} } }