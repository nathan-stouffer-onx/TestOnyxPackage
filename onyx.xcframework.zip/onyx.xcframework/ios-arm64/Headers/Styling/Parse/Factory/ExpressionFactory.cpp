#include "ExpressionFactory.h"

#include <functional>
#include <unordered_map>
#include <unordered_set>

#include <Logging/LogManager.h>
#include <System/Map3DException.h>

#include "Styling/Parse/Factory/ArrayExpressionFactory.h"
#include "Styling/Parse/Factory/BooleanExpressionFactory.h"
#include "Styling/Parse/Factory/ColorExpressionFactory.h"
#include "Styling/Parse/Factory/NumberExpressionFactory.h"
#include "Styling/Parse/Factory/StringExpressionFactory.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Factory {

	static bool ExactlyOneParser(Parsers parsers)
	{
		return parsers == Parsers::BOOLEAN
				|| parsers == Parsers::COLOR
				|| parsers == Parsers::NUMBER
				|| parsers == Parsers::STRING
				|| parsers == Parsers::BOOLEAN_ARRAY
				|| parsers == Parsers::COLOR_ARRAY
				|| parsers == Parsers::NUMBER_ARRAY
				|| parsers == Parsers::STRING_ARRAY;
	}

	// Function that returns the appropriate operator prefix to use. The types on either side of the operator are inferred based
	// on the operand. If an operand is known to return only one type (eg , it is called exact.
	// Many times, it cannot be uniquely determined what type an operand will return. We have the following situations
	//   * both sides are exact and those types are equal                       => return type as the prefix
	//   * both sides are exact and those types are not equal                   => throw exception (invalid operator)
	//   * one side is exact and the other side can convert to that type        => return the known type
	//   * one side is string or color and the other side can convert to string => return string as the type
	static std::string_view OperatorPrefix(nlohmann::json const& j)
	{
		static std::unordered_set<std::string_view> sComparisons = { "!=", "==", "<", "<=", ">=", ">" };
		std::string const& name = j[0];
		bool contains = sComparisons.count(name) > 0;
		if (contains)
		{
			// make sure the expression is of the correct form
			MAP3D_ASSERT(j.size() == 3, "Comparison expression must have exactly 3 elements");

			// compute the available parsers
			Parsers lhs = available(j[1]);
			Parsers rhs = available(j[2]);

			// compute if there are any exact expressions
			bool lhsExact = ExactlyOneParser(lhs);
			bool rhsExact = ExactlyOneParser(rhs);

			Parsers parser = Parsers::NONE;
			Parsers stringOrColor = Parsers::COLOR | Parsers::STRING;

			if (lhsExact && rhsExact)	// if both are exact and identify the same type, make sure they are the same and use either one
			{
				if (lhs != rhs)
				{
					MAP3D_THROW("Attempting to compare two non-equal types");
				}
				else
				{
					parser = lhs;
				}
			}
			else if (lhsExact)			// if only the lhs is exact, make sure the rhs can convert and use the lhs
			{
				MAP3D_ASSERT((lhs & rhs) != Parsers::NONE, "Attempting to compare two types that cannot be parsed to the same type");
				parser = lhs;
			}
			else if (rhsExact)			// if only the rhs is exact, make sure the lhs can convert and use the rhs
			{
				MAP3D_ASSERT((lhs & rhs) != Parsers::NONE, "Attempting to compare two types that cannot be parsed to the same type");
				parser = rhs;
			}
			else if (lhs == stringOrColor)	// if the lhs could be either a string or a color, assume a string and make sure the rhs can be parsed as a string
			{
				MAP3D_ASSERT((rhs & Parsers::STRING) != Parsers::NONE, "Attempting to compare type to string that cannot be parsed to a string");
				parser = Parsers::STRING;
			}
			else if (rhs == stringOrColor)	// if the rhs could be either a string or a color, assume a string and make sure the lhs can be parsed as a string
			{
				MAP3D_ASSERT((lhs & Parsers::STRING) != Parsers::NONE, "Attempting to compare type to string that cannot be parsed to a string");
				parser = Parsers::STRING;
			}

			switch (parser)
			{
				case Parsers::NONE:    MAP3D_THROW("Invalid expression"); break;
				case Parsers::BOOLEAN: return "boolean";                  break;
				case Parsers::COLOR:   return "color";					  break;
				case Parsers::NUMBER:  return "number";                   break;
				case Parsers::STRING:  return "string";                   break;
				case Parsers::ALL:     // intentionally fall through to default
				default: MAP3D_THROW("Return types are ambiguous for comparison operator");
			}
		}

		// default to no prefix
		return "";
	}

	using BooleanFunc = std::function<BooleanT::Ptr(nlohmann::json const&)>;
	using ColorFunc = std::function<ColorT::Ptr(nlohmann::json const&)>;
	using NumberFunc = std::function<NumberT::Ptr(nlohmann::json const&)>;
	using StringFunc = std::function<StringT::Ptr(nlohmann::json const&)>;

	template<typename OutputT>
	using ArrayFunc = std::function<typename ArrayT<OutputT>::Ptr(nlohmann::json const&)>;

	using BooleanArrayFunc = ArrayFunc<bool>;
	using ColorArrayFunc = ArrayFunc<lgal::Color>;
	using NumberArrayFunc = ArrayFunc<float>;
	using StringArrayFunc = ArrayFunc<std::string>;

	static BooleanFunc GetBooleanFunc(nlohmann::json const& j)
	{
		if (j.is_boolean()) { return &Boolean::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, BooleanFunc> const sFunctions =
			{
				{ "context",   &Boolean::Factory::context },
				{ "get",       &Boolean::Factory::get },
				{ "has",       &Boolean::Factory::has },
				{ "step",      &Boolean::Factory::step },
				{ "case",      &Boolean::Factory::cases },
				{ "match",     &Boolean::Factory::match },
				{ "all",       &Boolean::Factory::all },
				{ "any",       &Boolean::Factory::any },
				{ "!",         &Boolean::Factory::negate },
				{ "boolean==", &Boolean::Factory::booleanEquals },
				{ "color==",   &Boolean::Factory::colorEquals },
				{ "number==",  &Boolean::Factory::numberEquals },
				{ "string==",  &Boolean::Factory::stringEquals },
				{ "boolean!=", &Boolean::Factory::booleanNotEquals },
				{ "color!=",   &Boolean::Factory::colorNotEquals },
				{ "number!=",  &Boolean::Factory::numberNotEquals },
				{ "string!=",  &Boolean::Factory::stringNotEquals },
				{ "number<",   &Boolean::Factory::numberLessThan },
				{ "number>",   &Boolean::Factory::numberGreaterThan },
				{ "number<=",  &Boolean::Factory::numberLEQ },
				{ "number>=",  &Boolean::Factory::numberGEQ },
				{ "string<",   &Boolean::Factory::stringLessThan },
				{ "string>",   &Boolean::Factory::stringGreaterThan },
				{ "string<=",  &Boolean::Factory::stringLEQ },
				{ "string>=",  &Boolean::Factory::stringGEQ },
			};

			// add prefix (might be blank)
			std::string_view prefix = OperatorPrefix(j);

			std::string name = std::string(prefix) + std::string(j[0]);
			auto iter = sFunctions.find(name);
			BooleanFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}
		
		return nullptr;
	}

	static ColorFunc GetColorFunc(nlohmann::json const& j)
	{
		if (j.is_string()) { return &Color::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, ColorFunc> const sFunctions =
			{
				{ "context",	 &Color::Factory::context },
				{ "get",         &Color::Factory::get },
				{ "interpolate", &Color::Factory::interpolate },
				{ "step",        &Color::Factory::step },
				{ "case",        &Color::Factory::cases },
				{ "match",       &Color::Factory::match },
			};

			std::string const& name = j[0];
			auto iter = sFunctions.find(name);
			ColorFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static NumberFunc GetNumberFunc(nlohmann::json const& j)
	{
		if (j.is_number()) { return &Number::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, NumberFunc> const sFunctions =
			{
				{ "context",	 &Number::Factory::context },
				{ "pitch",       &Number::Factory::pitch },
				{ "zoom",        &Number::Factory::zoom },
				{ "get",         &Number::Factory::get },
				{ "index-of",    &Number::Factory::indexof },
				{ "length",      &Number::Factory::length },
				{ "-",           &Number::Factory::subtract },
				{ "*",           &Number::Factory::product },
				{ "/",           &Number::Factory::divide },
				{ "%",           &Number::Factory::modulo },
				{ "^",           &Number::Factory::exponentiate },
				{ "+",           &Number::Factory::sum },
				{ "interpolate", &Number::Factory::interpolate },
				{ "step",        &Number::Factory::step },
				{ "case",        &Number::Factory::cases },
				{ "match",       &Number::Factory::match },
			};

			std::string const& name = j[0];
			auto iter = sFunctions.find(name);
			NumberFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	static StringFunc GetStringFunc(nlohmann::json const& j)
	{
		if (j.is_string()) { return &String::Factory::constant; }
		else if (j.is_array())
		{
			static std::unordered_map<std::string_view, StringFunc> const sFunctions =
			{
				{ "context",  &String::Factory::context },
				{ "get",      &String::Factory::get },
				{ "downcase", &String::Factory::downcase },
				{ "upcase",   &String::Factory::upcase },
				{ "slice",    &String::Factory::slice },
				{ "step",     &String::Factory::step },
				{ "case",     &String::Factory::cases },
				{ "match",    &String::Factory::match },
			};

			std::string const& name = j[0];
			auto iter = sFunctions.find(name);
			StringFunc const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	template<typename OutputT> static bool CorrectJsonType(nlohmann::json const& j) = delete;
	template<> bool CorrectJsonType<bool>          (nlohmann::json const& j) { return j.is_boolean(); }
	template<> bool CorrectJsonType<lgal::Color>   (nlohmann::json const& j) { return j.is_string(); }
	template<> bool CorrectJsonType<float>         (nlohmann::json const& j) { return j.is_number(); }
	template<> bool CorrectJsonType<std::string>   (nlohmann::json const& j) { return j.is_string(); }

	template<typename OutputT>
	static ArrayFunc<OutputT> GetArrayFunc(nlohmann::json const& j)
	{
		if (j.is_array())
		{
			MAP3D_ASSERT(j.size() > 0, "Array expression is empty");
			
			bool allCorrectType = true;
			for (auto const& item : j)
			{
				if (!CorrectJsonType<OutputT>(item))
				{
					allCorrectType = false;
				}
			}
			if (allCorrectType) { return &Array::Factory::constant<OutputT>; }

			static std::unordered_map<std::string_view, ArrayFunc<OutputT>> const sFunctions =
			{
				{ "literal", &Array::Factory::literal<OutputT> },
				{ "step",    &Array::Factory::step<OutputT> },
				{ "case",    &Array::Factory::cases<OutputT> },
				{ "match",   &Array::Factory::match<OutputT> },
			};

			std::string const& name = j[0];
			auto iter = sFunctions.find(name);
			ArrayFunc<OutputT> const& func = (iter != sFunctions.end()) ? iter->second : nullptr;
			return func;
		}

		return nullptr;
	}

	Parsers available(nlohmann::json const& j)
	{
		Parsers parsers = Parsers::NONE;
		parsers |= (GetBooleanFunc(j)            != nullptr) ? Parsers::BOOLEAN       : Parsers::NONE;	// whether we have a function to parse this as a boolean
		parsers |= (GetColorFunc(j)              != nullptr) ? Parsers::COLOR         : Parsers::NONE;	// whether we have a function to parse this as a color
		parsers |= (GetNumberFunc(j)             != nullptr) ? Parsers::NUMBER        : Parsers::NONE;	// whether we have a function to parse this as a number
		parsers |= (GetStringFunc(j)             != nullptr) ? Parsers::STRING        : Parsers::NONE;	// whether we have a function to parse this as a string
		parsers |= (GetArrayFunc<bool>(j)        != nullptr) ? Parsers::BOOLEAN_ARRAY : Parsers::NONE;	// whether we have a function to parse this as a boolean array
		parsers |= (GetArrayFunc<lgal::Color>(j) != nullptr) ? Parsers::COLOR_ARRAY   : Parsers::NONE;	// whether we have a function to parse this as a color array
		parsers |= (GetArrayFunc<float>(j)       != nullptr) ? Parsers::NUMBER_ARRAY  : Parsers::NONE;	// whether we have a function to parse this as a number array
		parsers |= (GetArrayFunc<std::string>(j) != nullptr) ? Parsers::STRING_ARRAY  : Parsers::NONE;	// whether we have a function to parse this as a string array
		return parsers;
	}

	BooleanT::Ptr boolean(nlohmann::json const& j)
	{
		BooleanFunc func = GetBooleanFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid Boolean expression");
			return nullptr;
		}
	}

	ColorT::Ptr color(nlohmann::json const& j)
	{
		ColorFunc func = GetColorFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid Color expression");
			return nullptr;
		}
	}

	NumberT::Ptr number(nlohmann::json const& j)
	{
		NumberFunc func = GetNumberFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid Number expression");
			return nullptr;
		}
	}

	StringT::Ptr string(nlohmann::json const& j)
	{
		StringFunc func = GetStringFunc(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid String expression");
			return nullptr;
		}
	}

	BooleanArrayT::Ptr booleans(nlohmann::json const& j)
	{
		BooleanArrayFunc func = GetArrayFunc<bool>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid BooleanArray expression");
			return nullptr;
		}
	}

	ColorArrayT::Ptr colors(nlohmann::json const& j)
	{
		ColorArrayFunc func = GetArrayFunc<lgal::Color>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid ColorArray expression");
			return nullptr;
		}
	}

	NumberArrayT::Ptr numbers(nlohmann::json const& j)
	{
		NumberArrayFunc func = GetArrayFunc<float>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid NumberArray expression");
			return nullptr;
		}
	}

	StringArrayT::Ptr strings(nlohmann::json const& j)
	{
		StringArrayFunc func = GetArrayFunc<std::string>(j);
		if (func)
		{
			return func(j);
		}
		else
		{
			MAP3D_THROW("Invalid StringArray expression");
			return nullptr;
		}
	}

} } } }