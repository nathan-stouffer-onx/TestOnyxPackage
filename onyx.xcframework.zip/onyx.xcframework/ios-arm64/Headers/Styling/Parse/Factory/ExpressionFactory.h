#ifndef __STYLING_EXPRESSION_FACTORY_H__
#define __STYLING_EXPRESSION_FACTORY_H__

#include <3rdParty/nlohmann/json.hpp>
#include <Utils/BitwiseEnumOperators.h>

#include "Styling/Expressions/Expressions.h"

namespace onyx {
namespace Styling {
namespace Expressions {
namespace Factory {

	BooleanT::Ptr boolean(nlohmann::json const& j);
	ColorT::Ptr color(nlohmann::json const& j);
	NumberT::Ptr number(nlohmann::json const& j);
	StringT::Ptr string(nlohmann::json const& j);

	BooleanArrayT::Ptr booleans(nlohmann::json const& j);
	ColorArrayT::Ptr colors(nlohmann::json const& j);
	NumberArrayT::Ptr numbers(nlohmann::json const& j);
	StringArrayT::Ptr strings(nlohmann::json const& j);

	// delete generic template so that it can never be used
	template<typename OutputT> inline ExpressionPtr<OutputT>                  expr(nlohmann::json const& j) = delete;
	template<>                 inline ExpressionPtr<bool>                     expr(nlohmann::json const& j) { return boolean(j); }
	template<>                 inline ExpressionPtr<lgal::Color>              expr(nlohmann::json const& j) { return color(j); }
	template<>                 inline ExpressionPtr<float>                    expr(nlohmann::json const& j) { return number(j); }
	template<>                 inline ExpressionPtr<std::string>              expr(nlohmann::json const& j) { return string(j); }
	template<>                 inline ExpressionPtr<std::vector<bool>>        expr(nlohmann::json const& j) { return booleans(j); }
	template<>                 inline ExpressionPtr<std::vector<lgal::Color>> expr(nlohmann::json const& j) { return colors(j); }
	template<>                 inline ExpressionPtr<std::vector<float>>       expr(nlohmann::json const& j) { return numbers(j); }
	template<>                 inline ExpressionPtr<std::vector<std::string>> expr(nlohmann::json const& j) { return strings(j); }

	// enum that denotes what types of parsers that know how to work with a given expression
	enum class Parsers : uint8_t
	{
		NONE          = 0x0,
		BOOLEAN       = 0x1,
		COLOR         = 0x2,
		NUMBER        = 0x4,
		STRING        = 0x8,
		BOOLEAN_ARRAY = 0x10,
		COLOR_ARRAY   = 0x20,
		NUMBER_ARRAY  = 0x40,
		STRING_ARRAY  = 0x80,
		ALL = BOOLEAN | COLOR | NUMBER | STRING | BOOLEAN_ARRAY | COLOR_ARRAY | NUMBER_ARRAY | STRING_ARRAY
	};

	_FLAGS_ENUM_CLASS_BITWISE_OPERATORS(Parsers);

	// function to return the factory functions that have parsers available to deal with the given json
	Parsers available(nlohmann::json const& j);

} } } }

#endif