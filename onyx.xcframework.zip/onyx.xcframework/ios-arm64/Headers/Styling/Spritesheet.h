#ifndef __SPRITE_H__
#define __SPRITE_H__

#include <string>
#include <vector>
#include <unordered_map>
#include <lucid/gal/Types.h>

namespace onyx {
namespace Styling {

struct SpriteIndex
{
	std::string name = "";

	// 9/15 patch
	lgal::gpu::Vector4 offsets1; // x1, 2, 3, 4
	lgal::gpu::Vector4 offsets2; // x5, y1, 2, 3

	lgal::gpu::Vector2 sizePx;
	lgal::gpu::Vector4 uvOffset = { 0 };
	lgal::screen::Vector2 xy = { 0 };
	float pixelRatio = 1;
	
	lgal::array::AABB2d content = lgal::array::AABB2d::nothing();
};

struct Spritesheet
{
	// Does not include path extension (json, png)
	std::string path = "";
	std::unordered_map<std::string, SpriteIndex> indices;

	inline bool idxsLoaded() const { return !indices.empty(); }
	inline bool hasSprite(std::string const& key) const 
	{ 
		return indices.find(key) != indices.end(); 
	}
	inline SpriteIndex getSpriteIdx(std::string const& key) const
	{
		SpriteIndex toRet{};

		auto idxIter = indices.find(key);
		if (idxIter != indices.end()) toRet = idxIter->second;

		return toRet;
	}
};

} }

#endif