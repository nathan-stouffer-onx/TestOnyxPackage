#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <lucid/gal/Types.h>

#include "SpriteIdx.h"

namespace onyx::Styling {

struct Spritesheet
{
	// Does not include path extension (json, png)
	std::string path = "";
	std::unordered_map<std::string, SpriteIndex> indices;

	inline bool idxsLoaded() const { return !indices.empty(); }
	inline bool hasSprite(std::string const& key) const 
	{ 
		return indices.find(key) != indices.end(); 
	}
	inline SpriteIndex getSpriteIdx(std::string const& key) const
	{
		SpriteIndex toRet{};

		auto idxIter = indices.find(key);
		if (idxIter != indices.end()) toRet = idxIter->second;

		return toRet;
	}
};

}
