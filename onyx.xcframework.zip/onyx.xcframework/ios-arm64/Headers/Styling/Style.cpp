#include "Style.h"

#include <unordered_set>

namespace onyx {
namespace Styling {

	Style::Style() : Style{ std::make_unique<Expressions::ExpressionContext>(), std::make_unique<LayoutContext>(), std::make_unique<PaintContext>() } {}

	Style::Style(std::unique_ptr<Expressions::ExpressionContext> expressions, std::unique_ptr<LayoutContext> layouts, std::unique_ptr<PaintContext> paints)
		: mLayerIndex(&mLayers)
		, mExpressionContext(std::move(expressions))
		, mLayoutContext(std::move(layouts))
		, mPaintContext(std::move(paints))
	{}

	void Style::update()
	{
		mHasDirtySources = false;
		mHasDirtyLayers = false;
		mHasDirtyTerrain = false;

		mHasToggledLayers = false;

		mDirtySourceNames.clear();
		mAddedLayerIds.clear();
		mEditedLayerIds.clear();
		mRemovedLayerIds.clear();

		// TODO eventually, we can keep track of animations here?
	}

	void Style::addSource(std::string const& name, std::unique_ptr<Source> source)
	{
		mHasDirtySources = true;
		mDirtySourceNames.insert(name);
		std::shared_ptr<Source> src = std::move(source);
		mSources.insert_or_assign(name, src);

		if (mValidationEnabled) { validate(); }
	}

	void Style::removeSource(std::string const& name)
	{
		mSources.erase(name);

		if (mValidationEnabled) { validate(); }
	}

	void Style::setTerrain(std::unique_ptr<Terrain> terrain)
	{
		mHasDirtyTerrain = true;
		mTerrain = std::move(terrain);

		if (mValidationEnabled) { validate(); }
	}

	void Style::addLayer(std::unique_ptr<Layer> layer)
	{
		addLayer(std::move(layer), mLayers.end());
	}

	void Style::addLayer(std::unique_ptr<Layer> layer, std::string const& beforeId)
	{
		addLayer(std::move(layer), mLayerIndex.at(beforeId));
	}

	void Style::addLayer(std::unique_ptr<Layer> layer, size_t const beforeIdx)
	{
		addLayer(std::move(layer), mLayers.begin() + beforeIdx);
	}

	void Style::addLayer(std::unique_ptr<Layer> layer, LayersT::const_iterator pos)
	{
		// grab raw pointer to layer for use later in the function
		Layer* rawLayer = layer.get();

		mHasDirtyLayers = true;
		if (layer->isVisible())
		{
			mHasToggledLayers = true;
		}
		mAddedLayerIds.insert(layer->id);
		mLayers.insert(pos, std::move(layer));
		mLayerIndex.invalidate();

		if (mValidationEnabled) { validate(); }

		// if applicable, add reference to feature state
		if (rawLayer->isVector())
		{
			SourcedLayer* l = static_cast<SourcedLayer*>(rawLayer);
			Source& source = *mSources.at(l->source);
			source.states.insert({ l->sourceLayer, std::make_shared<FeatureStatesT>() });	// NOTE: insert only does something if an entry does not exist
			l->states = source.states[l->sourceLayer];
		}
	}

	void Style::removeLayer(std::string const& id)
	{
		mHasDirtyLayers = true;
		auto found = mLayerIndex.find(id);
		if (found != mLayerIndex.end())
		{
			auto it = found->second;
			if ((*it)->isVisible())
			{
				mHasToggledLayers = true;
			}
			mRemovedLayerIds.insert(id);
			mLayers.erase(it);
			mLayerIndex.invalidate();
		}
	}

	void Style::toggle(std::string const& layerId)
	{
		LayerIndex::const_iterator it = mLayerIndex.find(layerId);
		if (it != mLayerIndex.end())
		{
			std::shared_ptr<Layer> const& layer = *(it->second);
			LayoutBase::Visibility visibility = (layer->isVisible()) ? LayoutBase::Visibility::NONE : LayoutBase::Visibility::VISIBLE;
			layer->layout->visibility = visibility;

			mHasDirtyLayers = true;
			mHasToggledLayers = true;
			mEditedLayerIds.insert(layerId);
		}
	}

	void Style::toggle(std::string const& layerId, LayoutBase::Visibility visibility)
	{
		LayerIndex::const_iterator it = mLayerIndex.find(layerId);
		if (it != mLayerIndex.end())
		{
			std::shared_ptr<Layer> const& layer = *(it->second);
			if (layer->layout->visibility != visibility)
			{
				layer->layout->visibility = visibility;
				mHasDirtyLayers = true;
				mHasToggledLayers = true;
				mEditedLayerIds.insert(layerId);
			}
		}
	}

	void Style::toggleGroup(std::string const& group, LayoutBase::Visibility const visibility)
	{
		for (auto const& layer : layers())
		{
			if (layer->isElementOf(group))
			{
				toggle(layer->id, visibility);
			}
		}
	}

	void Style::index() const
	{
		mLayerIndex.index();
	}

	// TODO consider caching this and returning a std::vector<std::string> const&
	std::vector<std::string> Style::activeSources() const
	{
		std::set<std::string_view> inserted;
		std::vector<std::string> active;
		
		// check terrain
		if (hasTerrain())
		{
			active.push_back(mTerrain->source);
			inserted.insert(mTerrain->source);
		}

		// add the sources of visible layers
		for (auto const& layer : visibleLayers<Styling::SourcedLayer>())
		{
			if (inserted.find(layer->source) == inserted.end())
			{
				active.push_back(layer->source);
				inserted.insert(layer->source);
			}
		}

		return active;
	}

	std::set<std::string> Style::layerGroups() const
	{
		std::set<std::string> available;
		for (auto const& layer : layers())
		{
			available.insert(layer->groups.begin(), layer->groups.end());
		}
		return available;
	}

	void Style::markContextLayersAsEdited()
	{
		// to do this correctly, we must blindly mark all layers that depend on the expression context as edited
		InitArgs args = initArgs();
		for (auto& layer : mLayers)
		{
			if ((layer->dependencies(args) & Expressions::Dependencies::CONTEXT) != Expressions::Dependencies::NONE)
			{
				mEditedLayerIds.insert(layer->id);
			}
		}
	}

	// validation methods ---------------------------------------------------------------------------------------------------------------------------------------

	void Style::validate() const
	{
		ONYX_ASSERT(mVersion == 8, "Version must be 8");

		validateExpressionContext();
		validateLayoutContext();
		validatePaintContext();

		if (hasTerrain()) { validate(*mTerrain); }

		std::unordered_set<std::string_view> ids;		// using std::string_view because Layer::id is guaranteed to exist for the lifetime of this method
		for (std::shared_ptr<Layer const> layer : mLayers)
		{
			ONYX_ASSERT(ids.count(layer->id) == 0, "Style has duplicate layer names");
			ids.insert(layer->id);

			switch (layer->type)
			{
				case Layer::Types::BACKGROUND:        validate(static_cast<BackgroundLayer       const&>(*layer));  break;
				case Layer::Types::CIRCLE:            validate(static_cast<CircleLayer           const&>(*layer));  break;
				case Layer::Types::CONTOUR_LABEL:     validate(static_cast<ContourLabelLayer     const&>(*layer));  break;
				case Layer::Types::CONTOUR_LINE:      validate(static_cast<ContourLineLayer      const&>(*layer));  break;
				case Layer::Types::ELEVATION:         validate(static_cast<ElevationLayer        const&>(*layer));  break;
				case Layer::Types::FILL:              validate(static_cast<FillLayer             const&>(*layer));  break;
				case Layer::Types::INTERSECT:         validate(static_cast<IntersectLayer        const&>(*layer));  break;
				case Layer::Types::LINE:              validate(static_cast<LineLayer             const&>(*layer));  break;
				case Layer::Types::RASTER:            validate(static_cast<RasterLayer           const&>(*layer));  break;
				case Layer::Types::SLOPE_ANGLE:       validate(static_cast<SlopeAngleLayer       const&>(*layer));  break;
				case Layer::Types::SLOPE_ASPECT:      validate(static_cast<SlopeAspectLayer      const&>(*layer));  break;
				case Layer::Types::SUNLIGHT:          validate(static_cast<SunlightLayer         const&>(*layer));  break;
				case Layer::Types::SYMBOL:            validate(static_cast<SymbolLayer           const&>(*layer));  break;
				case Layer::Types::VIEWSHED:          validate(static_cast<ViewshedLayer         const&>(*layer));  break;
				default:
					ONYX_THROW("no validation method for Layer::Types::" + std::string(std::toStringView(layer->type)));
					break;
			}
		}
	}

	void Style::validateExpressionContext() const
	{
		// a validate call should be here for every return type that can be stored in the context
		ValidateExpressionContext<bool>(mExpressionContext);
		ValidateExpressionContext<lgal::Color>(mExpressionContext);
		ValidateExpressionContext<Formatted>(mExpressionContext);
		ValidateExpressionContext<gpu_float_t>(mExpressionContext);
		ValidateExpressionContext<ResolvedImage>(mExpressionContext);
		ValidateExpressionContext<std::string>(mExpressionContext);
		ValidateExpressionContext<Utils::Gradient>(mExpressionContext);
	}

	void Style::validateLayoutContext() const
	{
		// a validate call should be here for every layout type that can be stored in the context
		InitArgs args{ { mExpressionContext }, *mLayoutContext, *mPaintContext };
		ValidateLayoutContext<BackgroundLayout>(args);
		ValidateLayoutContext<CircleLayout>(args);
		ValidateLayoutContext<ContourLabelLayout>(args);
		ValidateLayoutContext<ContourLineLayout>(args);
		ValidateLayoutContext<ElevationLayout>(args);
		ValidateLayoutContext<FillLayout>(args);
		ValidateLayoutContext<IntersectLayout>(args);
		ValidateLayoutContext<LineLayout>(args);
		ValidateLayoutContext<RasterLayout>(args);
		ValidateLayoutContext<SlopeAngleLayout>(args);
		ValidateLayoutContext<SlopeAspectLayout>(args);
		ValidateLayoutContext<SunlightLayout>(args);
		ValidateLayoutContext<SymbolLayout>(args);
		ValidateLayoutContext<ViewshedLayout>(args);
	}

	void Style::validatePaintContext() const
	{
		// a validate call should be here for every paint type that can be stored in the context
		InitArgs args{ { mExpressionContext }, *mLayoutContext, *mPaintContext };
		ValidatePaintContext<BackgroundPaint>(args);
		ValidatePaintContext<CirclePaint>(args);
		ValidatePaintContext<ContourLabelPaint>(args);
		ValidatePaintContext<ContourLinePaint>(args);
		ValidatePaintContext<ElevationPaint>(args);
		ValidatePaintContext<FillPaint>(args);
		ValidatePaintContext<IntersectPaint>(args);
		ValidatePaintContext<LinePaint>(args);
		ValidatePaintContext<RasterPaint>(args);
		ValidatePaintContext<SlopeAnglePaint>(args);
		ValidatePaintContext<SlopeAspectPaint>(args);
		ValidatePaintContext<SunlightPaint>(args);
		ValidatePaintContext<SymbolPaint>(args);
		ValidatePaintContext<ViewshedPaint>(args);
	}

	void Style::validate(Terrain const& terrain) const
	{
		ONYX_ASSERT(hasSource(terrain.source), "Style does not have source '" + terrain.source + "'");
		auto const& src = mSources.at(terrain.source);
		ONYX_ASSERT(src->type == Source::Types::RASTER_DEM, "Terrain must reference a RASTER_DEM source");
		terrain.validate();
	}

	void Style::validate(Layer const& layer) const
	{
		layer.validate(InitArgs{ { mExpressionContext }, *mLayoutContext, *mPaintContext });
	}

	void Style::validate(SourcedLayer const& layer) const
	{
		ONYX_ASSERT(hasSource(layer.source), "Style does not have source '" + layer.source + "'");
		auto const& src = mSources.at(layer.source);
		layer.validate(*src);
		validate(static_cast<Layer const&>(layer));
	}

	bool Style::IsExpressionTree(std::deque<Expressions::ExpressionBase const*>& ancestors, Expressions::ExpressionBase const* current, Expressions::InitArgs args)
	{
		auto it = std::find(ancestors.begin(), ancestors.end(), current);
		if (it != ancestors.end()) { return false; }
		
		ancestors.push_back(current);
		for (auto const& child : current->children(args))
		{
			if (!IsExpressionTree(ancestors, child, args)) { return false; }
		}
		ancestors.pop_back();

		// made it through all checks => return true
		return true;
	}

} }