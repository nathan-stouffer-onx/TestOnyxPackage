#pragma once

#if !defined(JSON_PARSING_H_INCLUDED)
#define JSON_PARSING_H_INCLUDED

#include <functional>

#include <3rdParty/nlohmann/json.hpp>
#include <System/OnyxException.h>
#include <System/FileSystem.h>

namespace JsonParsing
{
	ONYX_EXCEPTION_TYPE(JsonParseError);

	template <typename T, typename KeyT>
	inline T Get(nlohmann::json const& json, KeyT const& propertyName, T const& defaultValue)
	{
		ONYX_TRY
			if (json.contains(propertyName))
			{
				T val;
				json.at(propertyName).get_to(val);
				return val;
			}
			else
			{
				return defaultValue;
			}
		ONYX_CATCH_ALL
			ONYX_CUSTOM_THROW(JsonParseError, std::string("error parsing propertyName: ") + propertyName);
		ONYX_END_CATCH
	}

	template <typename T>
	inline nlohmann::json Get(nlohmann::json const& json, std::string const& propertyName, T const& defaultValue)
	{
		return Get<T, std::string>(json, propertyName, defaultValue);
	}

	template <typename T, typename KeyT>
	inline bool SetIfFound(nlohmann::json const& json, KeyT const& propertyName, T& targetValue)
	{
		ONYX_TRY
			auto val = json.find(propertyName);
			if (val == json.end())
				return false;

			json.at(propertyName).get_to(targetValue);
			return true;
		ONYX_CATCH_ALL
			ONYX_CUSTOM_THROW(JsonParseError, std::string("error parsing propertyName: ") + propertyName);

		ONYX_END_CATCH
	}

	template <class T, typename defaultT, typename KeyT>
	inline bool SetIfFound(nlohmann::json const& json, KeyT const& propertyName, T& targetValue, defaultT const& defaultValue)
	{
		if (SetIfFound(json, propertyName, targetValue))
			return true;

		targetValue = defaultValue;
		return false;
	}

	template <class T, typename KeyT, class FuncT>
	inline bool SetPropIfFound(nlohmann::json const& json, KeyT const& propertyName, FuncT targetFun)
	{
		T value;
		if (SetIfFound(json, propertyName, value))
		{
			targetFun(value);
			return true;
		}

		return false;
	}

	template <class T, class Ex, typename KeyT>
	inline void RequireEx(nlohmann::json const& json, KeyT const& propertyName, T& targetValue, std::string const& errorMessage)
	{
		auto val = json.find(propertyName);
		if (val != json.end())
			json.at(propertyName).get_to(targetValue);
		else
			ONYX_CUSTOM_THROW(Ex, errorMessage);
	}

	template <class Ex, typename KeyT>
	inline void RequireEx(nlohmann::json const& json, KeyT const& propertyName, std::string const& errorMessage)
	{
		auto val = json.find(propertyName);
		if (val == json.end())
			ONYX_CUSTOM_THROW(Ex, errorMessage);
	}

	template <class T, typename KeyT>
	inline void Require(nlohmann::json const& json, KeyT const& propertyName, T& targetValue, std::string const& errorMessage)
	{
		RequireEx<T, JsonParseError, KeyT>(json, propertyName, targetValue, errorMessage);
	}

	template <class T, typename KeyT>
	inline T Require(nlohmann::json const& json, KeyT const& propertyName, std::string const& errorMessage)
	{
		T value;
		Require<T, KeyT>(json, propertyName, value, errorMessage);
		return value;
	}

	template <class T>
	inline T Require(nlohmann::json const& json, std::string const& propertyName, std::string const& errorMessage)
	{
		return Require<T, std::string>(json, propertyName, errorMessage);
	}

	template <typename KeyT>
	inline void Require(nlohmann::json const& json, KeyT const& propertyName, std::string const& errorMessage)
	{
		RequireEx<JsonParseError, KeyT>(json, propertyName, errorMessage);
	}

	template <class Ex, typename KeyT>
	inline void RequireNotFoundEx(nlohmann::json const& json, KeyT const& propertyName, std::string const& errorMessage)
	{
		auto val = json.find(propertyName);
		if (val != json.end())
			ONYX_CUSTOM_THROW(Ex, errorMessage);
	}

	template <typename KeyT>
	inline void RequireNotFound(nlohmann::json const& json, KeyT const& propertyName, std::string const& errorMessage)
	{
		RequireNotFoundEx<JsonParseError>(json, propertyName, errorMessage);
	}

	template <class Ex, typename KeyT>
	inline KeyT RequireOneFoundEx(nlohmann::json const& json, std::vector<KeyT> const& propertyNames, std::string const& errorMessage)
	{
		int count = 0;
		KeyT found;

		for (auto const& key : propertyNames)
		{
			auto val = json.find(key);
			if (val == json.end())
				continue;
			++count;
			if (count == 1)
				found = key;
			else
				ONYX_CUSTOM_THROW(Ex, errorMessage);
		}

		return found;
	}

	template <typename KeyT>
	inline std::string RequireOneFound(nlohmann::json const& json, std::vector<KeyT> const& propertyNames, std::string const& errorMessage)
	{
		return RequireOneFoundEx<JsonParseError, KeyT>(json, propertyNames, errorMessage);
	}
}


template<class T>
T ParseJsonText(std::string const& jsonText)
{
	ONYX_TRY
		auto j = nlohmann::json::parse(jsonText);

	return j.get<T>();
	ONYX_CATCH
		ONYX_CUSTOM_RETHROW(JsonParsing::JsonParseError, "Error parsing json text");

	ONYX_CATCH_ALL
		ONYX_CUSTOM_THROW(JsonParsing::JsonParseError, "Unhandled exception while parsing JSON");

	ONYX_END_CATCH
}

template<class T>
T ParseJsonFile(std::string const& fileName)
{
	auto data = onyx::core::FileSystem::readText(fileName);

	return ParseJsonText<T>(data);
}

#endif