#ifndef DEMOSTEP_H_
#define DEMOSTEP_H_

#include "bgfx/bgfx.h"
#include "bx/math.h"

#include <map>
#include <functional>
#include <mutex>
#include <vector>
#include <string>

class ShaderParam;

enum class DemoAction
{
	ChangeLod,

	PickVector,
	UnselectVector,

	EnableShaderComponent,
	DisableShaderComponent,
	SetShaderParams,
	SetShowStats,

	TransitionTo,
	InputDrag,
	
	SetPointerState,
	SetPointerPosition,

	SetCameraMode,

	LoadWaypoint,
	AddWaypoint,
	SelectWaypoint,
	UnselectWaypoint,
	UnselectAllWaypoints,
	MoveWaypointTo,
	SetWaypointIcon,
	SetWaypointIconColor,
	SetWaypointDiskColor,
	SetWaypointBodyColor,
	SetWaypointOutlineColor,
	DeleteWaypoint,
	DeleteSelectedWaypoints,

};

struct DemoStep
{
	DemoAction stepAction = (DemoAction)0;
	bx::Vec3 moveTo = bx::InitZero;
	float transitionTime = 1.0f;
	float stepTotalTime = -1; //seconds
	float stepCurrentTime = 0.0f;

	float dataFloat = 0;
	bx::Vec3 dataVec3 = bx::InitZero;
	bool dataBool = false;
	std::string dataString = "";
	int dataInt = -1;
	std::vector<ShaderParam> shaderParams; //probably a better way to store these than adding a special case variable, but this'll do for now

};
#endif
