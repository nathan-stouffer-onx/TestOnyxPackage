#include "ImageManager.h"

#ifdef ONYX_THREADS_ENABLED
#include <thread>
#endif

#include <lucid/Profiler.h>

#include <Styling/Parse/MiscJson.h>
#include <Utils/BgfxUtils.h>
#include <System/FileSystem.h>

namespace onyx {

ImageManager::FetchCallbackT ImageManager::sFetchBytesCallback = ImageManager::FetchCallbackT{ ImageManager::defaultFetchCallback };

ImageManager::ImageManager() :
	mImageAtlas(std::make_shared<ImageAtlas>(Atlases::cRenderFlags, Atlases::cDefaultCellSize, Atlases::cDefaultResolution, 0)),
	mImageRecord(std::make_shared<Styling::Spritesheet>())
{}

std::shared_ptr<std::vector<uint8_t>> ImageManager::fetchLocalBytesCallback(std::string const& filepath)
{
	if (core::FileSystem::fileExists(filepath))
	{
		return std::make_shared<std::vector<uint8_t>>(core::FileSystem::readFileBytes(filepath));
	}

	logE("Failed to find " + filepath);
	return nullptr;
}

// TODO (Ronald): We need to code up a dedicated generic bytestream-fetching thread
std::shared_ptr<std::vector<uint8_t>> ImageManager::fetchBytestream(std::string const& url)
{
	LUCID_PROFILE_SCOPE("Fetch bytestream");
#ifdef ONYX_THREADS_ENABLED
	std::shared_ptr<std::vector<uint8_t>> toRet = std::make_shared<std::vector<uint8_t>>();
	auto lambda = [](std::string const url, std::shared_ptr<std::vector<uint8_t>> bsPtr)
	{
		auto bs = sFetchBytesCallback(url);
		if (bs && !bs->empty())
		{
			bsPtr->swap(*bs);
		}
	};
	std::thread fetchBsThread(lambda, url, toRet);
	fetchBsThread.join();
#else
	auto toRet = sFetchBytesCallback(url);
#endif

	return toRet;
}

bool ImageManager::addImage(std::string const& id, std::vector<uint8_t> const& imgData, lgal::array::Vector2 const& imgRes)
{
	auto const format = bgfx::TextureFormat::RGBA8;
	ONYX_ASSERT(imgRes.x * imgRes.y * 4 == imgData.size(), "addImage: image size and resolution info do not match");
	if (hasImage(id))
    {
        logI("Replacing image " + id);
		mImageAtlas->erase(id);
    }

	auto texFlags = BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP;
	auto* mem = bgfx::copy(imgData.data(), (uint32_t)imgData.size());
	auto tHndl = bgfx::createTexture2D((uint16_t)imgRes.x, (uint16_t)imgRes.y, false, 1, format, texFlags, mem);
	if (!bgfx::isValid(tHndl))
    {
		logE("Failed to load texture from data for " + id);
		return false;
    }

	return addImage(id, tHndl, format, imgRes);
}

bool ImageManager::addLocalImage(std::string const& id, std::string const& filepath)
{
	if (hasImage(id))
    {
        logI("Replacing image " + id);
		mImageAtlas->erase(id);
    }

    bgfx::TextureInfo tInfo{};
    auto tHndl = BgfxUtils::loadTexture(filepath, 0, 0, &tInfo);
    if (!bgfx::isValid(tHndl))
    {
		logE("Failed to load texture from  " + filepath);
		return false;
    }

	return addImage(id, tHndl, tInfo.format, lgal::array::Vector2{ (index_t)tInfo.width, (index_t)tInfo.height });

}

void ImageManager::compositeImages(std::string const& id, std::vector<std::string> const& filePaths)
{
	if (hasImage(id))
	{
		logE(id + " is already in SpriteAtlas!");
		return;
	}

	std::vector<bgfx::TextureHandle> tHndls;
	tHndls.reserve(filePaths.size());

	bgfx::TextureInfo tInfo = {};
	
	for (auto const& path : filePaths)
	{
		auto tHndl = BgfxUtils::loadTexture(path.c_str(), 0, 0, &tInfo);
		if (!bgfx::isValid(tHndl))
		{
			logE("Failed to load texture from " + path);
			for (auto h : tHndls)
			{
				BgfxUtils::tryDestroy(h);
			}
			return;
		}
		tHndls.push_back(tHndl);
	}

	if (!tHndls.empty())
	{
		mImageAtlas->compositeTextures(id, tHndls,
			lgal::screen::Vector2{ screen_coord_t(tInfo.width), screen_coord_t(tInfo.height) },
			tInfo.format);

        Styling::SpriteIndex idx{};
        idx.name = id;
        idx.sizePx = lgal::gpu::Vector2{ gpu_float_t(tInfo.width), gpu_float_t(tInfo.height) };
        idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
        idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };
        idx.content = { { 0, 0 }, { tInfo.width, tInfo.height } };
        idx.uvOffset = mImageAtlas->getUVOffset(id);
        mImageRecord->indices.insert_or_assign(id, idx);
	}
}

void ImageManager::resetToLocalSpritesheet(std::string const& filepath, int spritesheetSize)
{
	// Parse sprite stylesheet
	auto spritePath = filepath;
	if (spritesheetSize >= 2)
	{
		spritePath += "@" + std::to_string(spritesheetSize) + "x";
	}

	auto jsonPath = spritePath + ".json";
	auto jsonBS = fetchLocalBytesCallback(jsonPath);
	if (!jsonBS || jsonBS->empty())
	{
		logE("No data loaded from " + jsonPath);
		return;
	}
	// Treat data as a c-str
	jsonBS->push_back(uint8_t('\0'));

	auto pngPath = spritePath + ".png";
	auto pngBS = fetchLocalBytesCallback(pngPath);
	if (!pngBS || pngBS->empty())
	{
		logE("No data loaded from " + pngPath);
		return;
	}

	setSpritesheetJson(jsonBS);
	setSpritesheetPng(pngBS);
}

void ImageManager::setSpritesheetJson(std::shared_ptr<std::vector<uint8_t>> bytestream)
{
	auto ptr = reinterpret_cast<char const*>(bytestream->data());
	auto jsonStr = std::string(ptr);

	auto j = nlohmann::json::parse(jsonStr);
	mImageRecord->indices.clear();
	from_json(j, *mImageRecord);
}

void ImageManager::setSpritesheetPng(std::shared_ptr<std::vector<uint8_t>> bytestream)
{
	// load texture from data
	auto texFlags = uint64_t(BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP);

	bgfx::TextureInfo info{};
	auto tHndl = BgfxUtils::loadTexture((void*)bytestream->data(), uint32_t(bytestream->size()), "spritesheetPng", texFlags, 0, &info);

	ONYX_DEBUG_ASSERT(bgfx::isValid(tHndl), "ImageManager::setSpritesheetPng - Failed to parse bytestream to texture");

	mImageAtlas->erase();
	
	std::vector<Atlases::TextureAtlas<std::string>::SpriteIdx> idxs;
	idxs.reserve(mImageRecord->indices.size());
	for (auto const& [name, spriteIdx] : mImageRecord->indices)
	{
		// load into the SpriteIdx array
		Atlases::PageLocation pgLoc;
		pgLoc.position = spriteIdx.loc;
		pgLoc.size = spriteIdx.sizePx.as<screen_coord_t>();
		idxs.push_back({ spriteIdx.name, pgLoc });
	}

	// Break atlas into pieces if bigger than page resolution
	auto res = mImageAtlas->getResolution();
	if (res > info.width || res > info.height)
	{
		mImageAtlas->insertSpritesFull(tHndl, mImageRecord->path, info, idxs);
	}
	else
	{
		mImageAtlas->insertSpritesPerIdx(tHndl, info, idxs);
	}

	mImageAtlas->setName(mImageRecord->path);

	// Add the atlas UV offsets to the sprite sheet
	for (auto& [name, spriteIdx] : mImageRecord->indices)
	{
		auto uvOffset = mImageAtlas->getUVOffset(name);
		spriteIdx.uvOffset = uvOffset;
	}
}

void ImageManager::resetSpritesheet(std::string const& url, int spritesheetSize)
{
	LUCID_PROFILE_SCOPE("Reset spritesheet");

	// Adjust URL based on dpi scale
	auto spritesheetUrl = url;
	if (spritesheetSize > 1)
	{
		spritesheetUrl += "@" + std::to_string(spritesheetSize) + "x";
	}
	auto jsonUrl = spritesheetUrl + ".json";
	auto pngUrl = spritesheetUrl + ".png";

	auto jsonBS = fetchBytestream(jsonUrl);
	if (!jsonBS || jsonBS->empty())
	{
		logE("spritesheet json not found in url " + jsonUrl);
		return;
	}
	// Treat data as a c-str
	jsonBS->push_back(uint8_t('\0'));

	auto pngBS = fetchBytestream(pngUrl);
	if (!pngBS || pngBS->empty())
	{
		logE("spritesheet png not found in url " + pngUrl);
		return;
	}

	// Parse SpriteIdxs
	setSpritesheetJson(jsonBS);

	// Add png into atlas
	setSpritesheetPng(pngBS);
}

std::optional<Styling::SpriteIndex> ImageManager::getSpriteIdx(std::string const& id) const
{
	return mImageRecord->getSpriteIdx(id);
}

bool ImageManager::addImage(std::string const& id, bgfx::TextureHandle texHndl, bgfx::TextureFormat::Enum format, lgal::array::Vector2 const& imgRes)
{
	ONYX_DEBUG_ASSERT(bgfx::isValid(texHndl), "addImage: given texture is not valid!");

	mImageAtlas->insert(id, texHndl, format, imgRes.as<screen_coord_t>());
	if (!mImageAtlas->contains(id))
	{
		logE("Failed to add " + id + " to Sprite Atlas");
		return false;
	}

	auto pageId = mImageAtlas->getAtlasId(id).pageId;
	if (pageId + 1 > cMaxAtlasPages)
	{
		logI("No space available to insert sprite " + id);
		// TODO (Ronald): Atlas's default erase might be a problem here. Investigate this
		mImageAtlas->erase(id);
		return false;
	}

	Styling::SpriteIndex idx{};
    idx.name = id;
    idx.sizePx = imgRes.as<gpu_float_t>();
    idx.offsets1 = { 0, 0, 0, idx.sizePx.x };
    idx.offsets2 = { idx.sizePx.x, 0, idx.sizePx.y, idx.sizePx.y };
    idx.content = { { 0, 0 }, { imgRes.x, imgRes.y } };
    idx.uvOffset = mImageAtlas->getUVOffset(id);
	mImageRecord->indices.insert_or_assign(id, idx);

    return true;
}

std::shared_ptr<std::vector<uint8_t>> ImageManager::defaultFetchCallback(std::string const& url)
{
	logE("ImageManager: default fetch callback hit for " + url);
	return nullptr;
}

}