#pragma once

#include <vector>
#include <string>
#include <condition_variable>

#include <Styling/Spritesheet.h>

#include "Atlases/TextureAtlas.h"

namespace onyx {

class ImageManager {

public:

	using ImageAtlas = Atlases::TextureAtlas<std::string>;

	static constexpr size_t cMaxAtlasPages = 2;
	
public:

	using FetchCallbackT = std::function<std::shared_ptr<std::vector<uint8_t>>(std::string const&)>;

	static void setFetchBytesCallback(FetchCallbackT const& callback)
	{
		sFetchBytesCallback = callback;
	}

	// Fetches bytes from file system given the spritesheet url.
	static std::shared_ptr<std::vector<uint8_t>> fetchLocalBytesCallback(std::string const& filepath);

	
public:

	ImageManager();

	ImageManager(ImageManager const&) = delete;
	ImageManager(ImageManager&&) = delete;

	bool addImage(std::string const& id, std::vector<uint8_t> const& imgData, lgal::array::Vector2 const& imgRes);
	bool addLocalImage(std::string const& id, std::string const& filepath);
	void compositeImages(std::string const& id, std::vector<std::string> const& filePaths);

	inline bool hasImage(std::string const& id)
	{
		return mImageRecord->hasSprite(id);
	}
	inline void removeImage(std::string const& id)
	{
		mImageAtlas->erase(id);
		mImageRecord->indices.erase(id);
	}

	// TODO (Ronald): Nothing outside of viewport, let alone anything platform side should need this functionality
	std::optional<Styling::SpriteIndex> getSpriteIdx(std::string const& id) const;

	// Only should be used for viewport
	inline std::shared_ptr<Styling::Spritesheet const> getImageRecord() const
	{
		return std::const_pointer_cast<Styling::Spritesheet>(mImageRecord);
	}
	inline std::shared_ptr<ImageAtlas const> getImageAtlas() const
	{
		return std::const_pointer_cast<ImageAtlas>(mImageAtlas);
	}
	void resetToLocalSpritesheet(std::string const& filePath, int spritesheetSize);
	void resetSpritesheet(std::string const& baseUrl, int spritesheetSize);
	inline void updateImageAtlas() { mImageAtlas->update(); }

private:

	std::shared_ptr<ImageAtlas> mImageAtlas;
	std::shared_ptr<Styling::Spritesheet> mImageRecord;

	static FetchCallbackT sFetchBytesCallback;

	static std::shared_ptr<std::vector<uint8_t>> defaultFetchCallback(std::string const&);

	// Fetches a bytestream using a separate thread if it is enabled
	static std::shared_ptr<std::vector<uint8_t>> fetchBytestream(std::string const& url);

	bool addImage(std::string const& id, bgfx::TextureHandle texHndl, bgfx::TextureFormat::Enum format, lgal::array::Vector2 const& imgRes);

	// TODO (Ronald): Temporarily expose this for ios api workarounds?
	void setSpritesheetJson(std::shared_ptr<std::vector<uint8_t>> bytestream);
	void setSpritesheetPng(std::shared_ptr<std::vector<uint8_t>> bytestream);

};

}
