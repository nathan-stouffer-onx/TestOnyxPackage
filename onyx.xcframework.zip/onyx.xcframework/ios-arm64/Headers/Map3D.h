#pragma once
// NOTE: bx must be includes before bgfx. additionally, sole includes winsock and should be included
//		 prior to any (direct or indirect) includes of windows.h

#include <vector>
#include <string>
#include <memory>

#include <bgfx/bgfx.h>
#include <3rdParty/nlohmann/json.hpp>
#include <3rdParty/sole/ourSole.h>

#include "Camera/CameraController.h"
#include "Pyramid/Culling.h"
#include "Input/UserInputs.h"
#include "DataObjects/WaypointManager.h"
#include "Utils/MapMath.h"
#include "Utils/lowpass.h"
#include "Shaders/ShaderParameters.h"
#include "DataObjects/TrackerManager.h"
#include "Viewport/ViewportManager.h"
#include "Icon/IconRenderer.h"

#ifdef PLATFORM_ANDROID
#include <android/asset_manager.h>
#endif

namespace cam = onyx::Camera;
namespace in = onyx::Input;
namespace tiles = onyx::Tiles;
namespace utils = onyx::Utils;

enum class InputAction
{
	Pan,
	Orbit,
	Zoom,
	Count
};

class Map3D
{
public:
	static int mCurrentFrame;

	Map3D();
	~Map3D();
	int init(uint32_t width, uint32_t height, void* window, bgfx::RendererType::Enum rendererType, void* device = NULL);
	void resize(uint32_t width, uint32_t height);
	lucid::math::Vector<uint32_t, 2> getScreenSize() const;

	void render();
	void finishFrame(); //moved seperate from render so we can insert bgfx 3d calls on the native layer if need be
	void shutdown();
	void setShowStats(bool b);

	void setStyle(std::string const& viewport, std::shared_ptr<onyx::Styling::Style> style);

	void setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, onyx::Shaders::ValueBag const& configuration);
	void loadShaders(std::string const& path = "assets/shaders/signatures.txt");
	void initLabelManager(FontManager::FontConfiguration const &defaultFont);
	std::vector<ShaderParam*> getAllShaderParameters();
	std::vector<ShaderParam*> getActiveShaderParameters(ShaderEnums::ConfigurableShaders shader);
	void setMaxSubdivisionDepth(int subd) { mMaxSubdDepth = subd; }
	void toggleCulling(bool on);

	lgal::world::Vector3 unproject(int pixX, int pixY);
	lgal::world::Vector2 project(lgal::world::Vector3 const& pos);

	std::string getWaypointUuid(int pixX, int pixY);
	void loadWaypoint(nlohmann::json json);
	WaypointManager::sharedWaypoint_t addWaypoint(std::string uuidStr, lgal::world::Vector3 const& worldPos, lucid::gal::Color const& color);
	WaypointManager::sharedWaypoint_t addWaypoint(sole::uuid const& id, lgal::world::Vector3 const & worldPos, lucid::gal::Color const& color);
	WaypointManager::sharedWaypoint_t getWaypoint(sole::uuid const &id);
	void selectWaypoint(std::string uuidStr);
	void unselectWaypoint(std::string uuidStr);
	void unselectAllWaypoints();
	void moveWaypointTo(std::string uuidStr, int pixX, int pixY);
	void moveWaypointTo(std::string uuidStr, lgal::world::Vector3 const& pos);
	void moveWaypointTo(sole::uuid const& uuid, lgal::world::Vector3 const& pos);
	void setWaypointIcon(std::string uuidStr, std::string icon);
	void setWaypointIconColor(std::string uuidStr, lucid::gal::Color color);
	void setWaypointDiskColor(std::string uuidStr, lucid::gal::Color color);
	void setWaypointBodyColor(std::string uuidStr, lucid::gal::Color color);
	void setWaypointOutlineColor(std::string uuidStr, lucid::gal::Color color);
	void deleteWaypoint(sole::uuid const& uuid);
	void deleteWaypoint(std::string uuidStr);
	void deleteSelectedWaypoints();
	void clearWaypoints();
	void generateRandomWaypoints(int count);		// TODO delete later, just for generating lots of test waypoints

	Tracker* addTracker(sole::uuid const& id, onyx::MapMath::LonLat const& coords, TrackerType type = TrackerType::Puck);
	Tracker* addTracker(sole::uuid const& id, lgal::world::Vector2 const& worldPos, TrackerType type = TrackerType::Puck);
	Tracker* getTracker(sole::uuid const& id);

	int clickGetPickingId(int pixX, int pixY);
	tiles::TileId getActiveTileAtPosition(lgal::world::Vector3 const& worldPos);

	void startDemo();
	void startRecordingDemo();
	bool isRecordingDemo();
	void loadDemoJson(std::string path);
	void saveDemoJson(std::string path);

	template <class T>
	void setViewportContext(std::string const& viewport, std::string const& key, T const& value)
	{
		auto vp = ViewportManager::Instance()->getViewport(viewport);
		MAP3D_ASSERT(vp != nullptr, "No '" + viewport + "' viewport found");

		vp->setContext(key, value);
	}

	template <class T>
	T getViewportContext(std::string const& viewport, std::string const& key) const
	{
		auto vp = ViewportManager::Instance()->getViewport(viewport);
		MAP3D_ASSERT(vp != nullptr, "No '" + viewport + "' viewport found");

		return vp->getContext<T>(key);
	}

	void setTileLod(std::string const& viewportName, float lod);

	double tileLoadTimeMS(std::string const& viewport) const;
	std::vector<onyx::Tiles::TileId> recentTiles(double windowMS) const;

	inline double lastFrameTimeMS() const { return mFrameTimeHistorySeconds.last() * 1000.0; }
	inline double avgFrameTimeMS() const { return mFrameTimeHistorySeconds.avg() * 1000.0; }

	float heightAt(lgal::world::Vector2 const& pos) const;

	void addLabel(lgal::world::Vector3 const & pos, std::string text);

	nlohmann::json getDebugState(bool includeTiles = true, bool includeAtlas = true, bool includeWaypoints = true, bool includeShaders = true);
	
	//visualization testing - this "should" be more dynamic by getting a list of shader params, but for now, going hardcoded
	// probably set this up to be in tune with the component system
	void toggleIntersectTerrain(bool on);
	bool isIntersectTerrainOn();
	void toggleHeightRanges(bool on);
	bool isHeightRangesOn();
	void toggleSlopeAngleRanges(bool on);
	bool isSlopeAngleRangesOn();
	void toggleSlopeDirRanges(bool on);
	bool isSlopeDirRangesOn();

	void setHeightRanges(std::vector<lgal::world::Range> const& ranges);
	// 0 degrees == north, going counterclockwise
	void setSlopeDirRanges(std::vector<lgal::world::Range> const& ranges);
	void setSlopeAngleRanges(std::vector<lgal::world::Range> const& ranges);

	void setHeightScale(float scale = 1.0);

	bool		getViewshedEnabled(std::string const& viewportName);
	void		toggleViewshed(std::string const& viewportName, bool on, bool inverted = false);
	void			addViewshed(std::string const& viewportName, lgal::world::Vector2 const& pos);
	void		 enableViewshed(std::string const& viewportName, bool on);
	void    setViewshedPosition(std::string const& viewportName, lgal::world::Vector2 const& pos);
	void	  setViewshedOffset(std::string const& viewportName, world_float_t offset);
	lgal::world::Vector2	getViewshedPosition(std::string const& viewportName);
	float	   getViewshedRange(std::string const& viewportName);
	void	   setViewshedRange(std::string const& viewportName, world_float_t range);
#ifdef PLATFORM_ANDROID
	void setAssetManager(AAssetManager* assetMan) { onyx::core::FileSystem::setAssetManager(assetMan); }
#endif
	void setController(std::string name, std::shared_ptr<cam::CameraController> &controller);
	template<class Controller, class... Args>
	void constructController(std::string name, Args&&... args)
	{
		std::shared_ptr<cam::CameraController> controller = std::make_shared<Controller>(args...);
		setController(name, controller);
	}

	std::shared_ptr<onyx::Input::UserInputs> getInput() const { return mInput; }

	double getInputSensitivity();
	void setInputSensitivity(double value);

	std::shared_ptr<onyx::Camera::CameraController> getController(float x, float y) const;
	cam::CameraState getCameraState(float x, float y) const;
	cam::CameraState getCameraState(std::string const& name) const;
	onyx::Pyramid::CullResult getCullResult(std::string const& name) const;

	lgal::world::Vector3 getViewportPosition(float x, float y);
	lgal::world::Vector3 getViewportPosition(std::string name);
	lgal::world::Vector2 getViewportSize(float x, float y);
	lgal::world::Vector2 getViewportSize(std::string name);

	inline void toggleDebugInfo() { mShowDebugInfo = !mShowDebugInfo; }
	inline void toggleDebugInfo(bool on) { mShowDebugInfo = on; }

	float getTileLod() const { return mLODScaler; }
	void setTileHeightCulling(bool enabled) { mCullTileHeight = enabled; }
	void setCameraState(std::string const& viewport, cam::CameraState const& state);
	void setTopoEnable(std::string name, bool on);
	void setTopoMajorColor(std::string name, lucid::gal::Color color);
	void setTopoMinorColor(std::string name, lucid::gal::Color color);
	void setSunlightEnable(std::string vpName, bool on);
	void setSunlightTime(std::string vpName, int year, int month, int day, float timezone, float hours24);

	std::shared_ptr<onyx::Icon::IconRenderer> getIconRenderer(std::string const& vpName);
	void addDebugIconTile(std::string const& vpName, onyx::Tiles::IconTile const& iconTile);
	void addDebugIconLayer(std::string const& vpName, 
		std::shared_ptr<onyx::Styling::SymbolLayer const> iconLayer);

private:
	float mTimeStepMS = 0;
	bool showStats = false;
	bool mShowProfiling = false;
	bool mShowDebugInfo = true;
	
	int mMaxSubdDepth = 20;
	float mLODScaler = 2.0;
	bool mCullTileHeight = true;
	
	uint16_t writeDebugInfo(uint16_t x, uint16_t y);
	uint16_t writeProfiling(uint16_t x, uint16_t y, const lucid::core::Profiler::Sample* sample, bool log = false);
	std::shared_ptr<in::UserInputs> mInput = std::make_shared<in::UserInputs>();

	double mPrevTimeMS = 0;
	bool initialized = false;

	LowpassFilter<double, 16> mFrameTimeHistorySeconds;
};
