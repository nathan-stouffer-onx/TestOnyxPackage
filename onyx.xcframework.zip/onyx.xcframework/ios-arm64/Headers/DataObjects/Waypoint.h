#pragma once

#include <string>
#include <vector>
#include <bgfx/bgfx.h>
#include <bx/bx.h>
#include <bx/math.h>

#include <3rdParty/nlohmann/json.hpp>
#include <lucid/gal/Types.h>
#include <3rdParty/sole/ourSole.h>

#define DEFAULT_WAYPOINT_ICON "Location"

class Waypoint
{
public:

	Waypoint(sole::uuid uuid);
	~Waypoint();

	inline void setPosition(const bx::Vec3& pos) { mPosition = pos; }
	inline void setRadius(float radius) { mRadius = radius; }
	inline void setIconColor(const lucid::gal::Color& col) { mIconColor = col; }	// TODO set up png input so that the color on/off match this order
	inline void setDiskColor(const lucid::gal::Color& col) { mDiskColor = col; }
	inline void setBodyColor(const lucid::gal::Color& col) { mBodyColor = col; }
	inline void setOutlineColor(const lucid::gal::Color& col) { mOutlineColor = col; }
	inline void setIcon(std::string icon)
	{
		mIcon = icon;
		mIconSelected = "selected-" + icon;
		mIconUnselected = "unselected-" + icon;
	}

	const inline std::string getIconState() const {	return isSelected() ? mIconSelected : mIconUnselected; }

	inline void select() { mSelected = true; }
	inline void unselect() { mSelected = false; }
	inline bool isSelected() const { return mSelected; }

	inline sole::uuid getUuid() const { return mUuid; }
	inline bx::Vec3 getPosition() const { return mPosition; }
	inline float getRadius() const { return mRadius; }
	inline std::string getIcon() const { return mIcon; }
	inline lucid::gal::Color getIconColor() const { return mIconColor; }
	inline lucid::gal::Color getDiskColor() const { return mDiskColor; }
	inline lucid::gal::Color getBodyColor() const { return mBodyColor; }
	inline lucid::gal::Color getOutlineColor() const { return mOutlineColor; }

	static std::string iconToFileName(const std::string& icon);

private:

	sole::uuid mUuid;
	bx::Vec3 mPosition;
	float mRadius;
	std::string mIcon;
	std::string mIconSelected;
	std::string mIconUnselected;
	bool mSelected;

	lucid::gal::Color mIconColor = { 1.0f, 1.0f, 1.0f, 1.0f };
	lucid::gal::Color mDiskColor = { 1.0f, 1.0f, 1.0f, 1.0f };
	lucid::gal::Color mBodyColor = { 1.0f, 1.0f, 1.0f, 1.0f };
	lucid::gal::Color mOutlineColor = { 1.0f, 1.0f, 1.0f, 1.0f };

};
