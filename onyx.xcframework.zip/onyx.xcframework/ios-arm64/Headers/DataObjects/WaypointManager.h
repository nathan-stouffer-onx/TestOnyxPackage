#pragma once

#include <map>
#include <mutex>

#include <bx/bx.h>

#include <3rdParty/nlohmann/json.hpp>
#include <3rdParty/sole/ourSole.h>

#include <lucid/gal/Types.h>

#include "Atlases/TextureAtlas.h"
#include "Camera/CameraState.h"
#include "Rendering/VertStructs.h"
#include "Rendering/BufferPool.h"

#include "Waypoint.h"

/**
* WaypointManager is an singleton class that manages waypoints. All edits should be ran through the 
* WaypointManager. Each Waypoint is responsible for generating it's own vertices/indices, then the 
* manager collects all the vertices and draws the them. For any Waypoint, we can edit/delete/move
* them based on their uuid. They can also be selected/unselected.
*
* NOTE: Individual instances of Waypoint are not thread-safe. We place that on the burden of the
* library user to not edit the same object from different threads. The manager, however, is safe to
* accomodate loading data on multiple threads
* 
*/

class WaypointManager
{
public:

	typedef std::shared_ptr<Waypoint> sharedWaypoint_t;
	typedef onyx::Rendering::VertStructs::PosColor4NormalUV WaypointVert_t;

	static WaypointManager* Instance();
	static void Shutdown();

	void update();
	void draw(bgfx::ViewId viewId, onyx::Camera::CameraState const &cameraState);

	static void populateVerts(sharedWaypoint_t wp, lgal::world::Vector3 const& eye, std::vector<WaypointVert_t>& verts, lgal::gpu::Vector4 const& uvOffset);
	static std::vector<uint16_t> const& getIndices() { return WaypointManager::sIndices; }

	sharedWaypoint_t addWaypoint(nlohmann::json json);
	sharedWaypoint_t addWaypoint(const sole::uuid& uuid, const bx::Vec3& pos, lucid::gal::Color const& color);
	sharedWaypoint_t getWaypoint(const sole::uuid& uuid) const;
	void clearWaypoints();
	void deleteWaypoint(const sole::uuid& uuid);
	void moveWaypointTo(const sole::uuid& uuid, const bx::Vec3& pos);

	void selectWaypoint(const sole::uuid& uuid);
	void unselectWaypoint(const sole::uuid& uuid);
	void unselectAllWaypoints();
	void deleteSelectedWaypoints();

	void setWaypointSize(float size);
	void setWaypointIcon(const sole::uuid& uuid, const std::string& icon);
	void setIconColor(const sole::uuid& uuid, const lucid::gal::Color& col);
	void setDiskColor(const sole::uuid& uuid, const lucid::gal::Color& col);
	void setBodyColor(const sole::uuid& uuid, const lucid::gal::Color& col);
	void setOutlineColor(const sole::uuid& uuid, const lucid::gal::Color& col);

	bool getWaypoint(sole::uuid uuid, sharedWaypoint_t& waypoint) const;

	sole::uuid getWaypointUuid(const bx::Vec3& pos);

	std::vector<sole::uuid> getAllWaypointUuids();
	std::vector<sole::uuid> getSelectedWaypointUuids();

	std::vector<nlohmann::json> getAllWaypointJsons();
	std::vector<nlohmann::json> getWaypointJsons(int start, int end);	// bounds are inclusive

	bx::Vec3 getWaypointPosition(const sole::uuid& uuid);

	bool isDirty() { return mIsDirty; }

	nlohmann::json getJson() const;

private:

	WaypointManager(float size = 0.05f, float offset = 0.001f);
	~WaypointManager();

	static WaypointManager* sSingleton;
	static std::vector<uint16_t> sIndices;
	
	static std::mutex sMutex;

	bool mIsDirty = true;		// clear vertex/index buffers and recompute everything from scratch
	float mSize;				// icon size on screen
	float mOffset;				// vertical offset from terrain

	std::map<sole::uuid, sharedWaypoint_t> mWaypoints;

	std::map<sole::uuid, onyx::Rendering::BufferPoolId> mWaypointBufferPoolIds;

	bgfx::TextureHandle mUnselectedPinTexHandle;
	bgfx::TextureHandle mSelectedPinTexHandle;

	onyx::Atlases::TextureAtlas<std::string> mWaypointAtlas;

	// TODO we really should find a way to define these on the client -- I dislike hardcoding these secondary colors in core
	// uint32_t is encoded as argb to allow similar lucid::gal::Colors to get mapped to the same Disk color. lucid's color
	// struct has much more precision than we need in this context
	std::map<uint32_t, lucid::gal::Color> const mDiskColors;

	// TODO consider making this a double buffer
	std::map<std::string, onyx::Rendering::BufferPool<WaypointVert_t>> mBufferPools;		// access with icon type as the key
	bgfx::ProgramHandle mProgram;

	struct IconTex
	{
		bgfx::TextureHandle handle = BGFX_INVALID_HANDLE;
		int frameCount;
		IconTex(bgfx::TextureHandle h, int count = 0) : handle(h), frameCount(count) {}
	};

	std::vector<IconTex> mIconTexturesToDelete;

	bool containsWaypointNoLock(sole::uuid uuid) const;
	bool getWaypointNoLock(sole::uuid uuid, sharedWaypoint_t& waypoint) const;

	void setUniforms(const std::string& atlasKey, onyx::Camera::CameraState const& cameraState);
	void updateWaypointBuffer(lgal::world::Vector3 const& eye, const sole::uuid& uuid);
	void addIconTexture(const std::string& icon);
	inline lgal::gpu::Vector4 getIconTextureOffset(std::string const& icon)
	{
		return (mWaypointAtlas.isReady(icon)) ? mWaypointAtlas.getUVOffset(icon) : lgal::gpu::Vector4{ 0, 0, 1, 1 };
	}
};
