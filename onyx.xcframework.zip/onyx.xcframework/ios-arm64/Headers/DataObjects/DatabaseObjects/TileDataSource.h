#if !defined(_TILE_DATA_SOURCE_H)
#define _TILE_DATA_SOURCE_H
#pragma once

#include "DBObject.h"

namespace onyx {
namespace Storage {

	class TileDataSource : public DBObject
	{
	public:
		TileDataSource() : DBObject() { }

		DB_GET_SET_PROP(BaseUrl, DBString);

		static inline std::string GetSelectTableSql()
		{
			return "SELECT Id, BaseUrl FROM TileDataSource";
		}

		static inline std::string GetInsertSql()
		{
			return "INSERT INTO TileDataSource(BaseUrl) VALUES (?)";
		}

	};

} }

#endif