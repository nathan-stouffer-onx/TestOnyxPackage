#pragma once

#include <unordered_set>
#include <thread>
#include <unordered_map>
#include <vector>

#include "Atlases/HeightAtlas.h"
#include "Camera/CameraState.h"
#include "Camera/Frustum.h"
#include "Camera/ScreenSpaceManager.h"
#include "font/text_buffer_manager.h"
#include "LabelCollection.h"
#include "MapLabel.h"
#include "Rendering/VertStructs.h"
#include "Tiles/TileId.h"
#include "Utils/property.h"

namespace onyx {

	class Viewport;

namespace DataObjects {

class LabelManager
{
public:
	using sharedLabel_t = std::shared_ptr<MapLabel>;
	using labelVec_t = std::vector<sharedLabel_t>;
	using labelSet_t = std::unordered_set<sharedLabel_t>;

	struct Stats {
		size_t visibilityClipped;
		size_t depthClipCount;
		size_t bufferClipped;
		size_t buffered;
		size_t frustumClipped;
		size_t screenSpaceClipped;
		size_t overlapClipped;

		void clear()
		{
			*this = { 0, 0, 0, 0, 0, 0, 0 };
		}
	};

	enum class LabelCullState {
		UNKNOWN,
		DEPTH_CLIPPED,
		FRUSTUM_CLIPPED,
		SCREEN_SPACE_CLIPPED,
		OVERLAP_CLIPPED,
		SIZE_CLIPPED,
		PATH_CLIPPED,
		STYLE_INVALID,
		VISIBLE
	};

	struct LabelState {
		sharedLabel_t label;
		LabelCullState cullState = LabelCullState::UNKNOWN;
		lgal::world::Vector3 globePosition = { 0, 0, 0 };
		lgal::gpu::Vector3 screenPositionPx = { -1, -1, -1 };
		lgal::gpu::Vector3 screenDirectionPx = { -1, -1, -1 };
		lgal::gpu::AABB2d screenRectPx = lgal::gpu::AABB2d::nothing();
	};

	using labelStateVec_t = std::vector<LabelState>;

	LabelManager(Viewport const* viewport);
	~LabelManager();

	void initialize();
	void update();
	void getLabelScreenState(LabelState& labelState, onyx::Camera::CameraState const& camState, Camera::Frustum const& frustum, Atlases::HeightAtlas const* heightAtlas);
	bool isLabelVisible(Camera::ScreenSpaceManager& screenSpaceManager, LabelState &labelState);
	bool bufferLabel(Camera::ScreenSpaceManager& screenSpaceManager, Atlases::HeightAtlas const* heightAtlas, LabelState &labelState, Camera::CameraState const& cameraState);
	void draw(Camera::ScreenSpaceManager& screenSpaceManager, Atlases::HeightAtlas const* heightAtlas, std::vector<sharedLabel_t> const &frameLabels, bgfx::ViewId viewId);

	void setScreenSize(lgal::gpu::Vector2 const& size) { mScreenSize = size; }

	// TODO (scott) remove debug stuff
	gpu_float_t DBG_sizeCutoff = 1.f,
		DBG_DepthOffset = 0.01f;
	int DBG_maxLabelsDrawn = 50;
	GET_SET_VALUE(DebugLabel, sharedLabel_t, nullptr);
	GET_SET_VALUE(DebugMode, bool, true);

	void clearAciveLabels() { mActiveLabels.clear(); }

	void addLabel(sharedLabel_t const& label) { mActiveLabels.push_back(label); }

	GET_SET_VALUE(ActiveLabels, labelVec_t, labelVec_t());
	GET_SET_VALUE(OnscreenLabels, labelSet_t, labelSet_t());
	GET_SET_VALUE(CurrentFrameLabels, labelSet_t, labelSet_t());
	GET_PROP(LabelStates, labelStateVec_t, labelStateVec_t());
	GET_PROP(Stats, Stats, Stats());

	inline bool isClipped(lgal::gpu::Vector3 normalizedPosition)
	{
		return (normalizedPosition.x < -1.f || normalizedPosition.x > 1.f
			|| normalizedPosition.y < -1.f || normalizedPosition.y > 1.f
			|| normalizedPosition.z < mNearClip || normalizedPosition.z > mFarClip);
	}

private:
	struct LabelGroup
	{
		std::string const label;
		Styling::FontStyle::SymbolPlacement placement;
		TextBufferHandle bufferHandle;
		Vector::Feature::Type featureType;

		bool operator==(LabelGroup const& rhs)
		{
			return label == rhs.label
				&& placement == rhs.placement
				&& bufferHandle.idx == rhs.bufferHandle.idx
				&& featureType == rhs.featureType;
		}

		struct hash
		{
			size_t operator()(const LabelGroup& x) const
			{
				size_t result = std::hash<std::string>()(x.label) * 53;
				result += std::hash<uint32_t>()(uint32_t(x.placement)) * 53;
				result += std::hash<uint16_t>()(x.bufferHandle.idx) * 53;
				result += std::hash<uint32_t>()(uint32_t(x.featureType));
				return result;
			}
		};
	};

	std::unordered_map<LabelGroup, sharedLabel_t, LabelGroup::hash> mLabelGroups;

	TextBufferHandle getStyleBuffer(Styling::FontStyle const& style);
	std::unordered_map<Styling::FontFace, TextBufferHandle> mStyleBufferHandles;

	mutable std::mutex mConnectionLock;
	std::thread mIntegrationThread;

	std::unique_ptr<TextBufferManager> mTextBufferManager;
	TextBufferHandle mTextBuffer = BGFX_INVALID_HANDLE;

	int64_t mTimeOffset = 0;
	int mLabelsDrawn = 0;

	lgal::gpu::Vector2 mScreenSize;

	// Used to determine the clipping bounds
	bool mHomogenousDepth = false;
	gpu_float_t mNearClip, mFarClip;
	Viewport const* mViewport;
};

} }