#pragma once

#include <string>
#include <lucid/gal/Types.h>

#include <3rdParty/sole/ourSole.h>

#include "font/text_buffer_manager.h"

#include "Camera/CameraState.h"
#include "Style/FontStyle.h"
#include "Tiles/TileId.h"
#include "Utils/property.h"
#include "Utils/SpaceTypes.h"
#include "Vector/Feature.h"

namespace onyx {
namespace DataObjects {

class MapLabel
{
public:

	typedef Vector::Feature             feature_t;

	typedef std::shared_ptr<feature_t const> sharedFeature_t;

	static std::shared_ptr<Styling::FontStyle> defaultStyle() {
		return std::make_shared<Styling::FontStyle>(Styling::FontFace({ "default", FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE, 0 }), lgal::Color::FromRGBA(0xFFFFFFFF), lgal::Color::FromRGBA(0x000000FF), lgal::Color::FromRGBA(0x00000064), 0.f, Styling::FontStyle::SymbolPlacement::LINE);
	}

	MapLabel(std::string text, lgal::world::Vector3 const& worldXY, std::shared_ptr<Styling::FontStyle> fontStyle = defaultStyle(), Tiles::TileId const& tileId = { -1, -1, -1 }, sharedFeature_t const& feature = nullptr, bool locked = false, Utils::SpaceTypes space = Utils::SpaceTypes::Tile, std::vector<lgal::world::Vector3> *worldGeometry = nullptr);
	
	MapLabel(std::string text, lgal::world::Vector3 const& worldXY, Utils::SpaceTypes space) : MapLabel(text, worldXY, defaultStyle(), { -1, -1, -1 }, nullptr, false, space) { }

	void setText(std::string name);

	lgal::world::Vector3 getMapPosition();
	lgal::world::Vector3 getPrevMapPosition();
	void setMass(float mass);
	void setMapPosition(lgal::world::Vector3 const & pos);

	void setPrevMapPosition(lgal::world::Vector3 const & prev);
	void setPrevScreenPosition(Camera::CameraState camState, lgal::gpu::Vector3 const& pos);
	void syncPrevPos() { mPrevMapPosition = mMapPosition; } //stops movement by making them match
	float getMass();
	float getInvMass();

	lgal::gpu::Vector3 getPrevScreenPosition(Camera::CameraState const& camState);
	void setScreenPosition(Camera::CameraState const &camState, lgal::gpu::Vector3 const& pos);
	lgal::gpu::Vector3 getAccel();

	float getSize() { return 1; }
	float getWidth() { return mTextRect.width; }
	float getHeight() { return mTextRect.height; }

	bool isVisible(Camera::CameraState const& cameraState);

	std::string getText() { return mText; }
	sole::uuid getUuid() { return mUuid; }

	bool isLocked() { return mLocked; }
	void setStyle(std::shared_ptr<Styling::FontStyle> const& style) { mStyle = style; }
	std::shared_ptr<Styling::FontStyle> const getStyle() const { return mStyle; }
	bool updateFade(bool visible);

	GET_SET_VALUE(TextDirection, lgal::gpu::Vector2, lgal::gpu::Vector2(1, 0));
	GET_SET_VALUE(Tag, void*, nullptr);
	std::function<float(void)> mFadeModifierPtr;

	void setAlpha(int alpha) { mCurrentAlpha = alpha; }
	int getCurrentAlpha() const { return mCurrentAlpha; }
	GET_SET_VALUE(Force, bool, false);
	GET_SET_VALUE(AnchorPoint, lgal::world::Vector3, lgal::world::Vector3(0, 0, 0));
	GET_SET_VALUE(TextLengthPx, gpu_float_t, -1.f);

	std::vector<lgal::world::Vector3> const& getWorldGeometry() { return mWorldGeometry; }

	size_t dataSize()
	{
		return sizeof(MapLabel) + (mWorldGeometry.size() * sizeof(lgal::world::Vector3));
	}

	bool operator==(MapLabel const& rhs)
	{
		return this == &rhs
			|| mFeature.get() == rhs.mFeature.get();
	}

	lgal::gpu::Vector3 getScreenAnchorPos(Camera::CameraState camState)
	{
		auto projected = camState.project(mAnchorPoint);
		return projected.position.as<gpu_float_t>();
	}

private:
	lgal::world::Vector3 mMapPosition;
	lgal::world::Vector3 mPrevMapPosition; //needed for verlet

	lgal::gpu::Vector3 mScreenPosition;
	lgal::gpu::Vector3 mPrevScreenPosition;

	lgal::gpu::Vector3 mAccel;

	float mMass;
	float mInvMass;
	std::string mText;
	sole::uuid mUuid;

	TextRectangle mTextRect;
	bool mLocked;

	std::shared_ptr<Styling::FontStyle> mStyle;

	int mCurrentAlpha;
	std::vector<lgal::world::Vector3> mWorldGeometry;

	GET_PROP(Feature, sharedFeature_t, nullptr);
	GET_PROP(TileId, Tiles::TileId, Tiles::TileId(-1, -1, -1));
	GET_PROP(LabelSpace, Utils::SpaceTypes, Utils::SpaceTypes::Tile);
};

} }