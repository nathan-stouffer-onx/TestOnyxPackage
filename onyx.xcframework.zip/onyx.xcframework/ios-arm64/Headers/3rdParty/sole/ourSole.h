#ifndef OURSOLE_H_
#define OURSOLE_H_

#include <Warnings.h>
DISABLE_WARNING_PUSH
DISABLE_WARNING_UNREFERENCED_FORMAL_PARAMETER
DISABLE_WARNING_NOT_DEFINED
DISABLE_UNUSED_FUNCTION

#include <bx/bx.h>		// ensures we always include bx.h before sole.hpp (we get loads of compile errors if bx.h is included after sole.hpp)
#include <3rdParty/sole/sole.hpp>

DISABLE_WARNING_POP

/**
* If you would like to use uuids, include this header file instead of
* sole.hpp -- we have a couple utility functions specific to our code
* base in this header file
*/

inline sole::uuid const nullUuid() {
	return { 0, 0 };
};

inline bool isNullUuid(sole::uuid uuid)
{
	return uuid == nullUuid();
}

bool isNullUuid(sole::uuid uuid);
namespace onyx {
namespace Utils {
			
	inline sole::uuid getUuid() {
		return sole::uuid4();
	}

} }
#endif
