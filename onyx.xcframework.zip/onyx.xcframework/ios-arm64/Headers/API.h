#pragma once

#include <cstdint>

namespace onyx {

	int initialize(uint32_t width, uint32_t height);
	void shutdown();

}