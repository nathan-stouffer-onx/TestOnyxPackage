/**
 * Declarations of functions that are bound and available to the 
 * Onyx Binding API for iOS.
 */

#pragma once

/**
 * Any functions that can be bound directly from the shared API header will be. 
 * Some functions require a web-specific implementation to wrap native types.
 */
#include "API/API.h"

#include <System/Resources/ResourceRequester.h>

namespace onyx::api::ios
{

    /**
	 * Function reference that takes no arguments and returns a boolean value.
	 *
	 * \warning This should be mapped to platform-native bool-function types in functions that return this type or expect it as a parameter.
	 */
    typedef bool (*BooleanFunction)(void);

    /**
     * Function reference that takes a string source id, the url of a tile, and the tile's id
     */
    typedef void (*TileReqCallbackFunction)(char const* source, char const* url, TileId id);

    /**
     * Function reference that takes a url string and 
     */
    typedef void (*BytestreamReqCallbackFunction)(char const* url, core::Resources::ResourceRequestType reqType);

    // As of 7/9/2024, adding data to std vector from Swift required the use of push_back, which is performance-heavy, so we chose this impl for now
    struct ByteStream
    {
        std::shared_ptr<std::vector<uint8_t>> data;

        ByteStream() : data(std::make_shared<std::vector<uint8_t>>()) {}
        ByteStream(void const* rawData, size_t count) : data(std::make_shared<std::vector<uint8_t>>())
        {
           uint8_t const* ptr = reinterpret_cast<uint8_t const*>(rawData);
           data->reserve(count);
           data->insert(data->begin(), ptr, ptr + count);
        }

    };

    // Sets the tile data for the requested TileCacheKey
    void setByteStream(TileCacheKey key, ByteStream stream);
    // Sets requested tile information as unavailable
    void setUnavailable(TileCacheKey key);

    int initialize(uint32_t width, uint32_t height, RawPointer metalLayer, RawPointer device, String const& prefix, BooleanFunction presentCallback, TileReqCallbackFunction tileBytestreamCallback);

    // Call to complete a bytestream request. Should be called within the BytestreamReqCallbackFunction
    void completeBytestreamRequest(core::Resources::ResourceIdentifier const& id, ByteStream stream, core::Resources::ResourceAvailability availability);
    // Sets the callback for retrieving a bytestream
    void setBytestreamRequestCallback(BytestreamReqCallbackFunction callback);

    void shutdown();

    // TODO remove these functions, they are part of our temporary API
    void setToken(String const& token);
    void setStyleByName(String const& filename);

    // TODO probably replace these functions with a more elegant solution
    void setPointerPosition(uint32_t pointerId, double newX, double newY, double newPressure);
    void setPointerUp(uint32_t pointerId);
    void setPointerDown(uint32_t pointerId);
}