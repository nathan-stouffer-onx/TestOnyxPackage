/**
 * Declarations of functions that are bound and available to the 
 * Onyx Binding API for iOS.
 */

#pragma once

/**
 * Any functions that can be bound directly from the shared API header will be. 
 * Some functions require a web-specific implementation to wrap native types.
 */
#include "API/API.h"

namespace onyx::api::ios
{

    /**
	 * Function reference that takes no arguments and returns a boolean value.
	 *
	 * \warning This should be mapped to platform-native bool-function types in functions that return this type or expect it as a parameter.
	 */
    typedef bool (*BooleanFunction)(void);

    int initialize(uint32_t width, uint32_t height, RawPointer metalLayer, RawPointer device, String const& prefix, BooleanFunction presentCallback);
	
    void shutdown();

    // TODO remove these functions, they are part of our temporary API
    void setToken(String const& token);
    void setStyleByName(String const& filename);

    // TODO probably replace these functions with a more elegant solution
    void setPointerPosition(uint32_t pointerId, double newX, double newY, double newPressure);
    void setPointerUp(uint32_t pointerId);
    void setPointerDown(uint32_t pointerId);

}