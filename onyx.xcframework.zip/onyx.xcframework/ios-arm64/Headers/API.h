#pragma once

#include <cstdint>

namespace onyx {

    int initialize(uint32_t width, uint32_t height, void* metalLayer, void* device, std::string const& prefix);
	void shutdown();

}