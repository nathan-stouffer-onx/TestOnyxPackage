#pragma once

#include <cstdint>

#include <string>

#include <lucid/gal/Types.h>

namespace onyx {

    // TODO remove these functions, they are part of our temporary API
    void setToken(std::string const& token);
    void setStyleByName(std::string const& name);

    int initialize(uint32_t width, uint32_t height, void* metalLayer, void* device, std::string const& prefix);
	void shutdown();

    void setCacheSize(size_t size);
    void purgeCache();

    // takes in a point on the globe and projects it to the screen
    // coordinates is a vector of the form [longitude, latitude]
    lgal::world::Vector2 point(lgal::world::Vector2 const& coordinates);
    // takes in a point on the screen and unprojects it to the world
    lgal::world::Vector2 coordinate(lgal::world::Vector2 const& point);

    void loadStyle(std::string const& url);

    void render();

    // TODO probably replace these functions with a more elegant solution
    void setPointerPosition(uint32_t pointerId, double newX, double newY, double newPressure);
    void setPointerUp(uint32_t pointerId);
    void setPointerDown(uint32_t pointerId);

}