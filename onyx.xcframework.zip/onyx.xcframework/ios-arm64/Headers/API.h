#pragma once

#include <cstdint>

#include <string>

namespace onyx {

    void setToken(std::string const& token);

    int initialize(uint32_t width, uint32_t height, void* metalLayer, void* device, std::string const& prefix);
	void shutdown();

    void render();

    void setPointerPosition(uint32_t pointerId, double newX, double newY, double newPressure);
    void setPointerUp(uint32_t pointerId);
    void setPointerDown(uint32_t pointerId);

}