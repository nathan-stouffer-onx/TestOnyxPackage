#pragma once

#include <cstdint>

#include <string>

namespace onyx {

    void setToken(std::string const& token);

    int initialize(uint32_t width, uint32_t height, void* metalLayer, void* device, std::string const& prefix);
	void shutdown();

    void render();

}