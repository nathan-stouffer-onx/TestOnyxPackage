#pragma once

#include <cstdint>

namespace onyx {

	int init(uint32_t width, uint32_t height);
	void shutdown();

}