#include "VectorLineMesh.h"

#include <Utils/UUID.h>

#include "Utils/BgfxUtils.h"

namespace onyx::Rendering
{

	VectorLineMesh::VectorLineMesh()
	{
		mIndices = { 0, 1, 2, 3 /*, 4, 5, 6, 7 */ };

		// Vertex.Pos is:
		// x: distance from center of the line
		// y: distance along the line
		// z: direction of end-cap
		// PosUV(float x, float y, float z, float u, float v);
		mVerts =
		{
			// vertex						// id
			{ { 1,  0, 0 }, { 1,  0 } },	//	0
			{ { -1, 0, 0 }, { -1, 0 } },	//	1
			{ { 1,  1, 0 }, { 1,  1 } },	//	2
			{ { -1, 1, 0 }, { -1, 1 } },	//	3
		};

		mVertexBuffer = bgfx::createVertexBuffer(bgfx::makeRef(mVerts.data(), uint32_t(sizeof(VertStructs::PosUV) * mVerts.size())), VertStructs::PosUV::ms_layout);
		mIndexBuffer = bgfx::createIndexBuffer(bgfx::makeRef(mIndices.data(), uint32_t(sizeof(uint16_t) * mIndices.size())));
		bgfx::setName(mVertexBuffer, "VectorLineMesh");
	}

	VectorLineMesh::~VectorLineMesh()
	{
		BgfxUtils::tryDestroy(mVertexBuffer);
		BgfxUtils::tryDestroy(mIndexBuffer);
	}

	bool VectorLineMesh::isValid() const
	{
		return mVertexBuffer.idx != bgfx::kInvalidHandle && mIndexBuffer.idx != bgfx::kInvalidHandle;
	}

	void VectorLineMesh::attach() const
	{
		// set vertex and index buffer.
		bgfx::setVertexBuffer(0, mVertexBuffer);
		bgfx::setIndexBuffer(mIndexBuffer);
	}

}