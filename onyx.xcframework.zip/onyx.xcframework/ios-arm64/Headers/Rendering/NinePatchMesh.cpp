#include "NinePatchMesh.h"

#include <Utils/UUID.h>
#include "Utils/BgfxUtils.h"

namespace onyx {
namespace Rendering {

NinePatchMesh::NinePatchMesh() :
	Drawable(ShaderEnums::ConfigurableShaders::Terrain)
	, mName("VectorLineMesh")
{
	mLayout.begin()
		.add(bgfx::Attrib::Normal, 4, bgfx::AttribType::Float)
		.add(bgfx::Attrib::Tangent, 4, bgfx::AttribType::Float)
		.end();

	generateVertsIndices();
}

NinePatchMesh::~NinePatchMesh()
{
	if (bgfx::isValid(mVertexBuffer))
	{
		bgfx::destroy(mVertexBuffer);
	}
	if (bgfx::isValid(mIndexBuffer))
	{
		bgfx::destroy(mIndexBuffer);
	}
}

// The patches are laid out on a grid:
//
//   0   1          2   3          4   5
// 0 +---+----------+---+----------+---+
//   | A |     B    | C |    D     | E |
// 1 +---+----------+---+----------+---+
//   |   |                         |   |
//   | F |            G            | H |
//   |   |                         |   |
// 2 +---+----------+---+----------+---+
//   | I |     J    | K |    L     | M |
// 3 +---+----------+---+----------+---+

void NinePatchMesh::generateVertsIndices()
{
	mIndices = {				// Cell
		// Tristrip topology
		   0,  6,  1,  7,  2,  8,  3,  9,  4, 10,  5, 11, 11,     // A - E
		   6,  6, 12,  7, 13, 10, 16, 11, 17, 17,                 // F G H
		  12, 12, 18, 13, 19, 14, 20, 15, 21, 16, 22, 17, 23      // I - M
		
		// Triangles topology
//		 0,  1,  6,  1,  6,  7, // A
//		 1,  2,  7,  2,  7,  8, // B
//		 2,  3,  8,  3,  8,  9, // C
//		 3,  4,  9,  4,  9, 10, // D
//		 4,  5, 10,  5, 10, 11, // E
//		 6,  7, 12,  7, 12, 13, // F
//		 7, 10, 13, 10, 13, 16, // G
//		10, 11, 16, 11, 16, 17, // H
//		12, 13, 18, 13, 18, 19, // I
//		13, 14, 19, 14, 19, 20, // J
//		14, 15, 20, 15, 20, 21, // K
//		15, 16, 21, 16, 21, 22, // L
//		16, 17, 22, 17, 22, 23, // M
	};

	mVerts = {
		// vertex 0, 0 can be implied if no X/Y position is set
		// grid X position        grid Y position
		//  1  2  3  4      5     1  2  3
		{ { 0, 0, 0, 0 }, { 0,    0, 0, 0 } }, // 0  (0, 0)
		{ { 1, 0, 0, 0 }, { 0,    0, 0, 0 } }, // 1  (0, 1)
		{ { 0, 1, 0, 0 }, { 0,    0, 0, 0 } }, // 2  (0, 2)
		{ { 0, 0, 1, 0 }, { 0,    0, 0, 0 } }, // 3  (0, 3)
		{ { 0, 0, 0, 1 }, { 0,    0, 0, 0 } }, // 4  (0, 4)
		{ { 0, 0, 0, 0 }, { 1,    0, 0, 0 } }, // 5  (0, 5)

		{ { 0, 0, 0, 0 }, { 0,    1, 0, 0 } }, // 6  (1, 0)
		{ { 1, 0, 0, 0 }, { 0,    1, 0, 0 } }, // 7  (1, 1)
		{ { 0, 1, 0, 0 }, { 0,    1, 0, 0 } }, // 8  (1, 2)
		{ { 0, 0, 1, 0 }, { 0,    1, 0, 0 } }, // 9  (1, 3)
		{ { 0, 0, 0, 1 }, { 0,    1, 0, 0 } }, // 10 (1, 4)
		{ { 0, 0, 0, 0 }, { 1,    1, 0, 0 } }, // 11 (1, 5)

		{ { 0, 0, 0, 0 }, { 0,    0, 1, 0 } }, // 12 (2, 0)
		{ { 1, 0, 0, 0 }, { 0,    0, 1, 0 } }, // 13 (2, 1)
		{ { 0, 1, 0, 0 }, { 0,    0, 1, 0 } }, // 14 (2, 2)
		{ { 0, 0, 1, 0 }, { 0,    0, 1, 0 } }, // 15 (2, 3)
		{ { 0, 0, 0, 1 }, { 0,    0, 1, 0 } }, // 16 (2, 4)
		{ { 0, 0, 0, 0 }, { 1,    0, 1, 0 } }, // 17 (2, 5)

		{ { 0, 0, 0, 0 }, { 0,    0, 0, 1 } }, // 18 (3, 0)
		{ { 1, 0, 0, 0 }, { 0,    0, 0, 1 } }, // 19 (3, 1)
		{ { 0, 1, 0, 0 }, { 0,    0, 0, 1 } }, // 20 (3, 2)
		{ { 0, 0, 1, 0 }, { 0,    0, 0, 1 } }, // 21 (3, 3)
		{ { 0, 0, 0, 1 }, { 0,    0, 0, 1 } }, // 22 (3, 4)
		{ { 0, 0, 0, 0 }, { 1,    0, 0, 1 } }, // 23 (3, 5)
	};

	// Create static vertex buffer.
	mVertexBuffer = bgfx::createVertexBuffer(
		bgfx::makeRef(mVerts.data(), uint32_t(sizeof(vertT) * mVerts.size()))
		, mLayout
	);

	// Create static index buffer for triangle strip rendering.
	mIndexBuffer = bgfx::createIndexBuffer(
		bgfx::makeRef(mIndices.data(), uint32_t(sizeof(uint16_t) * mIndices.size()))
	);

	bgfx::setName(mVertexBuffer, mName.c_str());
}

bool NinePatchMesh::isValid() const
{
	return bgfx::isValid(mVertexBuffer) && bgfx::isValid(mIndexBuffer);
}

void NinePatchMesh::setName(std::string name)
{
	mName = name;
	if (bgfx::isValid(mVertexBuffer))
	{
		bgfx::setName(mVertexBuffer, mName.c_str());
	}
}

void NinePatchMesh::attach() const
{
	// Set vertex and index buffer.
	bgfx::setVertexBuffer(0, mVertexBuffer);
	bgfx::setIndexBuffer(mIndexBuffer);
}

} }