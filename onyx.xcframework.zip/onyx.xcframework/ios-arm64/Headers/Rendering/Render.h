#pragma once

#include <string>
#include <vector>

#include <bgfx/bgfx.h>

#include <Shaders/ShaderDefinition.h>

#include "Rendering/VectorLineMesh.h"
#include "Rendering/VertStructs.h"

namespace onyx::Rendering
{
	
	void render(bgfx::ViewId renderId, std::vector<VertStructs::ScreenLineData> const& instances, std::string const& dashStyle, VectorLineMesh const& mesh, uint64_t bgfxRenderState, Shaders::ShaderDefinition& shader);

}