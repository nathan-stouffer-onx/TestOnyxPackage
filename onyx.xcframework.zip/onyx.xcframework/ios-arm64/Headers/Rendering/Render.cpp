#include "Render.h"

#include "DataObjects/DashStyleManager.h"

namespace onyx::Rendering
{

	void render(bgfx::ViewId renderId, std::vector<VertStructs::ScreenLineData> const& instances, std::string const& dashStyle, VectorLineMesh const& mesh, uint64_t bgfxRenderState, Shaders::ShaderDefinition& shader)
	{
		auto maxInstances = bgfx::getAvailInstanceDataBuffer(uint32_t(instances.size()), uint32_t(sizeof(Rendering::VertStructs::InstanceData4)));

		if (maxInstances == 0)
		{
			return;
		}

		bgfx::InstanceDataBuffer idb;
		bgfx::allocInstanceDataBuffer(&idb, maxInstances, uint32_t(sizeof(Rendering::VertStructs::InstanceData4)));

		if (idb.num > 0 && idb.num <= instances.size())
		{
			mesh.attach();
			shader.setParameter("u_drawColor", lgal::Color(0.f, 0, 0, 0));
			shader.setParameter("s_DashSampler", DataObjects::DashStyleManager::get(dashStyle));

			std::memcpy(idb.data, instances.data(), size_t(idb.num) * sizeof(Rendering::VertStructs::InstanceData4));
			bgfx::setInstanceDataBuffer(&idb);
			bgfx::setState(bgfxRenderState | BGFX_STATE_PT_TRISTRIP);
			bgfx::submit(renderId, shader.mInstancedHandle);
		}
	}

}