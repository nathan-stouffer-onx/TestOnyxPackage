#ifndef _VERTSTRUCTS_H_
#define _VERTSTRUCTS_H_

#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include <Warnings.h>

namespace onyx {
namespace Rendering {
namespace VertStructs {

	// I don't love all of these typedefs but they make the declarations a lot more readable.
	typedef lgal::gpu::Vector2 Vec2_t;
	typedef lgal::gpu::Vector3 Vec3_t;
	typedef lgal::gpu::Vector4 Vec4_t;

	typedef lgal::gpu::LineSegment2 LineSegment_t;
	typedef lgal::gpu::AABB2d AABB_t;

	void initialize();

#pragma pack(push,1)
#pragma pack(1)
	template<int DIM>
	struct InstanceData
	{
		lgal::gpu::Vector4 data[DIM];
		static bgfx::VertexLayout ms_layout;
		
		static void init()
		{
			ms_layout.begin();
			for (int i = 0; i < DIM; ++i)
			{
				ms_layout.add(bgfx::Attrib::Enum(bgfx::Attrib::TexCoord0 + i), 4,
					bgfx::AttribType::Float
				);
			}
			ms_layout.end();
            
            bgfx::createVertexLayout(ms_layout);
		}
	};

	using InstanceData1 = InstanceData<1>;
	using InstanceData2 = InstanceData<2>;
	using InstanceData3 = InstanceData<3>;
	using InstanceData4 = InstanceData<4>;
	using InstanceData5 = InstanceData<5>;
	
	template <int DIM>
	bgfx::VertexLayout InstanceData<DIM>::ms_layout;

	static constexpr uint8_t cMaxInstancedParameters = 5 * 4;	// instanced parameters come in blocks of 4 floats. we can have a max of 5 blocks

	struct LineData
	{

		LineSegment_t segment;
		Vec2_t prev;
		Vec2_t next;
		gpu_float_t	lineLengthA;
		gpu_float_t	lineLengthB;
		Vec2_t		paramsPos;

		LineData(Vec2_t const &paramsPos, LineSegment_t const& segment, Vec2_t prev, Vec2_t next, gpu_float_t lineLenA, gpu_float_t lineLenB) :
			segment(segment),
			prev(prev),
			next(next),
			lineLengthA(lineLenA),
			lineLengthB(lineLenB),
			paramsPos(paramsPos)
		{}

	};

	struct ScreenLineData
	{
		Vec3_t		position;
		gpu_float_t	lineWidth;

		Vec3_t		direction;
		gpu_float_t	length;

		Vec4_t		color;

		gpu_float_t	p1Cap;
		gpu_float_t	p2Cap;
		gpu_float_t	unused1[2];

DISABLE_WARNING_PUSH
DISABLE_WARNING_UNINITIALIZED
		ScreenLineData(gpu_float_t p1Cap, gpu_float_t p2Cap, lgal::Color const &color, Vec3_t const &position, Vec3_t const &direction, gpu_float_t length, gpu_float_t lineWidth)
			: 
				position(position),
				lineWidth(lineWidth),
				direction(direction),
				length(length),
				color({ color.r, color.g, color.b, color.a }),
				p1Cap(p1Cap),
				p2Cap(p2Cap)
		{
		}
DISABLE_WARNING_POP

	};

#pragma pack(pop)

	struct Pos
	{
		Pos() : pos(0) {}
		Pos(lgal::gpu::Vector3 const& p) : pos(p) { }
		lgal::gpu::Vector3 pos;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const Pos& oth);
		bool operator!=(const Pos& oth);
	};

#pragma pack(push, 1)
#pragma pack(1)
	struct PosUV
	{
		lgal::gpu::Vector3 pos;
		lgal::gpu::Vector2 uv;

		static void init();
		static bgfx::VertexLayout ms_layout;
	};
#pragma pack(pop)

#pragma pack(push, 1)
#pragma pack(1)
	struct UV2
	{
		lgal::gpu::Vector2 uv1;
		lgal::gpu::Vector2 uv2;

		static void init();
		static bgfx::VertexLayout ms_layout;
	};
#pragma pack(pop)

	class PosColor
	{
	public:

		PosColor() {}
		PosColor(float x, float y, float z, uint32_t abgr);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const PosColor& oth);
		bool operator!=(const PosColor& oth);
	};

	class PosColorUV
	{
	public:

		PosColorUV() {}
		PosColorUV(float x, float y, float z, uint32_t abgr, float u, float v);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		float m_u = 0;
		float m_v = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const PosColorUV& oth);
		bool operator!=(const PosColorUV& oth);
	};

	class PosColorUV2
	{

	public:

		PosColorUV2() {}
		PosColorUV2(float x, float y, float z, uint32_t abgr, float u, float v, float u2, float v2);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		float m_u = 0;
		float m_v = 0;
		float m_u2 = 0;
		float m_v2 = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const PosColorUV2& oth);
		bool operator!=(const PosColorUV2& oth);
	};

	class PosColorNormalUV
	{
	public:

		PosColorNormalUV() {}
		PosColorNormalUV(float x, float y, float z, uint32_t abgr, float nx, float ny, float nz, float u, float v);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		float m_nx = 0;
		float m_ny = 0;
		float m_nz = 0;
		float m_u = 0;
		float m_v = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool equWeak(const PosColorNormalUV& oth, float const epsilon = lmath::constants::tol_tol<float>());
		bool operator==(const PosColorNormalUV& oth);
		bool operator!=(const PosColorNormalUV& oth);
	};

	// Uses attribute type TexCoord0 instead of 7
	class PosColor2UV
	{
	public:

		PosColor2UV() {}
		PosColor2UV(float x, float y, float z, uint32_t abgr, uint32_t abgr2, float u, float v);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		uint32_t m_abgr2 = 0;
		float m_u = 0;
		float m_v = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const PosColor2UV& oth);
		bool operator!=(const PosColor2UV& oth);

	};

	class PosColor3UV
	{
	public:

		PosColor3UV() {}
		PosColor3UV(float x, float y, float z, uint32_t abgr, uint32_t abgr2, uint32_t abgr3, float u, float v);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		uint32_t m_abgr2 = 0;
		uint32_t m_abgr3 = 0;
		float m_u = 0;
		float m_v = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const PosColor3UV& oth);
		bool operator!=(const PosColor3UV& oth);

	};

	class PosColor4NormalUV
	{
	public:

		PosColor4NormalUV() {}
		PosColor4NormalUV(float x, float y, float z,
			uint32_t abgr, uint32_t abgr2, uint32_t abgr3, uint32_t abgr4,
			float nx, float ny, float nz, float u, float v);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		uint32_t m_abgr2 = 0;
		uint32_t m_abgr3 = 0;
		uint32_t m_abgr4 = 0;
		float m_nx = 0;
		float m_ny = 0;
		float m_nz = 0;
		float m_u = 0;
		float m_v = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const PosColor4NormalUV& oth);
		bool operator!=(const PosColor4NormalUV& oth);
	};

	class LineVert //special case for vertices used for vector lines
	{
		//position 3
		//color int
		//tangents 3
		//angles 2
		//segment 2
		//texcoord 2
	public:

		LineVert() {}
		LineVert(float x, float y, float z, uint32_t abgr, float tx, float ty, float tz, float ax, float ay, float sx, float sy, float u, float v, float index);
		float m_x = 0;
		float m_y = 0;
		float m_z = 0;
		uint32_t m_abgr = 0;
		float m_tangentx = 0;
		float m_tangenty = 0;
		float m_tangentz = 0;
		float m_anglex = 0;
		float m_angley = 0;
		float m_segmentx = 0;
		float m_segmenty = 0;
		float m_u = 0;
		float m_v = 0;
		float m_index = 0;

		static void init();
		static bgfx::VertexLayout ms_layout;

		bool operator==(const LineVert& oth);
		bool operator!=(const LineVert& oth);
	};

} } }

#endif
