#ifndef __VIEW_ID_H__
#define __VIEW_ID_H__

#include <bgfx/bgfx.h>

namespace onyx {
namespace Rendering {
namespace ViewId
{
	enum class Type
	{
		RenderToTexture = 10,		// leave room for atlas blitting in view ids [0, 10]
		MainDraw = 200,
		Composite = 250				// we need a view id for blitting back depths and copying textures to the screen
	};

	void shutdown();

	// call at the beginning of each frame to reset the view id counts
	void reset();
	
	// get the next view id for the specified type
	bgfx::ViewId next(Type type);

} } }

#endif