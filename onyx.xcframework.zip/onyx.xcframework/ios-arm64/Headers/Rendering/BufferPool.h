#pragma once

#include <vector>
#include <memory>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include "Utils/BgfxUtils.h"

namespace onyx::Rendering
{

	/*
	* BufferPool is a class that manages pools of vertices/indices and allocates memory for them on the gpu. We only use 16 bit
	* index buffers for cross platform compatibility (on gpu). BufferPool lets us automatically split things into chunks, as
	* long as each add is < 65k indices. So far, there is no reason to support breaking up a mesh into chunks, but we could add
	* that later if we end up with really complex meshes
	*/

	template <typename T>
	struct BufferPool // T is vertex type
	{
	public:

		struct Key
		{
			size_t index = std::numeric_limits<size_t>::max();
			lgal::array::Range range = { std::numeric_limits<size_t>::max(), std::numeric_limits<size_t>::max() };	// set up to work like iterators: [begin, end)

			Key() {}
			Key(size_t _index, lgal::array::Range _range) : index(_index), range(_range) {}
		};

		struct Page
		{
			std::vector<T> vertices;
			std::vector<uint16_t> indices;

			Page() = default;
			Page(std::vector<T> const& _vertices, std::vector<uint16_t> const& _indices) : vertices(_vertices), indices(_indices) {}
		};

	public:

		BufferPool() : mIsDirty(true) {}

		BufferPool(BufferPool const& rhs) = delete;
		BufferPool& operator=(BufferPool const& rhs) = delete;

		BufferPool(BufferPool const&& rhs) = delete;
		BufferPool& operator=(BufferPool const&& rhs) = delete;

		~BufferPool()
		{
			for (auto& handle : mVertexBuffers) { BgfxUtils::tryDestroy(handle); }
			for (auto& handle : mIndexBuffers) { BgfxUtils::tryDestroy(handle); }
		}

		void push_back(Page&& page)
		{
			mIsDirty = true;
			mSize += 2 * sizeof(T) * page.vertices.size();
			mSize += 2 * sizeof(uint16_t) * page.indices.size();
			mPages.push_back(std::move(page));
		}

		Key insert(std::vector<T> const& vertices, std::vector<uint16_t> const& indices)
		{
			mIsDirty = true;

			// multiply by 2 to account for the copy on the gpu
			mSize += 2 * sizeof(T) * vertices.size();
			mSize += 2 * sizeof(uint16_t) * indices.size();

			if (mPages.size() == 0 || mPages.back().indices.size() + indices.size() >= (2 << 15))	// allocate a fresh page
			{
				mPages.push_back(Page(vertices, indices));

				size_t index = mPages.size() - 1;
				size_t end = mPages[index].vertices.size();
				return { index, { 0, end } };
			}
			else // room to add on to existing one
			{
				Page& page = mPages.back();

				size_t index = mPages.size() - 1;
				size_t begin = page.vertices.size();
				size_t end = begin + vertices.size();

				size_t first = page.indices.size();

				page.vertices.insert(page.vertices.end(), vertices.begin(), vertices.end());	// add the new verts
				page.indices.insert(page.indices.end(), indices.begin(), indices.end());		// add the new indices

				// offset indices within the pool
				for (size_t i = first; i < page.indices.size(); ++i)
				{
					page.indices[i] += static_cast<uint16_t>(begin);
				}

				return { index, { begin, end } };
			}

		}

		void write(Key key, std::vector<T> const& vertices)
		{
			Page& page = mPages[key.index];
			// TODO convert this to a std::memcpy?
			for (size_t i = 0, j = key.range.begin; i < vertices.size(); ++i, ++j)
			{
				page.vertices[j] = vertices[i];
			}

			if (!mIsDirty)		// if not dirty, update the DynamicVertexBuffer
			{
				bgfx::Memory const* mem = bgfx::copy(&page.vertices[key.range.begin], sizeof(T) * (uint32_t)vertices.size());
				bgfx::update(mVertexBuffers[key.index], static_cast<uint32_t>(key.range.begin), mem);
			}
		}

		bool attach(size_t index, lgal::array::Range const& indices = { 0, std::numeric_limits<size_t>::max() }) const
		{
			if (mIsDirty) { allocate(); }

			ONYX_ASSERT(index < mVertexBuffers.size(), "Invalid buffer index requested")
			if (!bgfx::isValid(mVertexBuffers[index])) { return false; }

			bgfx::setVertexBuffer(0, mVertexBuffers[index]);
			if (mIndexBuffers.size() > index && bgfx::isValid(mIndexBuffers[index]))
			{
				auto size	= mPages[index].indices.size();
				auto first	= uint32_t(std::min(indices.begin, size));
				auto last	= uint32_t(std::min(indices.end, size));

				if (first != 0 || last != (uint32_t)size)
				{
					bgfx::setIndexBuffer(mIndexBuffers[index], first, (last - first));
				}
				else
				{
					bgfx::setIndexBuffer(mIndexBuffers[index]);
				}
			}
			return true;
		}

		void draw(bgfx::ViewId viewId, lgal::gpu::Vector3 const& pos, lgal::gpu::Vector3 const& extents, bgfx::ProgramHandle program, uint64_t flags = (uint64_t)0)
		{
			allocate();	// allocate gpu data (only does something if isDirty == true)

			if (mIndexBuffers.empty()) { return; }

			auto mtx = lgal::gpu::Scale<4>( { extents.x, extents.y, 1.0f, 1.0f });
			//position it
			mtx.elements[12] = pos.x;
			mtx.elements[13] = pos.y;
			mtx.elements[14] = pos.z;

			// Set model matrix for rendering.
			bgfx::setTransform(mtx.elements);

			for (size_t i = 0; i < mIndexBuffers.size(); i++)
			{
				if (!bgfx::isValid(mIndexBuffers[i]) || !bgfx::isValid(mVertexBuffers[i])) { continue; }

				// Set render states
				uint64_t state = 0
					| BGFX_STATE_WRITE_RGB
					| BGFX_STATE_WRITE_A
#ifdef ENABLE_MSAA
					| BGFX_STATE_MSAA
#endif
					| BGFX_STATE_WRITE_Z
					;
		
				if (mIndexBuffers.size() == 0) // must be a line list
				{
					// Set vertex and index buffer.
					bgfx::setVertexBuffer(0, mVertexBuffers[i]);
					bgfx::setState(state | BGFX_STATE_PT_TRISTRIP | flags);
				}
				else
				{
					// Set vertex and index buffer.
					bgfx::setVertexBuffer(0, mVertexBuffers[i]);
					bgfx::setIndexBuffer(mIndexBuffers[i]);
					bgfx::setState(state | flags);
				}
				bgfx::submit(viewId, program);
			}
		}

		void allocate() const
		{
			if (mIsDirty)
			{
				for (auto& handle : mVertexBuffers) { BgfxUtils::tryDestroy(handle); }
				for (auto& handle : mIndexBuffers) { BgfxUtils::tryDestroy(handle); }

				mVertexBuffers.clear();
				mIndexBuffers.clear();

				for (size_t i = 0; i < mPages.size(); ++i)
				{
					Page const& page = mPages[i];
					if (page.vertices.size() > 2 && page.indices.size() > 2)
					{
						{
							bgfx::Memory const* mem = bgfx::copy(page.vertices.data(), sizeof(T) * (uint32_t)page.vertices.size());
							auto buffer = bgfx::createDynamicVertexBuffer((uint32_t)page.vertices.size(), T::ms_layout, BGFX_BUFFER_ALLOW_RESIZE);
							// Keep dirty bit because we failed to update our buffers
							if (!bgfx::isValid(buffer)) { return; }

							mVertexBuffers.push_back(buffer);
							bgfx::update(mVertexBuffers[mVertexBuffers.size() - 1], 0, mem);
						}

						{
							bgfx::Memory const* mem = bgfx::copy(page.indices.data(), sizeof(uint16_t) * (uint32_t)page.indices.size());
							auto buffer = bgfx::createDynamicIndexBuffer((uint32_t)page.indices.size(), BGFX_BUFFER_ALLOW_RESIZE);
							// Keep dirty bit because we failed to update our buffers
							if (!bgfx::isValid(buffer)) { return; }

							mIndexBuffers.push_back(buffer);
							bgfx::update(mIndexBuffers[mIndexBuffers.size() - 1], 0, mem);
						}
					}
				}

				mIsDirty = false;
			}
		}
	
		void clear()
		{
			mPages.clear();
			mSize = 0;
			mIsDirty = true;
		}

		inline Page const& operator[](size_t i) const { return mPages[i]; }
		inline std::vector<Page> const& pages() const { return mPages; }
		inline size_t size() const { return mSize; }


	private:

		size_t mSize = 0;
		bool mutable mIsDirty = true;		// indicator for whether cpu data matches gpu data

		std::vector<Page> mPages;

		std::vector<bgfx::DynamicVertexBufferHandle> mutable mVertexBuffers;
		std::vector<bgfx::DynamicIndexBufferHandle> mutable mIndexBuffers;

	};

}