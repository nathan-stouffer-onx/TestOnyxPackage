#pragma once

#include <lucid/gal/Types.h>

#include "Rendering/VertStructs.h"
#include "General/Drawable.h"

namespace onyx {
namespace Rendering {

	struct NinePatchVert
	{
		lgal::gpu::Vector4 p1;
		lgal::gpu::Vector4 p2;
	};

	struct NinePatchInstance
	{
		// UV offsets in texture space relative to top-left UV coordinate in pixels
		lgal::gpu::Vector4 patchOffsets1;
		lgal::gpu::Vector4 patchOffsets2;
		// Top-left screen position of *content* cell
		lgal::gpu::Vector2 screenPosPx;
		// Size of *content* cell
		lgal::gpu::Vector2 screenSizePx;
		lgal::gpu::Vector2 uv;
		
		gpu_float_t orientToVpPlane;
		gpu_float_t rad;
	};

class NinePatchMesh : public Drawable<NinePatchVert>
{
public:
	NinePatchMesh();
	~NinePatchMesh();

	void generateVertsIndices() override;

	void setName(std::string name);
	bool isValid() const;
	void attach() const;

	bgfx::VertexLayout const& getLayout() const { return mLayout; }

private:
	std::string mName;

	bgfx::VertexBufferHandle mVertexBuffer;
	bgfx::IndexBufferHandle mIndexBuffer;

	bgfx::VertexLayout mLayout;
};

} }

