#pragma once

#include <vector>

#include "Rendering/VertStructs.h"

namespace onyx::Rendering
{

	class VectorLineMesh
	{
	public:

		VectorLineMesh();
		~VectorLineMesh();

		bool isValid() const;
		void attach() const;

	private:

		std::vector<VertStructs::PosUV> mVerts;
		std::vector<uint16_t> mIndices;

		bgfx::VertexBufferHandle mVertexBuffer;
		bgfx::IndexBufferHandle mIndexBuffer;
	};

}