#include "VertStructs.h"

#include <lucid/math/Algorithm.h>

namespace onyx {
namespace Rendering {
namespace VertStructs {

	// compile-time asserts that our instanced structs don't require too much data
	static_assert(sizeof(LineData)       <= (cMaxInstancedParameters * sizeof(float)), "LineData exceeds the maximum number of instanced parameters bgfx can accept");
	static_assert(sizeof(ScreenLineData) <= (cMaxInstancedParameters * sizeof(float)), "ScreenLineData exceeds the maximum number of instanced parameters bgfx can accept");

	// compile-time asserts that our instanced structs fit into the 4-float blocks that bgfx expects
	static_assert(sizeof(LineData)       % (4 * sizeof(float)) == 0, "LineData does not map perfectly to 4-float blocks -- required for instancing in bgfx");
	static_assert(sizeof(ScreenLineData) % (4 * sizeof(float)) == 0, "ScreenLineData does not map perfectly to 4-float blocks -- required for instancing in bgfx");

	bgfx::VertexLayout UV2::ms_layout;
	bgfx::VertexLayout PosColor::ms_layout;
	bgfx::VertexLayout PosUV::ms_layout;
	bgfx::VertexLayout PosColorUV::ms_layout;
	bgfx::VertexLayout PosColor2UV::ms_layout;
	bgfx::VertexLayout PosColor3UV::ms_layout;
	bgfx::VertexLayout PosColorUV2::ms_layout;
	bgfx::VertexLayout PosColorNormalUV::ms_layout;
	bgfx::VertexLayout LineVert::ms_layout;
	bgfx::VertexLayout PosColor4NormalUV::ms_layout;

	void initialize()
	{
		// initialize all VertStructs on start up to avoid data races
		Pos::init();
		PosUV::init();
		PosColor::init();
		PosColorUV::init();
		PosColor2UV::init();
		PosColor3UV::init();
		PosColorUV2::init();
		PosColorNormalUV::init();
		LineVert::init();
		PosColor4NormalUV::init();
		UV2::init();

		InstanceData1::init();
		InstanceData2::init();
		InstanceData3::init();
		InstanceData4::init();
		InstanceData5::init();
	}

	bgfx::VertexLayout Pos::ms_layout;

	void Pos::init()
	{
		Pos::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	bool Pos::operator==(const Pos& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return oth.pos == pos;		// check position equality
	}

	bool Pos::operator!=(const Pos& oth)
	{
		return !(*this == oth);
	}

	void PosUV::init()
	{
		PosUV::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::TexCoord0, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	void UV2::init()
	{
		UV2::ms_layout
			.begin()
			.add(bgfx::Attrib::TexCoord7, 4, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	VertStructs::PosColor::PosColor(float x, float y, float z, uint32_t abgr) :
		m_x(x),
		m_y(y),
		m_z(z),
		m_abgr(abgr)
	{

	}

	void VertStructs::PosColor::init()
	{
		PosColor::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.end();

		bgfx::createVertexLayout(ms_layout);
	};

	bool VertStructs::PosColor::operator==(const PosColor& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&		// check position equality
				m_abgr == oth.m_abgr;										// check color equality
	}

	bool VertStructs::PosColor::operator!=(const PosColor& oth)
	{
		return !(*this == oth);
	}

	VertStructs::PosColorUV::PosColorUV(float x, float y, float z, uint32_t abgr, float u, float v) :
		m_x(x),
		m_y(y),
		m_z(z),
		m_abgr(abgr),
		m_u(u),
		m_v(v)
	{

	}

	void VertStructs::PosColorUV::init()
	{
		PosColorUV::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::TexCoord7, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	};


	bool VertStructs::PosColorUV::operator==(const PosColorUV& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&		// check position equality
				m_abgr == oth.m_abgr &&										// check color equality
				m_u == oth.m_u && m_v == oth.m_v;							// check uv coord equality
	}

	PosColor2UV::PosColor2UV(float x, float y, float z, uint32_t abgr, uint32_t abgr2, float u, float v) :
		m_x(x), m_y(y), m_z(z),
		m_abgr(abgr), m_abgr2(abgr2),
		m_u(u), m_v(v)
	{}

	void PosColor2UV::init()
	{
		PosColor2UV::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Color1, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::TexCoord0, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	bool PosColor2UV::operator==(const PosColor2UV& oth)
	{
		if (this == &oth)
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&
				m_abgr == oth.m_abgr && m_abgr2 == oth.m_abgr2 &&
				m_u == oth.m_u && m_v == oth.m_v;
	}

	bool PosColor2UV::operator!=(const PosColor2UV& oth)
	{
		return !(*this == oth);
	}

	bool VertStructs::PosColorUV::operator!=(const PosColorUV& oth)
	{
		return !(*this == oth);
	}

	PosColor3UV::PosColor3UV(float x, float y, float z, 
		uint32_t abgr, uint32_t abgr2, uint32_t abgr3, float u, float v) :
		m_x(x), m_y(y), m_z(z),
		m_abgr(abgr), m_abgr2(abgr2), m_abgr3(abgr3),
		m_u(u), m_v(v)
	{}

	void PosColor3UV::init()
	{
		PosColor3UV::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Color1, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Color2, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::TexCoord0, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	bool PosColor3UV::operator==(const PosColor3UV& oth)
	{
		if (this == &oth)
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&
				m_abgr == oth.m_abgr && m_abgr2 == oth.m_abgr2 && m_abgr3 == oth.m_abgr3 &&
				m_u == oth.m_u && m_v == oth.m_v;
	}

	bool PosColor3UV::operator!=(const PosColor3UV& oth)
	{
		return !(*this == oth);
	}

	VertStructs::PosColorUV2::PosColorUV2(float x, float y, float z, uint32_t abgr, float u, float v, float u2, float v2) :
		m_x(x),
		m_y(y),
		m_z(z),
		m_abgr(abgr),
		m_u(u),
		m_v(v),
		m_u2(u2),
		m_v2(v2)
	{

	}

	void VertStructs::PosColorUV2::init()
	{
		PosColorUV2::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::TexCoord6, 2, bgfx::AttribType::Float)
			.add(bgfx::Attrib::TexCoord7, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	bool VertStructs::PosColorUV2::operator==(const PosColorUV2& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&		// check position equality
				m_abgr == oth.m_abgr &&										// check color equality
				m_u == oth.m_u && m_v == oth.m_v &&							// check uv coord equality
				m_u2 == oth.m_u2 && m_v2 == oth.m_v2;						// check uv2 coord equality
	}

	bool VertStructs::PosColorUV2::operator!=(const PosColorUV2& oth)
	{
		return !(*this == oth);
	}

	VertStructs::PosColorNormalUV::PosColorNormalUV(float x, float y, float z, uint32_t abgr, float nx, float ny, float nz, float u, float v) :
		m_x(x),
		m_y(y),
		m_z(z),
		m_abgr(abgr),
		m_nx(nx),
		m_ny(ny),
		m_nz(nz),
		m_u(u),
		m_v(v)
	{

	}

	void VertStructs::PosColorNormalUV::init()
	{
		PosColorNormalUV::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Normal, 3, bgfx::AttribType::Float, true)
			.add(bgfx::Attrib::TexCoord7, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	};

	bool VertStructs::PosColorNormalUV::equWeak(const PosColorNormalUV& oth, float const epsilon)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		// check position equality
		return lucid::math::equWeak(m_x, oth.m_x, epsilon) && lucid::math::equWeak(m_y, oth.m_y, epsilon) && lucid::math::equWeak(m_z, oth.m_z, epsilon) &&
				// check color equality
				m_abgr == oth.m_abgr &&
				// check normal equality
				lucid::math::equWeak(m_nx, oth.m_nx, epsilon) && lucid::math::equWeak(m_ny, oth.m_ny, epsilon) && lucid::math::equWeak(m_nz, oth.m_nz, epsilon) &&
				// check uv coord equality
				lucid::math::equWeak(m_u, oth.m_u, epsilon) && lucid::math::equWeak(m_v, oth.m_v, epsilon);
	}

	bool VertStructs::PosColorNormalUV::operator==(const PosColorNormalUV& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&				// check position equality
				m_abgr == oth.m_abgr &&												// check color equality
				m_nx == oth.m_nx && m_ny == oth.m_ny && m_nz == oth.m_nz &&			// check normal equality
				m_u == oth.m_u && m_v == oth.m_v;									// check uv coord equality
	}

	bool VertStructs::PosColorNormalUV::operator!=(const PosColorNormalUV& oth)
	{
		return !(*this == oth);
	}

	VertStructs::PosColor4NormalUV::PosColor4NormalUV(float x, float y, float z,
		uint32_t abgr, uint32_t abgr2, uint32_t abgr3, uint32_t abgr4,
		float nx, float ny, float nz, float u, float v) :
		m_x(x),
		m_y(y),
		m_z(z),
		m_abgr(abgr),
		m_abgr2(abgr2),
		m_abgr3(abgr3),
		m_abgr4(abgr4),
		m_nx(nx),
		m_ny(ny),
		m_nz(nz),
		m_u(u),
		m_v(v)
	{

	}

	void VertStructs::PosColor4NormalUV::init()
	{
		PosColor4NormalUV::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Color1, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Color2, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Color3, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Normal, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::TexCoord0, 2, bgfx::AttribType::Float)
			.end();

		bgfx::createVertexLayout(ms_layout);
	};

	bool VertStructs::PosColor4NormalUV::operator==(const PosColor4NormalUV& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&	// check position equality
			m_abgr == oth.m_abgr &&										// check color equality
			m_abgr2 == oth.m_abgr2 &&									// check color 2 equality
			m_abgr3 == oth.m_abgr3 &&									// check color 3 equality
			m_abgr4 == oth.m_abgr4 &&									// check color 4 equality
			m_nx == oth.m_nx && m_ny == oth.m_ny && m_nz == oth.m_nz &&	// check normal equality
			m_u == oth.m_u && m_v == oth.m_v;							// check uv coord equality
	}

	bool VertStructs::PosColor4NormalUV::operator!=(const PosColor4NormalUV& oth)
	{
		return !(*this == oth);
	}

	VertStructs::LineVert::LineVert(float x, float y, float z, uint32_t abgr, float tx, float ty, float tz, float ax, float ay, float sx, float sy, float u, float v, float index) :
		m_x(x), 
		m_y(y), 
		m_z(z), 
		m_abgr(abgr), 
		m_tangentx(tx), 
		m_tangenty(ty), 
		m_tangentz(tz), 
		m_anglex(ax), 
		m_angley(ay), 
		m_segmentx(sx), 
		m_segmenty(sy), 
		m_u(u), 
		m_v(v),
		m_index(index)
	{

	}

	//NOTE - for some unknown reason, this vert class is currently having issues with data retention, position.y keeps having garbage??
	void VertStructs::LineVert::init()
	{
		LineVert::ms_layout
			.begin()
			.add(bgfx::Attrib::Position, 3, bgfx::AttribType::Float)
			.add(bgfx::Attrib::Color0, 4, bgfx::AttribType::Uint8, true)
			.add(bgfx::Attrib::Tangent, 3, bgfx::AttribType::Float, true)
			.add(bgfx::Attrib::TexCoord6, 4, bgfx::AttribType::Float) //angles
			.add(bgfx::Attrib::TexCoord5, 2, bgfx::AttribType::Float) //segment
			.add(bgfx::Attrib::TexCoord7, 2, bgfx::AttribType::Float) //uv
			.add(bgfx::Attrib::TexCoord4, 1, bgfx::AttribType::Float) //index
			.end();

		bgfx::createVertexLayout(ms_layout);
	}

	bool VertStructs::LineVert::operator==(const LineVert& oth)
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return m_x == oth.m_x && m_y == oth.m_y && m_z == oth.m_z &&				// check position equality
				m_abgr == oth.m_abgr &&												// check color equality
				m_tangentx == oth.m_tangentx &&										// check tangentx equality
				m_tangenty == oth.m_tangenty &&										// check tangenty equality
				m_tangentz == oth.m_tangentz &&										// check tangentz equality
				m_anglex == oth.m_anglex && m_angley == oth.m_angley &&				// check angle equality
				m_segmentx == oth.m_segmentx && m_segmenty == oth.m_segmenty &&		// check segment equality
				m_u == oth.m_u && m_v == oth.m_v &&									// check uv coord equality
				m_index == oth.m_index;												// check index equality
	}

	bool VertStructs::LineVert::operator!=(const LineVert& oth)
	{
		return !(*this == oth);
	}

} } }