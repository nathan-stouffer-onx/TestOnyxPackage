#pragma once

#include <memory>

#include <lucid/gal/Types.h>
#include <Styling/Styles/TextStyle.h>

#include "Font/FontManager.h"

namespace onyx::Style
{

	class TextStyleManager
	{
	public:

		static std::shared_ptr<Styling::TextStyle> find(Styling::TextStyle const& style);
		static std::shared_ptr<Styling::TextStyle> cache(Styling::TextStyle const& style);
		static void Shutdown();

		template<class T>
		static Styling::TextStyle random(T const& param)
		{
			std::hash<T> hasher;
			std::hash<size_t> sizeHasher;
			auto hashed = hasher(param);

			Styling::TextStyle result;
			result.font = Font::M3DFontManager::random(param);
			result.color = lgal::Color::HashColor(hashed);
			hashed = sizeHasher(hashed);
			result.haloColor = lgal::Color::HashColor(hashed);
			hashed = sizeHasher(hashed);
			result.dropshadowColor = lgal::Color::HashColor(hashed);
			result.kerningModifier = float(hashed & 0x1FFF) / 2048.f;

			return result;
		}
	};

}
