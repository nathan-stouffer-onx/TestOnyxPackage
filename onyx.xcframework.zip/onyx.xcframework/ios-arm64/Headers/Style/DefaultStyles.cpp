#include "DefaultStyles.h"

namespace onyx {
namespace Style {

	Styling::LineStyle randomLineStyle(Tiles::TileId const& tileId, float width, int offset)
	{
		Styling::LineStyle style;

		style.abgr = lgal::Color::HashColor(tileId, offset).abgr();
		style.width = width;
		style.dashArray = ((tileId.level & 1) == 0) ? Styling::DashArray{ { 1.0 } } : Styling::DashArray{ { 2.0, 2.0 } };

		return style;
	}

	Styling::FillStyle randomFillStyle(Tiles::TileId const& tileId, int offset)
	{
		Styling::FillStyle style;

		style.abgr = lgal::Color::HashColor(tileId, offset).abgr();
		
		// set pattern by zoom level
		switch (tileId.level % 4)
		{
		case 0:
			style.pattern = Styling::ResolvedImage("hatch");
			break;
		case 1:
			style.pattern = Styling::ResolvedImage("checker1");
			break;
		case 2:
			style.pattern = Styling::ResolvedImage("checker4");
			break;
		default:
			break;
		};

		return style;
	}

} }
