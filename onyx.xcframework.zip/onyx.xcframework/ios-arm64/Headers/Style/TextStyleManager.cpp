#include "TextStyleManager.h"

#include <unordered_map>
#include <mutex>

namespace onyx {
namespace Style {

	static std::unordered_map<Styling::TextStyle, std::shared_ptr<Styling::TextStyle>> sCachedFonts;

	static std::recursive_mutex sCacheGuard;

	void TextStyleManager::Shutdown()
	{
		sCachedFonts.clear();
	}

	std::shared_ptr<Styling::TextStyle> TextStyleManager::cache(Styling::TextStyle const& style)
	{
		std::lock_guard l(sCacheGuard);
	
		auto result = std::make_shared<Styling::TextStyle>(style);
		sCachedFonts.emplace(style, result);
	
		return result;
	}

	std::shared_ptr<Styling::TextStyle> TextStyleManager::find(Styling::TextStyle const& style)
	{
		auto found = sCachedFonts.find(style);
		if (found == sCachedFonts.end())
		{
			std::lock_guard l(sCacheGuard);
			found = sCachedFonts.find(style);
			if (found == sCachedFonts.end())
			{
				return cache(style);
			}
		}

		return found->second;
	}

} }