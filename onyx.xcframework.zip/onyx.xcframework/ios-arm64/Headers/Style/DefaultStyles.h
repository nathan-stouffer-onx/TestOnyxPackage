#if !defined(DEFAULT_STYLES_H)
#define DEFAULT_STYLES_H
#pragma once

#include <string>
#include <vector>

#include <Styling/Styles/LineStyle.h>
#include <Styling/Styles/FillStyle.h>

#include "Tiles/TileId.h"

namespace onyx {
namespace Style {

	Styling::LineStyle randomLineStyle(Tiles::TileId const& tileId, float width, int offset = 0);

	Styling::FillStyle randomFillStyle(Tiles::TileId const& tileId, int offset = 0);
	
} }

#endif