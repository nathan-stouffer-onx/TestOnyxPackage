#if !defined(_MARKUP_DB_H)
#define _MARKUP_DB_H

#if !defined(PLATFORM_EMSCRIPTEN)
#include <sqlite3.h>
#include <string>
#include <vector>

#include <System/OnyxException.h>
#include "Utils/property.h"
#include "DataObjects/DatabaseObjects/UserMarkup.h"

namespace onyx {
namespace Storage {

	ONYX_EXCEPTION_TYPE(UserMarkupDBException)

	class UserMarkupDB
	{

	public:
		typedef uint32_t Id_t;

		UserMarkupDB();
		UserMarkupDB(std::string const &fileName);

		~UserMarkupDB();

		std::string getErrorMessage();

		std::shared_ptr<std::vector<UserMarkup>> getMarkupGeoJson();
		Id_t getMarkup(std::string const &baseUrl);

		bool isOpen() { return mDb != nullptr; }

	private:
		sqlite3 *mDb = nullptr;
		std::string mDbFileName = "assets/markups.sqlite";

		void open();

	};


} }

#endif

#endif