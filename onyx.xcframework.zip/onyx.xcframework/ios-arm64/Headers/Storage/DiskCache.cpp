#if !defined(PLATFORM_EMSCRIPTEN)

#include "DiskCache.h"

#include <chrono>
#include <sstream>

#include <Logging/LogManager.h>
#include <System/FileSystem.h>
#include <lucid/Profiler.h>

#if !defined(NO_TILE_REQUESTER_THREADS)
#define LOCK(mtx) std::lock_guard lock##__LINE__(mtx);
#else
#define LOCK(mtx)
#endif

namespace onyx {
namespace Storage {

struct cacheEntries
{
	int size;
	DiskCache::Id_t id;
};

DiskCache::DiskCache(std::string const& fileName, size_t /*maxSize*/)
	: mDbFileName(fileName)
{
    bool exists = onyx::core::FileSystem::fileExists(mDbFileName);

	auto rc = sqlite3_open(mDbFileName.c_str(), &mDb);
	if (rc)
	{
		auto errMsg = getErrorMessage();
		logE("Can't open Disk Cache database: %s", errMsg.c_str());
	}
	else
	{
		logI("Opened cache database successfully");
	}

	if (!exists)
    {
        CreateDb();
    }

	prepareDefaultStatements();

	if (exists)
	{
		mStatus = getCacheStatus();
		
		auto dataSources = retrieveStatement<TileDataSource>(mGetDataSources);
		for (auto const& ds : (*dataSources))
		{
			auto const &url = ds->getBaseUrl();
			if (url != nullptr)
			{
				mDataSourceIds.emplace(*ds->getBaseUrl(), ds->getId());
			}
		}
	}
}

void DiskCache::prepareDefaultStatements()
{
	std::string selectCacheSQL = "SELECT SUM(length(Data)), count(Data), Persistent FROM TileData GROUP BY Persistent";
	mGetCacheStatus = prepareStatement(selectCacheSQL, &mGetCacheStatus);

	std::string selectCacheDSSQL = "SELECT SUM(LENGTH(td.Data)), count(td.Data), td.Persistent FROM TileData td INNER JOIN TileDataSource tds ON tds.Id = td.TileDataSourceId AND tds.BaseUrl = ? GROUP BY td.Persistent";
	mGetCacheDataSourceStatus = prepareStatement(selectCacheDSSQL, &mGetCacheDataSourceStatus);

	auto tileDataSelectSQL = TileData::GetSelectTableSql() + " WHERE level = ? AND x = ? AND y = ? AND TileDataSourceId = ?";

	mGetTileDataStmt = prepareStatement(tileDataSelectSQL, &mGetTileDataStmt);

	std::string tileDataUpdateSql ="UPDATE TileData SET Timestamp = ? WHERE level = ? AND x = ? AND y = ? AND TileDataSourceId = ?";
	mUpdateTileDataStmt = prepareStatement(tileDataUpdateSql, &mUpdateTileDataStmt);

	auto deleteTileDataSQL = TileData::GetDeleteSql() + " WHERE level = ? AND x = ? AND y = ? AND TileDataSourceId = ?";
	mDeleteTileDataStmt = prepareStatement(deleteTileDataSQL, &mDeleteTileDataStmt);

	mClearTileDataStmt = prepareStatement(TileData::GetDeleteSql(), &mClearTileDataStmt);

	std::string getTileDataTimestampSql = "SELECT Length(Data), Id FROM TileData WHERE Persistent = 0 OR Persistent IS NULL ORDER BY Timestamp ASC";
	mGetTileDataTimestamps = prepareStatement(getTileDataTimestampSql, &mGetTileDataTimestamps);

	std::string deleteTileIdSQL = "DELETE FROM TileData WHERE Id = ?";
	mDeleteTileId = prepareStatement(deleteTileIdSQL, &mDeleteTileId);

	std::string getDataSourcesSQL = "SELECT Id, BaseUrl, Prefix, FileType FROM TileDataSource";
	mGetDataSources = prepareStatement(getDataSourcesSQL, &mGetDataSources);

	std::string getSystemInfoSQL = "SELECT Id, Version, Notes FROM System";
	mGetSystemInfo = prepareStatement(getSystemInfoSQL, &mGetSystemInfo);
}

DiskCache::~DiskCache()
{
	if (mDb != nullptr)
	{

		for (auto const& stmt : mPreparedStatements)
		{
			sqlite3_finalize(stmt.second);
		}

		mPreparedStatements.clear();

		sqlite3_close(mDb);
	}
	mDb = nullptr;
}

std::string DiskCache::getErrorMessage() const
{
    std::string result;
    auto msg = sqlite3_errmsg(mDb);
    result = msg;
    return result;
}

std::string sCreateTables = R"(

--DROP TABLE TileData;

--DROP TABLE TileDataSource;

--DROP TABLE System

CREATE TABLE System (
	Id					INTEGER PRIMARY KEY AUTOINCREMENT,
    Version				INTEGER,
    Notes				VARCHAR(4096)
);

CREATE TABLE TileDataSource (
    Id					INTEGER PRIMARY KEY AUTOINCREMENT,
    BaseUrl				VARCHAR(2048) UNIQUE,
    Prefix				VARCHAR(32),
    FileType			VARCHAR(32)
);

CREATE TABLE TileData (
	Id					INTEGER PRIMARY KEY AUTOINCREMENT,
    TileDataSourceId    INT NOT NULL,
    Data				BLOB,
    Level				INT NOT NULL,
    X					INT NOT NULL,
    Y					INT NOT NULL,
    Timestamp			DATETIME NOT NULL,
	Persistent			BOOL,
	Version				INT
);

CREATE UNIQUE INDEX TileData_TileId ON TileData(Level, X, Y, TileDataSourceId);
CREATE INDEX TileData_Timestamp ON TileData(Timestamp);

)";

DiskCache::Id_t DiskCache::getDataSourceId(std::string const& baseUrl)
{
	LOCK(mLockMutex);
	auto found = mDataSourceIds.find(baseUrl);
	if (found == mDataSourceIds.end())
	{
		return DBObject::cEmptyId;
	}

	return found->second;
}

void DiskCache::addDataSource(std::string const& baseUrl)
{
	if (getDataSourceId(baseUrl) != DBObject::cEmptyId)
	{
		return;
	}

	TileDataSource tds;
	tds.setBaseUrl(baseUrl);
	insert(tds);
}

void DiskCache::CreateDb()
{
	AssertIsOpen();

	SQLITE_VALIDATE(sqlite3_exec(mDb, sCreateTables.c_str(), nullptr, 0, nullptr), "Error creating database");

	System currentInfo;
	currentInfo.setVersion(cCurrentVersion);
	currentInfo.setNotes("Created By onyx::Storage::DiskCache");

	insert(currentInfo);
}

void loadRow(sqlite3_stmt* stmt, std::shared_ptr<TileData> &result)
{
	result->setId(sqlite3_column_int(stmt, 1));
	DBObject::DBBlob blob;
	auto size = sqlite3_column_bytes(stmt, 2);
	blob.resize(size);
	memcpy(blob.data(), sqlite3_column_blob(stmt, 2), size);
	result->setData(std::move(blob));
	result->setTimestamp(sqlite3_column_double(stmt, 6));
	result->setTileId({ sqlite3_column_int(stmt, 3),
						sqlite3_column_int(stmt, 4),
						sqlite3_column_int(stmt, 5) });
}

struct cacheStatsInternal
{
	int size, count;
	bool persistent;
};

void loadRow(sqlite3_stmt* stmt, std::shared_ptr<cacheStatsInternal> &result)
{
	result->size = sqlite3_column_int(stmt, 0);
	result->count = sqlite3_column_int(stmt, 1);
	result->persistent = sqlite3_column_int(stmt, 2) != 0;
}

void loadRow(sqlite3_stmt* stmt, std::shared_ptr<cacheEntries> &result)
{
	result->size = sqlite3_column_int(stmt, 0);
	result->id = sqlite3_column_int(stmt, 1);
}

void loadRow(sqlite3_stmt* stmt, std::shared_ptr<System> &result)
{
	result->setId(sqlite3_column_int(stmt, 0));
	result->setVersion(sqlite3_column_int(stmt, 0));
}

void loadRow(sqlite3_stmt* stmt, std::shared_ptr<TileDataSource> &result)
{
	result->setId(sqlite3_column_int(stmt, 0));
	result->setBaseUrl((char*) sqlite3_column_text(stmt, 1));
}

template<typename T>
void DiskCache::bindValue(int , T const& , sqlite3_stmt* ) const
{
	ONYX_THROW("Unrecognized type for bindValue()");
}

template<>
void DiskCache::bindValue(int column, bool const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_int(stmt, column, int(value)), "Error binding boolean value");
}

template<>
void DiskCache::bindValue(int column, int const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_int(stmt, column, value), "Error binding int value");
}

template<>
void DiskCache::bindValue(int column, uint32_t const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_int(stmt, column, int(value)), "Error binding uint32_t value");
}

template<>
void DiskCache::bindValue(int column, std::string const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_text(stmt, column, value.c_str(), int(value.size()), SQLITE_STATIC), "Error binding string value");
}

template<>
void DiskCache::bindValue(int column, std::shared_ptr<DBObject::DBString> const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_text(stmt, column, value->c_str(), int(value->size()), SQLITE_STATIC), "Error binding shared DBString value");
}

template<>
void DiskCache::bindValue(int column, double const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_double(stmt, column, value), "Error binding double value");
}

template<>
void DiskCache::bindValue(int column, std::shared_ptr<DBObject::DBBlob> const& value, sqlite3_stmt* stmt) const
{
	SQLITE_VALIDATE(sqlite3_bind_blob(stmt, column, value->data(), int(value->size()), SQLITE_STATIC), "Error binding DBBlob value");
}

template <typename T>
void DiskCache::bind(T const&, sqlite3_stmt*) const
{
	ONYX_THROW("Unrecognized type for bind()");
}

template <>
void DiskCache::bind(System const& row, sqlite3_stmt* stmt) const
{
	bindValue(1, row.getVersion(), stmt);
	bindValue(2, row.getNotes(), stmt);
}

template <>
void DiskCache::bind(TileDataSource const& row, sqlite3_stmt* stmt) const
{
	bindValue(1, row.getBaseUrl(), stmt);
}

template <>
void DiskCache::bind(TileData const& row, sqlite3_stmt* stmt) const
{
	bindValue(1, row.getDataSourceId(), stmt);
	bindValue(2, row.getData(), stmt);
	auto tileId = row.getTileId();
	bindValue(3, tileId.level, stmt);
	bindValue(4, tileId.x, stmt);
	bindValue(5, tileId.y, stmt);
	bindValue(6, row.getTimestamp(), stmt);
	bindValue(7, row.getPersistent(), stmt);
	bindValue(8, row.getVersion(), stmt);
}

void DiskCache::executeStatement(sqlite3_stmt* statement) const
{
	LOCK(mLockMutex);

	ONYX_FINALLY([&]
		{
			sqlite3_reset(statement);
		});

	SQLITE_VALIDATE(sqlite3_step(statement), "Error executing prepared statement");
}

bool DiskCache::getRow(sqlite3_stmt* statement) const
{
	auto code = sqlite3_step(statement);

	if (code == SQLITE_ROW)
	{
		return true;
	}
	if (code == SQLITE_DONE)
	{
		return false;
	}

	SQLITE_THROW(code, "Error retrieving row");
}

template <typename T>
std::shared_ptr<std::vector<std::shared_ptr<T>>> DiskCache::retrieveStatement(sqlite3_stmt* statement) const
{
	LOCK(mLockMutex);

	ONYX_FINALLY([&]
		{
			sqlite3_reset(statement);
		});

	auto result = std::make_shared<std::vector<std::shared_ptr<T>>>();

	while (getRow(statement))
	{
		result->push_back(std::make_shared<T>());
		loadRow(statement, result->back());
	}

	return result;
}

sqlite3_stmt* DiskCache::prepareStatement(std::string const& sql, void* tag) const
{
	sqlite3_stmt* result;

	LOCK(mLockMutex);
	auto find = mPreparedStatements.find(tag);
	if (find == mPreparedStatements.end())
	{
		SQLITE_VALIDATE(sqlite3_prepare_v2(mDb, sql.c_str(), -1, &result, nullptr), "Error preparing statement");

		mPreparedStatements.emplace(tag, result);
	}
	else
	{
		result = find->second;
	}

	return result;
}

template <typename T>
void DiskCache::insertInternal(T & row) const
{
	LOCK(mLockMutex);

	static int typeId = 0;
	sqlite3_stmt* stmt = nullptr;

	auto find = mPreparedStatements.find(&typeId);
	if (find == mPreparedStatements.end())
	{
		stmt = prepareStatement(T::GetInsertSql().c_str(), &typeId);
	}
	else
	{
		stmt = find->second;
	}

	bind(row, stmt);

	executeStatement(stmt);

	row.setId(DBObject::DBId_t(sqlite3_last_insert_rowid(mDb)));
}

void DiskCache::insert(System & row)
{
	insertInternal(row);
}

void DiskCache::insert(TileDataSource & row)
{
	LOCK(mLockMutex);

	ONYX_ASSERT(row.getBaseUrl() != nullptr && row.getBaseUrl()->length() != 0, "null or empty BaseUrl is not allowed");
	insertInternal(row);
	mDataSourceIds.emplace(*row.getBaseUrl(), row.getId());
}

void DiskCache::insert(TileData & row)
{
	if (row.getData() == nullptr)
	{
		return;
	}

	insertInternal(row);
	++mStatus.entryCount;
	mStatus.cachedSize += row.getData()->size();
}

System DiskCache::getSystemInfo()
{
	auto table = retrieveStatement<System>(mGetSystemInfo);
	ONYX_ASSERT(!table->empty(), "No entry in System table");
	return *(table->back());
}

DiskCache::Status DiskCache::getCacheStatus() const
{
	auto rows = retrieveStatement<cacheStatsInternal>(mGetCacheStatus);
	
	DiskCache::Status result = { 0, 0, 0, 0 };

	if (!rows->empty())
	{
		for (auto const& row : *rows)
		{
			if (row->persistent)
			{
				result.persistentEntryCount = row->count;
				result.persistentSize = row->size;
			}
			result.entryCount += row->count;
			result.cachedSize += row->size;
		}
	}

	return result;
}

DiskCache::Status DiskCache::getCacheStatus(std::string const& baseUrl)
{
	LOCK(mLockMutex);

	bindValue(1, baseUrl, mGetCacheDataSourceStatus);

	auto rows = retrieveStatement<cacheStatsInternal>(mGetCacheStatus);

	DiskCache::Status result = { 0, 0, 0, 0 };

	if (!rows->empty())
	{
		for (auto const& row : *rows)
		{
			if (row->persistent)
			{
				result.persistentEntryCount = row->count;
				result.persistentSize = row->size;
			}
			result.entryCount += row->count;
			result.cachedSize += row->size;
		}
	}

	return result;
}

double nowSeconds()
{
	auto now = std::chrono::system_clock::now();

	std::chrono::duration<double> seconds = now.time_since_epoch();

	return seconds.count();
}

std::shared_ptr<TileData> DiskCache::getTileData(std::string const &baseUrl, Tiles::TileId tileId) const
{
	AssertIsOpen();

	auto found = mDataSourceIds.find(baseUrl);

	ONYX_ASSERT(found != mDataSourceIds.end(), Messages::UnknownBaseUrl);

	LOCK(mLockMutex);

	auto timestamp = nowSeconds();

	bindValue(1, timestamp, mUpdateTileDataStmt);
	bindValue(2, tileId.level, mUpdateTileDataStmt);
	bindValue(3, tileId.x, mUpdateTileDataStmt);
	bindValue(4, tileId.y, mUpdateTileDataStmt);
	bindValue(5, found->second, mUpdateTileDataStmt);

	executeStatement(mUpdateTileDataStmt);

	bindValue(1, tileId.level, mGetTileDataStmt);
	bindValue(2, tileId.x, mGetTileDataStmt);
	bindValue(3, tileId.y, mGetTileDataStmt);
	bindValue(4, found->second, mGetTileDataStmt);

	auto rows = retrieveStatement<TileData>(mGetTileDataStmt);

	if (rows->empty())
	{
		return nullptr;
	}

	ONYX_ASSERT(rows->size() == 1, "getTileData returned more than one row");
	
	return rows->front();
}

void DiskCache::addTileData(std::string const& baseUrl, Tiles::TileId tileId, DBObject::DBBlob const& data, bool persistent, int version)
{
	AssertIsOpen();

	trim();

	auto found = mDataSourceIds.find(baseUrl);

	ONYX_ASSERT(found != mDataSourceIds.end(), Messages::UnknownBaseUrl);

	LOCK(mLockMutex);

	bindValue(1, tileId.level, mDeleteTileDataStmt);
	bindValue(2, tileId.x, mDeleteTileDataStmt);
	bindValue(3, tileId.y, mDeleteTileDataStmt);
	bindValue(4, found->second, mDeleteTileDataStmt);

	executeStatement(mDeleteTileDataStmt);

	TileData td;

	td.setData(data);
	td.setDataSourceId(found->second);
	td.setTileId(tileId);
	td.setTimestamp(nowSeconds());
	td.setPersistent(persistent);
	td.setVersion(version);
	insert(td);
}

void DiskCache::trim()
{
	LUCID_PROFILE_SCOPE("Disk Cache Trim");

	if (mStatus.cachedSize - mStatus.persistentSize < mMaxLRUSize)
	{
		return; // Nothing to do
	}
	
	LOCK(mLockMutex);

	// Refresh our status just to ensure that we're up-to-date
	mStatus = getCacheStatus();

	if (mStatus.cachedSize - mStatus.persistentSize < mMaxLRUSize)
	{
		return;
	}

	auto entries = retrieveStatement<cacheEntries>(mGetTileDataTimestamps);

	auto lruSize = mStatus.cachedSize - mStatus.persistentSize;

	auto threshold = (mMaxLRUSize * 9) / 10; // Cut down to 90% of max size

	int purgeCount = 0;
	size_t purgeAmount = 0;
	for (auto const &entry : *entries)
	{
		LUCID_PROFILE_SCOPE("Disk Cache Purge Entry");

		bindValue(1, entry->id, mDeleteTileId);
		executeStatement(mDeleteTileId);

		++purgeCount;

		lruSize -= entry->size;
		purgeAmount += entry->size;

		if (lruSize < threshold)
		{
			break;
		}
	}

	logD("Purged %d disk cache entries (%f MB)", purgeCount, (float) purgeAmount / (1024.f * 1024.f));

	mStatus = getCacheStatus();
}

void DiskCache::clear()
{
	executeStatement(mClearTileDataStmt);
}

} }

#endif