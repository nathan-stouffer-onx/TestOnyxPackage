#if !defined(PLATFORM_EMSCRIPTEN)

#include "MarkupDB.h"

#include <sstream>

#include <Logging/LogManager.h>

#define SQLITE_VALIDATE(x) { ONYX_CUSTOM_ASSERT(x == SQLITE_OK, onyx::Storage::DiskCacheException, std::string("SQL Error: ") + getErrorMessage()); }

namespace onyx {
namespace Storage {

UserMarkupDB::UserMarkupDB(std::string const& fileName)
	: mDbFileName(fileName)
{
	open();
}


UserMarkupDB::UserMarkupDB()
{
	open();
}

void UserMarkupDB::open()
{
    auto rc = sqlite3_open(mDbFileName.c_str(), &mDb);
    if (rc)
    {
        auto errMsg = getErrorMessage();
        logE("Can't open User Markup database: %s", errMsg.c_str());
    }
    else
    {
        logI("Opened markup database successfully");
    }
}

UserMarkupDB::~UserMarkupDB()
{
    sqlite3_close(mDb);
}

std::string UserMarkupDB::getErrorMessage()
{
    std::string result;
    auto msg = sqlite3_errmsg(mDb);
    result = msg;
    return result;
}

static int MarkupRowCallback(void *data, int argc, char **argv, char **azColName)
{
    auto *result = (std::vector<UserMarkup>*)data;

    result->push_back(UserMarkup(argc, argv, azColName));
    return 0;
}

std::shared_ptr<std::vector<UserMarkup>> UserMarkupDB::getMarkupGeoJson()
{
    std::shared_ptr<std::vector<UserMarkup>> result = std::make_shared<std::vector<UserMarkup>>();

    char* zErrMsg;
    
    auto resultPtr = result.get();

    /* Create SQL statement */
    auto sql = std::string("SELECT * from Markups");
    
    /* Execute SQL statement */
    auto rc = sqlite3_exec(mDb, sql.c_str(), MarkupRowCallback, resultPtr, &zErrMsg);

    ONYX_ASSERT(rc == SQLITE_OK, "Failed to retrieve user markups from SQLite database");

    auto msg = getErrorMessage();

    return result;
}

} }

#endif