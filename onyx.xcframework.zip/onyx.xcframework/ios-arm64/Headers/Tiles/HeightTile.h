#ifndef __HEIGHT_TILE_H__
#define __HEIGHT_TILE_H__

#include <map>
#include <memory>
#include <vector>

#include <lucid/gal/Types.h>

#include <Styling/Styles/ContourConfigs.h>

#include "Tiles/TileId.h"

namespace onyx {
namespace Tiles {

	struct HeightTile
	{	
	public:

		using HeightsT = std::vector<height_float_t>;

		static constexpr size_t cPadding = 2;

	public:

		HeightTile(Tiles::TileId const& tileId, size_t paddedLength, size_t padding, std::vector<HeightsT> const& heights, time_float_t timestampMS);
		HeightTile(Tiles::TileId const& tileId, size_t paddedLength, size_t padding, HeightsT const& heights, time_float_t timestampMS);
		~HeightTile();

		height_float_t heightAt(lgal::world::Vector2 const& pos, bool mercatorDistortion = true, bool interpolate = true) const;
		lgal::world::Vector3 normalAt(lgal::world::Vector2 const& pos, bool interpolate = true) const;
		
		inline Tiles::TileId getKey() const { return mTileId; }
		inline Tiles::TileId id() const { return mTileId; }
	
		inline size_t byteSize() const { return sizeof(height_float_t) * mHeightData.size(); }
		inline size_t getLength() const { return mLength; }

		// NOTE: distortion is applied by the latitude at the middle of the tile when fetching tile summary statistics
		height_float_t getMaxHeight(bool mercatorDistortion = true) const;
		height_float_t getMinHeight(bool mercatorDistortion = true) const;
		height_float_t getAverageHeight(bool mercatorDistortion = true) const;
		inline time_float_t timestampMS() const { return mTimestampMS; }

		inline std::vector<height_float_t> const& getHeightData() const { return mHeightData; }

	public:

		struct ContourLabel
		{
			std::string elevation;
			lgal::world::Vector2 pos;
			lgal::gpu::Vector2 direction;
		};

		std::vector<ContourLabel> labels(Styling::ContourLabelConfig const& config) const;

	public:

		static HeightsT Flatten(std::vector<HeightsT> const& heights);

		/*
		* A function to fit the height buffer passed in to the structure required by HeightTile.The parameters paddedLength
		* and padding refer to the dimensions of the passed in heights. The returned buffer will always have padding of size
		* 2.
		*/
		static HeightsT Fit(size_t inputPaddedLength, size_t inputPadding, HeightsT const& heights);
		static void FitRow(HeightsT& dst, size_t inputPadding, HeightsT::const_iterator begin, HeightsT::const_iterator end);
	
	private:

		static size_t NearestIndex(tile_float_t relative, size_t length);
		static size_t PrecedingIndex(tile_float_t relative, size_t length);

		static tile_float_t ToTileCoord(size_t index, size_t length);
		static lgal::tile::Vector2 ToTileCoord(size_t i, size_t j, size_t length);

	private:

		Tiles::TileId const mTileId;

		time_float_t const mTimestampMS;

		size_t const mLength;
		size_t const mPaddedLength;

		float const mPixelWidth;
		float const mHalfPixelWidth;
		
		HeightsT mHeightData;
	
		height_float_t mMaxHeight;
		height_float_t mMinHeight;
		height_float_t mAvgHeight;

		height_float_t mMaxDistortedHeight;
		height_float_t mMinDistortedHeight;
		height_float_t mAvgDistortedHeight;

		size_t mArgMinPixel, mArgMaxPixel;
		lgal::tile::Vector2 mContourDirection;
	
		height_float_t read(size_t i, size_t j) const;
		inline height_float_t read(lgal::screen::Vector2 const& pos) const { return read(size_t(pos.x), size_t(pos.y)); }

		void precomputeStats();

		height_float_t elevationAt(lgal::world::Vector2 const& pos, bool interpolate) const;

	};

} }

#endif