#include "HeightTile.h"

#include <cmath>

#include <lucid/math/Algorithm.h>

#include <System/OnyxException.h>

#include "Utils/MapMath.h"
#include "Tiles/TileId.h"

namespace onyx::Tiles
{

	HeightTile::HeightTile(TileId const& tileId, size_t paddedLength, size_t padding, std::vector<HeightsT> const& heights, time_float_t timestampMS) :
		HeightTile(tileId, paddedLength, padding, HeightTile::Flatten(heights), timestampMS)
	{}

	HeightTile::HeightTile(TileId const &tileId, size_t paddedLength, size_t padding, HeightsT const& heights, time_float_t timestampMS) :
		  mTileId(tileId)
		, mTimestampMS(timestampMS)
		, mLength(paddedLength - padding - padding)
		, mPaddedLength(mLength + cPadding + cPadding)
		, mPixelWidth(1.0f / mLength)
		, mHalfPixelWidth(0.5f * mPixelWidth)
		, mHeightData(HeightTile::Fit(paddedLength, padding, heights))
		, mMaxHeight(MapMath::cMaxElevation)
		, mMinHeight(MapMath::cMinElevation)
		, mAvgHeight(0)
		, mArgMinPixel(0)
		, mArgMaxPixel(0)
	{
		ONYX_ASSERT(mHeightData.size() == mPaddedLength * mPaddedLength, "Invalid number of height values");
		// precompute tile statistics
		precomputeStats();
	}

	HeightTile::~HeightTile()
	{
		mHeightData.clear();
	}

	float HeightTile::getMaxHeight(bool mercatorDistortion) const
	{
		return (mercatorDistortion) ? mMaxDistortedHeight : mMaxHeight;
	}

	float HeightTile::getMinHeight(bool mercatorDistortion) const
	{
		return (mercatorDistortion) ? mMinDistortedHeight : mMinHeight;
	}

	float HeightTile::getAverageHeight(bool mercatorDistortion) const
	{
		return (mercatorDistortion) ? mAvgDistortedHeight : mAvgHeight;
	}

	float HeightTile::heightAt(lgal::world::Vector2 const& pos, bool mercatorDistortion, bool interpolate) const
	{
		float height = elevationAt(pos, interpolate);
		auto distortion = (mercatorDistortion) ? MapMath::mercatorDistortion(pos) : 1.0;
		return float(distortion) * height;
	}

	float HeightTile::elevationAt(lgal::world::Vector2 const& pos, bool interpolate) const
	{
		ONYX_DEBUG_ASSERT(mHeightData.size() > 0, "must have height data");

		tile_float_t eps = 0.0000001;

		// compute uv coords and clamp to inside padding
		lgal::tile::Vector2 uv = mTileId.toUVCoords<tile_float_t>(pos, TileId::Origin::TOP_LEFT); // v = 0 is the top row
		tile_float_t padding = cPadding * mPixelWidth - mHalfPixelWidth - eps;
		uv = lmath::clamp(uv, -padding, 1.f + padding);

		if (interpolate)
		{
			/*
			* bilinearly interpolate between the following four points
			* 
			*  (0, 0)     s     (1, 0)
			*        a ------- b
			*        |         |
			*      t |         | 
			*        |         |
			*        c ------- d
			*  (0, 1)           (1, 1)
			*/

			// compute index of the center of the preceding pixel
			size_t i = HeightTile::PrecedingIndex(uv.x, mLength);
			size_t j = HeightTile::PrecedingIndex(uv.y, mLength);

			// compute tile coordinates of the center of the preceding
			tile_float_t x = HeightTile::ToTileCoord(i, mLength);
			tile_float_t y = HeightTile::ToTileCoord(j, mLength);

			tile_float_t s = (uv.x - x) / mPixelWidth;			// compute s for interpolation
			tile_float_t t = (uv.y - y) / mPixelWidth;			// compute t for interpolation

			// height values that we will interpolate between
			height_float_t a = read(i, j);
			height_float_t b = read(i + 1, j);
			height_float_t c = read(i, j + 1);
			height_float_t d = read(i + 1, j + 1);

			height_float_t top = lmath::lerp(a, b, s);
			height_float_t bot = lmath::lerp(c, d, s);
			return lmath::lerp(top, bot, t);
		}
		else
		{
			size_t nearestI = HeightTile::NearestIndex(uv.x, mLength);
			size_t nearestJ = HeightTile::NearestIndex(uv.y, mLength);
			return read(nearestI, nearestJ);
		}
	}

	lgal::world::Vector3 HeightTile::normalAt(lgal::world::Vector2 const& pos, bool interpolate) const
	{
		// compute the pixel size and the step we take in the world when computing the normal
		world_float_t worldStep = 0.5 * mTileId.extent() / static_cast<world_float_t>(mLength);

		lgal::world::Vector2 deltaX = { worldStep, 0 };
		lgal::world::Vector2 deltaY = { 0, worldStep };

		height_float_t westZ = heightAt(pos - deltaX, true, interpolate);
		height_float_t eastZ = heightAt(pos + deltaX, true, interpolate);
		height_float_t northZ = heightAt(pos - deltaY, true, interpolate);
		height_float_t southZ = heightAt(pos + deltaY, true, interpolate);

		return lmath::normalize(lgal::world::Vector3(westZ - eastZ, northZ - southZ, 2.0 * worldStep));
	}

	height_float_t HeightTile::read(size_t i, size_t j) const
	{
		return mHeightData.at(mPaddedLength * j + i);
	}

	void HeightTile::precomputeStats()
	{
		// TODO possibly only look at values actually in the height tile (avoid the padding)
		double total = 0;

		// compute max/min height values in the tile
		mMinHeight = mHeightData[0];
		mMaxHeight = mHeightData[0];
		float* heightPtr = mHeightData.data();
		for (size_t i = 0; i < mHeightData.size(); i++)
		{
			float height = *heightPtr;		// dereference the height value
			total += height;

			if (height < mMinHeight)
			{
				mMinHeight = height;
				mArgMinPixel = uint32_t(i);
			}
			else if (height > mMaxHeight)
			{
				mMaxHeight = height;
				mArgMaxPixel = uint32_t(i);
			}
			heightPtr++;			// increment pointer to the height data
		}
		mAvgHeight = std::float_t(total / std::double_t(mHeightData.size()));

		float distortion = (float)MapMath::mercatorDistortion(mTileId.center());
		mMinDistortedHeight = distortion * mMinHeight;
		mMaxDistortedHeight = distortion * mMaxHeight;
		mAvgDistortedHeight = distortion * mAvgHeight;

		lgal::tile::Vector2 minPos = HeightTile::ToTileCoord(mArgMinPixel / mPaddedLength, mArgMinPixel % mPaddedLength, mLength);
		lgal::tile::Vector2 maxPos = HeightTile::ToTileCoord(mArgMaxPixel / mPaddedLength, mArgMaxPixel % mPaddedLength, mLength);
		auto dir = lmath::normalize((maxPos - minPos));
		mContourDirection = { dir.y, -dir.x };
	}

	std::vector<HeightTile::ContourLabel> HeightTile::labels(Styling::ContourLabelConfig const& config) const
	{
		std::vector<HeightTile::ContourLabel> labels;

		lgal::screen::Vector2 argMin(int(mArgMinPixel) % int(mPaddedLength), int(mArgMinPixel) / int(mPaddedLength));
		lgal::screen::Vector2 argMax(int(mArgMaxPixel) % int(mPaddedLength), int(mArgMaxPixel) / int(mPaddedLength));

		//	plotLine(x0, y0, x1, y1)
		//		dx = abs(x1 - x0)
		//		sx = x0 < x1 ? 1 : -1
		//		dy = -abs(y1 - y0)
		//		sy = y0 < y1 ? 1 : -1
		//		error = dx + dy

		// set up for adapted Bresenham's line drawing algorithm
		auto p0 = argMin;
		auto p1 = argMax;
		lgal::screen::Vector2 diff(std::abs(argMax.x - argMin.x), -std::abs(argMax.y - argMin.y));
		auto sx = argMin.x < argMax.x ? 1 : -1;
		auto sy = argMin.y < argMax.y ? 1 : -1;
		auto error = diff.x + diff.y;

		struct Iteration
		{
			lgal::screen::Vector2 p = { 0, 0 };
			height_float_t height = 0.f;
		};

		// Adapted Bresenham's line drawning algorithm
		//	while true
		//		plot(x0, y0)
		//		if x0 == x1 && y0 == y1 break
		//		e2 = 2 * error
		//		if e2 >= dy
		//			if x0 == x1 break
		//			error = error + dy
		//			x0 = x0 + sx
		//		end if
		//		if e2 <= dx
		//			if y0 == y1 break
		//			error = error + dx
		//			y0 = y0 + sy
		//		end if
		//	end while

		float conversion = Styling::ContourConfig::fromKm(config.contours.units);
		Iteration prev;
		Iteration curr = { p0, read(p0) * conversion };
		while (p0.x != p1.x || p0.y != p1.y)
		{
			prev = curr;

			// upcate p0 calculation
			{
				auto e2 = 2 * error;
				if (e2 >= diff.y)
				{
					if (p0.x == p1.x) { break; }
					error += diff.y;
					p0.x += sx;
				}
				if (e2 <= diff.x)
				{
					if (p0.y == p1.y) { break; }
					error += diff.x;
					p0.y += sy;
				}
			}

			curr = { p0, read(p0) * conversion };

			// straddling points in tile coordinates
			lgal::tile::Vector2 uv = prev.p.as<tile_float_t>() * (1.f / mLength);
			lgal::tile::Vector2 st = curr.p.as<tile_float_t>() * (1.f / mLength);
			
			for (int contour : config.contours.straddled(prev.height, curr.height))
			{
				tile_float_t t = static_cast<tile_float_t>(lmath::inverseLerp(prev.height, curr.height, height_float_t(contour)));
				lgal::tile::Vector2 interpolated = lmath::lerp(uv, st, t);

				lgal::world::Vector2 pos = mTileId.toWorldPos(interpolated, TileId::Origin::TOP_LEFT);
				std::string elevation = std::to_string(static_cast<int>(std::round(contour)));
			
				labels.push_back(ContourLabel{ elevation, pos, mContourDirection });
			}
		}

		ONYX_DEBUG_ASSERT(p0 == p1, "did not complete at p1");

		return labels;
	}

	size_t HeightTile::NearestIndex(tile_float_t relative, size_t length)
	{
		tile_float_t index = std::round(relative * static_cast<tile_float_t>(length));
		index += static_cast<tile_float_t>(HeightTile::cPadding);
		return static_cast<size_t>(index);
	}

	size_t HeightTile::PrecedingIndex(tile_float_t relative, size_t length)
	{
		tile_float_t index = std::floor(relative * static_cast<tile_float_t>(length) - 0.5f);
		index += static_cast<tile_float_t>(HeightTile::cPadding);
		return static_cast<size_t>(index);
	}

	tile_float_t HeightTile::ToTileCoord(size_t index, size_t length)
	{
		tile_float_t offset = static_cast<tile_float_t>(index) - static_cast<tile_float_t>(HeightTile::cPadding) + 0.5f;
		return offset / static_cast<tile_float_t>(length);
	}

	lgal::tile::Vector2 HeightTile::ToTileCoord(size_t i, size_t j, size_t length)
	{
		return { ToTileCoord(i, length), ToTileCoord(j, length) };
	}

	HeightTile::HeightsT HeightTile::Flatten(std::vector<HeightsT> const& heights)
	{
		size_t dim = heights.size();
		
		HeightsT flattened;
		flattened.reserve(dim * dim);

		for (HeightsT const& row : heights)
		{
			ONYX_ASSERT(row.size() == dim, "row size must equal dimension");
			flattened.insert(flattened.end(), row.begin(), row.end());
		}

		return flattened;
	}

	HeightTile::HeightsT HeightTile::Fit(size_t inputPaddedLength, size_t inputPadding, HeightsT const& heights)
	{
		// compute metadata
		size_t length = inputPaddedLength - inputPadding;
		size_t paddedLength = length + HeightTile::cPadding + HeightTile::cPadding;
		size_t size = paddedLength * paddedLength;

		// initialize returned buffer
		HeightsT fit;
		fit.reserve(size);

		// populate padding at top of the tile
		for (size_t i = 0; i < HeightTile::cPadding - inputPadding; ++i)
		{
			HeightTile::FitRow(fit, inputPadding, heights.begin(), heights.begin() + inputPaddedLength);
		}

		// populate tile
		for (size_t row = 0; row < inputPaddedLength; ++row)
		{
			auto begin = heights.begin() + row * inputPaddedLength;
			auto end = begin + inputPaddedLength;
			HeightTile::FitRow(fit, inputPadding, begin, end);
		}

		// populate padding at bottom of the tile
		auto lastRowBegin = heights.end() - inputPaddedLength;
		for (size_t i = 0; i < HeightTile::cPadding - inputPadding; ++i)
		{
			HeightTile::FitRow(fit, inputPadding, lastRowBegin, heights.end());
		}

		return fit;
	}

	void HeightTile::FitRow(HeightsT& dst, size_t inputPadding, HeightsT::const_iterator begin, HeightsT::const_iterator end)
	{
		// add padding on the left
		for (size_t i = 0; i < HeightTile::cPadding - inputPadding; ++i)
		{
			dst.push_back(*begin);
		}

		// insert the range
		dst.insert(dst.end(), begin, end);

		// add padding on the right
		height_float_t last = *(end - 1);
		for (size_t i = 0; i < HeightTile::cPadding - inputPadding; ++i)
		{
			dst.push_back(last);
		}
	}

}