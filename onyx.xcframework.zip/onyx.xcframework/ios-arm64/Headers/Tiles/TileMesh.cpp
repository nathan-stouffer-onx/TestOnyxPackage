#include "TileMesh.h"

#include <array>
#include <cmath>

#include "Utils/MapMath.h"

namespace onyx {
namespace Tiles {

	// triangle count
	// res			face		face join	skirt	skirt join
	// ---------	----		---------	-----	----------
	// 1x1			2			0			8		2
	// 2x2			8			2			16		2
	// 3x3			18			4			24		2
	// 4x4			32			6			32		2
	// =======================================================
	// nxn			(n^2)*2		(n-1)*2		(n*8)	2

	// index count
	// res			face		join		skirt
	// ---------	----		----		-----
	// 1x1			4			0			4
	// 2x2			12			2			8
	// 3x3			24			4			12
	// 4x4			40			6			16
	// =======================================================
	// nxn			n*(n+1)^2	(n-1)*2		n*4


	inline static uint32_t computeVertCount(TileMesh::MeshResolution_t resolution)
	{
		auto res = uint32_t(resolution);
		auto count = (res + 1) * (res + 1);			// face vertices
		count += resolution * 4;					// skirt vertices
		return count;
	}
	inline static uint32_t computeIndexCount(TileMesh::MeshResolution_t resolution)
	{
		auto res = uint32_t(resolution);
		auto count = 2 + 2 * resolution + 2;		// indices in a row (or column) -- includes join verts
		count *= resolution;						// multiply by the number of rows (or columns)
		count += 4 * (2 * res);						// skirt indices
		count += 2;									// skirt join indices
		return count;
	}

	// index of each vertex (where n is the mesh resolution):
	// 
	//     SW                                                   \                                  SE
	//        n*n+1 --------- n*n+2 --------- n*n+3 ----------- \ --------- (n-1)*n+n+1 ----- n*n+n+1
	//          |               |               |               \                |               |
	//          |               |               |               \                |               | 
	//          |    (0,n-1)    |    (1,n-1)    |    (2,n-1)    \   (n-2,n-1)    |   (n-1,n-1)   | 
	//          |               |               |               \                |               | 
	//          |               |               |               \                |               |
	//      (n-1)*n+1 ----- (n-1)*n+2 ----- (n-1)*n+3 --------- \ --------- (n-1)*n+n+1 ----- 3*n+n+1
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//          |    (0,n-2)    |    (1,n-2)    |    (2,n-2)    \   (n-2,n-2)    |   (n-1,n-2)   |
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//      =================================================== \ ============== | ===================
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//    j     |     (0,2)     |     (1,2)     |     (2,2)     \    (n-2,2)     |    (n-1,2)    |
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//        2*n+1 --------- 2*n+2 --------- 2*n+3 ----------- \ ------------ 2*n+n -------- 2*n+n+1
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//          |     (0,1)     |     (1,1)     |     (2,1)     \    (n-2,1)     |    (n-1,1)    |
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//         n+1 ----------- n+2 ----------- n+3 ------------ \  ------------ n+n ---------- n+n+1
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//          |     (0,0)     |     (1,0)     |     (2,0)     \    (n-2,0)     |    (n-1,0)    |
	//          |               |               |               \                |               |
	//          |               |               |               \                |               |
	//          0 ------------- 1 ------------- 2 ------------- \ ------------- n-1 ------------ n
	//       NW                                         i       \                                  NE
	// 
	// NOTE: index 0 is actually the northwest corner since this mesh gets flipped when we interpolate between 
	//       the min/max of the tile
	// 
	// NOTE: regardless of which way the index buffer traverses the tile, the actual triangles that it
	//       forms must be the same. split quads from the SW to NE corner
	// 
	// NOTE: given a pixel with indices i and j, the vertices at the edge of the pixel will be:
	// 
	//                   SW                          SE 
	//                 (j+1)*(n+1)+i ------ (j+1)*(n+1)+i+1
	//                       |                     | 
	//                       |                     |
	//                       |                     |
	//                       |        (i,j)        |
	//                       |                     |
	//                       |                     |
	//                       |                     |
	//                   j*(n+1)+i ---------- j*(n+1)+i+1
	//                    NW                          NE

	// struct to help organize code for generating a mesh
	struct MeshCell
	{
		// a type for indexing into the cells of the above mesh grid
		// we use integers so that a negative value can signal that the cell index is invalid
		typedef int GridIndex_t;

		TileMesh::MeshResolution_t res;
		GridIndex_t i;
		GridIndex_t j;

		inline bool valid()
		{
			bool validI = (0 <= i && i < res);
			bool validJ = (0 <= j && j < res);
			return validI && validJ;
		}

		// static methods to construct a mesh cell at the specified corner of the mesh
		inline static MeshCell northwestCell(TileMesh::MeshResolution_t res)
		{
			return { res, 0, 0 };
		}
		inline static MeshCell northeastCell(TileMesh::MeshResolution_t res)
		{
			return { res, res - 1, 0, };
		}
		inline static MeshCell southeastCell(TileMesh::MeshResolution_t res)
		{
			return { res, GridIndex_t(res - 1), GridIndex_t(res - 1) };
		}
		inline static MeshCell southwestCell(TileMesh::MeshResolution_t res)
		{
			return { res, 0, GridIndex_t(res - 1) };
		}

		inline MeshCell northernNeighbor()
		{
			return { res, i, j - 1 };
		}
		inline MeshCell southernNeighbor()
		{
			return { res, i, j + 1 };
		}
		inline MeshCell westernNeighbor()
		{
			return { res, i - 1, j };
		}
		inline MeshCell easternNeighbor()
		{
			return { res, i + 1, j };
		}

		inline uint16_t northwestIndex()
		{
			return uint16_t(j * (GridIndex_t(res) + 1) + i);
		}
		inline uint16_t northeastIndex()
		{
			return uint16_t(j * (GridIndex_t(res) + 1) + i + 1);
		}
		inline uint16_t southwestIndex()
		{
			return uint16_t((j + 1) * (GridIndex_t(res) + 1) + i);
		}
		inline uint16_t southeastIndex()
		{
			return uint16_t((j + 1) * (GridIndex_t(res) + 1) + i + 1);
		}
	};

	// TODO possibly make this a std::vector for performance
	std::map<TileMesh::MeshResolution_t, TileMesh*> TileMesh::sMeshes = {
		{ TileMesh::MeshResolution_t(64), nullptr },
		{ TileMesh::MeshResolution_t(32), nullptr },
		{ TileMesh::MeshResolution_t(16), nullptr },
		{ TileMesh::MeshResolution_t(8),  nullptr },
		{ TileMesh::MeshResolution_t(4),  nullptr },
		{ TileMesh::MeshResolution_t(2),  nullptr },
		{ TileMesh::MeshResolution_t(1),  nullptr },
	};

	TileMesh const* TileMesh::Instance(MeshResolution_t res)
	{
		if (sMeshes.find(res) == sMeshes.end() || sMeshes.at(res) == nullptr)
		{
			sMeshes[res] = new TileMesh(res);
		}

		return sMeshes[res];
	}

	void TileMesh::Shutdown()
	{
		for (auto& [res, mesh] : sMeshes)
		{
			if (mesh != nullptr)
			{
				delete mesh;
				mesh = nullptr;
			}
		}
	}

	TileMesh::TileMesh(MeshResolution_t resolution) :
		mResolution(resolution),
		mVertCount(computeVertCount(resolution)),
		mIdxCount(computeIndexCount(resolution)),
		mName("TileMeshRes" + std::to_string(resolution))
	{
		generateFaceVertices();
		generateRowTraversalsFaceIndices();
		generateColTraversalsFaceIndices();
		generateSkirtVertsIndices();
		generateBottomCapVertsIndices();
		allocateBuffers();
	}

	TileMesh::~TileMesh()
	{
		if (bgfx::isValid(mVertexBuffer))
		{
			bgfx::destroy(mVertexBuffer);
		}

		if (bgfx::isValid(mCapVertexBuffer))
		{
			bgfx::destroy(mCapVertexBuffer);
		}

		for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
		{
			if (bgfx::isValid(mRowTraversals[i].handle))
			{
				bgfx::destroy(mRowTraversals[i].handle);
			}
		}

		for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
		{
			if (bgfx::isValid(mColTraversals[i].handle))
			{
				bgfx::destroy(mColTraversals[i].handle);
			}
		}

		if (sMeshes[mResolution] == this)
		{
			sMeshes[mResolution] = nullptr;
		}

		if (bgfx::isValid(mBottomCap.handle))
		{
			bgfx::destroy(mBottomCap.handle);
		}
	}

	bool TileMesh::isValid() const
	{
		bool valid = bgfx::isValid(mVertexBuffer);
		for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
		{
			valid &= bgfx::isValid(mRowTraversals[i].handle);
		}
		for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
		{
			valid &= bgfx::isValid(mColTraversals[i].handle);
		}
		return valid;
	}

	void TileMesh::render(bgfx::ViewId viewId, bgfx::ProgramHandle const& program, TileId const& tileId, lgal::world::Vector3 const& eye, world_float_t const heading, uint64_t state, bool capBottom) const
	{
		state |= BGFX_STATE_PT_TRISTRIP;

		// set the vertex buffer
		bgfx::setVertexBuffer(0, mVertexBuffer);
		// we select an index buffer based on the camera position relative to the tile
		Indices const& indices = selectIndices(tileId, eye, heading);

		// bind index buffer
		bgfx::setIndexBuffer(indices.handle);
		// set the backface cull state based on the selected index buffer
		uint64_t windingState = (indices.windingOrder == Indices::WindingOrder::COUNTERCLOCKWISE) ? BGFX_STATE_CULL_CW : BGFX_STATE_CULL_CCW;
		

		bgfx::setState(state | windingState);
		bgfx::submit(viewId, program);

		if (capBottom)
		{
			bgfx::setVertexBuffer(0, mCapVertexBuffer);
			bgfx::setIndexBuffer(mBottomCap.handle);
			bgfx::setState(state | BGFX_STATE_CULL_CW);
			bgfx::submit(viewId, program);
		}
	}

	TileMesh::Indices const& TileMesh::selectIndices(TileId const& tileId, lgal::world::Vector3 const& eye, world_float_t const heading) const
	{
		// there are a couple cases for where the eye can be relative to the tile. depending on the relative
		// position, we will want to select a different index buffer so that most of the triangles are drawn
		// back to front
		//
		//              |               |
		//         1    |       2       |    3
		//           NW |               | NE
		//      ------- # ------------- # -------
		//              |               |
		//              |               |
		//         8    |       T       |    4
		//              |               |
		//              |               |
		//      ------- # ------------- # -------
		//           SW |               | SE
		//         7    |       6       |    5
		//              |               |
		//
		// there is a fundamental difference between cells with even indices and cells with odd indices. those
		// with odd indices only require that we begin traversal at the correct corner. it doesn't matter
		// whether we use rows or columns to traverse the face. on the other hand, this does matter for regions
		// with an even index. we must traverse using the direction of the tile boundary the region touches. 
		// ex: region 8 touches the west boundary of the tile T, so we should traverse using columns. aside from
		// the row/column selection, we pick the starting corner based on camera heading (whichever way the 
		// camera is facing)
		// 
		//   case T: for the moment, if the camera is inside the tile, we will just rely on the precision of
		//           the depth buffer. at some point, it might be interesting to include camera heading
		//   case 1: traverse the tile in rows and start at the NW corner
		//   case 2: traverse the tile in rows and start at the NE/NW corner depending on camera heading
		//   case 3: traverse the tile in rows and start at the NE corner
		//   case 4: traverse the tile in cols and start at the SE/NW corner depending on camera heading
		//   case 5: traverse the tile in rows and start at the SE corner
		//   case 6: traverse the tile in rows and start at the SW/SE corner depending on camera heading
		//   case 7: traverse the tile in rows and start at the SW corner
		//   case 8: traverse the tile in cols and start at the NW/SW corner depending on camera heading

		// compute tile min and max
		auto tileMin = tileId.northwestCorner();
		auto tileMax = tileId.southeastCorner();

		bool inX = (tileMin.x < eye.x) && (eye.x < tileMax.x);
		bool inY = (tileMin.y < eye.y) && (eye.y < tileMax.y);

		// case T
		if (inX && inY)
		{
			// this index buffer can be arbitrary since we are inside the tile and will rely on z-buffer
			// to correctly compute depth
			// TODO possibly select this index buffer based on heading?
			return mRowTraversals[FirstCorner::NORTHEAST];
		}
		// case 1: traverse the tile in rows and start at the NW corner
		if (eye.x <= tileMin.x && eye.y <= tileMin.y)
		{
			return mRowTraversals[FirstCorner::NORTHWEST];
		}
		// case 2: traverse the tile in rows and start at the NE/NW corner depending on camera heading
		else if (inX && eye.y <= tileMin.y)
		{
			bool facesEast = heading < lmath::constants::pi<world_float_t>();
			FirstCorner_t corner = (facesEast) ? FirstCorner::NORTHWEST : FirstCorner::NORTHEAST;
			return mRowTraversals[corner];
		}
		// case 3: traverse the tile in rows and start at the NE corner
		else if (tileMax.x <= eye.x && eye.y <= tileMin.y)
		{
			return mRowTraversals[FirstCorner::NORTHEAST];
		}
		// case 4: traverse the tile in cols and start at the SE/NE corner depending on camera heading
		else if (tileMax.x <= eye.x && inY)
		{
			bool facesNorth = (heading < lmath::constants::half_pi<world_float_t>()) || (heading >= 3.0 * lmath::constants::half_pi<world_float_t>());
			FirstCorner_t corner = (facesNorth) ? FirstCorner::SOUTHEAST : FirstCorner::NORTHEAST;
			return mColTraversals[corner];
		}
		// case 5: traverse the tile in rows and start at the SE corner
		else if (tileMax.x <= eye.x && tileMax.y <= eye.y)
		{
			return mRowTraversals[FirstCorner::SOUTHEAST];
		}
		// case 6: traverse the tile in rows and start at the SW/SE corner depending on camera heading
		else if (inX && tileMax.y <= eye.y)
		{
			bool facesEast = heading < lmath::constants::pi<world_float_t>();
			FirstCorner_t corner = (facesEast) ? FirstCorner::SOUTHWEST : FirstCorner::SOUTHEAST;
			return mRowTraversals[corner];
		}
		// case 7: traverse the tile in rows and start at the SW corner
		else if (eye.x <= tileMin.x && tileMax.y <= eye.y)
		{
			return mRowTraversals[FirstCorner::SOUTHWEST];
		}
		// case 8: traverse the tile in cols and start at the NW/SW corner depending on camera heading
		else if (eye.x <= tileMin.x && inY)
		{
			bool facesNorth = (heading < lmath::constants::half_pi<world_float_t>()) || (heading >= 3.0 * lmath::constants::half_pi<world_float_t>());
			FirstCorner_t corner = (facesNorth) ? FirstCorner::SOUTHWEST : FirstCorner::NORTHWEST;
			return mColTraversals[corner];
		}
		// the above if statements, should catch all possible cases. if not,
		// we select an arbitrary index buffer and throw an error message
		else
		{
			ONYX_DEBUG_ASSERT(false, "failed to appropriately assign an index buffer");
			return mRowTraversals[FirstCorner::NORTHEAST];
		}
	}

	void TileMesh::generateFaceVertices()
	{
		// the number of pixels on each side of the tile. create local variable so we don't have to cast on every use
		uint16_t res = (uint16_t)mResolution;
		// the number of vertices on each side of the tile
		uint16_t edgeVertices = res + 1;

		// corner aligned and 0-1 scale, transform in the shaders
		float stepSize = 1.0f / (float)res;
		mVerts.reserve(mVertCount);

		// calculate verts for the face triangles
		for (uint16_t y = 0; y < edgeVertices; y++)
		{
			for (uint16_t x = 0; x < edgeVertices; x++)
			{
				// setup our vert
				mVerts.push_back(Rendering::VertStructs::Pos({ x * stepSize, y * stepSize, 0.f }));
			}
		}
	}

	void TileMesh::generateRowTraversalsFaceIndices()
	{
		// winding order for columns in counterclockwise
		Indices::WindingOrder windingOrder = Indices::WindingOrder::COUNTERCLOCKWISE;

		// row traversal from northeast corner
		{
			auto& traversal = mRowTraversals[FirstCorner::NORTHEAST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in rows starting at the northeast corner and going west
			auto rowBegin = MeshCell::northeastCell(mResolution);
			while (rowBegin.valid())
			{
				// begin the row with the first two indices
				indices.push_back(rowBegin.southeastIndex());
				indices.push_back(rowBegin.northeastIndex());

				// traverse the row
				auto rowIter = rowBegin;
				while (rowIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(rowIter.southwestIndex());
					indices.push_back(rowIter.northwestIndex());
					// advance the cell to the west
					rowIter = rowIter.westernNeighbor();
				}

				// now advance to the next row
				rowBegin = rowBegin.southernNeighbor();

				// if the new row beginning cell is valid, add some join vertices
				if (rowBegin.valid())
				{
					indices.push_back(rowIter.northeastIndex());
					indices.push_back(rowBegin.southeastIndex());
				}
			}
		}
		// row traversal from southeast corner
		{
			auto& traversal = mRowTraversals[FirstCorner::SOUTHEAST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in rows starting at the southeast corner and going west
			auto rowBegin = MeshCell::southeastCell(mResolution);
			while (rowBegin.valid())
			{
				// begin the row with the first two indices
				indices.push_back(rowBegin.southeastIndex());
				indices.push_back(rowBegin.northeastIndex());

				// traverse the row
				auto rowIter = rowBegin;
				while (rowIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(rowIter.southwestIndex());
					indices.push_back(rowIter.northwestIndex());
					// advance the cell to the west
					rowIter = rowIter.westernNeighbor();
				}

				// now advance to the next row
				rowBegin = rowBegin.northernNeighbor();

				// if the new row beginning is valid, add some join vertices
				if (rowBegin.valid())
				{
					indices.push_back(rowIter.northeastIndex());
					indices.push_back(rowBegin.southeastIndex());
				}
			}
		}
		// row traversal from southwest corner
		{
			auto& traversal = mRowTraversals[FirstCorner::SOUTHWEST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in rows starting at the southwest corner and going east
			auto rowBegin = MeshCell::southwestCell(mResolution);
			while (rowBegin.valid())
			{
				// begin the row with the first two indices
				indices.push_back(rowBegin.northwestIndex());
				indices.push_back(rowBegin.southwestIndex());

				// traverse the row
				auto rowIter = rowBegin;
				while (rowIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(rowIter.northeastIndex());
					indices.push_back(rowIter.southeastIndex());
					// advance the cell to the east
					rowIter = rowIter.easternNeighbor();
				}

				// now advance to the next row
				rowBegin = rowBegin.northernNeighbor();

				// if the new row beginning is valid, add some join vertices
				if (rowBegin.valid())
				{
					indices.push_back(rowIter.southwestIndex());
					indices.push_back(rowBegin.northwestIndex());
				}
			}
		}
		// row traversal from northwest corner
		{
			auto& traversal = mRowTraversals[FirstCorner::NORTHWEST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in rows starting at the northwest corner and going east
			auto rowBegin = MeshCell::northwestCell(mResolution);
			while (rowBegin.valid())
			{
				// begin the row with the first two indices
				indices.push_back(rowBegin.northwestIndex());
				indices.push_back(rowBegin.southwestIndex());

				// traverse the row
				auto rowIter = rowBegin;
				while (rowIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(rowIter.northeastIndex());
					indices.push_back(rowIter.southeastIndex());
					// advance the cell to the east
					rowIter = rowIter.easternNeighbor();
				}

				// now advance to the next row
				rowBegin = rowBegin.southernNeighbor();

				// if the new row beginning cell is valid, add some join vertices
				if (rowBegin.valid())
				{
					indices.push_back(rowIter.southwestIndex());
					indices.push_back(rowBegin.northwestIndex());
				}
			}
		}
	}

	void TileMesh::generateColTraversalsFaceIndices()
	{
		// winding order for columns in clockwise
		Indices::WindingOrder windingOrder = Indices::WindingOrder::CLOCKWISE;

		// column traversal from northeast corner
		{
			auto& traversal = mColTraversals[FirstCorner::NORTHEAST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in columns starting at the northeast corner and going south
			auto colBegin = MeshCell::northeastCell(mResolution);
			while (colBegin.valid())
			{
				// begin the column with the first two indices
				indices.push_back(colBegin.northwestIndex());
				indices.push_back(colBegin.northeastIndex());

				// traverse the column
				auto colIter = colBegin;
				while (colIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(colIter.southwestIndex());
					indices.push_back(colIter.southeastIndex());
					// advance the column cell
					colIter = colIter.southernNeighbor();
				}

				// now advance to the next column
				colBegin = colBegin.westernNeighbor();

				// if the new column cell is valid, add some join vertices
				if (colBegin.valid())
				{
					indices.push_back(colIter.northeastIndex());
					indices.push_back(colBegin.northwestIndex());
				}
			}
		}
		// column traversal from southeast corner
		{
			auto& traversal = mColTraversals[FirstCorner::SOUTHEAST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in columns starting at the southeast corner and going west
			auto colBegin = MeshCell::southeastCell(mResolution);
			while (colBegin.valid())
			{
				// begin the column with the first two indices
				indices.push_back(colBegin.southeastIndex());
				indices.push_back(colBegin.southwestIndex());

				// traverse the column
				auto colIter = colBegin;
				while (colIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(colIter.northeastIndex());
					indices.push_back(colIter.northwestIndex());
					// advance to the next cell
					colIter = colIter.northernNeighbor();
				}

				// advance to the next column
				colBegin = colBegin.westernNeighbor();

				// if the new column beginning cell is valid, add some join vertices
				if (colBegin.valid())
				{
					indices.push_back(colIter.southwestIndex());
					indices.push_back(colBegin.southeastIndex());
				}
			}
		}
		// column traversal from southwest corner
		{
			auto& traversal = mColTraversals[FirstCorner::SOUTHWEST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in columns starting at the southwest corner and going north
			auto colBegin = MeshCell::southwestCell(mResolution);
			while (colBegin.valid())
			{
				// begin the column with the first two indices
				indices.push_back(colBegin.southeastIndex());
				indices.push_back(colBegin.southwestIndex());

				// traverse the column
				auto colIter = colBegin;
				while (colIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(colIter.northeastIndex());
					indices.push_back(colIter.northwestIndex());
					// advance to the next cell
					colIter = colIter.northernNeighbor();
				}

				// advance to the next column
				colBegin = colBegin.easternNeighbor();

				// if the new column beginning cell is valid, add some join vertices
				if (colBegin.valid())
				{
					indices.push_back(colIter.southwestIndex());
					indices.push_back(colBegin.southeastIndex());
				}
			}
		}
		// column traversal from northwest corner
		{
			auto& traversal = mColTraversals[FirstCorner::NORTHWEST];
			// set the winding order of the indices
			traversal.windingOrder = windingOrder;

			// grab the index buffer by reference
			auto& indices = traversal.indices;
			indices.reserve(mIdxCount);

			// traverse the face of the tile in columns starting at the northwest corner and going east
			auto colBegin = MeshCell::northwestCell(mResolution);
			while (colBegin.valid())
			{
				// begin the column with the first two indices
				indices.push_back(colBegin.northwestIndex());
				indices.push_back(colBegin.northeastIndex());

				// traverse the column
				auto colIter = colBegin;
				while (colIter.valid())
				{
					// add the indices (completing a quad)
					indices.push_back(colIter.southwestIndex());
					indices.push_back(colIter.southeastIndex());
					// advance the column cell to the south
					colIter = colIter.southernNeighbor();
				}

				// now advance to the next column
				colBegin = colBegin.easternNeighbor();

				// if the new column cell is valid, add some join vertices
				if (colBegin.valid())
				{
					indices.push_back(colIter.northeastIndex());
					indices.push_back(colBegin.northwestIndex());
				}
			}
		}
	}

	void TileMesh::generateSkirtVertsIndices()
	{
		// corner aligned and 0-1 scale, transform in the shaders
		float stepSize = 1.0f / (float)mResolution;
		auto firstSkirtVert = uint16_t(mVerts.size());

		// emit join vertices
		{
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mRowTraversals[i].indices.push_back(mRowTraversals[i].indices.back());
				mRowTraversals[i].indices.push_back(firstSkirtVert);
			}
			// columns wind clockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mColTraversals[i].indices.push_back(mColTraversals[i].indices.back());
				mColTraversals[i].indices.push_back(MeshCell::northwestCell(mResolution).northwestIndex());
			}
		}

		// calculate skirt verts for the north side of the tile
		for (MeshCell cell = MeshCell::northwestCell(mResolution); cell.valid(); cell = cell.easternNeighbor())
		{
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mRowTraversals[i].indices.push_back(uint16_t(mVerts.size()));
				mRowTraversals[i].indices.push_back(cell.northwestIndex());
			}
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mColTraversals[i].indices.push_back(cell.northwestIndex());
				mColTraversals[i].indices.push_back(uint16_t(mVerts.size()));
			}

			mVerts.push_back(Rendering::VertStructs::Pos({ cell.i * stepSize, 0.f, mSkirtHeight }));
		}

		// calculate skirt verts for the east side of the tile
		for (MeshCell cell = MeshCell::northeastCell(mResolution); cell.valid(); cell = cell.southernNeighbor())
		{
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mRowTraversals[i].indices.push_back(uint16_t(mVerts.size()));
				mRowTraversals[i].indices.push_back(cell.northeastIndex());
			}
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mColTraversals[i].indices.push_back(cell.northeastIndex());
				mColTraversals[i].indices.push_back(uint16_t(mVerts.size()));
			}

			mVerts.push_back(Rendering::VertStructs::Pos({ 1.f, cell.j * stepSize, mSkirtHeight }));
		}

		// calculate verts for the south side of the tile
		for (MeshCell cell = MeshCell::southeastCell(mResolution); cell.valid(); cell = cell.westernNeighbor())
		{
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mRowTraversals[i].indices.push_back(uint16_t(mVerts.size()));
				mRowTraversals[i].indices.push_back(cell.southeastIndex());
			}
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mColTraversals[i].indices.push_back(cell.southeastIndex());
				mColTraversals[i].indices.push_back(uint16_t(mVerts.size()));
			}

			mVerts.push_back(Rendering::VertStructs::Pos({ (cell.i + 1) * stepSize, 1.f, mSkirtHeight }));
		}

		// calculate verts for the west side of the tile
		for (MeshCell cell = MeshCell::southwestCell(mResolution); cell.valid(); cell = cell.northernNeighbor())
		{
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mRowTraversals[i].indices.push_back(uint16_t(mVerts.size()));
				mRowTraversals[i].indices.push_back(cell.southwestIndex());
			}
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mColTraversals[i].indices.push_back(cell.southwestIndex());
				mColTraversals[i].indices.push_back(uint16_t(mVerts.size()));
			}

			mVerts.push_back(Rendering::VertStructs::Pos({ 0.f, (cell.j + 1) * stepSize, mSkirtHeight }));
		}

		// close the skirts
		{
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mRowTraversals[i].indices.push_back(firstSkirtVert);
				mRowTraversals[i].indices.push_back(MeshCell::northwestCell(mResolution).northwestIndex());
			}
			// rows wind counterclockwise
			for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
			{
				mColTraversals[i].indices.push_back(MeshCell::northwestCell(mResolution).northwestIndex());
				mColTraversals[i].indices.push_back(firstSkirtVert);
			}
		}
	}

	void TileMesh::generateBottomCapVertsIndices()
	{
		// the number of pixels on each side of the tile. create local variable so we don't have to cast on every use
		uint16_t res = (uint16_t)mResolution;
		// the number of vertices on each side of the tile
		uint16_t edgeVertices = res;

		// corner aligned and 0-1 scale, transform in the shaders
		float stepSize = 1.0f / (float)res;

		//walk around the perimeter placing verts
		int x = 0;
		int y = 0;
		for (x = 0; x < edgeVertices; x++)
		{
			mCapVerts.push_back(Rendering::VertStructs::Pos({ x * stepSize, y * stepSize, mSkirtHeight }));
		}

		x = edgeVertices;
		for (y = 0; y < edgeVertices; y++)
		{
			mCapVerts.push_back(Rendering::VertStructs::Pos({ x * stepSize, y * stepSize, mSkirtHeight }));
		}

		y = edgeVertices;
		for (x = edgeVertices; x > 0; x--)
		{
			mCapVerts.push_back(Rendering::VertStructs::Pos({ x * stepSize, y * stepSize, mSkirtHeight }));
		}

		x = 0;
		for (y = edgeVertices; y > 0; y--)
		{
			mCapVerts.push_back(Rendering::VertStructs::Pos({ x * stepSize, y * stepSize, mSkirtHeight }));
		}

		// add one in the center, lower than everything else to prevent clipping
		mCapVerts.push_back(Rendering::VertStructs::Pos({ edgeVertices * stepSize * 0.5f, edgeVertices * stepSize * 0.5f, mSkirtHeight * 15 }));

		mBottomCap.indices.reserve((res - 1) * 4 * 3+ 3);
		uint16_t pointVert = (uint16_t)mCapVerts.size() - 1;
		for (size_t i = 0; i < mCapVerts.size() - 2; i++)
		{
			mBottomCap.indices.push_back(uint16_t(i));
			mBottomCap.indices.push_back(uint16_t(i + 1));
			mBottomCap.indices.push_back(uint16_t(pointVert));
		}
		//final triangle back to start
		mBottomCap.indices.push_back(uint16_t(mCapVerts.size() - 2));
		mBottomCap.indices.push_back(uint16_t(0));
		mBottomCap.indices.push_back(uint16_t(pointVert));
	}

	void TileMesh::allocateBuffers()
	{
		// create static vertex buffer
		ONYX_ASSERT(mVerts.size() == mVertCount, "Invalid number of vertices emitted");
		mVertexBuffer = bgfx::createVertexBuffer(bgfx::makeRef(mVerts.data(), sizeof(Rendering::VertStructs::Pos) * uint32_t(mVerts.size())), Rendering::VertStructs::Pos::ms_layout);
		bgfx::setName(mVertexBuffer, (mName + "Verts").c_str());

		mCapVertexBuffer = bgfx::createVertexBuffer(bgfx::makeRef(mCapVerts.data(), sizeof(Rendering::VertStructs::Pos) * uint32_t(mCapVerts.size())), Rendering::VertStructs::Pos::ms_layout);
		bgfx::setName(mCapVertexBuffer, (mName + "Cap Verts").c_str());

		// create static index buffers for row traversals
		for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
		{
			auto& traversal = mRowTraversals[i];
			ONYX_ASSERT(traversal.indices.size() == mIdxCount, "Invalid number of indices emitted");
			uint32_t size = sizeof(uint16_t) * uint32_t(traversal.indices.size());
			bgfx::Memory const* mem = bgfx::makeRef(traversal.indices.data(), size);
			traversal.handle = bgfx::createIndexBuffer(mem);
			bgfx::setName(traversal.handle, (mName + "Row" + std::to_string(i) + "Indices").c_str());
		}

		// create static index buffers for column traversals
		for (FirstCorner_t i = 0; i < FirstCorner::COUNT; i++)
		{
			auto& traversal = mColTraversals[i];
			ONYX_ASSERT(traversal.indices.size() == mIdxCount, "Invalid number of indices emitted");
			uint32_t size = sizeof(uint16_t) * uint32_t(traversal.indices.size());
			bgfx::Memory const* mem = bgfx::makeRef(traversal.indices.data(), size);
			traversal.handle = bgfx::createIndexBuffer(mem);
			bgfx::setName(traversal.handle, (mName + "Col" + std::to_string(i) + "Indices").c_str());
		}

		uint32_t size = sizeof(uint16_t) * uint32_t(mBottomCap.indices.size());
		bgfx::Memory const* mem = bgfx::makeRef(mBottomCap.indices.data(), size);
		mBottomCap.handle = bgfx::createIndexBuffer(mem);
		bgfx::setName(mBottomCap.handle, (mName + "Bottom Cap" + "Indices").c_str());
	}

} }
