#pragma once

#include <array>
#include <string>
#include <sstream>
#include <tuple>
#include <unordered_set>

#include <lucid/gal/Types.h>

namespace onyx::Tiles
{

	// TODO move this to a LonLat/LonLatElevation file in lucid
	static constexpr world_float_t cEquatorCircumferenceKm = 40041.472;

	static constexpr world_float_t cMaxExtent = cEquatorCircumferenceKm;

	// x and y bounds for the projected map
	static constexpr world_float_t cLeftX = -cMaxExtent / 2.0;
	static constexpr world_float_t cRightX = cMaxExtent / 2.0;
	static constexpr world_float_t cTopY = -cMaxExtent / 2.0;		// top is negative because we flip the y axis
	static constexpr world_float_t cBotY = cMaxExtent / 2.0;

	struct TileId
	{

	public:

		enum class Origin
		{
			BOTTOM_LEFT,
			TOP_LEFT
		};

	public:

		typedef int IdCoordsT;
		IdCoordsT level, x, y;

	public:

		TileId() : level(0), x(0), y(0) { }

		TileId(IdCoordsT level, IdCoordsT x, IdCoordsT y)
			: level(level)
			, x(x)
			, y(y)
		{}

		explicit TileId(uint64_t quadTreeCode)
			: level(0)
			, x(0)
			, y(0)
		{
			while (quadTreeCode > 1)
			{
				y |= ((quadTreeCode & 1) << level);
				quadTreeCode >>= 1;
				x |= ((quadTreeCode & 1) << level);
				quadTreeCode >>= 1;
				++level;
			}
		}

		inline bool operator==(TileId const& rhs) const
		{
			return level == rhs.level
				&& x == rhs.x
				&& y == rhs.y;
		}

		inline bool operator!=(TileId const& rhs) const
		{
			return !(*this == rhs);
		}

		auto tie() const
		{
			return std::tie(level, x, y);
		}

		inline bool operator<(const TileId& rhs) const
		{
			return tie() < rhs.tie();
		}

		inline explicit operator uint64_t() const
		{
			auto l = level;
			uint64_t result = 1;
			if (l == 0)
				return result;
			do
			{
				--l;
				result <<= 1;
				auto xBit = (x & (1 << l)) >> l;
				result |= xBit;
				result <<= 1;
				auto yBit = (y & (1 << l)) >> l;
				result |= yBit;
			} while (l > 0);
			
			return result;
		}

		inline TileId moduloX() const { return { level, x & ((1 << level) - 1), y }; }

		bool isValid() const
		{
			if (level < 0)
			{
				return false;
			}

			int maxIndex = (1 << level) - 1;	// maximum index for this zoom level
			if (x < 0 || x > maxIndex)
			{
				return false;
			}
			if (y < 0 || y > maxIndex)
			{
				return false;
			}

			return true;		// passed all checks, return true
		}

		bool isValid(IdCoordsT minLevel, IdCoordsT maxLevel) const
		{
			if (level < minLevel || level > maxLevel)
			{
				return false;
			}

			return isValid();
		}

		inline TileId northwestChild() const { return { level + 1, x << 1, y << 1 }; }
		inline TileId northeastChild() const { return { level + 1, (x << 1) + 1, y << 1 }; }
		inline TileId southwestChild() const { return { level + 1, x << 1, (y << 1) + 1 }; }
		inline TileId southeastChild() const { return { level + 1, (x << 1) + 1, (y << 1) + 1 }; }

		inline std::array<TileId, 4> children() const { return { northwestChild(), northeastChild(), southwestChild(), southeastChild() }; }

		inline TileId parent(IdCoordsT relativeLevel = 1) const
		{
			relativeLevel = std::min(level, relativeLevel);
			return { level - relativeLevel, x >> relativeLevel, y >> relativeLevel };
		}

		inline TileId parentAtLevel(int lvl) const
		{
			return parent(level - lvl);
		}

		inline TileId northNeighbor() const { return { level, x, y - 1 }; }
		inline TileId southNeighbor() const { return { level, x, y + 1 }; }
		inline TileId westNeighbor()  const { return { level, x - 1, y }; }
		inline TileId eastNeighbor()  const { return { level, x + 1, y }; }

		inline TileId northwestNeighbor() const { return { level, x - 1, y - 1 }; }
		inline TileId northeastNeighbor() const { return { level, x + 1, y - 1 }; }
		inline TileId southwestNeighbor() const { return { level, x - 1, y + 1 }; }
		inline TileId southeastNeighbor() const { return { level, x + 1, y + 1 }; }

		inline world_float_t extent() const
		{
			return TileId::LevelToTileExtent(level);
		}

		// NOTE: includes the tile boundary
		bool inBounds(lgal::world::Vector2 const& pos) const;
		inline bool inBounds(lgal::world::Vector3 const& pos) const
		{
			return inBounds(pos.xy);
		}

		lgal::world::Vector2 center() const;

		lgal::world::Vector2 northwestCorner() const;
		lgal::world::Vector2 northeastCorner() const;
		lgal::world::Vector2 southeastCorner() const;
		lgal::world::Vector2 southwestCorner() const;

		template<typename T>
		lmath::Vector<T, 2> toUVCoords(lgal::world::Vector2 const& pos, Origin origin) const
		{
			// compute the extent
			auto extentInv = 1.0 / LevelToTileExtent(level);

			// x and y coordinates of the top left corner of the tile
			auto corner = northwestCorner();

			// uv coordinates on the tile
			auto u = (pos.x - corner.x) * extentInv;
			auto v = (pos.y - corner.y) * extentInv;

			// flip if necessary
			if (origin == Origin::BOTTOM_LEFT)
			{
				v = 1.0 - v;
			}

			return { static_cast<T>(u), static_cast<T>(v) };
		}

		template <typename T>
		lgal::world::Vector2 toWorldPos(lmath::Vector<T, 2> const& uv, Origin origin) const
		{
			auto extent = TileId::LevelToTileExtent(level);
			auto corner = northwestCorner();
			// flip if necessary
			auto v = uv.y;
			if (origin == Origin::BOTTOM_LEFT)
			{
				v = T(1.0) - v;
			}
			auto X = uv.x * extent;
			auto Y = v * extent;

			return { corner.x + X, corner.y + Y };
		}

		template <typename T>
		inline lmath::AABB<T, 2> worldBounds() const
		{
			auto nw = northwestCorner();
			auto se = southeastCorner();
			return { nw.as<T>(), se.as<T>() };
		}

		inline std::string string() const
		{
			std::ostringstream str;
			str << "{ " << level << ", " << x << ", " << y << " }";
			return str.str();
		}

	public:

		static inline TileId Root()
		{
			return TileId(0, 0, 0);
		}

		static inline world_float_t LevelToTileExtent(Tiles::TileId::IdCoordsT level)
		{
			int count = 1 << int(level);
			return cMaxExtent / world_float_t(count);
		}

		static Tiles::TileId Containing(Tiles::TileId::IdCoordsT level, lgal::world::Vector2 const& pos);
		static inline Tiles::TileId Containing(Tiles::TileId::IdCoordsT level, lgal::world::Vector3 const& pos)
		{
			return TileId::Containing(level, pos.xy);
		}

		static lgal::tile::AABB2d InternalBounds(TileId lowerDetail, TileId higherDetail)
		{
			if (lowerDetail.level == higherDetail.level)
			{
				return { { 0, 0 }, { 1, 1 } };
			}

			auto levelOffset = higherDetail.level - lowerDetail.level;
			auto factor = 1 << levelOffset;

			auto mask = ~(0xFFFFFFFF << levelOffset);
			auto higherX = higherDetail.x & mask;
			auto higherY = higherDetail.y & mask;

			auto scale = tile_float_t(1.0f) / tile_float_t(factor);

			return { { higherX * scale, higherY * scale }, { (higherX + 1) * scale, (higherY + 1) * scale } };
		}
		
	public:

		// function that will compute and return a container with the passed in TileIds modulo the x coordinate
		// ie the invalid TileId { 1, 2, 0 } gets mapped to the valid TileId { 1, 0, 0 }
		template<class Container>
		static Container UniqueModuloX(Container const& inContainer);

		// TODO possibly add a uniqueNeighbors function

		// functions that will compute a container with unique parents (at the relative level) of the passed in tiles
		template<class Container>
		static void UniqueParents(Container& result, Container const& tiles, IdCoordsT relativeLevel = 1);
		template<class Container>
		static Container UniqueParents(Container const& tiles, IdCoordsT relativeLevel = 1)
		{
			Container result;
			result.reserve(tiles.size() >> 1);	// reserve a predicted amount of memory
			UniqueParents(result, tiles, relativeLevel);
			return result;
		}

		// TODO possibly add a uniqueNeighbors function

		// functions that will compute a container with the unique tiles at (or lower detail) than the max level
		// explicitly:
		//      level < maxLevel => tile goes to output container as is
		//      level = maxLevel => add to output container (if not already present)
		//      level > maxLevel => find parent at maxLevel and add to output container (if not already present)
		template<class Container>
		static void UniqueClampedToMaxLevel(Container& result, Container const& tiles, IdCoordsT maxLevel);
		template<class Container>
		static Container UniqueClampedToMaxLevel(Container const& tiles, IdCoordsT maxLevel)
		{
			Container result;
			result.reserve(tiles.size() >> 1);	// reserve a predicted amount of memory
			UniqueClampedToMaxLevel(result, tiles, maxLevel);
			return result;
		}

		// functions that will keep only tile ids with minLevel <= level
		template<class Container>
		static void Filter(Container & result, Container const& tiles, IdCoordsT minLevel);
		template<class Container>
		static Container Filter(Container const& tiles, IdCoordsT minLevel)
		{
			Container result;
			result.reserve(tiles.size());	// reserve a predicted amount of memory
			Filter(result, tiles, minLevel);
			return result;
		}

		// functions that will keep only tile ids with minLevel <= level <= maxLevel
		template<class Container>
		static void Filter(Container& result, Container const& tiles, IdCoordsT minLevel, IdCoordsT maxLevel);
		template<class Container>
		static Container Filter(Container const& tiles, IdCoordsT minLevel, IdCoordsT maxLevel)
		{
			Container result;
			result.reserve(tiles.size() >> 1);	// reserve a predicted amount of memory
			Filter(result, tiles, minLevel, maxLevel);
			return result;
		}

		// functions that will keep only tileIds that are closer than distance from point. these should only be used in coarse contexts because it ignores the z bounds of a tile
		template<class Container>
		static void Filter2D(Container& result, Container const& tiles, lgal::world::Vector3 const& point, world_float_t distance);
		template<class Container>
		static Container Filter2D(Container const& tiles, lgal::world::Vector3 const& point, world_float_t distance)
		{
			Container result;
			result.reserve(tiles.size());	// reserve a predicted amount of memory
			Filter2D(result, tiles, point, distance);
			return result;
		}

	};

	template<>
	inline lmath::AABB<world_float_t, 2> TileId::worldBounds() const
	{
		auto nw = northwestCorner();
		auto se = southeastCorner();
		return { nw, se };
	}

}

namespace std
{
	template<>
	struct hash<onyx::Tiles::TileId>
	{
	public:
		inline size_t operator()(onyx::Tiles::TileId const& id) const
		{
			size_t constexpr prime = 53;
			size_t l = static_cast<size_t>(id.level);
			size_t x = static_cast<size_t>(std::abs(id.x));
			size_t y = static_cast<size_t>(std::abs(id.y));
			return l + prime * (x + prime * y);
		}
	};
}

namespace onyx::Tiles
{

	template<class Container>
	Container TileId::UniqueModuloX(Container const& inContainer)
	{
		// create the result container and a std::unordered_set to keep track of what has been inserted
		Container result;
		std::unordered_set<TileId> inserted;

		// compute a prediction for the size of the output container
		size_t predictedSize = inContainer.size();

		// reserve the predicted amount of memory
		result.reserve(predictedSize);
		inserted.reserve(predictedSize);

		// iterate over the container and add in the unique TileIds
		for (auto const& tileId : inContainer)
		{
			auto mod = tileId.moduloX();
			bool contains = inserted.find(mod) != inserted.end();
			if (!contains)
			{
				inserted.insert(mod);
				result.insert(result.end(), mod);
			}
		}

		return result;
	}

	template<class Container>
	void TileId::UniqueParents(Container& result, Container const& tiles, IdCoordsT relativeLevel)
	{
		// create a std::unordered_set to keep track of what has been inserted
		std::unordered_set<TileId> inserted;

		// compute a prediction for the size of the output container
		size_t predictedSize = tiles.size() >> 1;

		// reserve the predicted amount of memory
		inserted.reserve(predictedSize);

		// iterate over the container and add in the unique parent TileIds at the relative level
		for (auto const& tileId : tiles)
		{
			auto parent = tileId.parent(relativeLevel);
			bool contains = inserted.find(parent) != inserted.end();
			if (!contains)
			{
				inserted.insert(parent);
				result.insert(result.end(), parent);
			}
		}
	}

	template<class Container>
	void TileId::UniqueClampedToMaxLevel(Container& result, Container const& tiles, IdCoordsT maxLevel)
	{
		// create a std::unordered_set to keep track of what has been inserted
		std::unordered_set<TileId> inserted;

		// compute a prediction for the size of the output container
		size_t predictedSize = tiles.size() >> 1;
		// reserve the predicted amount of memory
		inserted.reserve(predictedSize);

		// iterate over the container and add in the unique parent TileIds at the relative level
		for (auto const& tileId : tiles)
		{
			if (tileId.level <= maxLevel)	// if we are at or below the max level, just check if we need to insert
			{
				bool contains = inserted.find(tileId) != inserted.end();
				if (!contains)
				{
					inserted.insert(tileId);
					result.insert(result.end(), tileId);
				}
			}
			else // beyond the max level, compute the appropriate tile and check if we need to insert
			{
				auto parent = tileId.parentAtLevel(maxLevel);
				bool contains = inserted.find(parent) != inserted.end();
				if (!contains)
				{
					inserted.insert(parent);
					result.insert(result.end(), parent);
				}
			}
		}
	}

	template <class Container>
	void TileId::Filter(Container& result, Container const& tiles, IdCoordsT minLevel)
	{
		// iterate over the container and only add the tiles in the range [minLevel, maxLevel]
		for (auto const& tileId : tiles)
		{
			if (minLevel <= tileId.level)
			{
				result.insert(result.end(), tileId);
			}
		}
	}

	template <class Container>
	void TileId::Filter(Container& result, Container const& tiles, IdCoordsT minLevel, IdCoordsT maxLevel)
	{
		// iterate over the container and only add the tiles in the range [minLevel, maxLevel]
		for (auto const& tileId : tiles)
		{
			if (minLevel <= tileId.level && tileId.level <= maxLevel)
			{
				result.insert(result.end(), tileId);
			}
		}
	}

	template<class Container>
	void TileId::Filter2D(Container& result, Container const& tiles, lgal::world::Vector3 const& point, world_float_t distance)
	{
		// iterate over the container and only add tiles that are close enough
		for (TileId const& tileId : tiles)
		{
			lgal::world::AABB3d aabb({ tileId.northwestCorner(), 0.0 }, { tileId.southeastCorner(), 0.0 });
			if (aabb.distanceTo(point) <= distance)
			{
				result.insert(result.end(), tileId);
			}
		}
	}

}