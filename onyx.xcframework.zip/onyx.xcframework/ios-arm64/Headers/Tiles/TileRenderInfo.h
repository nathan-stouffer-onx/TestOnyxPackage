#pragma once

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include "Atlases/TileAtlas.h"
#include "Tiles/TileId.h"
#include "Utils/MapMath.h"
#include "Utils/Timer.h"

namespace onyx::Tiles
{

	struct AtlasInfo
	{
		bgfx::TextureHandle handle = { bgfx::kInvalidHandle };
		uint32_t resolution = 0;
		lgal::gpu::Vector4 offset;
		gpu_float_t opacity = 1.f;
		TileId::IdCoordsT level = 0;

		AtlasInfo() : offset({ 0, 0, 0, 0 }) {}
		AtlasInfo(bgfx::TextureHandle const& handle, uint32_t resolution, lgal::gpu::Vector4 const &offset, gpu_float_t const _opacity, TileId::IdCoordsT level)
			: handle(handle)
			, resolution(resolution)
			, offset(offset)
			, opacity(_opacity)
			, level(level)
		{}

		inline bool isValid() const { return bgfx::isValid(handle); }
		
		static inline AtlasInfo invalid() { return { BGFX_INVALID_HANDLE, 0, {0, 0, 0, 0}, 1, -1 }; }

		static AtlasInfo Compute(Atlases::TileAtlas const& atlas, TileId const& tileId, lgal::Range const& zoomRange, gpu_float_t const opacity = 1.f);

	};

	struct TileInfo
	{
		TileId id;

		lgal::world::Vector3 tileMax,
			tileMin,
			tileSize;

		lgal::world::Vector2 distortion;

		AtlasInfo heightAtlasInfo;

		lgal::Color color = lgal::Color(0.f, 0, 0, 0);

		bool isReady = false;

		TileInfo(TileId const &id) : id(id)
		{
			world_float_t size = id.extent();
			tileSize = { size, size, 1. };
			tileMin = { id.northwestCorner(), 0. };
			tileMax = { id.southeastCorner(), 1. };
			distortion = { MapMath::mercatorDistortion(tileMin.xy), MapMath::mercatorDistortion(tileMax.xy) };
		}

	};

	struct TileVectorInfo final : public TileInfo
	{
		constexpr static time_float_t DefaultFadeTime = 500.0; // Milliseconds

		// TODO (stouff) probably move to TileInfo?
		uint16_t meshResolution;

		time_float_t addTimestamp;
		time_float_t useTimestamp;

		bool childIsLoading = true;

		inline void touch(time_float_t now)
		{
			useTimestamp = now;
		}

		TileVectorInfo(TileId const &id, time_float_t timestamp) :
			TileInfo(id),
			meshResolution(64),
			addTimestamp(timestamp),
			useTimestamp(timestamp)
		{}

		TileVectorInfo(TileVectorInfo const& tVecInfo) :
			TileInfo(tVecInfo.id), meshResolution(tVecInfo.meshResolution),
			addTimestamp(tVecInfo.addTimestamp), useTimestamp(tVecInfo.useTimestamp)
		{
			tileMin = tVecInfo.tileMin;
			tileMax = tVecInfo.tileMax;
			tileSize = tVecInfo.tileSize;
			distortion = tVecInfo.distortion;
			heightAtlasInfo = tVecInfo.heightAtlasInfo;
			color = tVecInfo.color;
		}
		
		TileVectorInfo& operator=(TileVectorInfo const& tVecInfo) = default;
	};

	struct TileTextureInfo final : public TileInfo
	{
		static constexpr size_t MAX_TEXTURE_LAYERS = 3;

		AtlasInfo layers[MAX_TEXTURE_LAYERS];

		int layerCount = 0;

		bool isComplete = false;

		time_float_t fadeTimer = 0;

		TileTextureInfo(TileId const &id) : TileInfo(id) {}
	};

}