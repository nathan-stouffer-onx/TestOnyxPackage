#pragma once

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include "Atlases/TileAtlas.h"
#include "Tiles/TileId.h"
#include "Utils/MapMath.h"
#include "Utils/Timer.h"

namespace onyx::Tiles
{

	struct AtlasInfo
	{
		bgfx::TextureHandle handle = { bgfx::kInvalidHandle };
		uint32_t resolution = 0;
		lgal::gpu::Vector4 offset;
		gpu_float_t opacity = 1.f;
		TileId::IdCoordsT level = 0;

		AtlasInfo() : offset({ 0, 0, 0, 0 }) {}
		AtlasInfo(bgfx::TextureHandle const& handle, uint32_t resolution, lgal::gpu::Vector4 const &offset, gpu_float_t const _opacity, TileId::IdCoordsT level)
			: handle(handle)
			, resolution(resolution)
			, offset(offset)
			, opacity(_opacity)
			, level(level)
		{}

		inline bool isValid() const { return bgfx::isValid(handle); }
		
		static inline AtlasInfo invalid() { return { BGFX_INVALID_HANDLE, 0, {0, 0, 0, 0}, 1, -1 }; }

		static AtlasInfo Compute(Atlases::TileAtlas const& atlas, TileId const& tileId, lgal::Range const& zoomRange, gpu_float_t const opacity = 1.f);

	};

	struct RenderInfo
	{
		TileId id;

		lgal::world::Vector3 tileMax,
			tileMin,
			tileSize;

		lgal::world::Vector2 distortion;

		AtlasInfo heightAtlasInfo;
		uint16_t meshResolution;

		bool isReady = false;

		RenderInfo(TileId const &id) :
			id(id),
			meshResolution(64)
		{
			world_float_t size = id.extent();
			tileSize = { size, size, 1. };
			tileMin = { id.northwestCorner(), 0. };
			tileMax = { id.southeastCorner(), 1. };
			distortion = { MapMath::mercatorDistortion(tileMin.xy), MapMath::mercatorDistortion(tileMax.xy) };
		}

		~RenderInfo() = default;

	};

	struct VectorRenderInfo final : public RenderInfo
	{
		constexpr static time_float_t DefaultFadeTime = 500.0; // Milliseconds

		time_float_t addTimestamp;
		time_float_t useTimestamp;

		bool childIsLoading = false;

		inline void touch(time_float_t now)
		{
			useTimestamp = now;
		}

		float alpha(time_float_t timeMS, time_float_t fadeMS, time_float_t pulseMS, time_float_t pulseDelayMS) const;

		VectorRenderInfo(TileId const &id, time_float_t timestamp) :
			RenderInfo(id),
			addTimestamp(timestamp),
			useTimestamp(timestamp)
		{}

	private:

		bool mutable mWasPulsing = 1.f;

	};

	struct RasterRenderInfo final : public RenderInfo
	{
		static constexpr size_t MAX_TEXTURE_LAYERS = 3;

		AtlasInfo layers[MAX_TEXTURE_LAYERS];

		int layerCount = 0;

		time_float_t fadeTimer = 0;

		RasterRenderInfo(TileId const &id) : RenderInfo(id) {}
	};

}