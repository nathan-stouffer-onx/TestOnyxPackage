#include "TileRenderInfo.h"

#include "Pyramid/UVOffset.h"

namespace onyx::Tiles
{

	AtlasInfo AtlasInfo::Compute(Atlases::TileAtlas const& atlas, Tiles::TileId const& tileId, lgal::Range const& zoomRange, gpu_float_t const opacity)
	{
		Tiles::TileId ready = tileId;
		if (ready.level > zoomRange.end)
		{
			ready = ready.parent(ready.level - zoomRange.end);
		}

		while (ready.level >= zoomRange.begin)	// loop to see if we can find a lower detail texture
		{
			if (atlas.isReady(ready))
			{
				auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(ready, tileId);
				auto uvOffset = atlas.getUVOffset(ready);

				auto combinedOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);

				auto handle = atlas.getTexHandle(ready);
				uint32_t atlasResolution = atlas.getResolution();

				return { handle, atlasResolution, combinedOffset, opacity, ready.level };
			}
			else
			{
				if (ready.level <= zoomRange.begin)
					break;

				ready = ready.parent();
			}
		}

		return AtlasInfo::invalid();
	}

}