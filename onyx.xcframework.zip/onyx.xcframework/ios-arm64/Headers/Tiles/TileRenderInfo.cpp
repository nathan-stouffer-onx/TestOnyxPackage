#include "TileRenderInfo.h"

#include "Pyramid/UVOffset.h"

namespace onyx::Tiles
{

	AtlasInfo AtlasInfo::Compute(Atlases::TileAtlas const& atlas, Tiles::TileId const& tileId, lgal::Range const& zoomRange, gpu_float_t const opacity)
	{
		Tiles::TileId ready = tileId;
		if (ready.level > zoomRange.end)
		{
			ready = ready.parent(ready.level - zoomRange.end);
		}

		while (ready.level >= zoomRange.begin)	// loop to see if we can find a lower detail texture
		{
			if (atlas.isReady(ready))
			{
				auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(ready, tileId);
				auto uvOffset = atlas.getUVOffset(ready);

				auto combinedOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);

				auto handle = atlas.getTexHandle(ready);
				uint32_t atlasResolution = atlas.getResolution();

				return { handle, atlasResolution, combinedOffset, opacity, ready.level };
			}
			else
			{
				if (ready.level <= zoomRange.begin)
					break;

				ready = ready.parent();
			}
		}

		return { atlas.getMissingTileHandle(), atlas.getMissingTileResolution(), atlas.getMissingTileUVOffset(), 0.f, 0 };
	}

	float VectorRenderInfo::alpha(time_float_t timeMS, time_float_t /* fadeMS */, time_float_t pulseMS, time_float_t pulseDelayMS) const
	{
		float alpha = 1.0f;

		// TODO (stouff) enable fade in/out
		//auto fadeIn = useTimestamp - addTimestamp;
		//auto fadeOut = timeMS - useTimestamp;
		//if (fadeIn < fadeMS || fadeOut > 0)
		//{
		//	alpha = float(std::min(fadeIn / fadeMS, 1.));
		//	if (fadeOut > 0)
		//	{
		//		alpha *= (1 - float(fadeOut / fadeMS));
		//	}
		//}

		if ((childIsLoading || mWasPulsing) && pulseMS > 0)
		{
			mWasPulsing = false;
			time_float_t interval = std::fmod(timeMS, pulseDelayMS + pulseMS);
			if (pulseDelayMS < interval)
			{
				mWasPulsing = true;
				time_float_t t = (interval - pulseDelayMS) / pulseMS;
				time_float_t theta = t * lmath::constants::pi<time_float_t>();
				alpha *= static_cast<float>(std::cos(theta) * std::cos(theta));
			}
		}

		return alpha;
	}
}