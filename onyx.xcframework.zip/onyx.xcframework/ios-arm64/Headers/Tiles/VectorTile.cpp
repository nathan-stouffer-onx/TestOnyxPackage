#include "VectorTile.h"

#include <lucid/Profiler.h>

#include <System/OnyxException.h>
#include <Utils/Memory.h>
#include <Warnings.h>

namespace onyx {
namespace Tiles {

	VectorTile::VectorTile(Caching::TileCacheKey const& key, std::shared_ptr<std::vector<uint8_t>> const& data, Styling::PromoteId const& promoteIds, time_float_t timestampMS) :
		VectorTile(key.tile, VectorTile::Parse(key, data), promoteIds, timestampMS)
	{}

	VectorTile::VectorTile(Tiles::TileId const& tileId, vector_tile::Tile const& protobuf, Styling::PromoteId const& promoteIds, time_float_t timestampMS) :
		VectorTile(tileId, VectorTile::Decode(protobuf, promoteIds, timestampMS))
	{}

	VectorTile::VectorTile(Tiles::TileId const& tileId, LayerT layer) :
		VectorTile(tileId, std::vector<LayerT>{ layer })
	{}

	VectorTile::VectorTile(Tiles::TileId const& tileId, std::vector<LayerT> layers) :
		mTileId(tileId),
		mTimestampMS(VectorTile::MaxTimestamp(layers)),
		mByteCount(Utils::countBytes(layers))
	{
		for (LayerT const& layer : layers)
		{
			mLayers.insert({ layer->name(), layer });
		}
	}

	vector_tile::Tile VectorTile::Parse(Caching::TileCacheKey const& key, std::shared_ptr<std::vector<uint8_t>> const& data)
	{
		LUCID_PROFILE_SCOPE("Parse protobuf tile");
		vector_tile::Tile protobuf;
		ONYX_ASSERT(data->size() < size_t(std::numeric_limits<int>::max()), "Protobuf tile data size is > 2GB");
		ONYX_ASSERT(protobuf.ParseFromArray(data->data(), int(data->size())), "Could not parse protobuf data for { " + key.source + " : " + key.tile.string() + " }");
		return protobuf;
	}

	std::vector<VectorTile::LayerT> VectorTile::Decode(vector_tile::Tile const& protobuf, Styling::PromoteId const& promoteIds, time_float_t timestampMS)
	{
		LUCID_PROFILE_SCOPE("Decode protobuf tile");
		std::vector<LayerT> layers;
		for (int i = 0; i < protobuf.layers_size(); ++i)
		{
			std::string const featureIdKey = promoteIds.key(protobuf.layers(i).name());
			LayerT layer = std::make_shared<Vector::Layer>(protobuf.layers(i), featureIdKey, timestampMS);
			layers.push_back(layer);
		}
		return layers;
	}

	time_float_t VectorTile::MaxTimestamp(std::vector<LayerT> const& layers)
	{
		time_float_t max = std::numeric_limits<time_float_t>::min();
		for (auto const& layer : layers)
		{
			max = std::max(max, layer->timestampMS());
		}
		return max;
	}


} }