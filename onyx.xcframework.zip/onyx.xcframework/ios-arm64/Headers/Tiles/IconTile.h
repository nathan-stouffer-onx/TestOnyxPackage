#ifndef __ICON_TILE_H__
#define __ICON_TILE_H__

#include <vector>
#include <lucid/gal/Types.h>

#include "TileRenderInfo.h"
#include "Utils/property.h"

namespace onyx {
namespace Tiles {

struct IconTile
{
	RenderInfo tInfo;
	std::vector<lgal::gpu::Vector2> points;	// coords are in tile coordinates

	IconTile(Tiles::TileId const& tId) : tInfo(tId), points()
	{
	
	}
};

} }

#endif
