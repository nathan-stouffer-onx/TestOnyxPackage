#pragma once

#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>

#include <Shaders/ShaderEnums.h>

#include "Camera/CameraState.h"
#include "Rendering/VertStructs.h"
#include "TileId.h"

namespace onyx {
namespace Tiles {

	/*
	* TileMesh is a helper class for Tile, it's purpose is to generate the mesh structure of a tile in a single place
	* so that each tile doesn't have to make those computations for themselves. Instead, it can just tell the TileMesh
	* class to draw and provide the appropriate data to transform the tile from the unit square to the world position
	* of the tile to be drawn.
	*/
	class TileMesh
	{
	public:

		typedef uint16_t MeshResolution_t;

		static TileMesh const* Instance(MeshResolution_t res = 64);
		static void Shutdown();
		
		bool isValid() const;
		void draw(TileId const& tileId, lgal::world::Vector3 const& eye, world_float_t const heading, bgfx::ProgramHandle const& program, bgfx::ViewId viewId, bool alpha = false, uint64_t renderStateOverride = 0, bool capBottom = false) const;

	private:

		TileMesh(MeshResolution_t divisions);
		~TileMesh();

		MeshResolution_t const mResolution;		// number of square divisions to make in the tile to form the mesh
		uint32_t const mVertCount;				// number of vertices in the mesh
		uint32_t const mIdxCount;				// number of indices in the mesh

		std::string const mName;

		// TODO change this to VertStructs::PosUV
		std::vector<Rendering::VertStructs::PosColorUV> mVerts;
		bgfx::VertexBufferHandle mVertexBuffer;
		std::vector<Rendering::VertStructs::PosColorUV> mCapVerts;
		bgfx::VertexBufferHandle mCapVertexBuffer;

		const float mSkirtHeight = -0.1f;

		struct Indices
		{
			enum class WindingOrder
			{
				COUNTERCLOCKWISE,
				CLOCKWISE
			};

			std::vector<uint16_t> indices;
			bgfx::IndexBufferHandle handle;
			WindingOrder windingOrder;
		};

		// an enum to use for indexing the index buffer arrays
		typedef uint8_t FirstCorner_t;
		enum FirstCorner : FirstCorner_t
		{
			NORTHEAST = 0,
			SOUTHEAST,
			SOUTHWEST,
			NORTHWEST,
			COUNT
		};

		// these index buffers are eight different traversals of the tile. they can be used to reduce z fighting
		// depending on the camera state. the starting cells of the index buffer are
		//    [0] - start at the northeast cell
		//    [1] - start at the southeast cell
		//    [2] - start at the southwest cell
		//    [3] - start at the northwest cell
		Indices mRowTraversals[FirstCorner::COUNT];
		Indices mColTraversals[FirstCorner::COUNT];
		Indices mBottomCap;
		Indices const& selectIndices(TileId const& tileId, lgal::world::Vector3 const& eye, world_float_t const heading) const;

		void generateFaceVertices();
		void generateRowTraversalsFaceIndices();
		void generateColTraversalsFaceIndices();
		void generateSkirtVertsIndices();
		void generateBottomCapVertsIndices();
		void allocateBuffers();

		static std::map<MeshResolution_t, TileMesh*> sMeshes;

	};

} }
