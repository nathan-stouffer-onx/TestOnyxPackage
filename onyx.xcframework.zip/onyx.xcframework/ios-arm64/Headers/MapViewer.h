#pragma once

#include <memory>
#include <mutex>
#include <string>
#include <queue>

#include <bgfx/bgfx.h>
#include <3rdParty/nlohmann/json.hpp>
#include <Utils/UUID.h>

#include "Camera/CameraController.h"
#include "Pyramid/Culling.h"
#include "Input/UserInputs.h"
#include "DataObjects/WaypointManager.h"
#include "Utils/MapMath.h"
#include "Utils/lowpass.h"
#include "Shaders/ShaderParameters.h"
#include "Viewport/ViewportManager.h"

#if defined(PLATFORM_ANDROID)
#include <android/asset_manager.h>
#endif

#if defined(PLATFORM_EMSCRIPTEN)
#define SINGLE_THREAD 1
#endif

namespace onyx {

class MapViewer
{
public:

	static constexpr float cDefaultDpi = 96.f;
	static float getDpiScalar(float desiredDpi) { return desiredDpi / cDefaultDpi; }

public:

	inline static MapViewer* Instance()
	{
		ONYX_DEBUG_ASSERT(sSingleton != nullptr, "Uninitialized MapViewer instance");
		return sSingleton;
	}

	inline static bool HasInstance() { return sSingleton; }

	static int Initialize(lgal::screen::Vector2 const& resolution, void* window, bgfx::RendererType::Enum rendererType, void* device = NULL, bool enableMSAA = false, float dpiScalar = 1.f);
	static void Shutdown();

public:

	enum class RenderThreadStates
	{
		INITIALIZING,
		RUNNING,
		PAUSED,
		TERMINATED
	};

	typedef std::function<bool(MapViewer *sender, void *tag)> FrameCallbackT;

public:

	template <typename T>
	inline bool INVOKE(T callback)
	{
		if (callback != nullptr) return callback(this, this->mCallbackTag);
		return true;
	}

	void resize(uint32_t width, uint32_t height);
	lmath::Vector<uint32_t, 2> getScreenSize() const;

	void setShowStats(bool b);

	void loadShaders(std::string const& path = "assets/shaders/signatures.txt");

	lgal::world::Vector3 unproject(viewportId_t viewportId, int pixX, int pixY);
	lgal::world::Vector3 unproject(viewportId_t viewportId, lgal::world::Vector2 const& pos);
	lgal::world::Vector2 project(viewportId_t viewportId, lgal::world::Vector2 const& pos);
	lgal::world::Vector2 project(viewportId_t viewportId, lgal::world::Vector3 const& pos);

	WaypointManager::sharedWaypoint_t addWaypoint(std::string uuidStr, lgal::world::Vector3 const& worldPos, lucid::gal::Color const& color);
	WaypointManager::sharedWaypoint_t addWaypoint(Utils::UUID const& id, lgal::world::Vector3 const & worldPos, lucid::gal::Color const& color);
	void moveWaypointTo(viewportId_t viewportId, std::string uuidStr, int pixX, int pixY);
	void moveWaypointTo(std::string uuidStr, lgal::world::Vector3 const& pos);
	void moveWaypointTo(Utils::UUID const& uuid, lgal::world::Vector3 const& pos);
	void deleteWaypoint(Utils::UUID const& uuid);
	void deleteWaypoint(std::string uuidStr);
	void generateRandomWaypoints(int count);		// TODO delete later, just for generating lots of test waypoints

	template <class T>
	void setViewportContext(viewportId_t viewportId, std::string const& key, T const& value)
	{
		auto vp = mViewportManager[viewportId];
		ONYX_ASSERT(vp != nullptr, "No '" + std::to_string(viewportId) + "' viewport found");

		vp->setContext(key, value);
	}

	template <class T>
	T getViewportContext(viewportId_t viewportId, std::string const& key) const
	{
		auto vp = mViewportManager[viewportId];
		ONYX_ASSERT(vp != nullptr, "No '" + std::to_string(viewportId) + "' viewport found");

		return vp->getContext<T>(key);
	}

	double tileLoadTimeMS(viewportId_t viewportId) const;
	std::vector<Tiles::TileId> recentTiles(double windowMS) const;

	inline double lastFrameTimeMS() const { return mFrameTimeHistorySeconds.last() * 1000.0; }
	inline double avgFrameTimeMS() const { return mFrameTimeHistorySeconds.avg() * 1000.0; }

	float elevationAt(lgal::world::Vector2 const& pos) const;

	void addLabel(lgal::world::Vector3 const & pos, std::string text);

	nlohmann::json getDebugState(viewportId_t viewportId, bool includeTiles = true, bool includeAtlas = true, bool includeWaypoints = true, bool includeShaders = true);

#ifdef PLATFORM_ANDROID
	static void SetAssetManager(AAssetManager* assetMan) { core::FileSystem::setAssetManager(assetMan); }
#endif

	void setController(viewportId_t viewportId, std::shared_ptr<Camera::CameraController> controller);
	template<class Controller, class... Args>
	void constructController(viewportId_t viewportId, Args&&... args)
	{
		std::shared_ptr<Camera::CameraController> controller = std::make_shared<Controller>(args...);
		setController(viewportId, controller);
	}

	std::shared_ptr<Input::UserInputs> getInput() const { return mInput; }

	double getInputSensitivity() const;
	void setInputSensitivity(double value) const;

	Camera::CameraState getCameraState(float x, float y) const;
	Camera::CameraState getCameraState(viewportId_t viewportId) const;
	Pyramid::CullResult const& getCullResult(viewportId_t viewportId) const;

	inline bool getShowDebugInfo() const { return mShowDebugInfo; }
	inline void toggleDebugInfo() { mShowDebugInfo = !mShowDebugInfo; }
	inline void toggleDebugInfo(bool on) { mShowDebugInfo = on; }

	GET_SET_VALUE(FrameStartCallback, FrameCallbackT, nullptr);
	GET_SET_VALUE(FrameEndCallback, FrameCallbackT, nullptr);
	GET_SET_VALUE(RenderDebugUICallback, FrameCallbackT, nullptr);
	GET_SET_VALUE(InitDebugUICallback, FrameCallbackT, nullptr);
	GET_SET_VALUE(ShutdownDebugUICallback, FrameCallbackT, nullptr);
	GET_SET_VALUE(CallbackTag, void*, nullptr);
	GET_SET_VALUE(ShowDebugUI, bool, true);
	GET_PROP(RenderThreadState, RenderThreadStates, RenderThreadStates::INITIALIZING);

	void setWindowResolution(lgal::screen::Vector2 const& res);
	lgal::screen::Vector2 getWindowResolution() const { return mWindowResolution; }

	void startRenderThread();
	void killRenderThread();
	bool isRenderThreadInitialized() const { return mRenderThread != nullptr; }

	void setScreenLogo(int viewportId, int logoId, lgal::screen::Vector2 position);

private:

	typedef std::function<void()> ThreadSafeTaskT;

	ViewportManager mViewportManager;

	bool mShowStats = false;
	bool mShowProfiling = false;
	bool mShowDebugInfo = false;
	bool mBgfxInitialized = false;
	bool mLogDispatches = false;

	bool mIsRenderThreadRunning = false;
	void* mWindow;
	void* mDevice = nullptr;
	bgfx::Init mBgfxInit;

	bgfx::RendererType::Enum mRendererType;

	onyx::core::Threading::thread_id_t mRenderThreadId = 0;
	std::unique_ptr<std::thread> mRenderThread;
	std::queue<ThreadSafeTaskT> mPreRenderTasks;
	std::mutex mRenderMtx;

	bool mResolutionChanged = true;
	lgal::screen::Vector2 mWindowResolution = { 0, 0 };
	float mDpiScalar = 1.f;
	uint16_t writeDebugInfo(uint16_t x, uint16_t y);
	uint16_t writeProfiling(uint16_t x, uint16_t y, const lucid::core::Profiler::Sample* sample, bool log = false);
	std::shared_ptr<Input::UserInputs> mInput = std::make_shared<Input::UserInputs>();

	double mPrevTimeMS = 0;
	bool mInitialized = false;

	LowpassFilter<double, 16> mFrameTimeHistorySeconds;

	static MapViewer* sSingleton;

	MapViewer();
	~MapViewer();

	int initialize(lgal::screen::Vector2 const& resolution, void* window, bgfx::RendererType::Enum rendererType, void* device, bool enableMSAA, float dpiScalar);
	int startup();
	
	void render();
	void finishFrame(); //moved separate from render so we can insert bgfx 3d calls on the native layer if need be

	static int sCurrentFrame;
	static int32_t RenderThreadFunc(MapViewer* self);

	void shutdownInner();

	int mScreenLogoId = -1; //temporary tracking to know which symbol to remove, this should be improved later on
#if defined(SINGLE_THREAD)
	// Web Assembly builds have to drive the render function on the browser's UI thread so make this visible for
	// web builds
public:
#endif
	bool renderFrame();
// ---------------------------------------------------------------------
// API functions
// ---------------------------------------------------------------------
public:
	// ------ non-const functions --------------------------------------
	ViewportManager& getViewportManager() { return mViewportManager; }

	void setStyle(viewportId_t viewportId, std::shared_ptr<Styling::Style> style);
	void setStyle(viewportId_t viewportId, std::string const& style);
	void addSource(viewportId_t viewportId, std::string const& id, std::string const& source);
	void removeSource(viewportId_t viewportId, std::string const& id);
	void addLayer(viewportId_t viewportId, std::string const& layer);
	void addLayer(viewportId_t viewportId, std::string const& layer, std::string const& beforeId);
	void removeLayer(viewportId_t viewportId, std::string const& id);
	void setFeatureState(viewportId_t viewportId, Styling::Feature const& feature, std::string const& key, Styling::Value const& value);
	void toggleLayer(viewportId_t viewportId, std::string const& id, std::string const& visibility);
	void toggleLayerGroup(viewportId_t viewportId, std::string const& group, std::string const& visibility);

	void setMaxConcurrentTileRequests(size_t maximum);

	void toggleCulling(viewportId_t viewportId, bool on);

	void setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*> const& params, Shaders::ValueBag const& configuration);

	void setTileLod(viewportId_t viewportId, float lod);

	void setCameraState(viewportId_t viewportId, Camera::CameraState const& state);

	// ------ const functions ------------------------------------------
	std::vector<ShaderParam*> getAllShaderParameters() const;
	std::vector<ShaderParam*> getActiveShaderParameters(ShaderEnums::ConfigurableShaders shader) const;

	Viewport* getViewport(viewportId_t const id = ViewportManager::sMainViewportId) const { return mViewportManager[id]; }

	lgal::world::Vector3 getViewportPosition(float x, float y) const;
	lgal::world::Vector3 getViewportPosition(viewportId_t viewportId) const;

	lgal::world::Vector2 getViewportSize(float x, float y);
	lgal::world::Vector2 getViewportSize(viewportId_t viewportId);

};

}
