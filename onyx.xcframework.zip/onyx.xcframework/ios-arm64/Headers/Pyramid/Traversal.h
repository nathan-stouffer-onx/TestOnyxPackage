#pragma once

#include <stack>

#include <lucid/gal/Types.h>

#include "Tiles/TileId.h"
#include "Utils/MapMath.h"

namespace onyx::Pyramid
{

	template<class T>
	class Traversal
	{

		std::stack<T> mStack;

	public:

		Traversal() = default;
		~Traversal() = default;

		inline bool empty() const
		{
			return mStack.empty();
		}

		inline void push(T const& item)
		{
			mStack.push(item);
		}

		// push the children onto the stack such that the tiles will be processed in front-to-back order
		//
		//    nw = northwest child
		//    ne = northeast child
		//    sw = southwest child
		//    se = southeast child
		void push(lgal::world::Vector2 const& eye, Tiles::TileId const& parent, T const& nw, T const& ne, T const& sw, T const& se)
		{
			// this stack array represents the four children of the parent
			//    [0][0] = northwest child
			//    [0][1] = northeast child
			//    [1][0] = southwest child
			//    [1][1] = southeast child
			//
			// push these onto the processing stack such that the tiles will be processed in front-to-back order
			T const children[2][2] = { { nw, ne }, { sw, se } };

			// compute the center of the parent tile, this will help determine the order in which to process the children
			auto center = parent.center();

			// booleans indicating which of the children will be occluded
			bool northOccludesSouth = (eye.y <= center.y);
			bool westOccludesEast   = (eye.x <= center.x);

			// compute the index of the child that is behind the other three children. this 
			// child cannot block any of the other children. we will reference this child as 
			// the "non-occluding" tile in subsequent comments. we want to push this child 
			// on to stack first so that it is processed last
			uint8_t i = (northOccludesSouth) ? 1 : 0;
			uint8_t j = (westOccludesEast)   ? 1 : 0;

			// push the non-occluding child on to the stack first. this child should be processed
			// after all the other children
			mStack.push(children[i][j]);

			// push the two tiles sharing an edge with the non-occluding tile. these tiles will not 
			// occlude each other or the other children. they can be processed in arbitrary order
			// relative to each other
			mStack.push(children[(i + 1) % 2][j]);
			mStack.push(children[i][(j + 1) % 2]);

			// the tile diagonal from the non-occluding child may occlude all three of the other
			// children. this should be pushed on to the stack last so it is processed first
			mStack.push(children[(i + 1) % 2][(j + 1) % 2]);
		}

		inline T& top()
		{
			return mStack.top();
		}

		inline void pop()
		{
			mStack.pop();
		}

	};

}