#include "Tiler.h"

#include "Utils/MapMath.h"
#include "Utils/Timer.h"
#include "Vector/FeatureFactory.h"

namespace onyx {
namespace Pyramid {

	Tiler::Tiler(Styling::GeojsonSource const& source) :
		mRoot(Styling::GeojsonSource::cLayerName, Tiler::Features(source), Utils::Timer::nowMS())
	{}

	std::shared_ptr<Tiles::VectorTile const> Tiler::generate(Tiles::TileId const& tile) const
	{
		lgal::tile::AABB2d box = Tiles::TileId::InternalBounds({ 0, 0, 0 }, tile);
		return std::make_shared<Tiles::VectorTile>(tile, mRoot.subLayer(box));
	}

	Vector::FeatureCollectionT Tiler::Features(Styling::GeojsonSource const& source)
	{
		Vector::FeatureCollectionT features;

		std::string idKey = source.promoteId.key(Styling::GeojsonSource::cLayerName);

		GeoJson::GeoJson const& data = *source.data;
		if (data.type == GeoJson::GeoJson::Types::Feature)
		{
			features.push_back(Vector::Factory::feature(static_cast<GeoJson::Feature const&>(data), idKey));
		}
		else
		{
			GeoJson::FeatureCollection const& collection = static_cast<GeoJson::FeatureCollection const&>(data);
			for (std::shared_ptr<GeoJson::Feature const> feature : collection.features)
			{
				features.push_back(Vector::Factory::feature(*feature, idKey));
			}
		}

		return features;
	}

}
}