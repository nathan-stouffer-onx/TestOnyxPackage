#include "UVOffset.h"

namespace onyx {
namespace Pyramid {
namespace UVOffset {

	lgal::gpu::Vector4 toLowerDetail(Tiles::TileId lowerDetail, Tiles::TileId higherDetail)
	{
		if (lowerDetail.level == higherDetail.level)
			return { 0, 0, 1, 1 };

		auto levelOffset = higherDetail.level - lowerDetail.level;
		auto factor = 1 << levelOffset;

		auto mask = ~(0xFFFFFFFF << levelOffset);
		auto higherX = higherDetail.x & mask;
		auto higherY = higherDetail.y & mask;

		auto scale = gpu_float_t(1) / gpu_float_t(factor);

		return { higherX * scale, higherY * scale, scale, scale };
	}

	lgal::gpu::Vector4 toHigherDetail(Tiles::TileId lowerDetail, Tiles::TileId higherDetail)
	{
		// TODO possibly optimize this by computing directly instead of as the inverse of lowerDetail
		lgal::gpu::Vector4 inverse = toLowerDetail(lowerDetail, higherDetail);
		return { -inverse.x / inverse.z, -inverse.y / inverse.w, 1.0f / inverse.z, 1.0f / inverse.w };
	}

	lgal::gpu::Vector4 compose(lgal::gpu::Vector4 first, lgal::gpu::Vector4 second)
	{
		auto x = second.x + (first.x * second.z);
		auto y = second.y + (first.y * second.w);
		auto z = second.z * first.z;
		auto w = second.w * first.w;
		return { x, y, z, w };
	}

} } }