#pragma once

#include <algorithm>

#include <lucid/gal/Types.h>

#include "Atlases/HeightAtlas.h"
#include "Tiles/TileId.h"
#include "Utils/MapMath.h"
#include "Camera/CameraState.h"

namespace onyx::Pyramid
{

	/*
	* This file defines a couple culling and subdivision algorithms that are the heart of deciding what tiles are put
	* on the screen. Each algorithm is a variation on the following approach:
	*
	*	1. add the root tile to a set of possible tiles
	*	2. while stack is not empty
	*		- pop the top tile
	*		- if tile should be culled, jump to step 2
	*		- if tile should be subdivided, add children to possible tiles. otherwise, add tile to rendering list
	*
	* The algorithms vary by their criteria for culling and subdivision
	* 
	* Additionally, each algorithm processes the tiles in such a way that the resulting vector CullState::tileIds is sorted
	* in increasing distance from the eye
	*/

	struct CullResult
	{
		uint32_t minLevel = 0xFFFFFFFF;
		uint32_t maxLevel = 0x00000000;
		world_float_t avgLevel = 0.0;

		// tileIds should be ordered as the reverse of the painters algorithm relative to the eye passed in for culling
		std::vector<Tiles::TileId> tileIds;

		lgal::world::AABB2d bounds = lgal::world::AABB2d::nothing();

		void add(Tiles::TileId const& tile)
		{
			tileIds.push_back(tile);
			minLevel = std::min(minLevel, (uint32_t)tile.level);
			maxLevel = std::max(maxLevel, (uint32_t)tile.level);
			avgLevel += world_float_t(tile.level);
			bounds = lmath::fit(bounds, tile.worldBounds<world_float_t>());
		}

		void root()
		{
			tileIds.clear();
			tileIds.push_back({ 0, 0, 0 });
			bounds = Tiles::TileId{ 0, 0, 0 }.worldBounds<world_float_t>();
			minLevel = 0;
			maxLevel = 0;
			avgLevel = 0.0;
		}

		void reset()
		{
			minLevel = 0xFFFFFFFF;
			maxLevel = 0x00000000;
			avgLevel = 0.0;
			bounds = lgal::world::AABB2d::nothing();
			tileIds.clear();
			tileIds.reserve(50);
		}

	};

	/**
	 * @brief Cull via computing a minimum number of tiles to put on screen and subdivide the highest priority tile until the minimum is reached
	 * @param [in] camera The CameraState used as input for culling
	 * @param [in] lod A scalar to increase the level of detail
	 * @param [in] maxZoom The maximum zoom level to which the algorithm subdivides
	 * @param [in] atlas The TerrainAtlas used to compute z values (set as nullptr to signal that there is no terrain)
	 * @param [in] exaggeration The exaggeration to apply to z
	 */
	CullResult cull(Camera::CameraState const& camera, float lod, Tiles::TileId::IdCoordsT maxZoom, Atlases::HeightAtlas const* atlas = nullptr, float exaggeration = 1.f);
	
	/**
	 * @brief Compute whether or not a particular tile needs another subdivision
	 * @param [in] eye The position of the camera
	 * @param [in] aabb The bounding box of the tile in question
	 * @param [in] projectedTileLength The approximate length of the tile when projected to be distance 1 from the camera
	 * @param [in] lod A scalar to increase the level of detail
	 * @param [in] focus A distance at which detail is reduced further to prioritize performance (set as nullptr to signal that there is no focus distance)
	 */
	bool subdivides(lgal::world::Vector3 const& eye, lgal::world::AABB3d const& aabb, world_float_t projectedTileLength, float lod, float const* focus);

	/**
	 * @brief Cull via computing a maximum screen size for a tile and subdividing until the projected tile takes up less space than the maximum
	 * @param [in] camera The CameraState used as input for culling
	 * @param [in] lod A scalar to increase the level of detail
	 * @param [in] maxZoom The maximum zoom level to which the algorithm subdivides
	 * @param [in] focus A distance at which detail is reduced further to prioritize performance (set as nullptr to signal that there is no focus distance)
	 * @param [in] atlas The TerrainAtlas used to compute z values (set as nullptr to signal that there is no terrain)
	 * @param [in] exaggeration The exaggeration to apply to z
	 */
	CullResult cull(Camera::CameraState const& camera, float lod, Tiles::TileId::IdCoordsT maxZoom, float const* focus, Atlases::HeightAtlas const* atlas = nullptr, float exaggeration = 1.f);
	
	bool subdivides(lgal::world::Vector2 const& eye, Tiles::TileId const& tileId, world_float_t searchScalar);
	CullResult cull(lgal::world::Vector2 const& center, world_float_t radius, world_float_t searchScalar, Tiles::TileId::IdCoordsT maxZoom);

	void sort(std::vector<Tiles::TileId>& tiles, lgal::world::Vector2 const& center);
	inline std::vector<Tiles::TileId> sorted(std::vector<Tiles::TileId> const& tiles, lgal::world::Vector2 const& center)
	{
		std::vector<Tiles::TileId> copy = tiles;
		sort(copy, center);
		return copy;
	}

}