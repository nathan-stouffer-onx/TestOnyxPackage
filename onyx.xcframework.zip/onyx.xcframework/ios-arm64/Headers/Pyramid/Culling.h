#ifndef __PRYAMID_CULLING_H__
#define __PRYAMID_CULLING_H__

#include <algorithm>

#include <lucid/gal/Types.h>

#include "Atlases/HeightAtlas.h"
#include "Tiles/TileId.h"
#include "Utils/MapMath.h"
#include "Camera/CameraState.h"

namespace onyx {
namespace Pyramid {

	/*
	* This file defines a couple culling and subdivision algorithms that are the heart of deciding what tiles are put
	* on the screen. Each algorithm is a variation on the following approach:
	*
	*	1. add the root tile to a stack
	*	2. while stack is not empty
	*		- pop the top tile
	*		- if tile should be culled, jump to step 2
	*		- if tile should be subdivided, add children to stack. otherwise, add tile to rendering list
	*
	* The algorithms vary by their criteria for culling and subdivision. The comments above each pair of cull/shouldSubdivide
	* functions give a loose description of that function's criteria.
	* 
	* Additionally, each algorithm processes the tiles in such a way that the resulting vector CullState::tileIds is sorted
	* front-to-back relative to the eye position used for culling.
	*/

	struct CullResult
	{
		uint32_t touched = 0;
		uint32_t culledCount = 0;
		uint32_t minLevel = 0xFFFFFFFF;
		uint32_t maxLevel = 0x00000000;
		world_float_t avgLevel = 0.0;

		// tileIds should be ordered as the reverse of the painters algorithm relative to the eye passed in for culling
		std::vector<Tiles::TileId> tileIds;

		lgal::world::AABB2d bounds = lgal::world::AABB2d::nothing();

		void add(Tiles::TileId const& tile)
		{
			tileIds.push_back(tile);
			minLevel = std::min(minLevel, (uint32_t)tile.level);
			maxLevel = std::max(maxLevel, (uint32_t)tile.level);
			avgLevel += world_float_t(tile.level);
			bounds = lmath::fit(bounds, tile.worldBounds<world_float_t>());
		}

		void root()
		{
			tileIds.clear();
			tileIds.push_back({ 0, 0, 0 });
			bounds = Tiles::TileId{ 0, 0, 0 }.worldBounds<world_float_t>();
			minLevel = 0;
			maxLevel = 0;
			avgLevel = 0.0;
		}

		void reset()
		{
			touched = 0;
			culledCount = 0;
			minLevel = 0xFFFFFFFF;
			maxLevel = 0x00000000;
			avgLevel = 0.0;
			bounds = lgal::world::AABB2d::nothing();
			tileIds.clear();
			tileIds.reserve(50);
		}

	};

	// distance-based subdivision in three dimensions. incorporates tile extent to auto-scale for zoom level
	bool shouldSubdivide(lgal::world::Vector3 const& eye, lgal::world::Vector3 const& tileMin, lgal::world::Vector3 const& tileSize, float thresholdScalar, world_float_t metricScalar);
	// culls by testing if a tile's 3D bounding box intersects the camera frustum
	void cull(CullResult& result, Camera::CameraState const& camera, float thresholdScalar, Tiles::TileId::IdCoordsT maxZoom, Atlases::HeightAtlas const* atlas = nullptr, float exaggeration = 1.0f);
	inline CullResult cull(Camera::CameraState const& camera, float lodScaler, Tiles::TileId::IdCoordsT maxZoom, Atlases::HeightAtlas const* atlas = nullptr, float exaggeration = 1.0f)
	{
		CullResult result;
		cull(result, camera, lodScaler, maxZoom, atlas, exaggeration);
		return result;
	}
	
	// distance-based (with the manhattan metric) subdivision in two dimensions. incorporates tile extent to auto-scale for zoom level
	bool shouldSubdivide(lgal::world::Vector2 const& eye, Tiles::TileId const& tileId, world_float_t searchScalar);
	// culls by testing if a tile's 2D bounding box intersects the circle defined by (center, radius)
	void cull(CullResult& result, lgal::world::Vector2 const& center, world_float_t radius, world_float_t searchScalar, Tiles::TileId::IdCoordsT maxZoom);
	inline CullResult cull(lgal::world::Vector2 const& center, world_float_t radius, world_float_t searchScalar, Tiles::TileId::IdCoordsT maxZoom)
	{
		CullResult result;
		cull(result, center, radius, searchScalar, maxZoom);
		return result;
	}

} }

#endif