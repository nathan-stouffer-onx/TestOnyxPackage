#ifndef __TILE_PYRAMID_H__
#define __TILE_PYRAMID_H__

#include <unordered_map>
#include <memory>

#include "Tiles/TileId.h"

namespace onyx {
namespace Pyramid {

	/*
	* A class to store a pyramid of tiles. An owning class can insert, erase, and search for tiles. A specific tile can be searched for
	* by using TilePyramid::find which will look only for the requested tile. Or the pyramid's best approximation of the requested tile
	* can be searched for using TilePyramid::findHighestDetail which will search for the requested tile but fallback to a lower detail 
	* tile if the pyramid has it.
	*/
	
	template<typename T>
	class TilePyramid
	{
	public:

		using EntryT = std::shared_ptr<T const>;

		using const_iterator = typename std::unordered_map<Tiles::TileId, EntryT>::const_iterator;

		TilePyramid(Tiles::TileId::IdCoordsT maxLevel) : mMaxLevel(maxLevel) {}
		~TilePyramid() {}

		inline void insert(EntryT const& item)
		{
			mTiles.insert({ item->id(), item });
		}

		inline bool contains(Tiles::TileId const& tileId) const
		{
			return mTiles.find(tileId) != mTiles.end();
		}
		
		inline void erase(Tiles::TileId const& tileId)
		{
			mTiles.erase(tileId);
		}

		inline EntryT const& at(Tiles::TileId const& tileId) const
		{
			return mTiles.at(tileId);
		}

		inline EntryT const& at(Tiles::TileId const& tileId)
		{
			return mTiles.at(tileId);
		}

		// searches the pyramid for the requested tile. when recurse is true, will fallback to low detail tiles
		// returns nullptr if the pyramid does not have the requested data
		const_iterator find(Tiles::TileId const& tileId, bool recurse) const
		{
			if (recurse)
			{
				Tiles::TileId query = (tileId.level <= mMaxLevel) ? tileId : tileId.parentAtLevel(mMaxLevel);
				const_iterator found = mTiles.find(query);

				// search the pyramid starting at the first parent (only runs until we have found something)
				for (int i = query.level - 1; found == mTiles.end() && i >= 0; --i)
				{
					Tiles::TileId ancestor = query.parentAtLevel(i);
					found = mTiles.find(ancestor);
				}
				return found;
			}
			else
			{
				return mTiles.find(tileId);
			}
		}

		inline const_iterator begin() const { return mTiles.begin(); }
		inline const_iterator end() const { return mTiles.end(); }

	private:

		std::unordered_map<Tiles::TileId, EntryT> mTiles;
		Tiles::TileId::IdCoordsT mMaxLevel;

	};

} }

#endif