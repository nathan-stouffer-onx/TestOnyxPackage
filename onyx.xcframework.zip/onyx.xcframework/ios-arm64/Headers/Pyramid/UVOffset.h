#ifndef __UV_OFFSET_H__
#define __UV_OFFSET_H__

#include <lucid/gal/Types.h>

#include "Tiles/TileId.h"

namespace onyx {
namespace Pyramid {
namespace UVOffset {

	lgal::gpu::Vector4 toLowerDetail(Tiles::TileId lowerDetail, Tiles::TileId higherDetail);
	lgal::gpu::Vector4 toHigherDetail(Tiles::TileId lowerDetail, Tiles::TileId higherDetail);

	// NOTE: not commutative
	lgal::gpu::Vector4 compose(lgal::gpu::Vector4 first, lgal::gpu::Vector4 second);

} } }

#endif