#include "Culling.h"

#include <stack>

#include <lucid/math/Sphere.h>

#include "Camera/Frustum.h"
#include "Pyramid/Traversal.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace Pyramid {

	struct CullState
	{
		Tiles::TileId tileId;
		lgal::world::Vector3 min;
		lgal::world::Vector3 size;
		bool inside;
	};

	// given two points p and q in 3-space, we define the metric:
	//     f(p, q) = d(p, q) + k * d(p.xy, q.xy)
	// where d is regular euclidean distance 
	static world_float_t LevelOfDetailDistanceMetric(lgal::world::Vector3 const& p, lgal::world::Vector3 const& q, world_float_t const k)
	{
		return lmath::len(q - p) + k * lmath::len(q.xy - p.xy);
	}

	bool shouldSubdivide(lgal::world::Vector3 const& eye, lgal::world::Vector3 const& tileMin, lgal::world::Vector3 const& tileSize, float thresholdScalar, world_float_t metricScalar)
	{
		auto maxDist = tileSize.x * thresholdScalar;

		auto minX = tileMin.x;
		auto minY = tileMin.y;

		auto maxX = tileMin.x + tileSize.x;
		auto maxY = tileMin.y + tileSize.y;
		
		auto z = std::min(eye.z, tileMin.z + tileSize.z);

		// check if any corner of the top of the bounding box is close enough to subdivide
		if (LevelOfDetailDistanceMetric(eye, lgal::world::Vector3(minX, minY, z), metricScalar) < maxDist || 
			LevelOfDetailDistanceMetric(eye, lgal::world::Vector3(minX, maxY, z), metricScalar) < maxDist || 
			LevelOfDetailDistanceMetric(eye, lgal::world::Vector3(maxX, minY, z), metricScalar) < maxDist || 
			LevelOfDetailDistanceMetric(eye, lgal::world::Vector3(maxX, maxY, z), metricScalar) < maxDist)
		{
			return true;
		}

		// no corner is close enough to subdivide, return false
		return false;
	}

	void cull(CullResult& result, Camera::CameraState const& camera, float thresholdScalar, Tiles::TileId::IdCoordsT maxZoom, Atlases::HeightAtlas const* atlas, float exaggeration)
	{
		world_float_t metricScalar = std::clamp(std::abs(camera.pitch / (lmath::constants::half_pi<world_float_t>())), 0.0, 1.0);

		Camera::Frustum frustum{ camera };
		
		// three root tiles. we assume the eye will always be in bounds of the middle root tile 
		Tiles::TileId left  = { 0, -1, 0 };
		Tiles::TileId mid   = { 0,  0, 0 };
		Tiles::TileId right = { 0,  1, 0 };

		lgal::world::Vector3 size{ Tiles::cMaxExtent, Tiles::cMaxExtent, (atlas) ? MapMath::cMaxHeight : 0.0 };

		// the left and right tiles will not occlude each other and must be further from the eye than the 
		// middle tile. so push the middle root on last so it is processed first
		Traversal<CullState> traversal;
		traversal.push(CullState{ left,  { left.northwestCorner(),  0.0 }, size, false });
		traversal.push(CullState{ right, { right.northwestCorner(), 0.0 }, size, false });
		traversal.push(CullState{ mid,   { mid.northwestCorner(),   0.0 }, size, false });

		// process the traversal until it is empty
		while (!traversal.empty())
		{
			++result.touched;
			CullState cullState = traversal.top();
			traversal.pop();

			// compute the modulo of the x coord of the TileId for all queries
			auto moduloId = cullState.tileId.moduloX();

			// update the height data if we have the available information
			// otherwise, we just use the existing (lower detail) data from the previous iteration
			if (atlas && atlas->contains(moduloId))
			{
				auto heightExtents = atlas->heightExtents(moduloId) * exaggeration;

				cullState.min.z = world_float_t(heightExtents.begin);
				cullState.size.z = world_float_t(heightExtents.end) - world_float_t(heightExtents.begin);
			}

			// once a tile is entirely inside the frustum, all of its children will be as well,
			// in that case, we can skip this step entirely
			if (!cullState.inside)
			{
				auto intersection = frustum.intersects({ cullState.min, cullState.min + cullState.size });
				if (intersection == Camera::Frustum::Intersection::OUTSIDE)
				{
					++result.culledCount;
					continue;
				}
				cullState.inside = (intersection == Camera::Frustum::Intersection::INSIDE);
			}

			if (shouldSubdivide(camera.position, cullState.min, cullState.size, thresholdScalar, metricScalar) && cullState.tileId.level < maxZoom)
			{
				// grab parent TileId and compute size of children tiles (height is left alone. if necessary, it will be updated when the CullState is popped)
				Tiles::TileId& parent = cullState.tileId;
				size = { 0.5 * cullState.size.xy, cullState.size.z };

				// compute each child TileId
				Tiles::TileId nwTile = parent.northwestChild();
				Tiles::TileId neTile = parent.northeastChild();
				Tiles::TileId swTile = parent.southwestChild();
				Tiles::TileId seTile = parent.southeastChild();

				// compute CullState for each child
				CullState nw = { nwTile, lgal::world::Vector3(nwTile.northwestCorner(), cullState.min.z), size, cullState.inside };
				CullState ne = { neTile, lgal::world::Vector3(neTile.northwestCorner(), cullState.min.z), size, cullState.inside };
				CullState sw = { swTile, lgal::world::Vector3(swTile.northwestCorner(), cullState.min.z), size, cullState.inside };
				CullState se = { seTile, lgal::world::Vector3(seTile.northwestCorner(), cullState.min.z), size, cullState.inside };

				traversal.push(camera.position.xy, parent, nw, ne, sw, se);
			}
			else	// otherwise, add this to the list of tiles to draw
			{
				result.add(cullState.tileId);
			}
		}

		// if the above process didn't want to draw anything, just draw the root tile
		if (result.tileIds.size() == 0)
		{
			// sets result to just the root tile
			result.root();
		}
		else
		{
			result.avgLevel /= world_float_t(result.tileIds.size());
		}
	}

	bool shouldSubdivide(lgal::world::Vector2 const& eye, Tiles::TileId const& tileId, world_float_t searchScalar)
	{
		auto center = tileId.center();
		auto halfLength = searchScalar * 0.5 * tileId.extent();						// half the side length of the search box
		auto halfDiagonal = lgal::world::Vector2{ halfLength, halfLength };			// half the diagonal of the search box
		lgal::world::AABB2d searchBox = { center - halfDiagonal, center + halfDiagonal };

		return searchBox.contains(eye);
	}

	void cull(CullResult& result, lgal::world::Vector2 const& center, world_float_t radius, world_float_t searchScalar, Tiles::TileId::IdCoordsT maxZoom)
	{
		lgal::world::Circle circle = { center, radius };

		Traversal<Tiles::TileId> traversal;
		traversal.push({ 0, 0, 0 });

		// process the queue until it is empty
		while (!traversal.empty())
		{
			++result.touched;
			Tiles::TileId tileId = traversal.top();
			traversal.pop();

			lgal::world::AABB2d tileBounds = tileId.worldBounds<world_float_t>();
			// check if the tile is outside the circle
			if (!lmath::intersects(circle, tileBounds))
			{
				++result.culledCount;
				continue;
			}

			if (shouldSubdivide(center, tileId, searchScalar) && tileId.level < maxZoom)
			{
				traversal.push(center, tileId, tileId.northwestChild(), tileId.northeastChild(), tileId.southwestChild(), tileId.southeastChild());
			}
			else	// otherwise, add this to the list of tiles to draw
			{
				result.add(tileId);
			}
		}

		// if the above process didn't want to draw anything, just draw the root tile
		if (result.tileIds.size() == 0)
		{
			// sets result to just the root tile
			result.root();
		}
		else
		{
			result.avgLevel /= world_float_t(result.tileIds.size());
		}
	}

} }