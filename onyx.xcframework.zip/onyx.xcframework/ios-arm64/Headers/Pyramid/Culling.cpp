#include "Culling.h"

#include <queue>

#include <lucid/math/Sphere.h>

#include "Camera/Frustum.h"
#include "Pyramid/Traversal.h"
#include "Utils/MapMath.h"

namespace onyx::Pyramid
{

	struct CullState
	{
		Tiles::TileId tileId;
		lgal::world::AABB3d aabb;
		bool inside;				// if we know the aabb to be inside the frustum
	};

	struct PriorityState
	{
		world_float_t priority;
		CullState state;
		inline bool operator<(PriorityState const& rhs) const { return priority < rhs.priority; }
	};

	static void PushIfIntersects(std::priority_queue<PriorityState>& heap, CullState state, Camera::Frustum const& frustum, lgal::world::Vector3 const& eye, world_float_t pitchStrength)
	{
		auto intersection = (state.inside) ? Camera::Frustum::Intersection::INSIDE : frustum.intersects(state.aabb);
		if (intersection != Camera::Frustum::Intersection::OUTSIDE)
		{
			world_float_t priority = state.aabb.extent().x - pitchStrength * state.aabb.distanceTo(eye);
			state.inside = intersection == Camera::Frustum::Intersection::INSIDE;
			heap.push({ priority, state });
		}
	}

	CullResult cull(Camera::CameraState const& camera, float lod, Tiles::TileId::IdCoordsT maxZoom, Atlases::HeightAtlas const* atlas, float exaggeration)
	{
		world_float_t pitchStrength = camera.pitchStrength();
		float pitchScalar = lmath::lerp(1.f, 2.f, static_cast<float>(pitchStrength * pitchStrength));
		
		lmath::Vector<float, 2> scaled = (1.f / 256.f) * camera.resolution.as<float>();
		size_t minimum = static_cast<size_t>(lod * pitchScalar * std::ceil(scaled.x) * std::ceil(scaled.y));

		Camera::Frustum frustum{ camera };
		
		pitchStrength = std::max(0.001, pitchStrength);	// place a minimum on pitch strength so that tiles are still sorted by distance when pitch is 0

		std::priority_queue<PriorityState> heap;
		CullResult result;

		{
			world_float_t minZ = (atlas) ? MapMath::cMinElevation : 0.0;
			world_float_t maxZ = (atlas) ? MapMath::cMaxElevation : 0.0;
			int adjacent = 2;
			for (int i = -adjacent; i <= adjacent; ++i)
			{
				Tiles::TileId tile = { 0, i, 0 };
				CullState state{ tile, lgal::world::AABB3d({ tile.northwestCorner(), minZ }, { tile.southeastCorner(), maxZ }), false };
				PushIfIntersects(heap, state, frustum, camera.position, pitchStrength);
			}
		}

		while (!heap.empty() && heap.size() + result.tileIds.size() <= minimum)	// process tiles until we have reached the minimum number to display
		{
			CullState parentState = heap.top().state;
			heap.pop();

			if (parentState.tileId.level == maxZoom)
			{
				result.add(parentState.tileId);
			}
			else
			{
				for (Tiles::TileId const& child : parentState.tileId.children())
				{
					lgal::world::Vector3 min(child.northwestCorner(), parentState.aabb.min.z);
					lgal::world::Vector3 max(child.southeastCorner(), parentState.aabb.max.z);

					if (atlas)
					{
						auto extents = atlas->extents(child.moduloX(), true) * exaggeration;
						min.z = world_float_t(extents.begin);
						max.z = world_float_t(extents.end);
					}

					CullState state{ child, lgal::world::AABB3d(min, max), parentState.inside };
					PushIfIntersects(heap, state, frustum, camera.position, pitchStrength);
				}
			}
		}

		while (!heap.empty())
		{
			result.add(heap.top().state.tileId);
			heap.pop();
		}

		// if the above process didn't want to draw anything, just draw the root tile. othwerise, compute the average zoom level
		if (result.tileIds.empty()) { result.root(); }
		else { result.avgLevel /= static_cast<world_float_t>(result.tileIds.size()); }

		// sort in increasing distance from camera
		// TODO [CSONYX-264] for complete rendering correctness, this should actually be sorted front-to-back
		sort(result.tileIds, camera.position.xy);

		return result;
	}

	bool subdivides(lgal::world::Vector3 const& eye, lgal::world::AABB3d const& aabb, world_float_t projectedTileLength, float lod, float const* focus)
	{
		world_float_t dist = aabb.distanceTo(eye);
		if (focus)	// if we have a focus distance, scale up the distance when beyond the focus
		{
			dist *= std::max(1.0, dist / (1.5f * *focus));	// 1.5x to give us a margin for error
		}	
		return dist * projectedTileLength < lod * aabb.extent().x;
	}

	CullResult cull(Camera::CameraState const& camera, float lod, Tiles::TileId::IdCoordsT maxZoom, float const* focus, Atlases::HeightAtlas const* atlas, float exaggeration)
	{
		world_float_t halfHeight = 0.5 * static_cast<world_float_t>(camera.resolution.y);
		world_float_t pixelSize = std::tan(lmath::degreesToRadians(0.5 * camera.fov)) / halfHeight;	// the pixel size (in world space) at distance 1 from the camera
		world_float_t projectedTileLength = 256.0 * pixelSize;										// the approximate projected size of a tile at distance 1 from the camera

		Camera::Frustum frustum{ camera };
		Traversal<CullState> traversal;

		// push root tiles
		{
			world_float_t minZ = (atlas) ? MapMath::cMinElevation : 0.0;
			world_float_t maxZ = (atlas) ? MapMath::cMaxElevation : 0.0;

			// the left and right tiles will not occlude each other and must be further from the eye than the middle tile
			int adjacent = 2;
			for (int i = adjacent; i > 0; --i)
			{
				Tiles::TileId left  = { 0, -i, 0 };
				Tiles::TileId right = { 0,  i, 0 };
				traversal.push(CullState{ left,  lgal::world::AABB3d({ left.northwestCorner(),  minZ }, { left.southeastCorner(),  maxZ }), false });
				traversal.push(CullState{ right, lgal::world::AABB3d({ right.northwestCorner(), minZ }, { right.southeastCorner(), maxZ }), false });
			}

			// push the middle root on last so it is processed first
			Tiles::TileId mid = { 0, 0, 0 };
			traversal.push(CullState{ mid, lgal::world::AABB3d({ mid.northwestCorner(), minZ }, { mid.southeastCorner(), maxZ }), false });
		}

		CullResult result;

		// process the traversal until it is empty
		while (!traversal.empty())
		{
			CullState state = traversal.top();
			traversal.pop();

			if (atlas)	// update the z extents to the current zoom level
			{
				auto extents = atlas->extents(state.tileId.moduloX(), true) * exaggeration;
				state.aabb.min.z = world_float_t(extents.begin);
				state.aabb.max.z = world_float_t(extents.end);
			}

			// once a tile is entirely inside the frustum, all of its children will be as well. in that case, we don't need to intersect with the frustum
			auto intersection = (state.inside) ? Camera::Frustum::Intersection::INSIDE : frustum.intersects(state.aabb);
			if (intersection != Camera::Frustum::Intersection::OUTSIDE)
			{
				state.inside = intersection == Camera::Frustum::Intersection::INSIDE;
				if (subdivides(camera.position, state.aabb, projectedTileLength, lod, focus) && state.tileId.level < maxZoom)
				{
					// compute each child TileId
					Tiles::TileId const& parent = state.tileId;
					Tiles::TileId nwTile = parent.northwestChild();
					Tiles::TileId neTile = parent.northeastChild();
					Tiles::TileId swTile = parent.southwestChild();
					Tiles::TileId seTile = parent.southeastChild();

					// compute CullState for each child
					CullState nw = { nwTile, lgal::world::AABB3d({ nwTile.northwestCorner(), state.aabb.min.z }, { nwTile.southeastCorner(), state.aabb.max.z }), state.inside };
					CullState ne = { neTile, lgal::world::AABB3d({ neTile.northwestCorner(), state.aabb.min.z }, { neTile.southeastCorner(), state.aabb.max.z }), state.inside };
					CullState sw = { swTile, lgal::world::AABB3d({ swTile.northwestCorner(), state.aabb.min.z }, { swTile.southeastCorner(), state.aabb.max.z }), state.inside };
					CullState se = { seTile, lgal::world::AABB3d({ seTile.northwestCorner(), state.aabb.min.z }, { seTile.southeastCorner(), state.aabb.max.z }), state.inside };

					traversal.push(camera.position.xy, parent, nw, ne, sw, se);
				}
				else	// otherwise, add this to the list of tiles to draw
				{
					result.add(state.tileId);
				}
			}
		}

		// if the above process didn't want to draw anything, just draw the root tile. othwerise, compute the average zoom level
		if (result.tileIds.empty()) { result.root(); }
		else { result.avgLevel /= static_cast<world_float_t>(result.tileIds.size()); }

		return result;
	}

	bool subdivides(lgal::world::Vector2 const& eye, Tiles::TileId const& tileId, world_float_t searchScalar)
	{
		auto center = tileId.center();
		auto halfLength = searchScalar * 0.5 * tileId.extent();						// half the side length of the search box
		auto halfDiagonal = lgal::world::Vector2{ halfLength, halfLength };			// half the diagonal of the search box
		lgal::world::AABB2d searchBox = { center - halfDiagonal, center + halfDiagonal };

		return searchBox.contains(eye);
	}

	CullResult cull(lgal::world::Vector2 const& center, world_float_t radius, world_float_t searchScalar, Tiles::TileId::IdCoordsT maxZoom)
	{
		lgal::world::Circle circle = { center, radius };

		Traversal<Tiles::TileId> traversal;
		traversal.push({ 0, 0, 0 });

		CullResult result;

		// process the queue until it is empty
		while (!traversal.empty())
		{
			Tiles::TileId tileId = traversal.top();
			traversal.pop();

			lgal::world::AABB2d tileBounds = tileId.worldBounds<world_float_t>();
			// check if the tile is outside the circle
			if (lmath::intersects(circle, tileBounds))
			{
				if (subdivides(center, tileId, searchScalar) && tileId.level < maxZoom)
				{
					traversal.push(center, tileId, tileId.northwestChild(), tileId.northeastChild(), tileId.southwestChild(), tileId.southeastChild());
				}
				else	// otherwise, add this to the list of tiles to draw
				{
					result.add(tileId);
				}
			}
		}

		// if the above process didn't want to draw anything, just draw the root tile. othwerise, compute the average zoom level
		if (result.tileIds.empty()) { result.root(); }
		else { result.avgLevel /= static_cast<world_float_t>(result.tileIds.size()); }

		// sort in increasing distance from the center
		sort(result.tileIds, center);

		return result;
	}

	void sort(std::vector<Tiles::TileId>& tiles, lgal::world::Vector2 const& center)
	{
		std::sort(tiles.begin(), tiles.end(),
			[center](Tiles::TileId const& lhs, Tiles::TileId const& rhs) -> bool
			{
				return lhs.worldBounds<world_float_t>().distanceTo(center) < rhs.worldBounds<world_float_t>().distanceTo(center);
			}
		);
	}

}