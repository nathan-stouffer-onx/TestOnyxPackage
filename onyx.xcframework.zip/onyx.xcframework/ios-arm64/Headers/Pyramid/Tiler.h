#ifndef __PYRAMID_TILER_H__
#define __PYRAMID_TILER_H__

#include <Styling/Sources/GeojsonSource.h>

#include "Tiles/TileId.h"
#include "Tiles/VectorTile.h"

namespace onyx {
namespace Pyramid {

	/*
	* A class that takes in a global data source (eg geojson) and can generate VectorTiles.
	* 
	* NOTE: it is important that this class be thread safe; it may be the case that multiple request threads
	* are requesting tiles at the same time.
	*/
	class Tiler final
	{
	public:

		Tiler(Styling::GeojsonSource const& source);

		// TODO expose other tiling parameters here (eg clustering)
		std::shared_ptr<Tiles::VectorTile const> generate(Tiles::TileId const& tile) const;

	private:

		static Vector::FeatureCollectionT Features(Styling::GeojsonSource const& source);

	private:

		// TODO possibly store this in a format better for tiling
		// TODO possibly increase precision?
		Vector::Layer mRoot;

	};

} }

#endif