#include "WKTParser.h"
namespace onyx::WKT {

std::vector<lgal::world::Vector2> parseLinestring(const std::string& wkt)
{
	size_t start = wkt.find("LINESTRING");
	if (start != 0)
	{
		logE("wkt string did not have a LINESTRING as required");
		return {};
	}

	size_t nextPair = wkt.find('(', start) + 1;
	size_t nextPairEnd = wkt.find(',', start);
	if (nextPairEnd == std::string::npos) //if theres no comma its only one pair, so just jump to the end
	{
		nextPairEnd = wkt.length() - 1;
	}

	bool hasMore = true;
	std::vector<lgal::world::Vector2> points;
	while (hasMore)
	{
		if (wkt.size() - 1 <= nextPairEnd)
		{
			hasMore = false;
		}

		size_t space = wkt.find(" ", nextPair + 1);
		if (space == std::string::npos)
		{
			ONYX_THROW("Could not find a space to separate x and y coordinates in wkt linestring");
		}
		space++;
		std::string xStr = wkt.substr(nextPair, space - nextPair);
		std::string yStr = wkt.substr(space, nextPairEnd - space);
		float x = (float)std::atof(xStr.c_str());
		float y = (float)std::atof(yStr.c_str());

		nextPair = nextPairEnd;
		nextPairEnd = wkt.find(',', nextPairEnd + 1);
		if (nextPairEnd == std::string::npos) //if theres no comma its only one pair, so just jump to the end
		{
			nextPairEnd = wkt.find(")", nextPairEnd);
		}
		nextPair++;
		points.push_back(lgal::world::Vector2(x, y));
	}

	return points;
}
}