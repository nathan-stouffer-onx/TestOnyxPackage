#ifndef WKTPARSER_H_
#define WKTPARSER_H_

#include "lucid/gal/Types.h"
#include "Logging/LogManager.h"
#include "System/OnyxException.h"

#include <string>

namespace onyx::WKT {
	std::vector<lgal::world::Vector2> parseLinestring(const std::string& wkt);
}

#endif