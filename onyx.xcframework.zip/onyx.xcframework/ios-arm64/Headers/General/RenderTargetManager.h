#ifndef RENDERTARGETMANAGER_H_
#define RENDERTARGETMANAGER_H_

#include <vector>
#include <mutex>
#include <bgfx/bgfx.h>
#include <bx/bx.h>
#include <bx/math.h>
#include <functional>
#include "../../../bgfx/bgfx/src/config.h"

#define MAX_RENDER_TARGETS_PER_FRAME (BGFX_CONFIG_MAX_FRAME_BUFFERS / 4)		// max allocated per frame. takes 3 frames to delete so using no more than 1/4 our max per frame to make sure we dont run out
//its too easy to run out of render target handles and then they just start quietly failing, so this manager gives us a queue system to ensure we dont overdo it
class RenderTargetManager
{

public:

	static RenderTargetManager* Instance();
	RenderTargetManager();
	~RenderTargetManager();

	void update();
	void renderToTexture(int width, int height, uint32_t clearColor, bgfx::TextureFormat::Enum format, std::function<void(bgfx::ViewId)> renderCallback, std::function<void(bgfx::TextureHandle)> finishedCallback, bx::Vec3 lookFrom = bx::Vec3(0, 0, 1), bx::Vec3 lookAt = bx::Vec3(0), bx::Vec3 lookUp = bx::Vec3(0, -1, 0), float orthoSize = 1);


private:

	struct RenderInfo
	{
		int width = 256;
		int height = 256;
		std::function<void(bgfx::ViewId)> renderCallback = NULL;
		std::function<void(bgfx::TextureHandle)> finishedCallback = NULL;
		bgfx::FrameBufferHandle frameBuffer = BGFX_INVALID_HANDLE;
		bgfx::TextureHandle texHandles[2]{ BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE };
		bgfx::TextureFormat::Enum format = bgfx::TextureFormat::RGBA8;
		uint32_t clearColor = 0x00000000;

		float viewMat[16]{};
		float projMat[16]{};

		int frameCount = 2; //keep it around for 2 frames so we can safely use the data
	};

	std::vector<RenderInfo*> mActiveRenders;
	std::vector<RenderInfo*> mQueuedRenders;

	void updateRenderPasses();
	void activateRenderPass(RenderInfo* pass);

protected:
	static RenderTargetManager* sSingleton;

	bool tryAcquireResources(RenderInfo* pass);

};
#endif
