#include "RenderTargetManager.h"

#include <bx/math.h>

#include <Logging/LogManager.h>

#include "Rendering/ViewId.h"
#include "Utils/BgfxUtils.h"

RenderTargetManager* RenderTargetManager::sSingleton = NULL;

RenderTargetManager* RenderTargetManager::Instance()
{
	if (sSingleton == NULL)
		sSingleton = new RenderTargetManager();

	return sSingleton;
}

RenderTargetManager::RenderTargetManager()
{

}

RenderTargetManager::~RenderTargetManager()
{
	for (RenderInfo* pass : mQueuedRenders)
	{
		delete pass;
	}
	mQueuedRenders.clear();
	for (RenderInfo* pass : mActiveRenders)
	{
		delete pass;
	}
	mActiveRenders.clear();

	sSingleton = NULL;
}

void RenderTargetManager::renderToTexture(int width, int height, uint32_t clearColor, bgfx::TextureFormat::Enum format, std::function<void(bgfx::ViewId)> renderCallback, std::function<void(bgfx::TextureHandle)> finishedCallback, lgal::gpu::Vector3 const& lookFrom, lgal::gpu::Vector3 const& lookAt, lgal::gpu::Vector3 const& lookUp, float orthoSize)
{
	RenderInfo* rp = new RenderInfo();
	rp->width = width;
	rp->height = height;
	rp->clearColor = clearColor;
	rp->finishedCallback = finishedCallback;
	rp->renderCallback = renderCallback;
	rp->format = format;
	bx::mtxLookAt(rp->viewMat, BgfxUtils::toBx(lookFrom), BgfxUtils::toBx(lookAt), BgfxUtils::toBx(lookUp));
	if (bgfx::getCaps()->originBottomLeft)
	{
		bx::mtxOrtho(rp->projMat, 0, orthoSize, 0, -orthoSize, 0.01f, 10, 0, false);
	}
	else
	{
		bx::mtxOrtho(rp->projMat, 0, orthoSize, -orthoSize, 0, 0.01f, 10, 0, false);
	}
	
	mQueuedRenders.push_back(rp);
}

void RenderTargetManager::update()
{
	updateRenderPasses();
}

void RenderTargetManager::updateRenderPasses()
{
	int deleted = 0;
	//check if any existing ones are done and ready for cleanup
	for (int i = (int)mActiveRenders.size() - 1; i >= 0; i--)
	{
		if (--mActiveRenders[i]->frameCount < 0)
		{
			RenderInfo* p = mActiveRenders[i];
			
			// only deallocate depth texture and frame buffer, color texture is the output
			if (bgfx::isValid(p->texHandles[1]))
			{
				bgfx::destroy(p->texHandles[1]);
			}
			if (bgfx::isValid(p->frameBuffer))
			{
				bgfx::destroy(p->frameBuffer);
			}
			
			mActiveRenders.erase(mActiveRenders.begin() + i);
			delete p;
			deleted++;
		}
	}

	bool failed = false;		// for now, assume no failures

	// NOTE: leave a frame buffer leftover for the camera depth texture
	uint32_t maxFrameBuffers = bgfx::getCaps()->limits.maxFrameBuffers - 20;	// TODO only sub for depth tex after tex atlas doesn't rtt
	
	// NOTE: framebuffers destroyed above are not available until the next frame	
	int added = 0;
	// create any we've queued up and have room for this frame
	while (mQueuedRenders.size() > 0 &&								// check that there are more passes to activate
			added < MAX_RENDER_TARGETS_PER_FRAME &&							// check that we can add more in this frame
			mActiveRenders.size() + deleted < maxFrameBuffers &&		// global check that there are existing frame buffers
			!failed)														// check that there have been no failures so far
	{
		RenderInfo* p = mQueuedRenders[0];
		
		if (tryAcquireResources(p))
		{
			mQueuedRenders.erase(mQueuedRenders.begin());
			activateRenderPass(p);
			added++;
		}
		else
		{
			failed = true;
			logE("Failed to create render target");
		}
	}
}

void RenderTargetManager::activateRenderPass(RenderInfo* pass)
{	
	mActiveRenders.push_back(pass);

	bgfx::ViewId viewId = onyx::Rendering::ViewId::next(onyx::Rendering::ViewId::Types::RenderToTexture);

	bgfx::setViewName(viewId, "rtt tex render");
	bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, pass->clearColor, 1.0f, 0);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)pass->width, (uint16_t)pass->height);
	bgfx::setViewFrameBuffer(viewId, pass->frameBuffer);
	bgfx::setViewTransform(viewId, pass->viewMat, pass->projMat);
	bgfx::touch(viewId);

	pass->renderCallback(viewId);

	pass->finishedCallback(pass->texHandles[0]);		// pass in target texture so caller can act appropriately
}

bool RenderTargetManager::tryAcquireResources(RenderInfo* pass)
{
	// create color texture and set name
	pass->texHandles[0] = bgfx::createTexture2D(
		  uint16_t(pass->width)
		, uint16_t(pass->height)
		, false
		, 1
		, pass->format
		, BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP// | BGFX_TEXTURE_READ_BACK
	);

	if (bgfx::isValid(pass->texHandles[0]))
	{
		bgfx::setName(pass->texHandles[0], "rtt color tex");
	}

	// create depth texture and set name
	bgfx::TextureFormat::Enum depthFormat =
		bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D16, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D16
		: bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24S8, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24S8
		: bgfx::TextureFormat::D32;
	
	pass->texHandles[1] = bgfx::createTexture2D(
		  uint16_t(pass->width)
		, uint16_t(pass->height)
		, false
		, 1
		, depthFormat
		, BGFX_TEXTURE_RT_WRITE_ONLY
	);
	
	if (bgfx::isValid(pass->texHandles[1]))
	{
		bgfx::setName(pass->texHandles[1], "rtt depth tex");
	}
	
	// create frame buffer and set name
	pass->frameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(pass->texHandles), pass->texHandles, false);
	if (bgfx::isValid(pass->frameBuffer))
	{
		bgfx::setName(pass->frameBuffer, "rtt framebuffer");
	}
	
	// if any handles are invalid, deallocate all resources
	if (!bgfx::isValid(pass->texHandles[0]) ||
		!bgfx::isValid(pass->texHandles[1]) || 
		!bgfx::isValid(pass->frameBuffer))
	{
		// destroy what was successfully allocated
		if (bgfx::isValid(pass->texHandles[0]))
		{
			bgfx::destroy(pass->texHandles[0]);
		}
		if (bgfx::isValid(pass->texHandles[1]))
		{
			bgfx::destroy(pass->texHandles[1]);
		}
		if (bgfx::isValid(pass->frameBuffer))
		{
			bgfx::destroy(pass->frameBuffer);
		}
		return false;
	}
	
	// if we make it here, resources were acquired successfully
	return true;
}
