#ifndef TEXT_UTILS_H_
#define TEXT_UTILS_H_

#include <string>
#include <sstream>
#include <array>
#include <iomanip>

#include "MapMath.h"

namespace onyx {
namespace Utils {
namespace Text {

template <typename T>
std::string ReadableByteCountStr(T value)
{
	std::array<std::string, 5> suffixes = { " B", " KB", " MB", " GB", " TB" };
	double current = (double)value;
	size_t magnitude = 0;

	while (magnitude < (suffixes.size() - 1) && current >= 1024.0)
	{
		++magnitude;
		current /= 1024.0;
	}

	std::ostringstream result;
	result << std::fixed << std::setprecision((magnitude) > 0 ? 2 : 0) << current << suffixes[magnitude];
	return result.str();
}

template <typename T>
std::string ReadableDurationStr(T durationMS)
{
	std::array<double, 5> scales =
	{
		60.,
		60.,
		24,
		365.,
		100 * 365.4
	};

	auto value = double(durationMS);

	std::ostringstream result;
	result << std::fixed;

	if (value < 1000) // milliseconds x.xx MS or xx MS
	{
		result << std::setprecision(value > 10 ? 2 : 0) << value << " ms";
		return result.str();
	}

	if (value < 60000) // seconds xx.x S
	{
		result << std::setprecision(1) << (value * 0.001) << " s";
		return result.str();
	}

	result << std::setprecision(0);
	value *= std::floor(0.001);

	for (auto const &scale : scales)
	{
		auto part = int(std::fmod(value, scale));
		value = std::floor(value / scale);

		result << std::to_string(part);

		// Yeah, it'll break if there are multiple identical scales at the end of the list.  But there aren't and won't be.
		if (value <= 0 || scale == scales.back())
		{
			break;
		}
	
		result << ":";
	}

	return result.str();
}

template <typename T>
std::string ReadableCountStr(T count)
{
	std::array<std::pair<double, std::string>, 3> magnitudes =
	{
		std::pair<double, std::string>{ 1000000000., " B" },
		std::pair<double, std::string>{ 1000000., " M" },
		std::pair<double, std::string>{ 1000., " K"}
	};

	auto value = double(count);

	for (auto& [size, suffix] : magnitudes)
	{
		if (value > size)
		{
			std::ostringstream result;
			value /= size;
			result << value << " " << suffix;
			return result.str();
		}
	}

	return std::to_string(count);
}

std::string ReadableLonLat(MapMath::LonLat const& lonLat);
std::pair<float32_t, std::string_view> GetDistanceLabelUnits(float32_t km, bool metric = false);

} } }
#endif // TEXT_UTILS_H_