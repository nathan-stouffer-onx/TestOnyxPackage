#ifndef TEXT_UTILS_H_
#define TEXT_UTILS_H_

#include <string>
#include <sstream>
#include <array>
#include <iomanip>

#include "MapMath.h"

namespace onyx {
namespace Utils {
namespace Text {

template <typename T>
std::string ReadableByteCountStr(T value)
{
	std::array<std::string, 5> suffixes = { " B", " KB", " MB", " GB", " TB" };
	double current = (double)value;
	size_t magnitude = 0;

	while (magnitude < (suffixes.size() - 1) && current >= 1024.0)
	{
		++magnitude;
		current /= 1024.0;
	}

	std::ostringstream result;
	result << std::fixed << std::setprecision((magnitude) > 0 ? 2 : 0) << current << suffixes[magnitude];
	return result.str();
}


template <typename T>
std::string ReadableCountStr(T count)
{
	std::array<std::pair<double, std::string>, 3> magnitudes =
	{
		std::pair<double, std::string>{ 1000000000., " B" },
		std::pair<double, std::string>{ 1000000., " M" },
		std::pair<double, std::string>{ 1000., " K"}
	};

	auto value = double(count);

	for (auto& [size, suffix] : magnitudes)
	{
		if (value > size)
		{
			std::ostringstream result;
			value /= size;
			result << value << " " << suffix;
			return result.str();
		}
	}

	return std::to_string(count);
}

std::string ReadableLonLat(MapMath::LonLat const& lonLat);
std::pair<float32_t, std::string_view> GetDistanceLabelUnits(float32_t km, bool metric = false);

} } }
#endif // TEXT_UTILS_H_