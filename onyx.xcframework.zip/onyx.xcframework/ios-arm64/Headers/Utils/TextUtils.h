#ifndef TEXT_UTILS_H_
#define TEXT_UTILS_H_

#include <string>
#include <sstream>
#include <array>
#include <iomanip>

#include "MapMath.h"

namespace onyx {
namespace Utils {
namespace Text {

template <typename T>
std::string ReadableByteCountStr(T value)
{
	std::array<std::string, 5> suffixes = { " B", " KB", " MB", " GB", " TB" };
	double current = (double)value;
	size_t magnitude = 0;

	while (magnitude < (suffixes.size() - 1) && current >= 1024.0)
	{
		++magnitude;
		current /= 1024.0;
	}

	std::ostringstream result;
	result << std::fixed << std::setprecision((magnitude) > 0 ? 2 : 0) << current << suffixes[magnitude];
	return result.str();
}

template <typename T>
std::string ReadableDurationStr(T durationMS)
{
	struct Pair
	{
		double scalar;
		std::string units;
	};

	std::array<Pair, 5> scales =
	{
		Pair{ 60.,          "min" },
		Pair{ 60.,          "hr"  },
		Pair{ 24.,          "day" },
		Pair{ 365.,         "yr"  },
		Pair{ 100 * 365.25, "cen" },
	};

	auto value = double(durationMS);

	std::ostringstream result;
	result << std::fixed;

	if (value < 1000) // milliseconds x.xx MS or xx MS
	{
		result << std::setprecision(value > 10 ? 2 : 0) << value << " ms";
		return result.str();
	}

	if (value < 60000) // seconds xx.x S
	{
		result << std::setprecision(1) << (value * 0.001) << " s";
		return result.str();
	}

	result << std::setprecision(0);
	value = std::floor(value * 0.001);

	std::array<int, 5> converted =
	{
		0,
		0,
		0,
		0,
		0,
	};
	
	std::string units = "";
	for (size_t i = 0; i < scales.size(); ++i)
	{
		auto scale = scales[i].scalar;
		auto part = int(std::fmod(value, scale));
		value = std::floor(value / scale);
		converted[i] = part;
		if (value > 0) { units = scales[i].units; }
	}

	bool first = true;
	bool write = false;
	for (auto it = converted.crbegin(); it != converted.crend(); ++it)
	{
		auto part = *it;
		if (part > 0) { write = true; }
		if (write)
		{
			if (!first) { result << ":"; }

			std::string str = std::to_string(part);
			if (str.size() < 2) { str = "0" + str; }
			result << str;

			first = false;
		}
	}

	result << " " << units;

	return result.str();
}

template <typename T>
std::string ReadableCountStr(T count)
{
	std::array<std::pair<double, std::string>, 3> magnitudes =
	{
		std::pair<double, std::string>{ 1000000000., " B" },
		std::pair<double, std::string>{ 1000000., " M" },
		std::pair<double, std::string>{ 1000., " K"}
	};

	auto value = double(count);

	for (auto& [size, suffix] : magnitudes)
	{
		if (value > size)
		{
			std::ostringstream result;
			value /= size;
			result << value << " " << suffix;
			return result.str();
		}
	}

	return std::to_string(count);
}

std::string ReadableLonLat(MapMath::LonLat const& lonLat);
std::pair<float32_t, std::string_view> GetDistanceLabelUnits(float32_t km, bool metric = false);

} } }
#endif // TEXT_UTILS_H_