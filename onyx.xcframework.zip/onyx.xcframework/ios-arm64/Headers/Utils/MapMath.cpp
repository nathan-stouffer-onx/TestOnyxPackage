#include "MapMath.h"

#include <cmath>

namespace onyx {
namespace MapMath {

	// implementation methods for LonLat struct
	LonLat::LonLat() : lon(0.0), lat(0.0) {}
	LonLat::LonLat(world_float_t lon, world_float_t lat) : lon(lon), lat(lat) {}
	LonLat::LonLat(lgal::world::Vector2 const& worldPos) : lon(XToLon(worldPos.x)), lat(YToLat(worldPos.y)) {}
	LonLat::LonLat(Tiles::TileId const& tileId)
	{
		auto pos = tileId.northwestCorner();
		lat = YToLat(pos.y);
		lon = XToLon(pos.x);
	}
	lgal::world::Vector2 LonLat::toWorldPos() const { return { LonToX(lon), LatToY(lat) }; }
	Tiles::TileId LonLat::containingTileId(Tiles::TileId::IdCoordsT level) const { return Tiles::TileId::Containing(level, toWorldPos()); }

	// implementation methods for LatLon struct
	LonLatElevation::LonLatElevation() : lon(0.0), lat(0.0), elevation(0.0) {}
	LonLatElevation::LonLatElevation(world_float_t lon, world_float_t lat, world_float_t height) : lon(lon), lat(lat), elevation(height) {}
	LonLatElevation::LonLatElevation(lgal::world::Vector3 const& worldPos) : lon(XToLon(worldPos.x)), lat(YToLat(worldPos.y)), elevation(worldPos.z / mercatorDistortion(LonLat{ lon, lat })) {}
	lgal::world::Vector3 LonLatElevation::toWorldPos() const { return { LonToX(lon), LatToY(lat), mercatorDistortion(LonLat{ lon, lat }) * elevation }; }
	Tiles::TileId LonLatElevation::containingTileId(Tiles::TileId::IdCoordsT level) const { return Tiles::TileId::Containing(level, toWorldPos()); }

	bool inWorldBounds(lgal::world::Vector2 const& pos)
	{
		auto corner = lgal::world::Vector2{ Tiles::cLeftX, Tiles::cTopY };

		bool inX = (corner.x <= pos.x) && (pos.x <= corner.x + Tiles::cMaxExtent);
		bool inY = (corner.y <= pos.y) && (pos.y <= corner.y + Tiles::cMaxExtent);
		return inX && inY;
	}
	bool inWorldBounds(lgal::world::Vector3 const& pos)
	{
		auto corner = lgal::world::Vector2{ Tiles::cLeftX, Tiles::cTopY };

		bool inX = (corner.x <= pos.x) && (pos.x <= corner.x + Tiles::cMaxExtent);
		bool inY = (corner.y <= pos.y) && (pos.y <= corner.y + Tiles::cMaxExtent);
		bool inZ = (cMinHeight <= pos.z) && (pos.z <= cMaxHeight);
		return inX && inY && inZ;
	}

	// mapbox has a concept of "zoom" that is assigned to a frame. It seems to be based purely on the distance between the camera
	// eye and the look point. This is our approximation of that value
	// https://docs.mapbox.com/mapbox-gl-js/style-spec/expressions/#zoom
	world_float_t zoom(world_float_t const dist)
	{
		// computing zoom in the mercator projection (where distances are artificially scaled). I think this is what we want, but
		// we may want to reconsider at a later time
		return std::clamp(26.5 - std::log2(dist * 1000.0), 0.0, 26.5);
	}

	world_float_t zoomToKm(world_float_t const z)
	{
		return 0.001 * std::pow(2.0, 26.5 - z);
	}

	lgal::world::Vector3 Spherical::toEuclidean() const
	{
		// compute x, y, and z based off heading and pitch
		auto x =  std::sin(heading) * std::sin(pitch);
		auto y = -std::cos(heading) * std::sin(pitch);
		auto z = -std::cos(pitch);
		return radius * lgal::world::Vector3{ x, y, z };
	}

} }
