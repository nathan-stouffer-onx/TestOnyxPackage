#pragma once

#include <limits>
#include <optional>
#include <vector>

#include "System/OnyxException.h"

namespace onyx::Collections {

	template<typename T>
	class LinkedListVector
	{
	private:
		struct LLItem
		{
			std::optional<T> value;
			size_t prev = cLast;
			size_t next = cLast;
		};

		static constexpr size_t cLast = std::numeric_limits<size_t>::max();

	public:

		class iterator
		{
		friend class LinkedListVector;
		public:
			inline T& operator*()
			{
				checkIterator();
				return owner.mDataPtr[position].value.value();
			}

			inline void operator=(iterator const& rhs)
			{
#if _ITERATOR_DEBUG_LEVEL != 0
				ONYX_ASSERT(&owner == &rhs.owner, "Invalid list owner");
#endif
				position = rhs.position;
			}

			inline bool operator!=(iterator const& rhs)
			{
				return !(*this == rhs);
			}

			inline bool operator==(iterator const& rhs)
			{
				return position == rhs.position
#if _ITERATOR_DEBUG_LEVEL != 0
					&& &owner == &rhs.owner
#endif
					;
			}

			inline iterator operator+(size_t offset)
			{
				iterator result =*this;
				result += offset;
				return result;
			}

			inline iterator operator-(size_t offset)
			{
				iterator result = *this;
				result -= offset;
				return result;
			}

			inline iterator& operator+=(size_t offset)
			{
				checkIterator();
				for (size_t i = 0; i < offset; ++i)
				{
					ONYX_ASSERT(position != cLast, "Reached end of list");
					position = owner.mDataPtr[position].next;
				}
				return *this;
			}

			inline iterator& operator-=(size_t offset)
			{
				checkIterator();
				if (offset == 0)
				{
					return *this;
				}

				if (position == cLast)
				{
					position = owner.mEnd;
					--offset;
				}
				for (size_t i = 0; i < offset; ++i)
				{
					ONYX_ASSERT(position != owner.mBegin, "Reached beginning of list");
					position = owner.mDataPtr[position].prev;
				}
				return *this;
			}

			inline iterator& operator++()
			{
				checkIterator();
				ONYX_ASSERT(position != cLast, "End of list");
				position = owner.mDataPtr[position].next;
				return *this;
			}

			inline iterator operator++(int)
			{
				iterator result(*this);
				++(*this);
				return result;
			}

			inline iterator& operator--()
			{
				checkIterator();
				ONYX_ASSERT(position != owner.mBegin, "Beginning of list");

				if (position == cLast)
				{
					position = owner.mEnd;
				}
				else
				{
					position = owner.mDataPtr[position].prev;
				}
				return *this;
			}

			inline iterator operator--(int)
			{
				iterator result(*this);
				--(*this);
				return result;
			}

		protected:
			LinkedListVector const& owner;
			size_t position;

			inline void checkIterator() { ONYX_DEBUG_ASSERT(position == cLast || owner.mDataPtr[position].value.has_value(), "Invalid iterator"); }

			iterator(LinkedListVector const& owner, size_t position) : owner(owner), position(position)
			{ }

		};

		class reverse_iterator : public iterator
		{
			friend class LinkedListVector;
			reverse_iterator(LinkedListVector const& owner, size_t position) : iterator(owner, position) { }
			reverse_iterator(iterator const& src) : iterator(this->owner, this->position) { }

		public:
			inline reverse_iterator operator+(size_t offset)
			{
				return reverse_iterator(iterator::operator-(offset));
			}

			inline bool operator==(iterator const& rhs)
			{
#if _ITERATOR_DEBUG_LEVEL != 0
				ONYX_ASSERT(&this->owner == &rhs.owner, "Invalid list owner");
#endif
				return this->position != cLast && iterator::operator*(rhs);
			}

			inline bool operator==(reverse_iterator const& rhs)
			{
#if _ITERATOR_DEBUG_LEVEL != 0
				ONYX_ASSERT(&this->owner == &rhs.owner, "Invalid list owner");
#endif
				return this->position == rhs.position
#if _ITERATOR_DEBUG_LEVEL != 0
					&&  &this->owner == &rhs.owner
#endif
					;
			}

			inline reverse_iterator operator-(size_t offset)
			{
				return reverse_iterator(iterator::operator+(offset));
			}

			inline reverse_iterator& operator+=(size_t offset)
			{
				iterator::operator-=(offset);
				return *this;
			}

			inline reverse_iterator& operator-=(size_t offset)
			{
				iterator::operator+=(offset);
				return *this;
			}

			inline reverse_iterator operator++(int)
			{
				iterator result(*this);
				++(*this);
				return result;
			}

			inline reverse_iterator& operator++()
			{
				this->checkIterator();
				ONYX_ASSERT(this->position != cLast, "End of list");
				this->position = this->owner.mDataPtr[this->position].prev;
				return *this;
			}

			inline reverse_iterator operator--(int)
			{
				iterator result(*this);
				--(*this);
				return result;
			}

			inline reverse_iterator& operator--()
			{
				this->checkIterator();
				ONYX_ASSERT(this->position != this->owner.mEnd, "Beginning of list");

				if (this->position == cLast)
				{
					this->position = this->owner.mBegin;
				}
				else
				{
					this->position = this->owner.mDataPtr[this->position].next;
				}
				return *this;

			}

		};

		void push_back(T const& item);
		void reserve(size_t capacity);
		void erase(iterator const& position);
		void insert(iterator const& after, T const& item);
		void clear();

		template <typename iter_t>
		void insert(iterator const& after, iter_t const& begin, iter_t const & end);

		size_t availableCount() const { return mAvailableCount; }
		size_t size() const { return mUsedCount; }
		size_t getCapacity() const { return mItems.size(); }
		bool empty() const { return mUsedCount == 0; }

		iterator begin() { return iterator{ *this, mBegin }; }
		iterator end() const { return iterator{ *this, cLast }; }

		reverse_iterator rbegin() { return reverse_iterator{ *this, mEnd }; }
		reverse_iterator rend() const { return reverse_iterator{ *this, cLast }; }

		LinkedListVector() { }
		LinkedListVector(size_t reserveSize)
		{
			reserve(reserveSize);
		}

	private:

		std::vector<LLItem> mItems;
		LLItem* mDataPtr = nullptr;

		size_t mBegin = cLast;
		size_t mEnd = cLast;
		size_t mFreeBegin = cLast;
		size_t mFreeEnd = cLast;
		size_t mUsedCount = 0;
		size_t mAvailableCount = 0;
		void autoGrow(size_t count = 0);
		void insertAt(T const &value, size_t position);
		void verify();
	};
	
	template<typename T>
	void LinkedListVector<T>::autoGrow(size_t count)
	{
		if (mFreeBegin == cLast)
		{
			ONYX_DEBUG_ASSERT(mUsedCount == mItems.size(), "Invalid used count");
			ONYX_DEBUG_ASSERT(mAvailableCount == 0, "Invalid available count");
			reserve(std::max(std::max(count, mUsedCount * 2), size_t(16)));
		}
	}

	template<typename T>
	void LinkedListVector<T>::push_back(T const &value)
	{
		autoGrow();

		auto data = mDataPtr + mFreeBegin;

		if (mBegin == cLast)
		{
			mBegin = mFreeBegin;
		}

		if (data->next != cLast)
		{
			mDataPtr[data->next].prev = cLast;
		}

		data->value = value;
		data->prev = mEnd;
		if (mEnd != cLast)
		{
			mDataPtr[mEnd].next = mFreeBegin;
		}
		mEnd = mFreeBegin;
		mFreeBegin = data->next;
		if (mFreeBegin == cLast)
		{
			mFreeEnd = cLast;
		}
		data->next = cLast;

		++mUsedCount;
		--mAvailableCount;
		verify();
	}

	template<typename T>
	void LinkedListVector<T>::insertAt(T const& value, size_t position)
	{
		if (position == cLast)
		{
			push_back(value);
			return;
		}

		autoGrow();

		auto beforeData = mDataPtr + position;
		auto newData = mDataPtr + mFreeBegin;
		auto oldFreeBegin = mFreeBegin;
		auto nextFreeBegin = newData->next;

		if (mBegin == cLast || mBegin == position)
		{
			mBegin = oldFreeBegin;
		}
		if (newData->next != cLast)
		{
			mDataPtr[newData->next].prev = cLast;
		}

		newData->value = value;
		newData->prev = beforeData->prev;
		newData->next = position;
		if (beforeData->prev != cLast)
		{
			mDataPtr[beforeData->prev].next = mFreeBegin;
		}

		beforeData->prev = mFreeBegin;

		mFreeBegin = nextFreeBegin;
		if (mFreeBegin == cLast)
		{
			mFreeEnd = cLast;
		}

		++mUsedCount;
		--mAvailableCount;
		verify();
	}

	template<typename T>
	void LinkedListVector<T>::reserve(size_t capacity)
	{
		size_t oldSize = mItems.size();

		ONYX_ASSERT(capacity >= oldSize, "LinkedListVector can only grow (for now)");
		if (oldSize == capacity)
		{
			return;
		}

		mAvailableCount = capacity - mUsedCount;
		mItems.resize(capacity);
		mDataPtr = mItems.data();

		if (mFreeEnd != cLast)
		{
			mDataPtr[mFreeEnd].next = oldSize;
		}

		if (mFreeBegin == cLast)
		{
			mFreeBegin = oldSize;
			mFreeEnd = oldSize;
		}


		LLItem* data = mDataPtr + oldSize;

		for (auto idx = oldSize; idx < capacity; ++idx, ++data)
		{
			if (mFreeBegin == idx)
			{
				data->prev = cLast;
			}
			else
			{
				data->prev = mFreeEnd;
			}
			mFreeEnd = idx;
			data->next = idx + 1;
		}

		--data;
		data->next = cLast;
		verify();
	}

	template<typename T>
	void LinkedListVector<T>::erase(LinkedListVector<T>::iterator const& position)
	{
		ONYX_ASSERT(&position.owner == this, "Invalid iterator; mismatched LinkedListVector");

		ONYX_ASSERT(position.position < mItems.size(), "Invalid iterator; past end of list");

		ONYX_DEBUG_ASSERT(mDataPtr[position.position].value.has_value(), "Invalid iterator; uninitialized value");

		auto item = mDataPtr + position.position;
		item->value.reset();

		auto prev = item->prev;
		auto next = item->next;

		// First add the slot back to the free list
		item->prev = mFreeEnd;
		if (mFreeEnd != cLast)
		{
			mDataPtr[mFreeEnd].next = position.position;
		}
		mFreeEnd = position.position;
		if (mFreeBegin == cLast)
		{
			mFreeBegin = mFreeEnd;
		}

		if (prev == cLast)
		{
			mBegin = next;
		}
		else
		{
			mDataPtr[prev].next = next;
		}

		if (next == cLast)
		{
			mEnd = prev;
		}
		else
		{
			mDataPtr[next].prev = prev;
		}

		mDataPtr[mFreeEnd].next = cLast;

		--mUsedCount;
		++mAvailableCount;
		verify();
	}

	template<typename T>
	void LinkedListVector<T>::insert(LinkedListVector<T>::iterator const& before, T const& item)
	{
		insertAt(item, before.position);
	}

	template <typename T>
	template <typename iter_t>
	void LinkedListVector<T>::insert(LinkedListVector<T>::iterator const& before, iter_t const& begin, iter_t const& end)
	{
		autoGrow();

		for (auto curr = begin; curr != end; ++curr)
		{
			insertAt(*curr, before.position);
		}
	}

	template<typename T>
	void LinkedListVector<T>::clear()
	{
		auto position = mBegin;
		while (position != cLast)
		{
			mDataPtr[position].value.reset();
			mDataPtr[position].prev = mFreeEnd;
			auto nextPosition = mDataPtr[position].next;
			mDataPtr[position].next = cLast;
			if (mFreeEnd != cLast)
			{
				mDataPtr[mFreeEnd].next = position;
			}
			if (mFreeBegin == cLast)
			{
				mFreeBegin = position;
			}
			mFreeEnd = position;
			position = nextPosition;
		}
		mUsedCount = 0;
		mAvailableCount = mItems.size();
		mBegin = cLast;
		mEnd = cLast;
		verify();
	}

	template<typename T>
	void LinkedListVector<T>::verify()
	{
#if _VERIFY_LINKED_LIST_VECTOR != 0
		auto begin = mBegin;
		auto used = mUsedCount;
		ONYX_ASSERT(mUsedCount + mAvailableCount == mItems.size(), "Used + Available counts do not match mItems.size()");

		while (begin != cLast)
		{
			auto const& item = *(mDataPtr + begin);
			ONYX_ASSERT(item.value.has_value(), "Invalid empty item in used list");
			--used;
			begin = item.next;
		}
		ONYX_ASSERT(used == 0, "Used count and actual used slots are not in sync");

		begin = mFreeBegin;
		used = mAvailableCount;
		while (begin != cLast)
		{
			auto const& item = *(mDataPtr + begin);
			ONYX_ASSERT(!item.value.has_value(), "Invalid item in available list");
			--used;
			begin = item.next;
		}
		ONYX_ASSERT(used == 0, "Available count and actual available slots are not in sync");
#endif
	}

}