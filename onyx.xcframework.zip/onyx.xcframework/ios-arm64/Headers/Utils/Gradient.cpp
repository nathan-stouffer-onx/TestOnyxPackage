#include "Gradient.h"

#include <vector>
#include <cmath>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <System/OnyxException.h>

namespace onyx {
namespace Utils {

	Gradient::Gradient() = default;

	Gradient::Gradient(std::vector<Stop> const& stops, time_float_t period) : mStops(stops), mPeriod(period)
	{
		if (mPeriod > 0.0)
		{
			for (Stop& stop : mStops)
			{
				stop.time = std::fmod(stop.time, mPeriod);
				if (stop.time < 0.0)
				{
					stop.time += mPeriod;
				}
			}
		}
		std::stable_sort(mStops.begin(), mStops.end(), [](Stop const& a, Stop const& b) -> bool { return a.time < b.time; });
	}

	Gradient Gradient::scaleOpacity(float scalar) const
	{
		std::vector<Stop> stops;
		stops.reserve(mStops.size());
		for (Stop const& stop : mStops)
		{
			lgal::Color color = stop.color;
			color.a *= scalar;
			stops.push_back({ stop.time, color });
		}
		return { stops, mPeriod };
	}

	Gradient Gradient::operator*(time_float_t const scalar) const
	{
		std::vector<Stop> stops;
		stops.reserve(mStops.size());
		for (Stop const& stop : mStops)
		{
			stops.push_back({ stop.time * scalar, stop.color });
		}
		return { stops, mPeriod * scalar };
	}

	lgal::Color Gradient::sample(time_float_t t, Mode mode)
	{
		// handle edge cases
		if (mStops.empty())
		{
			return lgal::Color{ 0x00000000 };
		}
		else if (mStops.size() == 1)
		{
			return mStops[0].color;
		}

		switch (mode)
		{
		case Mode::LINEAR:
			return linearSample(t);
			break;
		case Mode::NEAREST:
			return nearestSample(t);
			break;
		default:	// fall through to linear sample
			return linearSample(t);
			break;
		};
	}

	lgal::Color Gradient::linearSample(time_float_t t)
	{
		// grab the first and last points (guaranteed to exist because Color::sample handles edge cases)
		Stop const& first = mStops[0];
		Stop const& last = (*mStops.rbegin());

		if (mPeriod != 0.0)	// the case where we wrap around to the beginning
		{
			if (t < first.time || t > last.time)	// check if t is between last and first
			{
				// compute endpoints that we are lerping between -- adjusted so we can just use straight up lerp
				auto a = (t >= last.time) ? last.time : last.time - mPeriod;
				auto b = (t <= first.time) ? first.time : first.time + mPeriod;

				auto time = (t - a) / (b - a);
				return lgal::Color::lerp(last.color, first.color, (float)time);
			}
			else
			{
				// compute the two points on either side -- guaranteed to exist because we checked edge cases above
				size_t i = 0;
				while (!(mStops[i].time <= t && t <= mStops[i + 1].time))
				{
					i++;
				}

				Stop const& left = mStops[i];
				Stop const& right = mStops[i + 1];

				auto time = (t - left.time) / (right.time - left.time);
				return lgal::Color::lerp(left.color, right.color, (float)time);
			}
		}
		else	// in the case where we do not wrap the line
		{
			if (t <= first.time)		// check if t is less than the first element
			{
				return first.color;
			}
			else if (t >= last.time)	// check if t is greater than the last element
			{
				return last.color;
			}
			else
			{
				// compute the two points on either side -- guaranteed to exist because we checked edge cases above
				size_t i = 0;
				while (!(mStops[i].time <= t && t <= mStops[i + 1].time))
				{
					i++;
				}

				Stop const& left = mStops[i];
				Stop const& right = mStops[i + 1];

				auto time = (t - left.time) / (right.time - left.time);
				return lgal::Color::lerp(left.color, right.color, (float)time);
			}
		}
	}

	lgal::Color Gradient::nearestSample(time_float_t t)
	{
		// grab the first and last points (guaranteed to exist because Color::sample handles edge cases)
		Stop const& first = mStops[0];
		Stop const& last = (*mStops.rbegin());

		if (mPeriod != 0.0)	// the case where we wrap around to the beginning
		{
			if (t < first.time || t > last.time)	// check if t is between last and first
			{
				// compute endpoints that we are lerping between -- adjusted so we can just use straight up lerp
				auto a = (t >= last.time) ? last.time : last.time - 1.0;
				auto b = (t <= first.time) ? first.time : first.time + 1.0;

				// check which endpoint t is closer to
				return (std::abs(t - a) <= std::abs(t - b)) ? last.color : first.color;
			}
			else
			{
				// compute the two points on either side -- guaranteed to exist because we checked edge cases above
				size_t i = 0;
				while (!(mStops[i].time <= t && t <= mStops[i + 1].time))
				{
					i++;
				}

				Stop const& left = mStops[i];
				Stop const& right = mStops[i + 1];

				// check which endpoint t is closer to
				return (std::abs(t - left.time) <= std::abs(t - right.time)) ? left.color : right.color;
			}
		}
		else	// in the case where we do not wrap the line
		{
			if (t <= first.time)		// check if t is less than the first element
			{
				return first.color;
			}
			else if (t >= last.time)	// check if t is greater than the last element
			{
				return last.color;
			}
			else
			{
				// compute the two points on either side -- guaranteed to exist because we checked edge cases above
				size_t i = 0;
				while (!(mStops[i].time <= t && t <= mStops[i + 1].time))
				{
					i++;
				}

				Stop const& left = mStops[i];
				Stop const& right = mStops[i + 1];

				// check which endpoint t is closer to
				return (std::abs(t - left.time) <= std::abs(t - right.time)) ? left.color : right.color;
			}
		}
	}

} }