#pragma once
#ifndef __TIMER_H__
#define __TIMER_H__

#include <numeric>

#include <bx/timer.h>
#include <lucid/gal/Types.h>
#include <System/OnyxException.h>

namespace onyx {
namespace Utils {

	class Timer
	{
	public:

		Timer()
		{
			ONYX_ASSERT(sFreq != std::numeric_limits<time_float_t>::min(), "Timer has not been initialized");
			mStartTime = nowMS();
		}

		time_float_t DurationMS()
		{
			return nowMS() - mStartTime;
		}

		static void initialize();

		inline static time_float_t nowMS()
		{
			ONYX_DEBUG_ASSERT(sFreq != std::numeric_limits<time_float_t>::min(), "Timer has not been initialized");
			return bx::getHPCounter() * sFreq * 1000.0;
		}

	private:
		time_float_t mStartTime = 0;
		static time_float_t sFreq;
	};

} }

#endif