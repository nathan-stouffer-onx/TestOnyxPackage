#pragma once
#if !defined(__TIMER_H)
#define __TIMER_H

#include <numeric>
#include <bx/timer.h>
#include <System/Map3DException.h>

namespace onyx {
namespace Utils {

	class Timer
	{
	public:
		typedef double Map3D_time_t;

		Timer()
		{
			MAP3D_ASSERT(sFreq != std::numeric_limits<Map3D_time_t>::min(), "Timer has not been initialized");
			mStartTime = nowMS();
		}

		Map3D_time_t DurationMS()
		{
			return nowMS() - mStartTime;
		}

		static void initialize();

		inline static Map3D_time_t nowMS()
		{
			MAP3D_DEBUG_ASSERT(sFreq != std::numeric_limits<Map3D_time_t>::min(), "Timer has not been initialized");
			return bx::getHPCounter() * sFreq * 1000.0;
		}

	private:
		Map3D_time_t mStartTime = 0;
		static Map3D_time_t sFreq;
	};

} }

#endif