#include "StringUtils.h"

#include <algorithm>
#include <locale>

namespace onyx::Utils {

uint64_t hex2uint(char const c)
{
	if (c >= '0' && c <= '9')
	{
		return uint64_t(c) - char('0');
	}
	if (c >= 'A' && c <= 'F')
	{
		return uint64_t(c) - (uint64_t('A') - 10ull);
	}
	if (c >= 'a' && c <= 'f')
	{
		return uint64_t(c) - (uint64_t('a') - 10ull);
	}
	return 0b0000;
}

std::string_view hex2bin(char const c)
{
	switch (c)
	{
	case '0': return "0000";
	case '1': return "0001";
	case '2': return "0010";
	case '3': return "0011";
	case '4': return "0100";
	case '5': return "0101";
	case '6': return "0110";
	case '7': return "0111";
	case '8': return "1000";
	case '9': return "1001";
	case 'A': return "1010"; case 'a': return "1010";
	case 'B': return "1011"; case 'b': return "1011";
	case 'C': return "1100"; case 'c': return "1100";
	case 'D': return "1101"; case 'd': return "1101";
	case 'E': return "1110"; case 'e': return "1110";
	case 'F': return "1111"; case 'f': return "1111";
	}
	return "0000";
}

std::string hex2bin(std::string const& hex)
{
	std::string bin;
	bin.reserve(hex.size() * 4);
	for (char const c : hex)
	{
		bin += hex2bin(c);
	}
	return bin;
}

UUID uuid(std::string const& str)
{
	UUID id = 0;

	size_t shift = 0;	// the index of the half-byte that we are parsing from the hex string
	std::for_each(str.rbegin(), str.rend(),
		[&id, &shift](char const& c)
		{
			if (std::isalnum(c))	// only process the character if it is alphanumeric
			{
				id |= (UUID(Utils::hex2uint(c)) << shift);
				shift += 4;
			}
		}
	);

	return id;
}

	char charToUpper(char c) { return std::toupper(c, std::locale()); }
	void toUpperInPlace(std::string& str)
	{
		std::transform(str.begin(), str.end(), str.begin(), charToUpper);
	}

	char charToLower(char c) { return std::tolower(c, std::locale()); }
	void toLowerInPlace(std::string& str)
	{
		std::transform(str.begin(), str.end(), str.begin(), charToLower);
	}

	std::string trim(const std::string& str, const std::string& whitespace)
	{
		auto const strView = std::string_view(str);
		return std::string(trim(strView, whitespace));
	}

	std::string_view trim(const std::string_view& str, const std::string& whitespace)
	{
		const auto strBegin = str.find_first_not_of(whitespace);
		if (strBegin == std::string::npos)
			return ""; // no content

		const auto strEnd = str.find_last_not_of(whitespace);
		const auto strRange = strEnd - strBegin + 1;

		return str.substr(strBegin, strRange);
	}

	std::string removeWhitespace(std::string const& input)
	{
		std::string str;
		str.reserve(input.size());
		for (char c : input)
		{
			if (!Utils::isWhitespace(c))
			{
				str.push_back(c);
			}
		}
		return str;
	}

}