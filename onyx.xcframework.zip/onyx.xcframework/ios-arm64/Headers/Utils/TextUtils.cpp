#include "TextUtils.h"

#include <string>
#include <sstream>
#include <array>
#include <iomanip>

namespace onyx {
namespace Utils {
namespace Text {


std::string ReadableLonLat(MapMath::LonLat const& lonLat)
{
	std::ostringstream os;
	os.setf(std::ios::fixed);
	os.precision(2);

	char ns = (lonLat.lat >= 0.0) ? 'N' : 'S';
	char ew = (lonLat.lon >= 0.0) ? 'E' : 'W';

	os << std::abs(lonLat.lat) << ns << ", " << std::abs(lonLat.lon) << ew;

	return os.str();
}


struct unitDef {
	float32_t scale;
	std::string const label;
};

typedef std::vector<unitDef> labelMap_t;

labelMap_t const sMetricLabels =
{
	{ 1000, "km" },
	{ 1000, "m" },
	{ 1000, "cm" }
};

labelMap_t const sImperialLabels =
{
	{ 5280, "mi" },
	{ 12, "'" },
	{ 1, "\"" }
};

std::pair<float32_t, std::string_view> GetDistanceLabelUnits(float32_t km, bool metric)
{
	labelMap_t const* labels = &sMetricLabels;

	float32_t value = km;
	if (!metric)
	{
		labels = &sImperialLabels;
		value = float32_t(MapMath::kmToMi(km));
	}

	for (auto const& unit : (*labels))
	{
		if (value > 0.9f)
		{
			return { value,  unit.label };
		}

		value *= unit.scale;
	}

	return { value, labels->back().label };
}


} } }