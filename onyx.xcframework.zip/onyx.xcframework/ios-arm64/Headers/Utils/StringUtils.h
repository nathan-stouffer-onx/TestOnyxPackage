#pragma once

#include <cstdint>
#include <string>
#include <vector>

#include "Utils/UUID.h"

namespace onyx::Utils
{

	uint64_t hex2uint(char const c);

	std::string_view hex2bin(char const c);
	std::string hex2bin(std::string const& hex);

	UUID uuid(std::string const& str);

	std::string trim(const std::string& str, const std::string& whitespace = " \t");
	std::string_view trim(const std::string_view& str, const std::string& whitespace = " \t");

	template <typename T>
	std::vector<std::string> splitString(std::string str, T delimeter)
	{
		size_t start;
		size_t end = 0;
		std::vector<std::string> result;

		while ((start = str.find_first_not_of(delimeter, end)) != std::string::npos)
		{
			end = str.find(delimeter, start);
			std::string s = str.substr(start, end - start);
			result.push_back(s);
		}

		return result;
	}

}