#pragma once

#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

#include "Utils/UUID.h"

namespace onyx::Utils
{

	uint64_t hex2uint(char const c);

	std::string_view hex2bin(char const c);
	std::string hex2bin(std::string const& hex);

	UUID uuid(std::string const& str);

	std::string trim(const std::string& str, const std::string& whitespace = " \t");
	std::string_view trim(const std::string_view& str, const std::string& whitespace = " \t");

	template <typename T>
	std::vector<std::string> splitString(std::string str, T delimeter)
	{
		size_t start;
		size_t end = 0;
		std::vector<std::string> result;

		while ((start = str.find_first_not_of(delimeter, end)) != std::string::npos)
		{
			end = str.find(delimeter, start);
			std::string s = str.substr(start, end - start);
			result.push_back(s);
		}

		return result;
	}

	inline size_t argLength()
	{
		return 0;
	}

	template<typename T, typename... Tail>
	size_t argLength(T head, Tail... tail)        // upper bound of number of characters
	{
		std::ostringstream os;
		os.precision(25);		// set high precision to get enough length for floats
		os << head;
		return os.str().length() + argLength(tail...);	// add 15 for trailing zeros
	}

	template<typename... Args>
	std::string format(std::string str, Args... args)
	{
		auto argLen = argLength(args...);
		if (argLen == 0)
		{
			return str;
		}
		else
		{
			std::string result;

			auto len = str.length() + argLength(args...);
			result.resize(len + 1);
			snprintf(result.data(), len + 1, str.c_str(), args...);

			return result;
		}
	}
	template<typename T>
	static bool isWhitespace(T* const str)
	{
		return *str == ' ' || *str == '\t' || *str == '\n';
	}
}