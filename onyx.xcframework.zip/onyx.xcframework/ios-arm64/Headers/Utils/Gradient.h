#ifndef __COLOR_Line_H__
#define __COLOR_Line_H__

#include <vector>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Utils {

	class Gradient
	{
	public:

		struct Stop
		{
			lucid::gal::Map3D_float_t time;
			lucid::gal::Color color;			// color value at time

			inline bool operator==(Stop const& rhs)
			{
				return time == rhs.time
					&& color == rhs.color;
			}

			inline bool operator!=(Stop const& rhs)
			{
				return !((*this) == rhs);
			}
		};

		enum class Mode
		{
			LINEAR,
			NEAREST
		};

		Gradient();
		Gradient(std::vector<Stop> const& points);

		lucid::gal::Color sample(lucid::gal::Map3D_float_t t, bool wrap = false, Mode mode = Mode::LINEAR);

		inline bool operator==(Gradient const& rhs)
		{
			if (mStops.size() != rhs.mStops.size())
			{
				return false;
			}

			auto s1 = mStops.begin();
			auto s2 = rhs.mStops.begin();
			
			for (; s1 != mStops.end(); s1++, s2++)
			{
				if (*s1 != *s2)
					return false;
			}

			return true;
		}

	private:

		std::vector<Stop> mStops;

		lucid::gal::Color linearSample(lucid::gal::Map3D_float_t t, bool wrap);
		lucid::gal::Color nearestSample(lucid::gal::Map3D_float_t t, bool wrap);

	};

} }

#endif