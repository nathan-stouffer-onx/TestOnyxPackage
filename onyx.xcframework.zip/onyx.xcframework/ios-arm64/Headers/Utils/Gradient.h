#ifndef __COLOR_Line_H__
#define __COLOR_Line_H__

#include <vector>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Utils {

	class Gradient
	{
	public:

		struct Stop
		{
			time_float_t time;
			lgal::Color color;			// color value at time

			inline bool operator==(Stop const& rhs) const
			{
				return time == rhs.time
					&& color == rhs.color;
			}

			inline bool operator!=(Stop const& rhs) const
			{
				return !((*this) == rhs);
			}
		};

		enum class Mode
		{
			LINEAR,
			NEAREST
		};

		Gradient();
		Gradient(std::vector<Stop> const& stops, time_float_t period = time_float_t(0));

		lgal::Color sample(time_float_t t, Mode mode = Mode::LINEAR);

		inline bool operator==(Gradient const& rhs) const
		{
			if (mStops.size() != rhs.mStops.size())
			{
				return false;
			}

			if (mPeriod != rhs.mPeriod)
			{
				return false;
			}

			auto s1 = mStops.begin();
			auto s2 = rhs.mStops.begin();
			
			for (; s1 != mStops.end(); s1++, s2++)
			{
				if (*s1 != *s2)
					return false;
			}

			return true;
		}

		Gradient scaleOpacity(float scalar) const;

		Gradient operator*(time_float_t const scalar) const;

	private:

		std::vector<Stop> mStops;
		time_float_t mPeriod = 0;

		lgal::Color linearSample(time_float_t t);
		lgal::Color nearestSample(time_float_t t);

	};

	inline Gradient operator*(time_float_t const scalar, Utils::Gradient const& gradient)
	{
		return gradient * scalar;
	}

} }

#endif