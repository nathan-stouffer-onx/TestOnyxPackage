#include "Precache.h"

#include "Pyramid/Culling.h"

namespace onyx::Utils::Precaching
{

TileVisibilityList getVisibleTiles(Camera::CameraController& controller, time_float_t durationMS, time_float_t timeStartOffsetMS, Tiles::TileId::IdCoordsT parentLevel, time_float_t frameTimeMS, time_float_t timeGapThresholdMS, Atlases::HeightAtlas const *heightAtlas, VisibilityFilter filter)
{
	TileVisibilityList result;

	getVisibleTiles(result, controller, durationMS, timeStartOffsetMS, parentLevel, frameTimeMS, timeGapThresholdMS, heightAtlas, filter);

	return result;
}

void getVisibleTiles(TileVisibilityList &target, Camera::CameraController& controller, time_float_t durationMS, time_float_t timeStartOffsetMS, Tiles::TileId::IdCoordsT parentLevel, time_float_t frameTimeMS, time_float_t timeGapThresholdMS, Atlases::HeightAtlas const* heightAtlas, VisibilityFilter filter)
{
	Camera::CameraController::ControllerOptions options = { {}, 0, nullptr, 1. };

	Camera::CameraState camState = {};

	time_float_t ticks = 0.;
	TileVisibilityMap tileMap;
	do
	{
		options.timeMS = ticks * frameTimeMS + timeStartOffsetMS;
		ticks += 1.;

		camState = controller.update(options);

		Pyramid::CullResult cullRes = Pyramid::cull(camState, 1.0f, 18, nullptr, heightAtlas, 1.f);

		for (auto const& tileId : cullRes.tileIds)
		{
			for (Tiles::TileId::IdCoordsT level = 0; level <= parentLevel; ++level)
			{
				auto parent = level > 0 ? tileId.parent(level) : tileId;

				auto found = tileMap.find(parent);
				if (found == tileMap.end())
				{
					tileMap.emplace(parent, TileVisibility{ parent, { 1, { options.timeMS, options.timeMS } } });
				}
				else
				{
					if (found->second.visibility.whenSeen.end == options.timeMS)
					{	// Tile has already been seen this frame
						continue;
					}
					TileVisibility& tileVis = found->second;
					if (tileVis.visibility.whenSeen.end >= options.timeMS - timeGapThresholdMS) // If it has been seen within gap threshold, update it
					{
						tileVis.visibility.whenSeen.end = options.timeMS;
						++tileVis.visibility.timesSeen;
					}
					else // Add it to the list of visible tiles and create a new entry
					{
						if (filter == nullptr || filter(tileVis.visibility))
						{
							target.push_back(tileVis);
						}
						tileVis.visibility = Visibility{ 1, { options.timeMS, options.timeMS } };
					}
				}
			}
		}

	} while (options.timeMS <= durationMS + timeStartOffsetMS);
	
	target.reserve(tileMap.size() + target.size());
	for (auto const& tile : tileMap)
	{
		if (filter == nullptr || filter(tile.second.visibility))
		{
			target.push_back(tile.second);
		}
	}

	std::sort(target.begin(), target.end(),
		[&](TileVisibility const& t1, TileVisibility const& t2) -> bool {

			if (t1.visibility.whenSeen.begin != t2.visibility.whenSeen.begin)
			{
				return t1.visibility.whenSeen.begin < t2.visibility.whenSeen.begin;
			}
			return t1.visibility.whenSeen.end < t2.visibility.whenSeen.end;
		});
}

KeyVisibilityList getVisibleCacheEntries(TileVisibilityList const& visibleTiles, Styling::Style const& style)
{
	KeyVisibilityList result;

	getVisibleCacheEntries(result, visibleTiles, style);
	return result;
}

void getVisibleCacheEntries(KeyVisibilityList& entries, TileVisibilityList const& visibleTiles, Styling::Style const& style)
{
	for (auto const& src : style.activeSources())
	{
		for (auto const& tile : visibleTiles)
		{
			entries.push_back(VisibilityKey{ { src, tile.tileId }, tile.visibility });
		}
	}
}

Precacher::Precacher(Camera::CameraController& controller, time_float_t durationMS, time_float_t timeStartOffsetMS, Styling::Style const& style, Tiles::TileId::IdCoordsT parentLevel, time_float_t frameTimeMS, time_float_t timeGapThresholdMS, onyx::Atlases::HeightAtlas const* heightAtlas)
{
	getVisibleTiles(mVisibilityList, controller, durationMS, timeStartOffsetMS, parentLevel, frameTimeMS, timeGapThresholdMS, heightAtlas, [](Visibility vis) {
		return vis.timesSeen > 30;
		});
	getVisibleCacheEntries(mKeysList, mVisibilityList, style);

	std::sort(mKeysList.begin(), mKeysList.end(),
		[&](VisibilityKey const& t1, VisibilityKey const& t2) -> bool {
		
			if (t1.visibility.whenSeen.begin != t2.visibility.whenSeen.begin)
			{
				return t1.visibility.whenSeen.begin < t2.visibility.whenSeen.begin;
			}
			return t1.visibility.whenSeen.end < t2.visibility.whenSeen.end;
		});

}

void Precacher::getVisibleKeys(KeyVisibilityList& target, lgal::time::Range const& whenMS)
{
	target.reserve(mKeysList.size());
	for (auto const& key : mKeysList)
	{
		if (key.visibility.isSeen(whenMS))
		{
			target.push_back(key);
		}

		if (key.visibility.whenSeen.begin > whenMS.end)
		{	// Everything should be sorted by begin time, so if the current begin time is after
			// the interval end time, no other tiles will be seen during the interval.
			break;
		}
	}
}

}