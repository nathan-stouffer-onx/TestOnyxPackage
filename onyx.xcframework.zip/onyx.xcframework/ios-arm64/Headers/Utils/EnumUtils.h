#ifndef _ENUM_UTILS_H
#define _ENUM_UTILS_H
#pragma once

#include <unordered_map>

#include <System/Map3DException.h>

#include "Utils/StringUtils.h"

namespace onyx {
namespace Utils {

	template<typename T>
	T typeFromMap(std::string_view const enumName, std::unordered_map<std::string_view, T> const& nameMap, std::string_view const enumTypeName)
	{
		std::string lower(enumName);
		std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return (unsigned char)std::tolower(c); });

		auto found = nameMap.find(lower);
		MAP3D_ASSERT(found != nameMap.end(), std::string("Unrecognized string for ") + std::string(enumTypeName) + " '" + std::string(enumName) + "'");
		return found->second;
	}

	template<typename T>
	std::string_view stringViewFromMap(T enumValue, std::unordered_map<T, std::string_view> const& typeMap, std::string_view const enumTypeName)
	{
		auto found = typeMap.find(enumValue);
		MAP3D_ASSERT(found != typeMap.end(), std::string("Unrecognized value for ") + std::string(enumTypeName) + " '" + std::to_string(int(enumValue)) + "'");
		return found->second;
	}

	template<typename T>
	T typeFromMap(std::string const& enumName, std::unordered_map<std::string, T> const& nameMap, std::string const& enumTypeName)
	{
		std::string lower(enumName);
		std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return (unsigned char)std::tolower(c); });

		auto found = nameMap.find(lower);
		MAP3D_ASSERT(found != nameMap.end(), std::string("Unrecognized string for ") + enumTypeName + " '" + enumName + "'");
		return found->second;
	}

	template<typename T>
	std::string stringFromMap(T enumValue, std::unordered_map<T, std::string> const& typeMap, std::string const& enumTypeName)
	{
		auto found = typeMap.find(enumValue);
		MAP3D_ASSERT(found != typeMap.end(), std::string("Unrecognized value for ") + enumTypeName + " '" + std::to_string(int(enumValue)) + "'");
		return found->second;
	}

} }

namespace std
{

	template <typename T>
	inline T fromStringView(std::string_view const /* name */) = delete;
/* {
		// these static_asserts can be handy for tracking down unspecialized fromStringView usages at compile time
#if defined(__FUNCSIG__)
		static_assert(false, "fromStringView not implemented for type: " __FUNCSIG__);
#elif defined(__PRETTY_FUNC__)
		static_assert(false, "fromStringView not implemented for type: " __PRETTY_FUNC__);
#elif defined(__PRETTY_FUNCTION__)
		static_assert(false, "fromStringView not implemented for type: " __PRETTY_FUNCTION__);
#else
		static_assert(false, "fromStringView not implemented for type");
#endif
	}
	*/
}

namespace onyx {
namespace Utils {

	template<typename T>
	struct EnumStringConverter
	{
		static T convert(std::string_view const& view) {
			return std::fromStringView<T>(view);
		}
	};

	template<typename T>
	T flagsEnumTypeFromString(std::string_view const& value)
	{
		T result = T(0);

		if (value.empty())
		{
			return result;
		}

		size_t begin = 0;
		auto loc = value.find('|');

		while (loc != std::string::npos)
		{
			std::string_view subst = trim(value.substr(begin, loc - begin));

			result |= std::fromStringView<T>(subst);

			begin = loc + 1;
			loc = value.find('|', begin);
		}
		if (begin != 0)
		{
			result |= std::fromStringView<T>(trim(value.substr(begin)));
		}
		else
		{
			result |= std::fromStringView<T>(value);
		}
		return result;
	}

} }

#endif