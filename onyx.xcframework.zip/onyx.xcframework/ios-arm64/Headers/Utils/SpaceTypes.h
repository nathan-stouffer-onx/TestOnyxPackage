#pragma once
#if !defined(SPACE_TYPES_H)
#define SPACE_TYPES_H

namespace onyx {
namespace Utils {

	enum class SpaceTypes
	{
		ScreenPx = 0,
		Tile = 1,
		World = 2,
		WorldXY = 3,
		LatLon = 4
	};

} }

#endif