#pragma once

#include <Utils/EnumUtils.h>

namespace onyx::Utils {

	enum class SpaceTypes
	{
		ScreenPx = 0,
		Tile = 1,
		World = 2,
		WorldXY = 3,
		LatLon = 4
	};

}

namespace std
{

	template<>
	inline onyx::Utils::SpaceTypes fromStringView(std::string_view const name)
	{
		static std::unordered_map<std::string_view, onyx::Utils::SpaceTypes> const nameMap =
		{
			{ "ScreenPx",	onyx::Utils::SpaceTypes::ScreenPx		},
			{ "Tile",		onyx::Utils::SpaceTypes::Tile			},
			{ "World",		onyx::Utils::SpaceTypes::World			},
			{ "WorldXY",	onyx::Utils::SpaceTypes::WorldXY		},
			{ "LatLon",		onyx::Utils::SpaceTypes::LatLon			}
		};
		return onyx::Utils::typeFromMap(name, nameMap, "enum Utils::SpaceTypes");
	}

	inline std::string_view toStringView(onyx::Utils::SpaceTypes value)
	{
		static std::unordered_map<onyx::Utils::SpaceTypes, std::string_view> const nameMap =
		{
			{ onyx::Utils::SpaceTypes::ScreenPx,	"ScreenPx"	},
			{ onyx::Utils::SpaceTypes::Tile,		"Tile"		},
			{ onyx::Utils::SpaceTypes::World,		"World"		},
			{ onyx::Utils::SpaceTypes::WorldXY,		"WorldXY"	},
			{ onyx::Utils::SpaceTypes::LatLon,		"LatLon"	}
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Utils::SpaceTypes");
	}
	

}

