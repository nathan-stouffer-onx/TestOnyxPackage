#pragma once

#include <limits>
#include <bitset>

namespace std
{

	inline bool operator<(std::bitset<128> const& lhs, std::bitset<128> const& rhs)
	{
		// first check the 64 most significant bits
		uint64_t l = (lhs >> 64).to_ullong();
		uint64_t r = (rhs >> 64).to_ullong();
		if (l != r) { return l < r; }

		// then check the 64 least significant bits
		std::bitset<128> constexpr mask = std::numeric_limits<uint64_t>::max();
		l = (lhs & mask).to_ullong();
		r = (rhs & mask).to_ullong();

		return l < r;
	}

}

namespace onyx::Utils
{

	struct UUID
	{
		union {
			std::bitset<128> bits;
			struct {
				uint64_t low;
				uint64_t high;
			};
		};

		UUID() : bits(0) {}
		UUID(std::bitset<128> const& bits_) : bits(bits_) {}
		
		UUID(uint64_t const& low, uint64_t const& high) : bits(high)
		{
			bits <<= 64;
			bits |= low;
		}

		template<typename T>
		UUID(T const& value) : bits(value) {}

		inline operator std::bitset<128>() const
		{
			return bits;
		}

		template<typename T>
		inline UUID operator<<(T shift) const
		{
			return UUID(bits << shift);
		}

		inline UUID operator|(UUID const& rhs) const
		{
			return UUID(bits | rhs.bits);
		}

		inline void operator|=(UUID const& rhs)
		{
			bits |= rhs.bits;
		}
	};


//	using UUID = std::bitset<128>;

	inline UUID const nullUuid() { return { 0 }; };
	inline bool isNull(UUID uuid) { return uuid.bits == nullUuid().bits; }

	inline bool operator<(UUID const& lhs, UUID const& rhs)
	{
		return lhs.bits < rhs.bits;
	}

	inline bool operator==(UUID const& lhs, UUID const& rhs)
	{
		return lhs.bits == rhs.bits;
	}
}

namespace std
{
	template<>
	struct hash<onyx::Utils::UUID>
	{
	public:
		inline size_t operator()(onyx::Utils::UUID const& uuid) const
		{
			return std::hash<std::bitset<128>>()(uuid.bits);
		}
	};

}