#pragma once

#include <limits>
#include <bitset>

namespace onyx::Utils
{

	using UUID = std::bitset<128>;

	inline UUID const nullUuid() { return { 0 }; };
	inline bool isNull(UUID uuid) { return uuid == nullUuid(); }
			
}

namespace std
{

	inline bool operator<(std::bitset<128> const& lhs, std::bitset<128> const& rhs)
	{
		// first check the 64 most significant bits
		uint64_t l = (lhs >> 64).to_ullong();
		uint64_t r = (rhs >> 64).to_ullong();
		if (l != r) { return l < r; }

		// then check the 64 least significant bits
		std::bitset<128> constexpr mask = std::numeric_limits<uint64_t>::max();
		l = (lhs & mask).to_ullong();
		r = (rhs & mask).to_ullong();

		return l < r;
	}

}