#pragma once
#if !defined(__PROPERTY_H)
#define __PROPERTY_H

/*

A couple of macro definitions to clean up some boilerplate for declaring
private member variables and creating a getter/setter for them.

The GET_SET_PROP variant declares the X member variable and both getX and
setX functions, with the setX function calling through to a propertyChanged
function to let the object respond to value changes.

The GET_PROP variant only declares the X member variable and the getX function

*/

#define GET_SET_PROP(propName, typeName, defaultValue) private: typeName m##propName = defaultValue;\
public: inline typeName get##propName() const { return m##propName; }\
inline void set##propName(typeName value)\
{\
	if (m##propName == value) return;\
	m##propName = value;\
	propertyChanged(#propName);\
}

#define GET_SET_VALUE(propName, typeName, defaultValue) private: typeName m##propName = defaultValue;\
public: inline typeName get##propName() const { return m##propName; }\
inline void set##propName(typeName value)\
{\
	m##propName = value;\
}

#define GET_PROP(propName, typeName, defaultValue) private: typeName m##propName = defaultValue;\
public: inline typeName get##propName() const { return m##propName; }

#endif
