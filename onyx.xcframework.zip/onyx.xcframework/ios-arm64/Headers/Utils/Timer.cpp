#include "Timer.h"

namespace onyx {
namespace Utils {

double Timer::sFreq = std::numeric_limits<time_float_t>::min();

void Timer::initialize()
{
	sFreq = time_float_t(1.0 / bx::getHPFrequency());
}

} }
