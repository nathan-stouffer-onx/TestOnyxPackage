#pragma once

#include <json/jsonParsing.h>

#include "DataObjects/Waypoint.h"
#include "DataObjects/WaypointManager.h"
#include "Utils/BgfxUtils.h"
#include "Utils/EnumsStructs.h"
#include "Utils/MapMath.h"
#include "Viewport/ViewportState.h"

template <typename T>
inline void to_json(nlohmann::json& j, const onyx::Atlases::Atlas<T>* atlas)
{
    j = atlas->getJson();
}

namespace onyx {

	void from_json(const nlohmann::json& j, ViewportState& vp);
	void to_json(nlohmann::json& j, const ViewportState& vp);

	void to_json(nlohmann::json& j, const JulianDate& step);
	void from_json(const nlohmann::json& j, JulianDate& step);

}