#pragma once
#if !defined(__LOWPASS_H)
#define __LOWPASS_H

template <typename T, int DIM>
class LowpassFilter
{
private:
	size_t mPos = 0;
	size_t mCount = 0;
	T mData[DIM] = { 0 };

public:

	inline T last() const
	{
		// mPos is the first available slot, so we want the previous value (if it exists)
		return (mCount > 0) ? mData[(mPos + size_t(DIM - 1)) % DIM] : -1;
	}

	void insert(T value)
	{
		mData[mPos] = value;
		if (mCount < DIM)
		{
			++mCount;
		}

		++mPos;
		if (mPos >= DIM)
		{
			mPos = 0;
		}
	}

	T avg() const
	{
		T value = 0;
		for (size_t i = 0; i < mCount; ++i)
			value += mData[i];
		return value / mCount;
	}

	bool primed() { return mCount == DIM; }
};

#endif
