#ifndef __BITWISE_ENUM_OPERATORS__
#define __BITWISE_ENUM_OPERATORS__

#define PPCAT_NX(A, B) A ## B
#define PPCAT(A, B) PPCAT_NX(A, B)
// bitwise operators
#define _FN_OR |
#define _FN_AND &
#define _FN_XOR ^
#define _FN_NEG ~
#define _FN_NOT !
#define _FN_EQ ==
#define _FN_NEQ !=
#define _FN_ASSIGN =
#define _ASSIGN_FUNC_(TYPE, _FUNC_) static inline TYPE& operator PPCAT(_FUNC_,  _FN_ASSIGN) (TYPE &lhs, TYPE const rhs) { lhs = lhs _FUNC_ rhs; return lhs; }

#define _OPERATOR_FUNC_(TYPE, UNDERLYING_TYPE, _FUNC_) static inline TYPE operator _FUNC_ (TYPE const lhs, TYPE const rhs) { return static_cast<TYPE>(static_cast<UNDERLYING_TYPE>(lhs) _FUNC_ static_cast<UNDERLYING_TYPE>(rhs)); }

#define _EQ_FUNC_(TYPE, UNDERLYING_TYPE, _FUNC_) static inline bool operator _FUNC_(TYPE const lhs, TYPE const rhs) { return static_cast<UNDERLYING_TYPE>(lhs) _FUNC_ static_cast<UNDERLYING_TYPE>(rhs); } \
static inline bool operator _FUNC_(TYPE const lhs, UNDERLYING_TYPE const rhs) { return static_cast<UNDERLYING_TYPE>(lhs) _FUNC_ rhs; } \
static inline bool operator _FUNC_(UNDERLYING_TYPE const lhs, TYPE const rhs) { return static_cast<UNDERLYING_TYPE>(lhs) _FUNC_ static_cast<UNDERLYING_TYPE>(rhs); }

#define _FLAGS_ENUM_CLASS_BITWISE_OPERATORS(TYPE)\
using __U_T_##TYPE = std::underlying_type_t<TYPE>; \
_OPERATOR_FUNC_(TYPE, __U_T_##TYPE, _FN_OR) \
_ASSIGN_FUNC_(TYPE, _FN_OR) \
_OPERATOR_FUNC_(TYPE, __U_T_##TYPE, _FN_AND) \
_ASSIGN_FUNC_(TYPE, _FN_AND) \
_OPERATOR_FUNC_(TYPE, __U_T_##TYPE, _FN_XOR) \
_ASSIGN_FUNC_(TYPE, _FN_XOR) \
_EQ_FUNC_(TYPE, __U_T_##TYPE, _FN_EQ) \
_EQ_FUNC_(TYPE, __U_T_##TYPE, _FN_NEQ) \
static inline bool operator ! (TYPE rhs) { return !static_cast<__U_T_##TYPE>(rhs); } \
static inline TYPE operator ~ (TYPE rhs) { return static_cast<TYPE>(~static_cast<__U_T_##TYPE>(rhs)); }


#endif