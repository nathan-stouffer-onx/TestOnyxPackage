#ifndef __MEMORY_UTILS_H__
#define __MEMORY_UTILS_H__

#include <vector>
#include <memory>

namespace onyx {
namespace Utils {

	template<typename T>
	size_t countBytes(std::vector<T> const& items)
	{
		size_t count = (items.capacity() - items.size()) * sizeof(T);
		for (T const& item : items)
		{
			count += item.byteCount();
		}
		return count;
	}

	template<typename T>
	size_t countBytes(std::vector<T*> const& items)
	{
		size_t count = sizeof(T) * items.capacity();
		for (T* item : items)
		{
			count += item->byteCount();
		}
		return count;
	}

	template<typename T>
	size_t countBytes(std::vector<std::shared_ptr<T>> const& items)
	{
		size_t count = sizeof(T) * items.capacity();
		for (std::shared_ptr<T> const& item : items)
		{
			count += item->byteCount();
		}
		return count;
	}

	template<typename T>
	size_t countBytes(std::vector<std::unique_ptr<T>> const& items)
	{
		size_t count = sizeof(T) * items.capacity();
		for (std::unique_ptr<T> const& item : items)
		{
			count += item->byteCount();
		}
		return count;
	}

} }

#endif