#ifndef _UNIT_H_
#define _UNIT_H_

#include "bx/math.h"
#include "bx/bx.h"

class Unit
{
public:
	enum class UnitType
	{
		centimeter,
		meter,
		kilometer,
		inch,
		foot,
		yard,
		mile
	};

	Unit(float x, UnitType unitType = UnitType::meter)
	{
		mData.x = convert(x, unitType, UnitType::meter);
		mData.y = 0;
		mData.z = 0;
		isFloat = true;
	}

	Unit(float x, float y, float z, UnitType unitType = UnitType::meter)
	{
		mData.x = convert(x, unitType, UnitType::meter);
		mData.y = convert(y, unitType, UnitType::meter);
		mData.z = convert(z, unitType, UnitType::meter);
		isFloat = false;
	}

	Unit(bx::Vec3 vec, UnitType unitType = UnitType::meter) : Unit(vec.x, vec.y, vec.z, unitType)
	{
	}


	inline void scale(float scalar) 
	{
		mData = bx::mul(mData, scalar);	
	}

	inline bool operator==(const Unit& oth) const
	{
		if (this == &oth)	// check for pointer equality
		{
			return true;
		}
		return mData.x == oth.mData.x && mData.y == oth.mData.y && mData.z == oth.mData.z;
	}
	
	//trying some trickiness from https://devblogs.microsoft.com/oldnewthing/20191106-00/?p=103066 so one function call can return float *or* vec3 depending on what was set

	inline auto centimeters()
	{
		struct result
		{
			operator float()
			{
				return unit->centimetersFloat();
			}

			operator bx::Vec3()
			{
				return unit->centimetersVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}

	inline auto meters()
	{
		struct result
		{
			operator float()
			{
				return unit->metersFloat();
			}

			operator bx::Vec3()
			{
				return unit->metersVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}

	inline auto kilometers()
	{
		struct result
		{
			operator float()
			{
				return unit->kilometersFloat();
			}

			operator bx::Vec3()
			{
				return unit->kilometersVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}


	inline auto inches()
	{
		struct result
		{
			operator float()
			{
				return unit->inchesFloat();
			}

			operator bx::Vec3()
			{
				return unit->inchesVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}

	inline auto feet()
	{
		struct result
		{
			operator float()
			{
				return unit->feetFloat();
			}

			operator bx::Vec3()
			{
				return unit->feetVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}
	
	inline auto yards()
	{
		struct result
		{
			operator float()
			{
				return unit->yardsFloat();
			}

			operator bx::Vec3()
			{
				return unit->yardsVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}

	inline auto miles()
	{
		struct result
		{
			operator float()
			{
				return unit->milesFloat();
			}

			operator bx::Vec3()
			{
				return unit->milesVec3();
			}

			Unit* unit;
		};

		return result{ this };
	}

	inline void set(float x, UnitType inUnit = UnitType::meter)
	{
		mData.x = convert(x, inUnit, UnitType::meter);
	}

	inline void set(float x, float y, float z, UnitType inUnit = UnitType::meter)
	{
		mData.x = convert(x, inUnit, UnitType::meter);
		mData.y = convert(y, inUnit, UnitType::meter);
		mData.z = convert(z, inUnit, UnitType::meter);
	}

	inline void set(bx::Vec3 vec, UnitType inUnit = UnitType::meter)
	{
		set(vec.x, vec.y, vec.z, inUnit);
	}
	
protected:
	inline float centimetersFloat()
	{
		return convert(mData.x, UnitType::meter, UnitType::centimeter);
	}

	inline float metersFloat()
	{
		return mData.x;
	}

	inline float kilometersFloat()
	{
		return convert(mData.x, UnitType::meter, UnitType::kilometer);
	}

	inline float inchesFloat()
	{
		return convert(mData.x, UnitType::meter, UnitType::inch);
	}

	inline float feetFloat()
	{
		return convert(mData.x, UnitType::meter, UnitType::foot);
	}

	inline float yardsFloat()
	{
		return convert(mData.x, UnitType::meter, UnitType::yard);
	}

	inline float milesFloat()
	{
		return convert(mData.x, UnitType::meter, UnitType::mile);
	}

	inline bx::Vec3 centimetersVec3()
	{
		return convert(mData, UnitType::meter, UnitType::centimeter);
	}

	inline bx::Vec3 metersVec3()
	{
		return mData;
	}

	inline bx::Vec3 kilometersVec3()
	{
		return convert(mData, UnitType::meter, UnitType::kilometer);
	}

	inline bx::Vec3 inchesVec3()
	{
		return convert(mData, UnitType::meter, UnitType::inch);
	}

	inline bx::Vec3 feetVec3()
	{
		return convert(mData, UnitType::meter, UnitType::foot);
	}

	inline bx::Vec3 yardsVec3()
	{
		return convert(mData, UnitType::meter, UnitType::yard);
	}

	inline bx::Vec3 milesVec3()
	{
		return convert(mData, UnitType::meter, UnitType::mile);
	}


private:
	bx::Vec3 mData = bx::Vec3(0); //stores in meters by default

	bool isFloat = true;

	inline bx::Vec3 convert(bx::Vec3 val, UnitType inUnit, UnitType outUnit)
	{
		return bx::Vec3(convert(val.x, inUnit, outUnit), convert(val.y, inUnit, outUnit), convert(val.z, inUnit, outUnit));
	}

	inline float convert(float val, UnitType inUnit, UnitType outUnit)
	{
		float inToMeters = unitToMeters(inUnit);
		float metersToOut = 1.0f / unitToMeters(outUnit);

		return val * inToMeters * metersToOut;
	}

	inline float unitToMeters(UnitType unit)
	{
		switch (unit)
		{
		case(UnitType::centimeter):
			return 0.01f;
		case(UnitType::meter): 
			return 1.0f;
		case(UnitType::kilometer):
			return 1000.0f;
		case(UnitType::inch):
			return 0.0254;
		case(UnitType::foot):
			return 0.3048f;
		case(UnitType::yard):
			return 0.9144f;
		case(UnitType::mile):
			return 1609.344f;
		}

		return 1;
	}

};

#endif