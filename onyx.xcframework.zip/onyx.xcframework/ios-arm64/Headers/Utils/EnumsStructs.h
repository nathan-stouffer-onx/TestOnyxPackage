#pragma once

#include <Styling/Styles/ShadowConfigs.h>

// TODO see if we can delete this
enum class TextureType
{
	Basemap,
	Basemap2,
	Height,
	Weather,
	Roads,
	LocalData,
	Count
};

namespace onyx {

	// On UTC
	struct JulianDate
	{
		int year = 2010;
		int month = 0;
		int day = 0;
		float hours24 = 0.0; // 0-24

		JulianDate() = default;
		JulianDate(Styling::SunlightConfig const& config) : year(config.year), month(config.month), day(config.day), hours24(config.hour24) {}

		double getJulianCentury() const
		{
			int years = year - 1900;
			int leapYears = years / 4;
			int days = years * 365 + leapYears;
			int monthDays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
			for (int i = 0; i < month - 1; i++)
				days += monthDays[i];
			if (year % 4 == 0 && days >= 59)
				days++; //add this years leap day
			days += day + 2; //why plus 2? not sure, but it fixed the math, I somehow lost two days...
			double julianDays = days + 2415018.5f;
			julianDays += hours24 / 24.0f;

			return (julianDays - 2451545) / 36525;
		}

		bool operator==(const JulianDate& jd)
		{
			return hours24 == jd.hours24
				&& year == jd.year
				&& month == jd.month
				&& day == jd.day;
		}

		bool operator!=(const JulianDate& jd)
		{
			return !(*this == jd);
		}

	};

}