#include "jsonConversion.h"

#include <lucid/lucidJsonParsing.h>
#include <json/ShaderLib.h>

void from_json(const nlohmann::json& j, WaypointManager::sharedWaypoint_t& wp)
{
	onyx::Utils::UUID uuid = onyx::Utils::uuid(j["uuid"]);
	wp = std::make_shared<Waypoint>(uuid);

	auto &coords = j["geo_json"]["geometry"]["coordinates"];
	auto worldXY = onyx::MapMath::LonLat(coords[0], coords[1]).toWorldPos().as<float32_t>();
	auto worldZ = static_cast<world_float_t>(coords[2]) * 0.001f;		// divide by 1000 to convert from meters to km
	wp->setPosition({ worldXY.x, worldXY.y, worldZ });

	float radius = 0.f;
	if (j["geo_json"]["properties"].contains("range_radius"))
	{
		radius = j["geo_json"]["properties"]["range_radius"]["distance"];
	}
	wp->setRadius(radius);

	wp->setIcon(j["geo_json"]["properties"]["icon"]);

	auto &colorArr = j["color"];				// array is of the form rgba (rgb are ints, a is a float)
	lgal::Color color = { (float)colorArr[0] / 255.0f, (float)colorArr[1] / 255.0f, (float)colorArr[2] / 255.0f, (float)colorArr[3] };

	wp->setBodyColor(color);
}

void to_json(nlohmann::json& j, const WaypointManager::sharedWaypoint_t& wp)
{
	int intR = static_cast<int>(wp->getBodyColor().r * 255.0f);
	int intG = static_cast<int>(wp->getBodyColor().r * 255.0f);
	int intB = static_cast<int>(wp->getBodyColor().r * 255.0f);
	j["color"] = nlohmann::json::array({ intR, intG, intB, wp->getBodyColor().a });	// update color

	auto pos = wp->getPosition();
	auto latLon = onyx::MapMath::LonLat(lgal::world::Vector2{ pos.x, pos.y });
	auto height = pos.z * 1000.f;					// convert from km back to meteres
	j["geo_json"]["geometry"]["coordinates"] = nlohmann::json::array({ latLon.lon, latLon.lat, height });

	j["geo_json"]["properties"]["icon"] = wp->getIcon();			// update icon type

	float radius = wp->getRadius();
	if (radius > 0.0)				// update radius
	{
		j["geo_json"]["properties"]["range_radius"]["distance"] = radius;
	}
}

namespace onyx {

#define SET_OBJECT_PROP(json, classT, propName, obj) { typedef decltype(((classT*)nullptr)->get##propName()) propT; \
		JsonParsing::SetPropIfFound<propT>(json, #propName, std::bind(&classT::set##propName, &obj, std::placeholders::_1)); }

	void from_json(const nlohmann::json& j, ViewportState& vp)
	{
		SET_OBJECT_PROP(j, ViewportState, CullingEnabled, vp);
		SET_OBJECT_PROP(j, ViewportState, QuiescenceMode, vp);
		SET_OBJECT_PROP(j, ViewportState, TileZoomRange, vp);
		SET_OBJECT_PROP(j, ViewportState, ShowFills, vp);
		SET_OBJECT_PROP(j, ViewportState, ShowLines, vp);
		SET_OBJECT_PROP(j, ViewportState, ShowRasters, vp);
		SET_OBJECT_PROP(j, ViewportState, WidthRatio, vp);
		SET_OBJECT_PROP(j, ViewportState, HeightRatio, vp);
		SET_OBJECT_PROP(j, ViewportState, PosX, vp);
		SET_OBJECT_PROP(j, ViewportState, PosY, vp);
		SET_OBJECT_PROP(j, ViewportState, SortOrder, vp);
		SET_OBJECT_PROP(j, ViewportState, LODScaler, vp);
		SET_OBJECT_PROP(j, ViewportState, VectorFadeTime, vp);
		SET_OBJECT_PROP(j, ViewportState, VectorPulseTimeMS, vp);
		SET_OBJECT_PROP(j, ViewportState, VectorPulseDelayMS, vp);
	}

	void to_json(nlohmann::json& j, const ViewportState& vp)
	{
		j["CullingEnabled"] = vp.getCullingEnabled();
		j["QuiescenceMode"] = vp.getQuiescenceMode();
		j["TileZoomRange"] = vp.getTileZoomRange();
		j["ShowRasters"] = vp.getShowRasters();
		j["ShowLines"] = vp.getShowLines();
		j["ShowFills"] = vp.getShowFills();
		j["WidthRatio"] = vp.getWidthRatio();
		j["HeightRatio"] = vp.getHeightRatio();
		j["PosX"] = vp.getPosX();
		j["PosY"] = vp.getPosY();
		j["SortOrder"] = vp.getSortOrder();
		j["LODScaler"] = vp.getLODScaler();
		j["VectorFadeTime"] = vp.getVectorFadeTime();
		j["VectorPulseTimeMS"] = vp.getVectorPulseTimeMS();
		j["VectorPulseDelayMS"] = vp.getVectorPulseDelayMS();
	}

    void to_json(nlohmann::json& j, const JulianDate& step)
    {
        j["year"] = step.year;
        j["month"] = step.month;
        j["day"] = step.day;
        j["hours24"] = step.hours24;
    }

    void from_json(const nlohmann::json& j, JulianDate& step)
    {
        JsonParsing::SetIfFound(j, "year", step.year);
        JsonParsing::SetIfFound(j, "month", step.month);
        JsonParsing::SetIfFound(j, "day", step.day);
        JsonParsing::SetIfFound(j, "hours24", step.hours24);
    }

	void from_json(const nlohmann::json& j, ConfigManager& cm)
	{
		cm.from_json(j);
	}

	void to_json(nlohmann::json& j, ConfigManager& cm)
	{
		cm.to_json(j);
	}

	void from_json(const nlohmann::json& j, ConfigHolder& ch)
	{
		//ch = new ConfigHolder();
		if (j.find("constants") != j.end())
		{
			//std::map<std::string, ConfigHolder> constants = j.at("constants").get < std::map<std::string, ConfigHolder>>();
			std::vector<ConfigHolder> constants = j.at("constants").get<std::vector<ConfigHolder>>();
			ch.mConfigVars.insert(ch.mConfigVars.begin(), constants.begin(), constants.end());
		}

		if (j.find("key") != j.end())
			ch.mKey = j["key"];
		if (j.find("valUint") != j.end())
		{
			uint32_t i = (uint32_t)j["valUint"];
			ch.uintVal = i;
			ch.mValueType = ConfigHolder::ConfigType::vUint32;
		}
		else if (j.find("valInt") != j.end())
		{
			int i = (int)j["valInt"];
			ch.intVal = i;
			ch.mValueType = ConfigHolder::ConfigType::vInt;
		}
		else if (j.find("valM3DFloat") != j.end())
		{
			world_float_t d = (double)j["valM3DFloat"];
			ch.m3dFloatVal = d;
			ch.mValueType = ConfigHolder::ConfigType::vM3DFloat;
		}
		else if (j.find("valString") != j.end())
		{
			std::string s = (std::string)j["valString"];
			ch.stringVal = s;
			ch.mValueType = ConfigHolder::ConfigType::vString;
		}
		else if (j.find("valVec2") != j.end())
		{
			lgal::world::Vector2 v2 = (lgal::world::Vector2)j["valVec2"];
			ch.vec2Val = v2;
			ch.mValueType = ConfigHolder::ConfigType::vVec2;
		}
		else if (j.find("valVec3") != j.end())
		{
			lgal::world::Vector3 v3 = (lgal::world::Vector3)j["valVec3"];
			ch.vec3Val = v3;
			ch.mValueType = ConfigHolder::ConfigType::vVec3;
		}
	}

	void to_json(nlohmann::json& j, const ConfigHolder& ch)
	{
		j["key"] = ch.mKey;
		if (ch.mConfigVars.size() > 0)
		{
			j["constants"] = ch.mConfigVars;
		}
		if (ch.mValueType == ConfigHolder::ConfigType::vUint32)
			j["valUint"] = ch.uintVal;
		else if (ch.mValueType == ConfigHolder::ConfigType::vInt)
			j["valInt"] = ch.intVal;
		else if (ch.mValueType == ConfigHolder::ConfigType::vM3DFloat)
			j["valM3DFloat"] = ch.m3dFloatVal;
		else if (ch.mValueType == ConfigHolder::ConfigType::vString)
			j["valString"] = ch.stringVal;
		else if (ch.mValueType == ConfigHolder::ConfigType::vVec2)
			j["valVec2"] = ch.vec2Val;
		else if (ch.mValueType == ConfigHolder::ConfigType::vVec3)
			j["valVec3"] = ch.vec3Val;
	}

}