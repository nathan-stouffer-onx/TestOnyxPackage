#ifndef MAP_MATH_H_
#define MAP_MATH_H_

#include <vector>

#include <lucid/gal/Types.h>

#include <Styling/Sources/TiledSources/RasterDemSource.h>

#include "Tiles/TileId.h"

namespace onyx {
namespace MapMath {

	// min/max bounds for latitude and longitude
	static constexpr world_float_t cMinLon = -180.0;
	static constexpr world_float_t cMaxLon = 180.0;
	static constexpr world_float_t cMinLat = -85.051129;
	static constexpr world_float_t cMaxLat = 85.051129;

	// min/max bounds for height in the world (measured in kilometers)
	// the min is just below Challenger Deep and the max is just above Mt Everest
	// NOTE: if these values are changed, update analogous values in Shaders/sc/OnyxFunctions.sc
	static constexpr world_float_t cMinHeight = -10.0;
	static constexpr world_float_t cMaxHeight = 9.0;

	static constexpr float cBadHeight = -1000.0;

	// TODO move these (along with the LonLat and LonLatElevation structs) to a file in lucid
	static constexpr world_float_t cEarthRadiusMeters = Tiles::cMaxExtent / 6.28318530718 * 1000.0;
	static constexpr world_float_t cOriginShift = cEarthRadiusMeters * 3.14159265359;

	static constexpr uint16_t cMaxMeshResolution = 64;

	static constexpr world_float_t metersToKilometers = 0.001;
	static constexpr world_float_t kilometersToMeters = 1000.0;

	//math for lat/lon/x/y conversions from https://www.maptiler.com/google-maps-coordinates-tile-bounds-projection/
	template <typename T>
	T LonToX(T lon)
	{
		auto x = lon * T(cOriginShift) / T(180.0);
		return x * T(0.001);
	}
	
	template <typename T>
	static T XToLon(T xKm)
	{
		auto x = xKm * T(1000.0);
		auto lon = (x / T(cOriginShift)) * T(180.0);
		return lon;
	}

	template <typename T>
	T LatToY(T lat)
	{
		// hardcode in some edge cases (+-180 for std::tan and 0 for null island accuracy)
		if (lat == T(cMinLat)) {
			return T(Tiles::cBotY);
		}
		else if (lat == 0)
		{
			return 0;
		}
		else if (lat == T(cMaxLat))
		{
			return Tiles::cTopY;
		}

		auto pi = lmath::constants::pi<T>();
		auto y = std::log(std::tan((T(90.0) + lat) * pi / T(360.0))) / (pi / T(180.0));
		y = (T)(y * cOriginShift / 180.0);

		return (T)(-y * 0.001);
	}

	template <typename T>
	static T YToLat(T yKm)
	{
		// hardcode in some edge cases (+-180 for std::tan and 0 for null island accuracy)
		if (yKm == T(Tiles::cBotY)) {
			return T(cMinLat);
		}
		else if (yKm == 0)
		{
			return 0;
		}
		else if (yKm == T(Tiles::cTopY))
		{
			return cMaxLat;
		}

		auto pi = lmath::constants::pi<T>();

		auto y = -yKm * T(1000.0);
		auto lat = (y / T(cOriginShift)) * T(180.0);
		lat = T(180.0) / pi * (T(2.0) * std::atan(std::exp(lat * pi / T(180.0))) - pi / T(2.0));
		return lat;
	}

	struct LonLat
	{
		world_float_t lon;
		world_float_t lat;

		LonLat();
		LonLat(world_float_t lon, world_float_t lat);
		LonLat(lgal::world::Vector2 const& worldPos);
		LonLat(Tiles::TileId const& tileId);

		inline bool equWeak(LonLat const& other, world_float_t const epsilon = lmath::constants::tol_tol<world_float_t>())
		{
			return std::abs(lon - other.lon) < epsilon && std::abs(lat - other.lat) < epsilon;
		}

		inline bool operator==(LonLat const& other) const
		{
			return lon == other.lon && lat == other.lat;
		}

		// Projects to web mercator coordinates
		lgal::world::Vector2 toWorldPos() const;

		// Direct conversion to lucid Vector
		inline lgal::world::Vector2 toVec2() const { return { lon, lat }; }

		Tiles::TileId containingTileId(Tiles::TileId::IdCoordsT level) const;

	};

	struct LonLatElevation
	{
		world_float_t lon;
		world_float_t lat;
		world_float_t elevation;

		LonLatElevation();
		LonLatElevation(world_float_t lon, world_float_t lat, world_float_t height);
		LonLatElevation(lgal::world::Vector3 const& worldPos);

		inline bool operator==(LonLatElevation const& other) const
		{
			return lon == other.lon && lat == other.lat && elevation == other.elevation;
		}

		lgal::world::Vector3 toWorldPos() const;

		Tiles::TileId containingTileId(Tiles::TileId::IdCoordsT level) const;

	};

	inline world_float_t mercatorDistortion(world_float_t const latDegrees)
	{
		auto const latRad = latDegrees * lmath::constants::pi<world_float_t>() / 180.0;
		return 1.0 / std::cos(latRad);
	}

	inline world_float_t mercatorDistortion(LonLat const& pos)
	{
		return mercatorDistortion(pos.lat);
	}

	inline world_float_t mercatorDistortion(lgal::world::Vector2 const& pos)
	{
		return mercatorDistortion(LonLat(pos));
	}

	inline world_float_t mercatorUndistort(world_float_t const height, world_float_t const lat)
	{
		return height / mercatorDistortion(lat);
	}

	inline lgal::world::Vector2 moduloX(lgal::world::Vector2 const& pos)
	{
		// mod x position for infinite east/west pan
		world_float_t constexpr maxX = 0.5 * Tiles::cMaxExtent;
		world_float_t constexpr divisor = 2.0 * maxX;
		world_float_t x = std::fmod(pos.x + maxX, divisor);		// modulo the shifted position
		if (x < world_float_t(0.0))								// adjust if fmod puts us in the range (divisor, 0)
		{
			x += divisor;
		}
		x -= maxX;												// shift back so null island is the origin	
		return { x, pos.y };
	}
	
	template <typename T>
	inline lmath::AABB<T, 2> toGlobeBounds(lmath::AABB<T, 2> const& bounds)
	{
		MapMath::LonLat min(bounds.min.template as<world_float_t>());
		MapMath::LonLat max(bounds.max.template as<world_float_t>());

		return { { T(min.lon), T(max.lat) }, { T(max.lon), T(min.lat) } };
	}

	template <>
	inline lmath::AABB<world_float_t, 2> toGlobeBounds(lmath::AABB<world_float_t, 2> const& bounds)
	{
		MapMath::LonLat min(bounds.min);
		MapMath::LonLat max(bounds.max);

		return { { min.lon, max.lat }, { max.lon, min.lat } };
	}

	template <typename T>
	inline lmath::AABB<T, 2> projectToMercator(lmath::AABB<T, 2> const& bounds)
	{
		MapMath::LonLat min((world_float_t)bounds.min.x, (world_float_t)bounds.min.y);
		MapMath::LonLat max((world_float_t)bounds.max.x, (world_float_t)bounds.max.y);
		
		auto sw = min.toWorldPos().as<T>();
		auto ne = max.toWorldPos().as<T>();

		return { { sw.x, ne.y }, { ne.x, sw.y } };
	}

	template <>
	inline lmath::AABB<world_float_t, 2> projectToMercator(lmath::AABB<world_float_t, 2> const& bounds)
	{
		MapMath::LonLat min(bounds.min.x, bounds.min.y);
		MapMath::LonLat max(bounds.max.x, bounds.max.y);

		auto sw = min.toWorldPos();
		auto ne = max.toWorldPos();

		return { { sw.x, ne.y }, { ne.x, sw.y } };
	}

	bool inWorldBounds(lgal::world::Vector2 const& pos);
	bool inWorldBounds(lgal::world::Vector3 const& pos);

	// returns the infimum of the set of all zoom levels for which increasing the zoom level will not affect the terrain mesh
	inline int maxDetailZoom(Styling::RasterDemSource const& source)
	{
		float res = static_cast<float>(source.tileSize);
		int beyond = std::lround(std::log2(res / cMaxMeshResolution));
		return source.maxZoom + beyond;
	}

	inline uint16_t meshResolution(Styling::RasterDemSource const& source, Tiles::TileId const& tileId)
	{
		auto infimum = maxDetailZoom(source);		// level that we start reducing mesh resolution
		auto res = cMaxMeshResolution >> std::max(0, tileId.level - infimum);
		return uint16_t(std::max(1, res));
	}
	
	// mapbox has a concept of "zoom" that is assigned to a frame. It seems to be based purely on the distance between the camera
	// eye and the look point. This is our approximation of that value
	// https://docs.mapbox.com/mapbox-gl-js/style-spec/expressions/#zoom
	world_float_t zoom(lgal::world::Vector3 const& eye, lgal::world::Vector3 const& focus);

	// NOTE: this struct is from the perspective of the origin
	struct Spherical
	{
		world_float_t heading;
		world_float_t pitch;
		world_float_t radius;

		inline bool operator==(Spherical const& b)
		{
			return lmath::equ(heading, b.heading) &&
					lmath::equ(pitch, b.pitch) &&
					lmath::equ(radius, b.radius);
		}

		lgal::world::Vector3 toEuclidean() const;
	};	

	inline world_float_t kmToMi(world_float_t km)
	{
		return km * 0.62137119223733;
	}

	inline world_float_t miToKm(world_float_t mi)
	{
		return mi * 1.609344;
	}

} }

#endif // MAP_MATH_H_