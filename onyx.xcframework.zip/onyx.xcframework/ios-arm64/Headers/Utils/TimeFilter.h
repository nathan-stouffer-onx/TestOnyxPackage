#pragma once

#include <list>

#include "Caching/LRU.h"
#include "Utils/Timer.h"

namespace onyx::Utils
{

	template <typename T>
	class TimeFilter
	{
	private:

		struct Entry
		{
			T value;
			time_float_t timeMS;
		};

		std::list<Entry> mEntries;

		time_float_t mWindowMS;

	public:

		TimeFilter(time_float_t windowMS) :
			mWindowMS(windowMS)
		{}

		void update(time_float_t timeMS)
		{
			// run loop while there are items in the list and they are outside the window
			while (!mEntries.empty())
			{
				// check if the front is outside the window
				if (mEntries.front().timeMS + mWindowMS < timeMS)
				{
					mEntries.pop_front();
				}
				else
				{
					break;
				}
			}
		}

		void push(T const value, time_float_t timeMS)
		{
			mEntries.push_back({ value, timeMS });
		}

		T avg() const
		{
			T total = T(0);
			for (auto const& entry : mEntries) { total += entry.value; }
			return mEntries.empty() ? T(0) : total / mEntries.size();
		}

	};

	template <typename KeyT>
	class KeyedTimeFilter
	{

	private:

		struct Entry
		{
			time_float_t timeMS;

			Entry(time_float_t _timeMS) : timeMS(_timeMS) {}
		};

		Caching::LRU<KeyT, Entry> mLRU;

		time_float_t mWindowMS;

	public:

		KeyedTimeFilter(time_float_t windowMS) :
			mWindowMS(windowMS)
		{}

		void update(time_float_t timeMS = Timer::nowMS())
		{
			auto end = mLRU.end();
			bool outside = true;
			// run loop while there are items in the priority queue and they are outside the window
			while (!mLRU.empty() && outside)
			{
				// grab iterator to the last item (and leave end unchanged)
				auto lastIter = (--end)++;
				// check if the item is outside the window
				if (lastIter->entry.timeMS + mWindowMS < timeMS)
				{
					mLRU.erase(lastIter->key);
				}
				else
				{
					outside = false;
				}
			}
		}

		bool contains(KeyT const& key) const { return mLRU.contains(key); }

		void insert(KeyT const& key, time_float_t timeMS = Timer::nowMS())
		{
			auto it = mLRU.find(key);
			if (it == mLRU.end())
			{
				mLRU.insert(key, Entry{ timeMS });
			}
			else
			{
				it->entry.timeMS = timeMS;
				mLRU.touch(key);
			}
		}

		// return all entries that were last touched in the range [beginMS, endMS]
		std::vector<KeyT> recent(time_float_t windowMS) const
		{
			// TODO possibly optimize allocations by finding the first/last elements in the range and computing
			// the difference between the iterators

			time_float_t endMS = Timer::nowMS();
			time_float_t beginMS = endMS - windowMS;

			std::vector<KeyT> inRange;
			// iterate over the lru (starting with the most recently touched) and test which items are in the range
			for (auto const& [key, entry] : mLRU)
			{
				if (beginMS <= entry.timeMS && entry.timeMS <= endMS)
				{
					inRange.push_back(key);
				}
			}

			return inRange;
		}

	};

}