#ifndef __TIME_FILTER_H__
#define __TIME_FILTER_H__

#include <list>
#include <unordered_map>

#include "Caching/LRU.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Utils {

	template <typename T>
	class TimeFilter
	{

	private:

		struct Entry
		{
			time_float_t timeMS;

			Entry(time_float_t _timeMS) : timeMS(_timeMS) {}
		};

		Caching::LRU<T, Entry> mLRU;

		time_float_t mWindowMS;

	public:

		TimeFilter(time_float_t windowMS) :
			mWindowMS(windowMS)
		{}

		void update(time_float_t timeMS = Timer::nowMS())
		{
			auto end = mLRU.end();
			bool outside = true;
			// run loop while there are items in the priority queue and they are outside the window
			while (mLRU.size() > 0 && outside)
			{
				// grab iterator to the last item (and leave end unchanged)
				auto lastIter = (--end)++;
				// check if the item is outside the window
				if (lastIter->entry.timeMS + mWindowMS < timeMS)
				{
					mLRU.erase(lastIter->key);
				}
				else
				{
					outside = false;
				}
			}
		}

		bool contains(T const& key) const { return mLRU.contains(key); }

		void insert(T const& key, time_float_t timeMS = Timer::nowMS())
		{
			auto it = mLRU.find(key);
			if (it == mLRU.end())
			{
				mLRU.insert(key, Entry{ timeMS });
			}
			else
			{
				it->entry.timeMS = timeMS;
				mLRU.touch(key);
			}
		}

		// return all entries that were last touched in the range [beginMS, endMS]
		std::vector<T> recent(time_float_t windowMS) const
		{
			// TODO possibly optimize allocations by finding the first/last elements in the range and computing
			// the difference between the iterators

			time_float_t endMS = Timer::nowMS();
			time_float_t beginMS = endMS - windowMS;

			std::vector<T> inRange;
			// iterate over the lru (starting with the most recently touched) and test which items are in the range
			for (auto const& [key, entry] : mLRU)
			{
				if (beginMS <= entry.timeMS && entry.timeMS <= endMS)
				{
					inRange.push_back(key);
				}
			}

			return inRange;
		}

	};

} }


#endif