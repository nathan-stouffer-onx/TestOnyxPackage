#ifndef __BGFX_UTILS_H__
#define __BGFX_UTILS_H__
#pragma once

#include <bgfx/bgfx.h>
#include <bimg/bimg.h>
#include <bx/math.h>
#include <bx/bx.h>

#include <Logging/LogManager.h>
#include <3rdParty/nlohmann/json.hpp>
#include <lucid/gal/Types.h>

namespace bgfx
{
	inline void to_json(nlohmann::json& j, const UniformHandle& uh)
	{
		j["idx"] = uh.idx;
	}
}

namespace BgfxUtils
{
	// clean up memory used by methods in BgfxUtils
	void cleanup();

	template<typename T>
	inline bx::Vec3 toBx(lucid::math::Vector<T, 3> const& rhs)
	{
		return { float(rhs.x), float(rhs.y), float(rhs.z) };
	}

	template<typename T>
	inline bx::Vec3 toBx(lucid::math::Vector<T, 2> const& rhs)
	{
		return toBx(lucid::math::Vector<T, 3>{ rhs, T(0) });
	}

	inline lgal::world::Vector3 toVec3(bx::Vec3 const& rhs)
	{
		return { rhs.x, rhs.y, rhs.z };
	}

	// Destroys bgfx object if object is valid (per bgfx parlance)
	template <typename T>
	void tryDestroy(T& toDestroy)
	{
		if (bgfx::isValid(toDestroy))
		{
			bgfx::destroy(toDestroy);
			toDestroy = BGFX_INVALID_HANDLE;
		}
	}

	template <typename T>
	void tryDestroy(T const& toDestroy)
	{
		if (bgfx::isValid(toDestroy))
		{
			bgfx::destroy(toDestroy);
		}
	}

	// functions to load textures from disk and memory
	bgfx::TextureHandle loadTexture(void* data, uint32_t size, const std::string& name, uint64_t _flags = BGFX_TEXTURE_NONE | BGFX_SAMPLER_NONE, uint8_t _skip = 0, bgfx::TextureInfo* _info = NULL, bimg::Orientation::Enum* _orientation = NULL);
	bgfx::TextureHandle loadTexture(const std::string& _name, uint64_t _flags = BGFX_TEXTURE_NONE | BGFX_SAMPLER_NONE, uint8_t _skip = 0, bgfx::TextureInfo* _info = NULL, bimg::Orientation::Enum* _orientation = NULL);

	// _dstFormat states which format to convert the image data to. The default param will not do any conversion
	bimg::ImageContainer* imageLoad(const std::string& _filePath, 
		bgfx::TextureFormat::Enum _dstFormat = bgfx::TextureFormat::Count);
	bimg::ImageContainer* imageLoad(void* data, uint32_t size);
}

#endif