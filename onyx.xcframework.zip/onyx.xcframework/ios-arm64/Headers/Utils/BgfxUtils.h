#ifndef __BGFX_UTILS_H__
#define __BGFX_UTILS_H__
#pragma once

#include <bgfx/bgfx.h>
#include <bimg/bimg.h>
#include <bx/math.h>

#include <Logging/LogManager.h>
#include <3rdParty/nlohmann/json.hpp>

namespace bx
{
	inline void to_json(nlohmann::json& j, const Vec3& vec3)
	{
		j["X"] = vec3.x;
		j["Y"] = vec3.y;
		j["Z"] = vec3.z;
	}

	inline void from_json(const nlohmann::json& j, Vec3& vec3)
	{
		j.at("X").get_to(vec3.x);
		j.at("Y").get_to(vec3.y);
		j.at("Z").get_to(vec3.z);
	}
}

namespace bgfx
{
	inline void to_json(nlohmann::json& j, const UniformHandle& uh)
	{
		j["idx"] = uh.idx;
	}
}

namespace BgfxUtils
{
	// clean up memory used by methods in BgfxUtils
	void cleanup();

	// Destroys bgfx object if object is valid (per bgfx parlance)
	template <typename T>
	void tryDestroy(T& toDestroy)
	{
		if (bgfx::isValid(toDestroy))
		{
			bgfx::destroy(toDestroy);
			toDestroy = BGFX_INVALID_HANDLE;
		}
	}

	// functions to load textures from disk and memory
	bgfx::TextureHandle loadTexture(void* data, uint32_t size, const std::string& name, uint64_t _flags = BGFX_TEXTURE_NONE | BGFX_SAMPLER_NONE, uint8_t _skip = 0, bgfx::TextureInfo* _info = NULL, bimg::Orientation::Enum* _orientation = NULL);
	bgfx::TextureHandle loadTexture(const std::string& _name, uint64_t _flags = BGFX_TEXTURE_NONE | BGFX_SAMPLER_NONE, uint8_t _skip = 0, bgfx::TextureInfo* _info = NULL, bimg::Orientation::Enum* _orientation = NULL);

	// helper functions for bx::Vec3
	inline bool equals(const bx::Vec3& lhs, const bx::Vec3& rhs, const float eps = 0)
	{
		return bx::abs(lhs.x - rhs.x) <= eps && bx::abs(lhs.y - rhs.y) <= eps && bx::abs(lhs.z - rhs.z) <= eps;
	}
	inline bool lessThan(const bx::Vec3& a, const bx::Vec3& b) { return a.x < b.x && a.y < b.y && a.z < b.z; }
	inline bool lessThanEquals(const bx::Vec3& a, const bx::Vec3& b) { return a.x <= b.x && a.y <= b.y && a.z <= b.z; }
	inline bool greaterThan(const bx::Vec3& a, const bx::Vec3& b) { return a.x > b.x && a.y > b.y && a.z > b.z; }
	inline bool greaterThanEquals(const bx::Vec3& a, const bx::Vec3& b) { return a.x >= b.x && a.y >= b.y && a.z >= b.z; }

	// _dstFormat states which format to convert the image data to. The default param will not do any conversion
	bimg::ImageContainer* imageLoad(const std::string& _filePath, 
		bgfx::TextureFormat::Enum _dstFormat = bgfx::TextureFormat::Count);
	bimg::ImageContainer* imageLoad(void* data, uint32_t size);
}

#endif