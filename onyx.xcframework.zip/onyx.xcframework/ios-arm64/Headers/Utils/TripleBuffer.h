#ifndef _TRIPLE_BUFFER_H_
#define _TRIPLE_BUFFER_H_

#include <mutex>

#include <Utils/Timer.h>

namespace onyx {
namespace Utils {

	template<typename T>
	class TripleBuffer
	{
	public:
		TripleBuffer(T const initial)
			: mV3(initial)
		{ }

		TripleBuffer() : TripleBuffer(T()) { }

		T& getWorking() { return *mWorking; }
		T const& getWorking() const { return *mWorking; }

		void setReady();
		T const& getReady() const;
		T const& getNextReady(int timeoutMS = 17) const; // 60fps wait timeout
		bool isReady() { return mIsReady; }
	private:
		T mV1,
			mV2,
			mV3;
		
		mutable T *mWorking		= &mV1,	// The current "working" value
					*mReady		= &mV2,	// The next prepared value ready to be swapped to current
					*mCurrent	= &mV3;	// The most recently retrieved "ready" value available
		mutable bool mIsReady = false;
		mutable std::condition_variable mNextIsReady;
		mutable std::mutex mSwapMutex;

		inline void Swap() const;
	};

	template<typename T>
	inline void TripleBuffer<T>::Swap() const
	{
		if (mIsReady)
		{
			std::swap(mReady, mCurrent);
			mIsReady = false;
		}
	}

	template<typename T>
	void TripleBuffer<T>::setReady()
	{
		std::lock_guard lock(mSwapMutex);
		std::swap(mWorking, mReady);
		mNextIsReady.notify_all();
		mIsReady = true;
	}

	template<typename T>
	T const& TripleBuffer<T>::getReady() const
	{
		if (mIsReady)
		{
			std::lock_guard lock(mSwapMutex);
			Swap();
		}
		return *mCurrent;
	}
	
	template<typename T>
	T const& TripleBuffer<T>::getNextReady(int timeoutMS) const
	{
		ONYX_DEBUG_ASSERT(timeoutMS > 0, "Timeouts should never be zero")
		std::unique_lock lock(mSwapMutex);
		if (!mIsReady)
		{
			auto res = mNextIsReady.wait_for(lock, std::chrono::milliseconds(timeoutMS));
			ONYX_ASSERT(res != std::cv_status::timeout, "Wait timed out.");
		}

		ONYX_DEBUG_ASSERT(mIsReady, "Next buffer isn't ready."); // Shouldn't ever be possible, but just in case...

		Swap();
		return *mCurrent;
	}

} }

#endif