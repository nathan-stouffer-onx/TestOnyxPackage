#pragma once

#include <functional>
#include <set>
#include <unordered_map>
#include <vector>

#include <lucid/gal/Types.h>
#include <Utils/Timer.h>
#include <Styling/Style.h>

#include "Camera/CameraController.h"
#include "Tiles/TileId.h"
#include "Caching/Tiles/TileCacheKey.h"

namespace onyx::Utils::Precaching
{
	constexpr Tiles::TileId::IdCoordsT cDefaultDepth = 2;

	struct Visibility
	{
		size_t timesSeen;
		lgal::time::Range whenSeen = lgal::time::Range::nothing();
		inline bool isSeen() const { return timesSeen > 0; }
		inline bool isSeen(lgal::time::Range const& when) const { return when.intersects(whenSeen); }
	};

	struct TileVisibility
	{
		Tiles::TileId tileId;
		Visibility visibility;
	};

	struct VisibilityKey
	{
		Caching::TileCacheKey key;
		Visibility visibility;
	};

	using TileVisibilityMap = std::unordered_map<Tiles::TileId, TileVisibility>;

	using CacheEntrySet = std::set<Caching::TileCacheKey>;
	using CacheEntryList = std::vector<Caching::TileCacheKey>;
	using TileVisibilityList = std::vector<TileVisibility>;
	using KeyVisibilityList = std::vector<VisibilityKey>;

	using VisibilityFilter = std::function<bool(Visibility)>;

	void getVisibleTiles(TileVisibilityList&target, Camera::CameraController& controller, time_float_t durationMS, time_float_t timeStartOffsetMS, Tiles::TileId::IdCoordsT parentLevel = cDefaultDepth, time_float_t frameTimeMS = 1000. / 60., time_float_t timeGapThresholdMS = 1000., onyx::Atlases::HeightAtlas const* heightAtlas = nullptr, VisibilityFilter filter = nullptr);

	TileVisibilityList getVisibleTiles(Camera::CameraController& controller, time_float_t durationMS, time_float_t timeStartOffsetMS, Tiles::TileId::IdCoordsT parentLevel = cDefaultDepth, time_float_t frameTimeMS = 1000. / 60., time_float_t timeGapThresholdMS = 1000., onyx::Atlases::HeightAtlas const* heightAtlas = nullptr, VisibilityFilter filter = nullptr);

	void getVisibleCacheEntries(KeyVisibilityList &entries, TileVisibilityList const& visibleTiles, Styling::Style const& style);
	KeyVisibilityList getVisibleCacheEntries(TileVisibilityList const &visibleTiles, Styling::Style const &style);

	class Precacher
	{
	public:

		Precacher(Camera::CameraController& controller, time_float_t durationMS, time_float_t timeStartOffsetMS, Styling::Style const& style, Tiles::TileId::IdCoordsT parentLevel = cDefaultDepth, time_float_t frameTimeMS = 1000. / 60., time_float_t timeGapThresholdMS = 1000., onyx::Atlases::HeightAtlas const* heightAtlas = nullptr);

		void getVisibleKeys(KeyVisibilityList& target, lgal::time::Range const& whenMS);

		LUCID_PREVENT_COPY(Precacher);
		LUCID_PREVENT_ASSIGNMENT(Precacher);

		size_t getKeyCount() const { return mKeysList.size(); }
		size_t getVisibleCount() const { return mVisibilityList.size(); }
	private:
		TileVisibilityList mVisibilityList;
		KeyVisibilityList mKeysList;
	};

}