#if !defined(CONFIGMANAGER_H_)
#define CONFIGMANAGER_H_

#include <map>
#include <vector>
#include <unordered_set>


#include <bgfx/bgfx.h>
#include <3rdParty/nlohmann/json.hpp>
#include <lucid/gal/Types.h>
#include "ConfigHolder.h"
#include "ConfigResult.h"

#define Constants(c) onyx::ConfigManager::Instance()->getConstant(c)

//adds the get pointer so ConfigManager has access to get every constant created
#define ADDCONFIGGET(type, name, key) \
	bool registeredGet##name = onyx::ConfigManager::Instance()->addGetPointer(key, [&, this](void) \
		{ \
			return onyx::ConfigResult{onyx::ConfigManager::Instance()->getConstant(key)}; \
		});

//add a function pointer that can be used to set the value of every config val that gets created, when json is loaded
#define ADDCONFIGSET(type, name, key) \
	bool registeredSet##name = onyx::ConfigManager::Instance()->addSetPointer(key, [&, this](onyx::ConfigResult cr) \
		{ \
			this->name = cr;\
		});

//add the declaration/initiliazation
#define ADDCONFIGVAR(type, name, key, defaultVal)\
	/**Config Var defined by macro**/ \
	type name = onyx::ConfigManager::Instance()->hasKey(key) ? (type)onyx::ConfigManager::Instance()->getConstant(key) : (type)defaultVal;

//used to create a *non*static configval and setup its behind the scene get and set paths for configmanager
#define CONFIGVAL(type, name, key, defaultVal) \
	ADDCONFIGVAR(type, name, key, defaultVal)\
	ADDCONFIGGET(type, name, key)\
	ADDCONFIGSET(type, name, key)


//set a function pointer to get the value of each config val that gets created
#define ADDCONFIGGETSTATIC(type, name, key) \
	static bool registeredGet##name = onyx::ConfigManager::Instance()->addGetPointer(key, [](void) -> ConfigResult \
		{ \
			return onyx::ConfigResult{onyx::ConfigManager::Instance()->getConstant(key)}; \
		});
//set the function pointer so configmanager can modify these calues when json is loaded
#define ADDCONFIGSETSTATIC(type, name, key) \
	static bool registeredSet##name = onyx::ConfigManager::Instance()->addSetPointer(key, [](onyx::ConfigResult cr) \
		{ \
			name = cr;\
		});

//declare the extern value for this variable
#define ADDCONFIGVARSTATIC(type, name)\
	extern type name; \

//call this in the header to declare the variable
#define DECLARECONFIGVALSTATIC(type, name, key) \
	ADDCONFIGVARSTATIC(type, name)\
	ADDCONFIGGETSTATIC(type, name, key) \
	ADDCONFIGSETSTATIC(type, name, key)

//call this in the cpp to initialize it, same idea as declaring a static variable and then initializing it
#define INITCONFIGVALSTATIC(type, name, key, defaultVal) \
	type name = onyx::ConfigManager::Instance()->hasKey(key) ? (type)onyx::ConfigManager::Instance()->getConstant(key) : (type)defaultVal;

namespace onyx {
	
	
	class ConfigManager {
	public:

		static ConfigManager* Instance();
		static void Shutdown();

		void loadJson();
		ConfigResult getConstant(std::string key);

		bool hasKey(std::string key);

		void from_json(const nlohmann::json& j);
		void to_json(nlohmann::json& j);

		void invalidateCache()
		{
			mCache.clear();
		}

		bool addGetPointer(std::string key, std::function<ConfigResult(void)> fn)
		{
			mConfigGetFn[key] = fn;
			return true;
		}

		bool addSetPointer(std::string key, std::function<void(ConfigResult)> fn)
		{
			mConfigSetFn[key] = fn;
			return true;
		}

		void setConfigVars()
		{
			for (auto& kvp : mConfigSetFn)
			{
				ConfigResult cr = getConstant(kvp.first);
				if(cr.ch != NULL) //make sure it exists
					kvp.second(cr);
			}
		}

		void updateConfigVars()
		{
			ConfigResult cr;
			for (auto& kvp : mConfigGetFn)
			{
				cr = kvp.second();
				if (cr.ch != NULL && mConfigSetFn.find(kvp.first) != mConfigSetFn.end())
					mConfigSetFn[kvp.first](cr);

			}
		}

		std::unordered_map<std::string, ConfigHolder> getRoot() { return mConfigHolderRoot; }

	private:

		ConfigManager() {}

		~ConfigManager()
		{
			mConfigGetFn.clear();
			mConfigSetFn.clear();
			sSingleton = nullptr;
		}

		static ConfigManager* sSingleton;

		std::map<std::string, std::function<ConfigResult(void)>> mConfigGetFn;
		std::map<std::string, std::function<void(ConfigResult)>> mConfigSetFn;

		std::unordered_map<std::string, ConfigHolder> mConfigHolderRoot;
		std::unordered_map<std::string, ConfigResult> mCache; //used for a flat key store as values are accessed
		std::vector<std::string> keyToVec(std::string key);
		std::string addConstant(std::vector<std::string> keys);
	};

} 

#endif