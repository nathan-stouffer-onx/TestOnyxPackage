#include "ConfigManager.h"

#include <Logging/LogManager.h>
#include <System/FileSystem.h>

#include "Utils/StringUtils.h"
#include "Utils/jsonConversion.h"
#include "Utils/BgfxUtils.h"

namespace onyx {

	ConfigManager* ConfigManager::sSingleton = nullptr;

	ConfigManager* ConfigManager::Instance()
	{
		if (sSingleton == nullptr)
		{
			sSingleton = new ConfigManager();
			
		}
		return sSingleton;
	}

	void ConfigManager::Shutdown()
	{
		if (sSingleton)
		{
			delete sSingleton;
			sSingleton = nullptr;
		}
	}

	std::vector<std::string> ConfigManager::keyToVec(std::string key)
	{
		auto keys = onyx::Utils::splitString(key, ':');
		if (keys.size() == 0)
		{
			logE("invalid key for getConstant");
		}

		return keys;
	}

	void ConfigManager::loadJson()
	{
		if (onyx::core::FileSystem::fileExists("assets/Config/constants.json"))
		{
			std::string constants = onyx::core::FileSystem::readText("assets/Config/constants.json");

			if (constants.length() < 1)
			{
				logE("constants.json not found or was empty");
			}
			else
			{
				from_json(nlohmann::json::parse(constants));
				updateConfigVars();
			}
		}
	}

	ConfigResult ConfigManager::getConstant(std::string key)
	{
		if (mCache.find(key) != mCache.end())
			return mCache[key];

		std::vector<std::string> keys = keyToVec(key);
		std::string first = keys[0];
		keys.erase(keys.begin());

		ConfigResult cr = ConfigResult{ mConfigHolderRoot[first].getNextHolder(keys) };
		mCache[key] = cr;
		return cr;
	}

	bool ConfigManager::hasKey(std::string key)
	{
		if (mCache.find(key) != mCache.end())
			return true;

		std::vector<std::string> keys = keyToVec(key);
		std::string first = keys[0];
		keys.erase(keys.begin());

		ConfigResult cr = ConfigResult{ mConfigHolderRoot[first].getNextHolder(keys) };
		return cr.ch != NULL;
	}

	std::string ConfigManager::addConstant(std::vector<std::string> keys)
	{
		if (mConfigHolderRoot.find(keys[0]) == mConfigHolderRoot.end())
		{
			mConfigHolderRoot[keys[0]] = ConfigHolder(keys[0]);
		}
		std::string next = keys[0];
		return next;
	}

	void ConfigManager::from_json(const nlohmann::json& j)
	{
		if (j.find("constantRoot") == j.end())
		{
			logE("constantRoot not found in constants.json");
			return;
		}
		
		std::unordered_map<std::string, ConfigHolder> root = j.at("constantRoot").get<std::unordered_map<std::string, ConfigHolder>>();
		//std::vector<ConfigHolder> root = j.at("constantRoot").get<std::vector<ConfigHolder>>();
		mConfigHolderRoot.clear();
		mConfigHolderRoot.insert(root.begin(), root.end());

		//update all the known variables
		setConfigVars();
	}

	void ConfigManager::to_json(nlohmann::json& j) 
	{
		j["constantRoot"] = mConfigHolderRoot;
	}
}
