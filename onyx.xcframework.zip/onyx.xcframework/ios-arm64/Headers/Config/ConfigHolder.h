#if !defined(CONFIGHOLDER_H_)
#define CONFIGHOLDER_H_

#include <map>
#include <vector>
#include <unordered_map>

#include <bgfx/bgfx.h>
#include <3rdParty/nlohmann/json.hpp>
#include <lucid/gal/Types.h>
namespace onyx {

	struct ConfigHolder
	{
		enum class ConfigType //rather do away with this, but not sure yet how best to do so...
		{
			vUint32,
			vInt,
			vM3DFloat,
			vString,
			vVec2, 
			vVec3,
			NotSet
		};

		ConfigHolder() {}
		ConfigHolder(std::string key);
		~ConfigHolder();

		//TODO - linux does not allow unordered_map to contain the same class its within
		//std::unordered_map<std::string, ConfigHolder> mConfigVars;
		std::string mKey = "";
		std::vector<ConfigHolder> mConfigVars;

		uint32_t uintVal = 0;
		int intVal = 0;
		lucid::gal::Map3D_float_t m3dFloatVal = 0;
		std::string stringVal = "";
		lgal::world::Vector2 vec2Val = lgal::world::Vector2();
		lgal::world::Vector3 vec3Val = lgal::world::Vector3();

		ConfigType mValueType = ConfigType::NotSet;
		ConfigHolder* getNextHolder(std::vector<std::string> key);
		auto getConstant();

		template<typename T>
		void addConstant(std::vector<std::string>& key, T val);

		int hasKey(std::string key);
	};

	template<typename T>
	void ConfigHolder::addConstant(std::vector<std::string>& key, T val)
	{
		if (key.size() == 0)
		{
			intVal = val;
			mValueType = ConfigType::vInt;
			return;
		}

		std::string next = key[0];
		int id = hasKey(key[0]);
		key.erase(key.begin());
		if (id == -1)
		{
			mConfigVars.push_back(ConfigHolder(next));
			id = (int)mConfigVars.size() - 1;
		}

		mConfigVars[id].addConstant(key, val);
	}

} 

#endif