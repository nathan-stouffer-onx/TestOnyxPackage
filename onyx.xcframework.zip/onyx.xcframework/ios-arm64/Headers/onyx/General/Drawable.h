#pragma once

#include <vector>
#include <mutex>

#include <Shaders/ShaderEnums.h>
#include <3rdParty/sole/ourSole.h>

/**
* This is an interface that is set up for any drawable object to implement. The generic type should be populated
* by a VertStruct
*
* mUuid -- uuid to identify the drawable object
* mShaderType -- enumerated type to denote which shader to use
* mVerts/mIndices -- the vertex/index buffer to draw the VectorGeometry
* mIsDirty -- indicator for whether the points defining the VectorGeometry match the values stored
*			  in mVerts/mIndices (mIsDirty == false iff points matches mVerts/Indices)
*
*/

// TODO it would be nice if we could figure out a clean way to avoid templating this class

template <typename T>
class Drawable
{
public:

	Drawable<T>(ShaderEnums::ConfigurableShaders shaderType) :
		Drawable(sole::uuid4(), shaderType)
	{}

	Drawable<T>(sole::uuid uuid, ShaderEnums::ConfigurableShaders shaderType) :
		  mUuid(uuid)
		, mShaderType(shaderType)
		, mIsDirty(true)            // default to being dirty upon construction
	{}

	virtual ~Drawable<T>()
	{
		mVerts.clear();
		mIndices.clear();
	}

	virtual void generateVertsIndices() = 0;

	std::vector<T> getVerts() const
	{
		std::vector<T> result;
		appendVertsTo(result);
		return result;
	}

	std::vector<uint16_t> getIndices()
	{
		std::vector<uint16_t> result;
		appendIndicesTo(result);
		return result;
	}

	// TODO maybe have it pass in a raw pointer
	void appendVertsTo(std::vector<T>& target) const
	{
		target.insert(target.end(), mVerts.begin(), mVerts.end());
	}

	void insertVertsAt(std::vector<T>& target, int i) const
	{
		target.insert(target.begin() + i, mVerts.begin(), mVerts.end());
	}

	void appendIndicesTo(std::vector<uint16_t>& target) const
	{
		target.insert(target.end(), mIndices.begin(), mIndices.end());
	}

	inline sole::uuid getUuid() const { return mUuid; }
	inline ShaderEnums::ConfigurableShaders getShaderType() const { return mShaderType; }

	inline void setDirty() { mIsDirty = true; }
	inline bool isDirty() const { return mIsDirty; }
	inline int numVerts() const { return (int)mVerts.size(); }
	inline int numIndices() const { return (int)mIndices.size(); }

protected:

	sole::uuid mUuid;
	ShaderEnums::ConfigurableShaders mShaderType;

	std::vector<T> mVerts;
	std::vector<uint16_t> mIndices;

	bool mIsDirty;

};
