#ifndef __HEIGHT_ATLAS_H__
#define __HEIGHT_ATLAS_H__

#include <lucid/gal/Types.h>

#include "Pyramid/TilePyramid.h"
#include "Tiles/HeightTile.h"
#include "Tiles/TileId.h"
#include "TileAtlas.h"

namespace onyx {
namespace Atlases {

	class HeightAtlas final : public TileAtlas
	{
	public:

		HeightAtlas(int maxLevel, uint32_t cellSize = cDefaultCellSize, uint32_t res = cDefaultResolution,
					uint32_t padding = cDefaultPadding, InputPadding inputPadding = {});

		// this function hides all Atlas<Tiles::TileId>::insert members so this is the only insert function that can be called 
		// on a HeightAtlas. this is usually not the desired functionality of C++. However, for this specific case, this 
		// happens to be exactly what we want. two things should be noted
		//     1. this may cause a warning in some compilers
		//     2. if you have a pointer to a base class of HeightAtlas (eg TileAtlas), the ::insert members will not be hidden
		// https://isocpp.org/wiki/faq/strange-inheritance#hiding-rule
		void insert(Tiles::TileId const& tileId, std::shared_ptr<Tiles::HeightTile> tile, bgfx::TextureHandle const& handle, bgfx::TextureFormat::Enum const format, bool dealloc = true);

		void erase(Tiles::TileId const& tileId) override;

		inline std::shared_ptr<Tiles::HeightTile const> at(Tiles::TileId const& tileId) const { return mPyramid.at(tileId); }

		inline std::shared_ptr<Tiles::HeightTile const> find(Tiles::TileId const& tileId, bool recurse) const
		{ 
			return mPyramid.find(tileId, recurse);
		}

		std::shared_ptr<Tiles::HeightTile const> highestDetailedTile(lgal::world::Vector2 const& pos) const;

		height_float_t heightAt(lgal::world::Vector2 const& pos, bool mercatorDistortion = true, bool interpolate = true) const;
		inline lgal::world::Vector3 lockToTerrain(lgal::world::Vector2 const& pos) const { return { pos, heightAt(pos) }; }

		lgal::world::Vector3 normalAt(lgal::world::Vector2 const& pos, bool interpolate = true) const;

		lgal::height::Range heightExtents(Tiles::TileId const& tileId, bool mercatorDistortion = true) const;
		lgal::height::Range heightExtents(std::vector<Tiles::TileId> const& tiles, bool mercatorDistortion = true) const;

	private:

		int const mMaxLevel;

		Pyramid::TilePyramid<Tiles::HeightTile> mPyramid;

	};

} }

#endif