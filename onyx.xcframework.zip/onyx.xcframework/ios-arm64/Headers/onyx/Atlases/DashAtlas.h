#ifndef __DASH_ATLAS_H__
#define __DASH_ATLAS_H__

#include <unordered_map>

#include <bgfx/bgfx.h>

#include <Styling/Styles/LineStyle.h>

namespace onyx {
namespace Atlases {

	/*
	* A class to store DashArrays on the gpu. It allocates a row for each DashArray and encodes on/off in the row to integer
	* precision (eg 2 pixels on, 3 pixels off, 1 pixel on, 2 pixels off). It also packs the length of the DashArray in the
	* first pixel of the row.
	* 
	* This atlas is not very smart about allocating space. Even if a DashArray just uses one pixel, the atlas will mark the
	* entire row as "used."
	* 
	* NOTE: because we want to be able to draw all vector styles in the same draw call, this is not a multipaged atlas
	*/

	class DashAtlas
	{
	public:

		typedef uint8_t IndexT;

		// NOTE: the number of rows in the atlas is limited by the precision of the texture that stores that value. At the
		//       moment, LineStyleAtlas stores the row index in an 8-bit channel so we are pretty limited on the number of
		//       rows in this atlas. In reality, there aren't a whole lot of dash patterns used in the stylesheets
		static constexpr uint32_t cExponent = 5;
		static constexpr IndexT cNumRows = 1 << cExponent;
		static constexpr uint32_t cRowResolution = 1 + Styling::DashArray::cMaxLength;		// 1 for the number of pixels in the row

		DashAtlas();
		~DashAtlas();

		void update();

		bool contains(Styling::DashArray const& dashArray) const;
		bool isReady(Styling::DashArray const& dashArray) const;

		void insert(Styling::DashArray const& dashArray);
		void erase(Styling::DashArray const& dashArray);

		// returns the row index of the style
		IndexT row(Styling::DashArray const& dashArray) const;

		inline bgfx::TextureHandle getHandle() const { return mPatternsHandle; }

	private:

		// Internal struct to represent a slot in the atlas. At the moment it is really just an integer. If we 
		// change LineStyleAtlas to use blitting, then we will utilize Slot::isReady similar to how we use
		// AtlasId::isReady. Though for now, it is a glorified integer
		struct Slot
		{
			IndexT idx;
			//bool isReady;

			Slot(IndexT i) : idx(i) {} // , isReady(false) {}
			Slot(Slot const& rhs) : idx(rhs.idx) {} //, isReady(rhs.isReady) {}
			Slot& operator=(Slot const& rhs) { idx = rhs.idx; /* isReady = rhs.isReady; */ return *this; }

			//bool ready() const { return isReady; }

			static Slot invalid()
			{
				return Slot(std::numeric_limits<IndexT>::max());
			}
		};

		Slot next() const;

		void write(IndexT row, Styling::DashArray const& dashArray);

		void destroyTexture();

		bool mIsDirty = false;

		// stores the slots index from a DashArray into the subsequent array
		std::unordered_map<Styling::DashArray, Slot> mSlots;

		// use std::vector here for bounds checking
		std::vector<bool> mUsed = std::vector<bool>((size_t)cNumRows, false);

		uint8_t mPatterns[cRowResolution * cNumRows] = { 0 };

		bgfx::TextureHandle mPatternsHandle = BGFX_INVALID_HANDLE;

	};

} }

#endif