#include "DashAtlas.h"

#include <lucid/math/Algorithm.h>
#include <System/Map3DException.h>

namespace onyx {
namespace Atlases {

	template<typename T>
	static bgfx::TextureHandle BuildPage(T* data, bgfx::TextureFormat::Enum format)
	{
		// use makeRef because this data is stored in arrays that will never change memory addresses
		bgfx::Memory const* mem = bgfx::makeRef((void*)data, sizeof(T) * DashAtlas::cRowResolution * DashAtlas::cNumRows);
		bgfx::TextureHandle handle = bgfx::createTexture2D(DashAtlas::cRowResolution, DashAtlas::cNumRows, false, 1, format, 0, mem);
		MAP3D_ASSERT(bgfx::isValid(handle), "Failed to allocate DashAtlas page");
		return handle;
	}

	DashAtlas::DashAtlas() {}

	DashAtlas::~DashAtlas()
	{
		destroyTexture();
	}

	void DashAtlas::update()
	{
		if (mIsDirty)
		{
			// destroy the old texture and allocate a new page
			destroyTexture();
			mPatternsHandle = BuildPage(mPatterns, bgfx::TextureFormat::Enum::R8);
			mIsDirty = false;
		}
	}

	bool DashAtlas::contains(Styling::DashArray const& dashArray) const
	{
		return mSlots.find(dashArray) != mSlots.end();
	}

	bool DashAtlas::isReady(Styling::DashArray const& dashArray) const
	{
		// technically is slightly wrong because this will claim no dash arrays are ready if we
		// just insert one new array. but since we create an entire new texture whenever we
		// insert a new array, it works out
		return contains(dashArray) && !mIsDirty; // mSlots.at(style).isReady;
	}

	void DashAtlas::insert(Styling::DashArray const& dashArray)
	{
		if (!contains(dashArray))
		{
			// mark as dirty so we know to update the textures
			mIsDirty = true;

			// compute the next slot and write the style to that index
			Slot slot = next();
			write(slot.idx, dashArray);

			// update book-keeping
			mUsed[slot.idx] = true;
			mSlots.insert_or_assign(dashArray, slot);
		}
	}

	void DashAtlas::erase(Styling::DashArray const& dashArray)
	{
		if (contains(dashArray))
		{
			Slot& slot = mSlots.at(dashArray);
			mUsed[slot.idx] = false;
			mSlots.erase(dashArray);
		}
	}

	DashAtlas::IndexT DashAtlas::row(Styling::DashArray const& dashArray) const
	{
		Slot const& slot = mSlots.at(dashArray);
		return slot.idx;
	}
	
	DashAtlas::Slot DashAtlas::next() const
	{
		for (IndexT i = 0; i < cNumRows; i++)
		{
			if (!mUsed[i])
			{
				return Slot(i);
			}
		}

		MAP3D_THROW("No remaining slots in DashAtlas");
		return Slot::invalid();
	}

	// TODO possibly encode with more precision than just integers?
	void DashAtlas::write(IndexT row, Styling::DashArray const& dashArray)
	{
		uint32_t offset = row * cRowResolution;

		// encode the length as the first pixel in the row
		uint8_t numPixels = (uint8_t)dashArray.length();
		mPatterns[offset] = uint8_t((float(numPixels) / float(Styling::DashArray::cMaxLength)) * 255);

		// increment offset since we just wrote to the first slot
		++offset;
		
		// for each pixel in the dash array, write whether it should be on or off
		for (uint8_t i = 0; i < numPixels; i++)
		{
			float x = float(i) + 0.5f;
			mPatterns[offset + i] = (dashArray.on(x)) ? 0xFF : 0x00;
		}
	}

	void DashAtlas::destroyTexture()
	{
		if (bgfx::isValid(mPatternsHandle))
		{
			bgfx::destroy(mPatternsHandle);
			mPatternsHandle = BGFX_INVALID_HANDLE;
		}
	}

} }