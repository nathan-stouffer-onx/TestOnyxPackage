#include "SunShadow.h"

#include <Shaders/ShaderManager.h>

#include "Caching/TileCache.h"
#include "Rendering/ViewId.h"
#include "Height/HeightManager.h"
#include "Pyramid/UVOffset.h"
#include "Tiles/TileMesh.h"
#include "Utils/MapMath.h"
#include "Viewport/ViewportState.h"

namespace onyx {
namespace TerrainEffects {

	INITCONFIGVALSTATIC(world_float_t, cSunMinStrength, "Sun:MinStrength", 1.0)
	INITCONFIGVALSTATIC(world_float_t, cSunAmbient, "Sun:Ambient", 0.3)
	INITCONFIGVALSTATIC(world_float_t, cShadowStrength, "Sun:Shadow:Strength", 0.25)
	INITCONFIGVALSTATIC(world_float_t, cShadowFadeStart, "Sun:Shadow:FadeStart", 225.0)
	INITCONFIGVALSTATIC(world_float_t, cShadowFadeEnd, "Sun:Shadow:FadeEnd", 275.0)

	SunShadow::SunShadow() :
		mPosition(0, 0, 0)
		, mTargetPos(0, 0, 0)
		, mSunMinStrength(cSunMinStrength)
		, mSunAmbient(cSunAmbient)
		, mShadowStrength(cShadowStrength)
		, mShadowFadeStart(cShadowFadeStart)
		, mShadowFadeEnd(cShadowFadeEnd)
		, mIsDirty(true)
	{
		for (int i = 0; i < 3; i++)
		{
			ShadowCascade* sc = new ShadowCascade(mShadowRes, i);
			mCascades.push_back(sc);
		}
	}

	SunShadow::~SunShadow()
	{
		for (size_t i = 0; i < mCascades.size(); i++)
		{
			delete mCascades[i];
		}

		mCascades.clear();
	}

	void SunShadow::update(ViewportState* vs)
	{
		JulianDate julian = vs->mSunShadow->getTimeDate();
		lgal::world::Vector2 elevationPitch = calculateSunDir(julian.getJulianCentury(), julian.hours24 - julian.timezone);
		setPosDir(vs->mCameraState.position.xy, elevationPitch.x, elevationPitch.y);

		//calculate our cascade level ranges
		int levelCount = vs->mCullState.maxLevel - vs->mCullState.minLevel;
		int firstCascade = 1;// levelCount > 2 ? 1 : 0;
		mCascades[0]->setBiggestLevel(vs->mCullState.maxLevel - firstCascade);
		mCascades[0]->setSmallestLevel(vs->mCullState.maxLevel);
		int levelStep = (levelCount - firstCascade) / (mCascades.size() <= 1 ? 1 : ((int)mCascades.size() - 1));
		for (size_t i = 1; i < mCascades.size(); i++)
		{
			mCascades[i]->setBiggestLevel(mCascades[i - 1]->getBiggestLevel() - levelStep);
			mCascades[i]->setSmallestLevel(mCascades[i - 1]->getBiggestLevel() + 1);
		}
		mCascades[mCascades.size() - 1]->setBiggestLevel(vs->mCullState.minLevel);

		for (size_t i = 0; i < mCascades.size(); i++)
		{
			mCascades[i]->updateDepthBuffer(vs, mLocalSunDir);
			mCascades[i]->blurDepth((float)mVSMParams.z);
		}

		setIsDirty(false);
	}

	void SunShadow::setPosDir(lgal::world::Vector2 const& pos, world_float_t elevation, world_float_t azimuth)
	{
		mTargetPos = lgal::world::Vector3(pos, HeightManager::Instance()->heightAt(pos));

		//convert from sun direction to local vector angle
		lgal::world::Vector3 dir;
		dir.z = std::cos(elevation) * std::cos(azimuth);
		dir.y = std::cos(elevation) * std::sin(azimuth);
		dir.x = std::sin(elevation);

		world_float_t latitude = MapMath::YToLat(pos.y);
		world_float_t longitude = MapMath::XToLon(pos.x);
		lgal::world::Vector3 planetNormal;

		planetNormal.x = std::cos(lmath::degreesToRadians(latitude)) * cos(lmath::degreesToRadians(longitude));
		planetNormal.y = std::cos(lmath::degreesToRadians(latitude)) * sin(lmath::degreesToRadians(longitude));
		planetNormal.z = std::sin(lmath::degreesToRadians(latitude));

		lgal::world::Vector3 tangent;
		lgal::world::Vector3 binormal;

		tangent = lmath::cross(planetNormal, lgal::world::Vector3(1.0, 0.0, 0.0));
		tangent = lmath::normalize(tangent);

		binormal = lmath::cross(planetNormal, tangent);
		binormal = lmath::normalize(binormal);

		lgal::world::Vector3 tangentSun;
		tangentSun.x = -lmath::dot(tangent, dir);
		tangentSun.y = -lmath::dot(binormal, dir);
		tangentSun.z = lmath::dot(planetNormal, dir);

		lgal::world::Vector3 test;
		test.x = lmath::dot(tangent, planetNormal);
		test.y = lmath::dot(binormal, planetNormal);
		test.z = lmath::dot(planetNormal, planetNormal);

		//distance seems irrelevant now that ortho is properly calculated to fit the scene?
		world_float_t distance = 300.0;

		//TODO - check that these vectors are in the right order
		mLocalSunDir = tangentSun;// lmath::normalize(mTargetPos - mPosition);
		mPosition = mTargetPos + mLocalSunDir * distance;

		//mCameraState.position = mPosition;

		//find up
		mViewUp = lmath::cross(mLocalSunDir, tangent);

		world_float_t heading = lmath::atan2(mLocalSunDir.y, mLocalSunDir.x);
		world_float_t pitch = lmath::acos(mLocalSunDir.z / lmath::sqrt(lmath::dot(mLocalSunDir, mLocalSunDir)));
		mCameraState.heading = heading;
		mCameraState.pitch = pitch;
		mCameraState.fov = 45;
		mCameraState.position = mPosition;
		mCameraState.aspect = 1;
	}

	lgal::world::Vector2 SunShadow::calculateSunDir(world_float_t julianCentury, world_float_t localTime)
	{
		//we want a sun angle relative to the globe not a pixel, so set lat and lon to 0 when doing the sun angle calculations

		world_float_t PI = lmath::constants::pi<world_float_t>();

		world_float_t geomMeanLongSunDeg = std::fmod((280.46646 + julianCentury * (36000.76983 + julianCentury * 0.0003032)), 360.0);
		world_float_t geomMeanAnomSunDeg = 357.52911 + julianCentury * (35999.05029 - 0.0001537 * julianCentury);
		world_float_t eccentEarthOrbit = 0.016708634 - julianCentury * (0.000042037 + 0.0000001267 * julianCentury);
		world_float_t sunEqofCtr = sin(geomMeanAnomSunDeg * PI / 180.0) * (1.914602 - julianCentury * (0.004817 + 0.000014 * julianCentury)) + sin(2.0 * geomMeanAnomSunDeg * PI / 180.0) * (0.019993 - 0.000101 * julianCentury) + sin(PI / 180.0 * 3.0 * geomMeanAnomSunDeg) * 0.000289;

		world_float_t sunTrueLongDeg = geomMeanLongSunDeg + sunEqofCtr;
		world_float_t sunAppLongDeg = sunTrueLongDeg - 0.00569 - 0.00478 * sin((125.04 - 1934.136 * julianCentury) * PI / 180.0);
		world_float_t sunDeclinDeg = 180.0 / PI * asin(0.397767f * sin(sunAppLongDeg * PI / 180.0));

		world_float_t varY = 0.043031;

		world_float_t eqOfTimeMinutes = 4.0 * 180.0 / PI * (varY * sin(2.0 * PI / 180.0 * geomMeanLongSunDeg) - 2.0 * eccentEarthOrbit * sin(geomMeanAnomSunDeg * PI / 180.0) + 4.0 * eccentEarthOrbit * varY * sin(PI / 180.0 * geomMeanAnomSunDeg) * cos(2.0 * geomMeanLongSunDeg * PI / 180.0) - 0.5 * varY * varY * sin(4.0 * geomMeanLongSunDeg * PI / 180.0) - 1.25 * eccentEarthOrbit * eccentEarthOrbit * sin(2.0 * PI / 180.0 * geomMeanAnomSunDeg));

		world_float_t trueSolarTimeMinutes = std::fmod(((localTime / 24.0) * 1440.0 + eqOfTimeMinutes), 1440.0);
		world_float_t hourAngleDeg = trueSolarTimeMinutes / 4.0 < 0.0 ? trueSolarTimeMinutes / 4.0 + 180.0 : trueSolarTimeMinutes / 4.0 - 180.0;
		world_float_t solarZenithAngleDeg = 180.0 / PI * (acos(cos(sunDeclinDeg * PI / 180.0) * cos(hourAngleDeg * PI / 180.0)));
		world_float_t solarElevationAngleDeg = 90.0 - solarZenithAngleDeg;

		world_float_t solarAzimuthAngleDeg = 0.0;
		world_float_t offset = 0.0;
		world_float_t offsetSign = 1.0;
		world_float_t flip = 180.0;
		if (hourAngleDeg <= 0.0)
		{
			offset = 540.0;
			offsetSign = -1.0;
			flip = 0.0;
		}

		world_float_t inner = offset + offsetSign * 180.0 / PI * acos(-sin(PI / 180.0 * sunDeclinDeg) / sin(PI / 180.0 * solarZenithAngleDeg)) + flip;
		solarAzimuthAngleDeg = std::fmod(inner, 360.0);

		return { solarElevationAngleDeg * PI / 180.0, solarAzimuthAngleDeg * PI / 180.0 };
	}

	bgfx::TextureHandle SunShadow::getDepthHandle(int tileLevel)
	{
		return mCascades[levelToCascade(tileLevel)]->getDepthTexHandle();
	}

	void SunShadow::setDrawShaderParams(ViewportState* vs, Tiles::TileTextureInfo const& renderInfo, std::shared_ptr<Shaders::ShaderDefinition> shader)
	{
		if (shader->parameters.find("u_SunTimeData") != shader->parameters.end())
		{
			float jc = (float)mSunTimeDate.getJulianCentury();
			shader->setParameter("u_SunTimeData", lgal::gpu::Vector3(jc, mSunTimeDate.getTimezoneTime() / 24.0f, 0.0f));
			shader->setParameter("u_SunMinStrength", mSunMinStrength);
			shader->setParameter("u_SunAmbient", mSunAmbient);

			shader->setParameter("u_sunTileMin", renderInfo.sunMin);
			shader->setParameter("u_sunTileMax", renderInfo.sunMax);

			//fade out from 225 to 275 camera above ground
			auto shadowFade = 1.0 - std::min(std::max(vs->mCameraState.position.z - mShadowFadeStart, 0.0) / mShadowFadeEnd, 1.0);
			shader->setParameter("u_sunShadowFarPlane", getFarPlane(renderInfo.id.level));
			shader->setParameter("u_sunShadowBias", getBias());
			shader->setParameter("u_sunShadowStrength", mShadowStrength * shadowFade);
			shader->setParameter("u_sunShadowView", getSunView(renderInfo.id.level));
			shader->setParameter("u_sunShadowProj", getSunProj(renderInfo.id.level));
			shader->setParameter("s_sunShadowDepth", getDepthHandle(renderInfo.id.level), mShadowRes, mShadowRes);

			auto shadowTileMin = renderInfo.tileMin - getEyePos(renderInfo.id.level);
			auto shadowTileMax = renderInfo.tileMax - getEyePos(renderInfo.id.level);
			shadowTileMax.z = renderInfo.tileSize.x;
			shader->setParameter("u_sunShadowTileMin", shadowTileMin);
			shader->setParameter("u_sunShadowTileMax", shadowTileMax);
			shader->setParameter("u_sunShadowVSMParams", getVSMParams());
	
			if (mDebugMode)
				shader->setParameter("u_CascadeDebug", 1.0);
		}
	}

	void SunShadow::setTimeDate(JulianDate jd)
	{
		if(mSunTimeDate != jd)
			setIsDirty(true);

		mSunTimeDate = jd; 
	}

	void SunShadow::setDebugMode(bool on)
	{
		mDebugMode = on;
		for (size_t i = 0; i < mCascades.size(); i++)
		{
			mCascades[i]->setDebugMode(mDebugMode);
		}
	}
} }