#include "SunShadow.h"

#include <Shaders/ShaderManager.h>

#include "Caching/TileCache.h"
#include "Rendering/ViewId.h"
#include "Height/HeightManager.h"
#include "Pyramid/UVOffset.h"
#include "Tiles/TileMesh.h"
#include "Utils/MapMath.h"
#include "Viewport/ViewportState.h"
#include "Viewport/ViewportManager.h"
#include "Viewport/Viewport.h"

namespace onyx {
namespace TerrainEffects {

	ShadowCascade::ShadowCascade(uint16_t res, int id)
	{
		mDepthFrameBufferHandle[0] = BGFX_INVALID_HANDLE;
		mDepthFrameBufferHandle[1] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[0][0] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[0][1] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[1][0] = BGFX_INVALID_HANDLE;
		mDepthTexHandle[1][1] = BGFX_INVALID_HANDLE;
		mShadowRes = res;
		mNearPlane = 1.0;
		mCascadeId = id;
	}

	ShadowCascade::~ShadowCascade()
	{
		if (bgfx::isValid(mQuadVertsBuffer))
		{
			bgfx::destroy(mQuadVertsBuffer);
		}

		deallocateFrameBuffer();
	}

	void ShadowCascade::deallocateFrameBuffer()
	{
		for (int i = 0; i < 2; i++)
		{
			if (bgfx::isValid(mDepthFrameBufferHandle[i]))
			{
				bgfx::destroy(mDepthFrameBufferHandle[i]);
				mDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
			}

			for (int j = 0; j < 2; j++)
			{
				if (bgfx::isValid(mDepthTexHandle[i][j]))
				{
					bgfx::destroy(mDepthTexHandle[i][j]);
					mDepthTexHandle[i][j] = BGFX_INVALID_HANDLE;
				}
			}
		}
	}

	void ShadowCascade::updateDepthBuffer(ViewportState* vs, lgal::world::Vector3 sunDir)
	{
		lgal::world::AABB3d terrainBounds;
		terrainBounds.min = lgal::world::Vector3(9999999);
		terrainBounds.max = lgal::world::Vector3(-9999999);

		std::map<Tiles::TileId, Tiles::TileId> readyTiles;

		std::string heightId = Caching::TileCache::Instance()->getHeightSourceName();
		Atlases::TileAtlas const* heightAtlas = Caching::TileCache::Instance()->getSource(heightId).atlas();

		for (const auto& tileId : vs->mCullState.tileIds)//mCullState.tileIds)
		{
			//todo - maybe include the overlapping tiles here?
			if (tileId.level > mSmallestLevel || tileId.level < mBiggestLevel)
				continue; //not part of this cascade, so ignore it for sizing

			Tiles::TileId readyId = tileId;
			bool found = false;
			while (!found && readyId.level >= 0)
			{
				if (heightAtlas->isReady(readyId))
				{
					found = true;
					readyTiles[tileId] = readyId;
				}
				else
				{
					readyId = readyId.parent();
				}
			}

			//calculate our scene aabb, finding the box that contains all our tiles
			auto renderInfo = vs->mTileRenderInfo.find(tileId)->second;
			if (renderInfo.isReady)
			{
				lgal::world::Range z = HeightManager::Instance()->heightExtents(tileId);
				terrainBounds.min.x = std::min(terrainBounds.min.x, renderInfo.tileMin.x);
				terrainBounds.min.y = std::min(terrainBounds.min.y, renderInfo.tileMin.y);
				terrainBounds.min.z = std::min(terrainBounds.min.z, z.begin);
				terrainBounds.max.x = std::max(terrainBounds.max.x, renderInfo.tileMax.x);
				terrainBounds.max.y = std::max(terrainBounds.max.y, renderInfo.tileMax.y);
				terrainBounds.max.z = std::max(terrainBounds.max.z, z.end);
			}
		}

		bx::mtxLookAt(mSunView, { 0, 0, 0 }, lgal::toBx(-sunDir), lgal::toBx(lgal::world::Vector3(0, 1, 0)));

		//make sure our min and max are still  mins and maxes after we spun it around
		bx::Vec3 minBounds = lgal::toBx(terrainBounds.min);
		bx::Vec3 maxBounds = lgal::toBx(terrainBounds.max);

		bx::Vec3 center = bx::div(bx::add(minBounds, maxBounds), 2.0f);
		world_float_t radius = bx::length(bx::sub(minBounds, center));
		world_float_t farPlane = radius * 2.5 + mNearPlane;

		float left = (float)-radius;
		float right = (float)radius;
		float top = (float)radius;
		float bottom = (float)-radius;
		mFarPlane = farPlane;//radius * 2.0;
		bx::mtxOrtho(mSunProj, left, right, bottom, top, float(mNearPlane), float(mFarPlane), 0.0f, bgfx::getCaps()->homogeneousDepth);

		mEyePos = lgal::world::Vector3(center.x, center.y, center.z) + sunDir * (radius * 2.0 + mNearPlane);

		// double check that framebuffers are valid
		if (!bgfx::isValid(mDepthFrameBufferHandle[0]))
		{
			deallocateFrameBuffer();
			allocateFrameBuffer();
		}

		if (!bgfx::isValid(mDepthFrameBufferHandle[0]))
		{
			return;
		}

		uint64_t overrideState = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_G | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LESS;

		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainVSMDepth, 0);
		
		if(mDebugMode)
			shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::Terrain, 0); //draw full color

		//draw the terrain
		bgfx::ViewId viewId;

		viewId = Rendering::ViewId::next(Rendering::ViewId::Type::RenderToTexture);
		bgfx::touch(viewId);

		bgfx::setViewName(viewId, ("Sun Shadow Depth - Cascade " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(viewId, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(viewId, mSunView, mSunProj);
		bgfx::setViewFrameBuffer(viewId, mDepthFrameBufferHandle[0]);

		shader->setParameter("u_eyePos", lgal::toBx(mEyePos));
		shader->setParameter("u_nearFarPlane", bx::Vec3(float(mNearPlane), float(mFarPlane), 0));

		for (size_t j = 0u; j < vs->mTileCollections.rasters.size(); j++)
		{
			Tiles::TileId tileId = vs->mTileCollections.rasters[j];
			Tiles::TileId& readyId = readyTiles[tileId];

			if (tileId.level < mBiggestLevel || tileId.level > mSmallestLevel)
				continue;

			auto renderInfo = vs->mTileRenderInfo.find(tileId)->second;
			if (!renderInfo.isReady)
				continue; //not ready so dont think we want it casting shadows?

			// TODO: Monitor https://github.com/bkaradzic/bgfx/issues/3024 for when this is fixed
			// so we don't have to have two samplers for the same texture
			bgfx::TextureHandle tex = heightAtlas->getTexHandle(readyId);
			int res = heightAtlas->getResolution();
			shader->setParameter("s_heightTextureVert", tex, res, res);
				
			tex = heightAtlas->getTexHandle(readyId);
			res = heightAtlas->getResolution();
			shader->setParameter("s_heightTextureFrag", tex, res, res);

			if (mDebugMode)
			{
				//auto renderInfo = vs->mTileRenderInfo.find(tileId)->second;
				if (renderInfo.basemap.isValid())
				{
					//setTextureParameters(renderInfo.layers[0], shader.get(), TextureType::Roads);
					Viewport* vp = ViewportManager::Instance()->getViewport("main");
					if (vp != NULL)
					{
						std::string texName = "s_texture0";
						const std::string& uvOffsetName = "u_ScaleOffsetTex0";
						shader->setParameter(texName, renderInfo.basemap.handle, renderInfo.basemap.resolution, renderInfo.basemap.resolution);
						shader->setParameter(uvOffsetName, renderInfo.basemap.offset);
					}
				}

				shader->setParameter("u_fogVars", lgal::gpu::Vector3(0, 0, 0));
			}

			auto sp = shader->parameters["u_heightTileSize"];
			if (sp != NULL)
			{
				float size = (float)readyId.extent();

				sp->setValue(bx::Vec3(size, size, sp->mVec3.z));
			}

			auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(readyId, tileId);
			auto uvOffset = heightAtlas->getUVOffset(readyId);
			auto combinedOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);

			shader->setParameter("u_ScaleOffsetHeight", combinedOffset);

			auto meshRes = uint16_t(64 >> std::max(0, tileId.level - 17));

			auto tileMin = renderInfo.tileMin - mEyePos;
			auto tileMax = renderInfo.tileMax - mEyePos;
			tileMax.z = renderInfo.tileSize.x;

			shader->setParameter("u_tileMin", tileMin);
			shader->setParameter("u_tileMax", tileMax);

			// compute distortions at the min/max of the tile (NOTE: possible name confusion here since the min of the tile will have the most distortion)
			auto minDistortion = MapMath::mercatorDistortion(tileId.northwestCorner());
			auto maxDistortion = MapMath::mercatorDistortion(tileId.southeastCorner());
			shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ (gpu_float_t)minDistortion, (gpu_float_t)maxDistortion, 0.0 });

			Tiles::TileMesh::Instance(meshRes)->draw(tileId, mEyePos, 0.0f, shader->programHandle, viewId, false, overrideState, true);
		}
	}

	void ShadowCascade::blurDepth(float blurAmount)
	{
		if (mDebugMode)
			blurAmount = 0;

		if (!bgfx::isValid(mQuadVertsBuffer))
		{
			mQuadVerts[0].m_x = 0;
			mQuadVerts[0].m_y = 1;
			mQuadVerts[0].m_u = 1;
			mQuadVerts[0].m_v = 0;

			mQuadVerts[1].m_x = 1;
			mQuadVerts[1].m_y = 1;
			mQuadVerts[1].m_u = 0;
			mQuadVerts[1].m_v = 0;

			mQuadVerts[2].m_x = 0;
			mQuadVerts[2].m_y = 0;
			mQuadVerts[2].m_u = 1;
			mQuadVerts[2].m_v = 1;

			mQuadVerts[3].m_x = 1;
			mQuadVerts[3].m_y = 1;
			mQuadVerts[3].m_u = 0;
			mQuadVerts[3].m_v = 0;

			mQuadVerts[4].m_x = 1;
			mQuadVerts[4].m_y = 0;
			mQuadVerts[4].m_u = 0;
			mQuadVerts[4].m_v = 1;

			mQuadVerts[5].m_x = 0;
			mQuadVerts[5].m_y = 0;
			mQuadVerts[5].m_u = 1;
			mQuadVerts[5].m_v = 1;

			mQuadVertsBuffer = bgfx::createVertexBuffer(bgfx::makeRef(mQuadVerts, sizeof(Rendering::VertStructs::PosColorUV) * 6), Rendering::VertStructs::PosColorUV::ms_layout);
			
			if (bgfx::getCaps()->originBottomLeft)
			{
				bx::mtxOrtho(mBlurProj, 0.0f, (float)1, 0.0f, (float)-1, 0.01f, 10.0f, 0.0f, false);
			}
			else
			{
				bx::mtxOrtho(mBlurProj, 0.0f, (float)1, (float)-1, 0.0f, 0.01f, 10.0f, 0.0f, false);
			}

			bx::mtxLookAt(mBlurView, bx::Vec3(1, 1, 1), bx::Vec3(1, 1, 0.0), bx::Vec3(0, 1, 0));
		}

		bgfx::ViewId first = Rendering::ViewId::next(Rendering::ViewId::Type::RenderToTexture);
		bgfx::ViewId second = Rendering::ViewId::next(Rendering::ViewId::Type::RenderToTexture);
		bgfx::touch(first);
				
		bgfx::setViewName(first, ("Blur X " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(first, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(first, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(first, mBlurView, mBlurProj);
		bgfx::setViewFrameBuffer(first, mDepthFrameBufferHandle[1]);
		uint64_t state = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_G | BGFX_STATE_WRITE_B | BGFX_STATE_WRITE_A | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LESS;
		bgfx::setVertexBuffer(0, mQuadVertsBuffer);

		bgfx::setState(state);
				
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::GaussianBlur, 0);
		shader->setParameter("u_tileMin", bx::Vec3(0, 0, 0));
		shader->setParameter("u_tileMax", bx::Vec3(1, 1, 1));
		shader->setParameter("u_GaussBlurScale", bx::Vec3(blurAmount / mShadowRes, 0, 0));

		auto tex = shader->parameters["s_BlurTex"];
		if (tex != nullptr)
		{
			tex->setValue(mDepthTexHandle[0][0], mShadowRes, mShadowRes);
		}
		bgfx::submit(first, shader->programHandle);

		//now blur y
		bgfx::touch(second);
		if (tex != nullptr)
		{
			tex->setValue(mDepthTexHandle[1][0], mShadowRes, mShadowRes);
		}
		shader->setParameter("u_GaussBlurScale", bx::Vec3(0, blurAmount / mShadowRes, 0));


		bgfx::setViewName(second, ("Blur Y " + std::to_string(mCascadeId)).c_str());
		bgfx::setViewClear(second, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(second, 0, 0, mShadowRes, mShadowRes);

		bgfx::setViewTransform(second, mBlurView, mBlurProj);
		bgfx::setViewFrameBuffer(second, mDepthFrameBufferHandle[0]);
		bgfx::setState(state);
		bgfx::setVertexBuffer(0, mQuadVertsBuffer);

		bgfx::submit(second, shader->programHandle);
	}

	void ShadowCascade::allocateFrameBuffer()
	{
		for (int i = 0; i < 2; i++)
		{
			bgfx::TextureFormat::Enum tf = bgfx::TextureFormat::RG32F;
			if (mDebugMode)
				tf = bgfx::TextureFormat::RGBA8;

			mDepthTexHandle[i][0] = bgfx::createTexture2D(
				uint16_t(mShadowRes)
				, uint16_t(mShadowRes)
				, false
				, 1
				, tf
				, BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP | BGFX_SAMPLER_W_CLAMP
			);

			bgfx::TextureFormat::Enum depthFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;

			mDepthTexHandle[i][1] = bgfx::createTexture2D(
				uint16_t(mShadowRes)
				, uint16_t(mShadowRes)
				, false
				, 1
				, depthFormat
				, BGFX_TEXTURE_RT_WRITE_ONLY
			);

			if (bgfx::isValid(mDepthTexHandle[i][0]) && bgfx::isValid(mDepthTexHandle[i][1]))
			{
				bgfx::setName(mDepthTexHandle[i][0], "sunShadowColorTex");
				bgfx::setName(mDepthTexHandle[i][1], "sunShadowDepthTex");
				mDepthAttachments[i][0].init(mDepthTexHandle[i][0], bgfx::Access::Write, 0);
				mDepthAttachments[i][1].init(mDepthTexHandle[i][1], bgfx::Access::Write, 0);
				mDepthFrameBufferHandle[i] = bgfx::createFrameBuffer(BX_COUNTOF(mDepthTexHandle[i]), &mDepthAttachments[i][0], true);
			}
		}
	}

}
}