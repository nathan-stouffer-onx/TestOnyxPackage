#include "Viewshed.h"

#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>

#include "Caching/TileCache.h"
#include "Rendering/ViewId.h"
#include "Height/HeightManager.h"
#include "Pyramid/UVOffset.h"
#include "Tiles/TileMesh.h"
#include "Utils/MapMath.h"
#include "Utils/TextUtils.h"

namespace onyx {
namespace TerrainEffects {

	constexpr uint32_t VIEWSHED_PARAM_COUNT = 5;
	// Potential support for multiple viewshed effects
	static std::array<std::array<std::string, VIEWSHED_PARAM_COUNT>, 3> sVariableNames =
	{
		{
			{ "viewshedPosition0", "viewshedOffset0", "viewshedRange0", "viewshedStrength0", "viewshedColor0" },
			{ "viewshedPosition1", "viewshedOffset1", "viewshedRange1", "viewshedStrength1", "viewshedColor1" },
			{ "viewshedPosition2", "viewshedOffset2", "viewshedRange2", "viewshedStrength2", "viewshedColor2" },
		}
	};

	static std::array<lucid::gigl::Context::Primitive, VIEWSHED_PARAM_COUNT> sVariableDefaults =
	{
		{
			lgal::world::Vector2(0),
			Viewshed::Effect_float_t(0.01),
			Viewshed::Effect_float_t(8),
			Viewshed::Effect_float_t(1),
			lgal::Color(0xFF00CCFE)
		}
	};

	void Viewshed::initialize(std::shared_ptr<lucid::gigl::Context> context)
	{
		for (uint32_t i = 0u; i < VIEWSHED_PARAM_COUNT; ++i)
		{
			if (!context->exists(sVariableNames[mId][i])) // "viewshedPosition0"))
			{
				context->add(sVariableNames[mId][i], sVariableDefaults[i]);
			}
		}
	}

	void Viewshed::setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const
	{
		auto range = mRange; // context->lookup("ViewshedRange").as<float32_t>();
		auto strength = mStrength; // context->lookup("ViewshedStrength").as<float32_t>();
		shader->setParameter("s_cubeDepth0", getDepthHandle(), int(resolution()), int(resolution()));
		shader->setParameter("u_viewshedPos0", mOffsetPos - mCameraPosition);
		shader->setParameter("u_viewshedFarPlane", getFarPlane());
		shader->setParameter("u_viewshedRange", range * onyx::MapMath::mercatorDistortion(mOffsetPos.xy));
		shader->setParameter("u_viewshedStrength", strength);
		shader->setParameter("u_viewshedColor0", mColor);
	}

	std::vector<std::string> Viewshed::getComponents() const
	{
		if (mInverted)
		{
			return { "InvertedViewshed" };
		}
		else
		{
			return { "Viewshed" };
		}
	}

	void Viewshed::getLabels(std::vector<std::shared_ptr<DataObjects::MapLabel>>& labels) const
	{
		auto pos = mOffsetPos;

		auto camHeight = mCameraPosition.z - pos.z;

		size_t last = camHeight < 7.5f ? 16 : camHeight < 15.0f ? 8 : camHeight < 30.f ? 4 : 0;

		labels.insert(labels.end(), mLabels.begin(), mLabels.begin() + (last + 1));
	}

	lgal::world::Vector3 const Viewshed::sCubemapLookDirs[6] = {
		// east       west
		{ 1, 0, 0 },  { -1, 0, 0 },
		// north      south
		{ 0, -1, 0 }, { 0, 1, 0 },
		// up         down
		{ 0, 0, 1 },  { 0, 0, -1 },
	};

	lgal::world::Vector3 const Viewshed::sCubemapUpDirs[6] = {
		// east       west
		{ 0, 1, 0 },  { 0, 1, 0 },
		// north      south
		{ 0, 0, 1 },  { 0, 0, -1 },
		// up         down
		{ 0, 1, 0 },  { 0, 1, 0 },
	};

	Viewshed::Effect_float_t const Viewshed::sCubemapHeadings[6] = {
		// east													west
		lmath::constants::half_pi<Viewshed::Effect_float_t>(),  3.0 * lmath::constants::half_pi<Viewshed::Effect_float_t>(),
		// north												south
		0.0,													lmath::constants::pi<Viewshed::Effect_float_t>(),
		// up													down
		0.0,													0.0,
	};

	Viewshed::Viewshed(bool inverted)
		: mInverted(inverted)
		, mPosition(0, 0)
		, mOffsetPos(0, 0, 0)
		, mNearPlane(0.0001f)
		, mFarPlane(30.0f)
	{
		for (int i = 0; i < 6; i++)
		{
			mCubemapDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
		}
		mCubemapDepthTexHandle[0] = BGFX_INVALID_HANDLE;
		mCubemapDepthTexHandle[1] = BGFX_INVALID_HANDLE;

		auto style = std::make_shared<Styling::FontStyle>(Styling::FontFace({ "default", FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE, 15 }), lgal::Color::FromRGBA(0xFFFFFFFF), lgal::Color::FromRGBA(0x000000FF), lgal::Color::FromRGBA(0x00000064), 0.f, Styling::FontStyle::SymbolPlacement::POINT);

		for (int i = 0; i < 17; ++i)
		{
			mLabels.push_back(std::make_shared<DataObjects::MapLabel>("", lgal::world::Vector3(0, 0, 0), Utils::SpaceTypes::World));
			mLabels.back()->setStyle(style);
		}

		updateLabels();
	}

	std::array<lgal::world::Vector2 const, 4> sDirections = { { { 1, 0 }, { 0, 1 }, { -1, 0 }, { 0, -1 } } };
	std::array<float32_t const, 4> sDistances = { 1.0f, 0.5f, 0.25f, 0.75f };

	void Viewshed::updateLabels()
	{
		auto distortion = MapMath::mercatorDistortion(mPosition);

		MapMath::LonLat lonLat(mPosition);

		auto const& centerLabel = mLabels.front();
		centerLabel->setText(Utils::Text::ReadableLonLat(lonLat));
		lgal::world::Vector3 centerPos(mPosition, HeightManager::Instance()->heightAt(mPosition));
		centerLabel->setMapPosition(centerPos);
		centerLabel->setAnchorPoint(centerPos);
		
		std::ostringstream os;

		auto labelIdx = 1;

		for (auto const &dist : sDistances)
		{
			os.str("");
			os.clear();
			os.setf(std::ios::fixed);
			os.precision(1);

			auto rangeKm = dist * float32_t(mRange * distortion);

			auto values = Utils::Text::GetDistanceLabelUnits(rangeKm, false);

			os << values.first << values.second;
			auto text = os.str();

			for (auto const& direction : sDirections)
			{
				auto const& label = mLabels[labelIdx++];
				auto offsetPos = (mPosition + (direction * world_float_t(rangeKm)));
				lgal::world::Vector3 labelPos(offsetPos.x, offsetPos.y, HeightManager::Instance()->heightAt(offsetPos));
				label->setText(text);
				label->setMapPosition(labelPos);
				label->setAnchorPoint(labelPos);
			}
		}
	}

	Viewshed::~Viewshed()
	{
		deallocateFramebuffer();
	}

#define CONTEXT_VAR(name, type, key) type name; context->getTo(key, name);

	bool Viewshed::update(Camera::CameraState const& cameraState, std::shared_ptr<lucid::gigl::Context> context, Utils::Timer::Map3D_time_t /* timeMS */)
	{
		if (!getEnabled())
		{
			return false;
		}

		mCameraPosition = cameraState.position;

		lgal::world::Vector2 newPosition;
		context->getTo("viewshedPosition0", newPosition);
		Effect_float_t newOffset;
		context->getTo("viewshedOffset0", newOffset);
		context->getTo("viewshedColor0", mColor);

		CONTEXT_VAR(newRange, Effect_float_t, "viewshedRange0");
		CONTEXT_VAR(newStrength, Effect_float_t, "viewshedStrength0");

		if (mCompleted && newPosition == mPosition &&
			newOffset == mHeightOffsetKm &&
			newRange == mRange &&
			newStrength == mStrength)
		{
			return false; // Everything up-to-date
		}

		std::string heightId = Caching::TileCache::Instance()->getHeightSourceName();
		// TODO possibly rerender if cache updates?
		if (heightId == "")
			return true;

		bool needsLabelUpdate = mPosition != newPosition || mRange != newRange;

		// update position
		mPosition = newPosition;
		mHeightOffsetKm = newOffset;
		mRange = newRange;
		mStrength = newStrength;

		if (needsLabelUpdate)
		{
			updateLabels();
		}

		// set the offset position
		mOffsetPos = { mPosition, 0.0 };
		mOffsetPos.z = HeightManager::Instance()->heightAt(mPosition) + MapMath::mercatorDistortion(mPosition) * mHeightOffsetKm;


		Caching::Source const& heightDataSource = Caching::TileCache::Instance()->getSource(heightId);
		auto heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(heightDataSource.specification());

		// cull and precache the result
		mCullState.reset();
		Pyramid::cull(mCullState, mOffsetPos.xy, mFarPlane, 2.0, heightDataSource.specification()->maxZoom);
		for (Tiles::TileId const& tileId : mCullState.tileIds)
		{
			Caching::TileCache::Instance()->at({ heightId, tileId });
		}

		Atlases::TileAtlas const* heightAtlas = heightDataSource.atlas();
		// early out if the height atlas doesn't even have the root tile
		if (!heightAtlas->isReady({ 0, 0, 0 }))
		{
			return true;
		}

		// identify the height tiles that we have available
		std::map<Tiles::TileId, Tiles::TileId> readyTiles;
		bool allTilesHaveData = true;
		for (const auto& tileId : mCullState.tileIds)
		{
			Tiles::TileId readyId = tileId;
			bool found = false;
			while (!found && readyId.level >= 0)
			{
				if (heightAtlas->isReady(readyId))
				{
					found = true;
					readyTiles[tileId] = readyId;
				}
				else
				{
					readyId = readyId.parent();
				}
			}
			if (!found)
			{
				allTilesHaveData = false;
			}
		}

		// if any tile is missing data, don't draw viewshed
		if (!allTilesHaveData)
		{
			return false;
		}

		// double check that framebuffers are valid
		if (!bgfx::isValid(mCubemapDepthFrameBufferHandle[0]))
		{
			deallocateFramebuffer();
			allocateFramebuffer();
		}

		if (!bgfx::isValid(mCubemapDepthFrameBufferHandle[0]))
		{
			return false;
		}

		mCompleted = true;

		uint64_t overrideState = BGFX_STATE_WRITE_R | BGFX_STATE_WRITE_Z | BGFX_STATE_DEPTH_TEST_LESS;

		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainCubemapDepth, 0);

		// calculate the view/proj matrices
		for (int i = 0; i < 6; i++)
		{
			bx::mtxLookAt(mCubemapView[i], { 0, 0, 0 }, lgal::toBx(sCubemapLookDirs[i]), lgal::toBx(sCubemapUpDirs[i]));
		}
		bx::mtxProj(mCubemapProj, 90.0f, 1.0, float(mNearPlane), float(mFarPlane), bgfx::getCaps()->homogeneousDepth);

		for (int i = 0; i < 6; i++)
		{
			bgfx::ViewId cameraCubeDepthId = Rendering::ViewId::next(Rendering::ViewId::Type::RenderToTexture);
			setCubeView(cameraCubeDepthId, i);

			shader->setParameter("u_eyePos", lgal::toBx(mOffsetPos));
			shader->setParameter("u_nearFarPlane", bx::Vec3(float(mNearPlane), float(mFarPlane), 0));

			for (const auto& tileId : mCullState.tileIds)
			{
				Tiles::TileId& readyId = readyTiles[tileId];
				if (tileId.level < heightDataSource.specification()->maxZoom && tileId != readyId)	// if we are using a lower detail tile, set the dirty flag
				{
					mCompleted = false;
				}

				// TODO: Monitor https://github.com/bkaradzic/bgfx/issues/3024 for when this is fixed
				// so we don't have to have two samplers for the same texture
				ShaderParam* sp = shader->parameters["s_heightTextureVert"];
				if (sp != nullptr)
				{
					bgfx::TextureHandle tex = heightAtlas->getTexHandle(readyId);
					int res = heightAtlas->getResolution();
					sp->setValue(tex, res, res);
					
				}
				sp = shader->parameters["s_heightTextureFrag"];
				if (sp != nullptr)
				{
					bgfx::TextureHandle tex = heightAtlas->getTexHandle(readyId);
					int res = heightAtlas->getResolution();
					sp->setValue(tex, res, res);
				}

				auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(readyId, tileId);
				auto uvOffset = heightAtlas->getUVOffset(readyId);
				auto combinedUVOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);
				shader->setParameter("u_ScaleOffsetHeight", combinedUVOffset);

				auto meshRes = MapMath::meshResolution(*heightSpec, tileId);

				lgal::world::Vector3 tileMin = lgal::world::Vector3{ tileId.northwestCorner(), 0.0 } - mOffsetPos;
				lgal::world::Vector3 tileMax = lgal::world::Vector3{ tileId.southeastCorner(), 1.0 } - mOffsetPos;
				tileMax.z = tileId.extent();

				shader->setParameter("u_tileMin", tileMin);
				shader->setParameter("u_tileMax", tileMax);

				// compute distortions at the min/max of the tile (NOTE: possible name confusion here since the min of the tile will have the most distortion)
				auto minDistortion = onyx::MapMath::mercatorDistortion(tileId.northwestCorner());
				auto maxDistortion = onyx::MapMath::mercatorDistortion(tileId.southeastCorner());
				shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ (gpu_float_t)minDistortion, (gpu_float_t)maxDistortion, 0.0 });

				Tiles::TileMesh::Instance(meshRes)->draw(tileId, mOffsetPos, sCubemapHeadings[i], shader->programHandle, cameraCubeDepthId, false, overrideState);
			}
		}
		
		return true;
	}

	void Viewshed::setCubeView(bgfx::ViewId viewId, int side)
	{
		bgfx::touch(viewId);

		bgfx::setViewName(viewId, "Camera Cubemap Depth");
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xffffffff, 1.0f, 0);
		bgfx::setViewRect(viewId, 0, 0, mCubeDepthRes, mCubeDepthRes);

		bgfx::setViewFrameBuffer(viewId, mCubemapDepthFrameBufferHandle[side]);
		bgfx::setViewTransform(viewId, mCubemapView[side], mCubemapProj);
	}

	void Viewshed::allocateFramebuffer()
	{
		mCubemapDepthTexHandle[0] = bgfx::createTextureCube(
			uint16_t(mCubeDepthRes)
			, false
			, 1
			, bgfx::TextureFormat::R32F
			, BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP | BGFX_SAMPLER_W_CLAMP
		);

		bgfx::TextureFormat::Enum depthFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;

		mCubemapDepthTexHandle[1] = bgfx::createTextureCube(
			uint16_t(mCubeDepthRes)
			, false
			, 1
			, depthFormat
			, BGFX_TEXTURE_RT_WRITE_ONLY
		);

		if (bgfx::isValid(mCubemapDepthTexHandle[0]) && bgfx::isValid(mCubemapDepthTexHandle[1]))
		{
			bgfx::setName(mCubemapDepthTexHandle[0], "fboCubemapColorTex");
			bgfx::setName(mCubemapDepthTexHandle[1], "fboCubemapDepthTex");
			for (uint16_t i = 0; i < 6; i++)
			{
				mCubemapAttachments[i][0].init(mCubemapDepthTexHandle[0], bgfx::Access::Write, i);
				mCubemapAttachments[i][1].init(mCubemapDepthTexHandle[1], bgfx::Access::Write, i);
				mCubemapDepthFrameBufferHandle[i] = bgfx::createFrameBuffer(BX_COUNTOF(mCubemapDepthTexHandle), &mCubemapAttachments[i][0], true);
			}
		}
	}

	void Viewshed::deallocateFramebuffer()
	{
		for (int i = 0; i < 6; i++)
		{
			if (bgfx::isValid(mCubemapDepthFrameBufferHandle[i]))
			{
				bgfx::destroy(mCubemapDepthFrameBufferHandle[i]);
				mCubemapDepthFrameBufferHandle[i] = BGFX_INVALID_HANDLE;
			}
		}
		if (bgfx::isValid(mCubemapDepthTexHandle[0]))
		{
			bgfx::destroy(mCubemapDepthTexHandle[0]);
			mCubemapDepthTexHandle[0] = BGFX_INVALID_HANDLE;
		}
		if (bgfx::isValid(mCubemapDepthTexHandle[1]))
		{
			bgfx::destroy(mCubemapDepthTexHandle[1]);
			mCubemapDepthTexHandle[1] = BGFX_INVALID_HANDLE;
		}
	}

} }