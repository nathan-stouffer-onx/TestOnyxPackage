#pragma once
#if !defined(VIEWSHED_EFFECT_H)
#define VIEWSHED_EFFECT_H

#include "TerrainEffectBase.h"
#include "Pyramid/Culling.h"

namespace onyx {
namespace TerrainEffects {

	class Viewshed : public TerrainEffectBase
	{
	public:
		typedef world_float_t Effect_float_t;

		virtual void initialize(std::shared_ptr<lucid::gigl::Context> context) override;
		virtual void setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const override;
		virtual std::vector<std::string> getComponents() const override;
		virtual void getLabels(std::vector<std::shared_ptr<DataObjects::MapLabel>>& labels) const override;

		Viewshed(bool inverted = false);
		~Viewshed();

		bool update(Camera::CameraState const& cameraState, std::shared_ptr<lucid::gigl::Context> context, Utils::Timer::Map3D_time_t timeMS) override;

		Effect_float_t getFarPlane() const { return mFarPlane; }
		Effect_float_t getNearPlane() const { return mNearPlane; }

		uint16_t resolution() const { return mCubeDepthRes; }

		bgfx::TextureHandle getDepthHandle() const { return mCubemapDepthTexHandle[0]; }

	private:
		uint32_t mId = 0;
		Effect_float_t mRange = 8.f;
		Effect_float_t mStrength = 1.f;
		lgal::Color mColor = 0x00CCFFFF;
		lgal::world::Vector3 mCameraPosition;
		bool mInverted;
		bool mCompleted = false;

		std::vector<std::shared_ptr<DataObjects::MapLabel>> mLabels;

		uint16_t const mCubeDepthRes = 2048;

		lgal::world::Vector2 mPosition;

		// TODO see if we can get this down to head height (something about cpu/gpu height doesn't agree)
		Effect_float_t mHeightOffsetKm = 0.010; // in km
		lgal::world::Vector3 mOffsetPos;

		Effect_float_t mNearPlane;
		Effect_float_t mFarPlane;

		onyx::Pyramid::CullResult mCullState;

		// cubemap for viewshed/point light shadows
		bgfx::TextureHandle mCubemapDepthTexHandle[2] = { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE };
		bgfx::FrameBufferHandle mCubemapDepthFrameBufferHandle[6] = { BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE, BGFX_INVALID_HANDLE };
		bgfx::Attachment mCubemapAttachments[6][2];

		void allocateFramebuffer();
		void deallocateFramebuffer();

		float mCubemapProj[16] = { };
		float mCubemapView[6][16] = { };

		void setCubeView(bgfx::ViewId viewId, int side);
		void updateLabels();

		static lgal::world::Vector3 const sCubemapLookDirs[6];
		static lgal::world::Vector3 const sCubemapUpDirs[6];
		static Effect_float_t const sCubemapHeadings[6];

	};

} }

#endif