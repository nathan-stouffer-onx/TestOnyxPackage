#include "Fills.h"

#include <cstring>

#include <array>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <lucid/Profiler.h>

#include <3rdParty/delanuator/delaunator.hpp>

#include "Tessellation/PolyGrid.h"
#include "Rendering/VertStructs.h"

namespace onyx {
namespace Tessellation {

	constexpr uint32_t cGridSize = 32;
	static PolyGrid sSubdivisionGrid(cGridSize);
	static float sSubdivisionSize = 1.f / float(cGridSize);
	static std::array<lgal::gpu::Vector2, 4> sClip = { { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 } } };
	static lgal::gpu::AABB2d sTileAABB = { { 0, 0 }, { 1, 1 } };

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("generate grid vertices");

		if (lmath::intersects(hull.aabb(), sTileAABB) == lmath::Intersections::NONE)
		{
			return; // Entire polygon is clipped
		}

		auto gridPoints = sSubdivisionGrid.getContainedVertices(hull, holes);

		{
			LUCID_PROFILE_SCOPE("delaunation");

			auto gridSize = gridPoints.size();

			std::vector<lgal::gpu::Vector2> vertData;

			std::vector<lgal::gpu::Polygon> subdivided;

			size_t loopSize = 0;

			subdivided.push_back(lmath::subdivide(lmath::clip(hull, sClip), sSubdivisionSize));
			loopSize += subdivided.back().size();

			for (auto const& ring : holes)
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sClip), sSubdivisionSize));
				loopSize += subdivided.back().size();
			}

			if (loopSize == 0)
			{
				return;
			}

			vertData.resize(loopSize + gridSize);
			auto vertPtr = vertData.data();

			size_t subdividedPtr = 0;
			for (auto const& poly : subdivided)
			{
				memcpy(vertPtr + subdividedPtr, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
				subdividedPtr += poly.size();
			}

			if (gridSize > 0)
			{
				memcpy(vertPtr + loopSize, gridPoints.data(), gridSize * sizeof(gpu_float_t) * 2);
			}

			delaunator::Delaunator<gpu_float_t> d((gpu_float_t*)vertPtr, (loopSize + gridSize) * 2);

			for (size_t tri = 0; tri < d.triangles.size(); tri += 3)
			{
				auto v0 = vertPtr[d.triangles[tri]];
				auto v1 = vertPtr[d.triangles[tri + 1]];
				auto v2 = vertPtr[d.triangles[tri + 2]];

				auto centroid = (v0 + v1 + v2) * (1.f / 3.f);

				if (!hull.contains(centroid))
				{
					continue;
				}

				bool contains = true;

				for (size_t hole = 0; contains && hole < holes.size(); ++hole)
				{
					contains = !holes[hole].contains(centroid);
				}

				if (!contains)
				{
					continue;
				}

				indices.push_back(uint16_t(d.triangles[tri]));
				indices.push_back(uint16_t(d.triangles[tri + 1]));
				indices.push_back(uint16_t(d.triangles[tri + 2]));
			}

			vertices.reserve(vertData.size());

			for (auto const& v : vertData)
			{
				vertices.push_back({ v, style });
			}
		}
	}

} }