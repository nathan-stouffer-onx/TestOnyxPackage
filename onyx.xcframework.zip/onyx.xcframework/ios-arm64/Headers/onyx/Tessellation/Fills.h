#ifndef __TESSELLATION_FILLS_H__
#define __TESSELLATION_FILLS_H__

#include <vector>

#include <lucid/gal/Types.h>

#include "Rendering/VertStructs.h"

namespace onyx {
namespace Tessellation {

	// TODO consider passing in a Holygon -- Holygon::contains is unit tested
	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes, lgal::gpu::Vector2 const& style);

} }

#endif