#ifndef __TESSELLATION_LINES_H__
#define __TESSELLATION_LINES_H__

#include <vector>

#include <lucid/gal/Types.h>

#include "Rendering/VertStructs.h"

namespace onyx {
namespace Tessellation {

	void tessellate(std::vector<Rendering::VertStructs::LineData>& target, lgal::gpu::Vector2 const& style, lgal::gpu::Vector2 const& prevPoint, lgal::gpu::LineSegment2 const& segment, lgal::gpu::Vector2 const& nextPoint,
					gpu_float_t lineLengthA, gpu_float_t lineLengthB, gpu_float_t instLength = (1.0f / 64.0f));

	void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::vector<lgal::gpu::Vector2> const& points, bool loop,
					lgal::gpu::Vector2 style, gpu_float_t maxSegmentLen = 1.0f / 32.0f);

} }

#endif