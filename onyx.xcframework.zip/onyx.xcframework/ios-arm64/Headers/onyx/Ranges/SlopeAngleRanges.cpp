#include "SlopeAngleRanges.h"

using namespace lucid::gal;
using namespace lucid::math;

namespace onyx {

	SlopeAngleRanges::SlopeAngleRanges() :
		SlopeAngleRanges(Utils::Gradient(), std::vector<lgal::world::Range>{})
	{}

	SlopeAngleRanges::SlopeAngleRanges(Utils::Gradient const& line, std::vector<lgal::world::Range> const& ranges) :
		mColorLine(line),
		mRanges(ranges)
	{
		buildTexture();
	}

	SlopeAngleRanges::~SlopeAngleRanges()
	{
		destroyTexture();
	}

	void SlopeAngleRanges::buildTexture()
	{
		destroyTexture();

		uint32_t data[cResolution] = { 0 };
		for (uint32_t i = 0; i < cResolution; i++)
		{
			// TODO possible optimization is to pack this texture so the shaders just index with 1 - normal.z
			// we would pack with 1 - normal.z, as opposed to just normal.z, so that we lose precision on high
			// slope angles instead of low slope angles. we would have to lose precision on one of them because
			// the encoding uses arccos

			// compute t in [0, 1] -- sample pixel centers
			auto t = (Map3D_float_t(i) + 0.5) / Map3D_float_t(cResolution);

			// sample the color and write to the data buffer
			Color color = mColorLine.sample(t);
			data[i] = color.abgr();

			// iterate over the ranges, only turning the color on if phi is in one of the ranges
			auto phi = t * constants::half_pi<Map3D_float_t>();
			uint32_t on = 0x00FFFFFF;
			for (lgal::world::Range const& range : mRanges)
			{
				// if in the range (and not a zero range), flag byte as on via alpha channel
				on |= (range.contains(phi) && range.begin != range.end) ? (uint8_t)(color.a * 255.0f) << 24 : 0x00000000;
			}

			// set the color as on/off
			data[i] &= on;
		}

		bgfx::Memory const* mem = bgfx::copy((void*)data, cResolution * sizeof(uint32_t));
		mHandle = bgfx::createTexture2D(uint16_t(cResolution), 1, false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
		bgfx::setName(mHandle, "SlopeAngleRangesTexture");
	}

	void SlopeAngleRanges::destroyTexture()
	{
		if (bgfx::isValid(mHandle))
		{
			bgfx::destroy(mHandle);
			mHandle = BGFX_INVALID_HANDLE;
		}
	}

	void SlopeAngleRanges::setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const
	{
		shader->setParameter("s_SlopeAngleTexture", mHandle);
	}

}