#include "HeightRanges.h"

#include <cstring> // for Linux memset

#include "Utils/MapMath.h"

using namespace lucid::gal;
using namespace lucid::math;

namespace onyx {

	namespace ContextVariables {
		std::string const HeightRangesGradient("HeightRangesGradient");
		std::string const HeightRanges("HeightRanges");
	}

	HeightRanges::HeightRanges() :
		HeightRanges(Utils::Gradient(), std::vector<lgal::world::Range>{})
	{}

	HeightRanges::HeightRanges(Utils::Gradient const& line, std::vector<lgal::world::Range> const& ranges) :
		mColorLine(line),
		mRanges(ranges)
	{
		buildTexture({ MapMath::cMinHeight, MapMath::cMaxHeight });
	}

	HeightRanges::~HeightRanges()
	{
		destroyTexture();
	}

	void HeightRanges::buildTexture(lgal::world::Range const& heightExtents)
	{
		// use integer end points and make each pixel step 1 meter
		// if the range covers more than 4096m, just use 4096. we are probably zoomed out enough that it won't matter
		auto begin = std::clamp(std::floor(heightExtents.begin), MapMath::cMinHeight, MapMath::cMaxHeight);
		auto end = std::clamp(std::ceil(heightExtents.end), MapMath::cMinHeight, MapMath::cMaxHeight);

		if (mExtent != lgal::world::Range{ begin, end } || mIsDirty)
		{
			destroyTexture();

			uint32_t size = std::min(uint32_t(end - begin) * 1000, cMaxResolution);

			uint32_t* data = new uint32_t[size];
			std::memset((void*)data, 0, size);
			for (uint32_t i = 0; i < size; i++)
			{
				// compute t in [0, 1] -- sample pixel centers
				auto u = (Map3D_float_t(i) + 0.5) / Map3D_float_t(size);
				// compute the height at the specified t value
				auto height = lerp(begin, end, u);

				// compute t in [MapMath::cMinHeight, MapMath::cMaxHeight]
				auto t = lucid::math::inverseLerp(MapMath::cMinHeight, MapMath::cMaxHeight, height);

				// sample the color and write to the data buffer
				Color color = mColorLine.sample(t);
				data[i] = color.abgr();

				// iterate over the ranges, only turning the color on if the height is in one of the ranges
				uint32_t on = 0x00FFFFFF;
				for (lgal::world::Range const& range : mRanges)
				{
					// if in the range (and not a zero range), flag byte as on via alpha channel
					on |= (range.contains(height) && range.begin != range.end) ? (uint8_t)(color.a * 255.0f) << 24 : 0x00000000;
				}

				// set the color as on/off
				data[i] &= on;
			}

			// create gpu memory and free cpu memory
			bgfx::Memory const* mem = bgfx::copy((void*)data, size * sizeof(uint32_t));
			delete[] data;

			// create texture
			mHandle = bgfx::createTexture2D(uint16_t(size), 1, false, 1, bgfx::TextureFormat::RGBA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
			bgfx::setName(mHandle, "HeightRangesTexture");

			mExtent = { begin, end };
			mIsDirty = false;
		}
	}

	void HeightRanges::destroyTexture()
	{
		if (bgfx::isValid(mHandle))
		{
			bgfx::destroy(mHandle);
			mHandle = BGFX_INVALID_HANDLE;
		}
	}

	void HeightRanges::setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const
	{
		shader->setParameter("s_HeightBandTexture", mHandle);
	}

}
