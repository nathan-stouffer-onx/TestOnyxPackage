#ifndef __SLOPE_ASPECT_RANGES_H__
#define __SLOPE_ASPECT_RANGES_H__

#include <bgfx/bgfx.h>

#include <Utils/Gradient.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx {

	class SlopeAspectRanges
	{
	public:

		SlopeAspectRanges();
		SlopeAspectRanges(Utils::Gradient const& line, std::vector<lgal::world::Range> const& ranges = {});
		~SlopeAspectRanges();

		void setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const;

		inline void setRanges(std::vector<lgal::world::Range> const& ranges) { mRanges = ranges; }

		inline bgfx::TextureHandle getTextureHandle() const { return mHandle; }

		void buildTexture();

	private:

		static constexpr uint32_t cResolution = 512;

		Utils::Gradient mColorLine;

		std::vector<lgal::world::Range> mRanges;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

		void destroyTexture();

	};

}

#endif