#ifndef __HEIGHT_RANGES_H__
#define __HEIGHT_RANGES_H__

#include <bgfx/bgfx.h>

#include <Utils/Gradient.h>

#include "TerrainEffects/TerrainEffectBase.h"

namespace onyx {

	class HeightRanges
	{
	public:

		HeightRanges();
		HeightRanges(Utils::Gradient const& line, std::vector<lgal::world::Range> const& ranges = {});
		~HeightRanges();

		void setTerrainParameters(std::shared_ptr<onyx::Shaders::ShaderDefinition>& shader) const;

		inline void setRanges(std::vector<lgal::world::Range> const& ranges) { mIsDirty = true; mRanges = ranges; }

		inline lgal::world::Range getExtent() const { return mExtent; }

		void buildTexture(lgal::world::Range const& heightExtents);

	private:

		static constexpr uint32_t cMaxResolution = 4096;

		Utils::Gradient mColorLine;

		std::vector<lgal::world::Range> mRanges;

		lgal::world::Range mExtent;

		bool mIsDirty = true;

		bgfx::TextureHandle mHandle = BGFX_INVALID_HANDLE;

		void destroyTexture();
	};

}

#endif