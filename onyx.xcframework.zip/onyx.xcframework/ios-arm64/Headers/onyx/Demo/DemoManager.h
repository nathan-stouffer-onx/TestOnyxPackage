#ifndef DEMOMANAGER_H_
#define DEMOMANAGER_H_

#include "bgfx/bgfx.h"
#include "bx/math.h"

#include <map>
#include <functional>
#include <mutex>
#include <vector>
#include <string>

#include <3rdParty/nlohmann/json.hpp>
#include "DemoStep.h"
#include <Shaders/ShaderEnums.h>

class Map3D;
class ShaderParam;

class DemoManager
{
public:
    DemoManager();
	~DemoManager();
	static DemoManager* Instance();

	void startDemo();
	void setMap3d(Map3D* m3d);
	void update(float timeStep);

	void addStep(DemoStep step);
	void startRecording();
	void stopRecording();
	bool isRecording() { return mRecording; }

	void recordShaderState(ShaderEnums::ConfigurableShaders shader);

	nlohmann::json to_json();
	void from_json(nlohmann::json j);

private:

	bool mRecording;
	bool mPlaySteps;
	std::vector<DemoStep> mDemoSteps;
	size_t mCurrentStep;

	void activateStep(DemoStep& step);

	void activateChangeLod(DemoStep& step);

	void activatePickVector(DemoStep& step);
	void activateUnselectVector(DemoStep& step);

	void activateEnableShaderComponent(DemoStep& step);
	void activateDisableShaderComponent(DemoStep& step);
	void activateSetShaderParam(DemoStep& step);
	void activateSetShowStats(DemoStep& step);

	void setPointerState(DemoStep const& step);
	void setPointerPosition(DemoStep const& step);

	void activateLoadWaypoint(DemoStep& step);
	void activateAddWaypoint(DemoStep& step);
	void activateSelectWaypoint(DemoStep& step);
	void activateUnselectWaypoint(DemoStep& step);
	void activateUnselectAllWaypoints(DemoStep& step);
	void activateMoveWaypointTo(DemoStep& step);
	void activateSetWaypointIcon(DemoStep& step);
	void activateSetWaypointIconColor(DemoStep& step);
	void activateSetWaypointDiskColor(DemoStep& step);
	void activateSetWaypointBodyColor(DemoStep& step);
	void activateSetWaypointOutlineColor(DemoStep& step);
	void activateDeleteWaypoint(DemoStep& step);
	void activateDeleteSelectedWaypoints(DemoStep& step);

	Map3D* mMap3d;
protected:
	static DemoManager* sSingleton;
};
#endif
