#include "DemoManager.h"
#include <future>
#include "../Map3D.h"
#include "../DataObjects/Waypoint.h"
#include "bx/timer.h"
#include "../Utils/jsonConversion.h"

DemoManager* DemoManager::sSingleton = NULL;

DemoManager* DemoManager::Instance()
{
	if (sSingleton == NULL)
	{
		sSingleton = new DemoManager();
	}

	return sSingleton;
}

DemoManager::DemoManager() :
	  mRecording(false)
	, mPlaySteps(false)
	, mCurrentStep(0)
	, mMap3d(NULL)
{
	sSingleton = this;
}

DemoManager::~DemoManager()
{
	if (sSingleton == this)
		sSingleton = nullptr;
}

nlohmann::json DemoManager::to_json()
{
	nlohmann::json j = mDemoSteps;
	return j;
}

void DemoManager::from_json(nlohmann::json j)
{
	//auto parsed = j.get<std::vector<DemoStep>>();
	mDemoSteps = j.get<std::vector<DemoStep>>();
}

void DemoManager::recordShaderState(ShaderEnums::ConfigurableShaders shader)
{
	if (!mRecording)
		return;

	//get our starting terrain material state and camera position
	DemoStep shaders;
	shaders.dataInt = (int)shader;
	shaders.stepAction = DemoAction::SetShaderParams;

	auto activeShader = ShaderManager::Instance()->getShader(shader, 0);
	shaders.dataString = activeShader->mSignature;
	
	std::vector<ShaderParam*> params = ShaderManager::Instance()->getActiveParameters(shader);
	std::vector<ShaderParam> p;
	for (size_t i = 0; i < params.size(); i++)
	{
		p.push_back(*params[i]);
	}
	shaders.shaderParams = p;
	addStep(shaders);

	for (size_t i = 0; i < params.size(); i++)
	{
		delete params[i];
	}
}

void DemoManager::startRecording()
{
	mRecording = true;
	mCurrentStep = 0;
	mDemoSteps.clear();
	auto input = mMap3d->getInput();

	recordShaderState(ShaderEnums::ConfigurableShaders::Terrain);

	for (size_t i = 0; i < in::cMaxPointers; ++i)
	{
		auto const& button = input->getPointer((int)i);
		if (button->getState() == in::ButtonState::Released)
		{
			continue;
		}

		DemoStep ptrState;
		ptrState.stepAction = DemoAction::SetPointerState;
		ptrState.dataBool = true;
		ptrState.dataInt = (int)i;
		ptrState.dataVec3 = lgal::toBx(button->getPosition());
		addStep(ptrState);
	}
}

void DemoManager::stopRecording()
{
	mRecording = false;
	//calculate the time from the previous step to when we stopped recording
	int64_t now = bx::getHPCounter();
	float time = (float)((double)now / double(bx::getHPFrequency()));

	if (mDemoSteps.size() > 0)
	{
		mDemoSteps[mDemoSteps.size() - 1].stepTotalTime = time - mDemoSteps[mDemoSteps.size() - 1].stepTotalTime;
	}
}

void DemoManager::addStep(DemoStep step)
{
	//calculate the time from the previous step to this one
	int64_t now = bx::getHPCounter();
	float time = (float)((double)now / double(bx::getHPFrequency()));

	if (mDemoSteps.size() > 0)
	{
		mDemoSteps[mDemoSteps.size() - 1].stepTotalTime = time - mDemoSteps[mDemoSteps.size() - 1].stepTotalTime;
	}

	mDemoSteps.push_back(step);
	mDemoSteps[mDemoSteps.size() - 1].stepTotalTime = time; //store the time this step was created at for when we add the next one
}

void DemoManager::startDemo()
{
	mCurrentStep = 0;

	if (mDemoSteps.size() > 0)
	{
		activateStep(mDemoSteps[mCurrentStep]);

		mRecording = false;
		mPlaySteps = true;
	}
}

void DemoManager::setMap3d(Map3D* m3d)
{
	mMap3d = m3d;
}

void DemoManager::update(float timeStep)
{
	if (mPlaySteps)
	{
		if (mCurrentStep < 0 || mCurrentStep >= mDemoSteps.size() || mMap3d == NULL)
		{
			mPlaySteps = false; //no steps left so we're done with playback
			return;
		}

		DemoStep& step = mDemoSteps[mCurrentStep];

		step.stepCurrentTime += timeStep;
		if (step.stepCurrentTime >= step.stepTotalTime)
		{
			mCurrentStep++;
			if (mCurrentStep >= 0 && mCurrentStep < mDemoSteps.size())
			{
				activateStep(mDemoSteps[mCurrentStep]);
			}
			return;
		}

		if (step.stepAction == DemoAction::MoveWaypointTo)		// currently not animated, just move immediately
		{
			bx::Vec3 move = bx::sub(step.moveTo, step.dataVec3);
			float percent = step.stepCurrentTime / step.stepTotalTime;
			move = bx::add(step.dataVec3, bx::mul(move, percent));
			mMap3d->moveWaypointTo(step.dataString, lgal::toVec3(move)); //todo - add world pos option
		}
	}
}

void DemoManager::activateStep(DemoStep& step)
{
	switch (step.stepAction)
	{
		case(DemoAction::ChangeLod):
			activateChangeLod(step);
			break;
		case(DemoAction::PickVector):
			activatePickVector(step);
			break;
		case(DemoAction::UnselectVector):
			activateUnselectVector(step);
			break;
		case(DemoAction::EnableShaderComponent):
			activateEnableShaderComponent(step);
			break;
		case(DemoAction::DisableShaderComponent):
			activateDisableShaderComponent(step);
			break;
		case(DemoAction::SetShaderParams):
			activateSetShaderParam(step);
			break;
		case(DemoAction::SetShowStats):
			activateSetShowStats(step);
			break;
		case(DemoAction::SetPointerState):
			setPointerState(step);
			break;
		case DemoAction::SetPointerPosition:
			setPointerPosition(step);
			break;
		case(DemoAction::LoadWaypoint):
			activateLoadWaypoint(step);
			break;
		case(DemoAction::AddWaypoint):
			activateAddWaypoint(step);
			break;
		case(DemoAction::SelectWaypoint):
			activateSelectWaypoint(step);
			break;
		case(DemoAction::UnselectWaypoint):
			activateUnselectWaypoint(step);
			break;
		case(DemoAction::UnselectAllWaypoints):
			activateUnselectAllWaypoints(step);
			break;
		case(DemoAction::MoveWaypointTo):
			activateMoveWaypointTo(step);
			break;
		case(DemoAction::SetWaypointIcon):
			activateSetWaypointIcon(step);
			break;
		case(DemoAction::SetWaypointIconColor):
			activateSetWaypointIconColor(step);
			break;
		case(DemoAction::SetWaypointDiskColor):
			activateSetWaypointDiskColor(step);
			break;
		case(DemoAction::SetWaypointBodyColor):
			activateSetWaypointBodyColor(step);
			break;
		case(DemoAction::SetWaypointOutlineColor):
			activateSetWaypointOutlineColor(step);
			break;
		case(DemoAction::DeleteWaypoint):
			activateDeleteWaypoint(step);
			break;
		case(DemoAction::DeleteSelectedWaypoints):
			activateDeleteSelectedWaypoints(step);
			break;
		default:
			logE("Unrecognized demo action: %d", int(step.stepAction));
			break;
	};
}

void DemoManager::activateChangeLod(DemoStep& step)
{
	mMap3d->setTileLod(step.dataString, step.dataFloat);
}

void DemoManager::activatePickVector(DemoStep&)
{

}
void DemoManager::activateUnselectVector(DemoStep&)
{

}

void DemoManager::activateEnableShaderComponent(DemoStep&)
{

}
void DemoManager::activateDisableShaderComponent(DemoStep&)
{

}
void DemoManager::activateSetShaderParam(DemoStep& step)
{
	if (!isRecording())
	{
		//having to shuffle things around because json doesnt seem to be playing nice with pointer objects for some reason, so...

		auto configuration = ShaderManager::Instance()->getParamsFromSig(step.dataString);

		std::vector<ShaderParam*> pointers;
		for (size_t i = 0; i < step.shaderParams.size(); i++)
			pointers.push_back(&step.shaderParams[i]);
		mMap3d->setShaderParameters((ShaderEnums::ConfigurableShaders)step.dataInt, pointers, configuration);
	}
}
void DemoManager::activateSetShowStats(DemoStep& step)
{
	if (!isRecording())
	{
		mMap3d->setShowStats(step.dataBool);
	}
}

void DemoManager::setPointerState(DemoStep const& step)
{
	auto input = mMap3d->getInput();
	(step.dataBool) ? input->setPointerDown(step.dataInt) : input->setPointerUp(step.dataInt);
	input->setPointerPosition(step.dataInt, step.dataVec3.x, step.dataVec3.y, step.dataVec3.z);
}

void DemoManager::setPointerPosition(DemoStep const& step)
{
	auto input = mMap3d->getInput();
	input->setPointerPosition(step.dataInt, step.dataVec3.x, step.dataVec3.y, step.dataVec3.z);
}

void DemoManager::activateLoadWaypoint(DemoStep &step)
{
	if (!isRecording())
	{
		nlohmann::json j = nlohmann::json::parse(step.dataString);
		mMap3d->loadWaypoint(j);
	}
}
void DemoManager::activateAddWaypoint(DemoStep& step)
{
	if (!isRecording())
	{
		mMap3d->addWaypoint(step.dataString, lgal::toVec3(step.dataVec3), 0xFFFF3300);
	}
}
void DemoManager::activateMoveWaypointTo(DemoStep&)
{
	// do in update() method to keep animation
}
void DemoManager::activateSelectWaypoint(DemoStep& step)
{
	if (!isRecording())
	{
		mMap3d->selectWaypoint(step.dataString);
	}
}
void DemoManager::activateUnselectWaypoint(DemoStep& step)
{
	if (!isRecording())
	{
		mMap3d->unselectWaypoint(step.dataString);
	}
}
void DemoManager::activateUnselectAllWaypoints(DemoStep&)
{
	if (!isRecording())
	{
		mMap3d->unselectAllWaypoints();
	}
}
void DemoManager::activateSetWaypointIcon(DemoStep& step)
{
	if (!isRecording())
	{
		nlohmann::json j = nlohmann::json::parse(step.dataString);
		std::string uuidStr = j["uuidStr"];
		std::string icon = j["icon"];
		mMap3d->setWaypointIcon(uuidStr, icon);
	}
}
void DemoManager::activateSetWaypointIconColor(DemoStep& step)
{
	if (!isRecording())
	{
		std::string uuidStr = step.dataString;
		bx::Vec3 rgb = step.dataVec3;
		lucid::gal::Color col(rgb.x, rgb.y, rgb.z, step.dataFloat);
		mMap3d->setWaypointIconColor(uuidStr, col);
	}
}
void DemoManager::activateSetWaypointDiskColor(DemoStep& step)
{
	if (!isRecording())
	{
		std::string uuidStr = step.dataString;
		bx::Vec3 rgb = step.dataVec3;
		lucid::gal::Color col(rgb.x, rgb.y, rgb.z, step.dataFloat);
		mMap3d->setWaypointDiskColor(uuidStr, col);
	}
}
void DemoManager::activateSetWaypointBodyColor(DemoStep& step)
{
	if (!isRecording())
	{
		std::string uuidStr = step.dataString;
		bx::Vec3 rgb = step.dataVec3;
		lucid::gal::Color col(rgb.x, rgb.y, rgb.z, step.dataFloat);
		mMap3d->setWaypointBodyColor(uuidStr, col);
	}
}
void DemoManager::activateSetWaypointOutlineColor(DemoStep& step)
{
	if (!isRecording())
	{
		std::string uuidStr = step.dataString;
		bx::Vec3 rgb = step.dataVec3;
		lucid::gal::Color col(rgb.x, rgb.y, rgb.z, step.dataFloat);
		mMap3d->setWaypointOutlineColor(uuidStr, col);
	}
}
void DemoManager::activateDeleteWaypoint(DemoStep& step)
{
	if (!isRecording())
	{
		mMap3d->deleteWaypoint(step.dataString);
	}
}
void DemoManager::activateDeleteSelectedWaypoints(DemoStep&)
{
	if (!isRecording())
	{
		mMap3d->deleteSelectedWaypoints();
	}
}
