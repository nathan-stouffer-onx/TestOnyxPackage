#ifndef __EVENT_CALLBACKS_H__
#define __EVENT_CALLBACKS_H__

#include <functional>

namespace onyx {
namespace Events {

	enum class EventType
	{
		CAMERA_MOVED,
		CAMERA_STOPPED,
		FRAME,
		LONG_FRAME,
		TILES_LOADED
	};

	typedef std::function<void()> CallbackT;

	void addCallback(EventType type, CallbackT callback);
	// TODO add capability to remove a callback
	// TODO probably add some sort of id so we can remove callbacks when deallocating objects

	void trigger(EventType type);

	void shutdown();

} }

#endif