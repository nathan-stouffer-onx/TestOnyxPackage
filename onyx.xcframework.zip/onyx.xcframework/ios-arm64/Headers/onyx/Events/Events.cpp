#include "Events.h"

#include <map>
#include <vector>

#include <System/Map3DException.h>

namespace onyx {
namespace Events {
	
	static std::map<EventType, std::vector<CallbackT>> sCallbacks;

	void trigger(EventType type)
	{
		for (auto& callback : sCallbacks[type])
		{
			MAP3D_TRY
				callback();
			MAP3D_CATCH
				logE("callback threw an exception: " + ex.summarize());
			MAP3D_CATCH_ALL
				logE("callback threw an unrecognized exception");
			MAP3D_END_CATCH
		}
	}

	void addCallback(EventType type, CallbackT callback)
	{
		sCallbacks[type].push_back(callback);
	}

	void shutdown()
	{
		sCallbacks.clear();
	}

} }

