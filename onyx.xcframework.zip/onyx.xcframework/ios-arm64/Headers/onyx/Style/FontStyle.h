#if !defined(FONT_STYLE_H)
#define FONT_STYLE_H
#pragma once

#include <string>
#include <memory>

#include <lucid/gal/Types.h>
#include <Font/FontManager.h>
#include <Styling/Styles/FontStyle.h>
namespace onyx {
namespace Style {

	class FontStyleManager {
	public:
		static std::shared_ptr<Styling::FontStyle> findFontStyle(Styling::FontStyle const& style);
		static std::shared_ptr<Styling::FontStyle> cacheFontStyle(Styling::FontStyle const& style);
		static void Shutdown();
	};

	template<class T>
	Styling::FontStyle randomFontStyle(T const& param)
	{
		std::hash<T> hasher;
		std::hash<size_t> sizeHasher;
		auto hashed = hasher(param);

		Styling::FontStyle result;
		result.font = Font::randomFontFace(param);
		result.textColor = lucid::gal::Color::HashColor(hashed);
		hashed = sizeHasher(hashed);
		result.outlineColor = lucid::gal::Color::HashColor(hashed);
		hashed = sizeHasher(hashed);
		result.dropshadowColor = lucid::gal::Color::HashColor(hashed);
		result.kerningModifier = float(hashed & 0x1FFF) / 2048.f;

		return result;
	}
	
} }

#endif