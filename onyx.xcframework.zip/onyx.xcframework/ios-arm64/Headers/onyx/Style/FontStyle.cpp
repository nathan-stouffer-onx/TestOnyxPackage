#include "FontStyle.h"

#include <unordered_map>
#include <mutex>

#include <System/Map3DException.h>

namespace onyx {
namespace Style {

std::unordered_map<Styling::FontStyle, std::shared_ptr<Styling::FontStyle>> cachedFonts;

std::recursive_mutex cacheGuard;

void FontStyleManager::Shutdown()
{
	cachedFonts.clear();
}

std::shared_ptr<Styling::FontStyle> FontStyleManager::cacheFontStyle(Styling::FontStyle const& style)
{
	std::lock_guard l(cacheGuard);
	
	auto result = std::make_shared<Styling::FontStyle>(style);
	cachedFonts.emplace(style, result);
	
	return result;
}

std::shared_ptr<Styling::FontStyle> FontStyleManager::findFontStyle(Styling::FontStyle const& style)
{
	auto found = cachedFonts.find(style);
	if (found == cachedFonts.end())
	{
		std::lock_guard l(cacheGuard);
		found = cachedFonts.find(style);
		if (found == cachedFonts.end())
		{
			return cacheFontStyle(style);
		}
	}

	return found->second;
}

} }