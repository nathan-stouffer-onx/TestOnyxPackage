#ifndef __INDEXED_LIST_H__
#define __INDEXED_LIST_H__

#include <list>
#include <unordered_map>

namespace onyx {
namespace Caching {

	/*
	* A class to store a list along with a keyed index into the list. It is mostly a regular old list, but we get the
	* added bonus that we can easily check whether a key is in the list and replace the value at that key.
	*/
	template<typename KeyT, typename EntryT, typename KeyHasherT = std::hash<KeyT>>
	class IndexedList
	{
	public:

		struct Pair
		{
			KeyT key;
			EntryT entry;
		};

	private:

		// these aliases are a little verbose but they ensure consistency and avoid having to write "typename" all over this class
		using ListT = std::list<Pair>;
		using ListT_iterator = typename ListT::iterator;
		using ListT_const_iterator = typename ListT::const_iterator;

		using MapT = std::unordered_map<KeyT, ListT_iterator, KeyHasherT>;
		using MapT_iterator = typename MapT::iterator;
		using MapT_const_iterator = typename MapT::const_iterator;

		ListT mList;
		MapT mIndex;

	public:

		using iterator = ListT_iterator;
		using const_iterator = ListT_const_iterator;

	public:

		inline size_t size() const { return mList.size(); }
		inline bool empty() const { return mList.empty(); }

		void clear()
		{
			mIndex.clear();
			mList.clear();
		}

		const_iterator find(KeyT const& key) const
		{
			MapT_const_iterator iter = mIndex.find(key);
			if (iter != mIndex.end())
			{
				return iter->second;
			}
			else
			{
				return mList.end();
			}
		}

		iterator find(KeyT const& key)
		{
			MapT_iterator iter = mIndex.find(key);
			if (iter != mIndex.end())
			{
				return iter->second;
			}
			else
			{
				return mList.end();
			}
		}

		inline bool contains(KeyT const& key) const
		{
			return mIndex.find(key) != mIndex.end();
		}

		inline Pair const& at(KeyT const& key) const { return *mIndex.at(key); }
		inline Pair& at(KeyT const& key) { return *mIndex.at(key); }

		inline void erase(const_iterator iter)
		{
			mIndex.erase(iter->key);
			mList.erase(iter);
		}

		void erase(KeyT const& key)
		{
			ListT_const_iterator iter = find(key);
			if (iter != mList.end())
			{
				erase(iter);
			}
		}

		inline const_iterator replace(KeyT const& key, EntryT entry)
		{
			iterator iter = mIndex.at(key);
			Pair& pair = *iter;
			pair.entry = std::move(entry);
			return iter;
		}

		// moves iter to the specified position in the list
		inline void splice(const_iterator pos, const_iterator iter)
		{
			mList.splice(pos, mList, iter);
		}

		// if the key is present in the list, moves its iterator to the specified position
		inline void splice(const_iterator pos, KeyT const& key)
		{
			MapT_const_iterator found = mIndex.find(key);
			if (found != mIndex.end())
			{
				const_iterator iter = found->second;
				splice(pos, iter);
			}
		}

		inline void insert(const_iterator pos, KeyT const& key, EntryT entry)
		{
			erase(key);
			ListT_iterator inserted = mList.insert(pos, { key, std::move(entry) });
			mIndex[key] = inserted;
		}

		inline void push_front(KeyT const& key, EntryT entry)
		{
			insert(mList.begin(), key, std::move(entry));
		}

		inline void push_back(KeyT const& key, EntryT entry)
		{
			insert(mList.end(), key, std::move(entry));
		}

		inline void pop_front()
		{
			mIndex.erase(mList.front().key);
			mList.pop_front();
		}

		inline void pop_back()
		{
			mIndex.erase(mList.back().key);
			mList.pop_back();
		}

		inline Pair const& front() const { return mList.front(); }
		inline Pair& front() { return mList.front(); }

		inline Pair const& back() const { return mList.back(); }
		inline Pair& back() { return mList.back(); }

		const_iterator begin() const { return mList.begin(); }
		const_iterator end()   const { return mList.end(); }

		iterator begin() { return mList.begin(); }
		iterator end() { return mList.end(); }

	};

} }

#endif