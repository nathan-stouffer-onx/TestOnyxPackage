#ifndef __LEAST_RECENTLY_USED_H__
#define __LEAST_RECENTLY_USED_H__

#include <list>
#include <unordered_map>
#include <algorithm>

#include "IndexedList.h"

namespace onyx {
namespace Caching {

	/*
	* A templated class that implements a Least Recently Used cache. The cache itself is stored in an IndexedList that is sorted
	* by most recently used to least recently used. Owning classes can insert, erase, and touch entries. Access to both individual
	* entries and to iterators is provided.
	*
	* NOTE: If LRU::mOwnsHeapMemory is true (set via a constructor parameter) and EntryT is a raw pointer, the LRU will assume
	* ownership of the pointer. It will free heap memory when erasing entry and free all entries in the destructor
	*/
	template<typename KeyT, typename EntryT, typename KeyHasherT = std::hash<KeyT>>
	class LRU
	{

	public:

		using CacheT = IndexedList<KeyT, EntryT, KeyHasherT>;

		using iterator = typename CacheT::iterator;
		using const_iterator = typename CacheT::const_iterator;

	private:

		CacheT mCache;

		bool mOwnsHeapMemory;

	public:

		LRU(bool ownsHeapMemory = true) : mOwnsHeapMemory(ownsHeapMemory) {}
		~LRU()
		{
			// if EntryT is a pointer -- evaluated at compile time
			if constexpr (std::is_pointer<EntryT>::value)
			{
				// free heap memory if the LRU owns it
				if (mOwnsHeapMemory)
				{
					for (auto& [key, entry] : mCache)
					{
						delete entry;
					}
				}
			}
		}

		inline size_t size() const { return mCache.size(); }
		inline bool empty()  const { return mCache.empty(); }

		void clear()
		{
			std::vector<KeyT> keys;
			keys.reserve(size());

			for (auto const& [key, entry] : mCache)
			{
				keys.push_back(key);
			}

			for (KeyT const& key : keys)
			{
				erase(key);
			}
		}

		inline const_iterator find(KeyT const& key) const
		{
			return mCache.find(key);
		}

		inline iterator find(KeyT const& key)
		{
			return mCache.find(key);
		}

		inline bool contains(KeyT const& key) const
		{
			return mCache.contains(key);
		}

		void erase(KeyT const& key)
		{
			iterator iter = find(key);
			if (iter != mCache.end())
			{
				// if EntryT is a pointer -- evaluated at compile time
				if constexpr (std::is_pointer<EntryT>::value)
				{
					// free heap memory if the LRU owns it
					if (mOwnsHeapMemory)
					{
						EntryT entry = (*iter).entry;
						delete entry;
					}
				}

				// update book-keeping
				mCache.erase(iter);
			}
		}

		void touch(KeyT const& key)
		{
			iterator iter = find(key);
			// only update the bookeeping if we are tracking the key
			if (iter != mCache.end())
			{
				// move the item to the front of the cache
				mCache.splice(mCache.begin(), iter);
			}
		}

		/*
		* If LRU::mOwnsHeapMemory is true (set via a constructor parameter) and EntryT is a raw pointer, the LRU will assume
		* ownership of the pointer. It will free heap memory when erasing entry and free all entries in the destructor
		*/
		void insert(KeyT const& key, EntryT entry)
		{
			erase(key);						// no-op if the key is not present
			mCache.insert(mCache.begin(), key, entry);
		}
		
		inline EntryT const& at(KeyT const& key) const { return mCache.at(key).entry; }
		inline EntryT& at(KeyT const& key) { return mCache.at(key).entry; }

		const_iterator begin() const { return mCache.begin(); }
		const_iterator end()   const { return mCache.end();   }

		iterator begin() { return mCache.begin(); }
		iterator end()   { return mCache.end();   }

	};

} }

#endif