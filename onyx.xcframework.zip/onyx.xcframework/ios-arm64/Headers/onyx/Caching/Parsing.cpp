#include "Parsing.h"

#include <webp/decode.h>

#include "Caching/DecodeHeight.h"
#include "Utils/BgfxUtils.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Caching {

	std::shared_ptr<ParsedCacheData> ParseTexture(TileCacheKey const& request, SharedStreamT stream)
	{
		LUCID_PROFILE_SCOPE("Parse Texture");

		auto& tileId = request.tile;

		std::string texName = request.source + "_" + std::to_string(tileId.level) + "_" + std::to_string(tileId.x) + "_" + std::to_string(tileId.y) + "_texture";

		bgfx::TextureInfo info;

		if (stream == nullptr)
		{
			logD("Got a null stream for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		if (stream->size() == 0)
		{
			logD("Got an empty stream for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		bgfx::TextureHandle handle = BGFX_INVALID_HANDLE;

		// TODO figure out stream type before parsing. this just tries to have bgfx decode. if that doesn't work, it falls back to webp. if that doesn't work,
		// then we just say that we failed to create the texture
		handle = BgfxUtils::loadTexture(stream->data(), std::uint32_t(stream->size()), texName.c_str(), BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP, 0, &info);

		// if bgfx couldn't decode, try decoding webp
		if (!bgfx::isValid(handle))
		{
			WebPBitstreamFeatures features;
			auto result = WebPGetFeatures(stream->data(), stream->size(), &features);
			// TODO re-enable once we know we are supposed to be parsing a webp stream
			//MAP3D_ASSERT(result == VP8StatusCode::VP8_STATUS_OK, "Error decoding WebP stream features");
			if (result == VP8StatusCode::VP8_STATUS_OK)
			{
				auto stride = features.width * ((features.has_alpha) ? 4 : 3);  // number of bytes per pixel
				auto size = features.height * stride;
				auto mem = bgfx::alloc(size);

				MAP3D_ASSERT((uint32_t)size == mem->size, "Failed to allocate bgfx memory to decode WebP");

				bgfx::TextureFormat::Enum const format = (features.has_alpha) ? bgfx::TextureFormat::RGBA8 : bgfx::TextureFormat::RGB8;
				auto data = (features.has_alpha) ? WebPDecodeRGBAInto(stream->data(), stream->size(), mem->data, size, stride) : WebPDecodeRGBInto(stream->data(), stream->size(), mem->data, size, stride);
				MAP3D_ASSERT(data != nullptr, "Failed to parse WebP stream");

				handle = bgfx::createTexture2D(uint16_t(features.width), uint16_t(features.height), false, 1, format, 0, mem);
				info.storageSize = size;
				info.width = (uint16_t)features.width;
				info.height = (uint16_t)features.height;
				info.format = format;
			}
		}

		if (!bgfx::isValid(handle))
		{
			logD("Failed to create texture for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		return std::shared_ptr<ParsedCacheData>(new ImageUserData(handle, info));
	}

	std::shared_ptr<ParsedCacheData> ParseHeight(TileCacheKey const& request, SharedStreamT stream)
	{
		LUCID_PROFILE_SCOPE("Parse Height");
		auto& tileId = request.tile;

		// using statement to reduce verbosity
		using DEM = Styling::RasterDemSource;

		// TODO (stouff) once we have access to the source, assign the encoding appropriately
		DEM::Encoding encoding = DEM::Encoding::TERRARIUM;

		std::string texName = request.source + "_" + std::to_string(tileId.level) + "_" + std::to_string(tileId.x) + "_" + std::to_string(tileId.y) + "_texture";
		bgfx::TextureHandle handle = BGFX_INVALID_HANDLE;

		if (stream == nullptr)
		{
			logD("Got a null stream for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		if (stream->size() == 0)
		{
			logD("Got an empty stream for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		bimg::ImageContainer* image = BgfxUtils::imageLoad(static_cast<void*>(stream->data()), static_cast<uint32_t>(stream->size()));
		uint8_t const* data = static_cast<uint8_t const*>(image->m_data);
		std::vector<height_float_t> decoded = DecodeHeight(encoding, data, size_t(image->m_size), 0.001f);
		bimg::imageFree(image);

		if (decoded.size() == 0)
		{
			logD("Failed to decode stream for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		// fit the decoded stream to a tile with 2-pixels of padding
		std::vector<height_float_t> fit = Tiles::HeightTile::Fit(DEM::PaddedLength(encoding), DEM::Padding(encoding), decoded);

		size_t length = DEM::Length(encoding);
		uint16_t dim = static_cast<uint16_t>(Tiles::HeightTile::cPadding + length + Tiles::HeightTile::cPadding);

		bgfx::Memory const* mem = bgfx::copy((void*)fit.data(), uint32_t(sizeof(height_float_t) * fit.size()));
		handle = bgfx::createTexture2D(dim, dim, false, 1, bgfx::TextureFormat::R32F, BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP, mem);

		bgfx::TextureInfo info;
		bgfx::calcTextureSize(info, dim, dim, 1, false, false, 1, bgfx::TextureFormat::R32F);

		if (!bgfx::isValid(handle))
		{
			logD("Failed to create texture for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		auto heightTile = std::make_shared<Tiles::HeightTile>(tileId, size_t(dim), Tiles::HeightTile::cPadding, fit, Utils::Timer::nowMS());
		return std::shared_ptr<ParsedCacheData>(new HeightUserData(handle, info, heightTile));
	}

	std::shared_ptr<ParsedCacheData> ParseVector(TileCacheKey const& request, SharedStreamT stream)
	{
		LUCID_PROFILE_SCOPE("Parse Vector");

		if (stream == nullptr)
		{
			logD("Got a null stream for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
			return nullptr;
		}

		if (stream->size() == 0)
		{
			logE("Got a stream of 0 size for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);

			return nullptr;
		}

		auto parsed = std::make_shared<Tiles::VectorTile>(request.tile, stream, Utils::Timer::nowMS());
		return std::shared_ptr<ParsedCacheData>(new VectorUserData(parsed));
	}

} }