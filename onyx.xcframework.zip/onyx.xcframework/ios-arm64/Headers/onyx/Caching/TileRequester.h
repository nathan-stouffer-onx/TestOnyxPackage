#ifndef __TILE_REQUESTER_H__
#define __TILE_REQUESTER_H__

#include <list>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
#include <functional>

#include <Styling/Sources/TiledSources/TileUrlPattern.h>

#include "Atlases/TileAtlas.h"
#include "Utils/TimeFilter.h"
#include "Tiles/TileId.h"
#include "Tiles/HeightTile.h"
#include "Tiles/VectorTile.h"

#include "IndexedList.h"
#include "TileCache.h"

#if defined(PLATFORM_EMSCRIPTEN)
#define NO_TILE_CACHE_THREADS
#else
#include <mutex>
#include <condition_variable>
#include <bx/thread.h>
#endif

namespace onyx {
namespace Caching {

#if !defined(NO_TILE_CACHE_THREADS)
	constexpr size_t MaxCacheThreads = 16;
#endif

	class TileRequester
	{
	friend class TileCache;
	public:
		typedef TileCacheKey EntryKey;

		struct GetRequest
		{
			EntryKey key;
			uint64_t timestamp;

			bool operator==(GetRequest const& rhs) const
			{
				return key == rhs.key;
			}
		};

		class GetRequestHasher {
		public:
			size_t operator()(GetRequest const& req) const
			{
				std::hash<TileCacheKey> hasher;
				return hasher(req.key);
			}
		};

		typedef std::shared_ptr<std::vector<uint8_t>> SharedStreamT;

		enum class RequestThreadStatus
		{
			IDLING,
			DEQUEUEING,
			REQUEST_SENT,
			REQUEST_RECEIVED,
			PARSING,
			COMPLETING,
			UNKNOWN
		};

		//TODO (scott) Extend this class a bit so that exceptions can send more detailed
		//			   information to the TileRequester
		MAP3D_EXCEPTION_SUBTYPE(RequestException, Map3DUtil::Map3DException);
		
		enum class RequestStatus
		{
			QUEUED,
			IN_FLIGHT,
			RECEIVED,
			PARSED,
			PARSE_FAILURE,
			NOT_AVAILABLE
		};

		struct GetResult
		{
			SharedStreamT stream;
			RequestStatus status;
		};

		struct ThreadStatus
		{
			RequestThreadStatus status;
			Utils::Timer::Map3D_time_t requestStartTime;
			Utils::Timer::Map3D_time_t statusStartTime;
			lucid::core::Profiler::Sample const *profile;
			EntryKey key;
		};

		typedef std::function<GetResult(Styling::TileUrlPattern const&, EntryKey const&)> StreamCallbackT;
		typedef std::function<std::shared_ptr<ParsedCacheData>(EntryKey const&, SharedStreamT&)> ParseCallbackT;

		static TileRequester* Instance();
		static void Shutdown();

		void setParseCallback(ParseCallbackT const& callback) { mParseCallback = callback; }
		void setGetCallback(StreamCallbackT const& callback) { mGetCallback = callback; }

		void clearPendingRequest(EntryKey const& request);
		void completeRequest(EntryKey const& request, SharedStreamT& stream);
		static RequestStatus parseStream(EntryKey const& request, SharedStreamT& stream, SharedParsedDataT &parsedResult);
		void failRequest(EntryKey const& request, RequestStatus status);
		void setAsyncFetch(bool enabled) { mAsyncFetches = enabled; }

		struct ParseResult
		{
			EntryKey key;

			// TODO I think get rid of the stream -- once we have it parsed we shouldn't need it anymore
			SharedStreamT stream;
			SharedParsedDataT data;

			RequestStatus status;

			size_t size()
			{
				size_t result = 0;
				if (stream != nullptr)
				{
					result += stream->size();
				}
				if (data != nullptr)
				{
					result += data->size();
				}
				return result;
			}
		};

		ParseResult getNextParsed()
		{
			ParseResult parsed = mParsedQueue.front().entry;
			mParsedQueue.pop_front();
			mParsedSize -= parsed.size();
			return parsed;
		}

	private:

#if !defined(NO_TILE_CACHE_THREADS)

		struct ThreadInfo
		{
			RequestThreadStatus status = RequestThreadStatus::IDLING;
			std::unique_ptr<bx::Thread> thread;
			int threadId = 0;
			EntryKey key;
			Utils::Timer::Map3D_time_t requestStartTime = 0;
			Utils::Timer::Map3D_time_t statusStartTime = 0;
			ThreadInfo(bx::Thread* thread)
				: thread(thread)
			{ }
			lucid::core::Profiler::Sample* profilerStatus = nullptr;
		};

#endif

		void beginRequest(EntryKey const& request);
		void clearStaleRequests(bool onlyEphemeral = true);

		bool mAsyncFetches = false; // Set to true in environments like web where requests do not block
		
		TileRequester();
		~TileRequester();

		static TileRequester *sInstance;

		size_t mParsedSize = 0;		// current size of the parsed items waiting to be inserted to the non-threaded cache

		size_t mMemCacheLimit = MemCacheLimitDefault;

		uint64_t mFrameTimestamp = 0;
		uint64_t mUpdateTimestamp = 0;

		size_t mMaxPendingRequests = 12;

		// collection of parsed tile entries, waiting to be loaded into atlases and managers
		IndexedList<EntryKey, ParseResult> mParsedQueue;

		// collection of the tile entries that are in flight
		std::unordered_set<EntryKey> mPending;

		Utils::TimeFilter<Tiles::TileId> mTimeFilter;

		ParseCallbackT mParseCallback;
		StreamCallbackT mGetCallback;

#if !defined(NO_TILE_CACHE_THREADS)
		std::mutex mParsedMutex,
			mRequestMutex;
		std::condition_variable mReqReadyCondition;

#if DEBUG_TILE_CACHE && !defined(NO_TILE_CACHE_THREADS)
		unsigned int mThreadId;
#endif
		std::list<GetRequest> mEphemeralRequestQueue;
		std::unordered_map<GetRequest, std::list<GetRequest>::iterator, GetRequestHasher> mEphemeralRequests;

		std::list<GetRequest> mPersistentRequestQueue;
		std::unordered_map<GetRequest, std::list<GetRequest>::iterator, GetRequestHasher> mPersistentRequests;
#endif

		bool mKeepRunning = true,
			mPaused = false;

#if !defined(NO_TILE_CACHE_THREADS)
		std::vector<ThreadInfo> mRequestThreads;
		std::unordered_map<int, size_t> mRequestThreadIdMap;

		static int32_t requestThreadFunc(bx::Thread* thread, void* _userData);
#endif

		// return value implies whether the request was admitted. this may change in the future, but web will
		// ditch any requests beyond the max pending requests
		bool request(EntryKey const& entryId, bool ephemeral = true);
		
		GetResult defaultLoader(EntryKey const& request);

#if !defined(NO_TILE_CACHE_THREADS)
		void setCurrentRequestThreadStatus(RequestThreadStatus status);
		void setRequestThreadStatus(size_t threadId, RequestThreadStatus status);
		void setRequestThreadId(size_t threadId);
		void setRequestThreadTileId(size_t threadId, EntryKey const &key);
		inline void setRequestThreadProfilerStatus(size_t threadId)
		{
			MAP3D_ASSERT(threadId < mRequestThreads.size(), "Invalid thread requested");
			auto &ti = mRequestThreads[threadId];
			ti.profilerStatus = const_cast<lucid::core::Profiler::Sample*>(lucid::core::Profiler::samples());
		}
#else
		void setCurrentRequestThreadStatus(RequestThreadStatus /* status */) { }
		void setRequestThreadStatus(size_t /* threadId */, RequestThreadStatus /* status */) { }
		void setRequestThreadId(size_t /* threadId */) { }
		void setRequestThreadTileId(size_t /* threadId */, EntryKey const& /* key */) { }
#endif

	public: // getters/setters

#if !defined(NO_TILE_CACHE_THREADS)
		size_t requestQueueSize()	const { return mEphemeralRequests.size() + mPersistentRequests.size(); }
		size_t getThreadCount()		const { return mRequestThreads.size(); }
#else
		size_t requestQueueSize()	const { return mPending.size(); }
		size_t getThreadCount()		const { return 0; }
#endif
		size_t pendingCount()		const { return mPending.size(); }
		size_t parsedSize()			const { return mParsedSize; }
		size_t parsedEntryCount()	const { return mParsedQueue.size(); }
		bool isPaused()				const { return mPaused; }

#if !defined(NO_TILE_CACHE_THREADS)
		inline void setPaused(bool paused)		  
		{
			bool previouslyPaused = mPaused;
			mPaused = paused; 
			if (previouslyPaused && !mPaused)
			{
				mReqReadyCondition.notify_one();
			}
		}
#else
		inline void setPaused(bool paused)		  
		{
			mPaused = paused; 
		}
#endif

#if !defined(NO_TILE_CACHE_THREADS)
		ThreadStatus getThreadStatus(size_t threadId) const
		{
			MAP3D_ASSERT(threadId < mRequestThreads.size(), "Invalid thread requested");
			auto const &ti = mRequestThreads[threadId];
			return { ti.status, ti.requestStartTime, ti.statusStartTime, ti.profilerStatus, ti.key };
		}
#else
		RequestThreadStatus getThreadStatus(size_t /* threadId */) const { return RequestThreadStatus::UNKNOWN; }
#endif
	};

} }

namespace std
{

	inline std::string_view toStringView(onyx::Caching::TileRequester::RequestThreadStatus const& value)
	{
		static std::unordered_map<onyx::Caching::TileRequester::RequestThreadStatus, std::string_view> const nameMap =
		{
			{ onyx::Caching::TileRequester::RequestThreadStatus::IDLING,				"idling" },
			{ onyx::Caching::TileRequester::RequestThreadStatus::DEQUEUEING,			"dequeueing request" },
			{ onyx::Caching::TileRequester::RequestThreadStatus::REQUEST_SENT,		"request sent" },
			{ onyx::Caching::TileRequester::RequestThreadStatus::REQUEST_RECEIVED,	"received" },
			{ onyx::Caching::TileRequester::RequestThreadStatus::PARSING,				"parsing" },
			{ onyx::Caching::TileRequester::RequestThreadStatus::COMPLETING,			"completing" },
			{ onyx::Caching::TileRequester::RequestThreadStatus::UNKNOWN,				"unknown" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Caching::TileRequester::RequestThreadStatus");
	}

	inline std::string_view toStringView(onyx::Caching::TileRequester::RequestStatus const& value)
	{
		static std::unordered_map<onyx::Caching::TileRequester::RequestStatus, std::string_view> const nameMap = {
			{ onyx::Caching::TileRequester::RequestStatus::QUEUED,			"queued" },
			{ onyx::Caching::TileRequester::RequestStatus::IN_FLIGHT,			"in flight" },
			{ onyx::Caching::TileRequester::RequestStatus::RECEIVED,			"received" },
			{ onyx::Caching::TileRequester::RequestStatus::PARSED,			"parsed" },
			{ onyx::Caching::TileRequester::RequestStatus::NOT_AVAILABLE,		"not available" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Caching::TileRequester::RequestStatus");
	}

}

#endif