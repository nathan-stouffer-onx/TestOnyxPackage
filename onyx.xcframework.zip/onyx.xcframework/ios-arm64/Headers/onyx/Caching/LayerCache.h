#ifndef __LAYER_CACHE_H__
#define __LAYER_CACHE_H__

#include <memory>
#include <string>

#if MAP3D_THREADS_ENABLED
#include <mutex>
#include <condition_variable>
#include <thread>
#endif

#include <Styling/Layers/Layer.h>

#include "Atlases/StyleAtlases.h"
#include "Camera/CameraState.h"
#include "Tiles/TileId.h"
#include "Tiles/VectorTile.h"
#include "Tiles/HeightTile.h"

#include "IndexedList.h"
#include "LRU.h"
#include "PreparedData.h"
#include "PrepareTask.h"

namespace onyx {
namespace Caching {

	/*
	* A class that stores entries that are layers entirely prepared for rendering. Entries are keyed by TileId
	* and a std::string that uniquely identifies the layer. On platforms that have threads, the preparation
	* work is done on a separate thread. Otherwise, the work is throttled on the main thread.
	* 
	* NOTE: Subtle bugs will appear if we have more than one prepare thread. We could work around these, but 
	* a single thread seems sufficient for now.
	* 
	* NOTE: This class assumes that layer definitions will not change! It is up to the owning class to invalidate
	* entries when a Layer changes. The Style object reports layers that have changed since the last frame. These
	* can be used to purge entries.
	*/
	class LayerCache
	{

	public:

		typedef std::unique_ptr<PrepareTask> task_ptr_t;

#if defined(_DEBUG)
		static constexpr size_t cDefaultCapacity = 100 << 20;		// 100MB cache size limit to exercise the cache clear code while we're debugging
#else
		static constexpr size_t cDefaultCapacity = 400 << 20;		// 400MB cache size limit
#endif

		static constexpr time_float_t cDefaultTaskTimeoutMS = 10 * 1000;	// default timeout of 10 seconds

		struct EntryKey
		{
			Tiles::TileId tileId;
			std::string layerId = "";

			inline bool operator==(EntryKey const& rhs) const
			{
				return tileId == rhs.tileId && layerId == rhs.layerId;
			}

			inline bool operator!=(EntryKey const& rhs) const
			{
				return !(*this == rhs);
			}

			inline bool operator<(EntryKey const& rhs) const
			{
				if (layerId < rhs.layerId) { return true; }
				if (layerId > rhs.layerId) { return false; }
				return (tileId < rhs.tileId) ? true : false;
			}
		};

		class EntryKeyHasher
		{
		public:
			inline size_t operator()(EntryKey const& key) const
			{
				std::hash<std::string> stringHasher;
				std::hash<Tiles::TileId> tileHasher;
				return (23 + stringHasher(key.layerId)) * (23 + tileHasher(key.tileId));
			}
		};

		struct Entry
		{

			std::shared_ptr<PreparedData> prepared = nullptr;

			time_float_t touchTimeMS;

			Entry(time_float_t _touchTimeMS) : touchTimeMS(_touchTimeMS) {}

			size_t size() const
			{
				return (prepared) ? prepared->size() : 0;
			}

			PreparedData::Counts counts() const
			{
				return (prepared) ? prepared->counts() : PreparedData::Counts{ 0, 0, 0 };
			}

		};

	public:

		struct PendingT
		{
			task_ptr_t task;
			time_float_t touchTimeMS;

			PendingT(task_ptr_t _task, time_float_t _touchTimeMS) :
				task(std::move(_task)), touchTimeMS(_touchTimeMS)
			{}
		};

		using PendingTasksT = IndexedList<EntryKey, PendingT, EntryKeyHasher>;

#if MAP3D_THREADS_ENABLED
	public:

		enum class PrepareThreadStatus
		{
			IDLING,
			TRIMMING,
			DEQUEUEING,
			PREPARING,
			UNKNOWN
		};
#endif

	private:

		LRU<EntryKey, Entry, EntryKeyHasher> mLRU;

		size_t const mCapacity = cDefaultCapacity;

		time_float_t const mTaskTimeoutMS = cDefaultTaskTimeoutMS;
		time_float_t mFrameTimeMS = 0.0;

		size_t mSize = 0;

		PreparedData::Counts mCounts = { 0, 0, 0 };

		PendingTasksT mPendingTasks;
		PendingTasksT::const_iterator mInsertionPoint = mPendingTasks.begin();

		Atlases::LineStyleAtlas mLineStyles;
		Atlases::FillStyleAtlas mFillStyles;

#if MAP3D_THREADS_ENABLED
		mutable std::mutex mMutex;

		std::condition_variable mTaskReadyCond;
		
		std::unordered_map<EntryKey, std::shared_ptr<PreparedData>, EntryKeyHasher> mCompleted;

		struct ThreadInfo
		{
			PrepareThreadStatus status = PrepareThreadStatus::IDLING;
			std::thread thread;
			ThreadInfo(std::thread thread) : thread(std::move(thread)) {}
		};

		ThreadInfo mPrepareThreadInfo;

		bool mKeepRunning = true;
		
		struct ActiveTask
		{
			EntryKey key;
			PreparedData::Metadata metadata;
			bool purge = false;

			ActiveTask(EntryKey const& _key, PreparedData::Metadata _metadata) : key(_key), metadata(_metadata) {}
			static inline ActiveTask invalid()
			{
				return
				{ 
					EntryKey{ Tiles::TileId{ -1, -1, -1 }, "" },
					PreparedData::Metadata{ Styling::Layer::Type::UNKNOWN, { -1, -1, -1 }, 0.0, 0.f, Camera::CameraState{}, 0, nullptr }
				};
			}
		};

		ActiveTask mActiveTask = ActiveTask::invalid();

		static int32_t PrepareThreadFunc(LayerCache* cache);
#endif

	public:

		LayerCache();
		~LayerCache();

		void update();

		void clear();

		// returns whether the cache knows anything about this key
		inline bool contains(EntryKey const& key) const { return mLRU.contains(key); }

		// returns whether the cache entry at this key (if it exists) has data that is ready to render
		inline bool isPrepared(EntryKey const& key) const { return contains(key) && mLRU.at(key).prepared; }

		// returns whether there is a pending, active or completed task for this key
		bool isPending(EntryKey const& key) const;

		inline Entry const& at(EntryKey const& key) const { return mLRU.at(key); }

		// returns whether the passed in metadata would replace the most recently submitted metadata for
		// the specified key. if the key is not present, the function will return true
		bool replaces(EntryKey const& key, PreparedData::Metadata const& metadata) const;

		// no-op if the metadata in the cache is in sync with the passed in metadata
		void insert(EntryKey const& key, task_ptr_t task);
		
		void touch(EntryKey const& key);

		void purge(EntryKey const& key, bool immediate = true);
		void purge(Tiles::TileId const& tileId, bool immediate = true);
		void purge(std::string const& layerId, bool immediate = true);

		void trimTo(size_t byteThreshold);
		void trimOff(size_t byteThreshold);
		
		inline void setFrameTimeMS(time_float_t timeMS) { mFrameTimeMS = timeMS; }
		inline time_float_t getFrameTimeMS() const { return mFrameTimeMS; }

		inline Atlases::LineStyleAtlas const& getLineStyles() const { return mLineStyles; }
		inline Atlases::FillStyleAtlas const& getFillStyles() const { return mFillStyles; }

		inline size_t size() const { return mSize; }
		inline size_t capacity() const { return mCapacity; }
		inline size_t entryCount() const { return mLRU.size(); }
		inline size_t taskCount() const { return mPendingTasks.size(); }

		inline PreparedData::Counts const& counts() const { return mCounts; }

		LRU<EntryKey, Entry, EntryKeyHasher>::const_iterator begin() const { return mLRU.begin(); }
		LRU<EntryKey, Entry, EntryKeyHasher>::const_iterator end()   const { return mLRU.end();   }

#if MAP3D_THREADS_ENABLED
		inline PrepareThreadStatus getPrepareThreadStatus() const { return mPrepareThreadInfo.status; }
#endif

	private:

		static size_t sInstanceCount;

		struct Maximums
		{
			// caps on the percentage of the maximum number of gpu resources we can use. bgfx has a hard
			// limit of resources allowed the application. this is a buffer so that LayerCache instances
			// don't use up all the resources and we allow other rendering processes to allocate
			// resources as well
			static float constexpr cVertexBufferLimit = 0.8f;
			static float constexpr cDynamicVertexBufferLimit = 0.8f;
			static float constexpr cDynamicIndexBufferLimit = cDynamicVertexBufferLimit;

			size_t const vertexBuffers;
			size_t const dynamicVertexBuffers;
			size_t const dynamicIndexBuffers;

			Maximums(size_t _vertexBuffers, size_t _dynamicVertexBuffers, size_t _dynamicIndexBuffers) :
				vertexBuffers(_vertexBuffers),
				dynamicVertexBuffers(_dynamicVertexBuffers),
				dynamicIndexBuffers(_dynamicIndexBuffers)
			{}

			Maximums() :
				Maximums{
					static_cast<size_t>(cVertexBufferLimit * bgfx::getCaps()->limits.maxVertexBuffers),
					static_cast<size_t>(cDynamicVertexBufferLimit * bgfx::getCaps()->limits.maxDynamicVertexBuffers),
					static_cast<size_t>(cDynamicIndexBufferLimit * bgfx::getCaps()->limits.maxDynamicIndexBuffers)
				}
			{}


			inline Maximums operator/(size_t instances) const
			{
				return
				{
					vertexBuffers / instances,
					dynamicVertexBuffers / instances,
					dynamicIndexBuffers / instances
				};
			}
		};


		inline Maximums maximums() const
		{
			return (sInstanceCount == 0) ? Maximums() : (Maximums() / sInstanceCount);
		}

	private:

		void replace(EntryKey const& key, std::shared_ptr<PreparedData> const& prepared);

		void trimTo(Maximums const& maximums);
		void trimVertexBuffersTo(size_t limit);
		void trimDynamicVertexBuffersTo(size_t limit);
		void trimDynamicIndexBuffersTo(size_t limit);

		// adds a task to our pending tasks if it replaces the most recently submitted task for the key. return
		// value indicates whether the task was added or not
		bool addTask(EntryKey const& key, task_ptr_t task);
		// purges a task from the pending tasks (and active/completed tasks for threaded builds)
		void purgeTask(EntryKey const& key, bool immediate);

		void trimStaleTasks();

		// TODO (stouff) see if we can redesign this to take in task_ptr_t const&
		std::shared_ptr<PreparedData> prepare(task_ptr_t& task);

	};

} }

namespace std
{

	inline std::string toString(onyx::Caching::LayerCache::EntryKey const& key)
	{
		std::ostringstream os;
		os << "(" << key.tileId.level << ", " << key.tileId.x << ", " << key.tileId.y << " : " << key.layerId << ")";
		return os.str();
	}

#if MAP3D_THREADS_ENABLED

	inline std::string_view toStringView(onyx::Caching::LayerCache::PrepareThreadStatus const& value)
	{
		static std::unordered_map<onyx::Caching::LayerCache::PrepareThreadStatus, std::string_view> const nameMap =
		{
			{ onyx::Caching::LayerCache::PrepareThreadStatus::IDLING,				"idling" },
			{ onyx::Caching::LayerCache::PrepareThreadStatus::TRIMMING,			"trimming" },
			{ onyx::Caching::LayerCache::PrepareThreadStatus::DEQUEUEING,			"dequeueing" },
			{ onyx::Caching::LayerCache::PrepareThreadStatus::PREPARING,			"preparing" },
			{ onyx::Caching::LayerCache::PrepareThreadStatus::UNKNOWN,			"unknown" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Caching::LayerCache::PrepareThreadStatus");
	}

#endif

}

#endif
