#ifndef __PREPARED_DATA_H__
#define __PREPARED_DATA_H__

#include <unordered_set>

#include <lucid/Profiler.h>

#include <Styling/Layers/Layer.h>

#include "Atlases/StyleAtlases.h"
#include "Camera/CameraState.h"
#include "DataObjects/MapLabel.h"
#include "Rendering/VertStructs.h"
#include "Rendering/VectorBuffer.h"

namespace onyx {
namespace Caching {

	/*
	* Base class to hold data that has been prepared for rendering. Derived classes exist for types of layers
	*/

	class PreparedData
	{
	public:

		struct Metadata
		{

			Styling::Layer::Type type;
			Tiles::TileId sourceTileId;
			time_float_t sourceTimestampMS;
			float zoom;
			Camera::CameraState camera;
			uint16_t meshResolution;
			std::shared_ptr<Styling::Expressions::StyleContext const> context;
			// TODO possibly include feature state here?

			// override flag for replacing this entry. if this is true, any insert should replace this entry -- even if it is lower detail
			mutable bool stale = false;

			Metadata(
				Styling::Layer::Type _type,
				Tiles::TileId const& _sourceTileId, time_float_t _sourceTimestampMS,
				float _zoom, Camera::CameraState const& _camera,
				uint16_t _meshResolution,
				std::shared_ptr<Styling::Expressions::StyleContext const> _context = nullptr
			) :
				type(_type),
				sourceTileId(_sourceTileId),
				sourceTimestampMS(_sourceTimestampMS),
				zoom(_zoom),
				camera(_camera),
				meshResolution(_meshResolution),
				context(_context)
			{}
			~Metadata() = default;

			inline bool replaces(Metadata const& rhs) const
			{
				return Metadata::replaces(*this, rhs);
			}

			inline bool operator==(Metadata const& rhs) const
			{
				return type == rhs.type
						&& sourceTileId == rhs.sourceTileId
						&& sourceTimestampMS == rhs.sourceTimestampMS
						&& zoom == rhs.zoom
						&& camera == rhs.camera
						&& meshResolution == rhs.meshResolution
						&& stale == rhs.stale;
			}

		private:

			// returns whether the lhs should replace the rhs in the cache 
			static inline bool replaces(Metadata const& lhs, Metadata const& rhs)
			{
				// Shared contexts are identical across all PreparedData instances so it is irrelevant when
				// checking for replaceability; i.e. one change in the context will be seen by all PreparedData instances that
				// use it so there's no way to use the context itself to check if data has been updated.
				// Also, for now, contexts will never change for stylesheets so should remain const for the lifetime of the
				// prepared data that refers to them.
				return rhs.stale																			// check if rhs is stale (should be replaced by any entry)
					|| lhs.type != rhs.type																	// check if layer types differ
					|| lhs.sourceTileId.level > rhs.sourceTileId.level										// check if lhs has higher detail source data
					|| lhs.sourceTimestampMS > rhs.sourceTimestampMS										// check if the lhs is newer
					|| lhs.zoom != rhs.zoom																	// check if zooms differ
					|| (lhs.type == Styling::Layer::Type::SYMBOL && lhs.camera.pitch != rhs.camera.pitch)	// check if the pitch changed (only for symbol layers)
					|| lhs.meshResolution != rhs.meshResolution;											// check if the mesh resolutions differ
			}

		};

	public:

		struct Counts
		{

			size_t vertexBuffers;
			size_t dynamicVertexBuffers;
			size_t dynamicIndexBuffers;

			Counts(size_t _vertexBuffers, size_t _dynamicVertexBuffers, size_t _dynamicIndexBuffers) :
				vertexBuffers(_vertexBuffers),
				dynamicVertexBuffers(_dynamicVertexBuffers),
				dynamicIndexBuffers(_dynamicIndexBuffers)
			{}

			inline void clear()
			{
				vertexBuffers = 0;
				dynamicVertexBuffers = 0;
				dynamicIndexBuffers = 0;
			}

			inline Counts& operator+=(Counts const& rhs)
			{
				vertexBuffers += rhs.vertexBuffers;
				dynamicVertexBuffers += rhs.dynamicVertexBuffers;
				dynamicIndexBuffers += rhs.dynamicIndexBuffers;
				return *this;
			}

			inline Counts& operator-=(Counts const& rhs)
			{
				vertexBuffers -= rhs.vertexBuffers;
				dynamicVertexBuffers -= rhs.dynamicVertexBuffers;
				dynamicIndexBuffers -= rhs.dynamicIndexBuffers;
				return *this;
			}

		};

	private:

		Metadata const mMetadata;
		Counts const mCounts;
		mutable lucid::core::Profiler::Sample mProfile;

	public:

		PreparedData(Metadata const& metadata, Counts const& counts) : mMetadata(metadata), mCounts(counts), mProfile(nullptr, "root") {}
		virtual ~PreparedData() {}

		// TODO (stouff) eventually set this up to be a const member that is passed from derived class ctors
		virtual size_t size() const = 0;

		Counts const& counts() const { return mCounts; }

		void markStale() { mMetadata.stale = true; }

		Metadata const& metadata() const { return mMetadata; }

		lucid::core::Profiler::Sample const* getProfile() const { return mProfile.firstChild; }

		void snapshotProfile()
		{
			lucid::core::Profiler::snapshot(&mProfile);
			for (auto c = mProfile.firstChild; c != nullptr; c = c->nextSibling)
			{
				mProfile.timeTotal += c->timeTotal;
			}
		}
	};

	class PreparedLineData final : public PreparedData
	{
	public:

		using StylesT = std::unordered_set<Atlases::LineStyleAtlas::StrongRef>;
		using InstanceT = Rendering::VertStructs::LineData;

		PreparedLineData(Metadata const& _metadata, bgfx::VertexBufferHandle const _handle, size_t _count, StylesT&& _styles) :
			PreparedData(_metadata, Counts{ size_t(bgfx::isValid(_handle) ? 1 : 0), 0, 0 }),
			handle(_handle),
			count(_count),
			styles(std::move(_styles))
		{}

		~PreparedLineData()
		{
			if (bgfx::isValid(handle))
			{
				bgfx::destroy(handle);
			}
		}

		// instances to render
		bgfx::VertexBufferHandle const handle;

		// number of instances in this entry
		size_t const count;

		// references to the styles that are used so they are not overwritten in the LineStyleAtlas
		StylesT const styles;

		size_t size() const override
		{
			return sizeof(InstanceT) * count + sizeof(Atlases::LineStyleAtlas::StrongRef) * styles.size();
		}
	};

	class PreparedFillData final : public PreparedData
	{
	public:

		using StylesT = std::unordered_set<Atlases::FillStyleAtlas::StrongRef>;
		using Buffer_t = Rendering::VectorBuffer<Rendering::VertStructs::UV2>;

	public:

		PreparedFillData(Metadata const& _metadata, std::unique_ptr<Buffer_t const> _buffer, StylesT&& _styles) :
			PreparedData(_metadata, Counts{ 0, _buffer->numVertexPages(), _buffer->numVertexPages() }),
			buffer(std::move(_buffer)),
			styles(std::move(_styles))
		{}

		std::unique_ptr<Buffer_t const> buffer;

		// references to the styles that are used so they are not overwritten in the FillStyleAtlas
		StylesT const styles;

		size_t size() const override
		{
			return buffer->size();
		}
	};

	class PreparedSymbolData final : public PreparedData
	{
	public:

		typedef std::shared_ptr<DataObjects::MapLabel> sharedLabel_t;
		typedef std::vector<sharedLabel_t> labels_t;

	public:

		PreparedSymbolData(Metadata metadata) : PreparedData(metadata, Counts{ 0, 0, 0 }) {}

		void addLabel(std::shared_ptr<DataObjects::MapLabel> const& label)
		{
			if (label == nullptr)
			{
				return;
			}
			mSize += label->dataSize();
			mLabels.push_back(label);
		}

		labels_t const labels() const
		{
			return mLabels;
		}

		size_t size() const override
		{
			return mSize;
		}

		size_t labelCount() const
		{
			return mLabels.size();
		}

	private:
		size_t mSize = 0;
		labels_t mLabels;

	};

} }

#endif