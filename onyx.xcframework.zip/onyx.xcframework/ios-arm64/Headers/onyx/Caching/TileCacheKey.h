#ifndef __TILE_CACHE_KEY_H__
#define __TILE_CACHE_KEY_H__

#include <string>
#include <functional>

#include "Tiles/TileId.h"

namespace onyx {
namespace Caching {

	struct TileCacheKey
	{
		std::string source;
		Tiles::TileId tile;

		inline bool operator==(TileCacheKey const& rhs) const
		{
			return source == rhs.source && tile == rhs.tile;
		}

		inline bool operator!=(TileCacheKey const& rhs) const
		{
			return !(*this == rhs);
		}

		inline bool operator<(TileCacheKey const& rhs) const
		{
			if (source < rhs.source) { return true; }
			if (source > rhs.source) { return false; }
			return tile < rhs.tile ? true : false;
		}

	};

} }

namespace std
{

	template<>
	struct hash<onyx::Caching::TileCacheKey>
	{
		size_t operator()(onyx::Caching::TileCacheKey const& key) const
		{
			std::hash<std::string> sHasher;
			std::hash<onyx::Tiles::TileId> tHasher;
			return (53 + sHasher(key.source)) * (53 + tHasher(key.tile));
		}
	};

	inline std::string toString(onyx::Caching::TileCacheKey const& value)
	{
		std::ostringstream os;
		os << "{ " << value.source << " : " << value.tile.level << ", " << value.tile.x << ", " << value.tile.y << " }";
		return os.str();
	}

}

#endif