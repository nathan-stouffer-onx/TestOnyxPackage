#include "TileRequester.h"

#include <mutex>
#include <chrono>
#include <thread>
#include <queue>

#if DEBUG_TILE_CACHE
#include <fstream>
#include <iostream>
#include <sstream>
#endif

#include <bx/thread.h>
#include <bx/timer.h>

#include <System/Map3DException.h>
#include <System/Threading.h>

#include <lucid/Profiler.h>

#include <Styling/Sources/TiledSources/TiledSource.h>
#include <Styling/Sources/GeojsonSource.h>

#include "Caching/Parsing.h"
#include "DataObjects/UserMarkupManager.h"
#include "Tiles/HeightTile.h"
#include "Tiles/VectorTile.h"
#include "Utils/MapMath.h"

#if DEBUG_TILE_CACHE && !defined(NO_TILE_CACHE_THREADS)
#define ASSERT_MAIN_THREAD MAP3D_ASSERT(mThreadId == lucid::core::Profiler::CurrentThreadId(), __FUNCTION__ " can only be called from the thread that created the TileRequester");
#else
#define ASSERT_MAIN_THREAD
#endif

#if !defined(NO_TILE_CACHE_THREADS)
#define LOCK(mtx) std::lock_guard lock##mtx(mtx);
#else
#define LOCK(mtx)
#endif

namespace onyx {
namespace Caching {

	TileRequester*TileRequester::sInstance = nullptr;

	static std::mutex sInstanceMutex;

	TileRequester* TileRequester::Instance()
	{
		if (sInstance == nullptr)
		{
			LOCK(sInstanceMutex);
			if (sInstance == nullptr)
			{
				sInstance = new TileRequester();
			}
		}
		return sInstance;
	}

	void TileRequester::Shutdown()
	{
		LOCK(sInstanceMutex);

		if (sInstance != nullptr)
		{
			delete sInstance;
			sInstance = nullptr;
		}
	}

	TileRequester::TileRequester() :
		mTimeFilter(Utils::TimeFilter<Tiles::TileId>{ 5.0 * 60.0 * 1000.0 }), // track tile requests for the last five minutes
		mKeepRunning(true)
	{
		if (sInstance == nullptr)
		{
			sInstance = this;
		}
#if DEBUG_TILE_CACHE
		mThreadId = lucid::core::Profiler::CurrentThreadId();
#endif

#if !defined(NO_TILE_CACHE_THREADS)
		std::string name("Tile Data Request Thread ");
		for (size_t i = 0; i < MaxCacheThreads; ++i)
		{
			mRequestThreads.push_back(ThreadInfo(new bx::Thread()));
			ThreadInfo& ti = mRequestThreads.back();
			std::string threadName = name + std::to_string(i);
			ti.thread->init(TileRequester::requestThreadFunc, (void*) i, 0, threadName.c_str());
		}

		while (mRequestThreadIdMap.size() < mRequestThreads.size())
		{	// Wait for all of the request threads to add their info to the mRequestThreadIdMap
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
		}
#endif
	}

	TileRequester::~TileRequester()
	{
		logD("Tile Requester exiting");
		mKeepRunning = false;
#if !defined(NO_TILE_CACHE_THREADS)
		bool finished = true;
		int maxWait = 100; // Wait for 10 seconds before giving up on request threads

		// Wake up any sleeping threads
		mReqReadyCondition.notify_all();
		do
		{
			finished = true;
			for (auto& ti : mRequestThreads)
			{
				if (ti.thread->isRunning())
				{
					finished = false;
					break;
				}
			}
			if (finished)
				break;

			auto now = Utils::Timer::nowMS();

			for (size_t i = 0; i < mRequestThreads.size(); ++i)
			{
				auto status = getThreadStatus(i);
				if (status.status == TileRequester::RequestThreadStatus::IDLING)
				{
					logD("%d: %s", i, std::toStringView(status.status).data());
				}
				else
				{
					logD("%d: %s (%s : %d, %d, %d), %0.2fs (%0.2fs)", i, std::toStringView(status.status).data(),
						status.key.source.c_str(), status.key.tile.level, status.key.tile.x, status.key.tile.y,
						(now - status.requestStartTime) / 1000, (now - status.statusStartTime) / 1000);
				}
			}

			logD("Waiting for threads to terminate...", mRequestThreads.size());

			std::this_thread::sleep_for(std::chrono::milliseconds(100));

			for (auto& ti : mRequestThreads)
			{
				if (ti.thread->isRunning())
				{
					ti.thread->shutdown();
				}
			}
		} while (--maxWait > 0);

		if (finished)
		{
			logD("All request threads exited");
		}
		else
		{
			logE("One or more request threads failed to exit cleanly");
		}

		mRequestThreads.clear();
#endif
		logD("TileRequester shutdown complete");
	}

#if !defined(NO_TILE_CACHE_THREADS)
	bool TileRequester::request(EntryKey const& entryId, bool ephemeral)
#else
	bool TileRequester::request(EntryKey const& entryId, bool)
#endif
	{
		ASSERT_MAIN_THREAD;
		LUCID_PROFILE_SCOPE("Add to request queue");
#if !defined(NO_TILE_CACHE_THREADS)

		// check that we don't already have the entry loaded
		auto status = TileCache::Instance()->fastStatus(entryId);
		if (status == TileCache::Entry::Status::LOADED)
		{
			// Already loaded, nothing to do
			return true;
		}

		// check that the entry is not in the parsed queue
		LOCK(mParsedMutex);
		auto parsedContains = mParsedQueue.find(entryId) != mParsedQueue.end();
			
		if (!parsedContains)
		{
			LOCK(mRequestMutex);

			GetRequest req = { EntryKey{ entryId.source, entryId.tile }, mFrameTimestamp };

			auto ephemeralIter = mEphemeralRequests.find(req);
			auto persistentIter = mPersistentRequests.find(req);

			bool inEphemeral = ephemeralIter != mEphemeralRequests.end();
			bool inPersistent = persistentIter != mPersistentRequests.end();
			bool requestAdded = false;

			MAP3D_DEBUG_ASSERT(!(inEphemeral && inPersistent), "request cannot be in both ephemeral and persistent request queues");

			if (ephemeral)
			{
				// add to the ephemeral queue if it is not already there and not in the persistent queue
				bool inNeither = !(inEphemeral || inPersistent);
				if (inNeither)
				{
					TileCache::log(TileCache::CacheAction::Request, entryId);
					mEphemeralRequestQueue.push_back(req);
					mEphemeralRequests[req] = --mEphemeralRequestQueue.end();
					requestAdded = true;
				}
			}
			else
			{
				if (!inPersistent)	// check that it's not already in the persistent request queue
				{
					bool ephemeralInFlight = (inEphemeral) ? ephemeralIter->second == mEphemeralRequestQueue.end() : false;
					if (!ephemeralInFlight) // if in flight, ignore this
					{
						if (inEphemeral)	// if in the ephemeral queue, remove it
						{
							mEphemeralRequests.erase(req);
							mEphemeralRequestQueue.erase(ephemeralIter->second);
						}

						// add the to persistent request queue
						TileCache::log(TileCache::CacheAction::Request, entryId);
						mPersistentRequestQueue.push_back(req);
						mPersistentRequests[req] = --mPersistentRequestQueue.end();
						requestAdded = true;
					}
				}
			}
			if (requestAdded && !mPaused && mPending.size() < mMaxPendingRequests)
			{
				// Tell sleeping thread that a request has been added
				mReqReadyCondition.notify_one();
			}
		}

		return true;
#else

		// early out if the result is parsed or pending
		bool parsedContains = mParsedQueue.find(entryId) != mParsedQueue.end();
		bool pendingContains = mPending.find(entryId) != mPending.end();
		if (parsedContains || pendingContains)
		{
			return true;
		} 

		// check that we are below the appropriate size and to make sure request is not a duplicate
		if (mPending.size() < mMaxPendingRequests)
		{
			beginRequest(entryId);
			return true;
		}
		else
		{
			TileCache::Instance()->purge(entryId);
			return false;
		}
#endif
	}

	TileRequester::GetResult TileRequester::defaultLoader(EntryKey const& request)
	{
		logI("TileRequester::defaultLoader hit for { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
		return { nullptr, RequestStatus::NOT_AVAILABLE };
	}

	void TileRequester::clearPendingRequest(EntryKey const& request)
	{
		{
			LOCK(mRequestMutex);

#if DEBUG_TILE_CACHE		// only create this verbose message when debugging tile cache (slight performance benefit)
			std::stringstream msg;
			msg << "Received completed result for tile (";
			msg << request.id.level << ", " << request.id.x << ", " << request.id.y;
			msg << ") with data id " << request.dataType << " that was not pending";
			MAP3D_ASSERT(mPending.find(request) != mPending.end(), msg.str());
#else
			MAP3D_ASSERT(mPending.find(request) != mPending.end(), "Received completed result for request that was not pending");
#endif
			mPending.erase(request);
#if !defined(NO_TILE_CACHE_THREADS)
			if (!mPaused && mPending.size() < mMaxPendingRequests &&
				(!mPersistentRequestQueue.empty() || !mEphemeralRequestQueue.empty()))
			{
				mReqReadyCondition.notify_one();
			}
#endif
		}
	}

	TileRequester::RequestStatus TileRequester::parseStream(EntryKey const& request, SharedStreamT& stream, SharedParsedDataT& parsedResult)
	{
		// TODO (stouff) get rid of this reference to TileCache
		auto const& source = TileCache::Instance()->getSource(request.source);
		auto const& type = source.type();

		ParseCallbackT callback = Instance()->mParseCallback;

		if (source.specification()->internal)
		{
			MAP3D_ASSERT(callback != nullptr, "Internal data source specified but no callback configured");
			{
				parsedResult = callback(request, stream);
				if (parsedResult == nullptr)
				{
					return RequestStatus::NOT_AVAILABLE;
				}
			}
		}
		else
		{
			switch (type)
			{
				case Styling::Source::Type::RASTER:
					parsedResult = ParseTexture(request, stream);
					if (parsedResult == nullptr)
					{
						return RequestStatus::NOT_AVAILABLE;
					}
					break;
				case Styling::Source::Type::RASTER_DEM:
					parsedResult = ParseHeight(request, stream);
					if (parsedResult == nullptr)
					{
						return RequestStatus::NOT_AVAILABLE;
					}
					break;
				case Styling::Source::Type::VECTOR:
					parsedResult = ParseVector(request, stream);
					if (parsedResult == nullptr)
					{
						return RequestStatus::NOT_AVAILABLE;
					}
					break;
				case Styling::Source::Type::GEOJSON:
					{
						auto features = DataObjects::UserMarkupManager::find(request.source, request.tile);
						if (features.empty())
						{
							return RequestStatus::NOT_AVAILABLE;
						}

						auto layer = std::make_shared<Vector::Layer>("data", features, Utils::Timer::nowMS());
						auto parsed = std::make_shared<Tiles::VectorTile>(request.tile, layer);
						parsedResult = std::shared_ptr<ParsedCacheData>(new VectorUserData(parsed));
						
						return RequestStatus::PARSED;
					}
				break;
				default:
					logD("Unknown format for request { %s : %d, %d, %d }", request.source.c_str(), request.tile.level, request.tile.x, request.tile.y);
					if (callback != nullptr)
					{
						parsedResult = callback(request, stream);
					}
					break;
			}
		}
		return RequestStatus::PARSED;
	}

	void TileRequester::completeRequest(EntryKey const& request, SharedStreamT& stream)
	{
		LUCID_PROFILE_SCOPE("Complete Request");

		auto &tileId = request.tile;
		clearPendingRequest(request);
		
		TileCache::log(TileCache::CacheAction::Parse, request, stream != nullptr ? stream->size() : 0);

		SharedParsedDataT data;

		setCurrentRequestThreadStatus(RequestThreadStatus::PARSING);

		RequestStatus status = RequestStatus::PARSE_FAILURE;
		
		MAP3D_TRY
			status = parseStream(request, stream, data);

			if (stream == nullptr && data == nullptr)
			{
				status = RequestStatus::NOT_AVAILABLE;
			}

		MAP3D_CUSTOM_CATCH(RequestException)
			//TODO (scott) some custom error handling specified in the exception?  Retries?
			logE(ex.summarize());
		MAP3D_CATCH
			logE(ex.summarize());
		MAP3D_CATCH_ALL
			logE("Unrecognized failure parsing tile data");
		MAP3D_END_CATCH

		{
			LUCID_PROFILE_SCOPE("Store result");

			setCurrentRequestThreadStatus(RequestThreadStatus::COMPLETING);

			ParseResult result = { request, stream, data, status };

			LOCK(mParsedMutex);

			TileCache::log(TileCache::CacheAction::MoveToParsed, { request.source, tileId }, result.size());
			MAP3D_ASSERT(result.size() < (1 << 26), "cache item is > 32MB");

			mParsedQueue.push_back(request, result);
			mParsedSize += result.size();

#if !defined(NO_TILE_CACHE_THREADS)
			{
				LOCK(mRequestMutex);
				mEphemeralRequests.erase({ request, 0 });
				mPersistentRequests.erase({ request, 0 });
				mUpdateTimestamp = bx::getHPCounter();
#if DEBUG_TILE_CACHE
				logD("cache updated %ul", mUpdateTimestamp);
#endif
			}
#endif
			if (result.data != nullptr)
			{
				result.data->snapshotProfile();
			}
		}
	}

	void TileRequester::failRequest(EntryKey const& request, RequestStatus status)
	{
		auto tileId = request.tile;
		clearPendingRequest(request);

		LOCK(mParsedMutex);

		TileCache::log(TileCache::CacheAction::MoveToParsed, { request.source, tileId }, 0);
		mParsedQueue.push_back(request, { request, nullptr, nullptr, status });

#if !defined(NO_TILE_CACHE_THREADS)
		{
			LOCK(mRequestMutex);
			mEphemeralRequests.erase({ request, 0 });
			mPersistentRequests.erase({ request, 0 });
		}
#endif
	}
	
	void TileRequester::beginRequest(EntryKey const& request)
	{
#if defined(NO_TILE_CACHE_THREADS)
		mPending.insert(request);
#endif

		// TODO may need to lock TileCache::mDataSources because of this call. alternatively, we could refactor the request to 
		// include the actual source and avoid accessing TileCache altogether
		// TODO (stouff) remove this reference to TileCache
		auto const& source = TileCache::Instance()->getSource(request.source);

		GetResult result;

		{
			LUCID_PROFILE_SCOPE("Load Stream");

			if (source.specification()->internal)
			{
				result.status = RequestStatus::RECEIVED;
			}
			else
			{
				if (mGetCallback != nullptr)
				{
					// Geojson sources are not TiledSources 
					if (source.type() == Styling::Source::Type::GEOJSON)
					{
						result.status = RequestStatus::RECEIVED;
					}
					else 
					{
						auto tiledSource = std::static_pointer_cast<Styling::TiledSource const>(source.specification());
						result = mGetCallback(tiledSource->pattern(), request);
					}
				}
				else
				{
					result = defaultLoader(request);
				}

				if (result.status == RequestStatus::NOT_AVAILABLE)
				{
					failRequest(request, result.status);
					return;
				}

				if (mAsyncFetches && result.stream == nullptr)
				{
					return;
				}
			}
		}

		setCurrentRequestThreadStatus(RequestThreadStatus::REQUEST_RECEIVED);

		completeRequest(request, result.stream);
	}

	char const* sRootNode = "Request Thread";

#if !defined(NO_TILE_CACHE_THREADS)

	int32_t TileRequester::requestThreadFunc(bx::Thread* /*thread*/, void* _userData)
	{
		logD("Starting up TileRequester::requestThreadFunc");
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
		auto id = size_t(_userData);
		auto self = sInstance;

		core::Threading::setPriority(onyx::core::Threading::Priority::LOW);

		self->setRequestThreadId(id);
		while (self->mRequestThreadIdMap.size() < self->mRequestThreads.size())
		{	// Wait for all of the request threads to add their info to the mRequestThreadIdMap
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
		}

		MAP3D_FINALLY([&] { logD("Exiting TileRequester::requestThreadFunc %d", id); });

		MAP3D_ASSERT(self != nullptr, "Incomplete thread data passed to TileRequesterThreadEntry::threadFunc");

		while (self->mKeepRunning)
		{

			lucid::core::Profiler::reset();
			self->setRequestThreadStatus(id, RequestThreadStatus::IDLING);
			MAP3D_TRY

				GetRequest req;
				{
					std::unique_lock lock(self->mRequestMutex);
					self->mReqReadyCondition.wait(lock, [=] {
						return (!self->mPaused &&
							(!self->mPersistentRequestQueue.empty() || !self->mEphemeralRequestQueue.empty()) &&
							self->mPending.size() < self->mMaxPendingRequests) ||
							!self->mKeepRunning;	// Break out of waiting if shutting down
						}
					);

					// State may have changed during wait so check again
					bool persistentEmpty = self->mPersistentRequestQueue.empty();
					bool ephemeralEmpty = self->mEphemeralRequestQueue.empty();
					if (persistentEmpty && ephemeralEmpty)
						continue;

					self->setRequestThreadStatus(id, RequestThreadStatus::DEQUEUEING);

					// TODO possibly set up threads so that some prioritize each type of request
					if (!persistentEmpty)
					{
						req = self->mPersistentRequestQueue.front();
						self->mPersistentRequestQueue.pop_front();
						self->mPersistentRequests[req] = self->mPersistentRequestQueue.end();	// mark request as being processed by thread
						self->mPending.insert(req.key);
					}
					else if (!ephemeralEmpty)
					{
						req = self->mEphemeralRequestQueue.front();
						self->mEphemeralRequestQueue.pop_front();
						self->mEphemeralRequests[req] = self->mEphemeralRequestQueue.end();	// mark request as being processed by thread
						self->mPending.insert(req.key);
					}

#if DEBUG_TILE_CACHE
					logD("TileRequester::requestThreadFunc() loading tile (%d, %d, %d) with data id %d", req.key.id.level, req.key.id.x, req.key.id.y, req.key.dataType);
#endif
				}
				LUCID_PROFILE_SCOPE(sRootNode);

				self->setRequestThreadTileId(id, req.key);
				self->setRequestThreadStatus(id, RequestThreadStatus::REQUEST_SENT);

				self->beginRequest(req.key);

			MAP3D_CATCH
				logE(ex.summarize());

			MAP3D_CUSTOM_CATCH(std::exception)
				auto what = ex.what();
				logE("Error in TileRequesterThread: %s", what);

			MAP3D_CATCH_ALL
				logE("Caught exception in TileRequesterThread");
				// Just make sure that we don't ever bypass thread deinitialization

			MAP3D_END_CATCH
		}
		logD("Request thread %d shut down cleanly", id);

		return 0xDEAD;
	}

#endif

	void TileRequester::clearStaleRequests(bool onlyEphemeral)
	{
		// we only need to clear stale requests in threaded versions because the non-threaded version
		// just drops requests beyond the max
#if !defined(NO_TILE_CACHE_THREADS)
		ASSERT_MAIN_THREAD;

		auto tc = TileCache::Instance();
		// early outs if the request queues are empty
		if (onlyEphemeral)
		{
			if (mEphemeralRequestQueue.empty())
			{
				return;
			}
		}
		else
		{
			if (mEphemeralRequestQueue.empty() && mPersistentRequestQueue.empty())
			{
				return;
			}
		}

		{
			size_t clearedCount = 0;

			LOCK(mRequestMutex);

			// clear out stale ephemeral requests
			{
				while (!mEphemeralRequestQueue.empty())
				{
					// grab the entry
					auto& request = mEphemeralRequestQueue.front();
					if (request.timestamp >= mFrameTimestamp)
						break;

					// purge the request and cache entry
					tc->purge(request.key, true);
					mEphemeralRequests.erase(request);
					mEphemeralRequestQueue.pop_front();
					++clearedCount;
				}
			}

			if (!onlyEphemeral)	// clear out stale persistent requests
			{
				while (!mPersistentRequestQueue.empty())
				{
					// grab the entry
					auto& request = mPersistentRequestQueue.front();
					if (request.timestamp >= mFrameTimestamp)
						break;

					// purge the request and cache entry
					tc->purge(request.key, true);
					mPersistentRequests.erase(request);
					mPersistentRequestQueue.pop_front();
					++clearedCount;
				}
			}

#if DEBUG_TILE_CACHE
			if (clearedCount > 0)
				logD("TileRequester::clearStaleRequests() cleared %Iu requests", clearedCount);
#endif
		}
#endif
	}

#if !defined(NO_TILE_CACHE_THREADS)

	void TileRequester::setRequestThreadTileId(size_t threadId, EntryKey const& key)
	{
		mRequestThreads[threadId].key = key;
	}

	void TileRequester::setCurrentRequestThreadStatus(RequestThreadStatus status)
	{
		auto threadId = lucid::core::Profiler::CurrentThreadId();
		setRequestThreadStatus(mRequestThreadIdMap[threadId], status);
	}

	void TileRequester::setRequestThreadStatus(size_t threadId, RequestThreadStatus status)
	{
		auto &ti = mRequestThreads[threadId];
		
		auto now = Utils::Timer::nowMS();
		if (ti.status != status)
		{
			ti.statusStartTime = now;
		}
		if (ti.status == RequestThreadStatus::IDLING && status != RequestThreadStatus::IDLING)
		{
			ti.requestStartTime = now;
		}
		ti.status = status;
	}

	void TileRequester::setRequestThreadId(size_t threadId)
	{
		static std::mutex mtx;
		std::lock_guard lock(mtx);
		int id = lucid::core::Profiler::CurrentThreadId();
		mRequestThreads[threadId].threadId = id;
		mRequestThreadIdMap[id] = threadId;
		
		LUCID_PROFILE_SCOPE(sRootNode); // Prime the profiler
		setRequestThreadProfilerStatus(threadId);
	}

#endif

} }