#include "TileCache.h"

#include <mutex>
#include <chrono>
#include <thread>
#include <queue>

#if DEBUG_TILE_CACHE
#include <fstream>
#include <iostream>
#include <sstream>
#endif

#include <bx/thread.h>
#include <bx/timer.h>
#include <webp/decode.h>

#include <lucid/Profiler.h>
#include <System/Map3DException.h>

#include <Styling/Sources/TiledSources/TiledSource.h>
#include <Styling/Sources/SourceOperators.h>

#include "Atlases/HeightAtlas.h"
#include "Atlases/TileAtlas.h"
#include "Height/HeightManager.h"

#include "DataObjects/UserMarkupManager.h"
#include "Tiles/HeightTile.h"
#include "Tiles/VectorTile.h"
#include "TileRequester.h"
#include "Utils/MapMath.h"

#if DEBUG_TILE_CACHE && !defined(NO_TILE_CACHE_THREADS)
#define DEBUG_LOCK(mtx) std::lock_guard lock##__LINE__(mtx);
#define ASSERT_MAIN_THREAD MAP3D_ASSERT(mThreadId == lucid::core::Profiler::CurrentThreadId(), __FUNCTION__ " can only be called from the thread that created the TileCache");
#define CHECK_CONSISTENCY checkConsistency()
#define CHECK_ENTRY_SIZE_CHANGED(entry) validateEntry(entry)
#else
#define DEBUG_LOCK(mtx)
#define ASSERT_MAIN_THREAD
#define CHECK_CONSISTENCY
#define CHECK_ENTRY_SIZE_CHANGED(entry)
#endif

#if !defined(NO_TILE_CACHE_THREADS)
#define LOCK(mtx) std::lock_guard lock##__LINE__(mtx);
#else
#define LOCK(mtx)
#endif

namespace onyx {
namespace Caching {

#if DEBUG_TILE_CACHE

	std::vector<TileCache::CacheEvent> TileCache::sCacheLog;
	std::unordered_map<TileCache::EntryKey, size_t, TileCache::EntryKeyHasher> TileCache::sCachedEntrySizes;

	std::mutex TileCache::sLogMutex;
#endif

	static constexpr uint32_t cLoadCap = 10;

	TileCache *TileCache::sInstance = nullptr;

	static std::mutex sInstanceMutex;

	TileCache* TileCache::Instance()
	{
		if (sInstance == nullptr)
		{
			LOCK(sInstanceMutex);
			if (sInstance == nullptr)
			{
				sInstance = new TileCache();
			}
		}
		return sInstance;
	}

	void TileCache::Shutdown()
	{
		Caching::TileRequester::Shutdown();

		LOCK(sInstanceMutex);

		if (sInstance != nullptr)
		{
			delete sInstance;
			sInstance = nullptr;
		}
	}

	TileCache::TileCache() : 
		mTimeFilter(Utils::TimeFilter<Tiles::TileId>{ 5.0 * 60.0 * 1000.0 }) // track tile requests for the last five minutes
	{
#if DEBUG_TILE_CACHE
		mThreadId = lucid::core::Profiler::CurrentThreadId();
#endif
	}

	size_t TileCache::totalSize() const
	{
		return mCurrentSize + TileRequester::Instance()->parsedSize();
	}

#if DEBUG_TILE_CACHE
	void TileCache::dumpLog(std::string const& fileName, bool includeConsistency)
	{
		std::ofstream fs(fileName);
		if (!fs)
		{
			logE("Could not create cache log");
			fs.close();
			return;
		}

		if (includeConsistency)
		{
			{
				DEBUG_LOCK(sInstance->mLruMutex);
				for (auto& [key, entry] : sInstance->mLru)
				{
					log(CacheAction::LruReport, key, entry->size());
				}
			}
			{
				LOCK(TileRequester::sInstance->mParsedMutex);
				for (auto& parsed : TileRequester::sInstance->mParsedQueue)
				{
					size_t parsedSize = 0;
					if (parsed.stream != nullptr)
					{
						parsedSize += parsed.stream->size();
					}
					if (parsed.data != nullptr)
					{
						parsedSize += parsed.data->size();
					}
					log(CacheAction::ParsedReport, parsed.key, parsedSize);
				}
			}
		}

		std::lock_guard lock(sLogMutex);

		fs << "Action Id,level,x,y,type,data,Cache Size,timestamp" << std::endl;
		for (auto& log : sCacheLog)
		{
			fs << std::uint32_t(log.action)
				<< "," << log.key.id.level
				<< "," << log.key.id.x
				<< "," << log.key.id.y
				<< "," << log.key.dataType
				<< "," << log.data
				<< "," << log.currentSize
				<< "," << log.timestamp
				<< std::endl;
		}

		fs.close();
	}
#endif

	TileCache::~TileCache()
	{
		dumpLog("CacheReportLog.csv", false);
	}

	void TileCache::update()
	{
		mFrameTimestamp = bx::getHPCounter();

		auto requester = TileRequester::Instance();
		requester->mFrameTimestamp = mFrameTimestamp;

		requester->clearStaleRequests();

		// TODO possibly organize this so there is less time where the parse queue is locked
		{
			LUCID_PROFILE_SCOPE("load parsed data");
			LOCK(requester->mParsedMutex);
			uint32_t loaded = 0;
			while (loaded < cLoadCap &&  requester->parsedEntryCount())
			{
				auto parsed = requester->getNextParsed();

				auto iter = mLru.find(parsed.key);
				bool contains = iter != mLru.end();
				if (contains)	// make sure the request hasn't been purged
				{
					CHECK_CONSISTENCY;
					Entry* entry = (*iter).entry;

					if (entry->status == Entry::Status::EXPIRED)	// purge the old expired data
					{
						purge(parsed.key);
					}

					Source& source = mSources[parsed.key.source];

					if (parsed.status == TileRequester::RequestStatus::PARSED)	// if the status is successfully parsed, load into the containers
					{
						// if there isn't room, make some space
						if (mCurrentSize + parsed.size() > mMemCacheLimit)
						{
							trimOff(parsed.size());
						}

						// insert the entry into the appropriate data containers
						if (source.isRaster())
						{
							auto rasterData = static_cast<ImageUserData*>(parsed.data.get());
							Atlases::TileAtlas* atlas = source.atlas();

							if (source.specification()->type == Styling::Source::Type::RASTER_DEM)
							{
								auto heightData = static_cast<HeightUserData*>(rasterData);
								Atlases::HeightAtlas* heightAtlas = static_cast<Atlases::HeightAtlas*>(atlas);
								heightAtlas->insert(parsed.key.tile, heightData->getHeightTile(), heightData->getHandle(), heightData->getFormat(), true);
								// temporary double insert to atlas and HeightManager while we make the transfer
								HeightManager::Instance()->insert(parsed.key.tile, heightData->getHeightTile());
							}
							else
							{
								atlas->insert(parsed.key.tile, rasterData->getHandle(), rasterData->getFormat(), true);
							}

							// transfer ownership of the gpu memory to the atlas
							rasterData->releaseOwnership();
						}
						else if (source.isVector())
						{
							auto vecData = static_cast<VectorUserData*>(parsed.data.get());
							Pyramid::TilePyramid<Tiles::VectorTile>* pyramid = source.pyramid();
							pyramid->insert(vecData->mData);
						}
						else if (source.type() != Styling::Source::Type::UNKNOWN)
						{
							MAP3D_THROW("Unrecognized Stylinge::Source::Type found");
						}

						// update the entry
						entry->status = Entry::Status::LOADED;
						entry->stream = parsed.stream;
						entry->parsed = parsed.data;
						entry->expiresMS = source.specification()->expirationMS + Utils::Timer::nowMS();
						loaded++;						
					}
					else	// if the status isn't parsed, just propagate the info into the lru
					{
						// update the entry
						entry->status = Entry::Status::NOT_AVAILABLE;
						entry->stream = parsed.stream;
						entry->parsed = parsed.data;
						entry->expiresMS = source.specification()->expirationMS + Utils::Timer::nowMS();
					}

					setCacheSize(mCurrentSize + parsed.size());
					mUpdateTimestamp = bx::getHPCounter();

					log(CacheAction::MoveToLru, parsed.key, parsed.size());

					CHECK_CONSISTENCY;
				}
			}
		}
		
		{
			LUCID_PROFILE_SCOPE("source update");
			for (auto& [name, source] : mSources)
			{
				source.update();
			}
		}

		mTimeFilter.update();
	}

	void TileCache::setCacheSize(size_t size)
	{
#if DEBUG_TILE_CACHE
		auto oldSize = mCurrentSize;
#endif
		MAP3D_ASSERT(size < (MemCacheLimitDefault << 1), "Invalid cache size set");
		mCurrentSize = size;
		CHECK_CONSISTENCY;
	}

	void TileCache::getEntryKeys(std::vector<Key>& keys) const
	{
		ASSERT_MAIN_THREAD;
		LUCID_PROFILE_SCOPE("query entry keys");
		keys.reserve(mLru.size());
		for (auto const& [key, entry] : mLru)
		{
			keys.push_back(key);
		}
	}

	void TileCache::getEntries(EntryMapT& entries, std::vector<Key> const& keys) const
	{
		ASSERT_MAIN_THREAD;
		for (auto const& key : keys)
		{
			if (mLru.contains(key))
			{
				entries.emplace(key, mLru.at(key));
			}
		}
	}

	void TileCache::touch(Key const& key)
	{
		ASSERT_MAIN_THREAD;
		LUCID_PROFILE_SCOPE("cache touch");
		DEBUG_LOCK(mLruMutex);

		// get the appropriate data source
		std::shared_ptr<Styling::Source const> const& specification = mSources.at(key.source).specification();

		if (specification->minZoom <= key.tile.level)	// make sure the level is above the min
		{
			// compute the appropriate tile id
			int maxZoom = specification->maxZoom;
			Tiles::TileId const& tile = (key.tile.level > maxZoom) ? key.tile.parentAtLevel(maxZoom) : key.tile;
			mTimeFilter.insert(tile);
			mLru.touch({ key.source, tile });
		}
	}

	void TileCache::touch(std::vector<Key> const& keys)
	{
		ASSERT_MAIN_THREAD;
		for (Key const& key : keys)
		{
			touch(key);
		}
	}

	inline void TileCache::markIfExpired(Entry* entry, Utils::Timer::Map3D_time_t nowMS)
	{
		if (nowMS > entry->expiresMS)
		{
			entry->status = Entry::Status::EXPIRED;
		}
	}

	TileCache::Entry* TileCache::at(Key const& key, bool ephemeral)
	{
		ASSERT_MAIN_THREAD;
		LUCID_PROFILE_SCOPE("TileCache::at");

		auto sourceIt = mSources.find(key.source);
		MAP3D_ASSERT(sourceIt != mSources.end(), "Unknown source specified");
		Source const& source = sourceIt->second;

		if (!source.specification()->range().contains(key.tile.level))
		{
			return nullptr;
		}

		auto tileBounds = MapMath::toGlobeBounds(key.tile.worldBounds<world_float_t>());
		if (source.specification()->bounds.intersects(tileBounds) == lmath::Intersections::NONE)
		{
			return nullptr;
		}

		DEBUG_LOCK(mLruMutex);
		mTimeFilter.insert(key.tile);
		TileCache::Entry* entry = nullptr;
		// First look in the non-threaded cache
		{
			auto iter = mLru.find(key);
			if (iter == mLru.end())	// couldn't find it, so create an entry
			{
				log(CacheAction::Fetch, key);
				entry = new Entry();	// freeing will be managed by LRU
				mLru.insert(key, entry);
			}
			else
			{
				entry = (*iter).entry;
				if (entry->status == Entry::Status::NOT_AVAILABLE)
				{
					// TODO maybe move entry to the front of the lru? it will keep this information in memory for a longer 
					// amount of time. depends on whether we trust NOT_AVAILABLE to mean never available and not just a 
					// failed request that might succeed on another try

					// If this entry has already been marked as unavailable,
					// just bail right now before doing any more work.
					return entry;
				}
				mLru.touch(key);
			}
		}

		markIfExpired(entry);

		if (entry->status == Entry::Status::LOADED)
		{
			return entry;
		}

		// request the entry. if the request was ditched, return nullptr
		return (TileRequester::Instance()->request(key, ephemeral)) ? entry : nullptr;
	}

	TileCache::Entry::Status TileCache::entryStatus(Key const& key)
	{
		ASSERT_MAIN_THREAD;
		LUCID_PROFILE_SCOPE("Check cache entry status");
		DEBUG_LOCK(mLruMutex);

		auto entryIter = mLru.find(key);
		if (entryIter == mLru.end())
		{
			MAP3D_ASSERT(mSources.find(key.source) != mSources.end(), "Unknown source specified");
			Source const& source = mSources.at(key.source);

			if (!source.specification()->range().contains(key.tile.level))
			{
				return Entry::Status::NOT_AVAILABLE;
			}

			auto tileBounds = MapMath::toGlobeBounds(key.tile.worldBounds<world_float_t>());
			if (source.specification()->bounds.intersects(tileBounds) == lmath::Intersections::NONE)
			{
				return Entry::Status::NOT_AVAILABLE;
			}
			return Entry::Status::UNKNOWN;
		}
		else
		{
			TileCache::Entry* entry = (*entryIter).entry;
			markIfExpired(entry);
			return entry->status;
		}
	}

	std::vector<Tiles::TileId> TileCache::recentTiles(double windowMS) const
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);
		return mTimeFilter.recent(windowMS);
	}

	void TileCache::invalidate(Key const& key)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		auto iter = mLru.find(key);
		if (iter != mLru.end())
		{
			Entry* entry = (*iter).entry;
			entry->status = Entry::Status::EXPIRED;
		}
	}

	void TileCache::invalidate(Tiles::TileId const& tileId)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		for (auto& [key, entry] : mLru)
		{
			if (key.tile == tileId)
			{
				entry->status = Entry::Status::EXPIRED;
			}
		}
	}

	void TileCache::invalidate(std::string const& source, lgal::world::AABB2d area)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		for (auto& [key, entry] : mLru)
		{
			if (key.source != source || entry->status == Entry::Status::EXPIRED)
			{
				continue;
			}
			auto bounds = key.tile.worldBounds<world_float_t>();
			if (lmath::intersects(area, bounds) != lmath::Intersections::NONE)
			{
				entry->status = Entry::Status::EXPIRED;
			}
		}
	}

	void TileCache::purge(std::string const& source, bool placeholderOnly)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		std::vector<Key> toPurge;
		for (auto const& [key, entry] : mLru)
		{
			if (key.source == source)
			{
				toPurge.push_back(key);
			}
		}

		for (Key const& key : toPurge)
		{
			purge(key, placeholderOnly);
		}
	}

	void TileCache::purge(Tiles::TileId const& tile, bool placeholderOnly)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		std::vector<Key> toPurge;
		for (auto const& [key, entry] : mLru)
		{
			if (key.tile == tile)
			{
				toPurge.push_back(key);
			}
		}

		for (Key const& key : toPurge)
		{
			purge(key, placeholderOnly);
		}
	}

	void TileCache::purge(Key const& key, bool placeholderOnly)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		auto iter = mLru.find(key);
		if (iter != mLru.end())
		{
			Entry* entry = (*iter).entry;
			auto entrySize = entry->size();

			CHECK_ENTRY_SIZE_CHANGED(entry);
			MAP3D_ASSERT(entrySize <= mCurrentSize, "entrySize is larger than remaining cache size");

			log(CacheAction::Purge, key, entrySize);

			if (entry->status == Entry::Status::LOADED || entry->status == Entry::Status::EXPIRED)
			{
				if (placeholderOnly)
				{
					return;
				}

				// clean up memory in atlases and managers
				Source& source = mSources.at(key.source);
				if (source.isRaster())
				{
					source.atlas()->erase(key.tile);

					// if it was also height, clean up height memory
					if (source.type() == Styling::Source::Type::RASTER_DEM)
					{
						HeightManager::Instance()->erase(key.tile);
					}
				}
				else if (source.isVector())
				{
					source.pyramid()->erase(key.tile);
				}
				else if (source.type() != Styling::Source::Type::UNKNOWN)
				{
					MAP3D_THROW("Unrecognized Syling::Source::Type found");
				}
			}

			if (entry->status != Entry::Status::EXPIRED)
			{
#if DEBUG_TILE_CACHE
				sCachedEntrySizes.erase(key);
#endif
				mLru.erase(key);
			}
			else
			{
				entry->stream.reset();
				entry->parsed.reset();
				entry->status = Entry::Status::PURGED;
			}
			setCacheSize(mCurrentSize - entrySize);
			mUpdateTimestamp = bx::getHPCounter();
		}
	}

	bool TileCache::primeCache(Utils::Timer::Map3D_time_t timeoutMS)
	{
		ASSERT_MAIN_THREAD;
		
		std::queue<Key> entries;

		for (auto const& [name, source] : mSources)
		{
			if (source.specification()->minZoom != 0) // Don't attempt to prime sources that don't have zoom level 0 data
			{
				continue;
			}

			Key key = { name, { 0, 0, 0 } };
			auto state = at(key, false);
			if (!(state == nullptr || state->isRequestCompleted()))
			{
				entries.push(key);
			}
		}
		auto endTime = Utils::Timer::nowMS() + timeoutMS;
		
		while (!entries.empty() && Utils::Timer::nowMS() < endTime)
		{
			auto &key = entries.front();

			auto state = at(key, false);
			if (state != nullptr && state->isRequestCompleted())
			{
				entries.pop();
			}
			else
			{
				update();
				std::this_thread::sleep_for(std::chrono::milliseconds(5));
			}
		}

		return entries.empty();
	}

	bool TileCache::precache(Key const& key, bool ephemeral)
	{
		ASSERT_MAIN_THREAD;

		// get the appropriate source
		Source const& source = mSources.at(key.source);

		if (source.specification()->minZoom <= key.tile.level)	// only precache at or above the min zoom
		{
			// compute the appropriate tile id
			int maxZoom = source.specification()->maxZoom;
			Tiles::TileId const& tile = (key.tile.level > maxZoom) ? key.tile.parentAtLevel(maxZoom) : key.tile;

			// TileCache::at will add this key to the request queue if it is not already present
			Entry* entry = at({ key.source, tile }, ephemeral);

			// check if we already have the entry or not
			if (entry)
			{
				if (entry->status == Entry::Status::NOT_AVAILABLE)	// all work is done for this tile
				{
					return true;
				}
				else if (entry->status != Entry::Status::LOADED // if the status isn't loaded, we don't have the data
					&& entry->status != Entry::Status::EXPIRED)	// if the entry has been invalidated, we need to reload it
				{
					return false;
				}
				else
				{
					return true;
				}
			}
			else // if entry was nullptr, we don't have the data yet
			{
				return false;
			}
		}
		else	// if data is requested below the min level, no work needs to be done
		{
			return true;
		}
	}

	bool TileCache::precache(std::vector<Key> const& keys, bool ephemeral)
	{
		ASSERT_MAIN_THREAD;
		// at first, assume all the keys are precached
		bool allPrecached = true;
		for (Key const& key : keys)
		{
			allPrecached &= precache(key, ephemeral);
		}
		return allPrecached;
	}

	void TileCache::trimTo(size_t byteThreshold)
	{
		ASSERT_MAIN_THREAD;
		DEBUG_LOCK(mLruMutex);

		if (mLru.empty())
			return;

		auto back = mLru.end();
		
		size_t trimmedSize = mCurrentSize;
		std::vector<Key> toPurge;
		while (trimmedSize > byteThreshold && back != mLru.begin())
		{
			auto& pair = *(--back);
			if (pair.key.tile != Tiles::TileId{ 0, 0, 0 })	// skip deleting top-level tiles
			{
				toPurge.push_back(pair.key);
				trimmedSize -= pair.entry->size();
			}
		}

		for (auto const& key : toPurge)
		{
			purge(key);
		}

		MAP3D_ASSERT(trimmedSize == mCurrentSize, "actual size and computed size do not match");
	}

	void TileCache::trimOff(size_t byteThreshold)
	{
		ASSERT_MAIN_THREAD;

		if (byteThreshold > mCurrentSize)
		{
			trimTo(0);
		}
		else
		{
			trimTo(mCurrentSize - byteThreshold);
		}
	}

#if DEBUG_TILE_CACHE
	void TileCache::checkConsistency()
	{
		log(CacheAction::ConsistencyCheck, { { -1, -1, -1 }, 0xFFFFFFFF });
		
		size_t loadedTotal = 0;
		size_t parsedTotal = 0;

		DEBUG_LOCK(mLruMutex);

		static std::vector<CacheEvent> events(mLru.size());
		events.clear();
		
		for (auto& [key, entry] : mLru)
		{
			auto parsedIter = TileRequester::sInstance->mParsed.find(key);
			if (parsedIter != TileRequester::sInstance->mParsed.end())
			{
				MAP3D_ASSERT(entry->userData == nullptr, "Loaded data is present in mParsed and mLru simultaneously");
				auto entrySize = parsedIter->second->size();

				events.push_back({ CacheAction::ParsedConsistencyCheck, key, entrySize, mCurrentSize, mFrameTimestamp });
				parsedTotal += entrySize;
			}
			else
			{
				if (entry->size() != 0)
					CHECK_ENTRY_SIZE_CHANGED(entry);
				auto entrySize = entry->size();
				events.push_back({ CacheAction::LruConsistencyCheck, key, entrySize, mCurrentSize, mFrameTimestamp });
				loadedTotal += entrySize;
			}
		}

		if (loadedTotal != mCurrentSize)
		{
			{
				std::lock_guard lock(sLogMutex);
				sCacheLog.insert(sCacheLog.end(), events.begin(), events.end());
			}
			dumpLog("CacheErrorLog.csv", true);
			MAP3D_THROW("Loaded cache size is inconsistent!");
		}
		if (parsedTotal != TileRequester::sInstance->mParsedSize)
		{
			{
				std::lock_guard lock(sLogMutex);
				sCacheLog.insert(sCacheLog.end(), events.begin(), events.end());
			}
			dumpLog("CacheErrorLog.csv", true);
			MAP3D_THROW("Parsed cache size is inconsistent!");
		}
	}
#endif

	void TileCache::addSource(std::string const& name, std::shared_ptr<Styling::Source const> const& specification)
	{
		ASSERT_MAIN_THREAD;

		auto iter = mSources.find(name);
		if (iter != mSources.end())		// process case where we already have a source of this name
		{
			if (specification->type == Styling::Source::Type::GEOJSON)
			{
				// purge existing entries and overwrite the existing geojson source
				purge(name);
				mSources.insert_or_assign(name, Source{ specification });
				
				auto geojson = std::static_pointer_cast<Styling::GeojsonSource const>(specification);
				DataObjects::UserMarkupManager::add(name, geojson->data);
			}
			else
			{
				Source const& existing = iter->second;
				if (*specification != *existing.specification())	// only replace if the added specification is not the existing specification
				{
					// purge existing entries and overwrite the existing tiled source
					purge(name);
					mSources.insert_or_assign(name, Source{ specification });
				}
			}
		}
		else			// process case where we have no source for this name
		{
			mSources.insert_or_assign(name, Source{ specification });
		
			if (specification->type == Styling::Source::Type::GEOJSON)
			{
				auto geojson = std::static_pointer_cast<Styling::GeojsonSource const>(specification);
				DataObjects::UserMarkupManager::add(name, geojson->data);
			}
		}
	}

} }