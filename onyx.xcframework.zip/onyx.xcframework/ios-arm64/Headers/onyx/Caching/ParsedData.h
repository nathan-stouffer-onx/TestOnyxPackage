#ifndef __PARSED_DATA_H__
#define __PARSED_DATA_H__

#include <memory>

#include <bgfx/bgfx.h>

#include <lucid/Profiler.h>

#include "Tiles/HeightTile.h"
#include "Tiles/VectorTile.h"

namespace onyx {
namespace Caching {

	class ParsedCacheData
	{
	private:

		mutable lucid::core::Profiler::Sample mProfile;
	
	public:
		
		ParsedCacheData() : mProfile(nullptr, "root") { }
		virtual ~ParsedCacheData() {};
		
		virtual size_t size() = 0;
		
		virtual void releaseOwnership() = 0;
		
		lucid::core::Profiler::Sample const* getProfile() const { return mProfile.firstChild; }
		
		void snapshotProfile()
		{
			lucid::core::Profiler::snapshot(&mProfile);
			for (auto c = mProfile.firstChild; c != nullptr; c = c->nextSibling)
			{
				mProfile.timeTotal += c->timeTotal;
			}
		}
	};

	using SharedParsedDataT = std::shared_ptr<ParsedCacheData>;
	using SharedStreamT = std::shared_ptr<std::vector<uint8_t>>;

	class ImageUserData : public ParsedCacheData
	{
	private:
		bgfx::TextureHandle mHandle;

		uint16_t mWidth = 0;
		uint16_t mHeight = 0;
		bgfx::TextureFormat::Enum mFormat = bgfx::TextureFormat::Unknown;
		size_t mVidMemSize = 0;

	public:

		ImageUserData(bgfx::TextureHandle handle, bgfx::TextureInfo const& info) : mHandle(handle)
		{
			if (bgfx::isValid(handle))
			{
				mWidth = info.width;
				mHeight = info.height;
				mFormat = info.format;
				mVidMemSize = (size_t)info.storageSize;
			}
		}

		virtual ~ImageUserData()
		{
			if (bgfx::isValid(mHandle))
			{
				bgfx::destroy(mHandle);
				mHandle = BGFX_INVALID_HANDLE;
			}
		}

		virtual size_t size() override
		{
			return mVidMemSize;
		}

		void releaseOwnership() override
		{
			mHandle = BGFX_INVALID_HANDLE;
		}

		inline bgfx::TextureHandle getHandle() const { return mHandle; }
		inline bgfx::TextureFormat::Enum getFormat() const { return mFormat; }
		
	};

	class HeightUserData : public ImageUserData
	{
	private:
		std::shared_ptr<Tiles::HeightTile> mHeightTile = nullptr;
	public:
		size_t size() override
		{
			size_t sz = ImageUserData::size();
			if (mHeightTile)
			{
				sz += mHeightTile->byteSize();
			}
			return sz;
		}

		std::shared_ptr<Tiles::HeightTile> getHeightTile() const { return mHeightTile; }

		HeightUserData(bgfx::TextureHandle handle, bgfx::TextureInfo const& info, std::shared_ptr<Tiles::HeightTile> heightTile) :
			ImageUserData(handle, info),
			mHeightTile(heightTile)
		{
			if (mHeightTile != nullptr)
			{
				MAP3D_ASSERT(mHeightTile->byteSize() < (1 << 26), "height tile data is too large");
			}
		}

		virtual ~HeightUserData() {}
	};

	class VectorUserData : public ParsedCacheData
	{
	public:
		std::shared_ptr<Tiles::VectorTile> mData;

		size_t size() override
		{
			return mData != nullptr ? mData->byteCount() : 0;
		}
		void releaseOwnership() override {}
		VectorUserData(std::shared_ptr<Tiles::VectorTile> data) : mData(data) {};
	};

} }

#endif