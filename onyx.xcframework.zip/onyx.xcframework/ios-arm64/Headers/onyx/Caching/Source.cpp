#include "Source.h"

#include <Styling/Sources/TiledSources/RasterDemSource.h>

#include "Atlases/HeightAtlas.h"

namespace onyx {
namespace Caching {

	Source::Source(std::shared_ptr<Styling::Source const> const& _specification) :
		mSpecification(_specification),
		mAtlas(Source::Atlas(_specification)),
		mPyramid(Source::Pyramid(_specification))
	{}

	Source::~Source()
	{
		if (mAtlas)
		{
			delete mAtlas;
		}
		if (mPyramid)
		{
			delete mPyramid;
		}
	}

	Source::Source(Source&& source) noexcept :
		mSpecification(source.mSpecification),
		mAtlas(source.mAtlas),
		mPyramid(source.mPyramid)
	{
		source.mAtlas = nullptr;
		source.mPyramid = nullptr;
	}

	Source& Source::operator=(Source&& source) noexcept
	{
		mSpecification = source.mSpecification;
		mAtlas = source.mAtlas;
		mPyramid = source.mPyramid;

		source.mAtlas = nullptr;
		source.mPyramid = nullptr;

		return *this;
	}

	void Source::update()
	{
		if (mAtlas)
		{
			mAtlas->update();
		}
	}

	Atlases::TileAtlas* Source::Atlas(std::shared_ptr<Styling::Source const> const& specification)
	{
		if (specification && specification->isRaster())
		{
			std::shared_ptr<Styling::RasterSource const> raster = std::static_pointer_cast<Styling::RasterSource const>(specification);
			if (raster->type == Styling::Source::Type::RASTER_DEM)
			{
				// use 2-pixel padding so height sampling for normal computations has appropriate padding
				std::shared_ptr<Styling::RasterDemSource const> dem = std::static_pointer_cast<Styling::RasterDemSource const>(raster);
				size_t rawPadding = Styling::RasterDemSource::Padding(dem->encoding);
				Atlases::TileAtlas::InputPadding inputPadding =
				{
					uint32_t(Tiles::HeightTile::cPadding),
					uint32_t(Tiles::HeightTile::cPadding - rawPadding)
				};
				return new Atlases::HeightAtlas(raster->maxZoom, raster->tileSize, Atlases::cDefaultResolution, 2, inputPadding);
			}
			else
			{
				return new Atlases::TileAtlas(raster->tileSize, Atlases::cDefaultResolution, 1);
			}
		}
		else
		{
			return nullptr;
		}
	}

	Pyramid::TilePyramid<Tiles::VectorTile>* Source::Pyramid(std::shared_ptr<Styling::Source const> const& specification)
	{
		if (specification && specification->isVector())
		{
			return new Pyramid::TilePyramid<Tiles::VectorTile>();
		}
		else
		{
			return nullptr;
		}
	}

} }