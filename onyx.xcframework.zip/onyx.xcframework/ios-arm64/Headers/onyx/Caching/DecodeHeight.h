#ifndef __DECODE_HEIGHT_TILE_H__
#define __DECODE_HEIGHT_TILE_H__

#include <vector>
#include <memory>

#include <lucid/gal/Types.h>

#include <Styling/Sources/TiledSources/RasterDemSource.h>

namespace onyx {
namespace Caching {

	/*
	* The conversion parameter is a value that will be multiplied to the final heigh to convert units to the desired value
	*/
	std::vector<height_float_t> DecodeHeight(Styling::RasterDemSource::Encoding encoding, uint8_t const* stream, size_t size, height_float_t conversion = 1.0f);

	std::vector<height_float_t> DecodeTerrarium(size_t sideLen, uint8_t const* stream, size_t size, height_float_t conversion = 1.0f);
	std::vector<height_float_t> DecodeMapbox(size_t sideLen, uint8_t const* stream, size_t size, height_float_t conversion = 1.0f);
	std::vector<height_float_t> DecodeTinyDem(size_t sideLen, uint8_t const* stream, size_t size, height_float_t conversion = 1.0f);

} }

#endif