#ifndef __TILE_CACHE_H__
#define __TILE_CACHE_H__
#pragma once

#include <queue>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <sstream>
#include <functional>

#include <lucid/Profiler.h>

#include <Styling/Sources/Source.h>

#include "Atlases/TileAtlas.h"
#include "Pyramid/TilePyramid.h"
#include "Tiles/TileId.h"
#include "Tiles/HeightTile.h"
#include "Tiles/VectorTile.h"
#include "Utils/EnumsStructs.h"
#include "Utils/TimeFilter.h"
#include "Utils/Timer.h"

#include "LRU.h"
#include "ParsedData.h"
#include "Source.h"
#include "TileCacheKey.h"

#if defined(PLATFORM_EMSCRIPTEN)
#define NO_TILE_CACHE_THREADS
#else
#include <mutex>
#include <bx/thread.h>
#endif

namespace onyx {
namespace Caching {

#if defined(_DEBUG)
	constexpr size_t MemCacheLimitDefault = 300 << 20;		// 300MB cache size limit to exercise the cache clear code while we're debugging
#else
	constexpr size_t MemCacheLimitDefault = 1 << 30;		// 1 GB cache size limit
#endif
	constexpr uint64_t DiskCacheLimitDefault = 0x1ull << 32;		// 4 GB local/disk storage limit default

	class TileCache
	{
	public:

		using Key = TileCacheKey;

		using SharedStreamT = std::shared_ptr<std::vector<uint8_t>>;

		struct Entry
		{
			enum class Status
			{
				UNKNOWN,				// entry status is unknown
				REQUESTED,				// entry has been requested
				LOADED,					// entry has been loaded into atlases/managers
				NOT_AVAILABLE,			// entry is not available
				EXPIRED,				// entry needs to be refreshed
				PURGED,					// entry has been purged
			};

			Status status = Status::REQUESTED;
			
			SharedStreamT stream;
			SharedParsedDataT parsed;
			
			size_t retries = 0;

			time_float_t expiresMS = std::numeric_limits<time_float_t>::max();

			size_t size() const
			{
				size_t result = 0;
				if (stream.get() != nullptr)
				{
					result = stream->size();
				}

				if (parsed != nullptr)
				{
					result += parsed->size();
				}

				return result;
			}
			
			Entry() = default;

			inline bool isRequestCompleted() const
			{
				return status == Status::LOADED || status == Status::NOT_AVAILABLE;
			}
		};

		typedef std::unordered_map<Key, Entry*> EntryMapT;

		static TileCache* Instance();
		static void Shutdown();

		void update();

		void touch(Key const& key);
		void touch(std::vector<Key> const& keys);

		Entry* at(Key const& key, bool ephemeral = true);
		Entry::Status entryStatus(Key const& key);
		
		std::vector<Tiles::TileId> recentTiles(double windowMS) const;

		void addSource(std::string const& name, std::shared_ptr<Styling::Source const> const& specification);

		bool primeCache(Utils::Timer::Map3D_time_t timeoutMS = 1000);

		// indicators for whether all work is complete on the requested tiles
		bool precache(Key const& key, bool ephemeral = true);
		bool precache(std::vector<Key> const& keys, bool ephemeral = true);

		void trimTo(size_t byteThreshold);
		void trimOff(size_t byteThreshold);

		void purge(std::string const& source, bool placeholderOnly = false);
		void purge(Tiles::TileId const& tile, bool placeholderOnly = false);
		void purge(Key const& key, bool placeholderOnly = false);

		void invalidate(Key const& key);
		void invalidate(Tiles::TileId const& key);
		void invalidate(std::string const& source, lgal::world::AABB2d area);

		void getEntryKeys(std::vector<Key>& keys) const;
		void getEntries(EntryMapT& entries, std::vector<Key> const &keys) const;

		size_t getCacheLimit() { return mMemCacheLimit; }
		size_t getUpdateTimestamp() { return mUpdateTimestamp; }

	public:

		enum class CacheAction
		{
			Search					= 0,	// The cache searched for an entry
			Touch					= 1,	// A cache entry was touched to make it 'current'
			Request					= 2,	// A new entry was added to the cache and added to the request queue
			Fetch					= 3,	// A fetch was issued for an entry in the request queue
			Parse					= 4,	// Data fetched for a request was parsed
			Purge					= 5,	// An entry was purged from the cache
			SizeReport				= 6,	// A size consistency check was initiated
			MoveToLru				= 7,	// An entry from the Parsed map was moved into the LRU list
			MoveToParsed			= 8,	// An entry was retrieved and parsed and was added to the Parsed map
			ConsistencyCheck		= 9,	// A cache consistency check was triggered
			LruReport				= 10,	// A report for an entry in the LRU list
			ParsedReport			= 11,	// A report for an entry in the Parsed map
			LruConsistencyCheck		= 12,	// A LRU list entry cache consistency check
			ParsedConsistencyCheck	= 13	// A Parsed map entry cache consistency check
		};
#if DEBUG_TILE_CACHE

		struct CacheEvent
		{
			CacheAction action;
			Key key;
			size_t data;
			size_t currentSize;
			uint64_t timestamp;
		};

		static std::vector<CacheEvent> sCacheLog;
		static std::unordered_map<Key, size_t> sCachedEntrySizes;

		static std::mutex sLogMutex;

		static inline void log(CacheAction action, Key const& key, size_t data = 0)
		{
			std::lock_guard lock(sLogMutex);
			sCacheLog.push_back({ action, key, data, sInstance->mCurrentSize, sInstance->mFrameTimestamp });
		}

		static void dumpLog(std::string const& fileName, bool includeConsistency);
		static void validateEntry(Entry* entry)
		{
			auto &key = entry->key;
			auto currentSize = entry->size();
			if (currentSize == 0)
			{
				return;
			}

			auto oldSize = sCachedEntrySizes[key];
			if (oldSize != currentSize)
			{
				dumpLog("CacheErrorLog.csv", true);
				std::ostringstream msg;
				msg << "Entry { " << key.id.level << ", " << key.id.x << ", " << key.id.y << " } changed sizes! (was " << oldSize <<" now " << currentSize << ")";
				MAP3D_THROW(msg.str().c_str());
			}
		}
#else
		static inline void log(CacheAction /* action */, Key const& /* key */, size_t /* data */ = 0) { }
		static inline void dumpLog(std::string const& /* fileName */, bool /* includeConsistency */) { }
		static inline void validateEntry(Entry* /* entry */) { }
#endif

	private:
	
		TileCache();
		~TileCache();

		void markIfExpired(Entry* entry, Utils::Timer::Map3D_time_t nowMS = Utils::Timer::nowMS());

		static TileCache *sInstance;

		size_t mCurrentSize = 0;		// current size of the non-threaded cache

		size_t mMemCacheLimit = MemCacheLimitDefault;

		uint64_t mFrameTimestamp = 0;
		uint64_t mUpdateTimestamp = 0;

		std::unordered_map<std::string, Source> mSources;

		// LRU cache storing non-threaded access to the entries. access should be restricted to the main thread
		// keeps the most recently requested entries at the front and the least recently requested entries at the back
		Caching::LRU<Key, Entry*> mLru;
		
		Utils::TimeFilter<Tiles::TileId> mTimeFilter;

#if DEBUG_TILE_CACHE && !defined(NO_TILE_CACHE_THREADS)
		unsigned int mThreadId;
		mutable std::recursive_mutex mLruMutex;
#endif
		void setCacheSize(size_t size);

#if DEBUG_TILE_CACHE
		void checkConsistency();
#endif

	public: // getters/setters

		Entry::Status fastStatus(Key const& key) const { return mLru.at(key)->status; }
		size_t cacheEntryCount()	const { return mLru.size(); }
		size_t currentSize()		const { return mCurrentSize; }
		size_t totalSize()          const;

		Source const& getSource(std::string const& name) const
		{
			auto iter = mSources.find(name);
			MAP3D_ASSERT(iter != mSources.end(), "Invalid source name requested");
			return iter->second;
		}

		inline void getSourceNames(std::vector<std::string>& target) const
		{
			target.clear();
			target.reserve(mSources.size());
			for (auto const& [name, source] : mSources)
			{
				target.push_back(name);
			}
		}

		inline std::string getHeightSourceName() const
		{
			for (auto const& [name, source] : mSources)
			{
				if (source.type() == Styling::Source::Type::RASTER_DEM)
				{
					return name;
				}
			}
			// if we make it here, return invalid name
			return "";
		}

	};

} }

namespace std
{

	inline std::string_view toStringView(onyx::Caching::TileCache::Entry::Status const& value)
	{
		static std::unordered_map<onyx::Caching::TileCache::Entry::Status, std::string_view> nameMap =
		{
			{ onyx::Caching::TileCache::Entry::Status::UNKNOWN,			"unknown"		},
			{ onyx::Caching::TileCache::Entry::Status::REQUESTED,			"requested"		},
			{ onyx::Caching::TileCache::Entry::Status::LOADED,			"loaded"		},
			{ onyx::Caching::TileCache::Entry::Status::NOT_AVAILABLE,		"not available" },
			{ onyx::Caching::TileCache::Entry::Status::EXPIRED,			"expired"		},
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Caching::TileCache::Entry::Status");
	}

}

#endif