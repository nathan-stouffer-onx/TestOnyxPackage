#ifndef _HEIGHT_TILE_TASKS_H
#define _HEIGHT_TILE_TASKS_H
#pragma once

#include <memory>

#include "Tiles/HeightTile.h"
#include "../PrepareTask.h"

namespace onyx {
namespace Caching {
namespace Tasks {

	class HeightTileTask : public PrepareTask
	{
	public:

		virtual ~HeightTileTask() { };

	protected:
		HeightTileTask(Tiles::TileId const& tileId, PreparedData::Metadata _metadata, std::shared_ptr<Styling::Layer const> _layer, std::shared_ptr<Tiles::HeightTile const>& tile)
			: PrepareTask(tileId, _metadata, _layer)
			, mTile(tile)
		{ }

		std::shared_ptr<Tiles::HeightTile const> mTile;
	};

	class HeightSymbolTask : public HeightTileTask
	{
	public:

		HeightSymbolTask(Tiles::TileId const& tileId, PreparedData::Metadata _metadata, std::shared_ptr<Styling::Layer const> _layer, std::shared_ptr<Tiles::HeightTile const>& tile)
			: HeightTileTask(tileId, _metadata, _layer, tile)
		{ }

		std::shared_ptr<PreparedData> prepare(Styles& styles) override;
	};

} } }

#endif //_HEIGHT_TILE_TASKS_H