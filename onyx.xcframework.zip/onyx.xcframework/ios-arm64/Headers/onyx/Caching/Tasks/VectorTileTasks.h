#ifndef _VECTOR_TILE_TASKS_H
#define _VECTOR_TILE_TASKS_H
#pragma once

#include <memory>

#include "Atlases/HeightAtlas.h"
#include "Tiles/VectorTile.h"
#include "../PrepareTask.h"
#include "Camera/CameraState.h"

namespace onyx {
namespace Caching {
namespace Tasks {

	class VectorTileTask : public PrepareTask
	{
	public:

		VectorTileTask(Camera::CameraState const& cameraState, Tiles::TileId const& tileId, PreparedData::Metadata _metadata,
						std::shared_ptr<Styling::Layer const> _layer, std::shared_ptr<Tiles::VectorTile const> const& tile)
			: PrepareTask(tileId, _metadata, _layer)
			, mCameraState(cameraState)
			, mTile(tile)
		{ }

		virtual ~VectorTileTask() { }

	protected:
		// helper functions to reduce verbosity and consolidate profiling
		std::shared_ptr<Vector::Layer const> clip(std::string const& layer);
		bool filter(Styling::Expressions::Arguments const& args);

	protected:
		Camera::CameraState const mCameraState;

		std::shared_ptr<Tiles::VectorTile const> mTile;
	};

	class VectorLineTask : public VectorTileTask
	{
	public:

		VectorLineTask(Camera::CameraState const& cameraState, Tiles::TileId const& tileId, PreparedData::Metadata _metadata,
						std::shared_ptr<Styling::Layer const> _layer, std::shared_ptr<Tiles::VectorTile const> const& tile) :
			VectorTileTask(cameraState, tileId, _metadata, _layer, tile)
		{}

		std::shared_ptr<PreparedData> prepare(Styles& styles) override;

	private:

		void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::shared_ptr<Vector::Feature const> const& feature, lgal::gpu::Vector2 const& style, gpu_float_t maxSegmentLen);
		void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::shared_ptr<Vector::LinestringFeature const> const& linestring, lgal::gpu::Vector2 const& style, gpu_float_t maxSegmentLen);
		void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::shared_ptr<Vector::PolygonFeature const> const& polygon, lgal::gpu::Vector2 const& style, gpu_float_t maxSegmentLen);

	};

	class VectorFillTask : public VectorTileTask
	{
	public:

		VectorFillTask(Camera::CameraState const& cameraState, Tiles::TileId const& tileId, PreparedData::Metadata _metadata, 
			std::shared_ptr<Styling::Layer const> _layer, std::shared_ptr<Tiles::VectorTile const> const& tile) :
			VectorTileTask(cameraState, tileId, _metadata, _layer, tile)
		{}

		std::shared_ptr<PreparedData> prepare(Styles& styles) override;
	};

	class VectorSymbolTask : public VectorTileTask
	{
	public:

		VectorSymbolTask(Camera::CameraState const& cameraState, Tiles::TileId const& tileId, PreparedData::Metadata _metadata,
							std::shared_ptr<Styling::Layer const> _layer, std::shared_ptr<Tiles::VectorTile const> const& tile,
							std::shared_ptr<Tiles::HeightTile const> const& heightTile) :
			VectorTileTask(cameraState, tileId, _metadata, _layer, tile),
			mHeightTile(heightTile)
		{ }

		std::shared_ptr<PreparedData> prepare(Styles& styles) override;

	private:

		std::shared_ptr<Tiles::HeightTile const> const mHeightTile;
	};

} } }

#endif //_VECTOR_TILE_TASKS_H