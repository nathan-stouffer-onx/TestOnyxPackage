#ifndef __CACHING_SOURCE_H__
#define __CACHING_SOURCE_H__

#include <memory>

#include <Styling/Sources/Source.h>

#include "Atlases/TileAtlas.h"
#include "Pyramid/TilePyramid.h"
#include "Tiles/VectorTile.h"

namespace onyx {
namespace Caching {
			
	class Source
	{
	public:

		Source() : Source(nullptr) {}
		Source(std::shared_ptr<Styling::Source const> const& _specification);
		~Source();

		Source(Source const&) = delete;
		Source& operator=(Source const&) = delete;

		Source(Source&& source) noexcept;
		Source& operator=(Source&& source) noexcept;

		void update();

		inline Styling::Source::Type type() const { return mSpecification->type; }
		inline bool isRaster() const { return mSpecification->isRaster(); }
		inline bool isHeight() const { return mSpecification->isHeight(); }
		inline bool isVector() const { return mSpecification->isVector(); }
		inline lgal::Range range() const { return mSpecification->range(); }

		inline std::shared_ptr<Styling::Source const> const& specification() const { return mSpecification; }
		inline Atlases::TileAtlas const* atlas() const { return mAtlas; }
		inline Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid() const { return mPyramid; }

		inline std::shared_ptr<Styling::Source const> const& specification() { return mSpecification; }
		inline Atlases::TileAtlas* atlas() { return mAtlas; }
		inline Pyramid::TilePyramid<Tiles::VectorTile>* pyramid() { return mPyramid; }

	private:

		static Atlases::TileAtlas* Atlas(std::shared_ptr<Styling::Source const> const& specification);
		static Pyramid::TilePyramid<Tiles::VectorTile>* Pyramid(std::shared_ptr<Styling::Source const> const& specification);

	private:

		std::shared_ptr<Styling::Source const> mSpecification;

		Atlases::TileAtlas* mAtlas;
		Pyramid::TilePyramid<Tiles::VectorTile>* mPyramid;

	};

} }

#endif