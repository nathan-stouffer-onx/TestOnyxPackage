#ifndef __CACHING_PREPARE_TASK_H__
#define __CACHING_PREPARE_TASK_H__
#pragma once

#include <Styling/Styles/LineStyle.h>
#include <Styling/Layers/Layer.h>

#include "Atlases/StyleAtlases.h"
#include "Tiles/TileId.h"
#include "PreparedData.h"

// These are included here for convenience because nearly every derived class
// will almost certainly use at least one of them.  They are not used directly
// by the base PrepareTask class.
#include "Tessellation/Lines.h"
#include "Tessellation/Fills.h"
#include "Tessellation/PolyGrid.h"
#include "Vector/LinestringFeature.h"
#include "Vector/PolygonFeature.h"

namespace onyx {
namespace Caching {

	class PrepareTask
	{
	public:

		struct Styles
		{
			Atlases::LineStyleAtlas& lines;
			Atlases::FillStyleAtlas& fills;
		};

	public:

		PrepareTask(Tiles::TileId const &tileId, PreparedData::Metadata _metadata, std::shared_ptr<Styling::Layer const> _layer)
			: mTileId(tileId)
			, mMetadata(_metadata)
			, mLayer(_layer)
		{ }

		virtual ~PrepareTask() { };

		virtual std::shared_ptr<PreparedData> prepare(Styles& styles) = 0;

		inline void markStale() { mMetadata.stale = true; }

		Tiles::TileId getTileId() { return mTileId; }
		PreparedData::Metadata const& getMetadata() const { return mMetadata; }
		std::shared_ptr<Styling::Layer const> const& getLayer() const { return mLayer; }

	protected:

		Tiles::TileId const mTileId;
		PreparedData::Metadata const mMetadata;
		std::shared_ptr<Styling::Layer const> const mLayer;

	};

} }

#endif