#include "DecodeHeight.h"

#include <System/Map3DException.h>

namespace onyx {
namespace Caching {

	/*
	* The formula to decode terrarium can be found here:
	*     - https://github.com/tilezen/joerd/blob/master/docs/formats.md#terrarium
	* We employ a slightly modified (but mathematically equivalent) formula that preserves more floating point precision
	*/
	static inline height_float_t DecodeTerrariumPixel(uint8_t r, uint8_t g, uint8_t b)
	{
		height_float_t constexpr scalar = 1.f / 256.f;
		return scalar * (((r << 16) + (g << 8) + b) - (256 * 32'768));
	}

	/*
	* The formula to decode mapbox can be found here:
	*     - https://docs.mapbox.com/data/tilesets/reference/mapbox-terrain-rgb-v1/#elevation-data
	* We employ a slightly modified (but mathematically equivalent) formula that preserves more floating point precision
	*/
	static inline height_float_t DecodeMapboxPixel(uint8_t r, uint8_t g, uint8_t b)
	{
		height_float_t constexpr scalar = 0.1f;
		return scalar * (((r << 16) + (g << 8) + b) - (10 * 10'000));
	}

	std::vector<height_float_t> DecodeHeight(Styling::RasterDemSource::Encoding encoding, uint8_t const* stream, size_t size, height_float_t conversion)
	{
		size_t sideLen = Styling::RasterDemSource::PaddedLength(encoding);
		switch (encoding)
		{
			case Styling::RasterDemSource::Encoding::TERRARIUM: return DecodeTerrarium(sideLen, stream, size, conversion);	break;
			case Styling::RasterDemSource::Encoding::MAPBOX:	return DecodeMapbox(sideLen, stream, size);		break;
			case Styling::RasterDemSource::Encoding::TINY_DEM:	return DecodeTinyDem(sideLen, stream, size);		break;
			default: return {};
		}
	}

	std::vector<height_float_t> DecodeTerrarium(size_t sideLen, uint8_t const* stream, size_t size, height_float_t conversion)
	{
		size_t numPixels = size / 3;
		
		MAP3D_ASSERT(size % 3 == 0, "Byte stream must be divisible by three to match RGB channels");
		MAP3D_ASSERT(sideLen * sideLen == numPixels, "width and height must match byte stream dimensions");

		std::vector<height_float_t> heights;
		heights.resize(numPixels);
		height_float_t* heightPtr = heights.data();

		for (size_t i = 0; i < numPixels; ++i)
		{
			// grab the channels
			uint8_t r = *stream++;
			uint8_t g = *stream++;
			uint8_t b = *stream++;
			// decode and write height to buffer
			height_float_t height = DecodeTerrariumPixel(r, g, b);
			*heightPtr = height * conversion;		// convert units based on the passed in value
			++heightPtr;
		}

		return heights;
	}

	std::vector<height_float_t> DecodeMapbox(size_t sideLen, uint8_t const* stream, size_t size, height_float_t conversion)
	{
		size_t numPixels = size / 3;

		MAP3D_ASSERT(size % 3 == 0, "Byte stream must be divisible by three to match RGB channels");
		MAP3D_ASSERT(sideLen * sideLen == numPixels, "width and height must match byte stream dimensions");

		std::vector<height_float_t> heights;
		heights.resize(numPixels);
		height_float_t* heightPtr = heights.data();

		for (size_t i = 0; i < numPixels; ++i)
		{
			// grab the channels
			uint8_t r = *stream++;
			uint8_t g = *stream++;
			uint8_t b = *stream++;
			// decode and write height to buffer
			height_float_t height = DecodeMapboxPixel(r, g, b);
			*heightPtr = height * conversion;			// convert units based on the passed in value
			++heightPtr;
		}

		return heights;
	}

	std::vector<height_float_t> DecodeTinyDem(size_t sideLen, uint8_t const* stream, size_t size, height_float_t conversion)
	{
		size_t numPixels = size / 3;

		MAP3D_ASSERT(stream != nullptr && size != 0, "Empty stream passed");
		MAP3D_ASSERT(size % 3 == 0, "Byte stream must be divisible by three to match RGB channels");
		MAP3D_ASSERT(sideLen * sideLen == numPixels, "width and height must match byte stream dimensions");

		std::vector<height_float_t> heights;

		heights.resize(numPixels);
		uint8_t const* scanLine = stream;

		height_float_t* heightData = heights.data();
		height_float_t* heightDataEnd = heightData + (numPixels);
		// out = color_to_number(colors)
		// 
		// Undo the encoding on negative numbers
		// out = np.where(out % 2 == 1, -1 * (out - 1), out)

		size_t width = sideLen;
		size_t height = sideLen;

		// First unpack the RGB-encoded heights
		for (size_t y = 0; y < height; ++y, scanLine += (width * 3))
		{
			auto rgb = scanLine;

			for (size_t x = 0; x < width; ++x, rgb += 3, ++heightData)
			{
				uint8_t	r = rgb[0],
					g = rgb[1],
					b = rgb[2];

				bool isNegative = b & 0x1;
				b &= 0xFE;

				float32_t decodedHeight = (r * 256.f * 256.f) + (g * 256.f) + b;
				if (isNegative)
				{
					decodedHeight *= -1;
				}

				*heightData = decodedHeight;
			}
		}

		// At this point, our height data is:
		//      0 1 2 3 ... width
		//      1 E E E     E
		//      2 E E E     E
		//      3 E E E     E
		//    ...
		// height E E E     E
		// --------------------------------
		// E = Encoded			D = Decoded

		// out[0, 1] = out[0, 0] + out[0, 1]
		// out[1, 0] = out[0, 0] + out[1, 0]
		// out[1, 1] = int((out[0, 1] + out[1, 0]) / 2) + out[1, 1]

		// Special case the first 2x2 pixels in the top - left
		{
			heightData = heights.data();
			float a = heightData[0] + heightData[1],
				b = heightData[0] + heightData[width];
			heightData[1] = a;
			heightData[width] = b;
			heightData[width + 1] = (a + b) * 0.5f + heightData[width + 1];
		}

		// At this point, our height data is:
		//      0 1 2 3 ... width
		//      1 D D E     E
		//      2 D D E     E
		//      3 E E E     E
		//    ...
		// height E E E     E

		// rows, cols = out.shape
		// 
		//	for i in range(0, 2) :
		//	 	for j in range(2, cols) :
		//	 		a = out[i, j - 2]
		//	 		b = out[i, j - 1]
		//	 		e = out[i, j]
		//	 		out[i, j] = 2 * b - a + e

		// extract first two rows
		for (uint32_t y = 0u; y <= 1; ++y)
		{
			auto rowData = heightData + (width * y);
			for (uint32_t x = 0u; x < width - 2; ++x)
			{
				float a = rowData[0];
				float b = rowData[1];
				float e = rowData[2];

				rowData[2] = 2 * b - a + e;
				++rowData;
			}
		}

		// At this point, our height data is:
		//      0 1 2 3 ... width
		//      1 D D D     D
		//      2 D D D     D
		//      3 E E E     E
		//    ...
		// height E E E     E

		//	for i in range(2, rows) :
		//	 	for j in range(0, 2) :
		//	 		a = out[i - 2, j]
		//	 		b = out[i - 1, j]
		//	 		e = out[i, j]
		//	 		out[i, j] = 2 * b - a + e

		// extract first two columns
		for (uint32_t y = 0; y < height - 2; ++y)
		{
			auto rowData = heightData + (width * y);
			for (uint32_t x = 0u; x <= 1; ++x)
			{
				float a = rowData[0];
				float b = rowData[width];
				float e = rowData[width << 1];
				rowData[width << 1] = 2 * b - a + e;
				++rowData;
			}
		}

		// At this point, our height data is:
		//      0 1 2 3 ... width
		//      1 D D D     D
		//      2 D D D     D
		//      3 D D E     E
		//    ...
		// height D D E     E

		//	for i in range(2, rows) :
		//		for j in range(2, cols) :
		//			a, b = out[i - 2, j], out[i - 1, j]
		//			c, d = out[i, j - 2], out[i, j - 1]
		//			e = out[i, j]
		//			out[i, j] = (2 * b - a + 2 * d - c) / 2 + e

		// extract the remaining
		for (uint32_t y = 0u; y < height - 2; ++y)
		{
			auto rowData = heightData + (width * y);
			for (uint32_t x = 0u; x < width - 2; ++x)
			{
				float a = rowData[width << 1],
					b = rowData[(width << 1) + 1],
					c = rowData[2],
					d = rowData[width + 2],
					e = rowData[(width << 1) + 2];
				rowData[(width << 1) + 2] = (2 * b - a + 2 * d - c) * 0.5f + e;
				++rowData;
			}
		}

		// out = out / 5 (and scaled by unit conversion)
		for (heightData = heights.data(); heightData < heightDataEnd; ++heightData)
		{
			*heightData *= 0.2f * conversion;
		}

		// return out
		return heights;
	}

} }