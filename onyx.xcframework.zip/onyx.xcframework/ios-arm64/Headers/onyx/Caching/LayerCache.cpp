#include "LayerCache.h"

#if MAP3D_THREADS_ENABLED
#include <chrono>
#include <thread>
#include <condition_variable>
#endif

#include <lucid/gal/Types.h>
#include <lucid/Profiler.h>

#include <System/Map3DException.h>
#include <System/Threading.h>

#include "Utils/Timer.h"

#if MAP3D_THREADS_ENABLED
#define LOCK(mtx) std::lock_guard lock##mtx(mtx);
#else
#define LOCK(mtx)
#endif

namespace onyx {
namespace Caching {

	size_t LayerCache::sInstanceCount = 0;

#if !MAP3D_THREADS_ENABLED
	static constexpr time_float_t cTimeCapMS = 5.0;
#endif

#if MAP3D_THREADS_ENABLED

	int32_t LayerCache::PrepareThreadFunc(LayerCache* cache)
	{
		logD("LayerCache::prepareThreadFunc");
		std::this_thread::sleep_for(std::chrono::milliseconds(100));

		core::Threading::setPriority(core::Threading::Priority::LOW);

		MAP3D_FINALLY([&] { logD("Exiting LayerCache::PrepareThreadFunc"); });

		MAP3D_ASSERT(cache != nullptr, "Incomplete thread data passed to LayerCache::prepareThreadFunc");

		while (cache->mKeepRunning)
		{
			lucid::core::Profiler::reset();
			cache->mPrepareThreadInfo.status = PrepareThreadStatus::IDLING;
			cache->mActiveTask = ActiveTask::invalid();
			MAP3D_TRY
				LUCID_PROFILE_SCOPE("LayerCache Prepare Thread");

				cache->mPrepareThreadInfo.status = PrepareThreadStatus::TRIMMING;
				cache->trimStaleTasks();
				cache->mPrepareThreadInfo.status = PrepareThreadStatus::IDLING;

				std::unique_lock lock(cache->mMutex);
				cache->mTaskReadyCond.wait(lock, [cache] {
					return !cache->mPendingTasks.empty() || !cache->mKeepRunning;
				});
				if (!cache->mKeepRunning) { break; }

				cache->mPrepareThreadInfo.status = PrepareThreadStatus::DEQUEUEING;
			
				// check if we need to update the insertion point
				{
					auto iter = cache->mPendingTasks.begin();
					if (iter == cache->mInsertionPoint)
					{
						++(cache->mInsertionPoint);
					}
				}

				// pop from the pending tasks
				PendingTasksT::Pair& front = cache->mPendingTasks.front();
				EntryKey key = front.key;
				task_ptr_t task = std::move(front.entry.task);
				time_float_t touchTimeMS = front.entry.touchTimeMS;
				cache->mPendingTasks.pop_front();

				// if the task was touched recently enough, go ahead and process it. otherwise ignore it
				if (cache->mFrameTimeMS - touchTimeMS <= cache->mTaskTimeoutMS)
				{
					cache->mPrepareThreadInfo.status = PrepareThreadStatus::PREPARING;
					cache->mActiveTask = ActiveTask(key, task->getMetadata());

					lock.unlock();	// preparing layer -- might take awhile, so we release the lock

					std::shared_ptr<PreparedData> prepared = cache->prepare(task);

					// write to completed tasks
					{
						std::lock_guard relock(cache->mMutex);
						if (!cache->mActiveTask.purge)	// check to see if the task was purged while we prepared it
						{
							if (cache->mActiveTask.metadata.stale)	// if the task was marked as stale while we prepared it, update that info
							{
								prepared->markStale();
							}

							MAP3D_DEBUG_ASSERT(prepared->metadata() == cache->mActiveTask.metadata, "Metadata is out of sync");

							auto iter = cache->mCompleted.find(key);
							if (iter == cache->mCompleted.end())
							{
								cache->mCompleted[key] = prepared;
							}
							else
							{
								std::shared_ptr<PreparedData> const& existing = iter->second;
								if (prepared->metadata().replaces(existing->metadata()))
								{
									cache->mCompleted[key] = prepared;
								}
							}
						}
					}
				}

			MAP3D_CATCH
				logE(ex.summarize());
			MAP3D_CUSTOM_CATCH(std::exception)
				auto what = ex.what();
				logE("Error in LayerCache prepare thread: %s", what);
			MAP3D_CATCH_ALL
				logE("Caught exception in LayerCache prepare thread");
				// Just make sure that we don't ever bypass thread deinitialization
			MAP3D_END_CATCH
		}
		logD("LayerCache prepare thread shut down cleanly");

		return 0xDEAD;
	}
#endif

	LayerCache::LayerCache()
#if MAP3D_THREADS_ENABLED
		: mPrepareThreadInfo(std::thread(LayerCache::PrepareThreadFunc, this))
#endif
	{
		++sInstanceCount;
	}

	LayerCache::~LayerCache()
	{
#if MAP3D_THREADS_ENABLED
		mKeepRunning = false;
		mTaskReadyCond.notify_all();	// Wake up any waiting prepare threads
		mPrepareThreadInfo.thread.join();
		logD("LayerCache thread shut down");
#endif
		--sInstanceCount;
	}

	void LayerCache::update()
	{
		LUCID_PROFILE_SCOPE("update LayerCache");

#if MAP3D_THREADS_ENABLED
		{
			LOCK(mMutex);
			for (auto const& [key, prepared] : mCompleted)
			{
				if (mLRU.contains(key))
				{
					// check that the freshly prepared item should replace the existing item
					Entry const& entry = mLRU.at(key);
					if (!entry.prepared || prepared->metadata().replaces(entry.prepared->metadata()))
					{
						replace(key, prepared);
					}
				}
			}
			mCompleted.clear();
			mInsertionPoint = mPendingTasks.begin();
		}

		// trim off any excess gpu resources
		trimTo(maximums());

		// if there wasn't room, make some space
		if (mSize > mCapacity)
		{
			trimTo(mCapacity);
		}
#else
		time_float_t beginMS = Utils::Timer::nowMS();

		while (!mPendingTasks.empty() && Utils::Timer::nowMS() - beginMS <= cTimeCapMS)
		{
			PendingTasksT::Pair& front = mPendingTasks.front();
			EntryKey key = front.key;
			task_ptr_t task = std::move(front.entry.task);
			time_float_t touchTimeMS = front.entry.touchTimeMS;
			mPendingTasks.pop_front();

			// if the task was touched recently enough, go ahead and process it. otherwise ignore it
			if (mFrameTimeMS - touchTimeMS <= mTaskTimeoutMS)
			{
				if (mLRU.contains(key))	// only prepare the data if the LRU still contains the entry
				{
					PreparedData::Metadata const& metadata = task->getMetadata();
					auto const& entry = mLRU.at(key);
					// only prepare the data if it should still replace the existing entry
					if (!entry.prepared || metadata.replaces(entry.prepared->metadata()))
					{
						std::shared_ptr<PreparedData> prepared = prepare(task);
						replace(key, prepared);

						// if there wasn't room, make some space
						if (mSize > mCapacity)
						{
							trimTo(mCapacity);
						}
					}
				}
			}
		}

		// update the insertion point
		mInsertionPoint = mPendingTasks.begin();
#endif

		// update style atlases
		mLineStyles.update();
		mFillStyles.update();
	}

	void LayerCache::clear()
	{
		mSize = 0;
		mLRU.clear();
		mCounts.clear();
		
		{
			LOCK(mMutex);
			mPendingTasks.clear();
			mInsertionPoint = mPendingTasks.begin();
#if MAP3D_THREADS_ENABLED
			mActiveTask.purge = true;
			mCompleted.clear();
#endif
		}
	}

	bool LayerCache::isPending(EntryKey const& key) const
	{
		auto iter = mLRU.find(key);
		if (iter != mLRU.end())		// => an entry is in the LRU
		{
			LOCK(mMutex);

			// perform necessary finds
			auto pendingIter = mPendingTasks.find(key);
			auto completedIter = mCompleted.find(key);
			
			if (pendingIter != mPendingTasks.end())
			{
				return true;
			}
#if MAP3D_THREADS_ENABLED
			else if (mActiveTask.key == key && !mActiveTask.purge)
			{
				return true;
			}
			else if (completedIter != mCompleted.end())
			{
				return true;
			}
#endif
		}

		// fall through case => return false
		return false;
	}

	bool LayerCache::replaces(EntryKey const& key, PreparedData::Metadata const& metadata) const
	{
		auto iter = mLRU.find(key);
		if (iter != mLRU.end())		// => an entry is in the LRU
		{
			LOCK(mMutex);

			// perform necessary finds
			auto pendingIter = mPendingTasks.find(key);
#if MAP3D_THREADS_ENABLED
			auto completedIter = mCompleted.find(key);
#endif

			if (pendingIter != mPendingTasks.end())					// if there is a pending task, test against it
			{
				PreparedData::Metadata const& pending = pendingIter->entry.task->getMetadata();
				return metadata.replaces(pending);
			}
#if MAP3D_THREADS_ENABLED
			else if (mActiveTask.key == key && !mActiveTask.purge)	// test against the actively processing task
			{
				return metadata.replaces(mActiveTask.metadata);
			}
			else if (completedIter != mCompleted.end())				// if there is a completed task, test against it
			{
				PreparedData::Metadata const& completed = completedIter->second->metadata();
				return metadata.replaces(completed);
			}
#endif
			else													// no task is in bound, test against the metadata in the LRU
			{
				Entry const& entry = iter->entry;
				return !entry.prepared || metadata.replaces(entry.prepared->metadata());
			}
		}
		else // if the entry is not present, then it definitely should be replaced
		{
			return true;
		}
	}

	// TODO (stouff) set up LayerCache to avoid duplicating tessellation work if all we need to do is restyle an entry
	void LayerCache::insert(EntryKey const& key, LayerCache::task_ptr_t task)
	{
		// touch existing or insert a new entry
		(mLRU.contains(key)) ? mLRU.touch(key) : mLRU.insert(key, Entry{ mFrameTimeMS });

		if (replaces(key, task->getMetadata()))		// test if the task replaces the existing prepared entry
		{
#if MAP3D_THREADS_ENABLED
			if (addTask(key, std::move(task)))
			{
				mTaskReadyCond.notify_one();
			}
#else
			addTask(key, std::move(task));
#endif
		}
		else				// the exisiting prepared data is up to date. if there is a pending task, remove it
		{
			purgeTask(key, true);
		}
	}

	void LayerCache::touch(EntryKey const& key)
	{
		// touch the key in the LRU
		mLRU.touch(key);
		mLRU.at(key).touchTimeMS = mFrameTimeMS;

		// if there is a pending task, touch it as long as it has not been touched this frame. if it has been
		// touched this frame, touching it again will actually move it further from the front of the queue
		LOCK(mMutex);
		auto iter = mPendingTasks.find(key);
		if (iter != mPendingTasks.end() && iter->entry.touchTimeMS < mFrameTimeMS)
		{
			mPendingTasks.splice(mInsertionPoint, iter);
			iter->entry.touchTimeMS = mFrameTimeMS;
		}
	}

	void LayerCache::purge(EntryKey const& key, bool immediate)
	{
		if (mLRU.contains(key))
		{
			Entry const& entry = mLRU.at(key);
			if (immediate)				// if we should immediately purge, just erase the item from LRU
			{
				mSize -= entry.size();
				mCounts -= entry.counts();
				mLRU.erase(key);
			}
			else if (entry.prepared)	// otherwise, just mark entry so the next insert will replace it
			{
				entry.prepared->markStale();
			}
		
			// purge tasks appropriately
			purgeTask(key, immediate);
		}
	}

	void LayerCache::purge(Tiles::TileId const& tileId, bool immediate)
	{
		std::vector<EntryKey> toPurge;
		for (auto const& [key, entry] : mLRU)
		{
			if (key.tileId == tileId)
			{
				toPurge.push_back(key);
			}
		}

		for (EntryKey const& key : toPurge)
		{
			purge(key, immediate);
		}
	}

	void LayerCache::purge(std::string const& layerId, bool immediate)
	{
		std::vector<EntryKey> toPurge;
		for (auto const& [key, entry] : mLRU)
		{
			if (key.layerId == layerId)
			{
				toPurge.push_back(key);
			}
		}

		for (EntryKey const& key : toPurge)
		{
			purge(key, immediate);
		}
	}

	void LayerCache::trimTo(size_t byteThreshold)
	{
		if (mLRU.empty())
			return;

		auto back = mLRU.end();

		size_t trimmedSize = mSize;
		std::vector<EntryKey> toPurge;
		while (trimmedSize > byteThreshold && back != mLRU.begin())
		{
			auto& pair = *(--back);
			toPurge.push_back(pair.key);
			trimmedSize -= pair.entry.size();
		}

		for (auto const& key : toPurge)
		{
			purge(key);
		}

		MAP3D_DEBUG_ASSERT(trimmedSize == mSize, "actual size and computed size do not match");
	}

	void LayerCache::trimOff(size_t byteThreshold)
	{
		if (byteThreshold > mSize)
		{
			trimTo(0);
		}
		else
		{
			trimTo(mSize - byteThreshold);
		}
	}

	void LayerCache::replace(EntryKey const& key, std::shared_ptr<PreparedData> const& prepared)
	{
		Entry& entry = mLRU.at(key);
		MAP3D_ASSERT(entry.size() <= mSize, "entry size is larger than cache size");

		mSize -= entry.size();
		mCounts -= entry.counts();
		entry.prepared = prepared;
		mSize += entry.size();
		mCounts += entry.counts();
	}

	void LayerCache::trimTo(Maximums const& maximums)
	{
		trimVertexBuffersTo(maximums.vertexBuffers);
		trimDynamicVertexBuffersTo(maximums.dynamicVertexBuffers);
		trimDynamicIndexBuffersTo(maximums.dynamicIndexBuffers);
	}

	void LayerCache::trimVertexBuffersTo(size_t limit)
	{
		if (mLRU.empty())
			return;

		auto back = mLRU.end();

		size_t count = mCounts.vertexBuffers;
		std::vector<EntryKey> toPurge;
		while (count > limit && back != mLRU.begin())
		{
			auto& pair = *(--back);
			if (pair.entry.counts().vertexBuffers > 0)
			{
				toPurge.push_back(pair.key);
				--count;
			}
		}

		for (auto const& key : toPurge)
		{
			purge(key);
		}

		MAP3D_DEBUG_ASSERT(count == mCounts.vertexBuffers, "actual vertex buffer count and computed vertex buffer count do not match");
	}

	void LayerCache::trimDynamicVertexBuffersTo(size_t limit)
	{
		if (mLRU.empty())
			return;

		auto back = mLRU.end();

		size_t count = mCounts.dynamicVertexBuffers;
		std::vector<EntryKey> toPurge;
		while (count > limit && back != mLRU.begin())
		{
			auto& pair = *(--back);
			if (pair.entry.counts().dynamicVertexBuffers > 0)
			{
				toPurge.push_back(pair.key);
				--count;
			}
		}

		for (auto const& key : toPurge)
		{
			purge(key);
		}

		MAP3D_DEBUG_ASSERT(count == mCounts.dynamicVertexBuffers, "actual dynamic vertex buffer count and computed dynamic vertex buffer count do not match");
	}

	void LayerCache::trimDynamicIndexBuffersTo(size_t limit)
	{
		if (mLRU.empty())
			return;

		auto back = mLRU.end();

		size_t count = mCounts.dynamicIndexBuffers;
		std::vector<EntryKey> toPurge;
		while (count > limit && back != mLRU.begin())
		{
			auto& pair = *(--back);
			if (pair.entry.counts().dynamicIndexBuffers > 0)
			{
				toPurge.push_back(pair.key);
				--count;
			}
		}

		for (auto const& key : toPurge)
		{
			purge(key);
		}

		MAP3D_DEBUG_ASSERT(count == mCounts.dynamicIndexBuffers, "actual dynamic index buffer count and computed dynamic index buffer count do not match");
	}

	bool LayerCache::addTask(EntryKey const& key, task_ptr_t task)
	{
		PreparedData::Metadata const& metadata = task->getMetadata();

		LOCK(mMutex);

		// perform necessary finds
		auto pendingIter = mPendingTasks.find(key);
#if MAP3D_THREADS_ENABLED
		auto completedIter = mCompleted.find(key);
#endif

		if (pendingIter != mPendingTasks.end())	// check if there is a pending task
		{
			// check if the inserted task should replace the pending task
			task_ptr_t const& existing = pendingIter->entry.task;
			if (metadata.replaces(existing->getMetadata()))
			{
				auto iter = mPendingTasks.replace(key, PendingT{ std::move(task), mFrameTimeMS });
				mPendingTasks.splice(mInsertionPoint, iter);
			}
		}
#if MAP3D_THREADS_ENABLED
		else if (mActiveTask.key == key)	// if there is no pending task for the key, check the active task
		{
			// if the task to insert replaces the active task, add it to the pending tasks
			if (metadata.replaces(mActiveTask.metadata))
			{
				mPendingTasks.insert(mInsertionPoint, key, PendingT{ std::move(task), mFrameTimeMS });
				return true;
			}
		}
		else if (completedIter != mCompleted.end())		// if the key is not pending or being actively worked on, check whether it is completed
		{
			// check if the inserted task should replace the completed task
			std::shared_ptr<PreparedData> const& prepared = completedIter->second;
			if (metadata.replaces(prepared->metadata()))
			{
				mPendingTasks.insert(mInsertionPoint, key, PendingT{ std::move(task), mFrameTimeMS });
				return true;
			}
		}
#endif
		else // key is not pending, active, or completed. add to pending
		{
			mPendingTasks.insert(mInsertionPoint, key, PendingT{ std::move(task), mFrameTimeMS });
			return true;
		}

		// default to returning false (we did not add the task)
		return false;
	}

	void LayerCache::purgeTask(EntryKey const& key, bool immediate)
	{
		LOCK(mMutex);
		if (immediate)
		{
			auto iter = mPendingTasks.find(key);
			if (iter != mPendingTasks.end())	// skip this step if there is no pending task for this key
			{
				if (iter == mInsertionPoint)		// if necessary, update our insertion point
				{
					++mInsertionPoint;
				}
			}

			mPendingTasks.erase(key);		// erase from pending tasks
#if MAP3D_THREADS_ENABLED
			if (mActiveTask.key == key)		// tell the prepare thread to purge when it completes
			{
				mActiveTask.purge = true;
			}
			mCompleted.erase(key);			// erase from completed
#endif
		}
		else
		{
			// mark pending task as stale
			{
				auto iter = mPendingTasks.find(key);
				if (iter != mPendingTasks.end())
				{
					iter->entry.task->markStale();
				}
			}
#if MAP3D_THREADS_ENABLED
			// if the key matches, mark active task as stale
			if (mActiveTask.key == key)
			{
				mActiveTask.metadata.stale = true;
			}
			// mark completed task as stale
			{
				auto iter = mCompleted.find(key);
				if (iter != mCompleted.end())
				{
					iter->second->markStale();
				}
			}
#endif
		}
	}

	void LayerCache::trimStaleTasks()
	{
		LOCK(mMutex);

		// check the back of the queue to delete any stale tasks
		bool trim = true;
		while (trim && !mPendingTasks.empty())
		{
			// iterator pointing to the final pending element
			auto iter = --mPendingTasks.end();
			if (mFrameTimeMS - iter->entry.touchTimeMS > mTaskTimeoutMS)		// check if task is stale
			{
				if (iter == mInsertionPoint)	// if necessary, update the insert point
				{
					mInsertionPoint = mPendingTasks.end();
				}
				mPendingTasks.erase(iter);
			}
			else
			{
				trim = false;
			}
		}
	}

	std::shared_ptr<PreparedData> LayerCache::prepare(LayerCache::task_ptr_t& task)
	{
		LUCID_PROFILE_SCOPE("preparing layer");

		PrepareTask::Styles styles{ mLineStyles, mFillStyles };
		std::shared_ptr<PreparedData> prepared = task->prepare(styles);

		if (prepared)
		{
			prepared->snapshotProfile();
		}
		return prepared;
	}

} }
