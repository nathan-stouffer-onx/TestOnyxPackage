#ifndef __FLY_TO_CONTROLLER_H__
#define __FLY_TO_CONTROLLER_H__

#include "Animator.h"
#include "Config/ConfigManager.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that will fly the camera from a begin state to an end state.
	// the flight path is defined by a cubic bezier function. the begin and end states
	// provide the 0 and 3 anchor points (respectively). and the middle two anchor
	// points are computed internally based off the begin/end states
	DECLARECONFIGVALSTATIC(world_float_t, cDefaultDurationMS, "Camera:Controller:Animator:cDefaultDurationMS")

	class FlyTo : public Animator
	{
	public:

		FlyTo(CameraState const& begin, CameraState const& end,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS());

		FlyTo(CameraState const& begin, lgal::world::Vector3 const& lookPt, MapMath::Spherical const& spherical,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS());

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "FlyTo"; }

		std::vector<CameraState> highlights() const override { return std::vector<CameraState>{ mCubicBezierAnchor3 }; }

	protected:

		// CameraState anchors for the cubic bezier calculation
		// NOTE: anchor points 0 and 3 are the begin/end state respectively
		CameraState mCubicBezierAnchor0;
		CameraState mCubicBezierAnchor1;
		CameraState mCubicBezierAnchor2;
		CameraState mCubicBezierAnchor3;

		Camera_time_t const mDurationMS;

		void computeAnchors(CameraState const& begin, CameraState const& end);

	};

} } }

#endif
