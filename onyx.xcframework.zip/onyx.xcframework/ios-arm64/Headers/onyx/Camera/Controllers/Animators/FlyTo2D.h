#ifndef __FLY_TO_2D_CONTROLLER_H__
#define __FLY_TO_2D_CONTROLLER_H__

#include "FlyTo.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	class FlyTo2D : public FlyTo
	{
	public:

		FlyTo2D(CameraState const& begin, lgal::world::Vector2 const& lookPt, MapMath::Spherical const& spherical,
			Camera_time_t const durationMS = cDefaultDurationMS, Camera_time_t const beginMS = Utils::Timer::nowMS());

		CameraState animationUpdate(Camera_time_t relativeTimeMS, Atlases::HeightAtlas const* atlas) override;

		std::string getName() const override { return "FlyTo2D"; }

	private:

		lgal::world::Vector2 const mLookPoint;
		MapMath::Spherical const mSpherical;

	};

} } }

#endif