#ifndef __IDENTITY_CONTROLLER_H__
#define __IDENTITY_CONTROLLER_H__

#include "Camera/CameraController.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that does not change anything about the current state; the identity map
	// NOTE: the CameraController base class may still change the camera state if the state is invalid

	class Identity : public CameraController
	{
	public:

		Identity() {}

		std::string getName() const override { return "Identity"; }

	private:

		CameraState derivedUpdate(ControllerOptions const& options) override
		{
			return options.previousState;
		}

	};

} } }

#endif