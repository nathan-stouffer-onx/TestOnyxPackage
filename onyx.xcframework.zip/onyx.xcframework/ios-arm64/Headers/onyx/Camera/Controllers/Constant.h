#ifndef __CONSTANT_CONTROLLER_H__
#define __CONSTANT_CONTROLLER_H__

#include "Camera/CameraController.h"

namespace onyx {
namespace Camera {
namespace Controllers {

	// camera controller that always returns the state it is constructed with; a constant map
	// NOTE: the CameraController base class may still change the camera state if mState is invalid

	class Constant : public CameraController
	{
	public:

		Constant(CameraState const& state) : mState(state) {}

		std::string getName() const override { return "Constant"; }

	private:

		CameraState derivedUpdate(ControllerOptions const& /* options */) override
		{
			return mState;
		}

		CameraState mState;

	};

} } }

#endif