#include "TimeTransform.h"

#include <System/Map3DException.h>

namespace onyx {
namespace Camera {
namespace TimeTransform {

	world_float_t evaluate(Type const type, world_float_t const t)
	{
		world_float_t clampedT = std::clamp(t, 0.0, 1.0);
		switch (type)
		{
			case Type::LINEAR:             return clampedT;                                    break;
			case Type::SMOOTHSTEP:         return lmath::smoothstep(0.0, 1.0, clampedT);       break;
			case Type::QUADRATIC_EASE_OUT: return 1.0 - std::pow(clampedT - 1.0, 2.0);         break;
			default: MAP3D_THROW("invalid enum value for Camera::TimeTransform::Type")         break;
		}
	}

} } }