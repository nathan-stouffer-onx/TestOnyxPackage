#pragma once

// TODO see if we can delete this
// TODO: Monitor https://github.com/bkaradzic/bgfx/issues/3024 for when this is fixed
// so we don't have to have two samplers for the same texture
enum class TextureType
{
	Basemap,
	Basemap2,
	//Height,
	HeightVert,	// This is being used for the TileLayerData ID
	HeightFrag,
	Weather,
	Roads,
	LocalData,
	Count
};

struct JulianDate
{
	int year = 2010;
	int month = 0;
	int day = 0;
	float timezone = 0.0;
	float hours24 = 0.0; //0-24

	double getJulianCentury()
	{
		int years = year - 1900;
		int leapYears = years / 4;
		int days = years * 365 + leapYears;
		int monthDays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		for (int i = 0; i < month - 1; i++)
			days += monthDays[i];
		if (year % 4 == 0 && days >= 59)
			days++; //add this years leap day
		days += day + 2; //why plus 2? not sure, but it fixed the math, I somehow lost two days...
		double julianDays = days + 2415018.5f;
		julianDays += hours24 / 24.0f;
		julianDays += timezone / 24.0f;

		return (julianDays - 2451545) / 36525;
	}

	float getTimezoneTime()
	{
		return hours24 + timezone;
	}

	bool operator==(const JulianDate& jd)
	{
		return hours24 == jd.hours24 && year == jd.year && month == jd.month && day == jd.day && timezone == jd.timezone;
	}

	bool operator!=(const JulianDate& jd)
	{
		return !(*this == jd);
	}
};