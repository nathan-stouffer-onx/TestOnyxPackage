#pragma once

#include <vector>
#include <unordered_map>
#include <algorithm>
#include <queue>

#include <lucid/math/Vector.h>
#include <lucid/math/AABB.h>

namespace onyx {
namespace util {

namespace quadtree
	{
	constexpr auto TOP_NODE = 1;

	typedef uint64_t code_t;

	constexpr code_t MAX_CODE = 0xFFFFFFFFFFFFFFFF;
	constexpr code_t ROOT_CODE = 0x1;

	template <typename PrecisionT, class StorageT>
	class QuadTree
		{
		public:
		
			static constexpr PrecisionT MIN_LEAF_SIZE = 1.f / PrecisionT(2 << 20);

			typedef lucid::math::AABB<PrecisionT, 2> AABB;

		// 00       |        01
		//          |
		//          |
		//          |
		// --------------------
		//          |
		//          |
		//          |
		// 10       |        11

			enum Intersections
				{
				NONE = 0,
				PARTIAL = 1,
				FULL = 2
				};
			class Node
				{
				private:
					AABB _looseBounds;
					AABB _bounds;
				public:
					mutable std::vector<StorageT> items;

					Node(AABB bounds) : _bounds(bounds)
						{
						PrecisionT size = std::max(bounds.max.x - bounds.min.x, bounds.max.y - bounds.min.y) * 0.5f;
						_looseBounds = AABB(lucid::math::Vector<PrecisionT, 2>(bounds.min.x - size, bounds.min.y - size),
							lucid::math::Vector<PrecisionT, 2>(bounds.max.x + size, bounds.max.y + size));
						}
					Node() : _bounds(AABB(lucid::math::Vector<PrecisionT, 2>(10, 10), lucid::math::Vector<PrecisionT, 2>(-10, -10))) { }

					__inline AABB const &looseBounds() const { return _looseBounds; }
					__inline AABB const &bounds() const { return _bounds; }
				};

		protected:
			uint32_t _maxDepth;
			std::unordered_map<code_t, Node> _nodes;
			std::unordered_map<StorageT, code_t> _items;
			PrecisionT _looseSize;
			lucid::math::Vector<PrecisionT, 2> _center;
			AABB _extents;

			__inline Node const *node(code_t node) const
				{
				auto iter = _nodes.find(node);
				if (iter == _nodes.end())
					return nullptr;

				return &iter->second;
				}
		private:
			code_t insert(StorageT item, AABB position, code_t nodeId);
			
		public:
			QuadTree(AABB extents, uint32_t maxDepth = 8);
			QuadTree() {};

			void setExtents(AABB const &extents);
			AABB const &extents() const { return _extents; }

			size_t size() const { return _items.size(); }

			code_t insert(StorageT item, AABB position);
			code_t move(StorageT item, AABB position);
			code_t remove(StorageT item);
			~QuadTree();

			template <class Intersector>
			class nodeIterator
				{
				protected:
					typedef nodeIterator<Intersector> self_type;
					typedef StorageT value_type;
					typedef StorageT& reference;
					typedef StorageT* pointer;

				public:
					virtual ~nodeIterator() { };

					reference const operator *() const
						{
						return _nodeList->items.at(_currentItem);
						}

					pointer const operator->() const
						{
						return &_nodeList->items.at(_currentItem);
						}

					bool operator==(const self_type& rhs) const { return _currentNode == rhs._currentNode && _currentItem == rhs._currentItem; }
					bool operator!=(const self_type& rhs) const { return _currentNode != rhs._currentNode || _currentItem != rhs._currentItem; }

					template <class otherIntersector>
					bool operator==(const nodeIterator<otherIntersector>& rhs) const { return _currentNode == rhs.currentNode() && _currentItem == rhs.currentItem(); }

					template <class otherIntersector>
					bool operator!=(const nodeIterator <otherIntersector>& rhs) const { return _currentNode != rhs.currentNode() || _currentItem != rhs.currentItem(); }

					__inline nodeIterator operator++() //prefix increment
						{
						if (_currentNode)
							moveNext();
	
						return *this;
						}

					__inline nodeIterator operator++(int junk) { // postfix increment
						return ++(*this);
						}

					__inline code_t currentNode() const { return _currentNode; }
					__inline size_t currentItem() const { return _currentItem; }

				protected:
					typename QuadTree<PrecisionT, StorageT> const *_source;
					code_t	_currentNode,
						_beginNode;
					size_t	_maxItem = size_t(-1);
					code_t	_currentSubNode = 0,
						_nodeInBounds = 0;
					size_t	_currentItem = 0;
					Node const	*_nodeList = nullptr;
					Intersector	_shape;
					bool _isFind;
				private:
					__inline void moveUp()
					{
						do
						{
							_currentNode >>= 2;
						} while ((_currentNode & 0x3) == 0x3); // walk back up the tree until we find a node with more subnodes to search

						if (_currentNode <= _nodeInBounds)
							_nodeInBounds = 0;

						_currentSubNode = (_currentNode & 0x3) + 1;
						_currentNode = _currentNode & ~(code_t)0x3;
					}

					void moveNextFind()
					{
						while (_currentNode != 0)
						{
							if (_maxItem == -1) // We don't have an item list yet
							{
								auto nextNode = _source->node(_currentNode | _currentSubNode);
								if (nextNode == nullptr) // This node has no subnodes and it is empty
								{
									if (_currentSubNode < 0x3)
										++_currentSubNode;
									else
										moveUp();

									continue;
								}

								if (_nodeInBounds == 0) // We need to check for intersection
								{
									auto looseBounds = nextNode->looseBounds();
									auto intersection = _shape.intersects(looseBounds); // looseBounds.intersects<Intersector>(_shape);
									if (intersection == Intersections::NONE)
									{
										if (_currentSubNode < 0x3)
											++_currentSubNode;
										else
											moveUp();

										continue;
									}
									if (intersection == Intersections::FULL)
									{
										_nodeInBounds = _currentNode | _currentSubNode;
									}
								}

								auto nextSize = nextNode->items.size();

								if (nextSize == 0) // This node has subnodes, but it itself is empty
								{
									_currentNode |= _currentSubNode;
									_currentNode <<= 2;
									_currentSubNode = 0;
									continue;
								}
								else
								{
									_nodeList = nextNode;
									_maxItem = nextSize - 1;
									_currentItem = 0;
									return;
								}
							}
							else
							{
								if (_currentItem < _maxItem)
									++_currentItem;
								else // we've reached the end of the list for this node
								{
									_maxItem = size_t(-1);
									_currentNode |= _currentSubNode;
									_currentNode <<= 2;
									if (_currentNode == _beginNode)
										return;

									_currentSubNode = 0;
									_currentItem = 0;
									moveNextFind();
								}
								return;
							}
						}
					}

					void moveNext()
						{

						if (_isFind)
						{
							moveNextFind();
							return;
						}

						while (_currentNode != 0)
							{
							if (_maxItem == -1) // We don't have an item list yet
								{
								auto nextNode = _source->node(_currentNode | _currentSubNode);
								if (nextNode == nullptr) // This node has no subnodes and it is empty
									{
									if (_currentSubNode < 0x3)
										++_currentSubNode;
									else
										{
										do
											{
											_currentNode >>= 2;
											}
										while ((_currentNode & 0x3) == 0x3); // walk back up the tree until we find a node with more subnodes to search
										_currentSubNode = (_currentNode & 0x3) + 1;
										_currentNode = _currentNode & ~(code_t)0x3;
										}
									continue;
									}

								auto nextSize = nextNode->items.size();

								if (nextSize == 0) // This node has subnodes, but it itself is empty
									{
									_currentNode |= _currentSubNode;
									_currentNode <<= 2;
									_currentSubNode = 0;
									continue;
									}
								else
									{
									_nodeList = nextNode;
									_maxItem = nextSize - 1;
									_currentItem = 0;
									return;
									}
								}
							else
								{
								if (_currentItem < _maxItem)
									++_currentItem;
								else // we've reached the end of the list for this node
									{
									_maxItem = size_t(-1);
									_currentNode |= _currentSubNode;
									_currentNode <<= 2;
									if (_currentNode == _beginNode)
										return;

									_currentSubNode = 0;
									_currentItem = 0;
									moveNext();
									}
								return;
								}
							}
						}

				public:

					typedef std::forward_iterator_tag iterator_category;
					typedef int difference_type;


					nodeIterator(code_t begin, QuadTree<PrecisionT, StorageT> const* source)
						: _beginNode(begin)
						, _currentNode(begin)
						, _source(source)
						, _isFind(false)
					{
						if (!_currentNode)
							return;

						moveNext();
					}

					nodeIterator(code_t begin, Intersector const &shape, QuadTree<PrecisionT, StorageT> const* source)
						: _beginNode(begin)
						, _currentNode(begin)
						, _source(source)
						, _isFind(true)
						, _shape(shape)
					{
						if (!_currentNode)
							return;
						moveNextFind();
					}

				};

			template <typename Intersector>
			void remove(nodeIterator<Intersector> &nodes)
			{
				std::queue<StorageT> q;

				for (; nodes != end(); ++nodes)
					q.push(*nodes);

				while (!q.empty())
				{
					remove(q.front());
					q.pop();
				}
			}

			template <typename Intersector>
			nodeIterator<Intersector> find(const Intersector &shape) const
				{
				return nodeIterator<Intersector>(1, shape, this);
				}

			nodeIterator<AABB> begin()
				{
				return nodeIterator<AABB>(1, this);
				}

			nodeIterator<AABB> end()
				{
				return nodeIterator<AABB>(0, this);
				}
		};


	template <typename PrecisionT, class StorageT>
	QuadTree<PrecisionT, StorageT>::QuadTree(AABB extents, uint32_t maxDepth)
		: _maxDepth(maxDepth)
		{
		setExtents(extents);
		}

	template <typename PrecisionT, class StorageT>
	void QuadTree<PrecisionT, StorageT>::setExtents(AABB const &extents)
		{
		_looseSize = std::max(extents.max.x - extents.min.x, extents.max.y - extents.min.y);
		_center = extents.center();
		_extents = AABB(lucid::math::Vector<PrecisionT, 2>(_center.x - _looseSize * 0.5f, _center.y - _looseSize * 0.5f),
						lucid::math::Vector<PrecisionT, 2>(_center.x + _looseSize * 0.5f, _center.y + _looseSize * 0.5f));
		_nodes.clear();
		_nodes[ROOT_CODE] = Node(_extents);
		}

	template <typename PrecisionT, class StorageT>
	QuadTree<PrecisionT, StorageT>::~QuadTree<PrecisionT, StorageT>()
		{
		}

	template <typename PrecisionT, class StorageT>
	code_t QuadTree<PrecisionT, StorageT>::remove(StorageT item)
		{
		auto iter = _items.find(item);
		if (iter == _items.end())
			return 0;

		code_t nodeId = iter->second;

		auto nodeIter = _nodes.find(nodeId);

		if (nodeIter == _nodes.end())
			return 0;

		Node &node = nodeIter->second;
		node.items.erase(std::remove(node.items.begin(), node.items.end(), item), node.items.end());

		_items.erase(iter);

		return nodeId;
		}


	template <typename PrecisionT, class StorageT>
	code_t QuadTree<PrecisionT, StorageT>::move(StorageT item, AABB position)
		{
		auto iter = _items.find(item);
		if (iter == _items.end())
			return insert(item, position, ROOT_CODE);

		code_t nodeId = iter->second;

		auto nodeIter = _nodes.find(nodeId);

		if (nodeIter == _nodes.end())
			{
			_items.erase(iter);
			return insert(item, position, ROOT_CODE);
			}

		Node &node = nodeIter->second;
		
		PrecisionT itemSize = std::max(MIN_LEAF_SIZE, std::max(position.max[0] - position.min[0], position.max[1] - position.min[1]));
		PrecisionT looseSize = (node.bounds().max.x - node.bounds().min.x);

		lucid::math::Vector<PrecisionT, 2> nodeCenter = node.bounds().center(),
			itemCenter((position.min + position.max) * lucid::math::constants::half<PrecisionT>());

		if (itemSize > looseSize
			|| itemSize < looseSize * 0.5f
			|| !lucid::math::contains(node.bounds(), position.center()))
			{
			node.items.erase(std::remove(node.items.begin(), node.items.end(), item), node.items.end());
			_items.erase(iter);
			return insert(item, position, ROOT_CODE);
			}

		// It didn't move out of the node that it was previously in, so just return
		return nodeId;
		}

	template <typename PrecisionT, class StorageT>
	code_t QuadTree<PrecisionT, StorageT>::insert(StorageT item, AABB position)
		{
		return insert(item, position, ROOT_CODE);
		}

	template <typename PrecisionT, class StorageT>
	code_t QuadTree<PrecisionT, StorageT>::insert(StorageT item, AABB position, code_t nodeId)
		{
		if (position.max[0] < _extents.min[0]
			|| position.max[1] < _extents.min[1]
			|| position.min[0] > _extents.max[0]
			|| position.min[1] > _extents.max[1]
			)
			return 0;

		auto nodeIter = _nodes.find(nodeId);
		if (nodeIter == _nodes.end())
			return insert(item, position, ROOT_CODE);

		uint8_t depth = 0;
		while ((1ULL << (depth * 2)) < nodeId)
			++depth;

		Node const &node = nodeIter->second;

		PrecisionT itemSize = std::max(MIN_LEAF_SIZE, std::max(position.max[0] - position.min[0], position.max[1] - position.min[1]));

		PrecisionT looseSize = (node.bounds().max.x - node.bounds().min.x) * lucid::math::constants::half<PrecisionT>();

		lucid::math::Vector<PrecisionT, 2> nodeCenter = _center,
			itemCenter((position.min + position.max) * lucid::math::constants::half<PrecisionT>());
		while (itemSize < looseSize && depth < _maxDepth)
			{
			++depth;
			looseSize *= 0.5f;
			code_t nextCode;

			if (nodeCenter.x >= itemCenter.x)
				{
				nodeCenter.x -= looseSize;
				nextCode = 0;
				}
			else
				{
				nodeCenter.x += looseSize;
				nextCode = 0x2;
				}

			if (nodeCenter.y >= itemCenter.y)
				{
				nodeCenter.y -= looseSize;
				}
			else
				{
				nodeCenter.y += looseSize;
				nextCode |= 1;
				}

			nodeId <<= 2;
			nodeId |= nextCode;
			auto iter = _nodes.find(nodeId);
			if (iter == _nodes.end())
				_nodes[nodeId] = Node(AABB(lucid::math::Vector<PrecisionT, 2>(nodeCenter.x - looseSize, nodeCenter.y - looseSize),
					lucid::math::Vector<PrecisionT, 2>(nodeCenter.x + looseSize, nodeCenter.y + looseSize)));
			}

		_nodes.at(nodeId).items.push_back(item);
		_items[item] = nodeId;
		return nodeId;
		}
	}
} }