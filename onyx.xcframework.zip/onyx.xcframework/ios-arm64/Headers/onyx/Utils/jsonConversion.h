#pragma once

#include <json/jsonParsing.h>

#include "Viewport/ViewportState.h"
#include "DataObjects/Waypoint.h"
#include "DataObjects/WaypointManager.h"
#include "Demo/DemoStep.h"
#include "Utils/BgfxUtils.h"
#include "Utils/EnumsStructs.h"
#include "Utils/MapMath.h"

void to_json(nlohmann::json& j, const DemoStep& step);
void from_json(const nlohmann::json& j, DemoStep& step);
void to_json(nlohmann::json& j, const WaypointManager::sharedWaypoint_t& wp);
void from_json(const nlohmann::json& j, WaypointManager::sharedWaypoint_t& wp);

void to_json(nlohmann::json& j, const JulianDate& step);
void from_json(const nlohmann::json& j, JulianDate& step);

inline void to_json(nlohmann::json& j, const WaypointManager* mngr)
{
	j = mngr->getJson();
}

template <typename T>
inline void to_json(nlohmann::json& j, const onyx::Atlases::Atlas<T>* atlas)
{
	j = atlas->getJson();
}

namespace onyx {

	void from_json(const nlohmann::json& j, ViewportState& vp);
	void to_json(nlohmann::json& j, const ViewportState& vp);

void from_json(const nlohmann::json& j, ConfigManager& cm);
void to_json(nlohmann::json& j, ConfigManager& cm);

void from_json(const nlohmann::json& j, ConfigHolder& ch);
void from_json(const nlohmann::json& j, ConfigHolder* ch);
void to_json(nlohmann::json& j, const ConfigHolder& ch);
void to_json(nlohmann::json& j, ConfigHolder* ch);
}