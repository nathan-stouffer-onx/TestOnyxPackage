#ifndef TILE_RENDER_INFO_H
#define TILE_RENDER_INFO_H

#include <bgfx/bgfx.h>

#include <Logging/LogManager.h>
#include <lucid/gal/Types.h>

#include "TileId.h"
#include "Utils/MapMath.h"
#include "Utils/Timer.h"

namespace onyx {
namespace Tiles {

	struct TileTextureAtlasInfo
	{
		bgfx::TextureHandle handle = { bgfx::kInvalidHandle };
		uint32_t resolution = 0;
		lgal::gpu::Vector4 offset;
		TileId::IdCoordsT level = 0;
		TileTextureAtlasInfo() : offset({ 0, 0, 0, 0 }) {}
		TileTextureAtlasInfo(bgfx::TextureHandle const& handle, uint32_t resolution, lgal::gpu::Vector4 const &offset, TileId::IdCoordsT level)
			: handle(handle)
			, resolution(resolution)
			, offset(offset)
			, level(level)
		{}
		
		static inline TileTextureAtlasInfo invalid() { return { BGFX_INVALID_HANDLE, 0, {0, 0, 0, 0}, -1 }; }

		inline bool isValid() const { return bgfx::isValid(handle); }

	};

	struct TileInfo
	{
		TileId id;

		lgal::world::Vector3 sunMin,
			sunMax,
			tileMax,
			tileMin,
			tileSize;

		lgal::world::Vector2 distortion;

		TileTextureAtlasInfo heightAtlasInfo;

		lgal::Color color = lgal::Color(0.f, 0, 0, 0);

		bool isReady = false;

		TileInfo(TileId const &id) : id(id)
		{
			world_float_t halfGlobe = Tiles::cMaxExtent * 0.5;
			world_float_t size = id.extent();

			tileSize = { size, size, 1. };
			tileMin = { id.northwestCorner(), 0. };
			tileMax = { id.southeastCorner(), 1. };
			sunMin = { (tileMin.x + halfGlobe) / Tiles::cMaxExtent, (tileMin.y + halfGlobe) / Tiles::cMaxExtent, 0.0 };
			sunMax = { (tileMin.x + size + halfGlobe) / Tiles::cMaxExtent, (tileMin.y + size + halfGlobe) / Tiles::cMaxExtent, 0.0 };
			distortion = { MapMath::mercatorDistortion(tileMin.xy), MapMath::mercatorDistortion(tileMax.xy) };
		}

	};

	struct TileVectorInfo final : public TileInfo
	{
		constexpr static Utils::Timer::Map3D_time_t DefaultFadeTime = 500.0; // Milliseconds

		// TODO (stouff) probably move to TileInfo?
		uint16_t meshResolution;

		Utils::Timer::Map3D_time_t addTimestamp;
		Utils::Timer::Map3D_time_t useTimestamp;

		bool childIsLoading = true;

		inline void touch(Utils::Timer::Map3D_time_t now)
		{
			useTimestamp = now;
		}

		TileVectorInfo(TileId const &id, Utils::Timer::Map3D_time_t timestamp) :
			TileInfo(id),
			addTimestamp(timestamp),
			useTimestamp(timestamp)
		{}
	};

	struct TileTextureInfo final : public TileInfo
	{
		static constexpr size_t MAX_TEXTURE_LAYERS = 3;

		TileTextureAtlasInfo basemap,
								layers[MAX_TEXTURE_LAYERS];

		int layerCount = 0;

		bool isComplete = false;

		Utils::Timer::Map3D_time_t fadeTimer = 0;

		TileTextureInfo(TileId const &id) : TileInfo(id) {}
	};

} }

#endif