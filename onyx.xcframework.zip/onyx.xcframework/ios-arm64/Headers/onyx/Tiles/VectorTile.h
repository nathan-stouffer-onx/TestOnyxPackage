#ifndef __VECTOR_TILE_H__
#define __VECTOR_TILE_H__

#include <vector>
#include <string>

#include <Logging/LogManager.h>
#include <Warnings.h>

#include "Tiles/TileId.h"
#include "Vector/Layer.h"

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

namespace onyx {
namespace Tiles {

	class VectorTile
	{
	public:
	
		using LayerMapT = std::unordered_map<std::string, std::shared_ptr<Vector::Layer const>>;

		VectorTile(Tiles::TileId const& tileId, std::shared_ptr<std::vector<uint8_t>> const& data, time_float_t timestampMS);
		VectorTile(Tiles::TileId const& tileId, vector_tile::Tile const& protobuf, time_float_t timestampMS);
		VectorTile(Tiles::TileId const& tileId, std::shared_ptr<Vector::Layer> layer);
		VectorTile(Tiles::TileId const& tileId, std::vector<std::shared_ptr<Vector::Layer>> layers);
		~VectorTile() = default;

		inline TileId id() const { return mTileId; }

		inline size_t byteCount() const { return mByteCount; }
		inline bool contains(std::string const& layer) const { return mLayers.find(layer) != mLayers.end(); }
		
		/*
		* if layer is present     => returns timestampMS for the layer
		* if layer is not present => returns timestampMS for the tile
		*/ 
		inline time_float_t timestampMS(std::string const& layer) const
		{
			auto it = mLayers.find(layer);
			return (it != mLayers.end()) ? it->second->timestampMS() : mTimestampMS;
		}

		inline std::shared_ptr<Vector::Layer const> at(std::string const& layer) const { return mLayers.at(layer); }

		LayerMapT::const_iterator begin() const { return mLayers.begin(); }
		LayerMapT::const_iterator end()   const { return mLayers.end();   }

	public:

		static vector_tile::Tile Parse(std::shared_ptr<std::vector<uint8_t>> const& data);
		static std::vector<std::shared_ptr<Vector::Layer>> Decode(vector_tile::Tile const& protobuf, time_float_t timestampMS);

	private:

		static time_float_t MaxTimestamp(std::vector<std::shared_ptr<Vector::Layer>> const& layers);

	private:

		TileId mTileId;

		LayerMapT mLayers;

		time_float_t const mTimestampMS;

		size_t const mByteCount = 0;
	
	};

} }

#endif