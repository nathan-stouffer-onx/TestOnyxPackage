#include "VectorTile.h"

#include <lucid/Profiler.h>

#include <System/Map3DException.h>
#include <Utils/Memory.h>
#include <Warnings.h>

namespace onyx {
namespace Tiles {

	VectorTile::VectorTile(Tiles::TileId const& tileId, std::shared_ptr<std::vector<uint8_t>> const& data, time_float_t timestampMS) :
		VectorTile(tileId, VectorTile::Parse(data), timestampMS)
	{}

	VectorTile::VectorTile(Tiles::TileId const& tileId, vector_tile::Tile const& protobuf, time_float_t timestampMS) :
		VectorTile(tileId, VectorTile::Decode(protobuf, timestampMS))
	{}

	VectorTile::VectorTile(Tiles::TileId const& tileId, std::shared_ptr<Vector::Layer> layer) :
		VectorTile(tileId, std::vector<std::shared_ptr<Vector::Layer>>{ layer })
	{}

	VectorTile::VectorTile(Tiles::TileId const& tileId, std::vector<std::shared_ptr<Vector::Layer>> layers) :
		mTileId(tileId),
		mTimestampMS(VectorTile::MaxTimestamp(layers)),
		mByteCount(Utils::countBytes(layers))
	{
		for (std::shared_ptr<Vector::Layer> layer : layers)
		{
			mLayers.insert({ layer->name(), layer });
		}
	}

	vector_tile::Tile VectorTile::Parse(std::shared_ptr<std::vector<uint8_t>> const& data)
	{
		LUCID_PROFILE_SCOPE("Parse protobuf tile");
		vector_tile::Tile protobuf;
		MAP3D_ASSERT(data->size() < size_t(std::numeric_limits<int>::max()), "Protobuf tile data size is > 2GB");
		MAP3D_ASSERT(protobuf.ParseFromArray(data->data(), int(data->size())), "Could not parse protobuf data");
		return protobuf;
	}

	std::vector<std::shared_ptr<Vector::Layer>> VectorTile::Decode(vector_tile::Tile const& protobuf, time_float_t timestampMS)
	{
		LUCID_PROFILE_SCOPE("Decode protobuf tile");
		std::vector<std::shared_ptr<Vector::Layer>> layers;
		for (int i = 0; i < protobuf.layers_size(); ++i)
		{
			std::shared_ptr<Vector::Layer> layer = std::make_shared<Vector::Layer>(protobuf.layers(i), timestampMS);
			layers.push_back(layer);
		}
		return layers;
	}

	time_float_t VectorTile::MaxTimestamp(std::vector<std::shared_ptr<Vector::Layer>> const& layers)
	{
		time_float_t max = std::numeric_limits<time_float_t>::min();
		for (auto const& layer : layers)
		{
			max = std::max(max, layer->timestampMS());
		}
		return max;
	}


} }