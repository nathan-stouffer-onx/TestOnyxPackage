#include "TileId.h"

namespace onyx {
namespace Tiles {

	bool TileId::inBounds(lgal::world::Vector2 const& pos) const
	{
		auto min = northwestCorner();
		auto max = southeastCorner();

		// compute whether the point is strictly inside the tile
		bool inX = (min.x <= pos.x) && (pos.x <= max.x);
		bool inY = (min.y <= pos.y) && (pos.y <= max.y);

		return inX && inY;
	}

	lgal::world::Vector2 TileId::center() const
	{
		auto halfExtent = 0.5 * extent();
		return northwestCorner() + lgal::world::Vector2{ halfExtent, halfExtent };
	}
	lgal::world::Vector2 TileId::northwestCorner() const
	{
		auto ext = extent();
		auto X = -cMaxExtent / 2.0 + x * ext;
		auto Y = -cMaxExtent / 2.0 + y * ext;
		return { X, Y };
	}
	lgal::world::Vector2 TileId::northeastCorner() const
	{
		return northwestCorner() + lgal::world::Vector2{ extent(), 0.0 };
	}
	lgal::world::Vector2 TileId::southeastCorner() const
	{
		world_float_t ext = extent();
		return northwestCorner() + lgal::world::Vector2{ ext, ext };
	}
	lgal::world::Vector2 TileId::southwestCorner() const
	{
		return northwestCorner() + lgal::world::Vector2{ 0.0, extent() };
	}

	lgal::tile::Vector2 TileId::toUVCoords(lgal::world::Vector2 const& pos, Origin origin) const
	{
		// compute the extent
		auto extentInv = 1.0 / LevelToTileExtent(level);

		// x and y coordinates of the top left corner of the tile
		auto corner = northwestCorner();

		// uv coordinates on the tile
		auto u = (pos.x - corner.x) * extentInv;
		auto v = (pos.y - corner.y) * extentInv;

		// flip if necessary
		if (origin == Origin::BOTTOM_LEFT)
		{
			v = 1.0 - v;
		}

		return { static_cast<tile_float_t>(u), static_cast<tile_float_t>(v) };
	}

	Tiles::TileId TileId::Containing(Tiles::TileId::IdCoordsT level, lgal::world::Vector2 const& pos)
	{
		// clamp to world boundaries
		lgal::world::Vector2 clamped = clamp(pos, { cLeftX, cTopY }, { cRightX, cBotY });

		// compute the tile extent at this level
		auto extent = TileId::LevelToTileExtent(level);
		// shift x and y to put the origin at the top left of the world
		auto shiftedX = clamped.x + cMaxExtent / 2.0;
		auto shiftedY = clamped.y + cMaxExtent / 2.0;

		// compute the indices in the level x level grid
		// if we are at the border, return the max index: 2^z - 1
		int xIndex = (shiftedX == cMaxExtent) ? (1 << level) - 1 : int(std::floor(shiftedX / extent));
		int yIndex = (shiftedY == cMaxExtent) ? (1 << level) - 1 : int(std::floor(shiftedY / extent));

		// return the TileId
		return { level, xIndex, yIndex };
	}

} }