#include "VectorLineMesh.h"

#include <3rdParty/sole/ourSole.h>
#include "../Utils/BgfxUtils.h"

namespace onyx {
namespace DataObjects {

VectorLineMesh::VectorLineMesh() :
	Drawable(ShaderEnums::ConfigurableShaders::Terrain)
	, mName("VectorLineMesh")
{
	generateVertsIndices();
}

VectorLineMesh::~VectorLineMesh()
{
	if (bgfx::isValid(mVertexBuffer))
	{
		bgfx::destroy(mVertexBuffer);
	}
	if (bgfx::isValid(mIndexBuffer))
	{
		bgfx::destroy(mIndexBuffer);
	}
}


// Vertex.Pos is:
// x: distance from center of the line
// y: distance along the line
// z: direction of end-cap

void VectorLineMesh::generateVertsIndices()
{
	mIndices = { 0, 1, 2, 3/*, 4, 5, 6, 7 */};
	
//	PosUV(float x, float y, float z, float u, float v);
	mVerts = {
		//new dash line setup   // id
		{ { 1,0,0 }, {1,0} },	//	0
		{ { -1,0,0 }, {-1,0} },	//	1
		{ { 1,1,0 }, {1,1} },	//	2
		{ { -1,1,0 }, {-1,1} },	//	3
	};

	// Create static vertex buffer.
	mVertexBuffer = bgfx::createVertexBuffer(
		bgfx::makeRef(mVerts.data(), uint32_t(sizeof(Rendering::VertStructs::PosUV) * mVerts.size()))
		, Rendering::VertStructs::PosUV::ms_layout
	);

	// Create static index buffer for triangle strip rendering.
	mIndexBuffer = bgfx::createIndexBuffer(
		bgfx::makeRef(mIndices.data(), uint32_t(sizeof(uint16_t) * mIndices.size()))
	);

	bgfx::setName(mVertexBuffer, mName.c_str());

}

bool VectorLineMesh::isValid() const
{
	return mVertexBuffer.idx != bgfx::kInvalidHandle && mIndexBuffer.idx != bgfx::kInvalidHandle;
}

void VectorLineMesh::setName(std::string name)
{
	mName = name;
	if (mVertexBuffer.idx != bgfx::kInvalidHandle)
	{
		bgfx::setName(mVertexBuffer, mName.c_str());
	}
}

void VectorLineMesh::attach() const
{
	// Set vertex and index buffer.
	bgfx::setVertexBuffer(0, mVertexBuffer);
	bgfx::setIndexBuffer(mIndexBuffer);
}

} }