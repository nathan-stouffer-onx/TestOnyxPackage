#ifndef __DRAW_PATH_HANDLE_H__
#define __DRAW_PATH_HANDLE_H__

#include <vector>

#include <3rdParty/sole/ourSole.h>
#include <lucid/gal/Types.h>
#include <Styling/Sources/GeojsonSource.h>
#include <Styling/Layers/Layer.h>
#include <GeoJson/GeoJson.h>

#include "Utils/MapMath.h"

namespace onyx {
namespace DataObjects {

/**
* Possible temporary class meant to handle path drawing.
*/
class DrawPathHandle
{
public:
	static constexpr uint32_t cVerticesLimit = 1000;

	static std::unique_ptr<DrawPathHandle> makeDrawPathHandle();

	~DrawPathHandle();

	void addPoint(MapMath::LonLat const& lonLat);

	void replacePath(std::vector<lgal::gpu::Vector3> const& pathArr);

	void submitForRender();

private:

	GeoJson::LineString mLineString;

	std::string const mSourceName;
	std::string const mLayerName;

	DrawPathHandle();

	std::unique_ptr<Styling::Source> source() const;
	std::unique_ptr<Styling::Layer> layer() const;

};

} }

#endif