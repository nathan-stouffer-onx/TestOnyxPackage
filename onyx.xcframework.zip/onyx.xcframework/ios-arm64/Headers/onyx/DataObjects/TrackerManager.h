#ifndef __TRACKER_MANAGER_H__
#define __TRACKER_MANAGER_H__

#include <vector>
#include <map>
#include <mutex>
#include <Shaders/ShaderDefinition.h>
#include <3rdParty/sole/ourSole.h>

#include "../Atlases/TextureAtlas.h"
#include "../Rendering/VertStructs.h"
#include "../Camera/CameraState.h"

#include "Tracker.h"

/**
* TrackerManager is an singleton class that deals with adding and giving out handles to active Tracker objects.
* The viewer supports a limited amount of Trackers present at a time. Edits of a tracker's styling, positioning, and orientation should be made
* through the returned handles. Trackers are identified by uuid(may be subject to change due to small number of supportable trackers. 
* Deactivation of Trackers can be done by calling setInactive() from their given handles. Continued use of the handle after setInactive() will lead to undefined behavior
*
* NOTE: Currently, editing Trackers are not thread safe. Tracker editing as of now should be done before calling draw or querying for Trackers.
*		However, loading Trackers into TrackerManager is thread safe. 
*		TODO: 
*			- Full on refactor: Combine this into some sort of IconManager or SymbolManager with Waypoints 
*			- Add render tests for billboard and puck style trackers
*/

class TrackerManager
{
public:
	typedef onyx::Rendering::VertStructs::PosColor4NormalUV TrackerQuadVert_t;
	typedef onyx::Rendering::VertStructs::PosColor3UV TrackerPuckVert_t;	// TODO: Have the puck and bb share the same vertex struct

	static constexpr size_t cMaxNumTrackers = 10;

	static TrackerManager* Instance();
	static void Shutdown();		// Should only be called once at the end of the program
	void reset();				// Used for testing purposes only. Does not deallocate the singleton instance

	Tracker* addTracker(sole::uuid const& uuid, lgal::world::Vector2 const& pos, TrackerType type);
	Tracker* addTracker(nlohmann::json const& json);

	Tracker* getActiveTracker(sole::uuid const& uuid);
	size_t getNumActiveTrackers() const;

	GET_PROP(SizePuck, float, cInitialSizePuck) // Puck quad size
	inline void setSizePuck(float const size = cInitialSizePuck)
	{
		std::lock_guard<std::mutex> lock(sMutex);
		mSizePuck = size;
	}

	GET_PROP(SizeBB, float, cInitialSizeBB)		// Billboard quad size
	inline void setSizeBB(float const size = cInitialSizeBB)
	{
		std::lock_guard<std::mutex> lock(sMutex);
		mSizeBB = size;
	}

	GET_PROP(OffsetBB, float, cInitialOffsetBB)
	inline void setOffsetBB(float const offset = cInitialOffsetBB)
	{
		std::lock_guard<std::mutex> lock(sMutex);
		mOffsetBB = offset;
	}

	void update();
	void draw(bgfx::ViewId viewId, onyx::Camera::CameraState const& cameraState);

private:
	static std::mutex sMutex;
	static TrackerManager* sSingleton;
	static std::array<uint16_t, 6> sIndices;

	struct RenderTracker
	{
		Tracker tracker;
		bgfx::DynamicVertexBufferHandle handle = BGFX_INVALID_HANDLE;
	};
	std::array<RenderTracker, cMaxNumTrackers> mRenderTrackers;

	// For use with Pucks and Billboard Quads
	bgfx::IndexBufferHandle mQuadIndexBuffer;
	onyx::Atlases::TextureAtlas<std::string> mTrackerIconAtlas;

	// Global rendering defs
	static constexpr gpu_float_t cInitialSizePuck = 0.05f;
	static constexpr gpu_float_t cInitialSizeBB = 0.1f;
	static constexpr gpu_float_t cInitialOffsetBB = 0.f;
	static constexpr gpu_float_t cDepthModifier = 0.001f;
	static constexpr int cInvalidTrackerInd = -1;

	// TODO (Ronald): Replace these shader definitions with configurable shaders
	typedef std::shared_ptr<onyx::Shaders::ShaderDefinition> sharedShaderDef_t;
	sharedShaderDef_t mProgramPuck;
	sharedShaderDef_t mProgramBillboard;
	sharedShaderDef_t mProgramModel;

	TrackerManager();
	~TrackerManager();

	// TODO: Rethink the amount of parameters here. Especially atlasKey, which we can currently get from Tracker
	void drawTracker(
		RenderTracker const& renderTracker,
		onyx::Camera::CameraState const& cameraState,
		bgfx::ViewId viewId,
		uint64_t state,
		std::string const& atlasKey
	);

	static void fillPuckBuffer(RenderTracker const& renderTracker);
	static void fillBillboardBuffer(RenderTracker const& renderTracker, 
		lgal::world::Vector3 const& camPos);

	// Might be cool to have a series of functions specifically for sending information to shaders at some point
	static void setTexture0AndScaleOffset(
		sharedShaderDef_t& shaderDefinition,
		onyx::Atlases::TextureAtlas<std::string> const& atlas,
		std::string const& atlasKey
	);
	static void setFixedSizeShaderUniforms(sharedShaderDef_t& shaderDefinition, 
		lgal::world::Vector3 const& midPoint);
	static void setDepthBiasShaderUniforms(sharedShaderDef_t& shaderDefinition, 
		gpu_float_t const depthModifier = cDepthModifier);
	static void setTransformSRTShaderUniforms(sharedShaderDef_t& shaderDefinition,
		world_float_t scale, lgal::world::Quaternion const& rotation, 
		lgal::world::Vector3 translation);

	void setUniformsPuck(
		Tracker const& tracker,
		onyx::Camera::CameraState const& cameraState,
		const std::string& atlasKey
	);
	void setUniformsBB(
		Tracker const& tracker,
		onyx::Camera::CameraState const& cameraState,
		const std::string& atlasKey
	);
	void setUniformsModel(
		Tracker const& tracker,
		onyx::Camera::CameraState const& cameraState,
		const std::string& atlasKey
	);

	static lgal::gpu::Vector4 getIconTextureOffset(onyx::Atlases::TextureAtlas<std::string> const& atlas, std::string const& key);

	void addIconTexture(const std::string& key);

	//static lgal::world::Quaternion getPuckRotation(Tracker const& tracker, Vector3 const& puckWorldPos, Map3D_float_t puckQuadLen);
	static lgal::world::Quaternion getTrackerOrientTransf(
		Tracker const& tracker,
		world_float_t height,
		world_float_t puckQuadLen,
		world_float_t lenModifier = 0.1);

	static bool isActiveTrackerWithUuid(Tracker const& tracker, sole::uuid const& uuid);

	// Will return cInvalidTrackerInd if no trackers are available
	int findFirstAvailableTracker();
};

#endif
