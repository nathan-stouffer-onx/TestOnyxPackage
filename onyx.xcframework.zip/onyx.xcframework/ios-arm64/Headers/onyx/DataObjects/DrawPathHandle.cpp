#include "DrawPathHandle.h"

#include "Caching/TileCache.h"

#include "Viewport/ViewportManager.h"

namespace onyx {
namespace DataObjects {

	namespace geoJson = onyx::GeoJson;

	DrawPathHandle::DrawPathHandle() :
		mSourceName("TrackerPathSource"),
		mLayerName("TrackerPathLayer")
	{}

	std::unique_ptr<DrawPathHandle> DrawPathHandle::makeDrawPathHandle()
	{
		std::unique_ptr<DrawPathHandle> toRet{ new DrawPathHandle() };
		return toRet;
	}

	DrawPathHandle::~DrawPathHandle()
	{
		// TODO (Ronald) Might be good to add a savePath here for when we're done editing the path
	}

	void DrawPathHandle::addPoint(MapMath::LonLat const& lonLat)
	{
		lgal::gpu::Vector3 pnt = lgal::gpu::Vector3{ lonLat.toVec2().as<gpu_float_t>(), 0 };
		mLineString.addPoint(pnt);
		
		logI("Added point to DrawPathHandle path cache");
	}

	void DrawPathHandle::replacePath(std::vector<lgal::gpu::Vector3> const& pathArr)
	{
		mLineString.lineVertices = pathArr;

		for (auto const& vert : mLineString.lineVertices)
		{
			mLineString.boundPoint(vert);
		}
	}

	void DrawPathHandle::submitForRender()
	{
		if (mLineString.lineVertices.size() < 2)
		{
			return;
		}
		auto* vpMain = ViewportManager::Instance()->getViewport("main");
		MAP3D_ASSERT(vpMain != nullptr, "DrawPathHandle ctor: main viewport should not be nullptr");
		auto vpMainStyle = vpMain->getStyle();
		
		if (vpMainStyle->hasSource(mSourceName))
		{
			vpMainStyle->removeLayer(mLayerName);
			vpMainStyle->removeSource(mSourceName);
		}

		vpMainStyle->addSource(mSourceName, source());
		vpMainStyle->addLayer(layer());
		
		vpMain->invalidate();
	}

	std::unique_ptr<Styling::Source> DrawPathHandle::source() const
	{
		std::unique_ptr<Styling::GeojsonSource> source = std::make_unique<Styling::GeojsonSource>();
		source->minZoom = 10;
		source->runtimeEdit = true;

		if (mLineString.lineVertices.size() >= 2)
		{
			auto lineString = std::make_shared<geoJson::LineString>(mLineString);
			auto feature = std::make_shared<geoJson::Feature>(lineString);
			source->data = feature;
			source->bounds = feature->bounds.as<world_float_t>();
		}

		return source;
	}

	std::unique_ptr<Styling::Layer> DrawPathHandle::layer() const
	{
		// TODO (Ronald):: expose a lot of these stylings as parameters
		std::unique_ptr<Styling::LineLayer> layer = std::make_unique<Styling::LineLayer>();
		
		layer->id = mLayerName;
		layer->source = mSourceName;
		layer->sourceLayer = "data";
		
		auto linePaint = layer->getPaint();
		linePaint->color = Styling::Expressions::Color::construct(lgal::Color(0xFFFF0000));
		linePaint->width = Styling::Expressions::Number::construct(3.0f);

		return layer;
	}

} }

