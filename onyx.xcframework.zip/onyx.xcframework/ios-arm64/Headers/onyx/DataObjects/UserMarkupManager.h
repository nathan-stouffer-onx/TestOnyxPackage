#if !defined(_USER_MARKUP_MANAGER_H)
#define _USER_MARKUP_MANAGER_H
#pragma once

#include <vector>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <cstdint>

#include <lucid/gal/Types.h>
#include <GeoJson/GeoJson.h>

#include "DatabaseObjects/UserMarkup.h"
#include "Tiles/TileId.h"
#include "Vector/LinestringFeature.h"
#include "Storage/MarkupDB.h"

// TODO (Ronald): Integrate data source removal into DrawPathHandle and add UMM deletion into TileCache and write tests
// Figure out if this is how we want to handle our user markups (how are we going to download user markups?)

namespace onyx {
namespace DataObjects {

	/**
	* Singleton class for storing UserMarkups
	* 
	* NOTE:	Loading data into the manager is currently thread safe. However, using markups through the handle is currently not
	*		thread safe. Editing/adding markups while data is being requested from the manager could also result in some race conditions.
	*		For example, bounding boxes may still be in the process of updating when another thread makes a query.
	*/
	class UserMarkupManager
	{
	public:

		typedef std::shared_ptr<onyx::GeoJson::GeoJson const> shared_markup_t;

		// Clears all stored markups. Resets all bounding boxes
		static void Shutdown();

		static void add(std::string const& name, Storage::UserMarkup const& markup);
		static void add(std::string const& name, shared_markup_t gj);

		// Return true if removal is successful, otherwise return false
		static bool erase(std::string const& name);

		static bool contains(std::string const& name);
		static shared_markup_t at(std::string const& name);

		// Find features for a tile from a source name
		static Vector::Feature::FeatureCollectionT find(std::string const& name, Tiles::TileId const& tile, gpu_float_t sizeThreshold = 0.1);

		static lgal::gpu::AABB2d getSourceBounds(std::string const& name);

		inline static lgal::gpu::AABB2d getOverallBounds()
		{ 
			std::lock_guard readL(sMarkupMutex);
			return sMarkupBounds; 
		}
	
	private:

		// TODO (Ronald) change to shared_mutex after upgrading apple ver. targets
		static std::mutex sMarkupMutex;
		static std::unordered_map<std::string, shared_markup_t> sMarkups;
		static lgal::gpu::AABB2d sMarkupBounds;

		static void clip(Vector::Feature::FeatureCollectionT& features, shared_markup_t const& markup, lgal::gpu::AABB2d const& bounds, gpu_float_t sizeThreshold);
		
		static void addLinesNoLock(Vector::Feature::FeatureCollectionT& lines,
			GeoJson::Feature const* feature, lgal::gpu::AABB2d const& bounds, gpu_float_t sizeThreshold);

		static void updateBBsNoLock();

		static void drawDebugLines(shared_markup_t const& markup);
	};

} }

#endif