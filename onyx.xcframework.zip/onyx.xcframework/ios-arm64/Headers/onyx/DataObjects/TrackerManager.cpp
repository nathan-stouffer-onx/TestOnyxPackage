#include "TrackerManager.h"

#include <bgfx/bgfx.h>
#include <bx/bx.h>
#include <Shaders/ShaderManager.h>

#include "../Height/HeightManager.h"
#include "../Utils/BgfxUtils.h"

std::array<uint16_t, 6> TrackerManager::sIndices =
{
	0, 1, 2,
	1, 3, 2
};

static const lgal::world::Vector3 cZAxis{0, 0, 1.0};

TrackerManager* TrackerManager::sSingleton = nullptr;

std::mutex TrackerManager::sMutex;

TrackerManager* TrackerManager::Instance()
{
	{
		std::lock_guard lock(sMutex);
		if (sSingleton == nullptr)
		{
			sSingleton = new TrackerManager;
		}
	}
	return sSingleton;
}

void TrackerManager::Shutdown()
{
	if (sSingleton != nullptr)
	{
		delete sSingleton;
	}

	sSingleton = nullptr;
}

void TrackerManager::reset()
{
	// Already locked
	setSizePuck();
	setSizeBB();
	setOffsetBB();

	std::lock_guard lock(sMutex);
	for (auto& renderTracker : mRenderTrackers)
	{
		renderTracker.tracker = Tracker();
		if (bgfx::isValid(renderTracker.handle))
		{
			bgfx::destroy(renderTracker.handle);
			renderTracker.handle = BGFX_INVALID_HANDLE;
		}
	}
	
}

TrackerManager::TrackerManager() :
	mSizePuck{ cInitialSizePuck },
	mSizeBB{ cInitialSizeBB },
	mOffsetBB{ cInitialOffsetBB },
	mRenderTrackers{ },
	mQuadIndexBuffer(BGFX_INVALID_HANDLE),
	mTrackerIconAtlas{ onyx::Atlases::TextureAtlas<std::string>(onyx::Atlases::cRenderFlags) },
	mProgramPuck{ nullptr },
	mProgramBillboard{ nullptr },
	mProgramModel{ nullptr }
{
	mQuadIndexBuffer = bgfx::createIndexBuffer(
		bgfx::makeRef(sIndices.data(), (uint32_t)(sizeof(uint16_t) * sIndices.size()))
	);
	bgfx::setName(mQuadIndexBuffer, "TrackerQuadIndices");

	mProgramPuck = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TrackerPuck, 0);
	mProgramBillboard = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::BillboardFixedSize, 0);
	mProgramModel = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0);

	sSingleton = this;
}

TrackerManager::~TrackerManager()
{
	std::lock_guard<std::mutex> lock(sMutex);

	for (auto& renderTracker : mRenderTrackers)
	{
		if (bgfx::isValid(renderTracker.handle))
		{
			bgfx::destroy(renderTracker.handle);
		}
	}

	if (bgfx::isValid(mQuadIndexBuffer))
	{
		bgfx::destroy(mQuadIndexBuffer);
	}

	sSingleton = nullptr;
}

Tracker* TrackerManager::getActiveTracker(sole::uuid const& uuid)
{
	Tracker* toRet = nullptr;

	for (auto& renderTracker : mRenderTrackers)
	{
		auto& tracker = renderTracker.tracker;
		if (isActiveTrackerWithUuid(tracker, uuid))
		{
			toRet = &tracker;
			break;
		}
	}

	return toRet;
}

size_t TrackerManager::getNumActiveTrackers() const
{
	size_t numActiveTrackers = 0;
	for (auto const& renderTracker : mRenderTrackers)
	{
		Tracker const& tracker = renderTracker.tracker;
		if (tracker.getIsActive())
		{
			++numActiveTrackers;
		}
	}
	return numActiveTrackers;
}

void TrackerManager::update()
{
	std::lock_guard<std::mutex> lock(sMutex);

	// Generate and integrate texture updates
	mTrackerIconAtlas.update();
}

void TrackerManager::draw(bgfx::ViewId viewId, onyx::Camera::CameraState const& cameraState)
{

	uint64_t state = 0
		| BGFX_STATE_PT_TRISTRIP
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_WRITE_Z
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		| BGFX_STATE_BLEND_ALPHA;

	// if the camera is pointed mostly horizontal, perform depth clipping
	if (cameraState.pitch > lmath::constants::quarter_pi<world_float_t>())
	{
		state |= BGFX_STATE_DEPTH_TEST_LEQUAL;
	}

	std::lock_guard lock(sMutex);

	for (auto& renderTracker : mRenderTrackers)
	{
		if (renderTracker.tracker.getIsActive())
		{
			// TODO: Reduce the number of params in this (move render data into a holding struct?)
			drawTracker(renderTracker, cameraState, viewId, state, renderTracker.tracker.getIcon());
		}
	}
}

void TrackerManager::drawTracker(
	RenderTracker const& renderTracker,
	onyx::Camera::CameraState const& cameraState,
	bgfx::ViewId viewId,
	uint64_t state,
	std::string const& atlasKey
)
{
	bgfx::setState(state);

	// TODO: Remove repetitions once Model is implemented
	Tracker const& tracker = renderTracker.tracker;
	switch (tracker.getType())
	{
	case TrackerType::Puck:
	{
		fillPuckBuffer(renderTracker);
		setUniformsPuck(tracker, cameraState, atlasKey);
		bgfx::setVertexBuffer(0, renderTracker.handle);
		bgfx::setIndexBuffer(mQuadIndexBuffer);
		bgfx::submit(viewId, mProgramPuck->programHandle);
	}
	break;
	case TrackerType::Billboard:
	{
		fillBillboardBuffer(renderTracker, cameraState.position);
		setUniformsBB(tracker, cameraState, atlasKey);
		bgfx::setVertexBuffer(0, renderTracker.handle);
		bgfx::setIndexBuffer(mQuadIndexBuffer);
		bgfx::submit(viewId, mProgramBillboard->programHandle);
	}
	break;
	case TrackerType::Model:
	{
		setUniformsModel(tracker, cameraState, atlasKey);
		bgfx::submit(viewId, mProgramModel->programHandle);
	}
	break;
	}
}

Tracker* TrackerManager::addTracker(sole::uuid const& uuid, lgal::world::Vector2 const& pos, TrackerType type)
{
	MAP3D_ASSERT(type != TrackerType::Model, "TrackerManager currently does NOT support Model type!\n");
	Tracker* toRet = nullptr;
	{
		std::lock_guard<std::mutex> lock(sMutex);

		bool duplicateTrackerFound = (getActiveTracker(uuid) != nullptr);
		if (duplicateTrackerFound)
		{
			logE("Active tracker %s already exists.", uuid.str().c_str());
			return nullptr;
		}

		int availableTrackerInd = findFirstAvailableTracker();
		if (availableTrackerInd == cInvalidTrackerInd)
		{
			logE("Maximum number of trackers reached!");
			return nullptr;
		}

		// TODO: Once billboard and model are implemented, would be good to refactor this part
		RenderTracker& renderTracker = mRenderTrackers[availableTrackerInd];

		Tracker& tracker = renderTracker.tracker;
		tracker.mIsActive = true;
		tracker.setType(type);
		tracker.mUuid = uuid;
		tracker.setPositionXY(pos);

		bgfx::DynamicVertexBufferHandle& handle = mRenderTrackers[availableTrackerInd].handle;
		if (bgfx::isValid(handle))
		{
			// Start with a fresh buffer handle or some weird behavior happens between separate vertex struct types
			bgfx::destroy(handle);
		}
		switch (tracker.getType())
		{
		case TrackerType::Puck:
			handle = bgfx::createDynamicVertexBuffer(4, TrackerPuckVert_t::ms_layout, BGFX_BUFFER_NONE);
			break;
		case TrackerType::Billboard:
			handle = bgfx::createDynamicVertexBuffer(4, TrackerQuadVert_t::ms_layout, BGFX_BUFFER_NONE);
			break;
		case TrackerType::Model:
			MAP3D_ASSERT(false, "Model tracker type has not been implemented yet");
			break;
		default:
			MAP3D_ASSERT(false, "Given tracker type is not supported!");
			break;
		}
		toRet = &tracker;
	}

	if (toRet != nullptr)
	{
		addIconTexture(toRet->getIcon());
	}

	return toRet;
}

Tracker* TrackerManager::addTracker(nlohmann::json const& /*json*/)
{
	MAP3D_ASSERT(0, "TODO: Implement addTracker(json)");
	return nullptr;
}

void TrackerManager::setTexture0AndScaleOffset(
	sharedShaderDef_t& shaderDefintion,
	onyx::Atlases::TextureAtlas<std::string> const& atlas,
	std::string const& atlasKey)
{
	bgfx::TextureHandle texHandle = atlas.getTexHandle(atlasKey);
	int res = atlas.getResolution();
	shaderDefintion->setParameter("s_texture0", texHandle, res, res);
	shaderDefintion->setParameter("u_ScaleOffsetTex0", getIconTextureOffset(atlas, atlasKey));
}

void TrackerManager::setFixedSizeShaderUniforms(sharedShaderDef_t& shaderDefinition, 
	lgal::world::Vector3 const& midpoint)
{
	shaderDefinition->setParameter("u_midpoint", midpoint);
}

void TrackerManager::setDepthBiasShaderUniforms(sharedShaderDef_t& shaderDefinition, 
	gpu_float_t const depthModifier)
{
	shaderDefinition->setParameter("u_depthModifier", depthModifier);
}


void TrackerManager::setTransformSRTShaderUniforms(sharedShaderDef_t& shaderDefinition,
	world_float_t scale, lgal::world::Quaternion const& rotation, lgal::world::Vector3 translation)
{
	shaderDefinition->setParameter("u_scale", scale);
	shaderDefinition->setParameter("u_quatRotation", rotation);
	shaderDefinition->setParameter("u_translation", translation);
}

void TrackerManager::setUniformsPuck(
	Tracker const& tracker,
	onyx::Camera::CameraState const& cameraState,
	const std::string& atlasKey)
{
	setTexture0AndScaleOffset(mProgramPuck, mTrackerIconAtlas, atlasKey);

	auto worldPosition = HeightManager::Instance()->lockToTerrain(tracker.getPositionXY());
	lgal::world::Vector3 posRelativeToEye = worldPosition - cameraState.position;

	// Remember that we assume our "worldspace" is defined with the camera's location as the origin, usually
	setFixedSizeShaderUniforms(mProgramPuck, posRelativeToEye);

	setDepthBiasShaderUniforms(mProgramPuck);

	auto quadSizeModifiedByDistToEye = mSizePuck * len(posRelativeToEye);
	auto rotationTransform = getTrackerOrientTransf(tracker, worldPosition.z, quadSizeModifiedByDistToEye);

	// FixedSize shader component already handles scale by distance to eye
	setTransformSRTShaderUniforms(mProgramPuck, mSizePuck, rotationTransform, posRelativeToEye);
}

void TrackerManager::setUniformsBB(
	Tracker const& //tracker
	, onyx::Camera::CameraState const& cameraState
	, const std::string& atlasKey
)
{
	setTexture0AndScaleOffset(mProgramBillboard, mTrackerIconAtlas, atlasKey);

	mProgramBillboard->setParameter("u_billboardSize", lgal::gpu::Vector3{ mSizeBB, mSizeBB, 0 });
	mProgramBillboard->setParameter("u_bbOffset", mOffsetBB);

	auto n = static_cast<gpu_float_t>(cameraState.nearClip);
	auto f = static_cast<gpu_float_t>(cameraState.farClip);
	mProgramBillboard->setParameter("u_nearFarPlane", lgal::gpu::Vector3{ n, f, 0.f });
	mProgramBillboard->setParameter("u_eyePos", cameraState.position);
	mProgramBillboard->setParameter("u_camRight", cameraState.rightDir());
	mProgramBillboard->setParameter("u_camForward", cameraState.lookDir());
	mProgramBillboard->setParameter("u_camUp", cameraState.upDir());
}

void TrackerManager::setUniformsModel(
	Tracker const& /*tracker*/,
	onyx::Camera::CameraState const& /*cameraState*/,
	const std::string& /*atlasKey*/
)
{
	MAP3D_ASSERT(false, "TODO: Implement TrackerManager::setUniformsModel!\n");
}

void TrackerManager::fillBillboardBuffer(RenderTracker const& renderTracker, lgal::world::Vector3 const& camPos)
{
	Tracker const& tracker = renderTracker.tracker;

	lgal::world::Vector3 pos = HeightManager::Instance()->lockToTerrain(tracker.getPositionXY());
	auto posRelativeToCam = (pos - camPos).as<gpu_float_t>();

	std::array<TrackerQuadVert_t, 4> quadVertices{};
	for (size_t y = 0; y < 2; ++y)
	{
		for (size_t x = 0; x < 2; ++x)
		{
			lgal::gpu::Vector2 xy = { float32_t(x), float32_t(y) };

			auto& v = quadVertices[2 * y + x];

			// Position
			v.m_x = xy.x;
			v.m_y = xy.y;
			v.m_z = 0.0f;

			// Colors
			v.m_abgr = tracker.getOutlineColor().abgr();
			v.m_abgr2 = tracker.getBodyColor().abgr();
			v.m_abgr3 = tracker.getArrowColor().abgr();

			// Pack pivot position in normal
			v.m_nx = posRelativeToCam.x;
			v.m_ny = posRelativeToCam.y;
			v.m_nz = posRelativeToCam.z;

			// UV Coordinates
			v.m_u = xy.x;
			v.m_v = 1.0f - xy.y;
		}
	}

	auto data = quadVertices.data();
	const bgfx::Memory* vMem = bgfx::copy(data, sizeof(TrackerQuadVert_t) * (uint32_t)quadVertices.size());
	bgfx::update(renderTracker.handle, 0, vMem);
}

void TrackerManager::fillPuckBuffer(RenderTracker const& renderTracker)
{
	Tracker const& tracker = renderTracker.tracker;

	std::array<TrackerPuckVert_t, 4> quadVertices{};
	for (size_t y = 0; y < 2; y++)
	{
		for (size_t x = 0; x < 2; x++)
		{
			lgal::gpu::Vector2 xy = { float32_t(x), float32_t(y) };

			TrackerPuckVert_t& v = quadVertices[2 * y + x];

			// Position. Center at (0, 0)
			v.m_x = xy.x - 0.5f;
			v.m_y = xy.y - 0.5f;
			v.m_z = 0.f;

			// Colors
			v.m_abgr = tracker.getOutlineColor().abgr();
			v.m_abgr2 = tracker.getBodyColor().abgr();
			v.m_abgr3 = tracker.getArrowColor().abgr();

			// UV Coordinates
			v.m_u = xy.x;
			v.m_v = xy.y;
		}
	}

	auto data = quadVertices.data();
	const bgfx::Memory* vMem = bgfx::copy(data, sizeof(TrackerPuckVert_t) * (uint32_t)quadVertices.size());
	bgfx::update(renderTracker.handle, 0, vMem);
}

lgal::gpu::Vector4 TrackerManager::getIconTextureOffset(onyx::Atlases::TextureAtlas<std::string> const& atlas, std::string const& key)
{
	return (atlas.isReady(key)) ? atlas.getUVOffset(key) : lgal::gpu::Vector4{ 0, 0, 1, 1 };
}


void TrackerManager::addIconTexture(const std::string& key)
{
	std::lock_guard<std::mutex> lock(sMutex);

	if (!mTrackerIconAtlas.contains(key))
	{
		std::string fileName = "assets/img/" + key + ".png";
		bgfx::TextureInfo info;
		bgfx::TextureHandle texHandle = BgfxUtils::loadTexture(fileName.c_str(), 0, 0, &info);
		if (bgfx::isValid(texHandle))
		{
			mTrackerIconAtlas.insert(key, { texHandle }, info.format);
		}
	}
}

lgal::world::Quaternion TrackerManager::getTrackerOrientTransf(
	Tracker const& tracker, 
	world_float_t height, 
	world_float_t puckQuadLen, 
	world_float_t lenModifier)
{
	// Default rotation is orienting puck to where it is facing
	lgal::world::Quaternion toRet = rotateUsingAxis(cZAxis, tracker.getHeadingAngleFromNorth());

	// Orient puck to terrain
	if (tracker.getIsOrientedToTerrain())
	{
		auto sampleQuadSize = puckQuadLen * lenModifier;
		lgal::world::Vector3 trkWorldPos{ tracker.getPositionXY(), height };
		auto terrainNormal = HeightManager::Instance()->getTerrainNormal(trkWorldPos, sampleQuadSize);

		lgal::world::Vector3 axisOfRot = normalize(cross(cZAxis, terrainNormal));
		world_float_t angleRad = acos(dot(cZAxis, terrainNormal));

		bool isValidRotation = !(lucid::math::isNan(axisOfRot)) && !(std::isnan(angleRad));
		if (isValidRotation)
		{
			auto orientToMatchTerrainTransform = rotateUsingAxis(axisOfRot, angleRad);
			toRet = orientToMatchTerrainTransform * toRet;
		}
	}

	return toRet;
}

bool TrackerManager::isActiveTrackerWithUuid(Tracker const& tracker, sole::uuid const& uuid)
{
	return (tracker.getUuid() == uuid) && tracker.getIsActive();
}

int TrackerManager::findFirstAvailableTracker()
{
	int const arraySize = static_cast<int>(mRenderTrackers.size());
	int indexToRet = cInvalidTrackerInd;
	for (int i = 0; i < arraySize; ++i)
	{
		auto& tracker = mRenderTrackers[i].tracker;
		bool isAvailable = !tracker.getIsActive();
		if (isAvailable)
		{
			indexToRet = i;
			break;
		}
	}
	return indexToRet;
}

