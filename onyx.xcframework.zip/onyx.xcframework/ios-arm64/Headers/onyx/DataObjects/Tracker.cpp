#include "Tracker.h"

#include "../Height/HeightManager.h"

const std::string Tracker::cDefaultTrackerIcon = "Puck";

Tracker::Tracker() : Tracker(sole::uuid{}, TrackerType::Puck)
{}

Tracker::Tracker(sole::uuid const& uuid, TrackerType type) :
	mUuid{ uuid },
	mIcon{ cDefaultTrackerIcon },
	mIsActive{ false },
	mHeadingAngleFromNorth{ 0.0 },
	mType{ type },
	mPositionXY{ 0, 0 },
	mOutlineColor{ 0xFFFF0000 },
	mBodyColor{ 0xFF00FF00 },
	mArrowColor{ 0xFF0000FF },
	mIsOrientedToTerrain{ true }
{
}

Tracker::~Tracker()
{
}
