#include "Waypoint.h"

#include <3rdParty/sole/ourSole.h>

Waypoint::Waypoint(sole::uuid uuid) :
	  mUuid(uuid)
	, mPosition(0)
	, mRadius(0.0)
	, mSelected(false)
{
	setIcon(DEFAULT_WAYPOINT_ICON);
}

Waypoint::~Waypoint() {}

std::string Waypoint::iconToFileName(const std::string& icon)
{
	std::string fileName = "assets/img/";

	std::string iconSansSpace;
	for (const char& c : icon)
	{
		if (c != ' ')
		{
			iconSansSpace += c;
		}
	}

	fileName += iconSansSpace + ".png";
	return fileName;
}
