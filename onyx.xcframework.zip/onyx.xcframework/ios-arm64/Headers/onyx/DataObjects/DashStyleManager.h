#if !defined(DASH_STYLE_MANAGER_H)
#define DASH_STYLE_MANAGER_H
#pragma once

#include <unordered_map>
#include <vector>
#include <unordered_set>
#include <string>

#include <bgfx/bgfx.h>

namespace onyx {
namespace DataObjects {
	
	class DashStyleManager {
	public:
		static void Shutdown();
		static bgfx::TextureHandle add(std::string const& name, std::vector<uint8_t> const& pattern);
		static void remove(std::string const& name);
		static bgfx::TextureHandle get(std::string const& name);
	private:
		static std::unordered_map<std::string, bgfx::TextureHandle> mPatterns;
	};

} }

#endif