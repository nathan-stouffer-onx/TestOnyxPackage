#include "UserMarkupManager.h"

#include <System/Map3DException.h>

#include "Utils/MapMath.h"
#include "WaypointManager.h"

namespace onyx {
namespace DataObjects {

	std::unordered_map<std::string, UserMarkupManager::shared_markup_t> UserMarkupManager::sMarkups;
	lgal::gpu::AABB2d UserMarkupManager::sMarkupBounds = lgal::gpu::AABB2d::nothing();
	std::mutex UserMarkupManager::sMarkupMutex;

	void UserMarkupManager::add(std::string const& name, shared_markup_t gj)
	{
		MAP3D_TRY
			bool skip = false;

			if (gj->type == GeoJson::GeoJson::Types::Feature)
			{
				auto const* feature = static_cast<GeoJson::Feature const*>(gj.get());
				switch (feature->geometry->type)
				{
				case GeoJson::Geometry::Types::Point:
				{
					skip = false;
					static bool debugPoints = true;
					if (debugPoints)
					{
						auto const* pt = static_cast<GeoJson::Point const*>(feature->geometry.get());
						lgal::world::Vector2 v2{ pt->position.x, pt->position.y };
						auto wp = WaypointManager::Instance()->addWaypoint(onyx::Utils::getUuid(), lgal::toBx(v2), 0xFF800080);
					}
				}
				break;
				case GeoJson::Geometry::Types::LineString:
				{
					skip = false;
					drawDebugLines(gj);
				}
				break;
				default:
					skip = true;
					logE("UserMarkup insertion skipped. Given Geometry type not supported");
					break;
				}
			}
			else
			{
				logE("UserMarkup insertion skipped. FeatureCollection not supported.");
				skip = true;
			}
			if (!skip)
			{
				std::lock_guard writeL(sMarkupMutex);

				sMarkups.emplace(name, gj);
				sMarkupBounds = lmath::fit(sMarkupBounds, gj->bounds);
			}
		MAP3D_CATCH
			logE(ex.summarize());
		MAP3D_CATCH_ALL
			logE("Unrecognized exception while attempting to parse markup JSON");
		MAP3D_END_CATCH
	}

	void UserMarkupManager::add(std::string const& name, Storage::UserMarkup const& markup)
	{
		shared_markup_t gj = nullptr;
		MAP3D_TRY
			gj = GeoJson::Parse(markup.getGeoJson());
		MAP3D_CATCH_ALL
			logE("Unrecognized exception while attempting to parse markup JSON");
			return;
		MAP3D_END_CATCH

		add(name, gj);
	}

	bool UserMarkupManager::erase(std::string const& name)
	{
		std::lock_guard writeL(sMarkupMutex);

		auto iter = sMarkups.find(name);
		if (iter == sMarkups.end())
		{
			return false;
		}

		// erase the markup
		sMarkups.erase(iter);
		updateBBsNoLock();

		return true;
	}

	bool UserMarkupManager::contains(std::string const& name)
	{
		std::lock_guard readL(sMarkupMutex);
		return sMarkups.find(name) != sMarkups.end();
	}

	UserMarkupManager::shared_markup_t UserMarkupManager::at(std::string const& name)
	{
		std::lock_guard readL(sMarkupMutex);
		bool contains = sMarkups.find(name) != sMarkups.end();
		return (contains) ? sMarkups.at(name) : nullptr;
	}

	void UserMarkupManager::Shutdown()
	{
		std::lock_guard l(sMarkupMutex);
		sMarkupBounds = lgal::gpu::AABB2d::nothing();
		sMarkups.clear();
	}

	void UserMarkupManager::addLinesNoLock(Vector::Feature::FeatureCollectionT& lines, GeoJson::Feature const* feature,
		lgal::gpu::AABB2d const& worldBounds, gpu_float_t sizeThreshold)
	{
		// size check
		auto boundsSize = lmath::lenSquared(worldBounds.max - worldBounds.min);
		auto minSizeScale = 1.f / (sizeThreshold * sizeThreshold);
		auto featureBounds = MapMath::projectToMercator(feature->bounds);
		auto featureSize = lmath::lenSquared(featureBounds.max - featureBounds.min);
		if (featureSize * minSizeScale < boundsSize)
		{
			return;
		}

		switch (feature->geometry->type)
		{
		case GeoJson::Geometry::Types::LineString:
			{
				auto ls = std::static_pointer_cast<GeoJson::LineString const>(feature->geometry);
				
				// copy line string into 2d version
				std::vector<lgal::tile::Vector2> points;
				for (auto const& point : ls->lineVertices)
				{
					auto ll = MapMath::LonLat(point.x, point.y);
					points.push_back(ll.toWorldPos().as<tile_float_t>());
				}

				std::vector<std::vector<lgal::tile::Vector2>> subPolylines = lmath::clip(points, worldBounds);
				
				// add to lines
				for (auto& line : subPolylines)
				{
					lgal::tile::Polyline polyline = { line };

					lgal::tile::Vector2 dim = worldBounds.length();
					lgal::tile::Vector2 scale{ 1.0f / dim.x, 1.0f / dim.y };
					polyline.translate(-worldBounds.min);
					polyline.scale(scale);

					lines.push_back(std::make_shared<Vector::LinestringFeature const>(polyline));
				}
			}
			break;
		case GeoJson::Geometry::Types::MultiLineString:
		default:
			MAP3D_ASSERT(false, "addLinesNoLock support for given type is not implemented");
			return;
		}
	}

	Vector::Feature::FeatureCollectionT UserMarkupManager::find(std::string const& name, Tiles::TileId const& tile, gpu_float_t sizeThreshold)
	{
		auto bounds = tile.worldBounds<gpu_float_t>();

		Vector::Feature::FeatureCollectionT features;

		{
			std::lock_guard readL(sMarkupMutex);
			shared_markup_t const& geojson = sMarkups.at(name);
			if (lmath::intersects(bounds, MapMath::projectToMercator(geojson->bounds)) != lmath::Intersections::NONE)
			{
				clip(features, geojson, bounds, sizeThreshold);
			}
		}

		return features;
	}

	void UserMarkupManager::clip(Vector::Feature::FeatureCollectionT& features, shared_markup_t const& markup, lgal::gpu::AABB2d const& bounds, gpu_float_t sizeThreshold)
	{
		switch (markup->type)
		{
		case GeoJson::GeoJson::Types::FeatureCollection:
		{
			auto fc = static_cast<GeoJson::FeatureCollection const*>(markup.get());
			for (auto const& f : fc->features)
			{
				addLinesNoLock(features, static_cast<GeoJson::Feature const*>(f.get()), bounds, sizeThreshold);
			}
		}
		case GeoJson::GeoJson::Types::Feature:
		{
			auto f = static_cast<GeoJson::Feature const*>(markup.get());
			addLinesNoLock(features, f, bounds, sizeThreshold);
		}
			break;

		
			break;
		default:
			MAP3D_ASSERT(false, "In UserMarkupManager::addToFeatures. geojson type not supported");
			break;
		}
		
	}

	lgal::gpu::AABB2d UserMarkupManager::getSourceBounds(std::string const& name)
	{
		std::lock_guard readL(sMarkupMutex);

		auto found = sMarkups.find(name);
		if (found == sMarkups.end())
		{
			return lgal::gpu::AABB2d::nothing();
		}

		return found->second->bounds;
	}

	void UserMarkupManager::updateBBsNoLock()
	{
		// update bounding box
		auto newBB = lgal::gpu::AABB2d::nothing();
		for (auto const& [source, geojson] : sMarkups)
		{
			newBB = lmath::fit(newBB, geojson->bounds);
		}
		sMarkupBounds = newBB;
	}

	void UserMarkupManager::drawDebugLines(shared_markup_t const& markup)
	{
		// Some test code to insert waypoints for each vertex in the line string
		static size_t count = 0;
		if (count < 10)
		{
			++count;
			auto ls = GeoJson::getGeometryFromGeoJson<GeoJson::LineString const>(markup);
			for (auto const& p : ls->lineVertices)
			{
				MapMath::LonLat ll{ p.x, p.y };
				auto pos = lgal::world::Vector3{ ll.toWorldPos(), 0 };

				auto wp = WaypointManager::Instance()->addWaypoint(Utils::getUuid(),
					lgal::toBx(pos), lgal::Color{ 1.f, 0.f, 0.f, 1.f });
				wp->setIconColor({ 0, 0, 0,1.f });
				wp->setDiskColor({ 0, 1, 1, 1.f });
				wp->setBodyColor({ 0, 0, 0, 0.f });
				wp->setOutlineColor({ 0, 0, 0, 0.f });
			}
		}
	}

} }