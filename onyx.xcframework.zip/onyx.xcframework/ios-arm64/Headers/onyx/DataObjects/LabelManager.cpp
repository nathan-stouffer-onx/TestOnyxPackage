#include "LabelManager.h"

#include <lucid/math/Constants.h>
#include <lucid/Profiler.h>

#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>
#include <System/Map3DException.h>

#include "Utils/MapMath.h"
#include "Viewport/Viewport.h"

namespace onyx {
namespace DataObjects {

LabelManager::LabelManager(Viewport const* viewport)
	: mViewport(viewport)
{
	mTimeOffset = bx::getHPCounter();

	auto caps = bgfx::getCaps();

	mHomogenousDepth = caps->homogeneousDepth;

	mNearClip = mHomogenousDepth ? -1.f : 0.f;
	mFarClip = 1.f;

}

void LabelManager::initialize()
{
	auto fontManager = Font::M3DFontManager::getFontManager();
	MAP3D_ASSERT(fontManager != nullptr, "Font manager has not been initialized");
	mTextBufferManager.reset(new TextBufferManager(fontManager));
}

LabelManager::~LabelManager()
{
	for (auto  &[style, handle] : mStyleBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	if (mTextBuffer.idx != bgfx::kInvalidHandle)
	{
		mTextBufferManager->destroyTextBuffer(mTextBuffer);
	}

	mTextBufferManager.reset();
}

void LabelManager::update()
{
	for (auto& kvp : mStyleBufferHandles)
	{
		mTextBufferManager->clearTextBuffer(kvp.second);
	}
}

TextBufferHandle LabelManager::getStyleBuffer(Styling::FontStyle const& style)
{
	auto found = mStyleBufferHandles.find(style.font);
	TextBufferHandle handle = { bgfx::kInvalidHandle };
	if (found == mStyleBufferHandles.end())
	{
		auto newHandle = mTextBufferManager->createTextBuffer(FONT_TYPE_DISTANCE_OUTLINE, BufferType::Transient);
		mStyleBufferHandles.emplace(style.font, newHandle);
		handle = newHandle;
	}
	else
	{
		handle = found->second;
	}
	return handle;
}

void LabelManager::getLabelScreenState(LabelState& labelState, onyx::Camera::CameraState const& camState, Camera::Frustum const& frustum, Atlases::HeightAtlas const *heightAtlas)
{
	LUCID_PROFILE_SCOPE("LabelManager::getLabelScreenState");
	auto const& label = labelState.label;
	auto labelSpace = label->getLabelSpace();

	auto anchorPoint = label->getAnchorPoint();
	auto textDirection = label->getTextDirection();

	if (labelSpace == Utils::SpaceTypes::ScreenPx)
	{
		labelState.screenPositionPx = anchorPoint.as<gpu_float_t>();
		labelState.screenDirectionPx = { textDirection, 0 };
	}
	else if (labelSpace == Utils::SpaceTypes::Tile)
	{
		auto tileId = label->getTileId();
		lgal::world::Vector3 pos(tileId.toWorldPos(anchorPoint.xy, Tiles::TileId::Origin::TOP_LEFT), 0);
		if (heightAtlas != nullptr)
		{
			pos.z = heightAtlas->heightAt(pos.xy);
		}

		auto projected = camState.projectExaggerated(pos);
		labelState.globePosition = pos;
		labelState.screenPositionPx = projected.position.as<gpu_float_t>();

		pos.xy = tileId.toWorldPos(anchorPoint.xy + textDirection.as<world_float_t>(), Tiles::TileId::Origin::TOP_LEFT);

		projected = camState.projectExaggerated(pos);
		labelState.screenDirectionPx = { projected.position.xy.as<gpu_float_t>() - labelState.screenPositionPx.xy, labelState.screenPositionPx.z };
		labelState.screenDirectionPx = lmath::normalize(labelState.screenDirectionPx);
	}
	else
	{
		auto pos = anchorPoint;
		if (heightAtlas != nullptr)
		{
			pos.z = heightAtlas->heightAt(pos.xy);
		}

		auto projected = camState.projectExaggerated(pos);
		labelState.globePosition = pos;
		labelState.screenPositionPx = projected.position.as<gpu_float_t>();
		
		lgal::world::Vector3 dirPos(anchorPoint.xy + textDirection.as<world_float_t>(), anchorPoint.z);
		projected = camState.projectExaggerated(dirPos);
		
		auto screenDirPos = projected.position.as<gpu_float_t>();
		labelState.screenDirectionPx = lmath::normalize(screenDirPos - labelState.screenPositionPx);
	}

	if (label->getLabelSpace() != Utils::SpaceTypes::ScreenPx)
	{
		if (!frustum.contains(labelState.globePosition))
		{
			labelState.cullState = LabelCullState::FRUSTUM_CLIPPED;
		}

		if (isClipped(labelState.screenPositionPx))
		{
			labelState.cullState = LabelCullState::SCREEN_SPACE_CLIPPED;
		}

		// Convert screen position from normalized screen coordinates to screen pixel coordinates
		labelState.screenPositionPx.x = (labelState.screenPositionPx.x * 0.5f + 0.5f) * mScreenSize.x;
		labelState.screenPositionPx.y = (labelState.screenPositionPx.y * 0.5f + 0.5f) * mScreenSize.y;
	}

}

bool LabelManager::isLabelVisible(Camera::ScreenSpaceManager& screenSpaceManager, LabelManager::LabelState &labelState)
{
	LUCID_PROFILE_SCOPE("LabelManager::isLabelVisible");

	auto const& label = labelState.label;

	auto &screenPos = labelState.screenPositionPx;

	if (labelState.cullState != LabelCullState::VISIBLE)
	{
		if (labelState.cullState == LabelCullState::FRUSTUM_CLIPPED)
		{
			++mStats.frustumClipped;
		}
		else if (labelState.cullState == LabelCullState::SCREEN_SPACE_CLIPPED)
		{
			++mStats.screenSpaceClipped;
		}
		return false;
	}

	auto depth = mViewport->depthAtPixel(int(screenPos.x), int(screenPos.y));

	if (depth < screenPos.z)
	{
		++mStats.depthClipCount;
		labelState.cullState = LabelCullState::DEPTH_CLIPPED;
		return false;
	}

	auto screenXY = screenPos.xy.as<screen_coord_t>();

	if (!label->getForce() && screenSpaceManager.intersects(screenXY) != lmath::Intersections::NONE)
	{
		labelState.cullState = LabelCullState::OVERLAP_CLIPPED;
		++mStats.overlapClipped;
		return false;
	}

	return true;
}

bool LabelManager::bufferLabel(Camera::ScreenSpaceManager& screenSpaceManager, Atlases::HeightAtlas const* heightAtlas, LabelManager::LabelState &labelState, Camera::CameraState const& cameraState)
{
	LUCID_PROFILE_SCOPE("LabelManager::bufferLabel");

	auto const& label = labelState.label;

	auto style = label->getStyle();

	TextBufferHandle handle = getStyleBuffer(*style);
	if (handle.idx == bgfx::kInvalidHandle)
	{
		labelState.cullState = LabelCullState::STYLE_INVALID;
		return false;
	}

	auto text = label->getText();

	auto font = Font::M3DFontManager::getFont(style->font);

	mTextBufferManager->setStyle(handle, style);
	mTextBufferManager->setAlpha(handle, gpu_float_t(label->getCurrentAlpha()) / 255.f);
	mTextBufferManager->setOutlineWidth(handle, 2);
	mTextBufferManager->setDropShadowOffset(handle, 3, 3);

	bool isScreenSpace = label->getLabelSpace() == Utils::SpaceTypes::ScreenPx;

	auto feature = label->getFeature();

	auto symbolPlacement = style->symbolPlacement;

	if ((symbolPlacement == Styling::FontStyle::SymbolPlacement::LINE
		|| symbolPlacement == Styling::FontStyle::SymbolPlacement::LINE_CENTER
		|| symbolPlacement == Styling::FontStyle::SymbolPlacement::LINE_JUSTIFY)
		&& feature != nullptr
		&& (feature->type() == Vector::Feature::Type::LINESTRING || feature->type() == Vector::Feature::Type::POLYGON))
	{
		std::vector<lgal::gpu::Vector3> screenPath;

		auto sizeThreshold = (mScreenSize.x * mScreenSize.y) * 0.025f;

		gpu_float_t pathLength = 0;

		if (isScreenSpace)
		{
			std::vector<lgal::gpu::Vector2> loop = feature->points();
			screenPath.reserve(loop.size());
			for (auto const& pt : loop)
			{
				screenPath.push_back({ pt, 0 });
			}
			labelState.screenRectPx = feature->aabb();
		}
		else
		{
			LUCID_PROFILE_SCOPE("Label geometry transform to screen space");
			auto const& worldGeometry = label->getWorldGeometry();

			screenPath.reserve(worldGeometry.size() + 1);

			lgal::gpu::Vector3 first(0, 0, 0);
			lgal::gpu::Vector3 prev(0, 0, 0);

			for (auto& worldPt : worldGeometry)
			{
				// TODO (scott) ensure that this is done in prepare tasks so it doesn't need to be done every frame
				lgal::world::Vector3 heightPt = worldPt;
				if (heightAtlas != nullptr)
				{
					heightPt.z = cameraState.terrainExaggeration * heightAtlas->heightAt(worldPt.xy);
				}

				auto projectedPt = cameraState.project(heightPt);
				if (projectedPt.valid)
				{
					auto screenPt = projectedPt.position.as<gpu_float_t>();
					screenPt.x = (screenPt.x * 0.5f + 0.5f) * mScreenSize.x;
					screenPt.y = (screenPt.y * 0.5f + 0.5f) * mScreenSize.y;
					screenPt.z = lucid::math::clamp(mNearClip, mFarClip, screenPt.z - DBG_DepthOffset - 0.01f);
					labelState.screenRectPx = labelState.screenRectPx.fit(screenPt.xy);
					if (screenPath.empty())
					{
						first = screenPt;
					}
					else
					{
						pathLength += lmath::len(screenPt.xy - prev.xy);
					}

					prev = screenPt;
					screenPath.push_back(screenPt);
					
					// TODO (scott) potentially check to see if there are longer segments still on screen instead of immediately bailing
					//				after one point leaves the clipping area.
					if (screenPath.size() > 2 && isClipped(projectedPt.position.as<gpu_float_t>())) // If the path leaves the screen, bail.
					{
						break;
					}
				}
			}

			if (feature->type() == Vector::Feature::Type::POLYGON) // Close the loop for polygons
			{
				screenPath.push_back(first);
			}

			auto area = labelState.screenRectPx.area();

			if (area < sizeThreshold * DBG_sizeCutoff)
			{
				labelState.cullState = LabelCullState::SIZE_CLIPPED;
				return false;
			}
		}

		if (screenPath.size() < 2)
		{
			labelState.cullState = LabelCullState::PATH_CLIPPED;
			return false;
		}

		if (screenPath.size() > 0)
		{
			LUCID_PROFILE_SCOPE("layout text");
			auto textLength = label->getTextLengthPx();
			auto kerningModifier = style->kerningModifier;

			if (symbolPlacement == Styling::FontStyle::SymbolPlacement::LINE_JUSTIFY)
			{
				if (textLength == -1.f)
				{
					mTextBufferManager->setTextDirection(handle, { 1, 0 }, { 0, 1 });
					auto rect = mTextBufferManager->measureText(handle, font, text.c_str(), 0);
					textLength = rect.max.x - rect.min.x;
					label->setTextLengthPx(textLength);
				}

				if (pathLength > textLength || kerningModifier > 1)
				{
					auto strlen = text.length();
					auto space = pathLength - textLength;
					kerningModifier = lmath::clamp(space / gpu_float_t(strlen), 1.f, kerningModifier);
				}
			}

			mTextBufferManager->setPenDepth(handle, DBG_DepthOffset);
			auto rect = mTextBufferManager->layoutText(handle, font, screenPath, text.c_str(), kerningModifier, nullptr, style->textPlacement);
			screenSpaceManager.reserveRect(rect.as<screen_coord_t>());
		}
	}
	else // point or unspecified placement, or no world geometry
	{
		auto clampedPitch = (lmath::clamp(gpu_float_t(cameraState.pitch), 0.25f, 0.75f) - 0.25f) * 2.f;

		auto const &screenPos = labelState.screenPositionPx;
		auto & screenDir = labelState.screenDirectionPx;

		screenDir.x *= mViewport->getWidthPixel() * 0.5f;
		screenDir.y *= mViewport->getHeightPixel() * 0.5f;
		screenDir = lmath::normalize(screenDir);

		if (screenDir.x < 0)
		{
			screenDir = screenDir * -1.f;
		}

		lgal::gpu::Vector2 xDir(1, 0);

		// TODO (scott) this transition would look nicer if it were tied to a pitch threshold and timed 
		//				animation instead of lerping based on camera pitch, so that the user couldn't
		//				move the camera to a pitch where the label directionss are semi-transitioned.
		xDir = lmath::lerp(screenDir.xy, xDir, clampedPitch);

		lgal::gpu::Vector2 yDir = { -xDir.y, xDir.x };

		labelState.screenRectPx = mTextBufferManager->measureText(handle, font, text.c_str(), style->kerningModifier);
		lgal::gpu::Vector2 textSize = labelState.screenRectPx.max - labelState.screenRectPx.min,
			offset(0);

		switch (style->textPlacement & Styling::TextPlacement::VERTICAL_FLAGS)
		{
			case Styling::TextPlacement::BELOW:
				break;
			case Styling::TextPlacement::ABOVE:
				offset = yDir * (textSize.y * -1.0f);
				break;
			case Styling::TextPlacement::VERTICAL_CENTER:
			default:
				offset = yDir * (textSize.y * -0.5f);
				break;
		}

		switch (style->textPlacement & Styling::TextPlacement::HORIZONTAL_FLAGS)
		{
			case Styling::TextPlacement::LEFT:
				offset += xDir * (textSize.x * -1.0f);
				break;
			case Styling::TextPlacement::RIGHT:
				break;
			case Styling::TextPlacement::HORIZONTAL_CENTER:
			default:
				offset += xDir * (textSize.x * -0.5f);
				break;
		}

		LUCID_PROFILE_SCOPE("append text");

		mTextBufferManager->setTextDirection(handle, xDir, yDir);
		labelState.screenDirectionPx = { xDir, screenDir.z };

		mTextBufferManager->setPenPosition(handle, { screenPos.xy + offset, mNearClip + DBG_DepthOffset });

		labelState.screenRectPx = mTextBufferManager->appendText(handle, font, text.c_str(), style->kerningModifier);
		screenSpaceManager.reserveRect(labelState.screenRectPx.as<screen_coord_t>());
	}

	return true;
}

void LabelManager::draw(Camera::ScreenSpaceManager& screenSpaceManager, Atlases::HeightAtlas const* heightAtlas, std::vector<LabelCollection::sharedLabel_t> const& frameLabels, bgfx::ViewId viewId)
{
	auto const& cameraState = mViewport->getCameraState();

	LUCID_PROFILE_SCOPE("LabelManager::draw");
	mStats.clear();

	if (mDebugMode)
	{
		mLabelStates.clear();
		mLabelStates.reserve(frameLabels.size());
	}

	// Setup a top-left ortho matrix for screen space drawing.
	const bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	const bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	float view[16];
	bx::mtxLookAt(view, eye, at);

	const float centering = 0.5f;

	float ortho[16];
	bx::mtxOrtho(ortho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);
	bgfx::setViewTransform((bgfx::ViewId)viewId, view, ortho);
	bgfx::setViewRect((bgfx::ViewId)viewId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

	LabelState tempLabelState = { nullptr };
	LabelState* currentLabelState = &tempLabelState;

	{
		std::lock_guard<std::mutex> lock(mConnectionLock);
		mCurrentFrameLabels.clear();
		mCurrentFrameLabels.reserve(DBG_maxLabelsDrawn);

		mLabelsDrawn = 0;

		Camera::Frustum frustum(cameraState);

		for (auto const &label : frameLabels)
		{
			LUCID_PROFILE_SCOPE("Add labels");
			if (mDebugMode)
			{
				mLabelStates.push_back({ label });
				currentLabelState = &mLabelStates.back();
			}
			if (label == mDebugLabel)
			{
				logD("Processing debug label: %s", label->getText().c_str());
			}

			currentLabelState->cullState = LabelCullState::VISIBLE;

			getLabelScreenState(*currentLabelState, cameraState, frustum, heightAtlas);
			if (isLabelVisible(screenSpaceManager, *currentLabelState))
			{
				if (bufferLabel(screenSpaceManager, heightAtlas, *currentLabelState, cameraState))
				{
					++mStats.buffered;
					currentLabelState->cullState = LabelCullState::VISIBLE;
					mCurrentFrameLabels.insert(label);
				}
				else
				{
					++mStats.bufferClipped;
				}
			}
			else
			{
				++mStats.visibilityClipped;
			}

			if (mCurrentFrameLabels.size() >= size_t(DBG_maxLabelsDrawn))
				break;
		}

		labelVec_t toDelete;
		for (auto const& label : mOnscreenLabels)
		{
			auto isCurrent = mCurrentFrameLabels.find(label) != mCurrentFrameLabels.end();
			if (isCurrent)
			{
				continue;
			}

			bool isVisible = label->updateFade(isCurrent);

			if (isVisible)
			{
				if (mDebugMode)
				{
					mLabelStates.push_back({ label });
					currentLabelState = &mLabelStates.back();
				}
				bufferLabel(screenSpaceManager, heightAtlas, *currentLabelState, cameraState);
			}
			else
			{
				toDelete.push_back(label);
			}
		}

		for (auto const& label : mCurrentFrameLabels)
		{
			label->updateFade(true);
			mOnscreenLabels.insert(label);
		}

		for (auto const& label : toDelete)
		{
			mOnscreenLabels.erase(label);
		}
	}
	
	float world[16];
	bx::mtxIdentity(world);

	for (auto const& styleBuffer : mStyleBufferHandles)
	{
		auto handle = styleBuffer.second;
		bgfx::setTransform(world);

		mTextBufferManager->submitTextBuffer(handle, (bgfx::ViewId)viewId);
	}
	
}

} }