#pragma once

#include <vector>
#include <thread>

#include "MapLabel.h"
#include "Tiles/TileId.h"

namespace onyx {
namespace DataObjects {

class LabelCollection
{
public:
	typedef std::shared_ptr<MapLabel> sharedLabel_t;

	~LabelCollection()
	{

		mLabels.clear();
		mCachedMapLabels.clear();
	}

	std::map<std::string, std::vector<sharedLabel_t>> mLabels;
	std::map<onyx::Tiles::TileId, std::map<std::string, std::vector<sharedLabel_t>>> mCachedMapLabels;

	mutable std::mutex mLock;

	/// <summary>
	/// Caches labels for a tile
	/// </summary>
	/// <param name="tileId"></param>
	/// <param name="bucket"></param>
	/// <param name="labels">Labels for tile; LabelCollection takes ownership of this vector</param>
	void cacheLabelsForTile(onyx::Tiles::TileId const& tileId, std::string bucket, std::vector<std::shared_ptr<MapLabel>> const& labels)
	{
		std::lock_guard<std::mutex> lock(mLock);
		if (mCachedMapLabels.find(tileId) != mCachedMapLabels.end() && mCachedMapLabels[tileId].find(bucket) != mCachedMapLabels[tileId].end())
		{
			mCachedMapLabels[tileId][bucket].clear();
		}
		mCachedMapLabels[tileId][bucket] = labels;
	}

	bool hasLabelsFor(onyx::Tiles::TileId const& tileId, std::string bucket)
	{
		return mCachedMapLabels.find(tileId) != mCachedMapLabels.end() && mCachedMapLabels[tileId].find(bucket) != mCachedMapLabels[tileId].end();
	}
	
	size_t totalLabels() const
	{
		size_t result = 0;

		for (auto const& labels : mLabels)
		{
			result += labels.second.size();
		}

		for (auto const& kvp : mCachedMapLabels)
		{
			for (auto const& labels : kvp.second)
			{
				result += labels.second.size();
			}
		}

		return result;
	}

	sharedLabel_t getLabel(lgal::world::Vector3 const & pos)
	{
		world_float_t dist = lucid::math::constants::max<world_float_t>();
		sharedLabel_t l = NULL;
		for (auto const& [key, labels] : mLabels)
		{
			for (auto const& label : labels)
			{
				auto d = len(label->getMapPosition() - pos);
				if (d < dist)
				{
					l = label;
					dist = d;
				}
			}
		}

		return l;
	}

	bool contains(std::string key) const
	{
		return mLabels.find(key) != mLabels.end();
	}

	void insert(std::string key, std::vector<sharedLabel_t> const& labels)
	{
		if (contains(key))
		{
			erase(key);
		}
		mLabels[key] = labels;
	}

	void append(std::string key, sharedLabel_t label)
	{
		mLabels[key].push_back(label);
	}

	void append(std::string key, std::vector<std::shared_ptr<MapLabel>> const& labels)
	{
		mLabels[key].insert(mLabels[key].end(), labels.begin(), labels.end());
	}

	void erase(std::string key)
	{
		std::lock_guard<std::mutex> lock(mLock);
		mLabels.erase(key);
	}
};

} }