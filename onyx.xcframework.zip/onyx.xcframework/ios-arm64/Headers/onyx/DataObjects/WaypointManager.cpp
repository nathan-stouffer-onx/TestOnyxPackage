#include "WaypointManager.h"

#include <bgfx/bgfx.h>
#include <bx/bx.h>
#include <bx/math.h>
#include <bimg/bimg.h>
#include <vector>
#include <algorithm>
#include <mutex>

#include "../Utils/BgfxUtils.h"
#include <Shaders/ShaderManager.h>
#include <Logging/LogManager.h>
#include "../Rendering/VertStructs.h"
#include "../Atlases/TextureAtlas.h"
#include "../Height/HeightManager.h"
#include "../General/RenderTargetManager.h"
#include <3rdParty/sole/ourSole.h>
#include "../Utils/jsonConversion.h"

using namespace lucid::gal;

#define SELECTED_PREFIX "selected-"
#define UNSELECTED_PREFIX "unselected-"

WaypointManager* WaypointManager::sSingleton = nullptr;
std::mutex WaypointManager::sMutex;
std::vector<uint16_t> WaypointManager::sIndices = { 0, 2, 3, 0, 3, 1 };

#define DISK_COLORS \
{ \
	{ 0xFFFF3300, 0xFFC92800 }, /* orange */		\
	{ 0xFF087AFF, 0xFF0056BB }, /* blue */			\
	{ 0xFF000000, 0xFF555555 }, /* black */			\
	{ 0xFF00FFFF, 0xFF298888 }, /* cyan */			\
	{ 0xFFFFFFFF, 0xFF555555 }, /* white */			\
	{ 0xFF800080, 0xFFFF00FF }, /* magenta */		\
	{ 0xFFFFFF00, 0xFF585650 }, /* yellow */		\
	{ 0xFFFF0000, 0xFF7F0000 }, /* red */			\
	{ 0xFF8B4513, 0xFF53290B }, /* brown */			\
	{ 0xFF84D400, 0xFF65B604 }, /* green */			\
}

WaypointManager* WaypointManager::Instance()
{
	{
		std::lock_guard lock(sMutex);
		if (sSingleton == nullptr)
		{
			sSingleton = new WaypointManager();
		}
	}

	return sSingleton;
}

void WaypointManager::Shutdown()
{
	if (sSingleton != nullptr)
	{
		delete sSingleton;
	}

	sSingleton = nullptr;
}

WaypointManager::WaypointManager(float size, float offset) :
	  mSize(size)
	, mOffset(offset)
	, mUnselectedPinTexHandle(BGFX_INVALID_HANDLE)
	, mSelectedPinTexHandle(BGFX_INVALID_HANDLE)
	, mWaypointAtlas(onyx::Atlases::TextureAtlas<std::string>(onyx::Atlases::cRenderFlags))
	, mDiskColors(DISK_COLORS)
{
	auto unselName = Waypoint::iconToFileName("unselectedWaypoint");
	auto selName = Waypoint::iconToFileName("selectedWaypoint");

	mUnselectedPinTexHandle = BgfxUtils::loadTexture(unselName);
	mSelectedPinTexHandle = BgfxUtils::loadTexture(selName);


	// Commenting these out for now until there's a good solution for system tests
	// MAP3D_ASSERT(bgfx::isValid(mUnselectedPinTexHandle), "Unable to load unselected waypoint texture " + unselName);
	// MAP3D_ASSERT(bgfx::isValid(mSelectedPinTexHandle), "Unable to load selected waypoint texture " + selName);

	if (!bgfx::isValid(mUnselectedPinTexHandle))
		logE("Unable to load unselected waypoint texture " + unselName);
	if (!bgfx::isValid(mSelectedPinTexHandle))
		logE("Unable to load selected waypoint texture " + selName);

	mProgram = ShaderManager::Instance()->getShaderHandle(ShaderEnums::ConfigurableShaders::BillboardFixedSize);

	sSingleton = this;
}

WaypointManager::~WaypointManager()
{
	std::lock_guard<std::mutex> lock(sMutex);
	mWaypoints.clear();								// using smart points so heap memory is automatically freed

	mWaypointBufferPoolIds.clear();

	for (auto& [slot, bufferPool] : mBufferPools)
	{
		bufferPool.clear();
	}

	if (bgfx::isValid(mUnselectedPinTexHandle))
	{
		bgfx::destroy(mUnselectedPinTexHandle);
	}
	if (bgfx::isValid(mSelectedPinTexHandle))
	{
		bgfx::destroy(mSelectedPinTexHandle);
	}

	for (auto& iconTex : mIconTexturesToDelete)
	{
		if (bgfx::isValid(iconTex.handle))
		{
			bgfx::destroy(iconTex.handle);
		}
	}
	mIconTexturesToDelete.clear();

	if (bgfx::isValid(mProgram))
	{
		bgfx::destroy(mProgram);
	}

	sSingleton = nullptr;
}

void WaypointManager::update()
{
	std::lock_guard<std::mutex> lock(sMutex);
	for (auto i = mIconTexturesToDelete.size(); i > 0; i--)
	{
		IconTex& iconTex = mIconTexturesToDelete[i - 1];
		if (iconTex.frameCount++ > 2)
		{
			if (bgfx::isValid(iconTex.handle))
			{
				bgfx::destroy(iconTex.handle);
			}
			mIconTexturesToDelete.erase(mIconTexturesToDelete.begin() + (i - 1));
		}
	}

	mWaypointAtlas.update();
}

void WaypointManager::draw(bgfx::ViewId viewId, onyx::Camera::CameraState const& cameraState)
{
	std::lock_guard<std::mutex> lock(sMutex);

	if (mWaypoints.size() == 0)
	{
		return;
	}

	// TODO figure out how to update vertices only when actually dirty
	//      we should render the waypoints at whatever height we have
	//      in the tiles. we need to figure out a nice way for waypoints
	//      to know if there have been updates (probably edit time or something)
	mIsDirty = true;

	if (mIsDirty) // generate vertex and index buffer
	{
		mIsDirty = false;
		for (auto& [slot, bufferPool] : mBufferPools)
		{
			bufferPool.clear();
		}

		mWaypointBufferPoolIds.clear();

		std::vector<WaypointVert_t> verts { 4 };
		for (auto& [uuid, wp] : mWaypoints)		// TODO frustum cull out waypoints not in the view
		{
			//std::string prefix = (wp->isSelected()) ? SELECTED_PREFIX : UNSELECTED_PREFIX;
			//std::string key = prefix + wp->getIcon();
			if (mWaypointAtlas.isReady(wp->getIconState()))
			{
				verts.clear();
				auto uvOffset = getIconTextureOffset(wp->getIconState());

				populateVerts(wp, cameraState.position, verts, uvOffset);

				onyx::Rendering::BufferPool<WaypointVert_t>& bufferPool = mBufferPools[wp->getIconState()];

				onyx::Rendering::BufferPoolId bufferPoolId;
				bufferPool.addVertsIndices(verts, sIndices, bufferPoolId);
				mWaypointBufferPoolIds[wp->getUuid()] = bufferPoolId;
			}
		}

		std::vector<std::string> empty;
		for (const auto& [key, bufferPool] : mBufferPools)	// slot may be a leftover from a user switching icons
		{
			if (bufferPool.numVerts() == 0)
			{
				empty.push_back(key);
			}
		}
		for (size_t i = 0u; i < empty.size(); ++i)			// erase empty buffers (can't do it above bc iterating)
		{
			mBufferPools.erase(empty[i]);
		}
	}

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_WRITE_A
		| BGFX_STATE_WRITE_Z
		| BGFX_STATE_MSAA
		| BGFX_STATE_BLEND_ALPHA;

	// if the camera is pointed mostly horizontal, perform depth clipping
	if (cameraState.pitch > lmath::constants::quarter_pi<world_float_t>())
	{
		state |= BGFX_STATE_DEPTH_TEST_LEQUAL;
	}

	// draw buffer pools
	for (auto& [key, bufferPool] : mBufferPools)
	{
		setUniforms(key, cameraState);
		bufferPool.draw(viewId, toBx(-cameraState.position), bx::Vec3(1), mProgram, state);
	}
}

void WaypointManager::populateVerts(sharedWaypoint_t wp, lgal::world::Vector3 const& eye, std::vector<WaypointVert_t>& verts, lgal::gpu::Vector4 const &uvOffset)
{
	lgal::world::Vector3 pos = toVec3(wp->getPosition());
	pos.z = HeightManager::Instance()->heightAt(pos.xy);

	auto relativePos = (pos - eye).as<float>();

	verts.resize(4);
	size_t vert = 0;
	for (size_t y = 0; y < 2; y++)			// compute the vertices
	{
		for (size_t x = 0; x < 2; x++)
		{
			lgal::gpu::Vector2 xy = { float32_t(x), float32_t(y) };

			WaypointVert_t &v = verts[vert++];

			// billboard position
			v.m_x = xy.x;
			v.m_y = xy.y;
			v.m_z = 0.f;

			// set waypoint colors
			v.m_abgr = wp->getOutlineColor().abgr();
			v.m_abgr2 = wp->getBodyColor().abgr();
			v.m_abgr3 = wp->getDiskColor().abgr();
			v.m_abgr4 = wp->getIconColor().abgr();

			// pack pivot position in the normal
			v.m_nx = relativePos.x;
			v.m_ny = relativePos.y;
			v.m_nz = relativePos.z;

			// set up the texture coordinates to map into the waypoint texture atlas
			//std::string prefix = (wp->isSelected()) ? SELECTED_PREFIX : UNSELECTED_PREFIX;
			//std::string iconKey = prefix + wp->getIcon();
			v.m_u = float32_t(uvOffset.x + Map3D_float_t(xy.x) * uvOffset.z);
			v.m_v = float32_t(uvOffset.y + Map3D_float_t(1 - xy.y) * uvOffset.w);	// TODO figure out how to match tex coord to quad vertex
		}
	}
}

void WaypointManager::setUniforms(const std::string& atlasKey, onyx::Camera::CameraState const& cameraState)
{
	ShaderParam* sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "s_texture0");
	if (sp != nullptr)
	{
		bgfx::TextureHandle handle = mWaypointAtlas.getTexHandle(atlasKey);
		int res = mWaypointAtlas.getResolution();
		sp->setValue(handle, res, res);
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_ScaleOffsetTex0");
	if (sp != nullptr)
	{
		sp->setValue(lgal::gpu::Vector4(0, 0, 1, 1));
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_billboardSize");
	if (sp != nullptr)
	{
		sp->setValue(bx::Vec3(mSize, mSize, 0));
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_bbOffset");
	if (sp != nullptr)
	{
		sp->setValue(mOffset);
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_eyePos");
	if (sp != nullptr)
	{
		sp->setValue(cameraState.position);
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_nearFarPlane");
	if (sp != nullptr)
	{
		auto n = cameraState.nearClip;
		auto f = cameraState.farClip;
		sp->setValue(lgal::world::Vector3(n, f, 0));
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_camRight");
	if (sp != nullptr)
	{
		sp->setValue(cameraState.rightDir());
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_camForward");
	if (sp != nullptr)
	{
		sp->setValue(cameraState.lookDir());
	}

	sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::BillboardFixedSize, "u_camUp");
	if (sp != nullptr)
	{
		sp->setValue(cameraState.upDir());
	}
}

std::shared_ptr<Waypoint> WaypointManager::addWaypoint(nlohmann::json json)
{
	sole::uuid uuid = sole::rebuild(json["uuid"]);

	sharedWaypoint_t result;

	{
		std::lock_guard<std::mutex> lock(sMutex);
		if (containsWaypointNoLock(uuid))
		{
			logE("Waypoint %s already exists, cannot add waypoint", uuid.str().c_str());
			return result;
		}
		from_json(json, result);		// TODO eventually parsing the json should be part of the receiving the bytes over the wire
		mWaypoints[uuid] = result;

		// compute disk color
		Color const& bodyColor = result->getBodyColor();
		uint32_t argb = bodyColor.argb();
		bool contains = mDiskColors.find(argb) != mDiskColors.end();
		Color const& diskColor = (contains) ? mDiskColors.at(argb) : 0xFF000000;

		// overwrite disk/outline colors because that info is not included in json
		result->setDiskColor(diskColor);
		result->setOutlineColor(bodyColor);

		mWaypointBufferPoolIds[uuid] = onyx::Rendering::BufferPoolId();
		mIsDirty = true;
	}

	addIconTexture(result->getIcon());

	return result;
	//bx::Vec3 pos = wp->getPosition();
	//float lat = MapMath::YToLat(pos.y);
	//float lon = MapMath::XToLon(pos.x);
	//logI("Added waypoint %s at %f, %f", uuid.str().c_str(), lat, lon);
}

std::shared_ptr<Waypoint> WaypointManager::addWaypoint(const sole::uuid& uuid, const bx::Vec3& pos, Color const& color)
{
	float height = HeightManager::Instance()->heightAt({ pos.x, pos.y });	// TODO figure out if this is actually how we want to handle height
	bx::Vec3 adjustedPos = bx::Vec3(pos.x, pos.y, height);

	std::shared_ptr<Waypoint> result;

	{
		std::lock_guard<std::mutex> lock(sMutex);
		if (containsWaypointNoLock(uuid))
		{
			logE("Waypoint %s already exists, cannot add waypoint", uuid.str().c_str());
			return result;
		}
		
		// compute disk color
		uint32_t argb = color.argb();
		bool contains = mDiskColors.find(argb) != mDiskColors.end();
		Color diskColor = (contains) ? mDiskColors.at(argb) : 0xFF000000;

		result = std::make_shared<Waypoint>(uuid);
		result->setPosition(adjustedPos);
		result->setBodyColor(color);
		result->setDiskColor(diskColor);
		result->setOutlineColor(color);

		mWaypoints[uuid] = result;
		mWaypointBufferPoolIds[uuid] = onyx::Rendering::BufferPoolId();
		mIsDirty = true;
	}

	addIconTexture(DEFAULT_WAYPOINT_ICON);		// this function only does work if the icon hasn't been loaded
	result->setIcon(DEFAULT_WAYPOINT_ICON);

	return result;
	//float lat = MapMath::YToLat(pos.y);
	//float lon = MapMath::XToLon(pos.x);
	//logI("Added waypoint %s at %f, %f", uuid.str().c_str(), lat, lon);
}

WaypointManager::sharedWaypoint_t WaypointManager::getWaypoint(const sole::uuid& uuid) const
{
	std::lock_guard<std::mutex> lock(sMutex);
	auto iter = mWaypoints.find(uuid);
	if (iter == mWaypoints.end())
	{
		return sharedWaypoint_t(nullptr);
	}
	return iter->second;
}

void WaypointManager::clearWaypoints()
{
	std::lock_guard<std::mutex> lock(sMutex);
	mWaypoints.clear();
	mWaypointBufferPoolIds.clear();
	mIsDirty = true;
}

void WaypointManager::deleteWaypoint(const sole::uuid& uuid)		// TODO maybe track how many waypoints use a texture?
{
    if (!containsWaypointNoLock(uuid))
    {
		logE("Waypoint %s not found, cannot delete waypoint", uuid.str().c_str());
		return;
    }

	{
		std::lock_guard<std::mutex> lock(sMutex);
		mWaypoints.erase(uuid);							// using smart pointer so heap memory is automatically freed
		mWaypointBufferPoolIds.erase(uuid);
		mIsDirty = true;
	}

	//logI("Deleted waypoint %s", uuid.str().c_str());
}

void WaypointManager::moveWaypointTo(const sole::uuid& uuid, const bx::Vec3& pos)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot move waypoint", uuid.str().c_str());
		return;
	}

	waypoint->setPosition(pos);
	mIsDirty = true;

	//float lat = MapMath::YToLat(pos.y);
	//float lon = MapMath::XToLon(pos.x);
	//logI("Moved waypoint %s to %f, %f", uuid.str().c_str(), lat, lon);
}

void WaypointManager::selectWaypoint(const sole::uuid& uuid)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot select waypoint", uuid.str().c_str());
		return;
	}

	waypoint->select();
	mIsDirty = true;

	//logI("Selected waypoint %s", uuid.str().c_str());
}

void WaypointManager::unselectWaypoint(const sole::uuid& uuid)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot unselect waypoint", uuid.str().c_str());
		return;
	}

	waypoint->unselect();
	mIsDirty = true;

	//logI("Unselected waypoint %s", uuid.str().c_str());
}

void WaypointManager::unselectAllWaypoints()
{
	std::vector<sole::uuid> toUnselect;
	{
		std::lock_guard<std::mutex> lock(sMutex);
		for (auto& [uuid, wp] : mWaypoints)
		{
			if (wp->isSelected())
			{
				toUnselect.push_back(uuid);
			}
		}
	}
	// mutex is locked and buffer is updated in unselectWaypoint()
	for (size_t i = 0u; i < toUnselect.size(); i++)
	{
		unselectWaypoint(toUnselect[i]);
	}

	//logI("All waypoints unselected");
}

void WaypointManager::deleteSelectedWaypoints()
{
	std::vector<sole::uuid> toDelete;
	{
		std::lock_guard<std::mutex> lock(sMutex);
		for (auto& [uuid, wp] : mWaypoints)
		{
			if (wp->isSelected())
			{
				toDelete.push_back(uuid);
			}
		}
	}
	for (size_t i = 0u; i < toDelete.size(); i++)
	{
		deleteWaypoint(toDelete[i]);
	}
	mIsDirty = true;

	//logI("Selected waypoints deleted");
}

void WaypointManager::setWaypointSize(float size)
{
	mSize = size;
	mIsDirty = true;
}

void WaypointManager::setWaypointIcon(const sole::uuid& uuid, const std::string& icon)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot change icon", uuid.str().c_str());
		return;
	}

	addIconTexture(icon);
	std::string prevIcon = waypoint->getIcon();

	waypoint->setIcon(icon);

	mIsDirty = true;		// reset buffers from scratch
	//logI("Changed icon from %s to %s on waypoint %s", prevIcon.c_str(), icon.c_str(), uuid.str().c_str());
}

void WaypointManager::setIconColor(const sole::uuid& uuid, const lucid::gal::Color& col)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot change icon color", uuid.str().c_str());
		return;
	}

	waypoint->setIconColor(col);
	mIsDirty = true;

	//logI("Changed icon color for waypoint %s", uuid.str().c_str());
}

void WaypointManager::setDiskColor(const sole::uuid& uuid, const lucid::gal::Color& col)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot change disk color", uuid.str().c_str());
		return;
	}

	waypoint->setDiskColor(col);
	mIsDirty = true;

	//logI("Changed disk color for waypoint %s", uuid.str().c_str());
}

void WaypointManager::setBodyColor(const sole::uuid& uuid, const lucid::gal::Color& col)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot change body color", uuid.str().c_str());
		return;
	}

	waypoint->setBodyColor(col);
	mIsDirty = true;

	//logI("Changed body color for waypoint %s", uuid.str().c_str());
}

void WaypointManager::setOutlineColor(const sole::uuid& uuid, const lucid::gal::Color& col)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot change outline color", uuid.str().c_str());
		return;
	}

	waypoint->setOutlineColor(col);
	mIsDirty = true;

	//logI("Changed outline color for waypoint %s", uuid.str().c_str());
}

sole::uuid WaypointManager::getWaypointUuid(const bx::Vec3& pos)
{
	std::lock_guard<std::mutex> lock(sMutex);

	sole::uuid closestUuid = nullUuid();
	float closest = bx::kFloatLargest;
	for (auto& [uuid, wp] : mWaypoints)		//change this to quadtree later, maybe use tiles for that?
	{
		float dist = bx::length(bx::sub(pos, wp->getPosition()));
		if (dist < closest)
		{
			closest = dist;
			closestUuid = uuid;
		}
	}

	return closestUuid;
}

std::vector<sole::uuid> WaypointManager::getAllWaypointUuids()
{
	std::lock_guard<std::mutex> lock(sMutex);
	std::vector<sole::uuid> uuids;
	for (auto& [uuid, wp] : mWaypoints)
	{
		uuids.push_back(uuid);
	}

	return uuids;
}

std::vector<sole::uuid> WaypointManager::getSelectedWaypointUuids()
{
	std::lock_guard<std::mutex> lock(sMutex);
	std::vector<sole::uuid> uuids;
	for (auto& [uuid, wp] : mWaypoints)
	{
		if (wp->isSelected())
		{
			uuids.push_back(uuid);
		}
	}

	return uuids;
}

std::vector<nlohmann::json> WaypointManager::getAllWaypointJsons()
{
	std::lock_guard<std::mutex> lock(sMutex);
	std::vector<nlohmann::json> waypoints;
	for (auto& [uuid, wp] : mWaypoints)
	{
		nlohmann::json j;
		to_json(j, wp);
		waypoints.push_back(j);
	}

	//logI("Retrieved json info for all waypoints");
	return waypoints;
}

std::vector<nlohmann::json> WaypointManager::getWaypointJsons(int start, int end)		// inclusive bounds
{
	std::lock_guard<std::mutex> lock(sMutex);
	std::vector<nlohmann::json> waypoints;
	if (start < 0 || end < 0 || end > start || end >= (int)mWaypoints.size())
	{
		logE("Requested for invalid range of waypoints [%d, %d]", start, end);
		return waypoints;
	}

	int i = 0;
	for (auto& [uuid, wp] : mWaypoints)
	{
		if (i >= start && i <= end)
		{
			nlohmann::json j;
			to_json(j, wp);
			waypoints.push_back(j);
		}
		i++;
	}

	//logI("Retrieved json info for %d waypoints (the range [%d, %d] as found in our std::map)", waypoints.size(), start, end);
	return waypoints;
}

bool WaypointManager::containsWaypointNoLock(sole::uuid uuid) const
{
	return mWaypoints.count(uuid) > 0;
}

bool WaypointManager::getWaypoint(sole::uuid uuid, sharedWaypoint_t& waypoint) const
{
	std::lock_guard<std::mutex> lock(sMutex);
	return getWaypointNoLock(uuid, waypoint);
}

bool WaypointManager::getWaypointNoLock(sole::uuid uuid, sharedWaypoint_t& waypoint) const
{
	if (!containsWaypointNoLock(uuid))
	{
		return false;
	}
	else
	{
		waypoint = mWaypoints.at(uuid);
		return true;
	}
}

bx::Vec3 WaypointManager::getWaypointPosition(const sole::uuid& uuid)
{
	std::shared_ptr<Waypoint> waypoint;
	if (!getWaypoint(uuid, waypoint))
	{
		logE("Waypoint %s not found, cannot return position", uuid.str().c_str());
		return bx::Vec3(0, 0, 0);
	}

	return waypoint->getPosition();
}

void WaypointManager::updateWaypointBuffer(lgal::world::Vector3 const& eye, const sole::uuid& uuid)
{
	std::lock_guard<std::mutex> lock(sMutex);

	sharedWaypoint_t wp;
	if (getWaypointNoLock(uuid, wp))
	{
		// figure out which buffer pool this waypoint is in
		//std::string prefix = (wp->isSelected()) ? SELECTED_PREFIX : UNSELECTED_PREFIX;
		//std::string key = prefix + wp->getIcon();
		onyx::Rendering::BufferPool<WaypointVert_t>& bufferPool = mBufferPools[wp->getIconState()];

		// populate a vertex buffer with this waypoint
		std::vector<WaypointVert_t> verts;
		auto uvOffset = getIconTextureOffset(wp->getIconState());

		populateVerts(wp, eye, verts, uvOffset);

		// set the vertices in the vertex buffer pool
		onyx::Rendering::BufferPoolId poolId = mWaypointBufferPoolIds[uuid];
		bufferPool.setVerts(poolId, verts);
	}
	else
	{
		logE("Waypoint %s not found, cannot update buffer", uuid.str().c_str());
	}
}

void WaypointManager::addIconTexture(const std::string& icon)
{
	std::lock_guard<std::mutex> lock(sMutex);

	std::string unselectedKey = UNSELECTED_PREFIX + icon;
	std::string selectedKey = SELECTED_PREFIX + icon;

	bool contains = mWaypointAtlas.contains(unselectedKey) && mWaypointAtlas.contains(selectedKey);
	if (!contains)
	{
		std::string fileName = Waypoint::iconToFileName(icon);
		bgfx::TextureInfo info;
		bgfx::TextureHandle iconTexHandle = BgfxUtils::loadTexture(fileName.c_str(), 0, 0, &info);

		if (bgfx::isValid(iconTexHandle))
		{
			std::vector<bgfx::TextureHandle> unselectedTextures = { mUnselectedPinTexHandle, iconTexHandle };
			std::vector<bgfx::TextureHandle> selectedTextures = { mSelectedPinTexHandle, iconTexHandle };
			mWaypointAtlas.insertMultiple(unselectedKey, unselectedTextures, info.format, false);
			mWaypointAtlas.insertMultiple(selectedKey, selectedTextures, info.format, false);

			// set up icon texture to be deleted after the TexAtlas completes the rtt
			mIconTexturesToDelete.push_back(IconTex{ iconTexHandle });
		}
	}
}

nlohmann::json WaypointManager::getJson() const
{
	nlohmann::json j;
	j["WaypointCount"] = mWaypoints.size();
	return j;
}
