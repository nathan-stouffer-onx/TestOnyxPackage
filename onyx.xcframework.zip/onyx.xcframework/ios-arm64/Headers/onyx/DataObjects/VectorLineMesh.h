#pragma once

#include <vector>

#include "../Rendering/VertStructs.h"
#include "../General/Drawable.h"

namespace onyx {
namespace DataObjects {

class VectorLineMesh : public Drawable<Rendering::VertStructs::PosUV>
{
public:
	VectorLineMesh();
	~VectorLineMesh();

	void generateVertsIndices() override;

	void setName(std::string name);
	bool isValid() const;
	void attach() const;

private:
	std::string mName;

	bgfx::VertexBufferHandle mVertexBuffer;
	bgfx::IndexBufferHandle mIndexBuffer;
};

} }

