#include "DashStyleManager.h"

#include <System/Map3DException.h>

namespace onyx {
namespace DataObjects {

std::unordered_map<std::string, bgfx::TextureHandle> DashStyleManager::mPatterns;

bgfx::TextureHandle DashStyleManager::add(std::string const& name, std::vector<uint8_t> const& pattern)
{
	MAP3D_ASSERT(mPatterns.find(name) == mPatterns.end(), std::string("dash pattern '" + name + "' is already defined"));

	auto width = uint32_t(pattern.size() * 8);

	auto mem = bgfx::alloc(width);

	auto data = static_cast<uint8_t*>(mem->data);
	for (auto byte : pattern)
	{
		for (int i = 0; i < 8; ++i)
		{
			(*data++) = (byte & (1 << i)) != 0 ? 0xFF : 0x00;
		}
	}

	auto handle = bgfx::createTexture2D(uint16_t(width), 1, false, 1, bgfx::TextureFormat::R8, 0, mem);

	mPatterns[name] = handle;

	return handle;
}

void DashStyleManager::remove(std::string const& name)
{
	auto found = mPatterns.find(name);
	if (found != mPatterns.end())
	{
		mPatterns.erase(name);
	}
}

bgfx::TextureHandle DashStyleManager::get(std::string const& name)
{
	MAP3D_ASSERT(mPatterns.find(name) != mPatterns.end(), std::string("dash pattern '" + name + "' is not defined"));

	return mPatterns[name];
}

void DashStyleManager::Shutdown()
{
	while (!mPatterns.empty())
	{
		auto entry = mPatterns.begin();
		if (bgfx::isValid(entry->second))
			bgfx::destroy(entry->second);
		mPatterns.erase(entry);
	}
}

} }
