#if !defined(_USER_MARKUP_H)
#define _USER_MARKUP_H
#pragma once

#include "DBObject.h"

namespace onyx {
namespace Storage {

	class UserMarkup : public DBObject
	{
	public:
		UserMarkup() : DBObject(0) { }
		UserMarkup(int argc, char** argv, char** azColName);

		GET_SET_PROP(Type, int, -1);
		GET_SET_PROP(Name, DBString, "");
		GET_SET_PROP(Notes, DBString, "");
		GET_SET_PROP(CreatedDate, DBString, "");
		GET_SET_PROP(UpdatedDate, DBString, "");
		GET_SET_PROP(GeoJson, DBString, "");
		GET_SET_PROP(Uuid, DBUuid, DBUuid({ 0, 0 }));
		GET_SET_PROP(OwnerUuid, DBUuid, DBUuid({ 0, 0 }));
	};

} }

#endif