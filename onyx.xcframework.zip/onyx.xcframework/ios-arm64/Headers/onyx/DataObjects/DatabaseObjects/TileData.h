#if !defined(_TILEDATA_H)
#define _TILEDATA_H
#pragma once

#include "DBObject.h"

#include "Tiles/TileId.h"

namespace onyx {
namespace Storage {

	class TileData : public DBObject
	{
	public:
		TileData() : DBObject() { }

		GET_SET_PROP(DataSourceId, int, -1);
		GET_SET_PROP(TileId, Tiles::TileId, (Tiles::TileId(-1, -1, -1)));
		DB_GET_SET_PROP(Data, DBBlob);
		GET_SET_PROP(Timestamp, double, 0);
		GET_SET_PROP(Persistent, bool, false);
		GET_SET_PROP(Version, int, -1);
		static inline std::string GetSelectTableSql()
		{
			return "SELECT Id, TileDataSourceId, Data, Level, X, Y, Timestamp, Persistent, Version FROM TileData";
		}

		static inline std::string GetInsertSql()
		{
			return "INSERT INTO TileData(TileDataSourceId, Data, Level, X, Y, Timestamp, Persistent, Version) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		}

		static inline std::string GetDeleteSql()
		{
			return "DELETE FROM TileData";
		}
	};

} }

#endif