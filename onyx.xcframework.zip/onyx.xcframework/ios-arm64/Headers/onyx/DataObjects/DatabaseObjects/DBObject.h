#if !defined(_DB_OBJECT_H)
#define _DB_OBJECT_H
#pragma once

/// TODO: This include is only here because for some reason, bx/math.h doesn't compile correctly
/// if it is included after sole.h.  Since Database objects will probably (unfortunately) use
/// UUIDs, I'm just including bx/math.h so that it won't cause mysterious build problems for
/// people.
#include <bx/math.h>

#include <string>
#include <memory>

#include <3rdParty/sole/ourSole.h>
#include "Utils/property.h"

namespace onyx {
namespace Storage {

#define DB_GET_SET_PROP(propName, typeName) private: std::shared_ptr<typeName> m##propName = nullptr;\
public: inline std::shared_ptr<typeName> const & get##propName() const { return m##propName; }\
inline void set##propName(typeName const &value)\
{\
	if (m##propName != nullptr && !(*(m##propName) == value)) return;\
	m##propName = std::make_shared<typeName>(value);\
	propertyChanged(#propName);\
}\
inline void clear##propName() { m##propName.reset(); }

	class DBObject
	{
	public:
		typedef uint32_t DBId_t;
		typedef std::string DBString;
		typedef sole::uuid DBUuid;
		typedef std::vector<uint8_t> DBBlob;

		static constexpr uint32_t cEmptyId = 0xFFFFFFFF;

		DBObject(uint32_t id = cEmptyId)
			: mId(id)
		{
		}

		GET_SET_PROP(Id, DBId_t, cEmptyId);
		GET_PROP(IsDirty, bool, false);
	protected:
		void propertyChanged(char const*)
		{
			mIsDirty = true;
		}

		inline void loadProperty(int & property, char const* data)
		{
			uint32_t value = atoi(data);
			property = value;
		}

		inline void loadProperty(std::shared_ptr<DBString> & property, char const* data)
		{
			property = std::make_shared<DBString>(data);
		}

		inline void loadProperty(std::shared_ptr<DBBlob>& property, char const*)
		{
			property = std::make_shared<DBBlob>();
		}

		inline void loadProperty(double& property, char const* data)
		{
			double value = atof(data);
			property = value;
		}

		template <typename T>
		inline void LOAD_PROPERTY(char const *propertyName, char const *colName, T &property, char const* data)
		{
			if (strcmp(colName, propertyName) == 0)
			{
				loadProperty(property, data);
			}
		}

	};

} }


#endif