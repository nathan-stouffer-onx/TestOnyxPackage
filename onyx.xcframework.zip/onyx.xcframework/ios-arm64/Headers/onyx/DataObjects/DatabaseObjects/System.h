#if !defined(_DBSYSTEM_H)
#define _DBSYSTEM_H
#pragma once

#include "DBObject.h"

namespace onyx {
namespace Storage {

	class System : public DBObject
	{
	public:
		System() : DBObject() { }

		GET_SET_PROP(Version, int, -1);
		DB_GET_SET_PROP(Notes, DBString);

		static inline std::string GetSelectTableSql()
		{
			return "SELECT Id, Version, Notes FROM System";
		}

		static inline std::string GetInsertSql()
		{
			return "INSERT INTO System(Version, Notes) VALUES (?, ?)";
		}
	};

} }

#endif