#ifndef __TRACKER_H__
#define __TRACKER_H__

#include <string>
#include <bx/bx.h>
#include <3rdParty/sole/ourSole.h>
#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>

#include "Utils/property.h"

enum class TrackerType
{
	Puck,
	Billboard,
	Model
};

/**
* Note: When deactivating a Tracker given through TrackerManager, call setInactive() instead of deleting it.
*/
class Tracker
{
public:
	Tracker();
	Tracker(sole::uuid const& uuid, TrackerType type);
	~Tracker();

	// Copies all but mUuid and mIsActive
	inline void copyTrackerStyle(Tracker const& tracker)
	{
		mIcon = tracker.getIcon();
		mHeadingAngleFromNorth = tracker.getHeadingAngleFromNorth();
		mType = tracker.getType();
		mPositionXY = tracker.getPositionXY();
		mOutlineColor = tracker.getOutlineColor();
		mBodyColor = tracker.getBodyColor();
		mArrowColor = tracker.getArrowColor();
		mIsOrientedToTerrain = tracker.getIsOrientedToTerrain();
	}

	GET_PROP(Uuid, sole::uuid, onyx::Utils::getUuid());
	GET_PROP(Icon, std::string, "");

	GET_PROP(IsActive, bool, false);
	inline void setInactive() { mIsActive = false; }

	GET_PROP(HeadingAngleFromNorth, lucid::gal::World_float_t, 0);
	inline void setHeadingAngleFromNorth(lucid::gal::World_float_t heading)
	{
		mHeadingAngleFromNorth = lucid::math::canonicalAngle(heading);
		propertyChanged("mHeadingAngleFromNorth");
	}

	GET_SET_PROP(Type, TrackerType, TrackerType::Puck);
	GET_SET_PROP(PositionXY, lgal::world::Vector2, lgal::world::Vector2{});
	GET_SET_PROP(OutlineColor, lgal::Color, 0xFFFF0000);
	GET_SET_PROP(BodyColor, lgal::Color, 0xFFFF0000);
	GET_SET_PROP(ArrowColor, lgal::Color, 0xFFFF0000);
	GET_SET_PROP(IsOrientedToTerrain, bool, false);

private:
	static const std::string cDefaultTrackerIcon;

	void propertyChanged(const char* /*propName*/) { }

	friend class TrackerManager;
};

#endif