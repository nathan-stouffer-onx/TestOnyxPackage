#ifndef FONT_MANAGER_H
#define FONT_MANAGER_H
#pragma once

#include <unordered_map>

#include <Styling/Styles/FontStyle.h>

#include "DataObjects/font/font_manager.h"

namespace onyx {
namespace Font {

	class M3DFontManager
	{
	public:
		static void Shutdown();
		static FontHandle getFont(Styling::FontFace const &face);
		static void addFontConfig(Styling::FontFace const& font, std::string ttfName);
		static void addTTF(std::string const &ttfName, std::string path);
		static void addTTF(std::string const& ttfName, uint8_t const* data, size_t size);
		static TrueTypeHandle loadTtf(std::string const& _filePath);
		static TrueTypeHandle loadTtf(uint8_t const* data, size_t size);

		static void initialize(::FontManager::FontConfiguration const& defaultFont);
		static FontManager* getFontManager() { return sFontManager; }
	private:
		static FontManager* sFontManager;
	};

	template<class T>
	Styling::FontFace randomFontFace(T const& param)
	{
		Styling::FontFace result;
		std::hash<T> hasher;
		auto hashed = hasher(param);

		switch (hashed & 0x3)
		{
			case 0:
				result.name = "default";
				break;
			case 1:
				result.name = "roboto regular";
				break;
			default:
				result.name = "roboto mono";
				break;
		}

		result.fontType = FONT_TYPE_DISTANCE_OUTLINE_DROP_SHADOW_IMAGE;
		result.pixelSize = 10 + ((hashed & 0x3FFF) / 0x800);
		return result;
	}

} }

#endif