#include "FontManager.h"

#include <set>

#include <System/FileSystem.h>

#include "System/Map3DException.h"


namespace onyx {
namespace Font {

	std::string const sDefaultFont = "default";
	std::unordered_map<Styling::FontFace, FontHandle> sFonts;
	std::unordered_map<std::string, TrueTypeHandle> sFontTTF;
	FontManager *M3DFontManager::sFontManager;

	void M3DFontManager::Shutdown()
	{
		for (auto& [name, handle] : sFonts)
		{
			if (handle.idx != bgfx::kInvalidHandle && name.pixelSize != 0)
				sFontManager->destroyFont(handle);
		}
		
		// keep track of which handles have already been destroyed, for fonts that 
		// get assigned to the default font because they are not otherwise available
		std::set<uint16_t> handles;

		for (auto& [name, handle] : sFontTTF)
		{
			if (handle.idx != bgfx::kInvalidHandle && handles.find(handle.idx) == handles.end())
			{
				sFontManager->destroyTtf(handle);
				handles.insert(handle.idx);
			}
		}

		sFonts.clear();
		sFontTTF.clear();
		if (sFontManager != nullptr)
		{
			delete sFontManager;
			sFontManager = nullptr;
		}
	}

	FontHandle M3DFontManager::getFont(Styling::FontFace const& face)
	{
		auto find = sFonts.find(face);
		if (find == sFonts.end())
		{
			addFontConfig(face, face.name);
		}

		return sFonts[face];
	}

	void M3DFontManager::initialize(FontManager::FontConfiguration const& defaultFont)
	{
		sFontManager = new FontManager(512);
		Styling::FontFace face = { sDefaultFont, defaultFont.fontType, defaultFont.pixelSize };
		
		MAP3D_ASSERT(!defaultFont.fileName.empty(), "default font file name cannot be empty");

		if (defaultFont.fontBytes == nullptr)
		{
			addTTF(face.name, defaultFont.fileName);
		}
		else
		{
			addTTF(face.name, defaultFont.fontBytes, defaultFont.fontDataSize);
		}

		sFontTTF[defaultFont.fileName] = sFontTTF[face.name];

		auto handle = sFontManager->createFontByPixelSize(sFontTTF[face.name], defaultFont.typefaceIndex, defaultFont.pixelSize, defaultFont.fontType, defaultFont.glyphWidthPadding, defaultFont.glyphHeightPadding);
		MAP3D_ASSERT(handle.idx != bgfx::kInvalidHandle, "Unable to create sized font");
		sFonts[face] = handle;
		face.pixelSize = 0;
		sFonts[face] = handle;
	}

	TrueTypeHandle M3DFontManager::loadTtf(uint8_t const* data, size_t size)
	{
		TrueTypeHandle handle = sFontManager->createTtf((uint8_t*)data, uint32_t(size));
		MAP3D_ASSERT(handle.idx != bgfx::kInvalidHandle, "Unable to create True Type Font");
		return handle;
	}

	TrueTypeHandle M3DFontManager::loadTtf(std::string const &_filePath)
	{
		uint32_t size;
		void* data = onyx::core::FileSystem::load(_filePath, &size);

		if (data != nullptr)
		{
			TrueTypeHandle handle = loadTtf((uint8_t*)data, size);// sFontManager->createTtf((uint8_t*)data, size);
			bx::free(onyx::core::FileSystem::getAllocator(), data);
			return handle;
		}

		MAP3D_THROW("Unable to load True Type Font data");
	}

	void M3DFontManager::addTTF(std::string const& ttfName, uint8_t const* data, size_t size)
	{
		auto handle = loadTtf(data, size);
		MAP3D_ASSERT(handle.idx != bgfx::kInvalidHandle, std::string("Unable to load font ") + ttfName + " bytes");

		sFontTTF[ttfName] = handle;
	}

	void M3DFontManager::addTTF(std::string const& ttfName, std::string path)
	{
		auto handle = loadTtf(path.c_str());
		MAP3D_ASSERT(handle.idx != bgfx::kInvalidHandle, std::string("Unable to load font: ") + path);
		sFontTTF[ttfName] = handle;
	}

	void M3DFontManager::addFontConfig(Styling::FontFace const &font, std::string ttfName)
	{

		sFonts[font] = sFontManager->createFontByPixelSize(sFontTTF[ttfName], 0, font.pixelSize, font.fontType);
	}

} }
