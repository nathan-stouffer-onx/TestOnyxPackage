#if !defined(CONFIGRESULT_H_)
#define CONFIGRESULT_H_

#include "lucid/gal/Types.h"
#include "ConfigHolder.h"
#include <System/Map3DException.h>

namespace onyx {

	struct ConfigResult
	{
		operator uint32_t()
		{
			if (ch->mValueType != ConfigHolder::ConfigType::vUint32)
				MAP3D_THROW("ConfigVal is not an uInt");
			return ch->uintVal;
		}

		operator int()
		{
			if (ch->mValueType != ConfigHolder::ConfigType::vInt)
				MAP3D_THROW("ConfigVal is not an Int");
			return ch->intVal;
		}
		operator lucid::gal::Map3D_float_t()
		{
			if (ch->mValueType != ConfigHolder::ConfigType::vM3DFloat)
				MAP3D_THROW("ConfigVal is not a M3dFloat");
			return ch->m3dFloatVal;
		}
		operator std::string()
		{
			if (ch->mValueType != ConfigHolder::ConfigType::vString)
				MAP3D_THROW("ConfigVal is not a String");
			return ch->stringVal;
		}
		operator lgal::world::Vector2()
		{
			if (ch->mValueType != ConfigHolder::ConfigType::vVec2)
				MAP3D_THROW("ConfigVal is not a Vec2");
			return ch->vec2Val;
		}
		operator lgal::world::Vector3()
		{
			if (ch->mValueType != ConfigHolder::ConfigType::vVec3)
				MAP3D_THROW("ConfigVal is not a Vec3");
			return ch->vec3Val;
		}


		ConfigHolder* ch;
	};
} 

#endif