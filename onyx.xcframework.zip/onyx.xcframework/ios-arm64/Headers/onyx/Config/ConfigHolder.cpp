#include "ConfigHolder.h"
#include <Logging/LogManager.h>
#include <3rdParty/nlohmann/json.hpp>
#include <System/Map3DException.h>
#include "ConfigResult.h"

namespace onyx {

	ConfigHolder::ConfigHolder(std::string key) { mKey = key; }
	ConfigHolder::~ConfigHolder() {}

	auto ConfigHolder::getConstant()
	{
		/*struct result
		{
			operator int()
			{
				if (ch->mValueType != ConfigType::vInt)
					MAP3D_THROW("ConfigVal is not an Int");
				return ch->intVal;
			}
			operator lucid::gal::Map3D_float_t()
			{
				if (ch->mValueType != ConfigType::vM3DFloat)
					MAP3D_THROW("ConfigVal is not a M3dFloat");
				return ch->m3dFloatVal;
			}
			operator std::string()
			{
				if (ch->mValueType != ConfigType::vString)
					MAP3D_THROW("ConfigVal is not a String");
				return ch->stringVal;
			}
			operator lucid::gal::Vector2()
			{
				if (ch->mValueType != ConfigType::vVec2)
					MAP3D_THROW("ConfigVal is not a Vec2");
				return ch->vec2Val;
			}
			operator lucid::gal::Vector3()
			{
				if (ch->mValueType != ConfigType::vVec3)
					MAP3D_THROW("ConfigVal is not a Vec3");
				return ch->vec3Val;
			}


			ConfigHolder* ch;
		};*/

		return ConfigResult{ this };
	}

	int ConfigHolder::hasKey(std::string key)
	{
		for (size_t i = 0; i < mConfigVars.size(); i++)
		{
			if (mConfigVars[i].mKey == key)
			{
				return int(i);
			}
		}

		return -1;
	}

	ConfigHolder* ConfigHolder::getNextHolder(std::vector<std::string> key)
	{
		if (key.size() == 0)
			return this;

		std::string thisOne = key[0];
		key.erase(key.begin());
		ConfigHolder* next = NULL;

		int id = hasKey(thisOne);
		if(id == -1)
		{
			logE("constant not found");
			return next; //constant not found
		}

		next = &mConfigVars[id];

		
		if (key.size() > 0)
			return next->getNextHolder(key);
		return next;
	}
}