#include "Wheel.h"

#include <limits>
#include <cmath>

#include <lucid/gal/Types.h>
#include "ButtonState.h"
#include "../Utils/Timer.h"
#include "../Config/ConfigManager.h"

using namespace lucid::gal;

namespace onyx {
namespace Input {
    INITCONFIGVALSTATIC(lucid::gal::Map3D_float_t, WheelSlidingWindowMS, "Input:WheelSlidingWindowMS", 350.0)

    static constexpr Utils::Timer::Map3D_time_t cStaleThresholdMS = 150.0;

    void Wheel::update(Utils::Timer::Map3D_time_t timeMS)
    {
        mPrevScrollState = mScrollState;
        
        // update scroll pos if we have pending updates
        if (mPending != lgal::input::Vector2{ 0, 0 })
        {
            mScrollState = { mScrollState.pos + mPending, ButtonState::Pressed, timeMS };
            mPending = { 0, 0 };
        }

        auto elapsed = timeMS - mScrollState.updateTimeMS;
        if (elapsed > cStaleThresholdMS && mScrollState.button == ButtonState::Pressed)
        {
            clear();
        }
    }

    void Wheel::clear()
    {
        mScrollState = { { 0, 0 }, ButtonState::Released, mScrollState.updateTimeMS };
        mPending = { 0, 0 };
    }

	void Wheel::addScrollClicks(lgal::input::Vector2 const& delta)
    {
        double scale = 1.0;
#if defined(PLATFORM_WINDOWS)
        scale = 0.625;
#elif defined(PLATFORM_OSX)
        scale = 0.1;
#elif defined(PLATFORM_EMSCRIPTEN)
        scale = 0.1;
#endif

        mPending = mPending + scale * delta;
    }

} }
