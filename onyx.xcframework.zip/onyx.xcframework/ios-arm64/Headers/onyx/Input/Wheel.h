#ifndef __WHEEL_H__
#define __WHEEL_H__

#include <limits>

#include <lucid/gal/Types.h>
#include "ButtonState.h"
#include "../Utils/Timer.h"
#include "../Config/ConfigManager.h"

namespace onyx {
namespace Input {

	DECLARECONFIGVALSTATIC(lucid::gal::Map3D_float_t, WheelSlidingWindowMS, "Input:WheelSlidingWindowMS")

	class Wheel
	{
	public:

		struct ScrollState
		{
			lgal::input::Vector2 pos;
			ButtonState button;
			Utils::Timer::Map3D_time_t updateTimeMS;

			ScrollState(lgal::world::Vector2 pos, ButtonState button, Utils::Timer::Map3D_time_t updateTimeMS) :
				pos(pos),
				button(button),
				updateTimeMS(updateTimeMS)
			{}
		};

		void update(Utils::Timer::Map3D_time_t timeMS);

		void clear();

		void addScrollClicks(lgal::input::Vector2 const& delta);

		inline ScrollState getPrevScrollState() const { return mPrevScrollState; }
		inline ScrollState getScrollState() const { return mScrollState; }

		inline ButtonState getButtonState() const { return mScrollState.button; }

	private:
		
		ScrollState mScrollState = { { 0, 0 }, ButtonState::Released, 0.0 };
		ScrollState mPrevScrollState = { { 0, 0 }, ButtonState::Released, 0.0 };

		lgal::input::Vector2 mPending = { 0, 0 };		// scroll clicks to be added on the next call to Wheel::update

	};

} }

#endif