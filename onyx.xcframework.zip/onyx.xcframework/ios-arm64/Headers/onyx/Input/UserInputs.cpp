#include "UserInputs.h"

#include <map>
#include <memory>
#include <functional>

#include "../Utils/MapMath.h"

#include "../Viewport/Viewport.h"
#include "../Viewport/ViewportManager.h"
#include "../Camera/CameraState.h"
#include "../Height/HeightManager.h"
#include "../Config/ConfigManager.h"

#include "../Camera/Controllers/InputHandlers/MouseOrbit.h"
#include "../Camera/Controllers/InputHandlers/MouseRotate.h"
#include "../Camera/Controllers/InputHandlers/MouseZoom.h"
#include "../Camera/Controllers/InputHandlers/Pan.h"
#include "../Camera/Controllers/InputHandlers/TouchOrbit.h"
#include "../Camera/Controllers/InputHandlers/TouchRotate.h"
#include "../Camera/Controllers/InputHandlers/WheelZoom.h"
#include "../Camera/Controllers/Animators/FlyTo2D.h"
#include "../Camera/Controllers/Animators/ZoomOn.h"

namespace ctlrs = onyx::Camera::Controllers;

using namespace lucid::gal;
using namespace onyx::Camera;

#define ALL_PARAMS_SIG [](CameraState const& initial, lgal::world::Vector3 const& focus, UserInputs const* input)
#define INIT_FOCUS_SIG [](CameraState const& initial, lgal::world::Vector3 const& focus, UserInputs const* /* input */)
#define INIT_INPUT_SIG [](CameraState const& initial, lgal::world::Vector3 const& /* focus */, UserInputs const* input)

namespace onyx {
namespace Input {

	// a threshold (in ms) that we must pass to allocate a new controller if the previous input state allocated a
	// controller. if the previous input state didn't allocate a controller, then this check should be ignored
	static constexpr Utils::Timer::Map3D_time_t cReleaseControllerThresholdMS = 30.0;

	// maximum depth value for the focus point when constructing a controller (prevents controllers being construced when
	// a user clicks on the sky)
	static constexpr float cMaxFocusDepth = 1.0;

	typedef std::function<std::shared_ptr<Camera::CameraController>(Camera::CameraState const&, lgal::world::Vector3 const&, UserInputs const*)> ControllerConstructorT;
	typedef Pointer::InteractionType PIT_t;	// convenience typedef for shorter code

	// TODO possibly make these attributes of a struct in UserInput so that they can be configurable at run time?
	static constexpr Map3D_float_t cZoomInScalar = 0.4;
	static constexpr Map3D_float_t cZoomOutScalar = 1.0 / cZoomInScalar;
	INITCONFIGVALSTATIC(Map3D_float_t, cZoomAnimationTimeMS, "Input:cZoomAnimationTimeMS", 400.0)

	static std::map<InputState, ControllerConstructorT> sControllerConstructors =
	{

		// a configuration for Pan controller (auto-compute pan plane)
		{ { ModifierButtons::None,									// no modifiers
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::SINGLE_TAP_DRAG } },							// pointer 0 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::Pan>(initial, focus, input->getPointer(0)); } },

		// a configuration for Pan controller (set pan plane with eye and look direction)
		{ { ModifierButtons::CtrlAlt,								// control and alt are down
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::SINGLE_TAP_DRAG } },							// pointer 0 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::Pan>(initial, focus, lgal::world::Plane{ initial.position, initial.lookDir() }, input->getPointer(0)); } },

		// a configuration for MouseRotate controller
		{ { ModifierButtons::Alt,									// just alt is down
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::SINGLE_TAP_DRAG } },							// pointer 0 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::MouseRotate>(initial, focus, input->getPointer(0)); } },

		// a configuration for MouseOrbit controller
		{ { ModifierButtons::None,									// no modifiers
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Released, ButtonState::Pressed },		// only pointer 1 is down
			{ PIT_t::NONE, PIT_t::SINGLE_TAP_DRAG } },				// pointer 1 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::MouseOrbit>(initial, focus, input->getPointer(1)); } },

		// a configuration for MouseOrbit controller
		{ { ModifierButtons::Ctrl,									// control is pressed
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::SINGLE_TAP_DRAG } },							// pointer 0 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::MouseOrbit>(initial, focus, input->getPointer(0)); } },
		
		// a configuration for MouseOrbit controller
		{ { ModifierButtons::Ctrl,									// control is pressed
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Released, ButtonState::Pressed },		// only pointer 1 is down
			{ PIT_t::NONE, PIT_t::SINGLE_TAP_DRAG } },				// pointer 1 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::MouseOrbit>(initial, focus, input->getPointer(1)); } },

		// a configuration for MouseZoom controller
		{ { ModifierButtons::None,									// no modifier buttons
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::DOUBLE_TAP_DRAG } },							// pointer 0 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::MouseZoom>(initial, focus, input->getPointer(0)); } },

		// a configuration for MouseZoom controller
		{ { ModifierButtons::Shift,									// shift is pressed
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::SINGLE_TAP_DRAG } },							// pointer 0 is a single tap drag
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::MouseZoom>(initial, focus, input->getPointer(0)); } },

		// a configuration for TouchOrbit controller
		{ { ModifierButtons::None,									// no modifier buttons
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed, ButtonState::Pressed },			// only pointers 0 and 1 are down
			{ PIT_t::SINGLE_TAP_DRAG, PIT_t::SINGLE_TAP_DRAG } },	// pointers 0 and 1 are single tap drags
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::TouchOrbit>(initial, focus, input->getPointer(0), input->getPointer(1)); } },

		// a configuration for TouchRotate controller
		{ { ModifierButtons::None,															// no modifier buttons
			ButtonState::Released,															// no mouse wheel
			{ ButtonState::Pressed, ButtonState::Pressed, ButtonState::Pressed },			// only pointers 0 and 1 and 2 are down
			{ PIT_t::SINGLE_TAP_DRAG, PIT_t::SINGLE_TAP_DRAG, PIT_t::SINGLE_TAP_DRAG } },	// pointers 0 and 1 are double tap drags
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::TouchRotate>(initial, focus, input->getPointer(0), input->getPointer(1), input->getPointer(2)); } },

		// a configuration for WheelZoom controller
		{ { ModifierButtons::None,									// no modifier buttons
			ButtonState::Pressed,									// mouse wheel is active
			{ },													// no pointers are down
			{ } },													// pointer states are all none
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::WheelZoom>(initial, focus, input->getWheel()); } },

		// a configuration for WheelZoom controller (enables pinch zoom on our ThinkPad laptops)
		{ { ModifierButtons::Ctrl,									// control is pressed
			ButtonState::Pressed,									// mouse wheel is active
			{ },													// no pointers are down
			{ } },													// pointer states are all none
			ALL_PARAMS_SIG { return std::make_shared<ctlrs::WheelZoom>(initial, focus, input->getWheel()); } },

		// a configuration for WheelZoom controller (zoom straight down)
		{ { ModifierButtons::Shift,									// shift is pressed
			ButtonState::Pressed,									// mouse wheel is active
			{ },													// no pointers are down
			{ } },													// pointer states are all none
			INIT_INPUT_SIG { return std::make_shared<ctlrs::WheelZoom>(initial, HeightManager::Instance()->lockToTerrain({ initial.position.x, initial.position.y }), input->getWheel()); } },

		// a configuration for ZoomOn controller
		{ { ModifierButtons::None,									// no modifier buttons
			ButtonState::Released,									// no mouse wheel
			{ },													// no pointers are down
			{ PIT_t::DOUBLE_TAP } },								// pointer 0 is a double tap
			INIT_FOCUS_SIG { return std::make_shared<ctlrs::ZoomOn>(initial, focus, cZoomInScalar, cZoomAnimationTimeMS); } },

		// a configuration for ZoomOn controller
		{ { ModifierButtons::None,									// no modifier buttons
			ButtonState::Released,									// no mouse wheel
			{ },													// no pointers are down
			{ PIT_t::PRE_SINGLE_TAP, PIT_t::PRE_SINGLE_TAP } },		// pointers 0 and 1 are pre-single taps
			INIT_FOCUS_SIG { return std::make_shared<ctlrs::ZoomOn>(initial, focus, cZoomOutScalar, cZoomAnimationTimeMS); } },

		// a configuration for ZoomOn controller
		{ { ModifierButtons::None,									// no modifier buttons
			ButtonState::Released,									// no mouse wheel
			{ },													// no pointers are down
			{ PIT_t::DOUBLE_TAP, PIT_t::DOUBLE_TAP } },				// pointers 0 and 1 are double taps
			INIT_FOCUS_SIG { return std::make_shared<ctlrs::ZoomOn>(initial, focus, cZoomOutScalar, cZoomAnimationTimeMS); } },

		// a configuration for FlyTo2D controller
		{ { ModifierButtons::None,									// no modifer buttons
			ButtonState::Released,									// no mouse wheel
			{ ButtonState::Pressed },								// only pointer 0 is down
			{ PIT_t::DOUBLE_TAP_LONG_PRESS } },						// pointer 0 is a double tap long press
			INIT_FOCUS_SIG { return std::make_shared<ctlrs::FlyTo2D>(initial, lgal::world::Vector2{ focus.x, focus.y }, MapMath::Spherical{ initial.heading, initial.pitch, 10.0 }); } },

	};

	UserInputs::UserInputs()
	{
		for (auto& pointer : mPointers)
		{
			pointer = std::make_shared<Pointer>();
		}
	}

	lgal::world::Vector2 UserInputs::focusPosition() const
	{
		auto active = activePointers();

		if (active.size() == 0)
		{
			return mPointers[0]->getPosition();
		}
		else
		{
			lgal::world::Vector2 sum = { 0.0, 0.0 };
			for (auto const& pointer : active)
			{
				sum = sum + pointer->getPosition();
			}
			return sum / world_float_t(active.size());
		}
	}

	void UserInputs::update(Utils::Timer::Map3D_time_t timeMS)
	{
		// update the pointers and mouse
		{
			for (auto& pointer : mPointers)
			{
				pointer->update(timeMS);
			}
			mWheel->update(timeMS);
		}

		// compute the input state
		InputState next = { mModifierButtonState, mWheel->getButtonState(), 
									Pointer::toButtonState<cMaxPointers>(mPointers),
									Pointer::toInteractionTypes<cMaxPointers>(mPointers) };

		if (next != mInputState)
		{
			mShouldConstructController = UserInputs::allowable(mInputState, next);
			mInputState = next;
			mInputStateUpdateTimeMS = timeMS;
			mPrevConstructedController = mConstructedController;
			mConstructedController = false;
			mFiredEvents = false;
		}

		if (mShouldConstructController && !mConstructedController)
		{
			auto elapsed = timeMS - mInputStateUpdateTimeMS;
			if (!mPrevConstructedController || elapsed > cReleaseControllerThresholdMS)
			{
				bool contains = sControllerConstructors.find(mInputState) != sControllerConstructors.end();
				if (contains)
				{
					// get the relevant pointer and viewport
					auto screenPos = focusPosition();

					// compute the input viewport and world position of the pointer in that viewport
					auto inputViewport = ViewportManager::Instance()->getViewportByNormalized(screenPos);
					lgal::world::Vector2 viewportPos = inputViewport->getState()->convertGlobalToViewportCoords(screenPos);
					auto depth = inputViewport->depthAtNormalized(viewportPos.as<gpu_float_t>());
					if (depth <= cMaxFocusDepth)
					{
						lgal::world::Vector3 worldPos = inputViewport->unprojectNormalized(viewportPos);
						Camera::CameraState const initial = inputViewport->getCameraState();

						// construct and set the appropriate controller
						std::shared_ptr<Camera::CameraController> controller = sControllerConstructors.at(mInputState)(initial, worldPos, this);
						inputViewport->setController(controller);
						mConstructedController = true;
					}
				}
			}
		}

		if (!mFiredEvents)
		{
			mFiredEvents = true;
			// TODO fire appropriate events here (ie tap, long press, and such)
		}
	}

	bool UserInputs::allowable(InputState const prev, InputState const next)
	{
		// we should not construct a controller when transferring from pinch to wheel zoom on
		// windows. we do this because windows seems to signify a pinch zoom by "pressing" Ctrl.
		// many times, the second finger is lifted early and Ctrl is no longer pressed. this
		// would trigger the construction of a new zoom controller that cancels out the existing
		// zooming controller and causes the camera to jump. returning false here avoids this case
		if (prev == InputState{ ModifierButtons::Ctrl, ButtonState::Pressed, {}, {} }			// pinch zoom on windows
			&& next == InputState{ ModifierButtons::None, ButtonState::Pressed, {}, {} })		// wheel zoom on windows
		{
			return false;
		}

		// made it through all edge cases, return true as default
		return true;
	}

} }
