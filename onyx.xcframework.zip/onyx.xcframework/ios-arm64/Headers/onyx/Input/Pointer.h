#ifndef __POINTER_H__
#define __POINTER_H__

#include <limits>
#include <memory>
#include <array>

#include <lucid/gal/Types.h>

#include <System/Map3DException.h>
#include <Utils/EnumUtils.h>

#include "ButtonState.h"
#include "Utils/Timer.h"
#include "Config/ConfigManager.h"

namespace onyx {
namespace Input {

	// millisecond window from the initial tap that we look for a second tap
	DECLARECONFIGVALSTATIC(lucid::gal::Map3D_float_t, cTapWindowMS, "Input:cTapWindowMS")

	// millisecond threshold after a double tap until we consider the input stale
	DECLARECONFIGVALSTATIC(lucid::gal::Map3D_float_t, cDoubleTapStaleInputThresholdMS, "Input:cDoubleTapStaleInputThresholdMS")

	// millisecond threshold to consider a tap a long press
	DECLARECONFIGVALSTATIC(lucid::gal::Map3D_float_t, cLongPressThresholdMS, "Input:cLongPressThresholdMS")

	// fallback stale threshold if we are not resetting input appropriately
	DECLARECONFIGVALSTATIC(lucid::gal::Map3D_float_t, cStaleInputFallbackThresholdMS, "Input:cStaleInputFallbackThresholdMS")

	class Pointer
	{
	public:

		// NOTE: we only use 3 bits of a uint8_t. if we exceed that, be sure to update the hash function Input::InputState to accomodate more bits
		enum class InteractionType : uint8_t
		{
			NONE = 0x0,					// no interaction at all
			PRE_SINGLE_TAP,				// pointer was down -> up at the same spot in a short time, but we are still waiting to see if it will be a double tap
			SINGLE_TAP,					// pointer was down -> up at the same spot in a short time
			SINGLE_TAP_DRAG,			// pointer was down -> moving in a relatively short time
			SINGLE_TAP_LONG_PRESS,		// pointer was down for a somewhat long time in the same spot
			DOUBLE_TAP,					// pointer was down -> up (at same spot) -> down (at same spot) -> up (at same spot) in a short time
			DOUBLE_TAP_DRAG,			// pointer was down -> up (at same spot) -> down (at same spot) -> move in a relatively short time
			DOUBLE_TAP_LONG_PRESS,		// pointer was down -> up (at same spot) -> down (at same spot) for a somewhat long time
		};

		void update(Utils::Timer::Map3D_time_t timeMS);

		void down(Utils::Timer::Map3D_time_t timeMS = Utils::Timer::nowMS());
		void up(Utils::Timer::Map3D_time_t timeMS = Utils::Timer::nowMS());

		void setPosition(lgal::input::Vector2 const& position, double newPressure);

		inline ButtonState getState() const
		{
			if (mTaps.size() == 0)
			{
				return ButtonState::Released;
			}
			else
			{
				return (mTaps.back().isDown()) ? ButtonState::Pressed : ButtonState::Released;
			}
		}
		inline InteractionType getInteractionType() const { return mInteractionType; }

		inline lgal::input::Vector2 getPosition() const { return mPosition; }
		inline lgal::input::Vector2 getDownPosition() const
		{
			MAP3D_ASSERT(mTaps.size() > 0, "Pointer has not yet been pressed");
			return mTaps.back().downPos;
		}

		inline float getPressure() const { return float(mPressure); }

		inline int getTapCount() const { return int(mTaps.size()); }

		template<int NUM>
		static inline std::array<ButtonState, NUM> toButtonState(std::array<std::shared_ptr<Pointer>, NUM> const& pointers)
		{
			std::array<ButtonState, NUM> state = {};
			for (size_t i = 0; i < pointers.size(); i++)
			{
				state[i] = pointers[i]->getState();
			}
			return state;
		}

		template<int NUM>
		static inline std::array<InteractionType, NUM> toInteractionTypes(std::array<std::shared_ptr<Pointer>, NUM> const& pointers)
		{
			std::array<InteractionType, NUM> interactions = {};
			for (size_t i = 0; i < pointers.size(); i++)
			{
				interactions[i] = pointers[i]->getInteractionType();
			}
			return interactions;
		}

	private:

		// Clip-space coordinates; -x left, -y up
		lgal::input::Vector2 mPosition = { 0.0, 0.0 };

		bool mHasMoved = false;

		InteractionType mInteractionType = InteractionType::NONE;

		// struct that represents a Tap. to construct it, you must provide a down time to construct it
		struct Tap
		{
			Utils::Timer::Map3D_time_t downTimeMS;
			lgal::input::Vector2 downPos;
			
			Utils::Timer::Map3D_time_t upTimeMS = std::numeric_limits<Utils::Timer::Map3D_time_t>::max();
			lgal::input::Vector2 upPos = { 0.0, 0.0 };

			Tap(Utils::Timer::Map3D_time_t downTimeMS, lgal::input::Vector2 downPos) :
				downTimeMS(downTimeMS),
				downPos(downPos)
			{}

			inline bool isDown() const { return upTimeMS == std::numeric_limits<Utils::Timer::Map3D_time_t>::max(); }
			inline bool isUp() const { return !isDown(); }
		};

		std::vector<Tap> mTaps;

		inline void reset()
		{
			mTaps.clear();
			mHasMoved = false;
		}

		static InteractionType detectInteractionType(Utils::Timer::Map3D_time_t timeMS, bool hasMoved, std::vector<Tap> const& taps);

		double mPressure = 0;

	};

} }

namespace std
{

	inline std::string_view toStringView(onyx::Input::Pointer::InteractionType const& value)
	{
		static std::unordered_map<onyx::Input::Pointer::InteractionType, std::string_view> const nameMap =
		{
			{ onyx::Input::Pointer::InteractionType::NONE,					"NONE" },
			{ onyx::Input::Pointer::InteractionType::PRE_SINGLE_TAP,			"PRE_SINGLE_TAP" },
			{ onyx::Input::Pointer::InteractionType::SINGLE_TAP,				"SINGLE_TAP" },
			{ onyx::Input::Pointer::InteractionType::SINGLE_TAP_DRAG,			"SINGLE_TAP_DRAG" },
			{ onyx::Input::Pointer::InteractionType::SINGLE_TAP_LONG_PRESS,	"SINGLE_TAP_LONG_PRESS" },
			{ onyx::Input::Pointer::InteractionType::DOUBLE_TAP,				"DOUBLE_TAP" },
			{ onyx::Input::Pointer::InteractionType::DOUBLE_TAP_DRAG,			"DOUBLE_TAP_DRAG" },
			{ onyx::Input::Pointer::InteractionType::DOUBLE_TAP_LONG_PRESS,	"DOUBLE_TAP_LONG_PRESS" },
		};
		return onyx::Utils::stringViewFromMap(value, nameMap, "enum Input::Pointer::InteractionType");
	}

}

#endif