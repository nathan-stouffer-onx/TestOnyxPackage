#ifndef __TILE_PYRAMID_H__
#define __TILE_PYRAMID_H__

#include <unordered_map>
#include <memory>

#include "Tiles/TileId.h"

namespace onyx {
namespace Pyramid {

	/*
	* A class to store a pyramid of tiles. An owning class can insert, erase, and search for tiles. A specific tile can be searched for
	* by using TilePyramid::find which will look only for the requested tile. Or the pyramid's best approximation of the requested tile
	* can be searched for using TilePyramid::findHighestDetail which will search for the requested tile but fallback to a lower detail 
	* tile if the pyramid has it.
	*/
	
	template<typename T>
	class TilePyramid
	{
	public:

		TilePyramid() {}
		~TilePyramid() {}

		inline void insert(std::shared_ptr<T> const& item)
		{
			mTiles.insert({ item->id(), item });
		}

		inline bool contains(Tiles::TileId const& tileId) const
		{
			return mTiles.find(tileId) != mTiles.end();
		}
		
		inline void erase(Tiles::TileId const& tileId)
		{
			mTiles.erase(tileId);
		}

		inline std::shared_ptr<T const> at(Tiles::TileId const& tileId) const
		{
			return mTiles.at(tileId);
		}

		inline std::shared_ptr<T> const& at(Tiles::TileId const& tileId)
		{
			return mTiles.at(tileId);
		}

		// searches the pyramid for the requested tile. when recurse is true, will fallback to low detail tiles
		// returns nullptr if the pyramid does not have the requested data
		std::shared_ptr<T> find(Tiles::TileId const& tileId, bool recurse) const
		{
			std::shared_ptr<T> data = find(tileId);

			if (!data && recurse)	// no data was found and we need to recurse
			{
				// search the pyramid starting at the first parent
				for (int i = tileId.level - 1; !data && i >= 0; --i)
				{
					Tiles::TileId ancestor = tileId.parentAtLevel(i);
					data = find(ancestor);
				}
			}

			return data;
		}

	private:

		inline std::shared_ptr<T> find(Tiles::TileId const& tileId) const
		{
			auto found = mTiles.find(tileId);
			return (found != mTiles.end()) ? found->second : nullptr;
		}

		std::unordered_map<Tiles::TileId, std::shared_ptr<T>> mTiles;

	};

} }

#endif