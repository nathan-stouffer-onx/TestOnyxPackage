#ifndef __ICON_RENDERER_H__
#define __ICON_RENDERER_H__

#include <Shaders/ShaderDefinition.h>
#include <Styling/Sprite.h>
#include <Styling/Layers/Layer.h>
#include <Styling/Sources/GeojsonSource.h>

#include "Utils/MapMath.h"
#include "Atlases/TextureAtlas.h"
#include "Camera/CameraState.h"
#include "Tiles/IconTile.h"
#include "Tiles/TileRenderInfo.h"
#include "Atlases/HeightAtlas.h"

namespace onyx {
namespace Icon {

// Draws icons from a set of tiles and layers

class IconRenderer
{
public:
	IconRenderer();
	~IconRenderer();

	void update();

	void loadSprite(std::string const& url);
	
	void draw(bgfx::ViewId const viewId, Camera::CameraState const& cam, 
		std::vector<Tiles::IconTile> const& tiles,
		Atlases::HeightAtlas const& heightAtlas,
		std::vector<std::shared_ptr<Styling::SymbolLayer const>> const& layers);

	// TODO (Ronald): Delete these settings. They are only meant as debug methods
	inline bool getIconsHidden() { return mHideIcons; }
	inline void setIconsHidden(bool hideIcons = true) { mHideIcons = hideIcons; }
	inline void setDepthBias(float depthBias) { mDepthBias = depthBias; }
	inline float getDepthBias() { return mDepthBias; }
	inline void setIconScale(float iconScale) { mIconScale = iconScale; }
	inline float getIconScale() { return mIconScale; }

	void setOrientToMap(bool orientToMap = true) { 
		mOrientToMap = orientToMap; 
		mShaderDirty = true;
	}
	inline bool getOrientToMap() { return mOrientToMap; }

private:
	using UniqIconAtlas_t = std::unique_ptr<Atlases::TextureAtlas<std::string>>;
	using SharedShader_t = std::shared_ptr<Shaders::ShaderDefinition>;
	using InstVert_t = Rendering::VertStructs::InstanceData5;
	using QuadVert_t = Rendering::VertStructs::PosUV;

private:
	UniqIconAtlas_t mIconAtlas;

	Shaders::ConfigurableShader mIconShader;

	// For per-icon instanced gpu data
	bgfx::DynamicVertexBufferHandle mVBufHndl = BGFX_INVALID_HANDLE;

	// for static quad info (quad corner positions and texture coordinates)
	bgfx::VertexBufferHandle mQuadVBufHndl = BGFX_INVALID_HANDLE;

	static std::array<Rendering::VertStructs::PosUV, 4> sQuadVerts;

	bool mHideIcons = true;
	float mDepthBias = 0.01f;
	float mIconScale = 0.0005f;
	bool mOrientToMap = false;
	bool mShaderDirty = true;

private:
	SharedShader_t getIconShader(std::shared_ptr<Styling::SymbolLayer const> const& layer);

	void setUniforms(SharedShader_t const program,
		Tiles::TileInfo const& tileId,
		Camera::CameraState const& cam,
		Atlases::HeightAtlas const& heightAtlas, 
		Styling::IconStyle const& iconStyle
	);

	void fillInstBuffer(
		std::vector<InstVert_t>& output,
		std::vector<lgal::gpu::Vector2> points,
		Styling::IconStyle const& iconStyle
	);

};

} }

#endif
