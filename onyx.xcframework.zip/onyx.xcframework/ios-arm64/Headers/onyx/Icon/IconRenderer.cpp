#include "IconRenderer.h"

#include <Shaders/ShaderManager.h>
// TODO (Ronald): Temp until IconRenderer is fully integrated
#include <Styling/Parse/SpriteJson.h>
#include <Utils/StringUtils.h>

#include "Utils/BgfxUtils.h"
// TODO (Ronald): Temp until IconRenderer is fully integrated
#include "json/jsonParsing.h"

namespace onyx {
namespace Icon {

typedef Atlases::TextureAtlas<std::string> Atlas_t;

/*
	Size 2 quad centered at (0, 0, 0)
	Quad layout
	0---2
	|	|
	1---3
*/
std::array<IconRenderer::QuadVert_t, 4> IconRenderer::sQuadVerts =
{
	QuadVert_t {
		{ -1.f, 1.f, 0.f },		// position
		{ 0.f, 1.f }			// uv
	},
	QuadVert_t {
		{ -1.f, -1.f, 0.f },	// position
		{ 0.f, 0.f }			// uv
	},
	QuadVert_t {
		{ 1.f, 1.f, 0.f },		// position
		{ 1.f, 1.f }			// uv
	},
	QuadVert_t {
		{ 1.f, -1.f, 0.f },		// position
		{ 1.f, 0.f }			// uv
	}
};

IconRenderer::IconRenderer() :
	mIconAtlas{ nullptr },
	mVBufHndl(BGFX_INVALID_HANDLE),
	mQuadVBufHndl(BGFX_INVALID_HANDLE)
{
	mVBufHndl = bgfx::createDynamicVertexBuffer(
		100, 
		Rendering::VertStructs::InstanceData5::ms_layout,
		BGFX_BUFFER_ALLOW_RESIZE
	);

	mQuadVBufHndl = bgfx::createVertexBuffer(
		bgfx::makeRef(
			sQuadVerts.data(),
			uint32_t(sizeof(QuadVert_t) * sQuadVerts.size())
		),
		QuadVert_t::ms_layout
	);
}

IconRenderer::~IconRenderer()
{
	BgfxUtils::tryDestroy(mVBufHndl);
	BgfxUtils::tryDestroy(mQuadVBufHndl);
}

void IconRenderer::update()
{
	if (mIconAtlas != nullptr)
	{
		mIconAtlas->update();
	}
}

void IconRenderer::loadSprite(std::string const& url)
{
	// Clear the previous spritesheet
	mIconAtlas = std::make_unique<Atlas_t>(
		Atlases::cRenderFlags,
		Atlases::cDefaultCellSize,
		Atlases::cDefaultResolution,
		0, // Loading spritesheets all at once. No padding
		"IconRenderer - Spritesheet Atlas"
		);

	// Extract the last three parts of the url
	auto names = Utils::splitString(url, '/');
	auto const numNames = names.size();
	MAP3D_ASSERT(numNames >= 3, "Sprite URL should at least have [app]/[version number]/[spritesheet name]");

	// Create a file path
	std::string spritePath = "assets/spritesheets";
	for (size_t i = numNames - 3; i < numNames; ++i)
	{
		spritePath += '/' + names[i];
	}

	// create a sprite stylesheet
	const std::string jsonExt = ".json";
	auto spritesheet = ParseJsonFile<Styling::Sprite>(spritePath + jsonExt);
	spritesheet.name = url.substr(url.find_last_of('/') + 1);

	// load the sprite atlas texture
	const std::string pngExt = ".png";
	std::string atlasPngPath = spritePath + pngExt;
	bgfx::TextureInfo texInfo;
	auto texHndl = BgfxUtils::loadTexture(atlasPngPath, 0, 0, &texInfo);
	MAP3D_ASSERT(bgfx::isValid(texHndl), "Failed to load spritesheet texture");

	std::vector<Atlas_t::SpriteIdx> idxs;
	idxs.reserve(spritesheet.indices.size());
	for (auto const& spriteIdx : spritesheet.indices)
	{
		// load into the SpriteIdx array
		Atlases::PageLocation pgLoc;
		pgLoc.position = lgal::screen::Vector2{
			screen_coord_t(spriteIdx.x), screen_coord_t(spriteIdx.y) };
		pgLoc.size = lgal::screen::Vector2{
			screen_coord_t(spriteIdx.width), screen_coord_t(spriteIdx.height)
		};
		idxs.push_back({ spriteIdx.name, pgLoc });
	}

	mIconAtlas->insertSpritesFull(texHndl, spritesheet.name, texInfo, idxs);
}

void IconRenderer::fillInstBuffer(
	std::vector<InstVert_t>& output,
	std::vector<lgal::gpu::Vector2> points,
	Styling::IconStyle const& iconStyle
)
{

	for (auto const& tilePnt : points)
	{
		/// Instance data layout
		/// TODO (Ronald): Orientation will be moved to be generated shader side
		/// TODO (Ronald): Colors will be handled by Atlases in the future
		///		1) Icon Position (canonical tile coords)
		///		2) Scale (x,y)
		///		3) Orientation represented by quaternion
		///		4) Color 1
		///		5) Color 2
		InstVert_t vert;

		// 1)
		vert.data[0] = lgal::gpu::Vector4{ tilePnt.x, tilePnt.y, 0, 0 };

		// 2) 
		auto const& spriteName = iconStyle.iconImage;
		MAP3D_DEBUG_ASSERT(spriteName != "", "Sprite name should not be empty");
		MAP3D_DEBUG_ASSERT(mIconAtlas->isReady(spriteName), "This function should be called when the sprite is ready");
		auto spriteSize = mIconAtlas->getPageLocation(spriteName).size;
		auto scale = lgal::gpu::Vector2{ iconStyle.iconSize };
		scale = hadamard(scale, spriteSize.as<gpu_float_t>());
		vert.data[1] = lgal::gpu::Vector4{ scale.x, scale.y, 0, 0 };

		// 3) 
		vert.data[2] = lgal::gpu::Vector4{ 0, 0, 0, 1 };

		// 4) Color 1
		lgal::Color const& col0 = iconStyle.iconColor;
		vert.data[3] = { col0.r, col0.g, col0.b, col0.a };

		// 5) Color 2
		vert.data[4] = { 0, 0, 0, 0 };

		output.push_back(vert);
	}
}

void IconRenderer::draw(bgfx::ViewId const viewId, Camera::CameraState const& cam, 
		std::vector<Tiles::IconTile> const& tiles,
		Atlases::HeightAtlas const& heightAtlas,
		std::vector<std::shared_ptr<Styling::SymbolLayer const>> const& layers)
{
	// TODO (Ronald): Remove sHideIcons once design matures
	if (mHideIcons) return;

	// TODO (Ronald): Currently we treat each tile point as if the layer is assigned that tile point
	// We need a way for IconRenderer to associate layers to the data it is pointed to
	std::vector<InstVert_t> instanceBuf;
	for (auto const& layer : layers)
	{

		// TODO (scott) hook evaluate up correctly
		auto iconStyle = layer->realizeIconStyle({ { }, 1, 1 });

		// Skip image if atlas has not loaded sprite yet
		if (!mIconAtlas->isReady(iconStyle.iconImage)) 
		{
			logI("Icon sprite " + iconStyle.iconImage + " is not ready");
			continue; 
		}

		for (auto const& tile : tiles)
		{
			// TODO (Ronald): Need to set up a fallback algorithm for if we don't have the height ready for this tile (Also maybe keep an invalid height tile?) 
			if (!heightAtlas.isReady(tile.tInfo.id)) { 
				logI("No height information for tile available");
				continue; 
			}

			// update render info buffer
			fillInstBuffer(instanceBuf, tile.points, iconStyle);

			// Update gpu instance buffer
			auto numInstVerts = instanceBuf.size();
			auto* mem = bgfx::copy((void*)instanceBuf.data(), uint32_t(sizeof(InstVert_t) * numInstVerts));
			MAP3D_DEBUG_ASSERT(bgfx::isValid(mVBufHndl), "Vertex buffer should be initialized before draw call");
			bgfx::update(mVBufHndl, 0, mem);

			uint64_t renderState = 0
				| BGFX_STATE_PT_TRISTRIP
				| BGFX_STATE_WRITE_RGB
				| BGFX_STATE_WRITE_A
				| BGFX_STATE_WRITE_Z
#ifdef ENABLE_MSAA
				| BGFX_STATE_MSAA
#endif
				| BGFX_STATE_BLEND_ALPHA;

			// if the camera is pointed mostly horizontal, perform depth clipping
			if (cam.pitch > lmath::constants::quarter_pi<world_float_t>())
			{
				renderState |= BGFX_STATE_DEPTH_TEST_LEQUAL;
			}

			auto iconShaderDef = getIconShader(layer);
			setUniforms(iconShaderDef, tile.tInfo, cam, heightAtlas, iconStyle);

			bgfx::setState(renderState);
			bgfx::setInstanceDataBuffer(mVBufHndl, 0, uint32_t(numInstVerts));
			bgfx::setVertexBuffer(0, mQuadVBufHndl);
			bgfx::submit(viewId, iconShaderDef->mInstancedHandle);
		}
	}
}

IconRenderer::SharedShader_t IconRenderer::getIconShader(
	std::shared_ptr<Styling::SymbolLayer const> const& /*layer*/)
{
	//auto const& layout = layer->getLayout();

	if (!mIconShader.count())
	{
		mIconShader.loadSignature(ShaderManager::Defaults::Icon);
	}

	// TODO (Ronald): Add a cache for most often used shaders either here in Icons namespace or in ConfigurableShaders
	// Any shader change will probably cause us to use the filesystem, which is not ideal for the main thread,
	// especially if we're rendering icons with different shaders on the same screen.
	/*
	switch (layout->iconPitchAlignment)
	{
	case Styling::SymbolLayout::PitchAlignOpts::Map:
		//mIconShader.loadSignature("IconBase-T-T-T-2-1_TextureLayer-1_FixedSize-F_DepthBias_TerrainHeight");
		mIconShader.toggleComponent("IconBillboard", false);
		break;
	case Styling::SymbolLayout::PitchAlignOpts::Viewport:
	case Styling::SymbolLayout::PitchAlignOpts::Auto:
	default:
		mIconShader.toggleComponent("IconBillboard", true);
		break;
	}
	*/
	if (mShaderDirty)
	{
		if (mOrientToMap)
		{
			mIconShader.loadSignature("IconBase-T-T-T-0-1_TextureLayer-1_FixedSize-F_DepthBias_TerrainHeight");
		}
		else
		{
			mIconShader.loadSignature(ShaderManager::Defaults::Icon);
		}
		mShaderDirty = false;
	}

	MAP3D_DEBUG_ASSERT(mIconShader.count(), "No icon shader has been loaded!");
	return mIconShader.getShader(0);
}

void IconRenderer::setUniforms(SharedShader_t const program,
	Tiles::TileInfo const& tileInfo,
	Camera::CameraState const& cam,
	Atlases::HeightAtlas const& heightAtlas,
	Styling::IconStyle const& iconStyle
)
{
	// Icon texture
	auto const& spriteName = iconStyle.iconImage;
	auto texHndl = mIconAtlas->tryGetTexHandle(spriteName);
	auto res = mIconAtlas->getResolution();
	MAP3D_DEBUG_ASSERT(bgfx::isValid(texHndl), "Invalid texture handle for iconRenderer atlas");
	auto uvOffset = mIconAtlas->getUVOffset(spriteName);
	program->setParameter("s_texture0", texHndl, res, res);
	program->setParameter("u_ScaleOffsetTex0", uvOffset);

	// Terrain height
	auto const& tileId = tileInfo.id;
	res = heightAtlas.getResolution();
	texHndl = heightAtlas.tryGetTexHandle(tileId);
	MAP3D_DEBUG_ASSERT(bgfx::isValid(texHndl), "Invalid texture handle for height atlas");
	uvOffset = heightAtlas.getUVOffset(tileId);
	program->setParameter("s_heightTextureVert", texHndl, res, res);
	program->setParameter("u_ScaleOffsetHeight", uvOffset);
	program->setParameter("u_tileSize", lgal::gpu::Vector3{ 1 });
	program->setParameter("u_tileDistortion", lgal::world::Vector3{ tileInfo.distortion, 0 });

	// Tile bounds
	auto tileMin = lgal::world::Vector3{ tileId.northwestCorner(), MapMath::cMinHeight } - cam.position;
	auto tileMax = lgal::world::Vector3{ tileId.southeastCorner(), MapMath::cMaxHeight } - cam.position;
	program->setParameter("u_tileMin", tileMin);
	program->setParameter("u_tileMax", tileMax);

	// depth bias
	program->setParameter("u_depthModifier", mDepthBias);

	// camera
	program->setParameter("u_camRight", cam.rightDir());
	program->setParameter("u_camUp", cam.upDir());

	// overall scale
	program->setParameter("u_scale", lgal::gpu::Vector3{ mIconScale, 0, 0 });
}

} }
