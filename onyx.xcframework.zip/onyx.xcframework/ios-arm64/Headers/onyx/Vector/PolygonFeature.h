#ifndef __VECTOR_POLYGON_FEATURE_H__
#define __VECTOR_POLYGON_FEATURE_H__

#include <lucid/gal/Types.h>

#include "Vector/Feature.h"

namespace onyx {
namespace Vector {

	class PolygonFeature final : public Feature
	{
	public:

		static constexpr tile_float_t cGutterProportion = 5.f / 256.f;
	
	public:

		PolygonFeature(lgal::tile::Holygon const& holygon, Feature::PropertiesT const& properties = {});
		PolygonFeature(std::vector<lgal::tile::Holygon>&& holygons, Feature::PropertiesT const& properties = {});

		std::shared_ptr<Feature const> subFeature(lgal::tile::AABB2d const& aabb, bool relative) const override;

		std::vector<lgal::tile::Vector2> const& points() const override;
		std::vector<lgal::world::Vector2> toWorld(lgal::world::AABB2d const& bounds) const override;

		std::vector<lgal::tile::Holygon> const& geometries() const { return mHolygons; }

	private:

		std::vector<lgal::tile::Holygon> const mHolygons;

	};

} }

#endif