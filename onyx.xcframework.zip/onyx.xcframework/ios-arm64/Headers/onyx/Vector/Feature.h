#ifndef __VECTOR_FEATURE_H__
#define __VECTOR_FEATURE_H__

#include <vector>
#include <memory>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

#include <lucid/gal/Types.h>

namespace onyx {
namespace Vector {

	/*
	* Feature is a pure virtual base class representing an item contained in mapbox vector tile layer. It can be one of four 
	* types: UNKNOWN, POINT, LINESTRING, POLYGON. We have chosen these names to match up exactly with the vector tile spec.
	* 
	* Some critical methods are:
	*   - Feature::subFeatures -- Given an aabb, this method will return the intersection of the Feature with that aabb. This is
	*                             realized as a std::vector of Features. It may be empty, it may contain a single feature, and
	*                             it may contain multiple features. All features will be of the same type as the parent Feature
	*   - Feature::metadata ----- Returns const access to metadata for evaluation in stylesheet expressions and platform queries
	* 
	* https://github.com/mapbox/vector-tile-spec/tree/master/2.1#42-features
	*/

	class Feature
	{
	public:

		using PropertiesT = std::unordered_map<std::string, vector_tile::Tile_Value>;
		using FeatureCollectionT = std::vector<std::shared_ptr<Feature const>>;
	
		enum class Type
		{
			UNKNOWN,
			POINT,
			LINESTRING,
			POLYGON
		};

		Feature(Type const type, lgal::tile::AABB2d const aabb, PropertiesT const& properties, size_t derivedByteCount) :
			mType(type),
			mAABB(aabb),
			mProperties(properties),
			mByteCount(derivedByteCount + Feature::CountPropertiesBytes(properties))
		{}
		
		virtual ~Feature() {}

		// Given an aabb, this method will return the intersection of the Feature with that aabb. This
		// is realized as a std::vector of Features. It may be empty, it may contain a single feature,
		// or it may contain multiple features -- it depends on how the Feature intersects with the
		// aabb. All features will be of the same type as the parent Feature. The parameter 'relative'
		// is used to determine whether the resulting sub-features should be returned in coordinates 
		// relative to the passed in aabb.
		virtual std::shared_ptr<Feature const> subFeature(lgal::tile::AABB2d const& aabb, bool relative) const = 0;

		inline lgal::tile::AABB2d aabb() const { return mAABB; }

		// TODO I am introducing these functions to get labels working, but I do not think they should stick
		// around in the long term. We should refactor to get rid of this as soon as possible
		virtual std::vector<lgal::tile::Vector2> const& points() const = 0;
		virtual std::vector<lgal::world::Vector2> toWorld(lgal::world::AABB2d const& bounds) const = 0;

		inline Type type() const { return mType; }

		inline PropertiesT const& properties() const { return mProperties; }

		inline size_t byteCount() const { return mByteCount; }

	public:

		static size_t CountPropertiesBytes(PropertiesT const& properties)
		{
			size_t count = 0;
			for (auto const& [key, value] : properties)
			{
				count += sizeof(std::string::value_type) + key.capacity();
				count += value.ByteSizeLong();
			}
			return count;
		}

	protected:

		Type const mType;

		lgal::tile::AABB2d const mAABB;

		PropertiesT const mProperties;

		size_t const mByteCount;

	};

} }

#endif