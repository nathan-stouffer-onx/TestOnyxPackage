#include "LinestringFeature.h"

#include <Utils/Memory.h>

namespace onyx {
namespace Vector {

	LinestringFeature::LinestringFeature(lgal::tile::Polyline const& polyline, Feature::PropertiesT const& properties) :
		LinestringFeature(std::vector<lgal::tile::Polyline>{ polyline }, properties)
	{}

	LinestringFeature::LinestringFeature(std::vector<lgal::tile::Polyline>&& polylines, Feature::PropertiesT const& properties) :
		Feature(Feature::Type::LINESTRING, lmath::fit<std::vector>(polylines), properties, Utils::countBytes(polylines)),
		mPolylines(polylines)
	{}

	std::shared_ptr<Feature const> LinestringFeature::subFeature(lgal::tile::AABB2d const& aabb, bool relative) const
	{
		std::vector<lgal::tile::Polyline> polylines;
		if (lmath::intersectsOrTouches(aabb, mAABB) != lmath::Intersections::NONE)
		{
			for (lgal::tile::Polyline const& polyline : mPolylines)
			{
				if (lmath::intersectsOrTouches(aabb, polyline.aabb()) != lmath::Intersections::NONE)
				{
					std::vector<lgal::tile::Polyline> subPolylines = lmath::clip(polyline, aabb);
					polylines.insert(polylines.end(), subPolylines.begin(), subPolylines.end());	
				}
			}

			if (relative)   // if necessary, transform to relative coordinates
			{
				for (lgal::tile::Polyline& polyline : polylines)
				{
					lgal::tile::Vector2 dim = aabb.length();
					lgal::tile::Vector2 scale{ 1.0f / dim.x, 1.0f / dim.y };
					polyline.translate(-aabb.min);
					polyline.scale(scale);
				}
			}

		}

		return (polylines.empty()) ? nullptr : std::make_shared<LinestringFeature const>(std::move(polylines), Feature::properties());
	}

	std::vector<lgal::tile::Vector2> const& LinestringFeature::points() const
	{
		return mPolylines.front().points();
	}

	std::vector<lgal::world::Vector2> LinestringFeature::toWorld(lgal::world::AABB2d const& bounds) const
	{
		std::vector<lgal::world::Vector2> points;

		points.reserve(mPolylines.front().size());

		for (lgal::tile::Vector2 const& point : mPolylines.front().points())
		{
			lgal::world::Vector2 world = lmath::lerp(bounds.min, bounds.max, point.as<world_float_t>());
			points.push_back(world);
		}

		return points;
	}

} }