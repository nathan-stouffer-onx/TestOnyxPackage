#include "PolygonFeature.h"

#include <array>

#include <Utils/Memory.h>

namespace onyx {
namespace Vector {

	PolygonFeature::PolygonFeature(lgal::tile::Holygon const& holygon, Feature::PropertiesT const& properties) :
		PolygonFeature(std::vector<lgal::tile::Holygon>{ holygon }, properties)
	{}

	PolygonFeature::PolygonFeature(std::vector<lgal::tile::Holygon>&& holygons, Feature::PropertiesT const& properties) :
		Feature(Feature::Type::POLYGON, lmath::fit<std::vector>(holygons), properties, Utils::countBytes(holygons)),
		mHolygons(holygons)
	{}

	std::shared_ptr<Feature const> PolygonFeature::subFeature(lgal::tile::AABB2d const& aabb, bool relative) const
	{
		std::vector<lgal::tile::Holygon> holygons;

		// compute the bounding box we will clip against
		lgal::tile::Vector2 offset = cGutterProportion * aabb.length();
		lgal::tile::AABB2d against = { aabb.min - offset, aabb.max + offset };

		if (lmath::intersectsOrTouches(against, mAABB) != lmath::Intersections::NONE)
		{
			for (lgal::tile::Holygon const& holygon : mHolygons)
			{
				if (lmath::intersectsOrTouches(against, holygon.aabb()) != lmath::Intersections::NONE)
				{
					std::array<lgal::tile::Vector2, 4> vertices = lmath::clockwise(against);
					lgal::tile::Holygon clipped = lmath::clip(holygon, vertices);

					if (!clipped.empty())
					{
						// TODO possibly branch outside the for loop for better performance -- but more maintenance
						if (relative)	// if necessary, transform to relative coordinates
						{
							// TODO we can do this more efficiently (fewer allocations) but building features is more important right now
							lgal::tile::Vector2 dim = aabb.length();
							lgal::tile::Vector2 scale{ 1.0f / dim.x, 1.0f / dim.y };
							lgal::tile::Holygon transformed = clipped.translate(-aabb.min).scale(scale);

							// add to vector of features
							holygons.push_back(transformed);
						}
						else
						{
							// add to vector of features
							holygons.push_back(clipped);
						}
					}
				}
			}
		}

		return (holygons.empty()) ? nullptr : std::make_shared<PolygonFeature const>(std::move(holygons), Feature::properties());
	}

	std::vector<lgal::tile::Vector2> const& PolygonFeature::points() const
	{
		return mHolygons.front().hull().getPoints();
	}

	std::vector<lgal::world::Vector2> PolygonFeature::toWorld(lgal::world::AABB2d const& bounds) const
	{
		std::vector<lgal::world::Vector2> points;
		points.reserve(mHolygons.front().hull().size());

		for (lgal::tile::Vector2 const& point : mHolygons.front().hull().getPoints())
		{
			lgal::world::Vector2 world = lmath::lerp(bounds.min, bounds.max, point.as<world_float_t>());
			points.push_back(world);
		}

		return points;
	}

} }