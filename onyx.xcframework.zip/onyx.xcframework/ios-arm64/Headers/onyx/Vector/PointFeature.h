#ifndef __VECTOR_POINT_FEATURE_H__
#define __VECTOR_POINT_FEATURE_H__

#include <lucid/gal/Types.h>

#include "Vector/Feature.h"

namespace onyx {
namespace Vector {

	class PointFeature final : public Feature
	{
	public:

		PointFeature(lgal::tile::Vector2 const& point, Feature::PropertiesT const& properties = {});
		PointFeature(std::vector<lgal::tile::Vector2>&& points, Feature::PropertiesT const& properties = {});

		std::shared_ptr<Feature const> subFeature(lgal::tile::AABB2d const& aabb, bool relative) const override;

		std::vector<lgal::tile::Vector2> const& points() const override;
		std::vector<lgal::world::Vector2> toWorld(lgal::world::AABB2d const& bounds) const override;

		std::vector<lgal::tile::Vector2> const& geometries() const { return mPoints; }


	private:

		std::vector<lgal::tile::Vector2> const mPoints;

	};

} }

#endif