#include "Layer.h"

#include <Utils/Memory.h>

#include "Vector/FeatureFactory.h"

namespace onyx {
namespace Vector {

	Layer::Layer(vector_tile::Tile::Layer const& layer, time_float_t timestampMS) :
		mName(layer.name()),
		mTimestampMS(timestampMS)
	{
		// TODO (stouff) eventually check the version field of a layer

		float extent = (float)layer.extent();
		for (int i = 0; i < layer.features_size(); ++i)
		{
			std::shared_ptr<Feature const> feature = Factory::feature(layer.features(i), extent, layer.keys(), layer.values());
			if (feature)
			{
				mFeatures.push_back(feature);
			}
		}

		mByteCount = Utils::countBytes(mFeatures);
	}

	Layer::Layer(std::string const& name, std::shared_ptr<Feature const> feature, time_float_t timestampMS) :
		Layer(name, std::vector<std::shared_ptr<Feature const>>{ feature }, timestampMS) {}

	Layer::Layer(std::string const& name, std::vector<std::shared_ptr<Feature const>> const& features, time_float_t timestampMS) :
		mName(name),
		mFeatures(features),
		mTimestampMS(timestampMS),
		mByteCount(Utils::countBytes(features))
	{}

	std::shared_ptr<Layer const> Layer::subLayer(lgal::tile::AABB2d const& subregion) const
	{
		std::vector<std::shared_ptr<Feature const>> features;

		for (std::shared_ptr<Feature const> feature : mFeatures)
		{
			std::shared_ptr<Feature const> subFeature = feature->subFeature(subregion, true);
			if (subFeature)
			{
				features.push_back(subFeature);
			}
		}

		// NOTE: pass in mConstructionTimeMS so all overzoomed tiles match this time
		return std::make_shared<Layer const>(mName, features, mTimestampMS);
	}


} }