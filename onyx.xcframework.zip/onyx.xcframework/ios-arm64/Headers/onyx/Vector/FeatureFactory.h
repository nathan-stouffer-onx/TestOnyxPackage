#ifndef __VECTOR_FEATURE_FACTORY_H__
#define __VECTOR_FEATURE_FACTORY_H__

#include <memory>

#include "Vector/Feature.h"
#include "Vector/PointFeature.h"
#include "Vector/LinestringFeature.h"
#include "Vector/PolygonFeature.h"

namespace onyx {
namespace Vector {
namespace Factory {

	using KeyCollectionT = google::protobuf::RepeatedPtrField<std::string>;
	using ValueCollectionT = google::protobuf::RepeatedPtrField<vector_tile::Tile_Value>;

	std::unique_ptr<PointFeature const> point(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values);
	std::unique_ptr<LinestringFeature const> linestring(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values);
	std::unique_ptr<PolygonFeature const> polygon(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values);

	std::unique_ptr<Feature const> feature(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values);

} } }

#endif