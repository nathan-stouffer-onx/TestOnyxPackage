#include "PointFeature.h"

namespace onyx {
namespace Vector {

	PointFeature::PointFeature(lgal::tile::Vector2 const& point, Feature::PropertiesT const& properties) :
		PointFeature(std::vector<lgal::tile::Vector2>{ point }, properties)
	{}

	PointFeature::PointFeature(std::vector<lgal::tile::Vector2>&& points, Feature::PropertiesT const& properties) :
		Feature(Feature::Type::POINT, lmath::fit<std::vector>(points), properties, lgal::tile::Vector2::byteCount() * points.capacity()),
		mPoints(std::move(points))
	{}

	std::shared_ptr<Feature const> PointFeature::subFeature(lgal::tile::AABB2d const& aabb, bool relative) const
	{
		std::vector<lgal::tile::Vector2> points;
		if (lmath::intersectsOrTouches(mAABB, aabb) != lmath::Intersections::NONE)
		{
			for (lgal::tile::Vector2 const& point : mPoints)
			{
				if (aabb.contains(point))
				{
					// TODO possibly branch outside the for loop for better performance -- but more maintenance
					if (relative)
					{
						lgal::tile::Vector2 dimensions = aabb.length();
						lgal::tile::Vector2 translated = (point - aabb.min);
						lgal::tile::Vector2 transformed = { translated.x / dimensions.x, translated.y / dimensions.y };
						points.push_back(transformed);
					}
					else
					{
						points.push_back(point);
					}
				}
			}
		}

		return (points.empty()) ? nullptr : std::make_shared<PointFeature>(std::move(points), Feature::properties());
	}

	std::vector<lgal::tile::Vector2> const& PointFeature::points() const
	{
		return mPoints;
	}

	std::vector<lgal::world::Vector2> PointFeature::toWorld(lgal::world::AABB2d const& bounds) const
	{
		std::vector<lgal::world::Vector2> worldCoords;
		worldCoords.reserve(mPoints.size());
		for (lgal::tile::Vector2 const& point : mPoints)
		{
			lgal::world::Vector2 interped = lmath::lerp(bounds.min, bounds.max, point.as<world_float_t>());
			worldCoords.push_back(interped);
		}
		return worldCoords;
	}

} }