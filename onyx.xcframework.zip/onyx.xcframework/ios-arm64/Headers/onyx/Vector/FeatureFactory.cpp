#include "FeatureFactory.h"

#include <System/Map3DException.h>
#include <Warnings.h>

namespace onyx {
namespace Vector {
namespace Factory {

	static lgal::tile::AABB2d const sUnitBounds = lgal::tile::AABB2d::unit();

	DISABLE_WARNING_PUSH;
	DISABLE_WARNING_UNARY_MINUS_APPLIED_TO_UNSIGNED;
	inline static int DecodeParameterInt(uint32_t val)
	{
		// https://github.com/mapbox/vector-tile-spec/tree/master/2.1#432-parameter-integers
		return (((int)(val >> 1)) ^ (int)(-(val & 1)));
	}
	DISABLE_WARNING_POP;

	static Feature::PropertiesT Properties(vector_tile::Tile_Feature const& feature, KeyCollectionT const& keys, ValueCollectionT const& values)
	{
		Feature::PropertiesT properties;
		properties.reserve(static_cast<size_t>(feature.tags_size() / 2));

		for (int i = 0; i < feature.tags_size(); i += 2)
		{
			// grab indices for key and value
			int k = feature.tags(i);
			int v = feature.tags(i + 1);

			// grab actual key and value
			std::string const& key = keys[k];
			vector_tile::Tile_Value const& value = values[v];

			// insert to metadata
			properties[key] = value;
		}

		return properties;
	}

	std::unique_ptr<PointFeature const> point(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values)
	{
		DISABLE_WARNING_PUSH;
		DISABLE_WARNING_UNUSED_VARIABLE;

		// compute command id and count -- spec requires this to a MoveTo command with count greater than 0
		uint32_t commandInt = feature.geometry(0);
		uint32_t id = commandInt & 0x7;
		uint32_t count = commandInt >> 3;

		MAP3D_DEBUG_ASSERT(id == 1, "Command in Point geometry must be MoveTo");
		MAP3D_DEBUG_ASSERT(count > 0, "Command count must be greater than 0");
		MAP3D_DEBUG_ASSERT(2 * count + 1 == static_cast<uint32_t>(feature.geometry_size()), "Point geometry should consist of only a single MoveTo command");

		DISABLE_WARNING_POP;

		// create points and reserve the appropriate number
		std::vector<lgal::tile::Vector2> points;
		points.reserve(count);

		// comput extent inverse -- do it once so we multiply instead divide later
		float extentInv = 1.0f / extent;

		lgal::tile::Vector2 cursor = { 0, 0 };
		for (uint32_t i = 0; i < count;)
		{
			int dx = DecodeParameterInt(feature.geometry(++i));
			int dy = DecodeParameterInt(feature.geometry(++i));
			lgal::tile::Vector2 delta = { tile_float_t(dx), tile_float_t(dy) };
			cursor = cursor + delta;
			lgal::tile::Vector2 coords = cursor * extentInv;
			if (sUnitBounds.contains(coords))
			{
				points.push_back(coords);
			}
		}

		return (points.empty()) ? nullptr : std::make_unique<PointFeature const>(std::move(points), Properties(feature, keys, values));
	}

	std::unique_ptr<LinestringFeature const> linestring(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values)
	{
		// create vector of polylines
		std::vector<lgal::tile::Polyline> polylines;

		// compute extent inverse -- do it once so we multiply instead divide later
		float extentInv = 1.0f / extent;

		lgal::tile::Vector2 cursor = { 0, 0 };
		for (int i = 0; i < feature.geometry_size(); ++i)
		{
			lgal::tile::Polyline polyline;

			DISABLE_WARNING_PUSH;
			DISABLE_WARNING_UNUSED_VARIABLE;

			// add first point to polyline
			{
				uint32_t commandInt = feature.geometry(i);
				uint32_t id = commandInt & 0x7;
				uint32_t count = commandInt >> 3;

				MAP3D_DEBUG_ASSERT(id == 1, "First command in Linestring geometry must be MoveTo");
				MAP3D_DEBUG_ASSERT(count == 1, "First command count in Linestring geometry must be 1");

				int dx = DecodeParameterInt(feature.geometry(++i));
				int dy = DecodeParameterInt(feature.geometry(++i));
				lgal::tile::Vector2 delta = { tile_float_t(dx), tile_float_t(dy) };
				cursor = cursor + delta;
				polyline.add(cursor * extentInv);
			}

			// add subsequent points
			{
				uint32_t commandInt = feature.geometry(++i);
				uint32_t id = commandInt & 0x7;
				uint32_t count = commandInt >> 3;

				MAP3D_DEBUG_ASSERT(id == 2, "Second command in Linestring geometry must be LineTo");
				MAP3D_DEBUG_ASSERT(count > 0, "Second command count in Linestring geometry must be greater than 0");

				for (uint32_t j = 0; j < count; ++j)
				{
					int dx = DecodeParameterInt(feature.geometry(++i));
					int dy = DecodeParameterInt(feature.geometry(++i));

					MAP3D_DEBUG_ASSERT((dx | dy) != 0, "dx and dy cannot both be 0");

					lgal::tile::Vector2 delta = { tile_float_t(dx), tile_float_t(dy) };
					cursor = cursor + delta;
					polyline.add(cursor * extentInv);
				}
			}

			DISABLE_WARNING_POP;

			std::vector<lgal::tile::Polyline> clipped = lmath::clip(polyline, sUnitBounds);
			polylines.insert(polylines.end(), clipped.begin(), clipped.end());
		}

		return (polylines.empty()) ? nullptr : std::make_unique<LinestringFeature const>(std::move(polylines), Properties(feature, keys, values));
	}

	// helper function to decode a polygonal ring
	static lgal::tile::Polygon LinearRing(vector_tile::Tile_Feature const& feature, int& i, lgal::tile::Vector2& cursor, float extentInv)
	{
		lgal::tile::Polygon polygon;

		DISABLE_WARNING_PUSH;
		DISABLE_WARNING_UNUSED_VARIABLE;

		// add first point to polygon
		{
			uint32_t commandInt = feature.geometry(i);
			uint32_t id = commandInt & 0x7;
			uint32_t count = commandInt >> 3;

			MAP3D_DEBUG_ASSERT(id == 1, "First command in a ring must be MoveTo");
			MAP3D_DEBUG_ASSERT(count == 1, "First command count a ring must be 1");

			int dx = DecodeParameterInt(feature.geometry(++i));
			int dy = DecodeParameterInt(feature.geometry(++i));
			lgal::tile::Vector2 delta = { tile_float_t(dx), tile_float_t(dy) };
			cursor = cursor + delta;
			polygon.add(cursor * extentInv);
		}

		// add subsequent points
		{
			uint32_t commandInt = feature.geometry(++i);
			uint32_t id = commandInt & 0x7;
			uint32_t count = commandInt >> 3;

			MAP3D_DEBUG_ASSERT(id == 2, "Second command in a ring must be LineTo");
			MAP3D_DEBUG_ASSERT(count > 1, "Second command count in a ring must be greater than 1");

			for (uint32_t j = 0; j < count; ++j)
			{
				int dx = DecodeParameterInt(feature.geometry(++i));
				int dy = DecodeParameterInt(feature.geometry(++i));

				MAP3D_DEBUG_ASSERT((dx | dy) != 0, "dx and dy cannot both be 0");

				lgal::tile::Vector2 delta = { tile_float_t(dx), tile_float_t(dy) };
				cursor = cursor + delta;
				polygon.add(cursor * extentInv);
			}
		}

		// close path
		{
			uint32_t commandInt = feature.geometry(++i);
			uint32_t id = commandInt & 0x7;
			uint32_t count = commandInt >> 3;

			MAP3D_DEBUG_ASSERT(id == 7, "Final command in a ring must be ClosePath");
			MAP3D_DEBUG_ASSERT(count == 1, "ClosePath must have a command count of 1");
		}

		DISABLE_WARNING_POP;

		return polygon;
	}

	std::unique_ptr<PolygonFeature const> polygon(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values)
	{
		std::vector<lgal::tile::Holygon> holygons;

		// allocate space for the hull and holes
		lgal::tile::Polygon hull;
		std::vector<lgal::tile::Polygon> holes;

		// compute extent inverse -- do it once so we multiply instead divide later
		float extentInv = 1.0f / extent;

		lgal::tile::Vector2 cursor = { 0, 0 };
		for (int i = 0; i < feature.geometry_size(); ++i)
		{
			int initialI = i;

			// parse the next linear ring
			lgal::tile::Polygon ring = LinearRing(feature, i, cursor, extentInv);

			MAP3D_DEBUG_ASSERT(!ring.empty(), "Linear ring cannot be empty");

			// compute the area
			tile_float_t signedArea = ring.signedArea();
			MAP3D_DEBUG_ASSERT(signedArea != 0.0f, "Linear ring must not have 0 area");

			if (initialI == 0)		// if this is the first ring, we know it must be a hull
			{
				MAP3D_DEBUG_ASSERT(signedArea > 0.0f, "First linear ring must have positive area");
				hull = ring;
			}
			else if (signedArea > 0.0f)		// if the ring has positive area, add the existing holygon and start over
			{
				holygons.push_back({ hull, holes });
				hull = ring;
				holes.clear();
			}
			else									// if the ring has negative area, add it as a hole
			{
				holes.push_back(ring);
			}
		}

		// add the final holygon
		holygons.push_back({ hull, holes });

		return std::make_unique<PolygonFeature const>(std::move(holygons), Properties(feature, keys, values));
	}

	std::unique_ptr<Feature const> feature(vector_tile::Tile_Feature const& feature, float extent, KeyCollectionT const& keys, ValueCollectionT const& values)
	{
		vector_tile::Tile_GeomType type = feature.type();
		switch (type)
		{
			case vector_tile::Tile_GeomType::Tile_GeomType_POINT:        return point(feature, extent, keys, values);                     break;
			case vector_tile::Tile_GeomType::Tile_GeomType_LINESTRING:   return linestring(feature, extent, keys, values);                break;
			case vector_tile::Tile_GeomType::Tile_GeomType_POLYGON:      return polygon(feature, extent, keys, values);                   break;
			case vector_tile::Tile_GeomType::Tile_GeomType_UNKNOWN:      return nullptr;                                                  break;
			default:                                                     return nullptr;                                                  break;
		}
	}

} } }