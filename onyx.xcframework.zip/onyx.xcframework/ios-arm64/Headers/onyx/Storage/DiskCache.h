#if !defined(_DISK_CACHE_H)
#define _DISK_CACHE_H

#if !defined(PLATFORM_EMSCRIPTEN)

#include <memory>
#include <mutex>
#include <typeinfo>
#include <unordered_map>

#include <sqlite3.h>
#include <string>
#include <System/Map3DException.h>
#include "DataObjects/DatabaseObjects/System.h"
#include "DataObjects/DatabaseObjects/TileDataSource.h"
#include "DataObjects/DatabaseObjects/TileData.h"
#include "Utils/property.h"

namespace onyx {
namespace Storage {

#define SQLITE_THROW(code, message) { \
		auto sqliteMsg = getErrorMessage(); \
		std::string msg(message); \
		msg += "\r\nResult code: "; \
		msg += std::to_string(code); \
		msg += "\r\n"; \
		msg += sqliteMsg; \
		MAP3D_THROW(msg); \
	}

#define SQLITE_VALIDATE(x, message) { \
		auto rc = (x); \
		if (rc != SQLITE_OK && rc != SQLITE_DONE && rc != SQLITE_ROW) \
		{ \
			SQLITE_THROW(rc, message); \
		} \
	}

	MAP3D_EXCEPTION_TYPE(DiskCacheException)

	class DiskCache
	{
	public:
		struct Status {
			size_t cachedSize;
			size_t persistentSize;
			size_t entryCount;
			size_t persistentEntryCount;
		};

		struct Messages {
			static constexpr const char* UnknownBaseUrl = "Unknown data source base url specified";
		};
		static constexpr const char *cMemory = ":memory:";
		static constexpr const char *cDefault = "tileStore.sqlite";
		static constexpr int cCurrentVersion = 1;

		typedef DBObject::DBId_t Id_t;

		DiskCache(std::string const &fileName, size_t maxSize = size_t(500 << 20));
		~DiskCache();

		bool isOpen() { return mDb != nullptr; }

		std::string getErrorMessage() const; 

		Id_t getDataSourceId(std::string const &baseUrl);
		void addDataSource(std::string const &baseUrl);

		System getSystemInfo();

		DiskCache::Status getCacheStatus() const;
		DiskCache::Status getCacheStatus(std::string const& baseUrl);

		std::shared_ptr<TileData> getTileData(std::string const &baseUrl, Tiles::TileId tileId) const;

		void addTileData(std::string const &baseUrl, Tiles::TileId tileId, DBObject::DBBlob const &data, bool persistent, int version);

		void insert(System &row);
		void insert(TileDataSource &row);
		void insert(TileData &row);
		
		// Clears any cached tiles
		void clear();

		void setMaxLRUSize(size_t size) { mMaxLRUSize = size; trim(); }

	private:
		mutable std::recursive_mutex mLockMutex;
		mutable std::unordered_map<void*, sqlite3_stmt*> mPreparedStatements;
		std::unordered_map<std::string, int> mDataSourceIds;

		mutable sqlite3_stmt *mGetTileDataStmt			= nullptr,
							*mDeleteTileDataStmt		= nullptr,
							*mClearTileDataStmt			= nullptr,
							*mGetCacheStatus			= nullptr,
							*mGetCacheDataSourceStatus	= nullptr,
							*mUpdateTileDataStmt		= nullptr,
							*mGetTileDataTimestamps		= nullptr,
							*mDeleteTileId				= nullptr,
							*mGetDataSources			= nullptr,
							*mGetSystemInfo				= nullptr;


		void prepareDefaultStatements();

		size_t mMaxLRUSize = 100 << 20; // 100MB default maximum cache
		Status mStatus;
		sqlite3 *mDb = nullptr;
		std::string mDbFileName;

		sqlite3_stmt* prepareStatement(std::string const& sql, void* tag) const;

		inline void AssertIsOpen() const
		{
			MAP3D_ASSERT(mDb != nullptr, "Database is not open!");
		}

		void CreateDb();

		void trim();

		void executeStatement(sqlite3_stmt* statement) const;

		bool getRow(sqlite3_stmt* statement) const;

		template <typename T>
		std::shared_ptr<std::vector<std::shared_ptr<T>>> retrieveStatement(sqlite3_stmt* statement) const;

		template <typename T>
		void bind(T const &value, sqlite3_stmt* stmt) const;

		template <typename T>
		void insertInternal(T & row) const;

		template<typename T>
		void bindValue(int column, T const& value, sqlite3_stmt* stmt) const;
	};

} }

#endif

#endif