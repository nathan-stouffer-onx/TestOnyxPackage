#ifndef __CLIENT_CAMERA_STATE_H__
#define __CLIENT_CAMERA_STATE_H__

#include <lucid/gal/Types.h>

#include "Camera/CameraState.h"
#include "Utils/MapMath.h"

namespace onyx {
namespace Client {

	struct CameraState
	{
		MapMath::LonLatHeight position;

		world_float_t heading;
		world_float_t pitch;

		world_float_t fov;

		Camera::CameraState::Mode mode;

		CameraState() :
			position(MapMath::LonLatHeight{ 0.0, 0.0, 10000.0 }),
			heading(Camera::DefaultHeading),
			pitch(Camera::DefaultPitch),
			fov(Camera::DefaultFoV),
			mode(Camera::CameraState::Mode::THREE_D)
		{}

		CameraState(MapMath::LonLatHeight const& position, world_float_t heading, world_float_t pitch) :
			position(position),
			heading(heading),
			pitch(pitch),
			fov(Camera::DefaultFoV),
			mode(Camera::CameraState::Mode::THREE_D)
		{}

		CameraState(Camera::CameraState const& state) :
			position(MapMath::LonLatHeight(state.position)),
			heading(state.heading),
			pitch(state.pitch),
			fov(state.fov),
			mode(state.mode)
		{}

		Camera::CameraState toInternal() const
		{
			return Camera::CameraState{ position.toWorldPos(), heading, pitch, fov, Camera::DefaultAspect, Camera::DefaultNear, Camera::DefaultFar, mode };
		}
	};

} }

#endif