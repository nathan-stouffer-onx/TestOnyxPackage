#include "ViewportState.h"
#include "Height/HeightManager.h"

using namespace onyx::Camera;

namespace onyx {

	ViewportState::ViewportState() : ViewportState("State", 1, 1, mCameraState, 0)
	{
	}

	ViewportState::ViewportState(std::string const& name, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
		mName(name),
		mWidthRatio(wRatio),
		mHeightRatio(hRatio),
		mPosX(0),
		mPosY(0),
		mSortOrder(sortOrder),
		mTileLoadTimeMS(Utils::Timer::nowMS(), 0.0),
		mIconRenderer(std::make_shared<Icon::IconRenderer>()),
		mContext(std::make_shared<lucid::gigl::Context>()),
		mCameraState(state),
		mController(std::make_shared<Camera::Controllers::Identity>())
	{
		mCameraState.aspect = getAspect();

		if (mSunShadow == nullptr)
		{
			mSunShadow.reset(new TerrainEffects::SunShadow());
		}
	}

	world_float_t ViewportState::getTopoMinorHeightFade()
	{
		world_float_t topoMinor = mTopoMinor / 1000.0f;
		return 1.0 - std::clamp((mCameraState.position.z - (topoMinor * 500.0)) / (topoMinor * 1000.0), 0.0, 1.0);
	}
	world_float_t ViewportState::getTopoMajorHeightFade()
	{
		world_float_t topoMajor = mTopoMajor / 1000.0f;
		return 1.0 - std::clamp((mCameraState.position.z - (topoMajor * 500)) / (topoMajor * 1000), 0.0, 1.0);
	}

	float ViewportState::depthAtPixel(int screenX, int screenY) const
	{
		auto depthData = (uint8_t*)mDepthData.data();
		size_t y = size_t(screenY);
		if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
		{
			y = size_t(getHeightPixel()) - 1 - y;
		}
		auto depthIndex = (size_t(screenX) + (y * size_t(getWidthPixel()))) * 4;
		if (depthIndex < mDepthData.size())
		{
			auto r = depthData[depthIndex] * (1.f / 255.f);
			auto g = depthData[depthIndex + 1] * (1.f / 255.f);
			auto b = depthData[depthIndex + 2] * (1.f / 255.f);
			auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
			return result;
		}
		return -1;
	}

	float ViewportState::depthAtNormalized(lgal::world::Vector2 const& normalizedScreen) const
	{
		int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * getWidthPixel());
		int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * getHeightPixel());
		return depthAtPixel(x, y);
	}

	lgal::world::Vector3 ViewportState::unprojectPixel(int screenX, int screenY) const
	{
		auto depth = depthAtPixel(screenX, screenY) * 2.0f - 1.0f;
		float x = (screenX / getWidthPixel()) * 2.0f - 1.0f;
		float y = (screenY / getHeightPixel()) * 2.0f - 1.0f;
		lgal::world::Vector3 normalizedCoords = { x, y, depth };
		return unprojectNormalized(normalizedCoords);
	}

	lgal::world::Vector3 ViewportState::unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const
	{
		int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * getWidthPixel());
		int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * getHeightPixel());
		return unprojectPixel(x, y);
	}

	// TODO change architecture so that the unprojected point is more accurate
	// the height discrepancy is really off when the camera is zoomed out
	lgal::world::Vector3 ViewportState::unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const
	{
		CameraState::ProjectionData unprojected = mCameraState.unproject(normalizedPos);

		lgal::world::Vector3 result = unprojected.position;

		// override z with a more accurate value
		auto heightKm = HeightManager::Instance()->heightAt({ result.x, result.y });
		result.z = heightKm;

		return result;
	}

	lgal::world::Vector3 ViewportState::project(lgal::world::Vector3 const& pos) const
	{
		CameraState::ProjectionData projected = mCameraState.project(pos);
		return projected.position;
	}

	lgal::world::Vector2 ViewportState::convertGlobalToViewportCoords(lgal::world::Vector2 const& globalNormalizedCoords) const
	{
		int pixX = static_cast<int>(((globalNormalizedCoords.x + 1.0) / 2.0) * ViewportState::sScreenWidth);
		int pixY = static_cast<int>(((globalNormalizedCoords.y + 1.0) / 2.0) * ViewportState::sScreenHeight);

		int minX = (int)mPosX;
		int maxX = (int)(mPosX + getWidthPixel());
		int minY = (int)mPosY;
		int maxY = (int)(mPosY + getHeightPixel());

		float x = static_cast<float>(pixX - minX) / static_cast<float>(maxX - minX);
		float y = static_cast<float>(pixY - minY) / static_cast<float>(maxY - minY);

		x = (x * 2.f) - 1.f;
		y = (y * 2.f) - 1.f;

		return { x, y };
	}

	void ViewportState::toggleViewshed(bool on, bool inverted)
	{
		if (on)
		{
			if (mViewshed == nullptr)
			{
				mViewshed.reset(new onyx::TerrainEffects::Viewshed(inverted));
				mViewshed->initialize(mContext);
			}
		}
		else
		{
			mViewshed.reset();
		}
	}

	bool ViewportState::getViewshedEnabled()
	{
		return mViewshed != nullptr;
	}

	int ViewportState::addViewshed(lgal::world::Vector2 const& pos)
	{
		toggleViewshed(true);

		setViewshedPosition(pos);

		// Something really weird is going on here with the MSVC compiler; in release builds,
		// it gives a warning that this return statement is unreachable.  In debug, it works.

		setViewshedOffset(world_float_t(0.01));
		return 0;
	}

	void ViewportState::setViewshedOffset(world_float_t offset)
	{
		setContext("viewshedOffset0", offset);
	}

	void ViewportState::setViewshedPosition(lgal::world::Vector2 const& pos)
	{
		setContext("viewshedPosition0", pos);
	}

	lgal::world::Vector2 ViewportState::getViewshedPosition()
	{
		return getContext<lgal::world::Vector2>("viewshedPosition0");
	}

	float ViewportState::getViewshedRange()
	{
		return (float)getContext<world_float_t>("viewshedRange0");
	}

	void ViewportState::setViewshedRange(world_float_t range)
	{
		setContext("viewshedRange0", range);
	}

}
