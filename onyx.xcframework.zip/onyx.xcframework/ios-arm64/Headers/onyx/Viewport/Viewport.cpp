#include "Viewport.h"

#include <unordered_set>

#include <lucid/Profiler.h>
#include <Shaders/ShaderDefinition.h>

#include "Caching/TileCache.h"
#include "Caching/Tasks/VectorTileTasks.h"
#include "Caching/Tasks/HeightTileTasks.h"
#include "DataObjects/LabelManager.h"
#include "DataObjects/DashStyleManager.h"
#include "DataObjects/UserMarkupManager.h"
#include "DataObjects/WaypointManager.h"
#include "DataObjects/TrackerManager.h"
#include "Atlases/HeightAtlas.h"
#include "Atlases/TileAtlas.h"
#include "Height/HeightManager.h"
#include "Pyramid/UVOffset.h"
#include "Tiles/TileRenderInfo.h"
#include "Tiles/TileMesh.h"
#include "Events/Events.h"
#include "Utils/Timer.h"
#include "Style/DefaultStyles.h"
#include "Camera/Frustum.h"

namespace DO = onyx::DataObjects;

namespace onyx {

static constexpr world_float_t HEIGHT_CONVERSION(world_float_t h) { return (h - MapMath::cMinHeight) / (MapMath::cMaxHeight - MapMath::cMinHeight); }

#define COLOR_INTERVAL(begin, end, color) { begin, color }, { end, color }
#define DEFAULT_HEIGHT_BAND_COLORS { HEIGHT_CONVERSION(0.0), 0xFF023020 }, { HEIGHT_CONVERSION(1.0), 0xFF90EE90 }, { HEIGHT_CONVERSION(2.0), 0xFFFFFFE0 }, { HEIGHT_CONVERSION(3.0), 0xFFCC5500 }, { HEIGHT_CONVERSION(4.0), 0xFF8B0000 }, { HEIGHT_CONVERSION(5.0), 0xFF5C4033 }
#define DEFAULT_SLOPE_DIR_COLORS { 0.0, 0xFF660000 }, { 0.25, 0xFF000066 }, { 0.5, 0xFFFF6600 }, { 0.75, 0xFF006600 }
#define ONX_SLOPE_ANGLE_COLORS COLOR_INTERVAL(0.0 / 90.0, 20.0 / 90.0, 0xFF023020), COLOR_INTERVAL(20.0 / 90.0, 25.0 / 90.0, 0xFF80FF01), COLOR_INTERVAL(25.0 / 90.0, 30.0 / 90.0, 0xFFFFFF01), COLOR_INTERVAL(30.0 / 90.0, 35.0 / 90.0, 0xFFE69137), COLOR_INTERVAL(35.0 / 90.0, 40.0 / 90.0, 0xFFFE0000), COLOR_INTERVAL(40.0 / 90.0, 45.0 / 90.0, 0xFF9A00FF), COLOR_INTERVAL(45.0 / 90.0, 90.0 / 90.0, 0xFF0000FE)
#define CALTOPO_SLOPE_ANGLE_COLORS COLOR_INTERVAL(0.0 / 90.0, 27.0 / 90.0, 0xFF023020), COLOR_INTERVAL(27.0 / 90.0, 30.0 / 90.0, 0xFFF1F5AB), COLOR_INTERVAL(30.0 / 90.0, 32.0 / 90.0, 0xFFF9D1AC), COLOR_INTERVAL(32.0 / 90.0, 35.0 / 90.0, 0xFFBC946E), COLOR_INTERVAL(35.0 / 90.0, 45.0 / 90.0, 0xFFB56B68), COLOR_INTERVAL(45.0 / 90.0, 50.0 / 90.0, 0xFFB58DD1), COLOR_INTERVAL(50.0 / 90.0, 60.0 / 90.0, 0xFF9091DD), COLOR_INTERVAL(60.0 / 90.0, 90.0 / 90.0, 0xFF655E58)
#define DEFAULT_SLOPE_ANGLE_COLORS ONX_SLOPE_ANGLE_COLORS

float ViewportState::sScreenWidth = 1280.f;
float ViewportState::sScreenHeight = 720.f;

Viewport::Viewport(std::string const& name, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder) :
	mViewportState(name, wRatio, hRatio, state, sortOrder),
	mStyle(new Styling::Style()),
	mSkydome(new Drawers::Skydome()),
	mHeightRanges(Utils::Gradient{ { DEFAULT_HEIGHT_BAND_COLORS } }),
	mSlopeAspectRanges(Utils::Gradient{ { DEFAULT_SLOPE_DIR_COLORS } }),
	mSlopeAngleRanges(Utils::Gradient{ { DEFAULT_SLOPE_ANGLE_COLORS } }),
	mLayerCache(new Caching::LayerCache())
{
	mLineMesh.reset(new DataObjects::VectorLineMesh());

	allocateTextures();
	allocateFramebuffers();

	// set up the only alpha on texture
	uint32_t onlyAlpha = 0xFF000000;
	bgfx::Memory const* mem = bgfx::copy((void*)&onlyAlpha, 4);
	mOnlyAlphaTexture = bgfx::createTexture2D(1, 1, false, 1, bgfx::TextureFormat::BGRA8, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT, mem);
	
	setHeightRanges(mViewportState.getHeightRangesKm());
	setSlopeDirRanges(mViewportState.getSlopeDirRangesRad());
	setSlopeAngleRanges(mViewportState.getSlopeAngleRangesRad());

	mLabelManager.reset(new DataObjects::LabelManager(this));
	mLabelManager->initialize();
	mLabelManager->setScreenSize({ getWidthPixel(), getHeightPixel() });

	//TODO - expose this as a configurable setup
	mViewportState.mRenderItems.push_back(ViewportState::RenderItems::Terrain);
	mViewportState.mRenderItems.push_back(ViewportState::RenderItems::Waypoint);
	mViewportState.mRenderItems.push_back(ViewportState::RenderItems::Tracker);
	mViewportState.mRenderItems.push_back(ViewportState::RenderItems::Labels);
	mViewportState.mRenderItems.push_back(ViewportState::RenderItems::Icons);

	//testing
	//SETUPCONFIG()
//	ConfigManager::Instance()->updateConfigVars();
}

Viewport::~Viewport()
{
	if (bgfx::isValid(mOnlyAlphaTexture))
	{
		bgfx::destroy(mOnlyAlphaTexture);
	}

	deallocateTextures();
	deallocateFramebuffers();
}

bgfx::TextureHandle Viewport::getTexture()
{
	if (mColorDepthZFrameBuffer.idx == bgfx::kInvalidHandle ||
		mColorZFrameBuffer.idx == bgfx::kInvalidHandle ||
		mColorTarg.idx == bgfx::kInvalidHandle)
	{
		return BGFX_INVALID_HANDLE;
	}

	return mColorTarg;
}

void Viewport::renderScreenLines(bgfx::ViewId renderId, screenLineVector_t const& instances, std::string const& dashStyle, uint64_t bgfxRenderState, std::shared_ptr<Shaders::ShaderDefinition> &shader)
{
	auto maxInstances = bgfx::getAvailInstanceDataBuffer(uint32_t(instances.size()), uint32_t(sizeof(Rendering::VertStructs::InstanceData4)));

	if (maxInstances == 0)
	{
		return;
	}

	bgfx::InstanceDataBuffer idb;
	bgfx::allocInstanceDataBuffer(&idb, maxInstances, uint32_t(sizeof(Rendering::VertStructs::InstanceData4)));

	if (idb.num > 0 && idb.num <= instances.size())
	{
		mLineMesh->attach();
		shader->setParameter("u_drawColor", lgal::Color(0.f, 0, 0, 0));
		shader->setParameter("s_DashSampler", DataObjects::DashStyleManager::get(dashStyle));

		memcpy(idb.data, instances.data(), size_t(idb.num) * sizeof(Rendering::VertStructs::InstanceData4));
		bgfx::setInstanceDataBuffer(&idb);
		bgfx::setState(bgfxRenderState | BGFX_STATE_PT_TRISTRIP);
		bgfx::submit(renderId, shader->mInstancedHandle);
	}
}

void Viewport::renderScreenLines()
{
	if (mViewportState.mScreenLines.empty())
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw screen-space lines");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);
	
	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_R
		| BGFX_STATE_WRITE_G
		| BGFX_STATE_WRITE_B
		| BGFX_STATE_BLEND_ALPHA;
#ifdef ENABLE_MSAA
	| BGFX_STATE_MSAA
#endif
		;

	for (auto const& styles : mViewportState.mScreenLines)
	{
		auto const& instances = styles.second;
		if (instances.empty())
		{
			continue;
		}

		renderScreenLines(renderId, instances, styles.first, state, shader);
	}
}

void Viewport::renderScreenSpaceManager()
{
	if (mViewportState.mScreenSpaceManager.empty() || !mShowScreenSpaceManager)
	{
		return;
	}

	bgfx::ViewId renderId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_NONE, 0x00000000, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, mColorZFrameBuffer);
	bgfx::setViewName(renderId, "Draw Screen Space Manager");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::VectorLine, 0);

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);

	uint64_t state = 0
		| BGFX_STATE_WRITE_R
		| BGFX_STATE_WRITE_G
		| BGFX_STATE_WRITE_B
		| BGFX_STATE_BLEND_ALPHA;
#ifdef ENABLE_MSAA
	| BGFX_STATE_MSAA
#endif
		;

	screenLineVector_t instances;

	auto screenSize = size().as<gpu_float_t>();

	auto xScale = 2.f / screenSize.x;
	auto yScale = 2.f / screenSize.y;

	for (auto const &screenRect : mViewportState.mScreenSpaceManager)
	{
		auto GPURect = screenRect.as<gpu_float_t>();

		static const std::array<int, 4> nextPts = { 1, 3, 0, 2 };

		for (int i = 0; i < GPURect.VERTEX_COUNT(); ++i)
		{
			lgal::gpu::LineSegment2 segment(GPURect.vertex(i), GPURect.vertex(nextPts[i]));

			lgal::gpu::Vector2 p1(segment.start.x * xScale - 1,
				(segment.start.y * yScale - 1));

			p1.y *= -1;
			auto dir = lucid::math::normalize(segment.direction());
			dir.y *= -1;

			instances.push_back(Rendering::VertStructs::ScreenLineData(
				0,
				0,
				0xFFFF0000,
				{ p1, 0 },
				{ dir, 0 },
				segment.length(),
				3.0
				));
		}
	}

	if (instances.empty())
	{
		return;
	}

	renderScreenLines(renderId, instances, "dotted", state, shader);
}

void Viewport::drawTerrainLines(bgfx::ViewId renderId, Tiles::TileVectorInfo const& info, bgfx::VertexBufferHandle const handle, uint32_t start, uint32_t num, float32_t fade, Shaders::ShaderDefinition* shader)
{
	if (num == 0 || !bgfx::isValid(handle))
	{
		return;
	}

	auto tileMin = (info.tileMin - mViewportState.mCameraState.position).as<gpu_float_t>();
	auto tileMax = (info.tileMax - mViewportState.mCameraState.position).as<gpu_float_t>();
	tileMax.z = (gpu_float_t)info.tileSize.x;

	shader->setParameter("u_tileMin", tileMin);
	shader->setParameter("u_tileMax", tileMax);

	setTextureParameters(info.heightAtlasInfo, shader, TextureType::HeightVert);
	shader->setParameter("u_MeshResolution", info.meshResolution);
	
	shader->setParameter("u_vectorFade", fade);
	shader->setParameter("u_drawColor", info.color);
	shader->setParameter("u_lineWidthScale", lmath::clamp(fade * 2.f, 0.f, 1.f));

	static uint64_t baseState = 0
		| BGFX_STATE_WRITE_R
		| BGFX_STATE_WRITE_G
		| BGFX_STATE_WRITE_B
		| BGFX_STATE_BLEND_ALPHA
		| BGFX_STATE_DEPTH_TEST_LEQUAL
#ifdef ENABLE_MSAA
	| BGFX_STATE_MSAA
#endif
		;

	lgal::gpu::Vector4 pixelSize(2.f / getWidthPixel(), 2.f / getHeightPixel(), getWidthPixel(), getHeightPixel());
	shader->setParameter("u_screenDimensions", pixelSize);
	
	shader->setParameter("u_tileDistortion", lgal::gpu::Vector3{ info.distortion.as<gpu_float_t>(), 0.0 });

	Atlases::LineStyleAtlas const& lineStyles = mLayerCache->getLineStyles();
	shader->setParameter("s_VectorColors", lineStyles.getColorHandle());
	shader->setParameter("s_VectorWidths", lineStyles.getWidthHandle());
	shader->setParameter("s_DashCoords", lineStyles.getDashCoordsHandle());
	shader->setParameter("s_DashSampler", lineStyles.getDashAtlasHandle(), Atlases::DashAtlas::cRowResolution, Atlases::DashAtlas::cNumRows);

	mLineMesh->attach();

	mViewportState.mFrameRenderStats.renderedLineInstances += num;

	bgfx::setInstanceDataBuffer(handle, start, num);
	bgfx::setState(baseState | BGFX_STATE_PT_TRISTRIP);
	bgfx::submit(renderId, shader->mInstancedHandle);
}

void Viewport::render(double timeMS)
{
	mCurrentFrameTime = timeMS;
	mLayerCache->setFrameTimeMS(timeMS);
	mViewportState.mFrameRenderStats.reset();

	if (mTerrainShader.count() == 0)
	{
		mTerrainShader.loadSignature(ShaderManager::Instance()->getDefaultConfiguration(ShaderEnums::ConfigurableShaders::Terrain));
		if (mTerrainShader.count() == 0)
		{
			MAP3D_THROW("Unable to load terrain shader!");
		}
	}
	if (mVectorShader.count() == 0)
	{
		mVectorShader.loadSignature(ShaderManager::Instance()->getDefaultConfiguration(ShaderEnums::ConfigurableShaders::TerrainVector));
		if (mVectorShader.count() == 0)
		{
			MAP3D_THROW("Unable to load filled terrain vector shader!");
		}
	}

	// sync source ids
	if (mStyle->hasDirtySources())
	{
		syncSources();
		mViewportState.setRenderComplete(false);
	}

	// sync layers
	if (mStyle->hasDirtyLayers())
	{
		syncLayers();
		mViewportState.setRenderComplete(false);
	}

	if (mStyle->hasDirtyTerrain())
	{
		mViewportState.setRenderComplete(false);
	}

	mStyle->update();

	// compute height atlas if we have the source
	auto heightAtlas = getHeightAtlas();

	// precache tiles associated with the controller's highlight states
	std::vector<Camera::CameraState> highlights = mViewportState.mController->highlights();
	for (auto const& highlight : highlights)
	{
		Pyramid::CullResult cullRes = Pyramid::cull(highlight, mViewportState.getLODScaler(), mViewportState.getMaxSubdDepth(), heightAtlas, mViewportState.getTerrainExaggeration());
		TileCollections tiles = { cullRes };
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(tiles.rasterGrandparents, tiles.vectorGrandparents, mStyle);
		// only continue processing if the tiles are precached
		if (!Caching::TileCache::Instance()->precache(keys, false))
		{
			break;
		}
	}

	Camera::CameraState newState = mViewportState.mController->update(mViewportState.mCameraState, timeMS, heightAtlas, mViewportState.getTerrainExaggeration());

	// evaluate exaggeration
	if (mStyle->hasTerrain())
	{
		std::shared_ptr<Styling::Terrain const> const& terrain = mStyle->terrain();
		Styling::Expressions::Arguments args{ {}, mViewportState.getZoom(), lmath::radiansToDegrees(newState.pitch), mStyle->getContext() };
		mViewportState.setTerrainExaggeration(terrain->exaggeration->evaluate(args));
	}

	// override aspect ratio with viewport value
	newState.aspect = getAspect();

	bool cameraWasMoving = mViewportState.getCameraMoved();
	mViewportState.setCameraMoved(newState != mViewportState.mCameraState);

	// trigger camera-related events
	if (mViewportState.getCameraMoved())
	{
		mViewportState.mCameraState = newState;
		mViewportState.mCameraState.updateViewProj();
		Events::trigger(Events::EventType::CAMERA_MOVED);
	}
	else if (cameraWasMoving)
	{
		Events::trigger(Events::EventType::CAMERA_STOPPED);
		lgal::world::Range r = lgal::world::Range(Utils::Timer::nowMS(), 0.0);
		mViewportState.setTileLoadTimeMS(r);
	}

	if (mViewportState.getCullingEnabled())
	{
		// compute zoom for this frame
		lgal::world::Vector3 center = unprojectNormalized(lgal::world::Vector2{ 0.f, 0.f });
		lgal::world::Vector3 bottom = unprojectNormalized(lgal::world::Vector2{ 0.f, 1.f });
		float zoom = (float)std::max(MapMath::zoom(newState.position, center), MapMath::zoom(newState.position, bottom));
		mViewportState.setZoom(zoom);
	}

	if (mViewportState.getCameraMoved() || mViewportState.getForceCulling())
	{
		mViewportState.setForceCulling(false);
		// reset tile load time when the camera moves

		if (mViewportState.getCullingEnabled())
		{
			LUCID_PROFILE_SCOPE("culling");
			mViewportState.mTileRenderInfo.clear();
			mViewportState.mCullState.reset();
			Pyramid::cull(mViewportState.mCullState, mViewportState.mCameraState, mViewportState.getLODScaler(), mViewportState.getMaxSubdDepth(), heightAtlas, mViewportState.getTerrainExaggeration());
			mViewportState.mTileCollections.update(mViewportState.mCullState, mViewportState.getTileZoomRange(), mViewportState.getTileRenderRange());
			mLastCacheUpdate = 0;
		}
		mViewportState.setRenderComplete(false);
	}

	if (mViewportState.mViewshed != nullptr)
	{
		mViewportState.mViewshed->update(mViewportState.mCameraState, mViewportState.mContext, timeMS);
	}

	if (mViewportState.getRenderComplete() && mViewportState.getQuiescenceMode()) // Nothing to do; render was already completed and nothing has changed.
	{
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(mViewportState.mTileCollections.rasters, mViewportState.mTileCollections.vectors, mStyle);
		Caching::TileCache::Instance()->touch(keys);
		return;
	}

	auto cacheTimestamp = Caching::TileCache::Instance()->getUpdateTimestamp();

	if (cacheTimestamp == mLastCacheUpdate)
	{
		//return; // Nothing new in the cache to render, so just bail
	}
//	logD("cache has new info %ul -> %ul", mLastCacheUpdate, cacheTimestamp);
	mLastCacheUpdate = cacheTimestamp;
	mViewportState.getScreenSpaceManager().clear();
	mTerrainShader.setParameter("u_eyePos", mViewportState.mCameraState.position);
	mTerrainShader.setParameter("u_nearFarPlane", lgal::world::Vector3(mViewportState.mCameraState.nearClip, mViewportState.mCameraState.farClip, 0));

	if (mSkydome.get() != nullptr)
	{
		auto id = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::Skydome, 0);
		auto p = shader->parameters["u_hazeColor"];
		bgfx::setViewClear(id, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, p->mColor.rgba(), 1.0f, 0);
		bgfx::setViewFrameBuffer(id, mColorDepthZFrameBuffer);
		bgfx::setViewRect(id, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());
		mSkydome->draw(id, mViewportState.mCameraState, shader);
	}

	for (size_t i = 0u; i < mViewportState.mRenderItems.size(); i++)
	{
		switch (mViewportState.mRenderItems[i])
		{
		case ViewportState::RenderItems::Terrain:
			renderTerrain();
			break;
		case ViewportState::RenderItems::Waypoint:
			renderWaypoints();
			break;
		case ViewportState::RenderItems::Tracker:
			renderTrackers();
			break;
		case ViewportState::RenderItems::Labels:
			renderLabels();
			break;
		case ViewportState::RenderItems::Icons:
			renderIcons();
			break;
		};
	}

	renderScreenLines();
	renderScreenSpaceManager();
	
	mViewportState.mLifetimeRenderStats += mViewportState.mFrameRenderStats;
}

void Viewport::readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue)
{
	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(float);
	if (mViewportState.mDepthData.size() < dataSize)
	{
		mViewportState.mDepthData.resize(dataSize);
		if (defaultValue != 0)
		{
			memset(mViewportState.mDepthData.data(), defaultValue, mViewportState.mDepthData.size());
		}

	}

	auto data = mViewportState.mDepthData.data();
	
	bgfx::blit(viewId, mDepthReadbackHandle, 0, 0, mDepthTarg);
	/*uint32_t frame =*/ bgfx::readTexture(mDepthReadbackHandle, data);
}

void Viewport::readDepth(std::vector<uint8_t>& target)
{
	target.resize(mViewportState.mDepthData.size());
	std::copy(mViewportState.mDepthData.begin(), mViewportState.mDepthData.end(), target.begin());
}

void Viewport::readColor(std::vector<uint8_t> &target, uint8_t defaultValue)
{
	auto viewId = Rendering::ViewId::next(Rendering::ViewId::Type::Composite);

	auto dataSize = size_t(getWidthPixel()) * size_t(getHeightPixel()) * sizeof(uint32_t);
	if (target.size() != dataSize)
	{
		target.resize(dataSize);
		if (defaultValue != 0)
		{
			memset(target.data(), defaultValue, target.size());
		}
	}

	auto data = target.data();

	bgfx::blit(viewId, mColorReadbackHandle, 0, 0, mColorTarg);

	bgfx::readTexture(mColorReadbackHandle, data);
}

void Viewport::resize()
{
	// set the camera state aspect
	setController(std::make_shared<Camera::Controllers::Identity>());
	mViewportState.mCameraState.aspect = getAspect();

	// reallocate textures of the appropriate size
	deallocateTextures();
	allocateTextures();

	// reallocate frame buffers with those textures
	deallocateFramebuffers();
	allocateFramebuffers();

	mLabelManager->setScreenSize({ getWidthPixel(), getHeightPixel() });
	invalidate();
}

void Viewport::setController(std::shared_ptr<Camera::CameraController> controller)
{
	mViewportState.mController = controller;
}

void Viewport::setCameraState(Camera::CameraState const& state)
{
	setController(std::make_shared<Camera::Controllers::Identity>());
	mViewportState.mCameraState = state;
}


gpu_float_t Viewport::depthAtPixel(int screenX, int screenY) const
{
	auto depthData = (uint8_t*)mViewportState.mDepthData.data();
	size_t y = size_t(screenY);
	if (bgfx::getCaps()->originBottomLeft)	// flip if the origin of the texture is in the bottom left
	{
		y = size_t(getHeightPixel()) - 1 - y;
	}
	auto depthIndex = (size_t(screenX) + (y * size_t(mViewportState.getWidthPixel()))) * 4;
	if (depthIndex < mViewportState.mDepthData.size())
	{
		auto r = depthData[depthIndex] * (1.f / 255.f);
		auto g = depthData[depthIndex + 1] * (1.f / 255.f);
		auto b = depthData[depthIndex + 2] * (1.f / 255.f);
		auto result = ((r * 65536.f) + (g * 256.f) + (b)) / 65536.f;
		return result;
	}
	return -1;
}

gpu_float_t Viewport::depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const
{
	int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * mViewportState.getWidthPixel());
	int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * mViewportState.getHeightPixel());
	return depthAtPixel(x, y);
}

lgal::world::Vector3 Viewport::unprojectPixel(int screenX, int screenY) const
{
	auto depth = depthAtPixel(screenX, screenY) * 2.0f - 1.0f;
	float x = (screenX / mViewportState.getWidthPixel()) * 2.0f - 1.0f;
	float y = (screenY / mViewportState.getHeightPixel()) * 2.0f - 1.0f;
	lgal::world::Vector3 normalizedCoords = { x, y, depth };
	return unprojectNormalized(normalizedCoords);
}

lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const
{
	int x = static_cast<int>(((normalizedScreen.x + 1.0) / 2.0) * mViewportState.getWidthPixel());
	int y = static_cast<int>(((normalizedScreen.y + 1.0) / 2.0) * mViewportState.getHeightPixel());
	return unprojectPixel(x, y);
}

// TODO change architecture so that the unprojected point is more accurate
// the height discrepancy is really off when the camera is zoomed out
lgal::world::Vector3 Viewport::unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const
{
	Camera::CameraState::ProjectionData unprojected = mViewportState.mCameraState.unproject(normalizedPos);

	lgal::world::Vector3 result = unprojected.position;

	// override z with a more accurate value
	if (mStyle->hasTerrain())
	{
		auto heightAtlas = getHeightAtlas();
		auto distortedHeightKm = heightAtlas->heightAt(MapMath::moduloX(result.xy));
		distortedHeightKm *= mViewportState.getTerrainExaggeration();
		result.z = distortedHeightKm;
	}
	else
	{
		result.z = 0.0;
	}

	return result;
}

lgal::world::Vector3 Viewport::project(lgal::world::Vector3 const& pos) const
{
	Camera::CameraState::ProjectionData projected = mViewportState.mCameraState.project(pos);
	return projected.position;
}

void Viewport::setMatrixUniforms(bgfx::ViewId const& viewId)
{
	mViewportState.mCameraState.updateViewProj();
	bgfx::setViewTransform(viewId, mViewportState.mCameraState.view, mViewportState.mCameraState.proj);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)mViewportState.getWidthPixel(), (uint16_t)mViewportState.getHeightPixel());
}

void Viewport::setTerrainToolsUniforms(std::shared_ptr<Shaders::ShaderDefinition>& shader)
{
	// update height ranges (changes based on the min/max of the tiles that are rendered)
	if (mViewportState.getHeightRangesOn() || mViewportState.getIntersectTerrain())
	{
		auto extent = mHeightRanges.getExtent();
		shader->setParameter("u_HeightExtents", lgal::world::Vector2{ extent.begin, extent.end });
	}

	if (mViewportState.getIntersectTerrain())	// if intersect terrain layers, set all uniforms to full values
	{
		shader->setParameter("s_HeightBandTexture", mOnlyAlphaTexture);
		shader->setParameter("s_SlopeAngleTexture", mOnlyAlphaTexture);
		shader->setParameter("s_SlopeDirTexture", mOnlyAlphaTexture);
	}

	if (mViewportState.getHeightRangesOn())
	{
		mHeightRanges.setTerrainParameters(shader);
	}

	if (mViewportState.getSlopeAngleRangesOn())
	{
		mSlopeAngleRanges.setTerrainParameters(shader);
	}

	if (mViewportState.getSlopeDirRangesOn())
	{
		mSlopeAspectRanges.setTerrainParameters(shader);
	}

	for (size_t i = 0u; i < mTerrainShader.count(); i++)
	{
		auto sp = mTerrainShader.getParameter("u_tileSize", int(i));
		if (sp != nullptr)
		{
			sp->setValue(lgal::world::Vector3(sp->mVec3.x, sp->mVec3.y, mViewportState.getTerrainExaggeration()));
		}
	}
}

void Viewport::renderTerrain()
{
	LUCID_PROFILE_SCOPE("viewport terrain render");

	bgfx::ViewId viewId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);

	if (mSkydome.get() == nullptr)
	{
		bgfx::setViewClear(viewId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0);
	}

	bgfx::setViewName(viewId, (std::string("viewport terrain ") + mViewportState.getName()).c_str());
	bgfx::setViewFrameBuffer(viewId, mColorDepthZFrameBuffer);
	setMatrixUniforms(viewId);
	bgfx::setViewRect(viewId, 0, 0, (uint16_t)getWidthPixel(), (uint16_t)getHeightPixel());


	if (renderTiles(viewId))
	{
//		logD("viewport render completed");
		mViewportState.setRenderComplete(true);
		if (mViewportState.getTileLoadTimeMS().end == 0.0)
		{
			mViewportState.setTileLoadTimeMS(lgal::world::Range(mViewportState.getTileLoadTimeMS().begin, Utils::Timer::nowMS()));
			Events::trigger(Events::EventType::TILES_LOADED);
		}
	}
	else
	{
//		logD("viewport render INCOMPLETE");
	}

}

void Viewport::renderWaypoints()
{
	LUCID_PROFILE_SCOPE("viewport waypoint render");

	bgfx::ViewId renderDataId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);
	bgfx::touch(renderDataId);
	bgfx::setViewFrameBuffer(renderDataId, mColorZFrameBuffer);
	bgfx::setViewClear(renderDataId, BGFX_CLEAR_NONE);
	bgfx::setViewName(renderDataId, "viewport waypoint");
	setMatrixUniforms(renderDataId);
	WaypointManager::Instance()->draw(renderDataId, mViewportState.mCameraState);

}

void Viewport::renderTrackers()
{
	LUCID_PROFILE_SCOPE("viewport tracker render");

	bgfx::ViewId renderDataId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);
	bgfx::touch(renderDataId);
	bgfx::setViewFrameBuffer(renderDataId, mColorZFrameBuffer);
	bgfx::setViewClear(renderDataId, BGFX_CLEAR_NONE);
	bgfx::setViewName(renderDataId, "viewport tracker");
	setMatrixUniforms(renderDataId);
	TrackerManager::Instance()->draw(renderDataId, mViewportState.mCameraState);
}

void Viewport::renderIcons()
{
	LUCID_PROFILE_SCOPE("viewport icon render");

	// compute height atlas if we have the source
	auto heightAtlas = getHeightAtlas();
	if (heightAtlas == nullptr)
	{
		return;
	}

	// Get visible tiles
	std::vector<Tiles::IconTile> tiles;
	for (auto& tile : mViewportState.mDebugIconTiles)
	{
		auto const& rIter = mViewportState.mTileRenderInfo.find(tile.tInfo.id);
		if (rIter != mViewportState.mTileRenderInfo.end())
		{
			tile.tInfo = rIter->second;
			tiles.push_back(tile);
		}
	}

	// Get symbol layers
	std::vector<std::shared_ptr<Styling::SymbolLayer const>> iconLayers;
	iconLayers.insert(iconLayers.end(), mViewportState.mDebugIconLayers.begin(), mViewportState.mDebugIconLayers.end());
	/*
	for (auto const& layer : mStyle->layers<Styling::SymbolLayer>())
	{
		if (layer->isVisible() && layer->hasIcons())
		{
			iconLayers.push_back(layer);
		}
	}
	*/

	// TODO (Ronald): Separate update function from render function
	mViewportState.mIconRenderer->update();

	bgfx::ViewId renderDataId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);
	bgfx::touch(renderDataId);
	bgfx::setViewFrameBuffer(renderDataId, mColorZFrameBuffer);
	bgfx::setViewClear(renderDataId, BGFX_CLEAR_NONE);
	bgfx::setViewName(renderDataId, "viewport icon");
	setMatrixUniforms(renderDataId);

	mViewportState.mIconRenderer->draw(renderDataId, mViewportState.mCameraState,
		tiles,		// Currently visibile tiles with data about where to render the tile info
		*heightAtlas,
		iconLayers	// Relevant symbol layers
	);
}

template<typename LayerType>
void Viewport::gatherLabels()
{
	for (auto const& layer : mStyle->layers<LayerType>())
	{
		if (layer->isVisible())
		{
			for (auto& tileId : mViewportState.mTileCollections.vectors)
			{
				Caching::LayerCache::EntryKey key = { tileId, layer->id };

				if (mLayerCache->isPrepared(key))
				{
					Caching::LayerCache::Entry const& entry = mLayerCache->at(key);
					auto prepared = std::static_pointer_cast<Caching::PreparedSymbolData const>(entry.prepared);
					auto preparedLabels = prepared->labels();
					mFrameLabels.insert(mFrameLabels.end(), preparedLabels.begin(), preparedLabels.end());
				}
			}
		}
	}
}

void Viewport::gatherLabels()
{
	// TODO we have to refactor this code at some point. viewports shouldn't have to add the viewshed labels on a per frame basis
	// viewshed should be able to tell a central label cache that about itself and it's labels. and the viewport draws all labels
	// as necessary. though we will have to think about how the viewport tells the label cache data sources (layers and waypoints
	// viewsheds and such) it wants to draw
	auto const& probe = mViewportState.mViewshed;
	if (probe != nullptr)
	{
		if (probe->getEnabled())
		{
			probe->getLabels(mFrameLabels);
		}
	}

	gatherLabels<Styling::SymbolLayer>();
	gatherLabels<Styling::ContourLayer>();
}

void Viewport::renderLabels()
{
	LUCID_PROFILE_SCOPE("label render");

	mLabelManager->update();
	mFrameLabels.clear();

	auto labelId = Rendering::ViewId::next(Rendering::ViewId::Type::MainDraw);

	bgfx::setViewFrameBuffer(labelId, mColorZFrameBuffer);
	bgfx::setViewClear(labelId, BGFX_CLEAR_NONE);
	bgfx::setViewName(labelId, "viewport labels");
	setMatrixUniforms(labelId);

	gatherLabels();

	mLabelManager->draw(mViewportState.getScreenSpaceManager(), getHeightAtlas(), mFrameLabels, labelId);
}

static Tiles::TileTextureAtlasInfo GetTextureAtlasInfo(Atlases::TileAtlas const* atlas, Tiles::TileId const& tileId, lucid::gal::Range const& zoomRange)
{
	Tiles::TileId ready = tileId;
	if (ready.level > zoomRange.end)
	{
		ready = ready.parent(ready.level - zoomRange.end);
	}

	while (ready.level >= zoomRange.begin)	// loop to see if we can find a lower detail texture
	{
		if (atlas->isReady(ready))
		{
			auto lowerDetailOffset = Pyramid::UVOffset::toLowerDetail(ready, tileId);
			auto uvOffset = atlas->getUVOffset(ready);

			auto combinedOffset = Pyramid::UVOffset::compose(lowerDetailOffset, uvOffset);

			auto handle = atlas->getTexHandle(ready);
			uint32_t atlasResolution = atlas->getResolution();

			return { handle, atlasResolution, combinedOffset, ready.level };
		}
		else
		{
			if (ready.level <= zoomRange.begin)
				break;

			ready = ready.parent();
		}
	}

	return Tiles::TileTextureAtlasInfo::invalid();
}

void Viewport::gatherTileTextureInfo(Tiles::TileId const& tileId, Tiles::TileTextureInfo& target)
{
	// map of data sources to the tiles that are ready to render (might be lower detail than the rendered tile)

	target.layerCount = 0;
	bool hasAllTextures = true;
	
	if (mStyle->hasTerrain())
	{
		Caching::Source const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
		Atlases::TileAtlas const* atlas = source.atlas();

		auto atlasInfo = GetTextureAtlasInfo(atlas, tileId, source.specification()->range());
		target.heightAtlasInfo = atlasInfo;
	}

	bool firstRaster = true;
	for (std::shared_ptr<Styling::RasterLayer const> layer : mStyle->layers<Styling::RasterLayer>())
	{
		if (layer->isVisible())
		{
			Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
			Atlases::TileAtlas const* atlas = source.atlas();

			auto atlasInfo = GetTextureAtlasInfo(atlas, tileId, source.specification()->range());

			Tiles::TileId ready = tileId;

			if (ready.level != tileId.level && ready.level < source.specification()->maxZoom)
			{
				hasAllTextures = false;
			}

			if (source.specification()->minZoom <= atlasInfo.level)
			{
				if (firstRaster)
				{
					firstRaster = false;
					target.basemap = atlasInfo;
				}
				else
				{
					target.layers[target.layerCount] = atlasInfo;
					++target.layerCount;
				}
			}
		}
	}

	target.isComplete = hasAllTextures;
	target.isReady = bgfx::isValid(target.basemap.handle) && bgfx::isValid(target.heightAtlasInfo.handle);
}

void Viewport::setTextureParameters(Tiles::TileTextureAtlasInfo const& info, Shaders::ShaderDefinition * shader, TextureType textureType)
{
	auto const& texInfo = mTextureShaderMapping.at(textureType);
	std::string texName = texInfo.first;
	const std::string& uvOffsetName = texInfo.second;

	auto sp = shader->parameters[texName];
	if (sp != nullptr)
	{
		sp->setValue(info.handle, info.resolution, info.resolution);

		sp = shader->parameters[uvOffsetName];
		if (sp != nullptr) //check this early to make sure the shader supports offsets before we do the math
		{
			sp->setValue(info.offset);
		}
	}

}

void Viewport::toggleTopo(bool enabled)
{
	if (mViewportState.getTopoOn() == enabled)
	{
		return;
	}
	mViewportState.setTopoOn(enabled);
	toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "TopoLines", enabled);
}

void Viewport::renderTileTextures(bgfx::ViewId const& viewId, Tiles::TileTextureInfo const& renderInfo)
{
	LUCID_PROFILE_SCOPE("terrain textures");

	uint16_t meshRes = 1;
	if (mStyle->hasTerrain())
	{
		auto const& source = mStyle->source(mStyle->terrain()->source);
		auto height = std::static_pointer_cast<Styling::RasterDemSource const>(source);
		meshRes = MapMath::meshResolution(*height, renderInfo.id);
	}

	if (renderInfo.isReady) //checks if samplers, etc all match up
	{
		//auto texCount = renderInfo.layerCount;

		auto subsetCount = std::min(size_t(renderInfo.layerCount), mTerrainShader.count() - 1);

		auto shader = mTerrainShader.getShader((int)subsetCount);
		MAP3D_ASSERT(shader != nullptr, "Unable to retrieve shader for requested ConfigurableShader/texture count subset");

		ShaderParam* sp = shader->parameters["u_tileSize"];
		if (sp != nullptr)
		{
			sp->setValue(lgal::gpu::Vector3((float)renderInfo.tileSize.x, (float)renderInfo.tileSize.y, (float)sp->mVec3.z));
		}

		shader->setParameter("u_tileDistortion", lgal::world::Vector3{ renderInfo.distortion, 0.0});

		sp = shader->parameters["u_heightTileSize"];
		if (sp != nullptr)
		{
			float size = (float)Tiles::TileId::LevelToTileExtent(renderInfo.heightAtlasInfo.level);

			sp->setValue(lgal::gpu::Vector3(size, size, sp->mVec3.z));
		}		

		// TODO: Merge the height textures once bgfx bug is resolved
		setTextureParameters(renderInfo.heightAtlasInfo, shader.get(), TextureType::HeightVert);
		setTextureParameters(renderInfo.heightAtlasInfo, shader.get(), TextureType::HeightFrag);
		setTextureParameters(renderInfo.basemap, shader.get(), TextureType::Basemap);
		if (renderInfo.layers[0].isValid())
		{
			setTextureParameters(renderInfo.layers[0], shader.get(), TextureType::Roads);
			if (renderInfo.layers[1].isValid())
			{
				setTextureParameters(renderInfo.layers[1], shader.get(), TextureType::LocalData);
			}
		}

		auto tileMin = renderInfo.tileMin - mViewportState.mCameraState.position;
		auto tileMax = renderInfo.tileMax - mViewportState.mCameraState.position;
		tileMax.z = renderInfo.tileSize.x;

		shader->setParameter("u_tileMin", tileMin);
		shader->setParameter("u_tileMax", tileMax);

		world_float_t topoMinor = mViewportState.getTopoMinor() / 1000.0f;
		world_float_t topoMajor = mViewportState.getTopoMajor() / 1000.0f;
		world_float_t minorDistanceFade = mViewportState.getTopoMinorHeightFade();
		world_float_t majorDistanceFade = mViewportState.getTopoMajorHeightFade();

		shader->setParameter("u_TopoParams", lgal::gpu::Vector3((gpu_float_t)topoMinor, (gpu_float_t)topoMajor, 1.0f));
		shader->setParameter("u_TopoHeightFade", lgal::gpu::Vector3((gpu_float_t)minorDistanceFade, (gpu_float_t)majorDistanceFade, 1.0f));
		shader->setParameter("u_majorTopoColor", lgal::gpu::Vector3(mViewportState.getTopoMajorColor().r, mViewportState.getTopoMajorColor().g, mViewportState.getTopoMajorColor().b));
		shader->setParameter("u_minorTopoColor", lgal::gpu::Vector3(mViewportState.getTopoMinorColor().r, mViewportState.getTopoMinorColor().g, mViewportState.getTopoMinorColor().b));

		if (mViewportState.getSunlightOn())
		{
			mViewportState.mSunShadow->setDrawShaderParams(&mViewportState, renderInfo, shader);
		}
		setTerrainToolsUniforms(shader);

		if (mViewportState.mViewshed != nullptr)
		{
			mViewportState.mViewshed->setTerrainParameters(shader);
		}

		//draw mesh
		Tiles::TileMesh::Instance(meshRes)->draw(renderInfo.id, mViewportState.mCameraState.position, mViewportState.mCameraState.heading, shader->programHandle, viewId, false);
	}
	else
	{
		auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0);
		shader->setParameter("u_tileMin", renderInfo.tileMin - mViewportState.mCameraState.position);
		shader->setParameter("u_tileMax", renderInfo.tileMax - mViewportState.mCameraState.position);
		Tiles::TileMesh::Instance(meshRes)->draw(renderInfo.id, mViewportState.mCameraState.position, mViewportState.mCameraState.heading, shader->programHandle, viewId, false);
	}
}

void Viewport::drawTerrainVectors(bgfx::ViewId viewId, Tiles::TileVectorInfo const& info, std::shared_ptr<Styling::FillLayer const> layer, Shaders::ShaderDefinition *shader, uint64_t flags)
{
	// render states
	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
#ifdef ENABLE_MSAA
		| BGFX_STATE_MSAA
#endif
		| BGFX_STATE_WRITE_Z
		| BGFX_STATE_BLEND_ALPHA
		| BGFX_STATE_DEPTH_TEST_LEQUAL
		;

	Caching::LayerCache::EntryKey key = { info.id, layer->id };
	lgal::gpu::Vector4 fragClip = { 0, 0, 1, 1 };	// TODO try using a stencil buffer to clip fragments to the rendered tile

	Caching::PreparedFillData::Buffer_t const* buffer = nullptr;

	// search cache for any buffer we can find
	for (int i = key.tileId.level; !buffer && i >= 0; --i)
	{
		if (mCoveredFills.find({ key.tileId, layer->id }) != mCoveredFills.end())
		{
			break;
		}

		Caching::LayerCache::EntryKey modulo = { key.tileId.moduloX(), key.layerId };
		if (mLayerCache->isPrepared(modulo))
		{
			auto const& entry = mLayerCache->at(modulo);
			auto prepared = std::static_pointer_cast<Caching::PreparedFillData const>(entry.prepared);
			buffer = prepared->buffer.get();
		}
		else
		{
			key.tileId = key.tileId.parent();
		}
	}

	if (buffer)
	{
		Tiles::TileVectorInfo rendered = info;
		if (key.tileId < info.id)
		{
			rendered = Tiles::TileVectorInfo{ key.tileId, rendered.useTimestamp };
			if (mStyle->hasTerrain())
			{
				auto terrain = mStyle->terrain();
						
				Caching::Source const& source = Caching::TileCache::Instance()->getSource(terrain->source);
				rendered.heightAtlasInfo = GetTextureAtlasInfo(source.atlas(), key.tileId.moduloX(), source.specification()->range());
			}
		}

		auto tileMin = (rendered.tileMin - mViewportState.mCameraState.position).as<gpu_float_t>();
		auto tileMax = (rendered.tileMax - mViewportState.mCameraState.position).as<gpu_float_t>();
		tileMax.z = (gpu_float_t)rendered.tileSize.x;

		mCoveredFills.insert({ rendered.id, layer->id });

		shader->setParameter("u_TileFragClip", fragClip);

		if (mViewportState.getVectorWireframes())
		{
			bgfx::setDebug(BGFX_DEBUG_WIREFRAME);
		}

		setTextureParameters(rendered.heightAtlasInfo, shader, TextureType::HeightVert);

		if (mViewportState.getVectorRenderRange() == lucid::gal::Range(-1, -1))
		{
			for (auto i = 0ull; i < buffer->numVertexPages(); ++i)
			{
				buffer->attachPageBuffers(i);
				setTextureParameters(rendered.heightAtlasInfo, shader, TextureType::HeightVert);

				Atlases::FillStyleAtlas const& fillStyles = mLayerCache->getFillStyles();
				shader->setParameter("s_vectorColors", fillStyles.getColorHandle());
				shader->setParameter("s_vectorPatterns", fillStyles.getPatternCoordsHandle());
				shader->setParameter("s_patterns", fillStyles.getPatternAtlasHandle(), 256, 256);
				shader->setParameter("u_tileDistortion", lgal::world::Vector3{ rendered.distortion, 0.0 });
				shader->setParameter("u_screenResolution", lgal::gpu::Vector3{ size().as<gpu_float_t>(), 0 });
				shader->setParameter("u_tileMin", tileMin);
				shader->setParameter("u_tileMax", tileMax);
				shader->setParameter("u_tileVectorData", lgal::gpu::Vector3(std::floor(mViewportState.getZoom()), 0, 0));

				// Set render states

				bgfx::setState(state | flags);
				bgfx::submit(viewId, shader->programHandle);
			}
		}
		else
		{
			auto maxVector = int(buffer->numVectors()) - 1;

			if (mViewportState.getVectorRenderRange().begin > maxVector)
			{
				return; // Nothing to do
			}

			auto first = std::min(std::max(0, mViewportState.getVectorRenderRange().begin), maxVector);
			auto last = std::min(maxVector, mViewportState.getVectorRenderRange().end);

			auto firstPage = buffer->getVectorPage(first);
			auto lastPage = (first == last) ? firstPage : buffer->getVectorPage(last);

			if (firstPage >= buffer->numVertexPages() || lastPage >= buffer->numVertexPages())
			{
				return;
			}

			for (auto i = firstPage; i <= lastPage; ++i)
			{
				lucid::gal::Range range = { -1, std::numeric_limits<int>::max() };

				if (i == firstPage)
				{
					auto firstRange = buffer->getVectorRange(first);
					range.begin = (int)firstRange.begin;
					if (last == first)
					{
						range.end = (int)firstRange.end;
					}
				}

				if (i == lastPage && last != first)
				{
					auto lastRange = buffer->getVectorRange(last);
					range.end = (int)lastRange.end;
				}

				buffer->attachPageBuffers(i, range);

				Atlases::FillStyleAtlas const& fillStyles = mLayerCache->getFillStyles();
				shader->setParameter("s_vectorColors", fillStyles.getColorHandle());
				shader->setParameter("s_vectorPatterns", fillStyles.getPatternCoordsHandle());
				shader->setParameter("s_patterns", fillStyles.getPatternAtlasHandle(), 256, 256);
				shader->setParameter("u_tileDistortion", lgal::world::Vector3{ rendered.distortion, 0.0 });
				shader->setParameter("u_screenResolution", lgal::gpu::Vector3{ size().as<gpu_float_t>(), 0 });
				shader->setParameter("u_tileVectorData", lgal::gpu::Vector3(std::floor(mViewportState.getZoom()), 0, 0));

				shader->setParameter("u_tileMin", tileMin);
				shader->setParameter("u_tileMax", tileMax);

				bgfx::setState(state | flags);
				bgfx::submit(viewId, shader->programHandle);
			}
		}
	}
}

void Viewport::drawLineInstances(bgfx::ViewId const& viewId, Tiles::TileVectorInfo const& info, float32_t fade, std::shared_ptr<Styling::LineLayer const> layer, Shaders::ShaderDefinition* shader)
{
	Caching::LayerCache::EntryKey key = { info.id.moduloX(), layer->id };
	std::shared_ptr<Caching::PreparedLineData const> prepared = nullptr;

	lgal::gpu::AABB2d everything = lgal::gpu::AABB2d::everything();
	lgal::gpu::Vector4 fragClip = { everything.min, everything.max };
			
	for (int i = key.tileId.level; !prepared && i >= 0; --i)
	{
		if (mLayerCache->isPrepared(key))
		{
			if (key.tileId.level < info.id.level)
			{
				auto bounds = Tiles::TileId::InternalBounds(key.tileId, info.id.moduloX());
				fragClip = { bounds.min, bounds.max };
			}

			auto const& entry = mLayerCache->at(key);
			prepared = std::static_pointer_cast<Caching::PreparedLineData const>(entry.prepared);
		}
		else
		{
			key.tileId = key.tileId.parent();
		}
	}

	if (prepared)
	{
		uint32_t start = 0;
		uint32_t num = uint32_t(prepared->count);

		if (mViewportState.getVectorRenderRange().end != -1)		// if necessary, filter from debug ui
		{
			// TODO (stouff) make this apply to features -- currently only applies to instances
			auto maxVector = int(prepared->count) - 1;
			if (prepared->count < 1 || mViewportState.getVectorRenderRange().begin > maxVector)
			{
				return; // Nothing to do
			}

			auto first = std::min(std::max(0, mViewportState.getVectorRenderRange().begin), maxVector);
			auto last = std::min(maxVector, mViewportState.getVectorRenderRange().end);

			start = uint32_t(first);
			num = uint32_t(last - first);
		}
		
		shader->setParameter("u_TileFragClip", fragClip);

		Tiles::TileVectorInfo rendered = info;
		if (key.tileId.level < info.id.level)
		{
			rendered = Tiles::TileVectorInfo{ info.id.parentAtLevel(key.tileId.level), rendered.useTimestamp };

			if (mStyle->hasTerrain())
			{
				auto terrain = mStyle->terrain();

				Caching::Source const& heightSource = Caching::TileCache::Instance()->getSource(terrain->source);
				rendered.heightAtlasInfo = GetTextureAtlasInfo(heightSource.atlas(), key.tileId, heightSource.specification()->range());
			}
		}

		drawTerrainLines(viewId, rendered, prepared->handle, start, num, fade, shader);
	}
}

void Viewport::renderTileVectors(bgfx::ViewId const& viewId, Tiles::TileVectorInfo& renderInfo, std::shared_ptr<Styling::Layer const> layer, Shaders::ShaderDefinition* shader)
{
	LUCID_PROFILE_SCOPE("terrain vectors");

	if (mViewportState.getTerrainWireframes())
	{
		bgfx::setDebug(BGFX_DEBUG_WIREFRAME);
	}

	float32_t alpha = 1.0f;

	// TODO (stouff) reintroduce fade in/out
	//auto fadeIn = renderInfo.useTimestamp - renderInfo.addTimestamp;
	//auto fadeOut = mCurrentFrameTime - renderInfo.useTimestamp;
	//if (fadeIn < getVectorFadeTime() || fadeOut > 0)
	//{
	//	alpha = float32_t(std::min(fadeIn / getVectorFadeTime(), 1.));
	//	if (fadeOut > 0)
	//	{
	//		alpha *= (1 - float32_t(fadeOut / getVectorFadeTime()));
	//	}
	//}

	if (renderInfo.childIsLoading && getVectorDownloadPulseTimeMS() > 0)
	{
		double interval = std::fmod(mCurrentFrameTime, getVectorDownloadPulseDelayMS() + getVectorDownloadPulseTimeMS());

		if (interval < getVectorDownloadPulseTimeMS())
		{
			auto period = interval * (lucid::math::constants::two_pi<double>() / getVectorDownloadPulseTimeMS());

			float32_t pulse = float32_t(lucid::math::periodic(0., 0.3, period));
			renderInfo.color.a = pulse;
		}
		else
		{
			renderInfo.color.a = 0;
		}
	}
	else
	{
		renderInfo.color.a = 0;
	}

	if (layer->type == Styling::Layer::Type::FILL && mViewportState.getShowFilledVectors())
	{
		LUCID_PROFILE_SCOPE("draw fills");
		shader->setParameter("u_vectorFade", alpha);
		drawTerrainVectors(viewId, renderInfo, std::static_pointer_cast<Styling::FillLayer const>(layer), shader);
	}

	if (layer->type == Styling::Layer::Type::LINE && mViewportState.getShowVectorLines())
	{
		LUCID_PROFILE_SCOPE("draw lines");
		shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::TerrainLine, 0).get();
		drawLineInstances(viewId, renderInfo, alpha, std::static_pointer_cast<Styling::LineLayer const>(layer), shader);
	}
}

bool Viewport::gatherTextureRenderInfo(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("gather texture render info");
	bool complete = true;

	for (auto& tileId : tiles)
	{
		auto ri = mViewportState.mTileRenderInfo.find(tileId);
		if (ri == mViewportState.mTileRenderInfo.end())
		{
			mViewportState.mTileRenderInfo.insert({ tileId, Tiles::TileTextureInfo(tileId) });
			ri = mViewportState.mTileRenderInfo.find(tileId);
		}

		if (!ri->second.isComplete)
		{
			gatherTileTextureInfo(tileId.moduloX(), ri->second);
		}

		complete &= ri->second.isComplete;
	}

	return complete;
}

bool Viewport::gatherVectorRenderInfo(std::vector<Tiles::TileId> const& tiles)
{
	LUCID_PROFILE_SCOPE("gather vector render info");
	bool complete = true;

	if (!mStyle->hasTerrain())
	{
		return false;
	}

	std::shared_ptr<Styling::Terrain const> terrain = mStyle->terrain();
	auto heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(mStyle->source(terrain->source));
	lmath::Range<Tiles::TileId::IdCoordsT> heightZoomRange = heightSpec->range();

	auto heightAtlas = getHeightAtlas();

	for (Tiles::TileId const& requestId : tiles)	// loop over all tiles
	{
		LUCID_PROFILE_SCOPE("cache tile data");
		
		for (auto const& layer : mStyle->layers<Styling::SourcedLayer>())	// loop over all layers
		{
			Caching::Source const& source = Caching::TileCache::Instance()->getSource(layer->source);
			
			// check that we want to actually process this layer
			float zoom = mViewportState.mZoom;
			bool outsideZoom = !(static_cast<float>(layer->minZoom) <= zoom && zoom <= static_cast<float>(layer->maxZoom));
			if (!layer->isVisible()
				|| !source.specification()->isVector()
				|| outsideZoom
				|| requestId.level < source.specification()->minZoom)
			{
				continue;
			}

			// prepare the (spatially) largest tile we can that will still satisfy all of our detail requirements. this
			// will result in fewer draw calls
			int maxLevel = std::max(MapMath::maxDetailZoom(*heightSpec), source.specification()->maxZoom);
			Tiles::TileId prepareId = (requestId.level <= maxLevel) ? requestId : requestId.parentAtLevel(maxLevel);

			Pyramid::TilePyramid<Tiles::VectorTile> const* pyramid = source.pyramid();

			auto ri = mViewportState.mVectorRenderInfo.find(prepareId);
			if (ri == mViewportState.mVectorRenderInfo.end())
			{
				mViewportState.mVectorRenderInfo.emplace(prepareId, Tiles::TileVectorInfo(prepareId, mCurrentFrameTime));
				ri = mViewportState.mVectorRenderInfo.find(prepareId);

				if (mViewportState.getDebugVectorColors())
				{
					ri->second.color = lgal::Color::HashColor(prepareId, int(std::hash<std::string>()(layer->source)), 0xFF);
				}
			}
			else
			{
				ri->second.touch(mCurrentFrameTime);
			}

			prepareId = prepareId.moduloX();

			// collect height info
			auto atlasInfo = GetTextureAtlasInfo(heightAtlas, prepareId, heightZoomRange);
			if (atlasInfo.isValid())
			{
				ri->second.isReady = true;
				ri->second.heightAtlasInfo = atlasInfo;
				ri->second.meshResolution = (mStyle->hasTerrain()) ? MapMath::meshResolution(*heightSpec, prepareId) : 1;
			}

			std::shared_ptr<Tiles::VectorTile const> vectorTile = pyramid->find(prepareId, true);
			std::shared_ptr<Tiles::HeightTile const> heightTile = heightAtlas->find(prepareId, true);

			if (vectorTile == nullptr || heightTile == nullptr) // No vectors available to display
			{
				continue;
			}

			if (prepareId.level > vectorTile->id().level)
			{
				ri->second.childIsLoading = vectorTile->id().level < source.specification()->maxZoom;
			}
			else
			{
				ri->second.childIsLoading = false;
			}

			if (layer->type == Styling::Layer::Type::LINE
				|| layer->type == Styling::Layer::Type::FILL
				|| layer->type == Styling::Layer::Type::SYMBOL)
			{
				Caching::LayerCache::EntryKey key = { prepareId, layer->id };
				Caching::PreparedData::Metadata metadata =
				{
					layer->type,
					vectorTile->id(), std::max(vectorTile->timestampMS(layer->sourceLayer), heightTile->timestampMS()),
					mViewportState.getZoom(), mViewportState.mCameraState,
					MapMath::meshResolution(*heightSpec, prepareId),
					mStyle->getContext()
				};

				if (mLayerCache->replaces(key, metadata))
				{
					Caching::LayerCache::task_ptr_t task;
					switch (layer->type)
					{
					case Styling::Layer::Type::LINE:
						task.reset(new Caching::Tasks::VectorLineTask(mViewportState.mCameraState, prepareId, metadata, layer, vectorTile));
						break;
					case Styling::Layer::Type::FILL:
						task.reset(new Caching::Tasks::VectorFillTask(mViewportState.mCameraState, prepareId, metadata, layer, vectorTile));
						break;
					case Styling::Layer::Type::SYMBOL:
						task.reset(new Caching::Tasks::VectorSymbolTask(mViewportState.mCameraState, prepareId, metadata, layer, vectorTile, heightTile));
						break;
					default:
						break;
					}
					mLayerCache->insert(key, std::move(task));
				}
				else
				{
					mLayerCache->touch(key);
				}
			}
		}
	}

	for (std::shared_ptr<Styling::SourcedLayer const> const& layer : mStyle->layers<Styling::SourcedLayer>())
	{
		LUCID_PROFILE_SCOPE("Cache contour data");

		std::shared_ptr<Styling::Source const> source = mStyle->source(layer->source);

		if (!source->isHeight() || !layer->isVisible())
		{
			continue;
		}

		std::vector<Tiles::TileId> filtered = Tiles::TileId::filter(tiles, std::max(layer->minZoom, source->minZoom), layer->maxZoom);
		
		for (Tiles::TileId const& tileId : filtered)
		{
			if (!heightAtlas->contains(tileId))
			{
				continue;
			}

			auto tile = heightAtlas->at(tileId);
			if (tile == nullptr)
			{
				continue;
			}

			Caching::PreparedData::Metadata metadata = 
			{ 
				layer->type, 
				tileId, tile->timestampMS(),
				mViewportState.getZoom(), mViewportState.mCameraState, 
				MapMath::meshResolution(*heightSpec, tileId), 
				mStyle->getContext()
			};
			Caching::LayerCache::task_ptr_t task(new Caching::Tasks::HeightSymbolTask(tileId, metadata, layer, tile));
			mLayerCache->insert({ tileId, layer->id }, std::move(task));
		}
	}

	return complete;
}

bool Viewport::renderTiles(bgfx::ViewId const& renderId)
{
	bool complete = true;

	// TODO possibly compute/request neighbors of both parents/tileset so that rasters will always have the appropriate padding?

	{
		LUCID_PROFILE_SCOPE("precache tiles");
		std::vector<Caching::TileCacheKey> keys = Viewport::CacheKeys(mViewportState.mTileCollections.rasterGrandparents, mViewportState.mTileCollections.vectorGrandparents, mStyle);
		if (Caching::TileCache::Instance()->precache(keys))
		{
			if (!mViewportState.getCameraMoved())
			{
				// All of the higher-level tiles are cached; start fetching full detail
				keys = Viewport::CacheKeys(mViewportState.mTileCollections.rasters, mViewportState.mTileCollections.vectors, mStyle);
				Caching::TileCache::Instance()->precache(keys);
			}
		}
	}

	{
		LUCID_PROFILE_SCOPE("gather render info");
		complete &= gatherTextureRenderInfo(mViewportState.mTileCollections.rasters);
		complete &= gatherVectorRenderInfo(mViewportState.mTileCollections.vectors);

		// for the moment, we update after gathering vector render info but before rendering
		mLayerCache->update();
	}

	// build height texture and set extents
	{
		LUCID_PROFILE_SCOPE("build height texture");
		auto extents = HeightManager::Instance()->heightExtents(mViewportState.mTileCollections.rasters, false);
		mHeightRanges.buildTexture(extents);
	}

	{
		LUCID_PROFILE_SCOPE("terrain draw");

		if (getSunlightOn())
		{
			if(getSunlightAlwaysUpdate()) //lets us set sunlight to update every frame instead of only when dirt, for debugging in renderdoc
				mViewportState.mSunShadow->update(&mViewportState);
			else
			{
				if (mViewportState.mSunShadow->isDirty() || mViewportState.getCameraMoved())
					mViewportState.mSunShadow->update(&mViewportState);
			}
		}

		if (mViewportState.getShowTextures() && mViewportState.mTileRenderInfo.size() > 0)
		{
			for (auto& tileId : mViewportState.mTileCollections.rasters)
			{
				auto ri = mViewportState.mTileRenderInfo.find(tileId);
				if (ri->second.isReady)
				{
					renderTileTextures(renderId, ri->second);
				}
			}
		}
		if (mViewportState.getShowVectors())
		{
			mCoveredFills.clear();

			auto vectorShader = mVectorShader.getShader(0);

			std::shared_ptr<Styling::RasterDemSource const> heightSpec = nullptr;
			if (mStyle->hasTerrain())
			{
				std::shared_ptr<Styling::Source const> const& source = mStyle->source(mStyle->terrain()->source);
				heightSpec = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			}

			for (std::shared_ptr<Styling::SourcedLayer const> layer : mStyle->layers<Styling::SourcedLayer>())
			{
				bool outsideZoom = !(static_cast<float>(layer->minZoom) <= mViewportState.mZoom && mViewportState.mZoom <= static_cast<float>(layer->maxZoom));
				if (outsideZoom || !layer->isVisible())
				{
					continue;
				}

				std::shared_ptr<Styling::Source const> source = mStyle->source(layer->source);

				int maxZoom = std::max((heightSpec) ? MapMath::maxDetailZoom(*heightSpec) : 0, source->maxZoom);
				std::vector<Tiles::TileId> clamped = Tiles::TileId::uniqueClampedToMaxLevel(mViewportState.mTileCollections.vectors, maxZoom);
				std::vector<Tiles::TileId> filtered = Tiles::TileId::filter(clamped, source->minZoom, maxZoom);

				for (auto& tileId : filtered)
				{
					auto ri = mViewportState.mVectorRenderInfo.find(tileId);
					if (ri != mViewportState.mVectorRenderInfo.end() && ri->second.isReady)
					{
						renderTileVectors(renderId, ri->second, layer, vectorShader.get());
					}
				}
			}

			// clean up old vector render info
			std::vector<Tiles::TileId> toDelete;
			for (auto& [key, renderInfo] : mViewportState.mVectorRenderInfo)
			{
				if (mCurrentFrameTime - renderInfo.useTimestamp > getVectorFadeTime())
				{
					toDelete.push_back(key);
				}
			}

			for (auto const& key : toDelete)
			{
				mViewportState.mVectorRenderInfo.erase(key);
			}
		}
	}

	return complete;
}

void Viewport::allocateTextures()
{
	// create color texture and set name
	mColorTarg = bgfx::createTexture2D(
		uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), 
		false, 1 , bgfx::TextureFormat::RGBA8, 
		BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP
	);

	if (bgfx::isValid(mColorTarg))
	{
		bgfx::setName(mColorTarg, (mViewportState.getName() + " viewport color tex").c_str());
	}

	mColorReadbackHandle = bgfx::createTexture2D(
		uint16_t(getWidthPixel()), uint16_t(getHeightPixel()),
		false, 1, bgfx::TextureFormat::RGBA8,
		BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP
	);

	MAP3D_ASSERT(bgfx::isValid(mColorReadbackHandle), "Failed to create color readback texture");

	bgfx::setName(mColorReadbackHandle, (mViewportState.getName() + " viewport color readback texture").c_str());

	mDepthTarg = bgfx::createTexture2D(
		uint16_t(getWidthPixel()), uint16_t(getHeightPixel()),
		false, 1, bgfx::TextureFormat::RGBA8,
		BGFX_SAMPLER_MIN_POINT | BGFX_SAMPLER_MAG_POINT | BGFX_TEXTURE_RT | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP
	);

	if (bgfx::isValid(mDepthTarg))
	{
		bgfx::setName(mDepthTarg, (mViewportState.getName() + " viewport RGBA8 float depth texture").c_str());
	}

	// create z buffer texture and set name
	mZBufferFormat = bgfx::isTextureValid(0, false, 1, bgfx::TextureFormat::D24, BGFX_TEXTURE_RT_WRITE_ONLY) ? bgfx::TextureFormat::D24 : bgfx::TextureFormat::D16;
	mZTarg = bgfx::createTexture2D(
		uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), 
		false, 1, mZBufferFormat, BGFX_TEXTURE_RT_WRITE_ONLY
	);

	if (bgfx::isValid(mZTarg))
	{
		bgfx::setName(mZTarg, (mViewportState.getName() + " viewport z buffer").c_str());
	}

	uint64_t requiredCaps = BGFX_CAPS_TEXTURE_BLIT | BGFX_CAPS_TEXTURE_READ_BACK;
	uint64_t caps = bgfx::getCaps()->supported;
	if ((caps & requiredCaps) == requiredCaps)
	{
		mDepthReadbackHandle = bgfx::createTexture2D(
			uint16_t(getWidthPixel()), uint16_t(getHeightPixel()), 
			false, 1, bgfx::TextureFormat::RGBA8, 
			BGFX_TEXTURE_BLIT_DST | BGFX_TEXTURE_READ_BACK | BGFX_SAMPLER_U_CLAMP | BGFX_SAMPLER_V_CLAMP
		);

		if (bgfx::isValid(mDepthReadbackHandle))
		{
			bgfx::setName(mDepthReadbackHandle, (mViewportState.getName() + " viewport RGBA8 depth readback buffer").c_str());
		}
	}
}

void Viewport::deallocateTextures()
{
	if (bgfx::isValid(mColorTarg))
	{
		bgfx::destroy(mColorTarg);
		mColorTarg = BGFX_INVALID_HANDLE;
	}
	if (bgfx::isValid(mDepthTarg))
	{
		bgfx::destroy(mDepthTarg);
		mDepthTarg = BGFX_INVALID_HANDLE;
	}
	if (bgfx::isValid(mZTarg))
	{
		bgfx::destroy(mZTarg);
		mZTarg = BGFX_INVALID_HANDLE;
	}
	if (bgfx::isValid(mColorReadbackHandle))
	{
		bgfx::destroy(mColorReadbackHandle);
		mColorReadbackHandle = BGFX_INVALID_HANDLE;
	}
	if (bgfx::isValid(mDepthReadbackHandle))
	{
		bgfx::destroy(mDepthReadbackHandle);
		mDepthReadbackHandle = BGFX_INVALID_HANDLE;
	}
}

void Viewport::allocateFramebuffers()
{
	// first deallocate all the old frame buffers
	deallocateFramebuffers();

	bgfx::TextureHandle colorDepthZHandles[] = { mColorTarg, mDepthTarg, mZTarg };
	// create frame buffer and set name
	mColorDepthZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorDepthZHandles), colorDepthZHandles, false);
	if (bgfx::isValid(mColorDepthZFrameBuffer))
	{
		bgfx::setName(mColorDepthZFrameBuffer, (mViewportState.getName() + " viewport color/depth/z framebuffer").c_str());
	}

	bgfx::TextureHandle colorZHandles[] = { mColorTarg, mZTarg };
	// create frame buffer and set name
	mColorZFrameBuffer = bgfx::createFrameBuffer(BX_COUNTOF(colorZHandles), colorZHandles, false);
	if (bgfx::isValid(mColorZFrameBuffer))
	{
		bgfx::setName(mColorZFrameBuffer, (mViewportState.getName() + " viewport color/z framebuffer").c_str());
	}
}

void Viewport::deallocateFramebuffers()
{
	if (bgfx::isValid(mColorZFrameBuffer))
	{
		bgfx::destroy(mColorZFrameBuffer);
		mColorZFrameBuffer = BGFX_INVALID_HANDLE;
	}
	if (bgfx::isValid(mColorDepthZFrameBuffer))
	{
		bgfx::destroy(mColorDepthZFrameBuffer);
		mColorDepthZFrameBuffer = BGFX_INVALID_HANDLE;
	}
}

void Viewport::toggleComponent(ShaderEnums::ConfigurableShaders shader, std::string const& component, bool on)
{
	invalidate();
	if (shader == ShaderEnums::ConfigurableShaders::Terrain)
	{
		mTerrainShader.toggleComponent(component, on);
	}
}

void Viewport::setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration)
{
	invalidate();
	if (shader == ShaderEnums::ConfigurableShaders::Terrain)
	{
		mTerrainShader.setCurrentShaderByParams(params, configuration);
	}
}

void Viewport::invalidate()
{
	mViewportState.invalidate();
}

void Viewport::toggleHeightRanges(bool enabled)
{
	if (mViewportState.getHeightRangesOn() == enabled)
	{
		return;
	}
	setHeightRangesOn(enabled);
	if (!mViewportState.getIntersectTerrain())
	{
		toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "HeightShade", enabled);
	}
}

void Viewport::toggleSlopeAngleRanges(bool enabled)
{
	if (mViewportState.getSlopeAngleRangesOn() == enabled)
	{
		return;
	}
	setSlopeAngleRangesOn(enabled);
	if (!mViewportState.getIntersectTerrain())
	{
		toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeShade", enabled);
	}
}

void Viewport::toggleSlopeDirRanges(bool enabled)
{
	if (mViewportState.getSlopeDirRangesOn() == enabled)
	{
		return;
	}
	setSlopeDirRangesOn(enabled);
	if (!mViewportState.getIntersectTerrain())
	{
		toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "SlopeDirection", enabled);
	}
}

void Viewport::setHeightRanges(std::vector<lgal::world::Range> const& ranges)
{
	invalidate();
	mViewportState.setHeightRangesKm(ranges);
	// TODO integrate this with TerrainBaseEffect
	mHeightRanges.setRanges(ranges);
}

void Viewport::setSlopeDirRanges(std::vector<lgal::world::Range> const& ranges)
{
	invalidate();
	mViewportState.setSlopeDirRangesRad(ranges);
	// TODO integrate this with TerrainBaseEffect
	mSlopeAspectRanges.setRanges(ranges);
	mSlopeAspectRanges.buildTexture();
}

void Viewport::setSlopeAngleRanges(std::vector<lgal::world::Range> const& ranges)
{
	invalidate();
	mViewportState.setSlopeAngleRangesRad(ranges);
	// TODO integrate this with TerrainBaseEffect
	mSlopeAngleRanges.setRanges(ranges);
	mSlopeAngleRanges.buildTexture();
}

void Viewport::addLabel(std::string text, lgal::world::Vector3 const& pos)
{
	mViewportState.mLabelCollection.append("viewport_" + mViewportState.getName(), std::shared_ptr<DO::MapLabel>(new DO::MapLabel{ text, pos }));
}

void Viewport::setSunlightEnabled(bool on)
{
	toggleComponent(ShaderEnums::ConfigurableShaders::Terrain, "Sunlight", on);
	setSunlightOn(on);
}

void Viewport::setSunlightTime(int year, int month, int day, float timezone, float hours24)
{
	JulianDate jd;
	jd.year = year;
	jd.month = month;
	jd.day = day;
	jd.timezone = timezone;
	jd.hours24 = hours24;
	mViewportState.mSunShadow->setTimeDate(jd);
}

void Viewport::setStyle(std::shared_ptr<Styling::Style> style)
{
	mStyle = style;
	mLayerCache->clear();
	invalidate();

	// TODO (Ronald): We should offload this to a separate thread since the string is a URL
	if (style->hasSprite())
	{
		mViewportState.mIconRenderer->loadSprite(style->mSprite);
	}
}

void Viewport::syncSources()
{
	Styling::Source::zoom_level_t maxZoom = 0;
	for (auto const& name : mStyle->activeSources())
	{
		std::shared_ptr<Styling::Source const> source = mStyle->source(name);
		if (source->isHeight())
		{
			auto height = std::static_pointer_cast<Styling::RasterDemSource const>(source);
			maxZoom = std::max(maxZoom, MapMath::maxDetailZoom(*height));
		}
		else
		{
			maxZoom = std::max(maxZoom, source->maxZoom);
		}
	}
	mViewportState.setMaxSubdDepth(maxZoom);

	// add all dirty sources to TileCache
	for (std::string const& name : mStyle->dirtySourceNames())
	{
		// if TileCache already knows about a tiled source, it won't do anything
		Caching::TileCache::Instance()->addSource(name, mStyle->source(name));
	}

	// prefetch the top level tiles
	for (auto const& [name, source] : mStyle->sources())
	{
		if (source->minZoom == 0)
		{
			Caching::TileCache::Instance()->at({ name, { 0, 0, 0 } }, false);
		}
	}
}

void Viewport::syncLayers()
{
	// update LayerCache with a non-immediate purge of all dirty layers
	for (std::string const& layerId : mStyle->dirtyLayerIds())
	{
		mLayerCache->purge(layerId, false);
	}
}

std::vector<Caching::TileCacheKey> Viewport::CacheKeys(std::vector<Tiles::TileId> const& rasters, std::vector<Tiles::TileId> const& vectors, std::shared_ptr<Styling::Style const> style)
{
	LUCID_PROFILE_SCOPE("compute cache keys");
	
	std::vector<Tiles::TileId> rastersModuloX = Tiles::TileId::uniqueModuloX(rasters);
	std::vector<Tiles::TileId> vectorsModuloX = Tiles::TileId::uniqueModuloX(vectors);

	std::unordered_set<Tiles::TileId> const vectorSet(vectorsModuloX.begin(), vectorsModuloX.end());

	std::vector<std::string> activeSources = style->activeSources();

	std::vector<Caching::TileCacheKey> keys;
	keys.reserve(activeSources.size() * rastersModuloX.size());

	// only iterate over rasters because we assume vectors is a subset of rasters
	for (Tiles::TileId const& requestId : rastersModuloX)
	{
		for (std::string const& name : activeSources)
		{
			std::shared_ptr<Styling::Source const> const& source = style->source(name);

			if (source->minZoom <= requestId.level)
			{
				if (source->isRaster())
				{
					// adjust based on the resolution of the height tiles
					auto raster = std::static_pointer_cast<Styling::RasterSource const>(source);
					auto adjustment = Tiles::TileId::IdCoordsT(std::log2(std::max(raster->tileSize / 256, 1u)));
					Tiles::TileId submittedId = requestId.parent(std::min(adjustment, requestId.level - source->minZoom));
					submittedId = (submittedId.level <= source->maxZoom) ? submittedId : submittedId.parentAtLevel(source->maxZoom);
					keys.push_back({ name, submittedId });
				}
				else if (source->isVector() && vectorSet.find(requestId) != vectorSet.end())
				{
					Tiles::TileId submittedId = (requestId.level <= source->maxZoom) ? requestId : requestId.parentAtLevel(source->maxZoom);
					keys.push_back({ name, submittedId });
				}
			}
		}
	}

	return keys;
}

}
