#include "ViewportManager.h"
#include <lucid/Profiler.h>
#include "../Map3D.h"
#include "../DataObjects/DashStyleManager.h"
#include "../DataObjects/MapLabel.h"

ViewportManager* ViewportManager::sSingleton = nullptr;

ViewportManager* ViewportManager::Instance()
{
	if (sSingleton == nullptr)
	{
		sSingleton = new ViewportManager();
	}
	return sSingleton;
}

void ViewportManager::Shutdown()
{
	if (sSingleton != nullptr)
	{
		delete sSingleton;
		sSingleton = nullptr;
	}
}

ViewportManager::~ViewportManager()
{
	for (auto& [name, vp] : mViewports)
	{
		delete vp;
		vp = nullptr;
	}

	mViewports.clear();

	if (bgfx::isValid(mVertexBuffer))
		bgfx::destroy(mVertexBuffer);
	if (bgfx::isValid(mIndexBuffer))
		bgfx::destroy(mIndexBuffer);
}

void ViewportManager::init(uint32_t w, uint32_t h)
{
	mScreenWidth = w;
	mScreenHeight = h;
	onyx::ViewportState::setScreenSize(float(w), float(h));

	bx::mtxLookAt(viewMat, bx::Vec3(0,0,10), bx::Vec3(0,0,0), bx::Vec3(0,1,0));
	if (bgfx::getCaps()->originBottomLeft)
	{
		bx::mtxOrtho(projMat, 0, -float(mScreenWidth), 0, float(mScreenHeight), 0.01, 20, 0, false);
		
		// subtract 1 from y coord so position specifies the top left corner
		mVertData[0] = onyx::Rendering::VertStructs::PosColorUV(0, 0 - 1, 0, 0xFFFFFFFF, 0, 0);
		mVertData[1] = onyx::Rendering::VertStructs::PosColorUV(0, 1 - 1, 0, 0xFFFFFFFF, 0, 1);
		mVertData[2] = onyx::Rendering::VertStructs::PosColorUV(1, 1 - 1, 0, 0xFFFFFFFF, 1, 1);
		mVertData[3] = onyx::Rendering::VertStructs::PosColorUV(1, 0 - 1, 0, 0xFFFFFFFF, 1, 0);
	}
	else
	{
		bx::mtxOrtho(projMat, 0, -float(mScreenWidth), float(mScreenHeight), 0, 0.01, 20, 0, false);

		mVertData[0] = onyx::Rendering::VertStructs::PosColorUV(0, 0, 0, 0xFFFFFFFF, 0, 0);
		mVertData[1] = onyx::Rendering::VertStructs::PosColorUV(0, 1, 0, 0xFFFFFFFF, 0, 1);
		mVertData[2] = onyx::Rendering::VertStructs::PosColorUV(1, 1, 0, 0xFFFFFFFF, 1, 1);
		mVertData[3] = onyx::Rendering::VertStructs::PosColorUV(1, 0, 0, 0xFFFFFFFF, 1, 0);
	}

	mIdxData[0] = 0;
	mIdxData[1] = 1;
	mIdxData[2] = 2;
	mIdxData[3] = 0;
	mIdxData[4] = 2;
	mIdxData[5] = 3;

	// create static vertex buffer
	mVertexBuffer = bgfx::createVertexBuffer(
		// static data can be passed with bgfx::makeRef
		bgfx::makeRef(mVertData.data(), (uint32_t)(sizeof(onyx::Rendering::VertStructs::PosColorUV) * mVertData.size()))
		, onyx::Rendering::VertStructs::PosColorUV::ms_layout
	);
	bgfx::setName(mVertexBuffer, "ViewportManagerVerts");

	// create static index buffer
	mIndexBuffer = bgfx::createIndexBuffer(
		// static data can be passed with bgfx::makeRef
		bgfx::makeRef(mIdxData.data(), (uint32_t)(sizeof(uint16_t) * mIdxData.size()))
	);
	bgfx::setName(mIndexBuffer, "ViewportManagerIndices");
}

void ViewportManager::setScreenSize(uint32_t w, uint32_t h)
{
	if (mScreenWidth != w || mScreenHeight != h)
	{
		mScreenWidth = w;
		mScreenHeight = h;
		onyx::ViewportState::setScreenSize(float(w), float(h));

		invalidate();

		if (bgfx::getCaps()->originBottomLeft)
		{
			bx::mtxOrtho(projMat, 0, -float(mScreenWidth), 0, float(mScreenHeight), 0.01, 20, 0, false);
		}
		else
		{
			bx::mtxOrtho(projMat, 0, -float(mScreenWidth), float(mScreenHeight), 0, 0.01, 20, 0, false);
		}
		
		for (size_t i = 0; i < mSortableViewports.size(); i++)
		{
			auto vp = mSortableViewports[i];
			vp->resize(); //update all the viewports
		}
	}
}

lucid::math::Vector<uint32_t, 2> ViewportManager::getScreenSize() const
{
	return lucid::math::Vector<uint32_t, 2>{ mScreenWidth, mScreenHeight };
}

void ViewportManager::addViewport(std::string const& name, float wRatio, float hRatio, int sortOrder, cam::CameraState const& state)
{
	auto vp = new onyx::Viewport(name, wRatio, hRatio, state, sortOrder);
	mViewports[name] = vp;
	mSortableViewports.push_back(vp);
	
	//sort by depth, currently only could change when we add another, so only have to sort here
	std::sort(mSortableViewports.begin(), mSortableViewports.end());
}

void ViewportManager::removeViewport(std::string const& name)
{
	for (size_t i = 0; i < mSortableViewports.size(); i++)
	{
		if (mSortableViewports[i] == mViewports[name])
		{
			mSortableViewports.erase(mSortableViewports.begin() + i);
		}
	}

	mViewports.erase(name);
}

onyx::Viewport* ViewportManager::getViewport(std::string const& name) const
{
	if (mViewports.find(name) == mViewports.end())
		return nullptr;

	return mViewports.at(name);
}

onyx::ViewportState* ViewportManager::getViewportState(std::string const& name) const
{
	if (mViewports.find(name) == mViewports.end())
		return nullptr;

	return mViewports.at(name)->getState();
}

onyx::Viewport* ViewportManager::getViewportByPixel(int x, int y) const
{
	for(int i = (int)mSortableViewports.size() - 1; i >= 0; i--)
	{
		auto vp = mSortableViewports[i];
		float px  = vp->getPosX();
		float px2 = vp->getPosX() + vp->getWidthPixel();
		float py  = vp->getPosY();
		float py2 = vp->getPosY() + vp->getHeightPixel();
		if (x >= px && x <= px2 && y >= py && y <= py2)
			return vp;
	}

	return nullptr;	
}

onyx::Viewport* ViewportManager::getViewportByNormalized(lgal::world::Vector2 const& normalizedPos) const
{
	int x = static_cast<int>(((normalizedPos.x + 1.0) / 2.0) * mScreenWidth);
	int y = static_cast<int>(((normalizedPos.y + 1.0) / 2.0) * mScreenHeight);
	return getViewportByPixel(x, y);
}

onyx::ViewportState* ViewportManager::getViewportStateByNormalized(lgal::world::Vector2 const& normalizedPos) const
{
	int x = static_cast<int>(((normalizedPos.x + 1.0) / 2.0) * mScreenWidth);
	int y = static_cast<int>(((normalizedPos.y + 1.0) / 2.0) * mScreenHeight);
	onyx::Viewport* vp = getViewportByPixel(x, y);
	if (vp == nullptr)
		return nullptr;
	return vp->getState();
}

void ViewportManager::invalidate()
{
	for (auto& kvp : mViewports)
	{
		kvp.second->invalidate();
	}
}

void ViewportManager::updateViewports(double timeMS)
{
	for(auto& kvp : mViewports)
	{
		kvp.second->render(timeMS);
	}

	// get depth
	bgfx::ViewId depthViewId = onyx::Rendering::ViewId::next(onyx::Rendering::ViewId::Type::Composite);
	for (auto& kvp : mViewports)
	{
		kvp.second->readDepth(depthViewId); //TODO - add a dirty flag so only the ones that need to update
	}
}


void ViewportManager::drawViewportsToScreen()
{
	LUCID_PROFILE_SCOPE("draw viewports");
	bgfx::ViewId renderId = onyx::Rendering::ViewId::next(onyx::Rendering::ViewId::Type::Composite);
	bgfx::setViewRect(renderId, 0, 0, bgfx::BackbufferRatio::Equal);
	bgfx::setViewClear(renderId, BGFX_CLEAR_COLOR | BGFX_CLEAR_DEPTH, 0xaaeeffff, 1.0f, 0);
	bgfx::setViewFrameBuffer(renderId, BGFX_INVALID_HANDLE);
	bgfx::setViewTransform(renderId, viewMat, projMat);
	bgfx::setViewName(renderId, "Draw Viewports");
	bgfx::touch(renderId);

	bgfx::setViewMode(renderId, bgfx::ViewMode::Sequential);

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::SimpleTexture, 0);

	for (auto& vp : mSortableViewports)
	{
		if (vp->getState()->hasBorder) //quick little border slapped on
		{
			auto ypos = vp->getPosY() - 2;
			if (bgfx::getCaps()->originBottomLeft)
			{
				ypos = float(mScreenHeight) - ypos;
			}

			bx::Vec3 tileMin(vp->getPosX() - 2, ypos, 0);
			bx::Vec3 tileMax(tileMin.x + vp->getWidthPixel() + 4, tileMin.y + vp->getHeightPixel() + 4, 0.0);

			shader->setParameter("u_tileMin", tileMin);
			shader->setParameter("u_tileMax", tileMax);

			// Set vertex and index buffer.
			bgfx::setVertexBuffer(0, mVertexBuffer);
			bgfx::setIndexBuffer(mIndexBuffer);

			// Set render states - maybe should do this higher up?.
			uint64_t state = 0;
			state = 0
				| BGFX_STATE_WRITE_R
				| BGFX_STATE_WRITE_G
				| BGFX_STATE_WRITE_B
				| BGFX_STATE_WRITE_A;

			bgfx::setState(state | BGFX_STATE_PT_TRISTRIP);
			bgfx::submit(renderId, ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0)->programHandle);
		}

		auto ypos = bgfx::getCaps()->originBottomLeft ? float(mScreenHeight) - vp->getPosY() : vp->getPosY();

		bx::Vec3 tileMin(vp->getPosX(), ypos, 0);
		bx::Vec3 tileMax(tileMin.x + vp->getWidthPixel(), tileMin.y + vp->getHeightPixel(), 0.0);

		shader->setParameter("u_tileMin", tileMin);
		shader->setParameter("u_tileMax", tileMax);

		// Set vertex and index buffer.
		bgfx::setVertexBuffer(0, mVertexBuffer);
		bgfx::setIndexBuffer(mIndexBuffer);

		auto sp = ShaderManager::Instance()->getParameter(ShaderEnums::ConfigurableShaders::SimpleTexture, "s_texture0");
		if (sp != nullptr)
		{
			sp->setValue(vp->getTexture(), (int)vp->getWidthPixel(), (int)vp->getHeightPixel());
		}

		shader->setParameter("u_ScaleOffsetTex0", lgal::gpu::Vector4(0,0,1,1));
		
		// Set render states - maybe should do this higher up?.
		uint64_t state = 0;
		state = 0
			| BGFX_STATE_WRITE_R
			| BGFX_STATE_WRITE_G
			| BGFX_STATE_WRITE_B
			| BGFX_STATE_WRITE_A
			| BGFX_STATE_DEPTH_TEST_ALWAYS;

		bgfx::setState(state | BGFX_STATE_PT_TRISTRIP);
		bgfx::submit(renderId, ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::SimpleTexture, 0)->programHandle);
	}

	return;
}

std::shared_ptr<onyx::Camera::CameraController> ViewportManager::getController(int x, int y)
{
	return getViewportByPixel(x, y)->getState()->getController();
}

void ViewportManager::setController(int x, int y, std::shared_ptr<onyx::Camera::CameraController> controller)
{
	auto vp = getViewportByPixel(x, y);
	vp->setController(controller);
}

std::shared_ptr<onyx::Camera::CameraController> ViewportManager::getController(std::string name)
{
	return getViewport(name)->getState()->getController();
}

void ViewportManager::setController(std::string name, std::shared_ptr<onyx::Camera::CameraController> controller)
{
	auto vp = getViewport(name);
	vp->setController(controller);
}


void ViewportManager::addLabel(std::string text, lgal::world::Vector3 const& pos)
{
	for(auto & [name, vp] : mViewports)
	{
		vp->addLabel(text, pos);
	}
}