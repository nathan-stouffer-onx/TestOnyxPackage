#ifndef __VIEWPORT_MANAGER_H__
#define __VIEWPORT_MANAGER_H__

#include <vector>
#include <map>
#include <array>
#include <mutex>
#include <string>

#include <bgfx/bgfx.h>
#include <bx/math.h>

#include "Camera/CameraController.h"
#include "DataObjects/MapLabel.h"
#include "DataObjects/VectorLineMesh.h"
#include "Rendering/VertStructs.h"
#include "Input/UserInputs.h"
#include "Viewport.h"

class ViewportManager
{
public:
	static ViewportManager* Instance();
	static void Shutdown();

	void init(uint32_t w, uint32_t h);
	void setScreenSize(uint32_t w, uint32_t h);
	lmath::Vector<uint32_t, 2> getScreenSize() const;

	void addViewport(std::string const& name, float wRatio, float hRatio, int sortOrder, onyx::Camera::CameraState const& state = { { -11000, -5600.0, 10000.0 } });
	void removeViewport(std::string const& name);
	
	onyx::Viewport* getViewport(std::string const& name) const;
	onyx::Viewport* getViewportByPixel(int x, int y) const;
	onyx::Viewport* getViewportByNormalized(lgal::world::Vector2 const& normalizedPos) const;
	onyx::ViewportState* getViewportStateByNormalized(lgal::world::Vector2 const& normalizedPos) const;

	onyx::ViewportState* getViewportState(std::string const& name) const;

	void updateViewports(double timeMS);
	void drawViewportsToScreen();

	void invalidate();

	std::shared_ptr<onyx::Camera::CameraController> getController(int x, int y);
	void setController(int x, int y, std::shared_ptr<onyx::Camera::CameraController> controller);

	std::shared_ptr<onyx::Camera::CameraController> getController(std::string name);
	void setController(std::string name, std::shared_ptr<onyx::Camera::CameraController> controller);
	void addLabel(std::string text, lgal::world::Vector3 const& pos);

	std::vector<onyx::Viewport*>::const_iterator getSortedViewports() { return mSortableViewports.begin(); }
	std::vector<onyx::Viewport*>::const_iterator sortedViewportsEnd() { return mSortableViewports.end(); }

private:

	ViewportManager() {
		mLineMesh.reset(new onyx::DataObjects::VectorLineMesh());
	}
	~ViewportManager();

	std::map<std::string, onyx::Viewport*> mViewports;
	std::vector<onyx::Viewport*> mSortableViewports;

	float viewMat[16] = { 0 };
	float projMat[16] = { 0 };

	uint32_t mScreenWidth = 1280;
	uint32_t mScreenHeight = 720;
	std::array<onyx::Rendering::VertStructs::PosColorUV, 4> mVertData;
	std::array<uint16_t, 6> mIdxData;

	bgfx::VertexBufferHandle mVertexBuffer = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle mIndexBuffer = BGFX_INVALID_HANDLE;

	std::unique_ptr<onyx::DataObjects::VectorLineMesh> mLineMesh;

protected:
	static ViewportManager* sSingleton;

};
#endif //_VIEWPORTMANAGER_H_