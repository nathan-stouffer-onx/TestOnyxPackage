#ifndef _VIEWPORTSTATE_H_
#define _VIEWPORTSTATE_H_

#include <vector>
#include <unordered_map>

#include <bgfx/bgfx.h>
#include <lucid/gal/Types.h>

#include <lucid/gigl/Context.h>

#include "Tiles/TileRenderInfo.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Camera/Controllers/Identity.h"
#include "Pyramid/Culling.h"
#include "Camera/ScreenSpaceManager.h"
#include "Utils/property.h"
#include "Utils/MapMath.h"
#include "Utils/Timer.h"
#include "Utils/EnumsStructs.h"
#include "DataObjects/LabelCollection.h"
#include "TerrainEffects/Viewshed.h"
#include "TerrainEffects/SunShadow.h"
#include "Rendering/VertStructs.h"
#include "TileCollection.h"
#include "Icon/IconRenderer.h"

namespace onyx {

class Viewport;

class ViewportState
{
	friend class Viewport;
public:
	typedef lucid::math::Range<onyx::Tiles::TileId::IdCoordsT> tileRangeT;
	typedef std::shared_ptr<lucid::gigl::Context> sharedContextT;
	//list of whatever render elements can be toggled on and off per viewport
	enum class RenderItems
	{
		Terrain,
		Waypoint,
		Labels,
		Tracker,
		Icons
	};

	struct RenderStats {
		size_t renderedLineInstances = 0,
			skippedLineInstances = 0;

		void reset()
		{
			renderedLineInstances = 0;
			skippedLineInstances = 0;
		}

		void operator+=(RenderStats const& rhs)
		{
			renderedLineInstances += rhs.renderedLineInstances;
			skippedLineInstances += rhs.skippedLineInstances;
		}

		bool operator==(RenderStats const& rhs)
		{
			return renderedLineInstances == rhs.renderedLineInstances && skippedLineInstances == rhs.skippedLineInstances;
		}
	};

	static float sScreenWidth;
	static float sScreenHeight;
	static void setScreenSize(float width, float height)
	{
		sScreenWidth = width;
		sScreenHeight = height;
	}

	ViewportState();
	ViewportState(std::string const& name, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder);

	// TODO possibly get rid of the scaling in the viewports
	float getAspect() { return getWidthPixel() / getHeightPixel(); }
	float getWidthPixel() const { return mWidthRatio * sScreenWidth; }
	float getHeightPixel() const { return mHeightRatio * sScreenHeight; }
	
	world_float_t getTopoMinorHeightFade();
	world_float_t getTopoMajorHeightFade();

	void setController(std::shared_ptr<Camera::CameraController> controller) { mController = controller; }

	float depthAtPixel(int screenX, int screenY) const;
	float depthAtNormalized(lgal::world::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectPixel(int screenX, int screenY) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const;
	// TODO change architecture so that the unprojected point is more accurate
	// the height discrepancy is really off when the camera is zoomed out
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const;
	lgal::world::Vector3 project(lgal::world::Vector3 const& pos) const;

	// function to convert global input coordinates to coordinates this viewport understands
	lgal::world::Vector2 convertGlobalToViewportCoords(lgal::world::Vector2 const& globalNormalizedCoords) const;

	bool hasBorder = false; //temp hacky bit to add an outline
	
	RenderStats mFrameRenderStats = RenderStats();
	RenderStats mLifetimeRenderStats = RenderStats();

	GET_SET_PROP(Zoom, float, 0.0f);
	GET_SET_PROP(TopoMinor, float, 100.0f);
	GET_SET_PROP(TopoMajor, float, 1000.0f);
	GET_SET_PROP(IntersectTerrain, bool, false);
	GET_SET_PROP(HeightRangesOn, bool, false);
	GET_SET_PROP(SlopeAngleRangesOn, bool, false);
	GET_SET_PROP(SlopeDirRangesOn, bool, false);
	GET_SET_PROP(CullingEnabled, bool, true);
	GET_SET_PROP(QuiescenceMode, bool,  true);
	GET_SET_PROP(HeightRangesKm, std::vector<lgal::world::Range>, { lgal::world::Range(1.0, 1.5) });
	GET_SET_PROP(SlopeAngleRangesRad, std::vector<lgal::world::Range>, { lgal::world::Range(0.0, lucid::math::constants::half_pi<lucid::gal::Map3D_float_t>()) });
	GET_SET_PROP(SlopeDirRangesRad, std::vector<lgal::world::Range>, { lgal::world::Range(0.0, lucid::math::constants::pi<lucid::gal::Map3D_float_t>()) });
	GET_SET_PROP(TerrainExaggeration, float, 1.0f);
	GET_SET_PROP(TileZoomRange, tileRangeT, tileRangeT(0, 24));
	GET_SET_PROP(TileRenderRange, tileRangeT, tileRangeT(-1, -1));
	GET_SET_PROP(VectorRenderRange, tileRangeT, tileRangeT(-1, -1));
	//GET_SET_PROP(ShowLabels, bool, true);
	GET_SET_PROP(ShowTextures, bool, true);
	GET_SET_PROP(ShowVectors, bool, true);
	GET_SET_PROP(ShowVectorLines, bool, true);
	GET_SET_PROP(ShowFilledVectors, bool, true);
	GET_SET_PROP(DebugVectorColors, bool, false);
	GET_SET_PROP(TileLineInstanceLimit, uint32_t, 4096);
	GET_SET_PROP(VectorWireframes, bool, false);
	GET_SET_PROP(TerrainWireframes, bool, false);
	GET_SET_PROP(TopoOn, bool, false);
	GET_SET_PROP(TopoMinorColor, lucid::gal::Color, lucid::gal::Color(0.95f, 0.75f, 0.45f, 1.0f));
	GET_SET_PROP(TopoMajorColor, lucid::gal::Color, lucid::gal::Color(0.9f, 0.7f, 0.4f, 1.0f));
	GET_SET_PROP(Name, std::string, "viewportState");
	GET_SET_PROP(WidthRatio, float, 1);
	GET_SET_PROP(HeightRatio, float, 1);
	GET_SET_PROP(PosX, float, 0);
	GET_SET_PROP(PosY, float, 0);
	GET_SET_PROP(SortOrder, int, 0); //higher numbers on top, lower behind
	GET_SET_PROP(RenderComplete, bool, false);
	GET_SET_PROP(ForceCulling, bool, false);
	GET_SET_PROP(TileLoadTimeMS, lucid::math::Range<double>, lgal::world::Range(0.0, 0.0));
	GET_SET_PROP(LODScaler, float, 2.0f); //todo - move this into its own standalone class probably?
	GET_SET_PROP(MaxSubdDepth, int, 15);
	GET_SET_PROP(CameraMoved, bool, false);
	GET_SET_PROP(VectorFadeTime, Utils::Timer::Map3D_time_t, Tiles::TileVectorInfo::DefaultFadeTime);
	GET_SET_PROP(VectorDownloadPulseTimeMS, float32_t, 750);
	GET_SET_PROP(VectorDownloadPulseDelayMS, float32_t, 2000);
	GET_SET_PROP(SunlightOn, bool, false);
	GET_SET_PROP(SunlightAlwaysUpdate, bool, false);

	// TODO (Ronald): Once a more mature version of the icon/symbol renderer is made, use GET_SET_PROP
	GET_SET_PROP(IconRenderer, std::shared_ptr<Icon::IconRenderer>, nullptr);
	std::vector<Tiles::IconTile> mDebugIconTiles;
	std::vector<std::shared_ptr<Styling::SymbolLayer const>> mDebugIconLayers;

	GET_PROP(Context, sharedContextT, nullptr);

	bool	 getViewshedEnabled();
	void		 toggleViewshed(bool on, bool inverted = false);
	int				addViewshed(lgal::world::Vector2 const& pos);
	void		 enableViewshed(bool on);
	void    setViewshedPosition(lgal::world::Vector2 const& pos);
	void	  setViewshedOffset(world_float_t offset);
	lgal::world::Vector2 getViewshedPosition();
	float	   getViewshedRange();
	void	   setViewshedRange(world_float_t range);

	std::shared_ptr<TerrainEffects::Viewshed> mViewshed;

	std::shared_ptr<TerrainEffects::SunShadow> mSunShadow;
	std::vector<RenderItems> mRenderItems;

	Camera::CameraState mCameraState;

	std::vector<uint8_t> mDepthData;

	void propertyChanged(const char* /* propName */) { invalidate(); }
	void invalidate()
	{
		mRenderComplete = false;
		mForceCulling = true;
	}

	Pyramid::CullResult mCullState;
	Pyramid::CullResult const& getCullResult() const { return mCullState; }
	// used for computing relevant collections of tiles based on a cull state, we make this a class variable to reduce heap allocations
	TileCollections mTileCollections = { mCullState };
	std::unordered_map<Tiles::TileId, Tiles::TileTextureInfo> mTileRenderInfo;
	std::unordered_map<Tiles::TileId, Tiles::TileVectorInfo> mVectorRenderInfo;

	std::shared_ptr<Camera::CameraController> mController;
	std::shared_ptr<Camera::CameraController> getController() const 
	{
		return mController; 
	}

	template<template<class, class...> class ContainerT, class... Additional>
	void debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds);

	template <typename T>
	inline void setContext(std::string const& key, T value)
	{
		mContext->set(key, value);
	}

	template <typename T>
	inline T getContext(std::string const& key) const
	{
		return mContext->lookup(key).as<T>();
	}

	DataObjects::LabelCollection mLabelCollection;
	bool mRegenLabels = true;

	void clearScreenLines() { mScreenLines.clear(); }
	void clearScreenLines(std::string const &style)
	{
		auto iter = mScreenLines.find(style);
		if (iter == mScreenLines.end())
		{
			return;
		}

		iter->second.clear();
	}

	template <typename T>
	void addScreenLines(std::string style, T const& lines)
	{
		auto iter = mScreenLines.find(style);
		if (iter == mScreenLines.end())
		{
			mScreenLines.emplace(style, std::vector<Rendering::VertStructs::ScreenLineData>());
			iter = mScreenLines.find(style);
		}

		iter->second.insert(iter->second.end(), std::begin(lines), std::end(lines));
	}

	void addScreenLine(std::string style, Rendering::VertStructs::ScreenLineData const& line)
	{
		auto iter = mScreenLines.find(style);
		if (iter == mScreenLines.end())
		{
			mScreenLines.emplace(style, std::vector<Rendering::VertStructs::ScreenLineData>());
			iter = mScreenLines.find(style);
		}

		iter->second.push_back(line);
	}

	Camera::ScreenSpaceManager& getScreenSpaceManager() { return mScreenSpaceManager; }

private:
	std::unordered_map<std::string, std::vector<Rendering::VertStructs::ScreenLineData>> mScreenLines;
	Camera::ScreenSpaceManager mScreenSpaceManager;
};


template<template<class, class...> class ContainerT, class... Additional>
void ViewportState::debugTiles(ContainerT<Tiles::TileId, Additional...> const& tileIds)
{
	mCullingEnabled = false;
	mCullState.reset();
	float avgLevel = 0.f;
	for (Tiles::TileId const& id : tileIds)
	{
		mCullState.add(id);
	}
	mCullState.avgLevel = avgLevel / float(mCullState.tileIds.size());

	mTileCollections.update(mCullState, getTileZoomRange(), getTileRenderRange());
}

}

#endif //_VIEWPORTSTATE_H_