#ifndef _VIEWPORT_H_
#define _VIEWPORT_H_

#include <memory>
#include <mutex>
#include <vector>

#include <bgfx/bgfx.h>

#include <lucid/gal/Types.h>
#include <Shaders/ConfigurableShader.h>
#include <Styling/Style.h>

#include "Caching/LayerCache.h"
#include "Caching/TileCache.h"
#include "Camera/CameraState.h"
#include "Camera/CameraController.h"
#include "Tiles/TileRenderInfo.h"
#include "Drawers/Skydome.h"
#include "DataObjects/LabelManager.h"
#include "DataObjects/MapLabel.h"
#include "DataObjects/VectorLineMesh.h"
#include "Ranges/HeightRanges.h"
#include "Ranges/SlopeAngleRanges.h"
#include "Ranges/SlopeAspectRanges.h"
#include "Utils/property.h"
#include "Config/ConfigManager.h"
#include "ViewportState.h"
#include "../Drawers/FrustumDrawer.h"

namespace onyx {

typedef lucid::math::Range<Tiles::TileId::IdCoordsT> tileRangeT;
typedef std::vector<Rendering::VertStructs::ScreenLineData> screenLineVector_t;

class Viewport
{
public:

	Viewport()
	{
		mLineMesh.reset(new DataObjects::VectorLineMesh());
	}

	Viewport(std::string const& name, float wRatio, float hRatio, Camera::CameraState const& state, int sortOrder = 0);
	~Viewport();
	
	void render(double timeMS);
	void readDepth(bgfx::ViewId const& viewId, uint8_t defaultValue = 0);
	void readColor(std::vector<uint8_t>& target, uint8_t defaultValue);
	void readDepth(std::vector<uint8_t>& target);
	bgfx::TextureHandle getTexture();

	void resize();

	void setController(std::shared_ptr<Camera::CameraController> controller);

	// TODO possibly get rid of the scaling in the viewports
	float getAspect() { return mViewportState.getAspect(); }

	float getWidthPixel() const { return mViewportState.getWidthPixel(); }
	float getHeightPixel() const { return mViewportState.getHeightPixel(); }

	lgal::screen::Vector2 size() const { return { screen_coord_t(mViewportState.getWidthPixel()), screen_coord_t(mViewportState.getHeightPixel()) }; }

	void setTileLod(float lod) { mViewportState.setLODScaler(lod); }

	bool operator<(Viewport& comp)
	{
		return mViewportState.getSortOrder() < comp.getState()->getSortOrder();
	}

	gpu_float_t depthAtPixel(int screenX, int screenY) const;
	gpu_float_t depthAtNormalized(lgal::gpu::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectPixel(int screenX, int screenY) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector2 const& normalizedScreen) const;
	lgal::world::Vector3 unprojectNormalized(lgal::world::Vector3 const& normalizedPos) const;
	lgal::world::Vector3 project(lgal::world::Vector3 const& pos) const;

	void toggleComponent(ShaderEnums::ConfigurableShaders shader, std::string const& component, bool on);
	void setShaderParameters(ShaderEnums::ConfigurableShaders shader, std::vector<ShaderParam*>& params, Shaders::ValueBag const& configuration);
	void setCameraState(Camera::CameraState const& state);
	Camera::CameraState const& getCameraState() const { return mViewportState.mCameraState; }

	void invalidate();
	void addLabel(std::string text, lgal::world::Vector3 const& pos);
	DataObjects::LabelManager* getLabelManager() { return mLabelManager.get(); }

	inline double tileLoadTimeMS() const { return mViewportState.getTileLoadTimeMS().end - mViewportState.getTileLoadTimeMS().begin; }

	void toggleHeightRanges(bool enabled);
	void toggleSlopeAngleRanges(bool enabled);
	void toggleSlopeDirRanges(bool enabled);

	void setHeightRanges(std::vector<lgal::world::Range> const& ranges);
	void setSlopeDirRanges(std::vector<lgal::world::Range> const& ranges);
	void setSlopeAngleRanges(std::vector<lgal::world::Range> const& ranges);

	void toggleTopo(bool enabled);

	ViewportState* getState() { return &mViewportState; }
	ViewportState const * getState() const { return (ViewportState const *)&mViewportState; }

	std::shared_ptr<Styling::Style> getStyle() const { return mStyle; }
	void setStyle(std::shared_ptr<Styling::Style> style);
	
	std::shared_ptr<Caching::LayerCache const> getLayerCache() const { return mLayerCache; }

	template <typename T>
	void setContext(std::string const& key, T value)
	{
		mViewportState.setContext(key, value);
	}

	template <typename T>
	T getContext(std::string const& key) const
	{
		return mViewportState.getContext<T>(key);
	}

	//keeping in sync with viewportstate for the moment, for easy flowthrough as needed
	GET_SET_CHILD(mViewportState, TopoMinor, float);
	GET_SET_CHILD(mViewportState, TopoMajor, float);
	GET_SET_CHILD(mViewportState, IntersectTerrain, bool);
	GET_SET_CHILD(mViewportState, HeightRangesOn, bool);
	GET_SET_CHILD(mViewportState, SlopeAngleRangesOn, bool);
	GET_SET_CHILD(mViewportState, SlopeDirRangesOn, bool);
	GET_SET_CHILD(mViewportState, CullingEnabled, bool);
	GET_SET_CHILD(mViewportState, QuiescenceMode, bool);
	GET_SET_CHILD(mViewportState, TerrainExaggeration, float);
	GET_SET_CHILD(mViewportState, TileZoomRange, tileRangeT);
	GET_SET_CHILD(mViewportState, TileRenderRange, tileRangeT);
	GET_SET_CHILD(mViewportState, VectorRenderRange, tileRangeT);
	GET_SET_CHILD(mViewportState, ShowTextures, bool);
	GET_SET_CHILD(mViewportState, ShowVectors, bool);
	GET_SET_CHILD(mViewportState, ShowVectorLines, bool);
	GET_SET_CHILD(mViewportState, ShowFilledVectors, bool);
	GET_SET_CHILD(mViewportState, DebugVectorColors, bool);
	GET_SET_CHILD(mViewportState, TileLineInstanceLimit, uint32_t);
	GET_SET_CHILD(mViewportState, VectorWireframes, bool);
	GET_SET_CHILD(mViewportState, TerrainWireframes, bool);
	GET_SET_CHILD(mViewportState, TopoOn, bool);
	GET_SET_CHILD(mViewportState, TopoMinorColor, lucid::gal::Color);
	GET_SET_CHILD(mViewportState, TopoMajorColor, lucid::gal::Color);
	GET_SET_CHILD(mViewportState, Name, std::string);
	GET_SET_CHILD(mViewportState, WidthRatio, float);
	GET_SET_CHILD(mViewportState, HeightRatio, float);
	GET_SET_CHILD(mViewportState, PosX, float);
	GET_SET_CHILD(mViewportState, PosY, float);
	GET_SET_CHILD(mViewportState, SortOrder, int);
	GET_SET_CHILD(mViewportState, RenderComplete, bool);
	GET_SET_CHILD(mViewportState, ForceCulling, bool);
	GET_SET_CHILD(mViewportState, TileLoadTimeMS, lucid::math::Range<double>);
	GET_SET_CHILD(mViewportState, LODScaler, float);
	GET_SET_CHILD(mViewportState, MaxSubdDepth, int);
	GET_SET_CHILD(mViewportState, CameraMoved, bool);
	GET_SET_CHILD(mViewportState, SunlightOn, bool);
	GET_SET_CHILD(mViewportState, SunlightAlwaysUpdate, bool);
	GET_CHILD(mViewportState, HeightRangesKm, std::vector<lgal::world::Range>);
	GET_CHILD(mViewportState, SlopeAngleRangesRad, std::vector<lgal::world::Range>);
	GET_CHILD(mViewportState, SlopeDirRangesRad, std::vector<lgal::world::Range>);

	GET_CHILD(mViewportState, IconRenderer, std::shared_ptr<Icon::IconRenderer>);
	void addDebugIconTile(Tiles::IconTile const& iconTile)
	{
		mViewportState.mDebugIconTiles.push_back(iconTile);
	}
	void addDebugIconLayer(std::shared_ptr<Styling::SymbolLayer const> iconLayer)
	{
		// TODO (scott) temporarily disabling this; I'm not sure that we'll ultimately need it
//		MAP3D_DEBUG_ASSERT(iconLayer->hasIcons(), "Icon layer is not set up for rendering icons");
		mViewportState.mDebugIconLayers.push_back(iconLayer);
	}

	GET_SET_CHILD(mViewportState, VectorFadeTime, Utils::Timer::Map3D_time_t);
	GET_SET_CHILD(mViewportState, VectorDownloadPulseTimeMS, float32_t);
	GET_SET_CHILD(mViewportState, VectorDownloadPulseDelayMS, float32_t);

	GET_SET_PROP(MaxLabelsPerTile, uint32_t, 10);
	GET_SET_PROP(ShowScreenSpaceManager, bool, false);

	template <class T>
	void setRenderedTileIds(T const& tileIds)
	{
		mViewportState.mTileCollections.forceCulled.clear();
		mViewportState.mTileCollections.forceCulled.insert(mViewportState.mTileCollections.forceCulled.end(), tileIds.begin(), tileIds.end());
	}

	void setSunlightEnabled(bool on);
	void setSunlightTime(int year, int month, int day, float timezone, float hours24);

	std::shared_ptr<TerrainEffects::SunShadow> getSunShadow() { return mViewportState.mSunShadow; }

	
private:
	
	ViewportState mViewportState;

	std::shared_ptr<Styling::Style> mStyle;
	
	std::shared_ptr<Drawers::Skydome> mSkydome;

	Shaders::ConfigurableShader mTerrainShader, mVectorShader;

	// track which fill entries have been rendered so that we don't double render -- cleared every frame
	std::unordered_set<Caching::LayerCache::EntryKey, Caching::LayerCache::EntryKeyHasher> mCoveredFills;

	bgfx::TextureHandle mColorTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mDepthTarg = BGFX_INVALID_HANDLE;
	
	bgfx::TextureHandle mZTarg = BGFX_INVALID_HANDLE;
	bgfx::TextureFormat::Enum mZBufferFormat = bgfx::TextureFormat::Enum::Unknown;
	
	bgfx::TextureHandle mDepthReadbackHandle = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle mColorReadbackHandle = BGFX_INVALID_HANDLE;

	void allocateTextures();
	void deallocateTextures();

	// not using rendertargetmanager because we need to be sure we always finish same frame
	// no queueing - maybe could add a priority override there instead?
	bgfx::FrameBufferHandle mColorDepthZFrameBuffer = BGFX_INVALID_HANDLE;
	bgfx::FrameBufferHandle mColorZFrameBuffer = BGFX_INVALID_HANDLE;

	void allocateFramebuffers();
	void deallocateFramebuffers();

	uint64_t mLastCacheUpdate = 0;

	void setMatrixUniforms(bgfx::ViewId const& viewId);
	void setTerrainToolsUniforms(std::shared_ptr<Shaders::ShaderDefinition>& shader);

	// TODO eventually expose these to the client
	HeightRanges mHeightRanges;
	SlopeAspectRanges mSlopeAspectRanges;
	SlopeAngleRanges mSlopeAngleRanges;

	bgfx::TextureHandle mOnlyAlphaTexture = BGFX_INVALID_HANDLE;

	void renderTerrain();
	void renderWaypoints();
	void renderTrackers();
	void renderLabels();
	void renderIcons();

	void syncSources();
	void syncLayers();

	Atlases::HeightAtlas const* getHeightAtlas() const
	{
		if (!mStyle->hasTerrain())
		{
			return nullptr;
		}

		auto const& source = Caching::TileCache::Instance()->getSource(mStyle->terrain()->source);
		return static_cast<Atlases::HeightAtlas const*>(source.atlas());
	}

	//todo - move this into its own standalone class probably?
	// TODO: Monitor https://github.com/bkaradzic/bgfx/issues/3024 for when this is fixed
	// so we don't have to have two samplers for the same texture
	std::map<TextureType, std::pair<std::string, std::string>> mTextureShaderMapping = {
		{ TextureType::Basemap,			{ "s_texture0", "u_ScaleOffsetTex0" } },
		{ TextureType::Basemap2,		{ "s_texture1", "u_ScaleOffsetTex1" } },
		//{ TextureType::Height,			{ "s_heightTexture", "u_ScaleOffsetHeight" } },
		{ TextureType::HeightVert,		{ "s_heightTextureVert", "u_ScaleOffsetHeight" } },
		{ TextureType::HeightFrag,		{ "s_heightTextureFrag", "u_ScaleOffsetHeight" } },
		{ TextureType::Weather,			{ "s_texture0", "u_ScaleOffsetTex0" } },
		{ TextureType::Roads,			{ "s_texture1", "u_ScaleOffsetTex1" } },
		{ TextureType::LocalData,		{ "s_texture2", "u_ScaleOffsetTex2" } }
	};

	std::unique_ptr<DataObjects::VectorLineMesh> mLineMesh;

	// uses the current style object to determine layers
	bool gatherTextureRenderInfo(std::vector<Tiles::TileId> const& tiles);
	bool gatherVectorRenderInfo(std::vector<Tiles::TileId> const& tiles);
	void gatherTileTextureInfo(Tiles::TileId const& tileId, Tiles::TileTextureInfo& target);
	bool renderTiles(bgfx::ViewId const& viewId);
	void renderTileTextures(bgfx::ViewId const& viewId, Tiles::TileTextureInfo const& renderInfo);
	void renderTileVectors(bgfx::ViewId const& viewId, Tiles::TileVectorInfo& renderInfo, std::shared_ptr<Styling::Layer const> layer, Shaders::ShaderDefinition* shader);

	void drawTerrainLines(bgfx::ViewId renderId, Tiles::TileVectorInfo const& info, bgfx::VertexBufferHandle const handle, uint32_t start, uint32_t num, float32_t fade, Shaders::ShaderDefinition* shader);
	void drawLineInstances(bgfx::ViewId const& viewId, Tiles::TileVectorInfo const& info, float32_t fade, std::shared_ptr<Styling::LineLayer const> layer, Shaders::ShaderDefinition* shader);
	void drawTerrainVectors(bgfx::ViewId viewId, Tiles::TileVectorInfo const& info, std::shared_ptr<Styling::FillLayer const> layer, Shaders::ShaderDefinition* shader, uint64_t flags = 0ull);

	void renderScreenLines(bgfx::ViewId renderId, screenLineVector_t const &instances, std::string const &dashStyle, uint64_t bgfxRenderState, std::shared_ptr<Shaders::ShaderDefinition>& shader);
	void renderScreenLines();
	void renderScreenSpaceManager();
	void setTextureParameters(Tiles::TileTextureAtlasInfo const& info, Shaders::ShaderDefinition * shader, TextureType textureType);
	void propertyChanged(const char* /* propName */) { invalidate(); }
	void setTextureParameters(Tiles::TileTextureAtlasInfo const& info, ShaderDefinition * shader, TextureType textureType);

	template<typename LayerType>
	void gatherLabels();
	void gatherLabels();

	std::vector<DataObjects::LabelCollection::sharedLabel_t> mFrameLabels;
	std::unique_ptr<DataObjects::LabelManager> mLabelManager;
	Utils::Timer::Map3D_time_t mCurrentFrameTime = 0;

	drawers::FrustumDrawer mFrustumDrawer;
	std::shared_ptr<Caching::LayerCache> mLayerCache;

public:

	// NOTE: we assume that vectors is a subset of rasters
	static std::vector<Caching::TileCacheKey> CacheKeys(std::vector<Tiles::TileId> const& rasters, std::vector<Tiles::TileId> const& vectors, std::shared_ptr<Styling::Style const> style);

};

}

#endif //_VIEWPORT_H_