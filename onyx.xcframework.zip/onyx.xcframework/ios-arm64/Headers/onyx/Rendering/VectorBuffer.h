#ifndef VECTOR_BUFFER_H_
#define VECTOR_BUFFER_H_

#include <map>
#include <vector>
#include <memory>

#include <lucid/gal/Types.h>

#include <System/Map3DException.h>
#include <Shaders/ShaderDefinition.h>

#include "Rendering/BufferPool.h"
#include "Rendering/VertStructs.h"

namespace onyx {
namespace Rendering {

	template<typename bufferT>
	class VectorBuffer
	{
	public:
	
		typedef lgal::array::Range Range_t;

		VectorBuffer() {}

		void insert(std::vector<bufferT> const& vertices, std::vector<uint16_t> const& indices)
		{
			if (vertices.size() > 2 && indices.size() > 3)
			{
				mBufferPoolIds.push_back(BufferPoolId());
				mIndexCount.push_back(indices.size());

				auto& id = mBufferPoolIds.back();
				mBufferPool.addVertsIndices(vertices, indices, id);

				mSize += sizeof(bufferT) * vertices.size();
				mSize += sizeof(uint16_t) * indices.size();
			}
		}

		void attachPageBuffers(size_t pageId, lucid::gal::Range const& indices = { 0, std::numeric_limits<int>::max() }) const
		{
			MAP3D_ASSERT(pageId < mBufferPool.numPages(), "Invalid buffer page");
			mBufferPool.attachBuffers({ int(pageId), 0 }, indices);
		}

		inline size_t size() const { return mSize; }

		inline size_t numVertexPages() const
		{
			return mBufferPool.numPages();
		}

		inline size_t numVectors() const
		{
			return mBufferPoolIds.size();
		}

		inline size_t getVectorPage(size_t vectorId) const
		{
			MAP3D_ASSERT(vectorId < mBufferPoolIds.size(), "Invalid vector Id requested");
			return mBufferPoolIds[vectorId].mSlot;
		}

		void draw(bgfx::ViewId viewId, lgal::world::Vector3 const& pos, lgal::world::Vector3 const& extents, Shaders::ShaderDefinition* shader)
		{
			mBufferPool.draw(viewId, lucid::gal::toBx(pos), lucid::gal::toBx(extents), shader->programHandle);
		}

		void attachBuffers(size_t vectorId, lucid::gal::Range const& indices) const
		{
			MAP3D_ASSERT(vectorId < mBufferPoolIds.size(), "Invalid vector Id requested");
			auto const& id = mBufferPoolIds[vectorId];
			auto size = int(mIndexCount[vectorId]);
			auto first = std::min(indices.begin, size) + id.mIndexStart;
			auto last = std::min(indices.end, size) + id.mIndexStart;

			mBufferPool.attachBuffers(id, { first, last });
		};

		Range_t getVectorRange(size_t vectorId) const
		{
			MAP3D_ASSERT(vectorId < mBufferPoolIds.size(), "Invalid vector Id requested");
			auto const& poolId = mBufferPoolIds[vectorId];
			size_t indexCount = mIndexCount[vectorId];
			return { size_t(poolId.mIndexStart), size_t(poolId.mIndexStart + indexCount) };
		}

	private:
	
		size_t mSize = 0;

		std::vector<size_t> mIndexCount;

		std::vector<BufferPoolId> mBufferPoolIds;
		mutable BufferPool<bufferT> mBufferPool;

	};

} }

#endif
