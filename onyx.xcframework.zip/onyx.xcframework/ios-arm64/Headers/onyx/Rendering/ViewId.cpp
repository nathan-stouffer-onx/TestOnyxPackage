#include "ViewId.h"

#include <map>

namespace onyx {
namespace Rendering {
namespace ViewId
{

	static std::map<Type, uint16_t> sCounts;

	void shutdown()
	{
		sCounts.clear();
	}

	void reset()
	{
		// new frame, so reset view id counts
		for (auto& [vid, count] : sCounts)
		{
			count = 0;
		}
	}

	bgfx::ViewId next(Type type)
	{
		// compute the next view id of this type
		bgfx::ViewId next = (bgfx::ViewId)type + sCounts[type];
		// increment the count at that type
		sCounts[type]++;
		// return the next view id
		return next;
	}

} } }