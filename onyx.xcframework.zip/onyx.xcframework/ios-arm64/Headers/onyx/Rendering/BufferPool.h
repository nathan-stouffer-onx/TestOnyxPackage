#ifndef BUFFERPOOL_H_
#define BUFFERPOOL_H_

#include <vector>
#include <mutex>
#include <memory>

#include <bgfx/bgfx.h>
#include <bx/bx.h>
#include <bx/math.h>

#include <lucid/gal/Types.h>

namespace onyx {
namespace Rendering {

	/*
	* BufferPool is a class that manages pools of vertices/indices and allocates memory for them on the gpu. We only use 16 bit
	* index buffers for cross platform compatibility (on gpu). BufferPool lets us automatically split things into chunks, as
	* long as each add is < 65k indices. So far, there is no reason to support breaking up a mesh into chunks, but we could add
	* that later if we end up with really complex meshes
	*/

	struct BufferPoolId
	{
		int mSlot = -1;
		int mVertStart = -1;
		int mIndexStart = -1;

		BufferPoolId() {}
		BufferPoolId(int slot, int vertStart) : mSlot(slot), mVertStart(vertStart) {}
	};

	template <typename T>
	struct BufferPool // T is vertex type
	{

		BufferPool() : mIsDirty(true) {}

		~BufferPool()
		{
			for (size_t i = 0; i < mVertData.size(); i++)
			{
				mVertData[i].clear();
			}
			mVertData.clear();

			for (size_t i = 0; i < mIdxData.size(); i++)
			{
				mIdxData[i].clear();
			}
			mIdxData.clear();

			for (size_t i = 0; i < mVertexBuffers.size(); i++)
			{
				if (bgfx::isValid(mVertexBuffers[i]))
				{
					bgfx::destroy(mVertexBuffers[i]);
				}
			}

			for (size_t i = 0; i < mIndexBuffers.size(); i++)
			{
				if (bgfx::isValid(mIndexBuffers[i]))
				{
					bgfx::destroy(mIndexBuffers[i]);
				}
			}

			mVertexBuffers.clear();
			mIndexBuffers.clear();
		}

		void addVertsIndices(const std::vector<T>& verts, const std::vector<uint16_t>& idx, BufferPoolId& bufferIdOut)
		{
			std::lock_guard<std::mutex> lock(mMutex);

			if (mIdxData.size() == 0 || mIdxData.back().size() + idx.size() >= (2 << 15))
			{
				mVertData.push_back(verts);
				mIdxData.push_back(idx);

				bufferIdOut.mSlot = (int)mVertData.size() - 1;
				bufferIdOut.mVertStart = 0;
				bufferIdOut.mIndexStart = 0;
			}
			else // room to add on to existing one
			{
				int slot = (int)mVertData.size() - 1;
				int vertStart = (int)mVertData[slot].size();

				bufferIdOut.mSlot = slot;
				bufferIdOut.mVertStart = vertStart;
				bufferIdOut.mIndexStart = (int)mIdxData[slot].size();

				auto idxStart = mIdxData[slot].size();

				mVertData[slot].insert(mVertData[slot].end(), verts.begin(), verts.end());	// add the new verts
				mIdxData[slot].insert(mIdxData[slot].end(), idx.begin(), idx.end());		// add the new indices

				// offset indices within the pool
				for (auto i = idxStart; i < mIdxData[slot].size(); i++)
				{
					mIdxData[slot][i] += (uint16_t)vertStart;
				}
			}

			mIsDirty = true;
		}

		void addVerts(const std::vector<T>& verts, BufferPoolId& bufferIdOut)
		{
			std::lock_guard<std::mutex> lock(mMutex);

			if (mVertData.size() == 0 || mVertData[mVertData.size() - 1].size() + verts.size() >= (2 << 15))
			{
				mVertData.push_back(verts);

				bufferIdOut.mSlot = mVertData.size() - 1;
				bufferIdOut.mVertStart = 0;
				bufferIdOut.mIndexStart = 0;

			}
			else // room to add on to existing one
			{
				int slot = mVertData.size() - 1;
				bufferIdOut.mSlot = slot;
				bufferIdOut.mVertStart = mVertData[slot].size();
				bufferIdOut.mIndexStart = (int)mIdxData[slot].size();


				mVertData[slot].insert(mVertData[slot].end(), verts.begin(), verts.end());	// add the new verts
			}

			mIsDirty = true;
		}

		void setVerts(BufferPoolId begId, const std::vector<T>& verts)
		{
			std::lock_guard<std::mutex> lock(mMutex);

			int slot = begId.mSlot;
			int start = begId.mVertStart;
			int end = start + (int)verts.size() - 1;

			// check that the buffer can be set at this id
			BufferPoolId endId(slot, end);
			if (!validId(begId))
			{
				logE("invalid begin id to set verts");
				return;
			}
			if (!validId(endId))
			{
				logE("invalid end id to set verts");		// vector of vertices is too long
				return;
			}

			mVertData[slot].erase(mVertData[slot].begin() + start, mVertData[slot].begin() + end);
			mVertData[slot].insert(mVertData[slot].begin(), verts.begin(), verts.end());

			if (!mIsDirty)		// if not dirty, update the DynamicVertexBuffer
			{
				const bgfx::Memory* memV = bgfx::copy(&mVertData[slot][start], sizeof(T) * (uint32_t)verts.size());
				bgfx::update(mVertexBuffers[slot], start, memV);
			}
		}

		bool attachBuffers(BufferPoolId const &bufferId, lucid::gal::Range const &indices = { 0, std::numeric_limits<int>::max() })
		{
			if (mIsDirty)
			{
				setAllBuffers();
			}

			auto slot = bufferId.mSlot;

			MAP3D_ASSERT(bufferId.mSlot < int(mVertexBuffers.size()), "Invalid buffer index requested")

			if (!bgfx::isValid(mVertexBuffers[slot]))
			{
				return false;
			}

			bgfx::setVertexBuffer(0, mVertexBuffers[slot]);
			if (int(mIndexBuffers.size()) > slot && bgfx::isValid(mIndexBuffers[slot]))
			{
				auto size	= int(mIdxData[slot].size());
				auto first	= uint32_t(std::min(indices.begin, size));
				auto last	= uint32_t(std::min(indices.end, size));

				if (first != 0 || last != (uint32_t)size)
				{
					bgfx::setIndexBuffer(mIndexBuffers[slot], first, (last - first));
				}
				else
				{
					bgfx::setIndexBuffer(mIndexBuffers[slot]);
				}
			}
			return true;
		}

		void draw(bgfx::ViewId viewId, bx::Vec3 pos, bx::Vec3 extents, bgfx::ProgramHandle program, uint64_t flags = (uint64_t)0)
		{
			std::lock_guard<std::mutex> lock(mMutex);
		
			setAllBuffers();	// set all the buffers (only does something if isDirty == true)

			if (mIndexBuffers.empty())
			{
				return;
			}

			float mtx[16];
			bx::mtxIdentity(mtx);
			bx::mtxScale(mtx, extents.x, extents.y, 1.0f); //dont scale z so we dont affect vertex shader heights
			//position it
			mtx[12] = pos.x;
			mtx[13] = pos.y;
			mtx[14] = pos.z;

			// Set model matrix for rendering.
			bgfx::setTransform(mtx);

			for (size_t i = 0; i < mIndexBuffers.size(); i++)
			{
				if (!bgfx::isValid(mIndexBuffers[i]) || !bgfx::isValid(mVertexBuffers[i]))
				{
					continue;
				}
		
				if (mIndexBuffers.size() == 0) //must be a line list
				{
					// Set vertex and index buffer.
					bgfx::setVertexBuffer(0, mVertexBuffers[i]);
					//bgfx::setIndexBuffer();

					// Set render states
					uint64_t state = 0
						| BGFX_STATE_WRITE_R
						| BGFX_STATE_WRITE_G
						| BGFX_STATE_WRITE_B
						| BGFX_STATE_WRITE_A
	#ifdef ENABLE_MSAA
						| BGFX_STATE_MSAA
	#endif
						| BGFX_STATE_WRITE_Z
						| BGFX_STATE_PT_TRISTRIP
						;

					bgfx::setState(state | flags);
				}
				else
				{
					// Set vertex and index buffer.
					bgfx::setVertexBuffer(0, mVertexBuffers[i]);
					bgfx::setIndexBuffer(mIndexBuffers[i]);

					// Set render states
					uint64_t state = 0
						| BGFX_STATE_WRITE_R
						| BGFX_STATE_WRITE_G
						| BGFX_STATE_WRITE_B
						| BGFX_STATE_WRITE_A
	#ifdef ENABLE_MSAA
						| BGFX_STATE_MSAA
	#endif
						| BGFX_STATE_WRITE_Z
						;

					bgfx::setState(state | flags);
				}
				bgfx::submit(viewId, program);
			}
		}
	
		void clear()
		{
			std::lock_guard<std::mutex> lock(mMutex);

			for (size_t i = 0; i < mVertData.size(); i++)
			{
				mVertData[i].clear();
			}
			mVertData.clear();

			for (size_t i = 0; i < mIdxData.size(); i++)
			{
				mIdxData[i].clear();
			}
			mIdxData.clear();
		}

		int numVerts() const
		{
			std::lock_guard<std::mutex> lock(mMutex);

			int count = 0;
			for (const auto& vertices : mVertData)
			{
				count += (int)vertices.size();
			}
			return count;
		}

		int numIndices() const
		{
			std::lock_guard<std::mutex> lock(mMutex);

			int count = 0;
			for (const auto& indices : mIdxData)
			{
				count += (int)indices.size();
			}
			return count;
		}

		inline size_t numPages()
		{
			if (mIsDirty)
			{
				setAllBuffers();
			}
			return mVertexBuffers.size();
		}

	private:

		std::vector<std::vector<T>> mVertData;
		std::vector<std::vector<uint16_t>> mIdxData;

		std::vector<bgfx::DynamicVertexBufferHandle> mVertexBuffers;
		std::vector<bgfx::DynamicIndexBufferHandle> mIndexBuffers;

		bool mIsDirty;		// indicator for whether cpu data matches gpu data

		mutable std::mutex mMutex;

		bool validId(const BufferPoolId& id)
		{
			int slot = id.mSlot;
			int vertStart = id.mVertStart;

			if (slot < 0 || slot >= int(mVertData.size()))					// check if slot is invalid
			{
				return false;
			}
			if (vertStart < 0 || vertStart >= int(mVertData[slot].size()))	// check if vertStart is invalid
			{
				return false;
			}
			return true;		// all checks passed, return true
		}

		void setAllBuffers()
		{
			if (mIsDirty)
			{
				for (size_t i = 0; i < mVertexBuffers.size(); i++)
				{
					if (bgfx::isValid(mVertexBuffers[i]))
					{
						bgfx::destroy(mVertexBuffers[i]);
					}
				}

				for (size_t i = 0; i < mIndexBuffers.size(); i++)
				{
					if (bgfx::isValid(mIndexBuffers[i]))
					{
						bgfx::destroy(mIndexBuffers[i]);
					}
				}

				mVertexBuffers.clear();
				mIndexBuffers.clear();

				for (size_t i = 0; i < mVertData.size(); i++)
				{
					if (mVertData[i].size() > 2 && mIdxData[i].size() > 2)
					{
						const bgfx::Memory* vMem = bgfx::copy(mVertData[i].data(), sizeof(T) * (uint32_t)mVertData[i].size());
						auto vertBuffer = bgfx::createDynamicVertexBuffer((uint32_t)mVertData[i].size(), T::ms_layout, BGFX_BUFFER_ALLOW_RESIZE);
						if (!bgfx::isValid(vertBuffer))
						{
							return; // Keep dirty bit because we failed to update our buffers
						}

						mVertexBuffers.push_back(vertBuffer);
						bgfx::update(mVertexBuffers[mVertexBuffers.size() - 1], 0, vMem);

						const bgfx::Memory* iMem = bgfx::copy(mIdxData[i].data(), sizeof(uint16_t) * (uint32_t)mIdxData[i].size());
						auto idxBuffer = bgfx::createDynamicIndexBuffer((uint32_t)mIdxData[i].size(), BGFX_BUFFER_ALLOW_RESIZE);
						if (!bgfx::isValid(idxBuffer))
						{
							return; // Keep dirty bit because we failed to update our buffers
						}

						mIndexBuffers.push_back(idxBuffer);
						bgfx::update(mIndexBuffers[mIndexBuffers.size() - 1], 0, iMem);
					}
				}

				mIsDirty = false;
			}
		}

	};

} }

#endif