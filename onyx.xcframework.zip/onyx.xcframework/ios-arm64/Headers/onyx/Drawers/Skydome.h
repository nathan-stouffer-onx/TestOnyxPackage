#ifndef __SKYDOME_H__
#define __SKYDOME_H__

#include <vector>

#include <bgfx/bgfx.h>

#include "../Camera/CameraState.h"
#include <Shaders/ShaderDefinition.h>

struct ShaderDefinition;

namespace onyx {
namespace Drawers {

	class Skydome
	{

	public:

		Skydome();
		~Skydome();

		void draw(bgfx::ViewId viewId, Camera::CameraState const &cameraState, std::shared_ptr<Shaders::ShaderDefinition> &shader);

	private:
		bgfx::VertexBufferHandle mVertexBuffer;
		bgfx::IndexBufferHandle mIndexBuffer;
	};

} }

#endif