#include "FrustumDrawer.h"

#include <vector>

#include "bgfx/bgfx.h"
#include "bx/math.h"
#include "../Camera/Frustum.h"
#include "../Rendering/VertStructs.h"
#include <Shaders/ShaderManager.h>

#define ANG2RAD 3.14159265358979323846/180.0

#define FRUSTUM_NUM_VERTS 8
#define FRUSTUM_NUM_INDICES 36
#define FRUSTUM_EDGES_NUM_VERTS 9
#define FRUSTUM_EDGES_NUM_INDICES 16

namespace drawers
{

	std::vector<uint16_t> FrustumDrawer::sIndices = std::vector<uint16_t>{
		// near plane
		0, 2, 1,
		3, 0, 2,
		// far plane
		4, 6, 5,
		7, 4, 6,
		// bottom plane
		6, 3, 7,
		2, 6, 3,
		// top plane
		4, 1, 5,
		0, 4, 1,
		// left plane
		4, 3, 0,
		7, 4, 3,
		// right plane
		1, 6, 5,
		2, 1, 6,
	};

	std::vector<uint16_t> FrustumDrawer::sEdgeIndices = std::vector<uint16_t>{
		// edges for near plane
		0, 1,
		1, 2,
		2, 3,
		3, 0,
		// edges for far plane
		4, 5,
		5, 6,
		6, 7,
		7, 4,
		// edges for connections between near and far plane
		0, 4,
		1, 5,
		2, 6,
		3, 7,
	};

	bgfx::VertexBufferHandle FrustumDrawer::sVertexBuffer = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle FrustumDrawer::sIndexBuffer = BGFX_INVALID_HANDLE;

	bgfx::VertexBufferHandle FrustumDrawer::sEdgeVertexBuffer = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle FrustumDrawer::sEdgeIndexBuffer = BGFX_INVALID_HANDLE;

	void FrustumDrawer::shutdown()
	{
		if (bgfx::isValid(sVertexBuffer))
		{
			bgfx::destroy(sVertexBuffer);
		}
		if (bgfx::isValid(sIndexBuffer))
		{
			bgfx::destroy(sIndexBuffer);
		}
		if (bgfx::isValid(sEdgeVertexBuffer))
		{
			bgfx::destroy(sEdgeVertexBuffer);
		}
		if (bgfx::isValid(sEdgeIndexBuffer))
		{
			bgfx::destroy(sEdgeIndexBuffer);
		}

		sIndices.clear();
		sEdgeIndices.clear();
	}

	void FrustumDrawer::draw(bgfx::ViewId viewId, lgal::world::Vector3 eye, const onyx::Camera::Frustum& frustum)
	{
		draw(viewId, eye, &frustum);
	}

	void FrustumDrawer::draw(bgfx::ViewId viewId, lgal::world::Vector3 eye, const onyx::Camera::Frustum* frustum)
	{
		ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0)->setParameter("u_tileMin", lgal::world::Vector3(0 - eye.x, 0 - eye.y, 0 - eye.z));
		ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::DebugColor, 0)->setParameter("u_tileMax", lgal::world::Vector3(1 - eye.x, 1 - eye.y, 1));
		drawPlanes(viewId, frustum);
		drawEdges(viewId, frustum);
	}

	void FrustumDrawer::drawPlanes(bgfx::ViewId viewId, const onyx::Camera::Frustum* frustum)
	{
		// retrieve the program handle
		bgfx::ProgramHandle program = ShaderManager::Instance()->getShaderHandle(ShaderEnums::ConfigurableShaders::DebugColor);

		auto corners = frustum->corners();
		
		auto ntl = corners.ntl.as<float>();
		auto ntr = corners.ntr.as<float>();
		auto nbr = corners.nbr.as<float>();
		auto nbl = corners.nbl.as<float>();
		auto ftl = corners.ftl.as<float>();
		auto ftr = corners.ftr.as<float>();
		auto fbr = corners.fbr.as<float>();
		auto fbl = corners.fbl.as<float>();

		// set up vertex buffer for the draw call
		std::vector<onyx::Rendering::VertStructs::PosColor> verts =
		{
			onyx::Rendering::VertStructs::PosColor(ntl.x, ntl.y, ntl.z, 0x0fffffff),
			onyx::Rendering::VertStructs::PosColor(ntr.x, ntr.y, ntr.z, 0x0fffffff),
			onyx::Rendering::VertStructs::PosColor(nbr.x, nbr.y, nbr.z, 0x0fffffff),
			onyx::Rendering::VertStructs::PosColor(nbl.x, nbl.y, nbl.z, 0x0fffffff),

			onyx::Rendering::VertStructs::PosColor(ftl.x, ftl.y, ftl.z, 0x0fffffff),
			onyx::Rendering::VertStructs::PosColor(ftr.x, ftr.y, ftr.z, 0x0fffffff),
			onyx::Rendering::VertStructs::PosColor(fbr.x, fbr.y, fbr.z, 0x0fffffff),
			onyx::Rendering::VertStructs::PosColor(fbl.x, fbl.y, fbl.z, 0x0fffffff),
		};

		if (bgfx::isValid(sVertexBuffer))	// if valid, destroy
		{
			bgfx::destroy(sVertexBuffer);
		}
		// create the vertex buffer
		sVertexBuffer = bgfx::createVertexBuffer(
			bgfx::copy(verts.data(), uint32_t(sizeof(onyx::Rendering::VertStructs::PosColor) * verts.size()))
			, onyx::Rendering::VertStructs::PosColor::ms_layout
		);

		if (!bgfx::isValid(sIndexBuffer))	// if not valid, create the index buffer
		{
			// create the index buffer
			sIndexBuffer = bgfx::createIndexBuffer(
				// static data can be passed with makeRef
				bgfx::makeRef(sIndices.data(), uint32_t(sizeof(uint16_t) * sIndices.size()))
			);
		}
		
		// create the model matrix
		float mtx[16];
		bx::mtxIdentity(mtx);
		bgfx::setTransform(mtx);

		// set vertex and index buffer.
		bgfx::setVertexBuffer(0, sVertexBuffer);
		bgfx::setIndexBuffer(sIndexBuffer);

		uint64_t state = 0
			| BGFX_STATE_WRITE_R
			| BGFX_STATE_WRITE_G
			| BGFX_STATE_WRITE_B
			| BGFX_STATE_WRITE_A
			| BGFX_STATE_WRITE_Z
			| BGFX_STATE_DEPTH_TEST_LESS;

		// submit for rendering
		bgfx::setState(state);
		bgfx::submit(viewId, program);
	}

	void FrustumDrawer::drawEdges(bgfx::ViewId viewId, const onyx::Camera::Frustum* frustum)
	{
		// retrieve the program handle
		bgfx::ProgramHandle program = ShaderManager::Instance()->getShaderHandle(ShaderEnums::ConfigurableShaders::DebugColor);

		auto corners = frustum->corners();

		auto ntl = corners.ntl.as<float>();
		auto ntr = corners.ntr.as<float>();
		auto nbr = corners.nbr.as<float>();
		auto nbl = corners.nbl.as<float>();
		auto ftl = corners.ftl.as<float>();
		auto ftr = corners.ftr.as<float>();
		auto fbr = corners.fbr.as<float>();
		auto fbl = corners.fbl.as<float>();

		// set up vertex buffer for the draw call
		std::vector<onyx::Rendering::VertStructs::PosColor> verts =
		{
			onyx::Rendering::VertStructs::PosColor(ntl.x, ntl.y, ntl.z, 0xff000000),
			onyx::Rendering::VertStructs::PosColor(ntr.x, ntr.y, ntr.z, 0xff000000),
			onyx::Rendering::VertStructs::PosColor(nbr.x, nbr.y, nbr.z, 0xff000000),
			onyx::Rendering::VertStructs::PosColor(nbl.x, nbl.y, nbl.z, 0xff000000),

			onyx::Rendering::VertStructs::PosColor(ftl.x, ftl.y, ftl.z, 0xff000000),
			onyx::Rendering::VertStructs::PosColor(ftr.x, ftr.y, ftr.z, 0xff000000),
			onyx::Rendering::VertStructs::PosColor(fbr.x, fbr.y, fbr.z, 0xff000000),
			onyx::Rendering::VertStructs::PosColor(fbl.x, fbl.y, fbl.z, 0xff000000),
		};

		if (bgfx::isValid(sEdgeVertexBuffer))	// if valid, destroy
		{
			bgfx::destroy(sEdgeVertexBuffer);
		}
		// create the vertex buffer
		sEdgeVertexBuffer = bgfx::createVertexBuffer(
			bgfx::copy(verts.data(), uint32_t(sizeof(onyx::Rendering::VertStructs::PosColor) * verts.size()))
			, onyx::Rendering::VertStructs::PosColor::ms_layout
		);

		if (!bgfx::isValid(sEdgeIndexBuffer))	// if not valid, create the index buffer
		{
			// create the index buffer
			sEdgeIndexBuffer = bgfx::createIndexBuffer(
				// static data can be passed with makeRef
				bgfx::makeRef(sEdgeIndices.data(), uint32_t(sizeof(uint16_t) * sEdgeIndices.size()))
			);
		}

		// set up model matrix
		float mtx[16];
		bx::mtxIdentity(mtx);
		bgfx::setTransform(mtx);

		// Set vertex and index buffer.
		bgfx::setVertexBuffer(0, sEdgeVertexBuffer);
		bgfx::setIndexBuffer(sEdgeIndexBuffer);

		uint64_t state = 0
			| BGFX_STATE_WRITE_R
			| BGFX_STATE_WRITE_G
			| BGFX_STATE_WRITE_B
			| BGFX_STATE_WRITE_A
			| BGFX_STATE_WRITE_Z
			| BGFX_STATE_DEPTH_TEST_LESS
			| BGFX_STATE_PT_LINES;

		bgfx::setState(state);
		bgfx::submit(viewId, program);
	}

}