#include "AABoxDrawer.h"

#include <Shaders/ShaderManager.h>

#define AABOX_NUM_VERTS 8
#define AABOX_NUM_INDICES 6*2*3			// 6 sides, 2 triangles per side, and three verts per triangle
#define AABOX_EDGES_NUM_VERTS 8
#define AABOX_EDGES_NUM_INDICES 24

namespace drawers
{

	std::vector<uint16_t> AABoxDrawer::sIndices = std::vector<uint16_t>{
		// bottom side
		0, 1, 2,
		1, 3, 2,
		// top side
		4, 5, 6,
		5, 7, 6,
		// left side
		0, 2, 4,
		2, 6, 4,
		// right side
		1, 3, 5,
		3, 7, 5,
		// front side
		0, 1, 4,
		1, 5, 4,
		// back side
		2, 3, 6,
		3, 7, 6
	};

	std::vector<uint16_t> AABoxDrawer::sEdgeIndices = std::vector<uint16_t>{
		// bottom edges
		0, 1,
		1, 3,
		3, 2,
		2, 0,
		// top edges
		4, 5,
		5, 7,
		7, 6,
		6, 4,
		// side edges
		0, 4,
		1, 5,
		3, 7,
		2, 6
	};

	bgfx::VertexBufferHandle AABoxDrawer::sVertexBuffer = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle AABoxDrawer::sIndexBuffer = BGFX_INVALID_HANDLE;

	bgfx::VertexBufferHandle AABoxDrawer::sEdgeVertexBuffer = BGFX_INVALID_HANDLE;
	bgfx::IndexBufferHandle AABoxDrawer::sEdgeIndexBuffer = BGFX_INVALID_HANDLE;

	void AABoxDrawer::shutdown()
	{
		if (bgfx::isValid(sVertexBuffer))
		{
			bgfx::destroy(sVertexBuffer);
		}
		if (bgfx::isValid(sIndexBuffer))
		{
			bgfx::destroy(sIndexBuffer);
		}
		if (bgfx::isValid(sEdgeVertexBuffer))
		{
			bgfx::destroy(sEdgeVertexBuffer);
		}
		if (bgfx::isValid(sEdgeIndexBuffer))
		{
			bgfx::destroy(sEdgeIndexBuffer);
		}

		sIndices.clear();
		sEdgeIndices.clear();
	}

	void AABoxDrawer::draw(bgfx::ViewId viewId, const std::vector<lgal::world::AABB3d>& boxes)
	{
		if (boxes.size() > 0)
		{
			drawBoxes(viewId, boxes);
			drawEdges(viewId, boxes);
		}
	}

	void AABoxDrawer::drawBoxes(bgfx::ViewId viewId, const std::vector<lgal::world::AABB3d>& boxes)
	{
		// retrieve the program handle
		bgfx::ProgramHandle program = ShaderManager::Instance()->getShaderHandle(ShaderEnums::ConfigurableShaders::DebugColor);

		// set up vertex/index buffers for the draw call
		std::vector<onyx::Rendering::VertStructs::PosColor> verts;
		std::vector<uint16_t> indices;

		// reserve memory
		verts.reserve(boxes.size() * AABOX_NUM_VERTS);
		indices.reserve(boxes.size() * AABOX_NUM_INDICES);

		// pack the boxes into a single vertex buffer
		for (auto const& box : boxes)
		{
			// compute the offset
			uint16_t offset = (uint16_t)verts.size();

			// pack the vertices
			for (int i = 0; i < 8; i++)
			{
				auto pos = box.vertex(i).as<float>();
				onyx::Rendering::VertStructs::PosColor v(pos.x, pos.y, pos.z, 0x0f000000);
				verts.push_back(v);
			}

			// pack the indices
			for (int i = 0; i < AABOX_NUM_INDICES; i++)
			{
				indices.push_back(sIndices[i] + offset);
			}
		}

		if (bgfx::isValid(sVertexBuffer))	// if valid, destroy
		{
			bgfx::destroy(sVertexBuffer);
		}
		// create the vertex buffer
		sVertexBuffer = bgfx::createVertexBuffer(
			bgfx::copy(verts.data(), uint32_t(sizeof(onyx::Rendering::VertStructs::PosColor) * verts.size()))
			, onyx::Rendering::VertStructs::PosColor::ms_layout
		);

		if (bgfx::isValid(sIndexBuffer))	// if valid, destroy
		{
			bgfx::destroy(sIndexBuffer);
		}
		// create the index buffer
		sIndexBuffer = bgfx::createIndexBuffer(
			bgfx::copy(indices.data(), uint32_t(sizeof(uint16_t) * indices.size()))
		);

		// create the model matrix
		float mtx[16];
		bx::mtxIdentity(mtx);
		bgfx::setTransform(mtx);

		// set vertex and index buffer.
		bgfx::setVertexBuffer(0, sVertexBuffer);
		bgfx::setIndexBuffer(sIndexBuffer);

		uint64_t state = 0
			| BGFX_STATE_WRITE_R
			| BGFX_STATE_WRITE_G
			| BGFX_STATE_WRITE_B
			| BGFX_STATE_WRITE_A
			| BGFX_STATE_WRITE_Z
			| BGFX_STATE_DEPTH_TEST_LESS;

		// submit for rendering
		bgfx::setState(state);
		bgfx::submit(viewId, program);
	}

	void AABoxDrawer::drawEdges(bgfx::ViewId viewId, const std::vector<lgal::world::AABB3d>& boxes)
	{
		// retrieve the program handle
		bgfx::ProgramHandle program = ShaderManager::Instance()->getShaderHandle(ShaderEnums::ConfigurableShaders::DebugColor);

		// set up vertex/index buffers for the draw call
		std::vector<onyx::Rendering::VertStructs::PosColor> verts;
		std::vector<uint16_t> indices;

		// reserve memory
		verts.reserve(boxes.size() * AABOX_EDGES_NUM_VERTS);
		indices.reserve(boxes.size() * AABOX_EDGES_NUM_INDICES);

		// pack the boxes into a single vertex buffer
		for (auto const& box : boxes)
		{
			// compute the offset
			uint16_t offset = (uint16_t)verts.size();

			// pack the vertices
			for (int i = 0; i < 8; i++)
			{
				auto pos = box.vertex(i).as<float>();
				onyx::Rendering::VertStructs::PosColor v(pos.x, pos.y, pos.z, 0xffffffff);
				verts.push_back(v);
			}

			// pack the indices
			for (int i = 0; i < AABOX_EDGES_NUM_INDICES; i++)
			{
				indices.push_back(sEdgeIndices[i] + offset);
			}
		}

		if (bgfx::isValid(sEdgeVertexBuffer))	// if valid, destroy
		{
			bgfx::destroy(sEdgeVertexBuffer);
		}
		// create the vertex buffer
		sEdgeVertexBuffer = bgfx::createVertexBuffer(
			bgfx::copy(verts.data(), uint32_t(sizeof(onyx::Rendering::VertStructs::PosColor) * verts.size()))
			, onyx::Rendering::VertStructs::PosColor::ms_layout
		);

		if (bgfx::isValid(sEdgeIndexBuffer))	// if valid, destroy
		{
			bgfx::destroy(sEdgeIndexBuffer);
		}
		// create the index buffer
		sEdgeIndexBuffer = bgfx::createIndexBuffer(
			bgfx::copy(indices.data(), uint32_t(sizeof(uint16_t) * indices.size()))
		);

		// set up the model matrix
		float mtx[16];
		bx::mtxIdentity(mtx);
		bgfx::setTransform(mtx);

		// set vertex and index buffer.
		bgfx::setVertexBuffer(0, sEdgeVertexBuffer);
		bgfx::setIndexBuffer(sEdgeIndexBuffer);

		uint64_t state = 0
			| BGFX_STATE_WRITE_R
			| BGFX_STATE_WRITE_G
			| BGFX_STATE_WRITE_B
			| BGFX_STATE_WRITE_A
			| BGFX_STATE_WRITE_Z
			| BGFX_STATE_DEPTH_TEST_LESS
			| BGFX_STATE_PT_LINES;

		// submit for rendering
		bgfx::setState(state);
		bgfx::submit(viewId, program);
	}

}