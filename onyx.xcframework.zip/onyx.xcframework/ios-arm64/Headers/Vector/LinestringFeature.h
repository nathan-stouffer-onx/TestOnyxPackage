#ifndef __VECTOR_LINESTRING_FEATURE_H__
#define __VECTOR_LINESTRING_FEATURE_H__

#include <lucid/gal/Types.h>

#include "Vector/Feature.h"

namespace onyx {
namespace Vector {

	class LinestringFeature final : public Feature
	{
	public:

		LinestringFeature(lgal::tile::Polyline const& polyline, Feature::PropertiesT const& properties = {});
		LinestringFeature(std::vector<lgal::tile::Polyline>&& polylines, Feature::PropertiesT const& properties = {});

		std::shared_ptr<Feature const> subFeature(lgal::tile::AABB2d const& aabb, bool relative) const override;

		std::vector<lgal::tile::Vector2> const& points() const override;
		std::vector<lgal::world::Vector2> toWorld(lgal::world::AABB2d const& bounds) const override;

		std::vector<lgal::tile::Polyline> const& geometries() const { return mPolylines; }

	private:

		std::vector<lgal::tile::Polyline> const mPolylines;

	};

} }

#endif