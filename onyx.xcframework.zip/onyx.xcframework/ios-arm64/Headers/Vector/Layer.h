#ifndef __VECTOR_LAYER_H__
#define __VECTOR_LAYER_H__

#include <vector>
#include <memory>

#include <Warnings.h>

DISABLE_WARNING_PUSH
DISABLE_WARNING_CONDITION_EXPRESSION_IS_CONSTANT
DISABLE_WARNING_NOT_DEFINED
#include <3rdParty/protobuf/vector_tile.pb.h>
DISABLE_WARNING_POP

#include <lucid/gal/Types.h>

#include "Vector/Feature.h"

namespace onyx {
namespace Vector {

	/*
	* A class that represents a layer in a vector tile. A layer consists of a collection of Features and their associated
	* metadata. A Layer can be constructed directly from a vector of Features or from an encoded protobuf layer
	*/

	class Layer
	{
	public:

		Layer(vector_tile::Tile::Layer const& layer, time_float_t timestampMS);
		Layer(std::string const& name, std::shared_ptr<Feature const> feature, time_float_t timestampMS);
		Layer(std::string const& name, std::vector<std::shared_ptr<Feature const>> const& features, time_float_t timestampMS);

		~Layer() = default;

		inline std::string const& name() const { return mName; }
		inline size_t byteCount() const { return mByteCount; }
		inline time_float_t timestampMS() const { return mTimestampMS; }

		// TODO possibly create an IndexedLayer class that quickly evaluates subLayer queries. We will still return 
		// regular Layers from subLayer, but we will store IndexedLayers in VectorTiles for effecient overzooming

		// Returns a new Layer object that is clipped and rescaled (top left is (0, 0)) to the provided subregion.
		// 
		//                      Layer
		// +---------------------------------------------+
		// |											 |
		// |											 |
		// |											 |
		// |					   +---------+			 |
		// |					   |         |			 |
		// |					   |   box   |			 |
		// |                       |         |			 |
		// |                       +---------+			 |
		// |											 |
		// |											 |
		// |											 |
		// |											 |
		// |											 |
		// |											 |
		// |                                             |
		// +---------------------------------------------+
		std::shared_ptr<Layer const> subLayer(lgal::tile::AABB2d const& subregion) const;

		std::vector<std::shared_ptr<Feature const>>::const_iterator begin() const { return mFeatures.begin(); }
		std::vector<std::shared_ptr<Feature const>>::const_iterator end()   const { return mFeatures.end(); }

		// TODO (scott) Redesign render tests to generate their own vector tiles so that this isn't needed
		void push_back(std::shared_ptr<Feature const>& feature)
		{
			mFeatures.push_back(feature);
			mByteCount += feature->byteCount();
		}

	private:

		std::string const mName;

		// list of all features in the tile
		std::vector<std::shared_ptr<Feature const>> mFeatures;

		time_float_t const mTimestampMS;

		size_t mByteCount = 0;

	};

} }

#endif