#ifndef LOGMANAGER_H_
#define LOGMANAGER_H_

#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <mutex>
#include <functional>

#define logI onyx::core::LogManager::Instance()->logInfo
#define logE onyx::core::LogManager::Instance()->logError
#define logD onyx::core::LogManager::Instance()->logDebug
#define logV onyx::core::LogManager::Instance()->logVerbose
#define logWTF onyx::core::LogManager::Instance()->logWhatATerribleFailure

#define COREVIEWERTAG "CoreViewer"

namespace onyx {
namespace core {

enum class LogPriorityEnum
{
    Verbose, Debug, Info, Error, WTF
};

class LogManager
{

public:
	typedef std::function<void(LogPriorityEnum, std::string const&, std::string const&)> LogCallbackT;

    static LogManager* Instance();
	static void Shutdown();

    LogManager();
    ~LogManager();

    void logVerbose(std::string message);
    void logDebug(std::string message);
    void logInfo(std::string message);
    void logError(std::string message);
    void logWhatATerribleFailure(std::string message);
	static void setCallback(LogCallbackT callback) { sLogCallback = callback; }

    template<typename... Args>
    void logVerbose(std::string message, Args... args)
    {
        message = format(message, args...);
        logEntry(new Entry(LogPriorityEnum::Verbose, COREVIEWERTAG, message));
    }

    template<typename... Args>
    void logDebug(std::string message, Args... args)
    {
        message = format(message, args...);
        logEntry(new Entry(LogPriorityEnum::Debug, COREVIEWERTAG, message));
    }

    template<typename... Args>
    void logInfo(std::string message, Args... args)
    {
        message = format(message, args...);
        logEntry(new Entry(LogPriorityEnum::Info, COREVIEWERTAG, message));
    }

    template<typename... Args>
    void logError(std::string message, Args... args)
    {
        message = format(message, args...);
        logEntry(new Entry(LogPriorityEnum::Error, COREVIEWERTAG, message));
    }

    template<typename... Args>
    void logWhatATerribleFailure(std::string message, Args... args)
    {
        message = format(message, args...);
        logEntry(new Entry(LogPriorityEnum::WTF, COREVIEWERTAG, message));
    }

    
    void enableConsoleLogLevel(LogPriorityEnum level);
    void disableConsoleLogLevel(LogPriorityEnum level);

    inline void enableConsoleLog() { mLogToConsole = true; }
    inline void disableConsoleLog() { mLogToConsole = false; }

private:

    static LogManager* sSingleton;

    struct Entry
    {
        const LogPriorityEnum mPriority;
        const std::string mTag, mMessage;

        Entry(LogPriorityEnum _priority, std::string _tag, std::string _message) :
                mPriority(_priority)
                , mTag(_tag)
                , mMessage(_message) {}

        std::string toString()
        {
            std::string priorityFlag;
            if (mPriority == LogPriorityEnum::Verbose) { priorityFlag = "V"; }
            if (mPriority == LogPriorityEnum::Debug)   { priorityFlag = "D"; }
            if (mPriority == LogPriorityEnum::Info)    { priorityFlag = "I"; }
            if (mPriority == LogPriorityEnum::Error)   { priorityFlag = "E"; }
            if (mPriority == LogPriorityEnum::WTF)     { priorityFlag = "WTF"; }

            return priorityFlag + "/" + mTag + " " + mMessage;
        }

    };

	static LogCallbackT sLogCallback;

    std::vector<Entry*> mEntries;
    std::map<LogPriorityEnum, bool> mConsoleLogPriorityEnabled;
    bool mLogToConsole = true;

    std::mutex mLogLock;

    void logEntry(Entry* entry);
    void writeToConsole(Entry* entry);

    template<typename... Args>
    std::string format(std::string str, Args... args)
    {
        if (length(args...) == 0)
        {
            return str;
        }
        else
        {
            int len = (int) str.length() + length(args...);
            char* charStr = new char[len];
            sprintf(charStr, str.c_str(), args...);
            str = std::string(charStr);
            delete[] charStr;
            return str;
        }
    }

    template<typename T, typename... Tail>
    int length(T head, Tail... tail)        // upper bound of number of characters
    {
        std::ostringstream os;
        os.precision(25);		// set high precision to get enough length for floats
        os << head;
        return (int) os.str().length() + 15 + length(tail...);	// add 15 for trailing zeros
    }

    int length()
    {
        return 0;
    }

};

} }

#endif