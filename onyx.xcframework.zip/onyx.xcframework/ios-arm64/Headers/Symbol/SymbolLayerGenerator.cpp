#include "SymbolLayerGenerator.h"

namespace onyx::Styling {

namespace Expr = onyx::Styling::Expressions;

std::unique_ptr<Styling::SymbolLayer> genSymLyr(SymOpts const& options, std::string const& layerId)
{
	if (options.sourceId.empty() || layerId.empty())
	{
		logE("genSymLyr - passed in layerId and/or sourceId is empty");
		return nullptr;
	}

	auto const& iconStyle = options.style.icon;
	auto const& textStyle = options.style.text.style;

	auto symbolLayout = std::make_shared<Styling::SymbolLayout>();
	symbolLayout->visibility = options.visibility;
	symbolLayout->symbolPlacement = Expr::Enum::construct(options.style.placement);

	symbolLayout->iconImage = Expr::Image::construct(iconStyle.image.key);
	symbolLayout->iconSize = Expr::Number::construct(iconStyle.sizeMultiple);
	symbolLayout->iconOffset = Expr::Array::construct<float>({ iconStyle.offsetPx.x, iconStyle.offsetPx.y });
	symbolLayout->iconRotDeg = Expr::Enum::construct(iconStyle.rotRad * 180.f / lmath::constants::pi<float>());
	symbolLayout->iconAnchor = Expr::Enum::construct(iconStyle.anchor);
	symbolLayout->iconTextFit = Expr::Enum::construct(iconStyle.textFitOpts);
	symbolLayout->iconTextFitPadding = Expr::Array::construct<float>({ iconStyle.textFitPadding.x, iconStyle.textFitPadding.y, iconStyle.textFitPadding.z, iconStyle.textFitPadding.w });
	symbolLayout->iconPadding = Expr::Number::construct(iconStyle.padding);
	symbolLayout->iconRotAlignment = Expr::Enum::construct(iconStyle.rotAlignment);
	symbolLayout->iconPitchAlignment = Expr::Enum::construct(iconStyle.pitchAlignment);
	symbolLayout->iconAllowOverlap = Expr::Boolean::construct(iconStyle.allowOverlap);
	symbolLayout->iconIgnorePlacement = Expr::Boolean::construct(iconStyle.ignorePlacement);
	
	{
		// TODO (Ronald): (CSONYX-388) Create a proper field-to-formatExpr generator
		std::string textStr = (options.style.text.field.isEmpty()) ? "" : options.style.text.field.getFullText();
		symbolLayout->text.field = Expr::Format::construct(textStr);
	}
	symbolLayout->text.size = Expr::Number::construct(float(textStyle.font.pixelSize));
	symbolLayout->text.fontFace = Expr::Array::construct(std::vector<std::string>{textStyle.font.name});
	symbolLayout->text.letterSpacing = Expr::Number::construct(textStyle.kerningModifier);
	if (!textStyle.anchors.empty())
	{
		symbolLayout->text.anchor = Expr::Enum::construct(textStyle.anchors.front());
	}
	symbolLayout->text.allowOverlap = Expr::Boolean::construct(textStyle.allowOverlap);
	symbolLayout->text.rotationAlignment = Expr::Enum::construct(textStyle.rotAlignment);
	symbolLayout->text.offset = Expr::Array::construct<float>({ textStyle.offsetEm.x, textStyle.offsetEm.y });
	symbolLayout->text.dropShadowOffset = Expr::Array::construct<float>({ textStyle.dropShadowOffset.x, textStyle.dropShadowOffset.y });
	symbolLayout->text.transform = Expr::Enum::construct(textStyle.transform);
	symbolLayout->text.keepUpright = Expr::Boolean::construct(textStyle.keepUpright);

	auto symbolPaint = std::make_shared<SymbolPaint>();
	symbolPaint->iconColor = Expr::Color::construct(iconStyle.color);
	symbolPaint->iconOpacity = Expr::Number::construct(iconStyle.opacity);
	symbolPaint->iconTranslate = Expr::Array::construct<float>({ iconStyle.anchorOffsetPx.x, iconStyle.anchorOffsetPx.y });
	symbolPaint->iconTranslateAnchor = Expr::Enum::construct(iconStyle.anchorOffsetFrame);

	symbolPaint->text.color = Expr::Color::construct(textStyle.color);
	symbolPaint->text.haloColor = Expr::Color::construct(textStyle.haloColor);
	symbolPaint->text.shadowColor = Expr::Color::construct(textStyle.dropShadowColor);
	symbolPaint->text.opacity = Expr::Number::construct(textStyle.opacity);
	symbolPaint->text.translate = Expr::Array::construct<float>( {textStyle.anchorTranslate.x, textStyle.anchorTranslate.y });
	symbolPaint->text.translateAnchor = Expr::Enum::construct(textStyle.anchorOrient);
	symbolPaint->text.haloWidth = Expr::Number::construct(textStyle.haloWidth);

	auto symbolLayer = std::make_unique<SymbolLayer>();
	symbolLayer->id = layerId;
	symbolLayer->source = options.sourceId;
	symbolLayer->layout = symbolLayout;
	symbolLayer->paint = symbolPaint;
	symbolLayer->minZoom = options.minZoom;
	symbolLayer->maxZoom = options.maxZoom;

	return symbolLayer;
}

}

