#include "SymbolManager.h"

#include <lucid/math/Constants.h>
#include <lucid/Profiler.h>

#include <Logging/LogManager.h>
#include <System/OnyxException.h>

#include "Font/FontManager.h"
#include "Utils/MapMath.h"
#include "Viewport/Viewport.h"

namespace onyx::Symbol {

SymbolManager::SymbolManager(Viewport const* viewport)
	: mScreenSize(viewport->size().as<gpu_float_t>())
	, mViewport(viewport)
	, mDummyTextBuffer(nullptr)
	, mIconRenderer(new IconRenderer())
{
	auto caps = bgfx::getCaps();

	mHomogenousDepth = caps->homogeneousDepth;

	mNearClip = mHomogenousDepth ? -1.f : 0.f;
	mFarClip = 1.f;

	mSymbolFrameCache.reserve(DBG_maxSymbolsDrawn);
	mIconPayloads.reserve(DBG_maxSymbolsDrawn);
	mCurrentFrameSymbols.reserve(DBG_maxSymbolsDrawn);
}

void SymbolManager::initialize()
{
	auto bgfxFontManager = Font::M3DFontManager::getFontManager();
	ONYX_ASSERT(!bgfxFontManager.expired(), "Font manager has not been initialized");
	mTextBufferManager.reset(new TextBufferManager(bgfxFontManager));
	mDummyTextBuffer = std::make_unique<TextBuffer>(bgfxFontManager);
}

SymbolManager::~SymbolManager()
{
	for (auto& [style, handle] : mTextBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	mTextBufferManager.reset();
}

void SymbolManager::update()
{
	for (auto& kvp : mTextBufferHandles)
	{
		mTextBufferManager->clearTextBuffer(kvp.second);
	}
}

void SymbolManager::resetFontManager()
{
	auto bgfxFontManager = Font::M3DFontManager::getFontManager();
	ONYX_ASSERT(!bgfxFontManager.expired(), "Font manager has not been initialized");

	for (auto& [style, handle] : mTextBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	mTextBufferHandles.clear();

	mTextBufferManager.reset(new TextBufferManager(bgfxFontManager));
}

TextBufferHandle SymbolManager::getStyleBuffer(Styling::FontFace const& font)
{
	auto found = mTextBufferHandles.find(font);
	TextBufferHandle handle = { bgfx::kInvalidHandle };
	if (found == mTextBufferHandles.end())
	{
		// TODO (Ronald): (CSONYX-312) make font type obey the stylesheet
		auto newHandle = mTextBufferManager->createTextBuffer(Styling::TextFontTypes::DistanceOutline, TextBuffer::Type::Transient);
		mTextBufferHandles.emplace(font, newHandle);
		handle = newHandle;
	}
	else
	{
		handle = found->second;
	}
	return handle;
}

void SymbolManager::setTextRenderStyle(TextBufferHandle const hndl, lgal::gpu::Vector2 const& xDir, lgal::gpu::Vector2 const& yDir, Styling::TextStyle const& style, gpu_float_t opacity)
{
	mTextBufferManager->setTextDirection(hndl, xDir, yDir);
	mTextBufferManager->setStyle(hndl, style);
	mTextBufferManager->setAlpha(hndl, opacity);
	mTextBufferManager->setOutlineWidth(hndl, style.haloWidth);
	mTextBufferManager->setDropShadowOffset(hndl, style.dropShadowOffset.x, style.dropShadowOffset.y);
}

void SymbolManager::bufferLabel(ScreenState const& screenState, MapSymbol const& symbol, Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& camera)
{
	LUCID_PROFILE_SCOPE("SymbolManager::bufferLabel");

	auto placement = symbol.getPlacement();
	auto& label = *symbol.getLabel();
	auto& style = *label.getStyle();

	TextBufferHandle mainTBH = getStyleBuffer(style.font);

	mTextBufferManager->setStyle(mainTBH, style);
	mTextBufferManager->setAlpha(mainTBH, label.getCurrentAlpha());
	mTextBufferManager->setOutlineWidth(mainTBH, style.haloWidth);
	mTextBufferManager->setDropShadowOffset(mainTBH, style.dropShadowOffset.x, style.dropShadowOffset.y);

	auto feature = label.getFeature();
	lgal::gpu::AABB2d labelBB = lgal::gpu::AABB2d::nothing();

	bool textFollowsLine = style.rotAlignment != Styling::Alignment::Viewport && placement != Styling::SymbolPlacement::POINT;
	if (textFollowsLine)
	{
		auto& textBuf = mTextBufferManager->getTextBuffer(mainTBH);
		// Hacky, but want to preserve const here. Changes in screen state should have happened in genScreenState, anyway
		ScreenState screenStateCpy = screenState;
		layoutLineText(screenStateCpy, textBuf, symbol, camera, heightAtlas);
		ONYX_ASSERT(screenStateCpy.cullState == CullState::VISIBLE, "bufferLabel - cull state calculation should have passed");
	}

	// Labels not laid out along screen or world path
	else
	{
		LUCID_PROFILE_SCOPE("labels NOT along lines");

		auto xDir = screenState.labelScreenDirectionPx.xy;
		auto yDir = lgal::gpu::Vector2{ -xDir.y, xDir.x };

		Styling::TextStyle chunkStyle = style;
		for (auto const& chunk : label.getChunks())
		{
			Styling::FontFace chunkFont = style.font;
			if (chunk.fontOverride->font && !chunk.fontOverride->font->empty())
			{
				chunkFont.name = chunk.fontOverride->font->front();
			}
			chunkFont.pixelSize = (int32_t)((gpu_float_t)chunkFont.pixelSize * chunk.fontOverride->fontScale);

			TextBufferHandle chunkTexBufHndl = getStyleBuffer(chunkFont);
			ONYX_ASSERT(chunkTexBufHndl.idx != bgfx::kInvalidHandle, "Buffer label: Text buffer should be valid");
			chunkStyle.color = chunk.fontOverride->color ? *chunk.fontOverride->color : style.color;

			auto chunkFontHndl = getFontHandle(chunkFont);

			setTextRenderStyle(chunkTexBufHndl, xDir, yDir, chunkStyle, label.getCurrentAlpha());

			mTextBufferManager->setPenPosition(chunkTexBufHndl, { screenState.labelScreenPositionPx.xy + chunk.offset, mNearClip + DBG_DepthOffset });
			mTextBufferManager->setPixelSize(chunkTexBufHndl, chunkFontHndl);
			labelBB = mTextBufferManager->appendText(chunkTexBufHndl, chunkFontHndl, chunk.strView.data(), style.kerningModifier, chunk.strView.data() + chunk.strView.size());
		}
	}
}

ScreenState SymbolManager::genScreenState(Camera::ScreenSpaceManager& screenSpaceManager, MapSymbol const& symbol, Camera::CameraState const& camera, Atlases::HeightAtlas const* heightAtlas, bool expiringSymbol)
{
	LUCID_PROFILE_SCOPE("genScreenState");

	ScreenState screenState;
	screenState.cullState = CullState::UNKNOWN;
	auto symPlacement = symbol.getPlacement();

	lgal::world::Vector3 anchorPos = symbol.getAnchorPos();
	Utils::SpaceTypes spaceType = symbol.getSpaceType();

	// Calculate anchor's screen position
	lgal::gpu::Vector3 anchorScreenPos{ -1000.f };
	switch (spaceType)
	{
	case Utils::SpaceTypes::ScreenPx:
		anchorScreenPos = anchorPos.as<gpu_float_t>();
		break;
	case Utils::SpaceTypes::Tile:
		anchorScreenPos = tileToScreenCoords(anchorPos, camera, mScreenSize, symbol.getTileId(), heightAtlas);
		anchorScreenPos.z = lmath::clamp(mNearClip, mFarClip, anchorScreenPos.z - DBG_DepthOffset - 0.01f);
		break;
	case Utils::SpaceTypes::World:
	case Utils::SpaceTypes::WorldXY:
		if (heightAtlas)
		{
			anchorPos.z = heightAtlas->heightAt(anchorPos.xy);
		}

		if (!worldToScreenCoords(anchorScreenPos, camera, mScreenSize, anchorPos))
		{
			screenState.cullState = CullState::SCREEN_SPACE_CLIPPED;
			return screenState;
		}
		anchorScreenPos.z = lmath::clamp(mNearClip, mFarClip, anchorScreenPos.z - DBG_DepthOffset - 0.01f);
		break;
	default:
		ONYX_THROW("genScreenState - SpaceType not supported");
		break;
	}

	// Check if anchor is screen-space culled
	// TODO (Ronald): Would be better to check a BB against the screen space for this cull test
	if (isScreenClipped(anchorScreenPos, mScreenSize, mNearClip, mFarClip))
	{
		screenState.cullState = CullState::SCREEN_SPACE_CLIPPED;
		return screenState;
	}

	// Check if anchor is depth culled
	gpu_float_t vpDepth = mViewport->depthAtPixel(anchorScreenPos.xy.as<screen_coord_t>());
	if (vpDepth < anchorScreenPos.z)
	{
		screenState.cullState = CullState::DEPTH_CLIPPED;
		return screenState;
	}
	
	bool passesLabelOverlap = true, passesIconOverlap = true;

	// LABEL SCREEN STATE
	if (symbol.hasLabel())
	{
		LUCID_PROFILE_SCOPE("genScreenState - label");

		screenState.labelScreenPositionPx = anchorScreenPos;

		auto& label = *symbol.getLabel();
		auto const textStyle = label.getStyle();

		// TODO (Ronald) Add text-offset calculation here

		// Calculate label x direction in screen space
		screenState.labelScreenDirectionPx = { 1, 0, 0 };
		bool notFollowingLine = textStyle->rotAlignment == Styling::Alignment::Viewport || symPlacement == Styling::SymbolPlacement::POINT;
		if (notFollowingLine && !isRotatedToVp(symPlacement, textStyle->rotAlignment))
		{
			// Project and normalize the X and Y axis
			auto projectedX = camera.projectDirToScreen(screenState.labelScreenDirectionPx);
			if (projectedX.length() > 1e-4f) { projectedX.normalize(); }

			// Remove depth offset as depth offset would be nonlinear
			screenState.labelScreenDirectionPx.xy = projectedX.xy;
		}

		// Update label screen state based on text layout results
		calcTextPlacement(screenState, symbol, camera, heightAtlas);
		// calcTextPlacement culled the symbol
		if (screenState.cullState != CullState::UNKNOWN)
		{
			return screenState;
		}

		// Check for overlap culling
		lgal::screen::AABB2d labelBB = screenState.labelScreenRectPx.as<screen_coord_t>();

		if (!label.getForce() && !label.getStyle()->allowOverlap && !expiringSymbol && screenSpaceManager.intersects(labelBB) != lmath::Intersections::NONE)
		{
			screenState.cullState = CullState::OVERLAP_CLIPPED;
			passesLabelOverlap = false;
		}
	}

	// ICON SCREEN STATE
	if (symbol.hasIcon())
	{
		LUCID_PROFILE_SCOPE("genScreenState - icon");

		MapIcon const icon = symbol.getIcon().value();

		lgal::gpu::Vector3 projected = anchorScreenPos;
		
		// Calculate icon orientation
		bool rotateToVp = isRotatedToVp(symPlacement, icon.style.rotAlignment);
		bool pitchToVp = rotateToVp;
		if (icon.style.pitchAlignment != Styling::Alignment::Auto) {
			pitchToVp = icon.style.pitchAlignment == Styling::Alignment::Viewport ? true : false;
		}
		lgal::gpu::Vector3 iconXAxis{ 1.f, 0, 0 };
		lgal::gpu::Vector3 iconYAxis{ 0, 1.f, 0 };
		if (!rotateToVp && !pitchToVp)
		{
			iconXAxis = camera.projectDirToScreen(iconXAxis);
			if (iconXAxis.length() > 1e-6f) iconXAxis.normalize();
			iconYAxis = camera.projectDirToScreen(iconYAxis);
			if (iconYAxis.length() > 1e-6f) iconYAxis.normalize();
		}
		else if (!rotateToVp && pitchToVp)
		{
			// Rotate the up and right vector by the angle made between the icon space right vector and the world right vector
			auto projectedX = camera.projectDirToScreen(iconXAxis);
			projectedX.z = 0;
			if (projectedX.length() > 1e-6f) projectedX.normalize();
			auto projectedY = lmath::rotateAround(projectedX, lgal::gpu::Vector3{ 0, 0, 1.f }, lmath::constants::half_pi<gpu_float_t>());

			iconXAxis = projectedX;
			iconYAxis = projectedY;
		}
		else if (rotateToVp && !pitchToVp)
		{
			// Rotate the up vector by the angle between the world normal and the camera's negated lookAt vector
			auto invLookAt = -camera.lookDir().as<gpu_float_t>();
			auto rad = lmath::acos(lmath::dot(invLookAt, lgal::gpu::Vector3{ 0, 0, 1 }));
			auto projectedY = lmath::rotateAround(iconYAxis, lgal::gpu::Vector3{ 1, 0, 0 }, rad);

			iconYAxis = projectedY;
		}

		{
			// Offset anchor
			lgal::gpu::Vector2 offsetAxisX{ 1.f, 0 };
			lgal::gpu::Vector2 offsetAxisY{ 0, 1.f };
			if (icon.style.anchorOffsetFrame == Styling::TranslateAnchor::MAP)
			{
				// Project and normalize the X and Y axis
				auto projectedX = camera.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisX, 0 });
				if (projectedX.length() > 1e-4f) { projectedX.normalize(); }
				auto projectedY = camera.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisY, 0 });
				if (projectedY.length() > 1e-4f) { projectedY.normalize(); }

				// Remove depth offset as depth offset would be nonlinear
				offsetAxisX = projectedX.xy;
				offsetAxisY = projectedY.xy;
			}

			auto anchorOffset = offsetAxisX * icon.style.anchorOffsetPx.x + offsetAxisY * icon.style.anchorOffsetPx.y;
			projected += lgal::gpu::Vector3{ anchorOffset, 0 };
		}

		lgal::gpu::Vector3 closestToAnchor{ 0 };
		auto adjSizePx = icon.style.sizeMultiple * icon.spriteIdx.sizePx;
		adjSizePx.x = std::round(adjSizePx.x);
		adjSizePx.y = std::round(adjSizePx.y);
		switch (icon.style.anchor & Styling::Anchor::VERTICAL_FLAGS)
		{
		case Styling::Anchor::BELOW:
			closestToAnchor += (adjSizePx.y * iconYAxis);
			break;
		case Styling::Anchor::VERTICAL_CENTER:
			closestToAnchor += (0.5f * adjSizePx.y * iconYAxis);
			break;
		default:
			break;
		}
		switch (icon.style.anchor & Styling::Anchor::HORIZONTAL_FLAGS)
		{
		case Styling::Anchor::RIGHT:
			closestToAnchor += (adjSizePx.x * iconXAxis);
			break;
		case Styling::Anchor::HORIZONTAL_CENTER:
			closestToAnchor += (0.5f * adjSizePx.x * iconXAxis);
			break;
		default:
			break;
		}
		closestToAnchor.z = 0;
		projected -= closestToAnchor;

		// Rotate CW about icon's midpoint
		{
			auto midpoint = 0.5f * adjSizePx.x * iconXAxis + 0.5f * adjSizePx.y * iconYAxis;
			auto rotAxis = lmath::cross(iconXAxis, iconYAxis);
			iconXAxis = lmath::rotateAround(iconXAxis, rotAxis, icon.style.rotRad);
			iconYAxis = lmath::rotateAround(iconYAxis, rotAxis, icon.style.rotRad);
			midpoint -= (0.5f * adjSizePx.x * iconXAxis + 0.5f * adjSizePx.y * iconYAxis);
			midpoint.z = 0;
			projected += midpoint;
		}

		// Remove z axis contribution when doing offset
		iconXAxis.z = 0, iconYAxis.z = 0;
		auto offset = (iconXAxis * icon.style.sizeMultiple * icon.style.offsetPx.x) +
			(iconYAxis * icon.style.sizeMultiple * icon.style.offsetPx.y);
		projected += lgal::gpu::Vector3{ offset.x, offset.y, 0 };

		screenState.iconScreenXAxis = iconXAxis.xy;
		screenState.iconScreenYAxis = iconYAxis.xy;
		screenState.iconScreenPositionPx = projected;
		screenState.iconSizePx = adjSizePx;

		// TODO (Ronald): (CSONYX-308) This works only with viewport pitched + rotated labels. Need to account for size of label along its screen x and y directions
		// Also needs to deal with labels resizing instead of icons due to the sprite's content area being set
		auto textFitOpts = icon.style.textFitOpts;
		if (textFitOpts != Styling::TextFitOpts::None && symbol.hasLabel())
		{
			auto texBBLen = screenState.labelScreenRectPx.length();
			auto midpoint = screenState.iconScreenPositionPx.xy + (0.5f * screenState.iconSizePx.x * screenState.iconScreenXAxis) +
				(0.5f * screenState.iconSizePx.y * screenState.iconScreenYAxis);

			auto pos = midpoint - (0.5f * texBBLen.x * screenState.iconScreenXAxis) -
				(0.5f * texBBLen.y * screenState.iconScreenYAxis);
			pos -= (icon.style.textFitPadding.w * screenState.iconScreenXAxis) + (icon.style.textFitPadding.x * screenState.iconScreenYAxis);
			auto siz = texBBLen + lgal::gpu::Vector2{ icon.style.textFitPadding.y + icon.style.textFitPadding.w,
				icon.style.textFitPadding.x + icon.style.textFitPadding.z };

			if ((textFitOpts & Styling::TextFitOpts::Width) != 0)
			{
				screenState.iconSizePx.x = siz.x;
				screenState.iconScreenPositionPx.x = pos.x;
			}
			if ((textFitOpts & Styling::TextFitOpts::Height) != 0)
			{
				screenState.iconSizePx.y = siz.y;
				screenState.iconScreenPositionPx.y = pos.y;
			}
		}

		// Calculate vertices and fit BB to them
		auto pt1 = screenState.iconScreenPositionPx.xy;
		auto pt2 = pt1 + screenState.iconScreenXAxis * screenState.iconSizePx.x;
		auto pt3 = pt1 + screenState.iconScreenYAxis * screenState.iconSizePx.y;
		auto pt4 = pt2 + screenState.iconScreenYAxis * screenState.iconSizePx.y;
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt1);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt2);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt3);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt4);

		auto padding = icon.style.padding;
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.pushBounds({ padding });
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.pushBounds({ -padding });

		// Check for overlap culling
		if (!icon.style.allowOverlap && !expiringSymbol && screenSpaceManager.intersects(screenState.iconScreenRectPx.as<screen_coord_t>()) != lmath::Intersections::NONE)
		{
			screenState.cullState = CullState::OVERLAP_CLIPPED;
			passesIconOverlap = false;
		}
	}

	if (passesIconOverlap && passesLabelOverlap)
	{
		// Expiring symbols should not block other symbols from being placed
		if (!expiringSymbol)
		{
			if (symbol.hasIcon())
			{
				screenSpaceManager.reserveRect(screenState.iconScreenRectPx.as<screen_coord_t>());
			}
			if (symbol.hasLabel())
			{
				screenSpaceManager.reserveRect(screenState.labelScreenRectPx.as<screen_coord_t>());
			}
		}

		screenState.cullState = CullState::VISIBLE;
	}

	return screenState;
}

bool SymbolManager::passesCull(ScreenState const& screenState, bool expiringSymbol)
{
	LUCID_PROFILE_SCOPE("Symbol Culling Consolidation");

	if (DBG_forcePassCull) { return true; }

	switch (screenState.cullState)
	{
	case CullState::DEPTH_CLIPPED:
		++mStats.depthClipCount;
		return false;
	case CullState::OVERLAP_CLIPPED:
		++mStats.overlapClipped;
		return expiringSymbol;
	case CullState::PATH_CLIPPED:
		++mStats.pathClipped;
		return false;
	case CullState::SCREEN_SPACE_CLIPPED:
		++mStats.screenSpaceClipped;
		return false;
	case CullState::STYLE_INVALID:
		++mStats.styleInvalid;
		return false;
	case CullState::VISIBLE:
		return true;
	default:
		ONYX_THROW("Invalid Symbol cull state given/cull state unknown");
		return false;
	}

	// Fallthrough case
	return false;
}

void SymbolManager::submitRender(bgfx::FrameBufferHandle const colorZBufferHndl, std::vector<IconRenderer::Payload> icons,
	Atlases::SpriteAtlas const& spriteAtlas)
{
	mStats.clear();

	// Setup a top-left ortho matrix for screen space drawing.
	const bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	const bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	bx::mtxLookAt(mView, eye, at);

	constexpr float centering = 0.5f;
	bx::mtxOrtho(mOrtho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);

	bx::mtxIdentity(mWorld);
	bgfx::setTransform(mWorld);

	{
		LUCID_PROFILE_SCOPE("SymbolManager::drawIcons");

		bgfx::ViewId iconId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::touch(iconId);
		bgfx::setViewFrameBuffer(iconId, colorZBufferHndl);
		bgfx::setViewClear(iconId, BGFX_CLEAR_NONE);
		bgfx::setViewName(iconId, "viewport icons");
		bgfx::setViewTransform(iconId, mView, mOrtho);
		bgfx::setViewRect(iconId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		mIconRenderer->draw(iconId, icons, spriteAtlas, mScreenSize);
	}

	{
		LUCID_PROFILE_SCOPE("SymbolManager::drawLabels");

		auto labelId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::setViewFrameBuffer(labelId, colorZBufferHndl);
		bgfx::setViewClear(labelId, BGFX_CLEAR_NONE);
		bgfx::setViewName(labelId, "viewport labels");
		bgfx::setViewTransform(labelId, mView, mOrtho);
		bgfx::setViewRect(labelId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		for (auto const& styleBuffer : mTextBufferHandles)
		{
			auto handle = styleBuffer.second;
			bgfx::setTransform(mWorld);

			mTextBufferManager->submitTextBuffer(handle, labelId);
		}
	}

}

bool SymbolManager::draw(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas, time_float_t currFrameMS)
{
	bool complete = true;
	mNumDrawnSyms = 0;

	if (mFirstDraw)
	{
		mPrevFrameMS = currFrameMS;
		mFirstDraw = false;
	}
	auto deltaMS = currFrameMS - mPrevFrameMS;

	auto const& camera = mViewport->getCameraState();

	static constexpr time_float_t cMaxFadeDuration = 300.0;

	mIconPayloads.clear();
	mCurrentFrameSymbols.clear();

	for (auto iter = frameSymbols.rbegin(); iter != frameSymbols.rend(); ++iter)
	{
		LUCID_PROFILE_SCOPE("Processing Symbols");

		if ((int)mCurrentFrameSymbols.size() >= DBG_maxSymbolsDrawn) { break; }

		auto const& symbol = *iter;
		auto const& key = symbol->getKey();

		bool willDrawIcon = false, willDrawLabel = false;

		auto screenState = genScreenState(screenSpaceManager, *symbol, camera, heightAtlas);
		if (passesCull(screenState))
		{
			ONYX_DEBUG_ASSERT(screenState.cullState == CullState::VISIBLE, "Symbol cull state should be set to visible");
		
			symbol->getScreenState() = screenState;

			auto cachedIter = mSymbolFrameCache.find(key);
			const bool hasCachedSym = (cachedIter != mSymbolFrameCache.end());

			if (symbol->hasLabel())
			{
				// Grab opacity from cache and update before buffering render data
				auto lbl = symbol->getLabel();

				// TODO (Ronald): (ONYX-316) Remove this at end of polishing symbol rendering?
				if (hasCachedSym && !cachedIter->second->hasLabel())
				{
					logWTF("Symbol with label has cached symbol analogue with no label data!");
					continue;
				}

				lbl->setCurrentAlpha(hasCachedSym ? cachedIter->second->getLabel()->getCurrentAlpha() : 0);

				gpu_float_t currentAlpha = lbl->getCurrentAlpha();
				complete &= (currentAlpha >= lbl->getStyle()->opacity);
				
				// Technically on screen, but no opacity == no need to render
				if (currentAlpha > 0)
				{
					bufferLabel(screenState, *symbol, heightAtlas, camera);
				}
				++mStats.labelsRendered;
				willDrawLabel = true;
			}
			if (symbol->hasIcon())
			{
				gpu_float_t currOpacity = hasCachedSym ? cachedIter->second->getIcon().value().currOpacity : 0;
				MapIcon icon = symbol->getIcon().value();
				icon.currOpacity = currOpacity;
				
				// TODO (Ronald): (ONYX-316) Remove this at end of polishing symbol rendering?
				if (hasCachedSym && !cachedIter->second->hasIcon())
				{
					logWTF("Symbol with icon has cached symbol analogue with no icon data!");
					continue;
				}
				
				// Technically on screen, but no opacity == no need to render
				if (icon.currOpacity > 0)
				{
					mIconPayloads.push_back(IconRenderer::genRenderPayload(screenState, icon, spriteAtlas));
				}
				
				willDrawIcon = true;
				complete &= (icon.currOpacity >= icon.style.opacity);
			}
		}

		if (willDrawLabel || willDrawIcon)
		{
			mCurrentFrameSymbols.insert({ key, symbol });
		}
	}

	mNumDrawnSyms = (int)mCurrentFrameSymbols.size();

	// Update expiring symbols + draw expiring symbols that are still visible
	for (auto& [ key, prevCachedSym ] : mSymbolFrameCache)
	{
		LUCID_PROFILE_SCOPE("Update Expiring Symbols");

		// Symbol is not expiring/expired
		if (mCurrentFrameSymbols.find(key) != mCurrentFrameSymbols.end())
		{
			continue;
		}

		bool drawIcon = (prevCachedSym->hasIcon() && prevCachedSym->getIcon().value().currOpacity > 0.f);
		bool drawLabel = (prevCachedSym->hasLabel() && prevCachedSym->getLabel()->getCurrentAlpha() > 0);

		// Symbol is expired. Queue up for frame cache deletion
		if (!drawIcon && !drawLabel)
		{
			mDeleteCache.push_back(key);
			continue;
		}

		auto screenState = genScreenState(screenSpaceManager, *prevCachedSym, camera, heightAtlas, true);
		prevCachedSym->getScreenState() = screenState;

		if (!passesCull(screenState, true))
		{
			mDeleteCache.push_back(key);
			continue;
		}

		if (drawIcon)
		{
			MapIcon icon = prevCachedSym->getIcon().value();

			// Add expiring icon to draw list
			mIconPayloads.push_back(IconRenderer::genRenderPayload(screenState, icon, spriteAtlas));

			// Fade out animation
			icon.currOpacity = updateOpacity(cMaxFadeDuration, deltaMS, icon.style.opacity, icon.currOpacity, false);
			prevCachedSym->setIcon(icon);
			
			complete = false;
		}

		if (drawLabel)
		{
			bufferLabel(screenState, *prevCachedSym, heightAtlas, camera);

			// Fade out animation
			auto label = prevCachedSym->getLabel();
			auto newOpacity = updateOpacity(cMaxFadeDuration, deltaMS, label->getStyle()->opacity, label->getCurrentAlpha(), false);
			label->setCurrentAlpha(newOpacity);
			complete = false;
		}
		
		if (drawIcon || drawLabel) ++mNumDrawnSyms;
	}

	// Fade in recently added current symbols in the cache + add fresh symbols to the cache
	for (auto const& [ key, currentSym ]: mCurrentFrameSymbols)
	{
		LUCID_PROFILE_SCOPE("Update current symbol alphas and add to cache");

		auto cacheIter = mSymbolFrameCache.find(key);
		if (cacheIter == mSymbolFrameCache.end())
		{
			mSymbolFrameCache.insert({ key, currentSym });
			cacheIter = mSymbolFrameCache.find(key);
		}

		// Tick opacity up
		SharedSymbol_t cachedSym = cacheIter->second;
		if (currentSym->hasIcon())
		{
			MapIcon icon = cachedSym->getIcon().value();

			icon.currOpacity = updateOpacity(cMaxFadeDuration, deltaMS, icon.style.opacity, icon.currOpacity, true);
			cachedSym->setIcon(icon);
		}
		if (currentSym->hasLabel())
		{
			auto lbl = cachedSym->getLabel();
			auto newOpacity = updateOpacity(cMaxFadeDuration, deltaMS, lbl->getStyle()->opacity, lbl->getCurrentAlpha(), true);
			lbl->setCurrentAlpha(newOpacity);
		}
	}

	for (auto const& key : mDeleteCache)
	{
		mSymbolFrameCache.erase(key);
	}
	mDeleteCache.clear();

	submitRender(colorZBufferHndl, mIconPayloads, spriteAtlas);

	mPrevFrameMS = currFrameMS;

	return complete;
}

bool SymbolManager::drawOverrideSymbols(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl,
	Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas)
{
	bool complete = true;
	mNumDrawnOverrideSyms = 0;

	mIconPayloads.clear();

	auto const& camera = mViewport->getCameraState();

	for (auto const& symbol : frameSymbols)
	{
		LUCID_PROFILE_SCOPE("Processing Override Symbols");

		auto screenState = genScreenState(screenSpaceManager, *symbol, camera, heightAtlas);
		if (passesCull(screenState))
		{
			if (symbol->hasIcon())
			{
				auto& iconScreenState = symbol->getScreenState();
				iconScreenState = screenState;
				MapIcon icon = symbol->getIcon().value();
				icon.currOpacity = icon.style.opacity;
				mIconPayloads.push_back(IconRenderer::genRenderPayload(iconScreenState, icon, spriteAtlas));
				++mNumDrawnOverrideSyms;
			}
		}
	}

	constexpr bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	constexpr bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	bx::mtxLookAt(mView, eye, at);

	const float centering = 0.5f;
	bx::mtxOrtho(mOrtho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);

	bx::mtxIdentity(mWorld);
	bgfx::setTransform(mWorld);

	{
		LUCID_PROFILE_SCOPE("Draw Override Icons");

		bgfx::ViewId iconId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::touch(iconId);
		bgfx::setViewFrameBuffer(iconId, colorZBufferHndl);
		bgfx::setViewClear(iconId, BGFX_CLEAR_NONE);
		bgfx::setViewName(iconId, "viewport override icons");
		bgfx::setViewTransform(iconId, mView, mOrtho);
		bgfx::setViewRect(iconId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		mIconRenderer->draw(iconId, mIconPayloads, spriteAtlas, mScreenSize);
	}

	return complete;
}

void SymbolManager::calcTextPlacement(ScreenState& screenState, MapSymbol const& symbol, Camera::CameraState const& camera, Atlases::HeightAtlas const* heightAtlas)
{
	LUCID_PROFILE_SCOPE("calcTextPlacement");

	auto symPlacement = symbol.getPlacement();
	auto& label = *symbol.getLabel();
	auto const& style = *label.getStyle();
	auto anchor = style.anchors.front();

	bool notFollowingLine = style.rotAlignment == Styling::Alignment::Viewport || symPlacement == Styling::SymbolPlacement::POINT;
	if (notFollowingLine)
	{
		auto& screenPos = screenState.labelScreenPositionPx;

		auto& screenDir = screenState.labelScreenDirectionPx;
		screenDir.x *= mViewport->getWidthPixel() * 0.5f;
		screenDir.y *= mViewport->getHeightPixel() * 0.5f;
		screenDir = lmath::normalize(screenDir);
		if (screenDir.x < 0) screenDir.x *= -1.f;

		label.gatherTextChunks();
		auto& chunks = label.getChunks();

		if (chunks.empty())
		{
			return;
		}

		// Break text apart if it is too long
		auto longestChunk = label.getLongestChunkPx();
		auto fntMgr = Font::M3DFontManager::getFontManager().lock();
		ONYX_ASSERT(fntMgr, "Font Manager is not initialized before use");
		if (longestChunk == 0)
		{
			Styling::TextStyle chunkStyle = style;

			// Gather relevant TextChunk info
			for (auto& chunk : chunks)
			{
				if (chunk.size.x == -1)
				{
					Styling::FontFace chunkFont = style.font;
					if (chunk.fontOverride->font && !chunk.fontOverride->font->empty())
					{
						chunkFont.name = chunk.fontOverride->font->front();
					}
					chunkFont.pixelSize = int32_t((gpu_float_t)chunkFont.pixelSize * chunk.fontOverride->fontScale);

					auto chunkFontHndl = getFontHandle(chunkFont);

					TextBufferHandle chunkTexBufHndl = getStyleBuffer(chunkFont);
					if (chunkTexBufHndl.idx == bgfx::kInvalidHandle)
					{
						screenState.cullState = CullState::STYLE_INVALID;
						return;
					}

					chunkStyle.color = chunk.fontOverride->color ? *chunk.fontOverride->color : style.color;

					setTextRenderStyle(chunkTexBufHndl, { 0 }, { 0 }, chunkStyle, label.getCurrentAlpha());

					mTextBufferManager->setPenPosition(chunkTexBufHndl, lgal::gpu::Vector3{ 0 });

					chunk.size = mTextBufferManager->measureText(chunkTexBufHndl, chunkFontHndl, chunk.strView.data(), chunkStyle.kerningModifier, chunk.strView.data() + chunk.strView.size()).length();
					chunk.fontInfo = fntMgr->getFontInfo(chunkFontHndl);
					longestChunk = std::max(longestChunk, chunk.size.x);
				}
			}

			label.setLongestChunkPx(longestChunk);

			// Calculate how much each chunk should be offset
			// TODO (Ronald): (CSONYX-314) Merge font placement and calculation with the placement code in the Font directory
			gpu_float_t currYOffset = 0.f;
			gpu_float_t maxNewLineOffset = std::numeric_limits<gpu_float_t>::lowest();
			gpu_float_t groupLength = 0.f;
			auto groupBegin = chunks.begin();
			bool prevChunkBrokeLine = false;

			for (auto chunkIter = chunks.begin(); chunkIter != chunks.end(); ++chunkIter)
			{
				auto const& chunk = *chunkIter;

				// Calculate font spacing
				auto const& chunkFontInfo = chunk.fontInfo;
				auto chunkEmWidth = chunkFontInfo.maxAdvanceWidth;
				//maxNewLineOffset = std::max(chunkFontInfo.lineGap + chunkFontInfo.ascender - chunkFontInfo.descender, maxNewLineOffset);
				maxNewLineOffset = std::max((gpu_float_t)chunkFontInfo.pixelSize + chunkStyle.haloWidth, maxNewLineOffset);

				auto wrapLength = longestChunk;
				if (style.maxWidth != 0 && style.maxWidth != Styling::cNoTextWrap)
				{
					wrapLength = std::min(style.maxWidth * chunkEmWidth, longestChunk);
				}

				bool currChunkBrokeLine = groupLength + chunk.size.x > wrapLength || chunk.isLineBreak;
				if (currChunkBrokeLine) // line is full; update the bounding boxes
				{
					if (groupBegin == chunkIter)
					{
						groupLength = chunk.size.x;
					}

					// 
					if (prevChunkBrokeLine)
					{
						auto const& prevChunk = *(chunkIter - 1);
						if (prevChunk.isLineBreak && chunk.strView.begin() == chunk.strView.end() && chunk.isLineBreak)
						{
							prevChunkBrokeLine = false;
							auto& newlineChunk = *chunkIter;
							newlineChunk.offset = prevChunk.offset;
							newlineChunk.offset.x = prevChunk.size.x;
							continue;
						}
					}

					lgal::gpu::Vector2 offset(std::floor((longestChunk - groupLength) * 0.5f), currYOffset);

					// Update each chunk's placement here
					do {
						auto& groupChunk = *groupBegin;

						auto const& groupChunkFontInfo = groupChunk.fontInfo;
						auto groupChunkEmWidth = groupChunkFontInfo.maxAdvanceWidth;
						auto groupChunkSpaceWidth = std::floor(groupChunkEmWidth * 0.5f);

						groupChunk.offset = offset;
						offset.x += groupChunk.size.x;
						offset.x += groupChunkSpaceWidth;
						if (groupBegin == chunkIter)
						{
							++groupBegin;
							break;
						}
					} while (++groupBegin != chunkIter);

					groupLength = 0.f;
					currYOffset += maxNewLineOffset;
					maxNewLineOffset = std::numeric_limits<gpu_float_t>::lowest();
				}

				prevChunkBrokeLine = currChunkBrokeLine;
				auto chunkSpaceWidth = std::floor(chunkEmWidth * 0.5f); // TODO (scott CSONYX-160) Hack, improve this later
				if (groupLength > 0)
				{
					groupLength += chunkSpaceWidth;
				}
				groupLength += chunk.size.x;
			}

			// Some un-updated chunks might still remain, so deal with the rest here
			lgal::gpu::Vector2 offset = lgal::gpu::Vector2(std::floor((longestChunk - groupLength) * 0.5f), currYOffset);

			while (groupBegin != chunks.end())
			{
				auto& groupChunk = *groupBegin;

				auto const& groupChunkFontInfo = groupChunk.fontInfo;
				auto groupChunkEmWidth = groupChunkFontInfo.maxAdvanceWidth;
				auto groupChunkSpaceWidth = std::floor(groupChunkEmWidth * 0.5f);

				groupChunk.offset = offset;
				offset.x += groupChunk.size.x;
				offset.x += groupChunkSpaceWidth;
				++groupBegin;
			}
		}

		lgal::gpu::AABB2d rect{ { 0, 0 }, { longestChunk, 0 } };
		for (auto const& chunk : chunks)
		{
			rect = rect.fit(chunk.offset + chunk.size);
		}

		// TODO (scott CSONYX-161) 
		// Add vertical/heads-up view switching for labels to be in world- or screen-space
		lgal::gpu::Vector2 xDir = screenDir.xy;
		lgal::gpu::Vector2 yDir = { -xDir.y, xDir.x };

		screenState.labelScreenRectPx = rect;
		lgal::gpu::Vector2 textSize = rect.length(),
			offset(0);

		lgal::gpu::Vector2 offsetAxisX{ 1.f, 0 };
		lgal::gpu::Vector2 offsetAxisY{ 0, 1.f };
		if (style.anchorOrient == Styling::TranslateAnchor::MAP)
		{
			auto projectedX = camera.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisX, 0 });
			if (projectedX.length() > 1e-4f) { projectedX.normalize(); }
			auto projectedY = camera.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisY, 0 });
			if (projectedY.length() > 1e-4f) { offsetAxisY.normalize(); }

			// Remove depth offset as depth offset would be nonlinear
			offsetAxisX = projectedX.xy;
			offsetAxisY = projectedY.xy;
		}
		offset += offsetAxisX * style.anchorTranslate.x + offsetAxisY * style.anchorTranslate.y;

		offsetAxisX = { 0 };
		offsetAxisY = { 0 };
		switch (anchor & Styling::Anchor::VERTICAL_FLAGS)
		{
		case Styling::Anchor::BELOW:
			offset -= yDir * (textSize.y * 1.0f);
			if (style.usingRadialOffset) { offsetAxisY.y -= 0.5f; }
			break;
		case Styling::Anchor::ABOVE:
			if (style.usingRadialOffset) { offsetAxisY.y += 0.5f; }
			break;
		case Styling::Anchor::VERTICAL_CENTER:
		default:
			offset -= yDir * (textSize.y * 0.5f);
			break;
		}

		switch (anchor & Styling::Anchor::HORIZONTAL_FLAGS)
		{
		case Styling::Anchor::LEFT:
			if (style.usingRadialOffset) { offsetAxisX.x += 0.5f; }
			break;
		case Styling::Anchor::RIGHT:
			if (style.usingRadialOffset) { offsetAxisX.x -= 0.5f; }
			offset -= xDir * (textSize.x * 1.0f);
			break;
		case Styling::Anchor::HORIZONTAL_CENTER:
		default:
			offset -= xDir * (textSize.x * 0.5f);
			break;
		}

		// Calculate amount to offset text away from anchor
		if (style.usingRadialOffset)
		{
			lgal::gpu::Vector2 radialOffsetDir = { offsetAxisX.x, offsetAxisY.y };
			if (radialOffsetDir.length() > 1e-4f) radialOffsetDir.normalize();
			auto offsetAmount = style.offsetEm.x * style.font.pixelSize;
			offset += offsetAmount * radialOffsetDir;
		}
		else
		{
			offsetAxisX = { 1.f, 0 };
			offsetAxisY = { 0, 1.f };
			offset += (style.offsetEm.x * style.font.pixelSize * offsetAxisX) + (style.offsetEm.y * style.font.pixelSize * offsetAxisY);
		}

		screenPos.xy += offset;

		auto len = screenState.labelScreenRectPx.length();
		auto pt1 = screenState.labelScreenRectPx.min;
		auto pt2 = pt1 + xDir * len.x;
		auto pt3 = pt1 + yDir * len.y;
		auto pt4 = pt2 + yDir * len.y;
		auto labelBB = lgal::gpu::AABB2d{ pt1, pt1 };
		labelBB = labelBB.fit(pt2);
		labelBB = labelBB.fit(pt3);
		labelBB = labelBB.fit(pt4);
		labelBB = labelBB.shift(screenPos.xy);
		labelBB.pushBounds({ style.padding });
		labelBB.pushBounds({ -style.padding });
		screenState.labelScreenRectPx = labelBB;
	}
	else
	{
		// For line-oriented symbols, get AABB for culling
		auto fntMgr = Font::M3DFontManager::getFontManager().lock();
		ONYX_ASSERT(fntMgr, "Font Manager not initialized before use");

		mDummyTextBuffer->setFontManager(fntMgr);
		layoutLineText(screenState, *mDummyTextBuffer, symbol, camera, heightAtlas);
	}

	mDummyTextBuffer->clearTextBuffer();
}

void SymbolManager::layoutLineText(ScreenState& screenState, TextBuffer& textBuf, MapSymbol const& symbol, Camera::CameraState const& camera, Atlases::HeightAtlas const* heightAtlas)
{
	LUCID_PROFILE_SCOPE("layoutLineText");

	auto& label = *symbol.getLabel();
	auto const feature = label.getFeature();
	auto const& text = label.getText();
	auto const& style = *label.getStyle();
	auto anchor = style.anchors.front();
	ONYX_DEBUG_ASSERT(feature != nullptr, "Label feature is nullptr when it should not be");

	auto const& fullTextStr = text.getFullText();
	if (fullTextStr.empty() || Utils::isWhitespace(*fullTextStr.c_str()))
	{
		screenState.cullState = CullState::STYLE_INVALID;
		return;
	}

	std::vector<lgal::gpu::Vector3> screenPath;
	gpu_float_t pathLength = 0;
	bool isScreenSpace = symbol.getSpaceType() == Utils::SpaceTypes::ScreenPx;
	if (isScreenSpace)
	{
		std::vector<lgal::gpu::Vector2> loop = feature->points();
		screenPath.reserve(loop.size());
		for (auto const& pt : loop)
		{
			screenPath.push_back({ pt, 0 });
		}
		screenState.labelScreenRectPx = feature->aabb();
	}
	else
	{
		LUCID_PROFILE_SCOPE("Label geometry transform to screen space");

		auto const& worldGeometry = label.getWorldGeometry();

		screenPath.reserve(worldGeometry.size() + 1);

		lgal::gpu::Vector3 first(0), prev(0);
		for (auto& worldPt : worldGeometry)
		{
			// TODO (scott CSONYX-162) ensure that height sampling is done in prepare tasks so it doesn't need to be done every frame
			lgal::world::Vector3 heightPt = worldPt;
			if (heightAtlas)
			{
				heightPt.z = camera.terrainExaggeration * heightAtlas->heightAt(worldPt.xy);
			}

			lgal::gpu::Vector3 screenPt;
			if (!worldToScreenCoords(screenPt, camera, mScreenSize, heightPt))
			{
				continue;
			}
			screenPt.z = lucid::math::clamp(mNearClip, mFarClip, screenPt.z - DBG_DepthOffset - 0.01f);
			screenState.labelScreenRectPx = screenState.labelScreenRectPx.fit(screenPt.xy);

			if (screenPath.empty())
			{
				first = screenPt;
			}
			else
			{
				pathLength += lmath::len(screenPt.xy - prev.xy);
			}

			prev = screenPt;
			screenPath.push_back(screenPt);

			// TODO (scott CSONYX-163) potentially check to see if there are longer segments still on screen instead of immediately bailing
			//				after one point leaves the clipping area.
			if (screenPath.size() > 2 && isScreenClipped(screenPt, mScreenSize, mNearClip, mFarClip))// If the path leaves the screen, bail.
			{
				break;
			}
			
		}

		if (feature->type() == Vector::Feature::Types::POLYGON) // Close the loop for polygons
		{
			screenPath.push_back(first);
		}
	}

	if (screenPath.size() < 2)
	{
		screenState.cullState = CullState::PATH_CLIPPED;
		return;
	}

	{
		LUCID_PROFILE_SCOPE("laying out line text");
		auto textLength = label.getTextLengthPx();
		auto kerningModifier = style.kerningModifier;

		textBuf.setStyle(style);
		textBuf.setAlpha(label.getCurrentAlpha());
		textBuf.setOutlineWidth(style.haloWidth);
		textBuf.setDropShadowOffset(style.dropShadowOffset.x, style.dropShadowOffset.y);

		auto fontHndl = getFontHandle(style.font);

		// Will adjust line kerning to try and fit the whole line
		if (symbol.getPlacement() == Styling::SymbolPlacement::LINE_JUSTIFY)
		{
			if (textLength == -1.f)
			{
				textBuf.setTextDirection({ 1, 0 }, { 0, 1 });
				textLength = 0.f;
				const bool measureOnly = true;
				for (Styling::Formatted::Segment const& segment : text.getSegments())
				{
					std::string_view const& strView = segment.getText();
					auto rect = textBuf.appendText(fontHndl, strView.data(), 0, strView.data() + strView.size(), measureOnly);
					textLength += rect.max.x - rect.min.x;
				}
				label.setTextLengthPx(textLength);
			}

			if (pathLength > textLength || kerningModifier > 1)
			{
				auto strlen = text.strLength();
				auto space = pathLength - textLength;
				kerningModifier = lmath::clamp(space / gpu_float_t(strlen), 1.f, kerningModifier);
			}
		}

		textBuf.setPenDepth(DBG_DepthOffset);

		// TODO (Ronald): (CSONYX-307) adjust this to account for full Formatted options
		screenState.labelScreenRectPx = textBuf.layoutText(fontHndl, screenPath, text.getFullText().c_str(), kerningModifier, (const char*)0, anchor, style.keepUpright);
	}
}

FontHandle SymbolManager::getFontHandle(Styling::FontFace const& fontFace)
{
	if (!Font::M3DFontManager::hasTtf(fontFace.name))
	{
		return Font::M3DFontManager::getDefaultFont(fontFace.pixelSize, fontFace.fontType);
	}
	if (!Font::M3DFontManager::hasFont(fontFace))
	{
		Font::M3DFontManager::addFontConfig(fontFace, fontFace.name);
	}

	return Font::M3DFontManager::getFont(fontFace);
}

}
