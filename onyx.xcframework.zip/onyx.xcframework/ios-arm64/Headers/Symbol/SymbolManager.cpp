#include "SymbolManager.h"

#include <lucid/math/Constants.h>
#include <lucid/Profiler.h>

#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>
#include <System/OnyxException.h>

#include "Font/FontManager.h"
#include "Utils/MapMath.h"
#include "Viewport/Viewport.h"

namespace onyx::Symbol {

SymbolManager::SymbolManager(Viewport const* viewport)
	: mScreenSize(viewport->size().as<gpu_float_t>())
	, mViewport(viewport)
	, mIconRenderer(new IconRenderer())
{
	auto caps = bgfx::getCaps();

	mHomogenousDepth = caps->homogeneousDepth;

	mNearClip = mHomogenousDepth ? -1.f : 0.f;
	mFarClip = 1.f;
}

void SymbolManager::initialize()
{
	auto fontManager = Font::M3DFontManager::getFontManager();
	ONYX_ASSERT(fontManager != nullptr, "Font manager has not been initialized");
	mTextBufferManager.reset(new TextBufferManager(fontManager));
}

SymbolManager::~SymbolManager()
{
	for (auto& [style, handle] : mStyleBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	mTextBufferManager.reset();
}

void SymbolManager::update()
{
	for (auto& kvp : mStyleBufferHandles)
	{
		mTextBufferManager->clearTextBuffer(kvp.second);
	}
}

void SymbolManager::resetFontManager()
{
	auto fontManager = Font::M3DFontManager::getFontManager();
	ONYX_ASSERT(fontManager != nullptr, "Font manager has not been initialized");

	for (auto& [style, handle] : mStyleBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	mStyleBufferHandles.clear();

	mTextBufferManager.reset(new TextBufferManager(fontManager));
}

TextBufferHandle SymbolManager::getStyleBuffer(Styling::FontFace const& font)
{
	auto found = mStyleBufferHandles.find(font);
	TextBufferHandle handle = { bgfx::kInvalidHandle };
	if (found == mStyleBufferHandles.end())
	{
		auto newHandle = mTextBufferManager->createTextBuffer(FONT_TYPE_DISTANCE_OUTLINE, BufferType::Transient);
		mStyleBufferHandles.emplace(font, newHandle);
		handle = newHandle;
	}
	else
	{
		handle = found->second;
	}
	return handle;
}

bool SymbolManager::bufferLabel(Camera::ScreenSpaceManager& screenSpaceManager, SymbolState& screenState, MapSymbol& symbol, 
	Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& cameraState)
{
	LUCID_PROFILE_SCOPE("SymbolManager::bufferLabel");
	
	auto placement = symbol.getPlacement();
	auto& label = *symbol.getLabel();

	// TODO account for Formatted structs in this function
	auto style = label.getStyle();

	TextBufferHandle handle = getStyleBuffer(style->font);
	if (handle.idx == bgfx::kInvalidHandle)
	{
		screenState.cullState = SymbolCullState::STYLE_INVALID;
		return false;
	}

	auto const& text = label.getText();

	auto font = Font::M3DFontManager::getFont(style->font);
	if (font.idx == bgfx::kInvalidHandle)
	{
		Font::M3DFontManager::addFontConfig(style->font, style->font.name);
		font = Font::M3DFontManager::getFont(style->font);
	}

	mTextBufferManager->setStyle(handle, *style);
	mTextBufferManager->setAlpha(handle, gpu_float_t(label.getCurrentAlpha()) / 255.f);
	mTextBufferManager->setOutlineWidth(handle, 2);
	mTextBufferManager->setDropShadowOffset(handle, 3, 3);

	bool isScreenSpace = label.getSpace() == Utils::SpaceTypes::ScreenPx;
	auto feature = label.getFeature();
	lgal::gpu::AABB2d labelBB = lgal::gpu::AABB2d::nothing();
	auto anchor = style->anchors.front();

	bool textFollowsLine = style->rotAlignment != Styling::Alignment::Viewport && placement != Styling::SymbolPlacement::POINT;
	if (textFollowsLine)
	{
		ONYX_DEBUG_ASSERT(feature != nullptr, "Label feature is nullptr when it should not be");
		//ONYX_DEBUG_ASSERT(feature->type() == Vector::Feature::Types::LINESTRING || feature->type() == Vector::Feature::Types::POLYGON, "Label feature is not a linestring nor polygon");

		std::vector<lgal::gpu::Vector3> screenPath;

		gpu_float_t pathLength = 0;
		
		if (isScreenSpace)
		{
			std::vector<lgal::gpu::Vector2> loop = feature->points();
			screenPath.reserve(loop.size());
			for (auto const& pt : loop)
			{
				screenPath.push_back({ pt, 0 });
			}
			screenState.labelScreenRectPx = feature->aabb();
		}
		else
		{
			LUCID_PROFILE_SCOPE("Label geometry transform to screen space");
			auto const& worldGeometry = label.getWorldGeometry();

			screenPath.reserve(worldGeometry.size() + 1);

			lgal::gpu::Vector3 first(0, 0, 0);
			lgal::gpu::Vector3 prev(0, 0, 0);

			for (auto& worldPt : worldGeometry)
			{
				// TODO (scott) ensure that height sampling is done in prepare tasks so it doesn't need to be done every frame
				lgal::world::Vector3 heightPt = worldPt;
				if (heightAtlas != nullptr)
				{
					heightPt.z = cameraState.terrainExaggeration * heightAtlas->heightAt(worldPt.xy);
				}

				auto projectedPt = cameraState.project(heightPt);
				if (projectedPt.valid)
				{
					auto screenPt = projectedPt.position.as<gpu_float_t>();
					screenPt.x = (screenPt.x * 0.5f + 0.5f) * mScreenSize.x;
					screenPt.y = (screenPt.y * 0.5f + 0.5f) * mScreenSize.y;
					screenPt.z = lucid::math::clamp(mNearClip, mFarClip, screenPt.z - DBG_DepthOffset - 0.01f);
					screenState.labelScreenRectPx = screenState.labelScreenRectPx.fit(screenPt.xy);
					if (screenPath.empty())
					{
						first = screenPt;
					}
					else
					{
						pathLength += lmath::len(screenPt.xy - prev.xy);
					}

					prev = screenPt;
					screenPath.push_back(screenPt);

					// TODO (scott) potentially check to see if there are longer segments still on screen instead of immediately bailing
					//				after one point leaves the clipping area.
					if (screenPath.size() > 2 && isNormalizedClipped(projectedPt.position.as<gpu_float_t>())) // If the path leaves the screen, bail.
					{
						break;
					}
				}
			}

			if (feature->type() == Vector::Feature::Types::POLYGON) // Close the loop for polygons
			{
				screenPath.push_back(first);
			}

			// TODO (scott) make this smarter, or remove it entirely.
			auto sizeThreshold = mScreenSize * 0.05f;

			auto size = screenState.labelScreenRectPx.length();

			if (size.x < sizeThreshold.x && size.y < sizeThreshold.y)
			{
				screenState.cullState = SymbolCullState::SIZE_CLIPPED;
				return false;
			}
		}

		if (screenPath.size() < 2)
		{
			screenState.cullState = SymbolCullState::PATH_CLIPPED;
			return false;
		}

		{
			LUCID_PROFILE_SCOPE("layout text");
			auto textLength = label.getTextLengthPx();
			auto kerningModifier = style->kerningModifier;


			// Will adjust line kerning to try and fit the whole line
			if (placement == Styling::SymbolPlacement::LINE_JUSTIFY)
			{
				if (textLength == -1.f)
				{
					mTextBufferManager->setTextDirection(handle, { 1, 0 }, { 0, 1 });
					textLength = 0.f;
					for (Styling::Formatted::Segment const& segment : text.segments)
					{
						auto rect = mTextBufferManager->measureText(handle, font, segment.text.c_str(), 0);
						textLength += rect.max.x - rect.min.x;
					}
					label.setTextLengthPx(textLength);
				}

				if (pathLength > textLength || kerningModifier > 1)
				{
					auto strlen = text.length();
					auto space = pathLength - textLength;
					kerningModifier = lmath::clamp(space / gpu_float_t(strlen), 1.f, kerningModifier);
				}
			}

			mTextBufferManager->setPenDepth(handle, DBG_DepthOffset);
			// TODO adjust this to account for full format
			labelBB = mTextBufferManager->layoutText(handle, font, screenPath, text.segments.front().text.c_str(), kerningModifier, nullptr, anchor);
			screenState.labelScreenRectPx = labelBB;
			screenSpaceManager.reserveRect(labelBB.as<screen_coord_t>());
		}
	}
	
	// Labels not rotated along line
	else
	{
		LUCID_PROFILE_SCOPE("append text");

		auto xDir = screenState.labelScreenDirectionPx.xy;
		auto yDir = lgal::gpu::Vector2{ -xDir.y, xDir.x };

		mTextBufferManager->setTextDirection(handle, xDir, yDir);
		mTextBufferManager->setPenPosition(handle, { screenState.labelScreenPositionPx.xy, mNearClip + DBG_DepthOffset });
		// TODO adjust this to account for full format
		labelBB = mTextBufferManager->appendText(handle, font, text.segments.front().text.c_str(), style->kerningModifier);
	}

	return true;
}

SymbolState SymbolManager::genScreenState(MapSymbol const& symbol, Camera::CameraState const& cameraState, 
	Atlases::HeightAtlas const* heightAtlas) 
{
	SymbolState screenState;
	auto symPlacement = symbol.getPlacement();

	// LABEL SCREEN STATE
	if (symbol.hasLabel())
	{
		auto& label = *symbol.getLabel();
		auto anchorPoint = label.getAnchorPoint();
		auto style = label.getStyle();
		auto labelSpace = label.getSpace();
		auto textDirection = label.getTextDirection();

		// Calculate label anchor position in screen space
		if (labelSpace == Utils::SpaceTypes::ScreenPx)
		{
			screenState.labelScreenPositionPx = anchorPoint.as<gpu_float_t>();
		}
		else if (labelSpace == Utils::SpaceTypes::Tile)
		{
			// get world position of anchor
			auto tileId = label.getTileId();
			lgal::world::Vector3 pos(tileId.toWorldPos(anchorPoint.xy, Tiles::TileId::Origin::TOP_LEFT), 0);
			if (heightAtlas != nullptr)
			{
				pos.z = heightAtlas->heightAt(pos.xy);
			}

			// get screen position of anchor
			auto projected = cameraState.projectExaggerated(pos);
			screenState.worldPosition = pos;
			screenState.labelScreenPositionPx = projected.position.as<gpu_float_t>();

			// get label screen direction
			pos.xy = tileId.toWorldPos(anchorPoint.xy + textDirection.as<world_float_t>(), Tiles::TileId::Origin::TOP_LEFT);
			projected = cameraState.projectExaggerated(pos);
			
			screenState.labelScreenDirectionPx = { 1, 0, 0 };
			bool rotateToMap = !isRotatedToVp(symPlacement, style->rotAlignment);
			if (rotateToMap)
			{
				// Project and normalize the X and Y axis
				auto projectedX = cameraState.projectDirToScreen(screenState.labelScreenDirectionPx);
				if (projectedX.length() > 1e-4f) { projectedX.normalize(); }

				// Remove depth offset as depth offset would be nonlinear
				screenState.labelScreenDirectionPx.xy = projectedX.xy;
			}
		}
		// World position
		else
		{
			auto pos = anchorPoint;
			if (heightAtlas != nullptr)
			{
				pos.z = heightAtlas->heightAt(pos.xy);
			}

			auto projected = cameraState.projectExaggerated(pos);
			screenState.worldPosition = pos;
			screenState.labelScreenPositionPx = projected.position.as<gpu_float_t>();

			lgal::world::Vector3 dirPos(anchorPoint.xy + textDirection.as<world_float_t>(), anchorPoint.z);
			projected = cameraState.projectExaggerated(dirPos);
		}
		// Convert screen position from normalized screen coordinates to screen pixel coordinates
		if (labelSpace != Utils::SpaceTypes::ScreenPx)
		{
			screenState.labelScreenPositionPx.x = (screenState.labelScreenPositionPx.x * 0.5f + 0.5f) * mScreenSize.x;
			screenState.labelScreenPositionPx.y = (screenState.labelScreenPositionPx.y * 0.5f + 0.5f) * mScreenSize.y;
		}

		// Calculate label x direction in screen space
		screenState.labelScreenDirectionPx = { 1, 0, 0 };

		bool notFollowingLine = style->rotAlignment == Styling::Alignment::Viewport || symPlacement == Styling::SymbolPlacement::POINT;
		if (notFollowingLine && !isRotatedToVp(symPlacement, style->rotAlignment))
		{
			// Project and normalize the X and Y axis
			auto projectedX = cameraState.projectDirToScreen(screenState.labelScreenDirectionPx);
			if (projectedX.length() > 1e-4f) { projectedX.normalize(); }

			// Remove depth offset as depth offset would be nonlinear
			screenState.labelScreenDirectionPx.xy = projectedX.xy;
		}

		// Update label screen state based on text layout results
		genTextBB(symbol, screenState, heightAtlas, cameraState);
	}

	// ICON SCREEN STATE
	if (symbol.hasIcon())
	{
		auto const& icon = symbol.getIcon().value();

		lgal::gpu::Vector3 projected{ -1.f };
		switch (symbol.getSpace())
		{
		case Utils::SpaceTypes::World:
			// Project anchor to screen position
			screenState.worldPosition = icon.pos;
			projected = cameraState.projectExaggerated(icon.pos).position.as<gpu_float_t>();
			projected.x = (0.5f * projected.x + 0.5f) * mScreenSize.x;
			projected.y = (0.5f * projected.y + 0.5f) * mScreenSize.y;
			break;
		case Utils::SpaceTypes::Tile:
		{
			auto tileId = symbol.getTileId();
			screenState.worldPosition = lgal::world::Vector3{ tileId.toWorldPos(icon.pos.xy, Tiles::TileId::Origin::TOP_LEFT), 0 };
			auto& pos = screenState.worldPosition;
			if (heightAtlas)
			{
				pos.z = heightAtlas->heightAt(pos.xy);
			}

			// get screen position of anchor
			auto projData = cameraState.projectExaggerated(pos);
			if (projData.valid)
			{
				projected = projData.position.as<gpu_float_t>();
				projected.x = (0.5f * projected.x + 0.5f) * mScreenSize.x;
				projected.y = (0.5f * projected.y + 0.5f) * mScreenSize.y;
			}
			else
			{
				// (*Hacky) Force fail culling test
				projected = lgal::gpu::Vector3{ -10000.f };
			}
			break;
		}
		case Utils::SpaceTypes::ScreenPx:
			projected = icon.pos.as<gpu_float_t>();
			break;
		default:
			ONYX_THROW("Icon symbol does not support the given SpaceType");
			break;
		}

		// Calculate icon orientation
		bool rotateToVp = isRotatedToVp(symPlacement, icon.style.rotAlignment);
		bool pitchToVp = rotateToVp;
		if (icon.style.pitchAlignment != Styling::Alignment::Auto) {
			pitchToVp = icon.style.pitchAlignment == Styling::Alignment::Viewport ? true : false;
		}
		lgal::gpu::Vector3 iconXAxis{ 1.f, 0, 0 };
		lgal::gpu::Vector3 iconYAxis{ 0, 1.f, 0 };
		if (!rotateToVp && !pitchToVp)
		{
			iconXAxis = cameraState.projectDirToScreen(iconXAxis);
			if (iconXAxis.length() > 1e-6f) iconXAxis.normalize();
			iconYAxis = cameraState.projectDirToScreen(iconYAxis);
			if (iconYAxis.length() > 1e-6f) iconYAxis.normalize();
		}
		else if (!rotateToVp && pitchToVp)
		{
			// Rotate the up and right vector by the angle made between the icon space right vector and the world right vector
			auto projectedX = cameraState.projectDirToScreen(iconXAxis);
			projectedX.z = 0;
			if (projectedX.length() > 1e-6f) projectedX.normalize();
			auto projectedY = lmath::rotateAround(projectedX, lgal::gpu::Vector3{ 0, 0, 1.f }, lmath::constants::half_pi<gpu_float_t>());

			iconXAxis = projectedX;
			iconYAxis = projectedY;
		}
		else if (rotateToVp && !pitchToVp)
		{
			// Rotate the up vector by the angle between the world normal and the camera's negated lookAt vector
			auto invLookAt = -cameraState.lookDir().as<gpu_float_t>();
			auto rad = lmath::acos(lmath::dot(invLookAt, lgal::gpu::Vector3{ 0, 0, 1 }));
			auto projectedY = lmath::rotateAround(iconYAxis, lgal::gpu::Vector3{ 1, 0, 0 }, rad);

			iconYAxis = projectedY;
		}

		{
			// Offset anchor
			lgal::gpu::Vector2 offsetAxisX{ 1.f, 0 };
			lgal::gpu::Vector2 offsetAxisY{ 0, 1.f };
			if (icon.style.anchorOffsetFrame == Styling::TranslateAnchor::MAP)
			{
				// Project and normalize the X and Y axis
				auto projectedX = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisX, 0 });
				if (projectedX.length() > 1e-4f) { projectedX.normalize(); }
				auto projectedY = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisY, 0 });
				if (projectedY.length() > 1e-4f) { projectedY.normalize(); }

				// Remove depth offset as depth offset would be nonlinear
				offsetAxisX = projectedX.xy;
				offsetAxisY = projectedY.xy;
			}

			auto anchorOffset = offsetAxisX * icon.style.anchorOffsetPx.x + offsetAxisY * icon.style.anchorOffsetPx.y;
			projected += lgal::gpu::Vector3{ anchorOffset, 0 };
		}

		lgal::gpu::Vector3 closestToAnchor{ 0 };
		auto adjSizePx = icon.style.sizeMultiple * icon.spriteIdx.sizePx;
		switch (icon.style.anchor & Styling::Anchor::VERTICAL_FLAGS)
		{
		case Styling::Anchor::BELOW:
			closestToAnchor += (adjSizePx.y * iconYAxis);
			break;
		case Styling::Anchor::VERTICAL_CENTER:
			closestToAnchor += (0.5f * adjSizePx.y * iconYAxis);
			break;
		default:
			break;
		}
		switch (icon.style.anchor & Styling::Anchor::HORIZONTAL_FLAGS)
		{
		case Styling::Anchor::RIGHT:
			closestToAnchor += (adjSizePx.x * iconXAxis);
			break;
		case Styling::Anchor::HORIZONTAL_CENTER:
			closestToAnchor += (0.5f * adjSizePx.x * iconXAxis);
			break;
		default:
			break;
		}
		closestToAnchor.z = 0;
		projected -= closestToAnchor;

		// Rotate CW about icon's midpoint
		{
			auto midpoint = 0.5f * adjSizePx.x * iconXAxis + 0.5f * adjSizePx.y * iconYAxis;
			auto rotAxis = lmath::cross(iconXAxis, iconYAxis);
			iconXAxis = lmath::rotateAround(iconXAxis, rotAxis, icon.style.rotRad);
			iconYAxis = lmath::rotateAround(iconYAxis, rotAxis, icon.style.rotRad);
			midpoint -= (0.5f * adjSizePx.x * iconXAxis + 0.5f * adjSizePx.y * iconYAxis);
			midpoint.z = 0;
			projected += midpoint;
		}

		// Remove z axis contribution when doing offset
		iconXAxis.z = 0, iconYAxis.z = 0;
		auto offset = (iconXAxis * icon.style.sizeMultiple * icon.style.offsetPx.x) + 
			(iconYAxis * icon.style.sizeMultiple * icon.style.offsetPx.y);
		projected += lgal::gpu::Vector3{ offset.x, offset.y, 0 };

		screenState.iconScreenXAxis = iconXAxis.xy;
		screenState.iconScreenYAxis = iconYAxis.xy;
		screenState.iconScreenPositionPx = projected;
		screenState.iconSizePx = adjSizePx;

		// TODO (Ronald): This works only with screen pitched AND rotated labels. Need to account for size of label along its screen x and y directions
		// Also needs to deal with labels resizing instead of icons due to the sprite's content area being set
		auto textFitOpts = icon.style.textFitOpts;
		if (textFitOpts != Styling::TextFitOpts::None && symbol.hasLabel())
		{
			auto texBBLen = screenState.labelScreenRectPx.length();
			auto midpoint = screenState.iconScreenPositionPx.xy + (0.5f * screenState.iconSizePx.x * screenState.iconScreenXAxis) + 
				(0.5f * screenState.iconSizePx.y * screenState.iconScreenYAxis);

			auto pos = midpoint - (0.5f * texBBLen.x * screenState.iconScreenXAxis) - 
				(0.5f * texBBLen.y * screenState.iconScreenYAxis);
			pos -= (icon.style.textFitPadding.w * screenState.iconScreenXAxis) + (icon.style.textFitPadding.x * screenState.iconScreenYAxis);
			auto siz = texBBLen + lgal::gpu::Vector2{ icon.style.textFitPadding.y + icon.style.textFitPadding.w,
				icon.style.textFitPadding.x + icon.style.textFitPadding.z };

			if ((textFitOpts & Styling::TextFitOpts::Width) != 0)
			{
				screenState.iconSizePx.x = siz.x;
				screenState.iconScreenPositionPx.x = pos.x;
			}
			if ((textFitOpts & Styling::TextFitOpts::Height) != 0)
			{
				screenState.iconSizePx.y = siz.y;
				screenState.iconScreenPositionPx.y = pos.y;
			}

		}
		
		// Calculate vertices and fit BB to them
		auto pt1 = screenState.iconScreenPositionPx.xy;
		auto pt2 = pt1 + screenState.iconScreenXAxis * screenState.iconSizePx.x;
		auto pt3 = pt1 + screenState.iconScreenYAxis * screenState.iconSizePx.y;
		auto pt4 = pt2 + screenState.iconScreenYAxis * screenState.iconSizePx.y;
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt1);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt2);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt3);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt4);

		auto padding = icon.style.padding;
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.pushBounds({ padding });
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.pushBounds({ -padding });
	}

	return screenState;
}

bool SymbolManager::cull(SymbolState& screenState, Camera::ScreenSpaceManager& screenSpaceManager, MapSymbol const& symbol, Camera::Frustum const& frustum)
{
	if (DBG_forcePassCull)
	{
		screenState.cullState = SymbolCullState::VISIBLE;
		return true;
	}

	// Check for icon visibility
	if (symbol.hasIcon())
	{
		auto const& icon = symbol.getIcon().value();

		if (icon.space != Utils::SpaceTypes::ScreenPx && !frustum.contains(screenState.worldPosition))
		{
			screenState.cullState = SymbolCullState::FRUSTUM_CLIPPED;
			++mStats.frustumClipped;
			return false;
		}

		if (icon.space == Utils::SpaceTypes::ScreenPx && isScreenClipped(screenState.iconScreenPositionPx))
		{
			screenState.cullState = SymbolCullState::SCREEN_SPACE_CLIPPED;
			++mStats.screenSpaceClipped;
			return false;
		}

		// Check if depth clipped
		auto screenPos = screenState.iconScreenPositionPx;
		auto depth = mViewport->depthAtPixel(int(screenPos.x), int(screenPos.y));
		if (depth < screenPos.z)
		{
			screenState.cullState = SymbolCullState::DEPTH_CLIPPED;
			++mStats.depthClipCount;
			return false;
		}
	}

	if (symbol.hasLabel())
	{
		auto& screenPos = screenState.labelScreenPositionPx;

		auto labelSpace = symbol.getLabel()->getSpace();

		if (labelSpace != Utils::SpaceTypes::ScreenPx && !frustum.contains(screenState.worldPosition))
		{
			screenState.cullState = SymbolCullState::FRUSTUM_CLIPPED;
			++mStats.frustumClipped;
			return false;
		}

		if (labelSpace == Utils::SpaceTypes::ScreenPx && isScreenClipped(screenState.labelScreenPositionPx))
		{
			screenState.cullState = SymbolCullState::SCREEN_SPACE_CLIPPED;
			++mStats.screenSpaceClipped;
			return false;
		}

		auto depth = mViewport->depthAtPixel(int(screenPos.x), int(screenPos.y));

		if (depth < screenPos.z)
		{
			++mStats.depthClipCount;
			screenState.cullState = SymbolCullState::DEPTH_CLIPPED;
			return false;
		}
	}

	// Overlap culling
	bool passesIconOverlap = true;
	auto iconBB = lgal::screen::AABB2d::nothing();
	bool passesLabelOverlap = true;
	auto labelBB = lgal::screen::AABB2d::nothing();
	if (symbol.hasIcon())
	{
		auto const& icon = symbol.getIcon().value();
		iconBB = screenState.iconScreenRectPx.as<screen_coord_t>();

		if (!icon.style.allowOverlap)
		{
			// Check if overlapping other symbols
			if (screenSpaceManager.intersects(iconBB) != lmath::Intersections::NONE)
			{
				screenState.cullState = SymbolCullState::OVERLAP_CLIPPED;
				passesIconOverlap = false;
			}
		}
	}
	if (symbol.hasLabel())
	{
		auto const& label = *symbol.getLabel();
		labelBB = screenState.labelScreenRectPx.as<screen_coord_t>();

		if (!label.getForce() && !label.getStyle()->allowOverlap &&
			screenSpaceManager.intersects(labelBB) != lmath::Intersections::NONE)
		{
			screenState.cullState = SymbolCullState::OVERLAP_CLIPPED;
			passesLabelOverlap = false;
		}
	}

	if (passesIconOverlap && passesLabelOverlap)
	{
		if (symbol.hasIcon())
		{
			screenSpaceManager.reserveRect(iconBB);
		}
		if (symbol.hasLabel())
		{
			screenSpaceManager.reserveRect(labelBB);
		}
	}
	else
	{
		++mStats.overlapClipped;
		screenState.cullState = SymbolCullState::OVERLAP_CLIPPED;
		return false;
	}
	
	screenState.cullState = SymbolCullState::VISIBLE;
	return true;
}

void SymbolManager::submitRender(bgfx::FrameBufferHandle const colorZBufferHndl, std::vector<IconRenderer::Payload> icons, 
	Atlases::SpriteAtlas const& spriteAtlas)
{
	mStats.clear();

	// Setup a top-left ortho matrix for screen space drawing.
	const bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	const bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	float view[16];
	bx::mtxLookAt(view, eye, at);

	const float centering = 0.5f;
	float ortho[16];
	bx::mtxOrtho(ortho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);

	float world[16];
	bx::mtxIdentity(world);
	bgfx::setTransform(world);

	{
		LUCID_PROFILE_SCOPE("SymbolManager::drawIcons");

		bgfx::ViewId iconId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::touch(iconId);
		bgfx::setViewFrameBuffer(iconId, colorZBufferHndl);
		bgfx::setViewClear(iconId, BGFX_CLEAR_NONE);
		bgfx::setViewName(iconId, "viewport icons");
		bgfx::setViewTransform(iconId, view, ortho);
		bgfx::setViewRect(iconId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		mIconRenderer->draw(iconId, icons, spriteAtlas, mScreenSize);
	}

	{
		LUCID_PROFILE_SCOPE("SymbolManager::drawLabels");

		auto labelId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::setViewFrameBuffer(labelId, colorZBufferHndl);
		bgfx::setViewClear(labelId, BGFX_CLEAR_NONE);
		bgfx::setViewName(labelId, "viewport labels");
		bgfx::setViewTransform(labelId, view, ortho);
		bgfx::setViewRect(labelId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		for (auto const& styleBuffer : mStyleBufferHandles)
		{
			auto handle = styleBuffer.second;
			bgfx::setTransform(world);

			mTextBufferManager->submitTextBuffer(handle, labelId);
		}
	}

}

bool SymbolManager::draw(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, 
	Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas)
{
	bool complete = true;

	std::vector<IconRenderer::Payload> iconPayloads;
	iconPayloads.reserve(frameSymbols.size());

	auto const& cameraState = mViewport->getCameraState();
	auto frustum = Camera::Frustum(cameraState);

	mCurrentFrameSymbols.clear();
	mCurrentFrameSymbols.reserve(DBG_maxSymbolsDrawn);

	int numSyms = 0;
	for (auto iter = frameSymbols.rbegin(); iter != frameSymbols.rend(); ++iter)
	{
		auto const& symbol = *iter;

		LUCID_PROFILE_SCOPE("Processing Symbols");

		if (numSyms > DBG_maxSymbolsDrawn) break;

		bool willDrawIcon = false, willDrawLabel = false;

		auto screenState = genScreenState(*symbol, cameraState, heightAtlas);
		if (cull(screenState, screenSpaceManager, *symbol, frustum))
		{
			ONYX_DEBUG_ASSERT(screenState.cullState == SymbolCullState::VISIBLE, "Symbol cull state should be set to visible");
			if (symbol->hasLabel())
			{
				if (bufferLabel(screenSpaceManager, screenState, *symbol, heightAtlas, cameraState))
				{
					++mStats.buffered;
					screenState.cullState = SymbolCullState::VISIBLE;
					mCurrentFrameSymbols.insert(symbol);
					willDrawLabel = true;
				}
				else
				{
					++mStats.bufferClipped;
				}
			}
			if (symbol->hasIcon())
			{
				auto& iconScreenState = symbol->getScreenState();
				iconScreenState = screenState;
				MapIcon icon = symbol->getIcon().value();
				iconPayloads.push_back(IconRenderer::genRenderPayload(iconScreenState, icon, spriteAtlas));
				willDrawIcon = true;
			}
		}

		if (willDrawLabel || willDrawIcon) ++numSyms;
	}

	symbolVec_t toDelete;
	// TODO fix label persistence -- mOnscreenSymbols gets a new (often duplicate) symbol each time a prepare task executes
	for (auto const& symbol : mOnscreenSymbols)
	{
		if (symbol->hasLabel())
		{
			auto label = symbol->getLabel();
			auto isCurrent = mCurrentFrameSymbols.find(symbol) != mCurrentFrameSymbols.end();
			if (isCurrent)
			{
				continue;
			}

			bool isVisible = label->updateFade(isCurrent);

			auto alpha = label->getCurrentAlpha();
			complete &= (alpha == 255);

			if (!isVisible)
			{
				toDelete.push_back(symbol);
			}
		}
	}


	for (auto const& symbol : mCurrentFrameSymbols)
	{
		symbol->getLabel()->updateFade(true);

		auto alpha = symbol->getLabel()->getCurrentAlpha();
		complete &= (alpha == 255);

		mOnscreenSymbols.insert(symbol);
	}

	for (auto const& symbol : toDelete)
	{
		mOnscreenSymbols.erase(symbol);
	}

	submitRender(colorZBufferHndl, iconPayloads, spriteAtlas);

	return complete;
}

bool SymbolManager::drawOverrideSymbols(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, 
	Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas)
{
	bool complete = true;

	std::vector<IconRenderer::Payload> iconPayloads;
	iconPayloads.reserve(frameSymbols.size());

	auto const& cameraState = mViewport->getCameraState();
	auto frustum = Camera::Frustum(cameraState);

	for (auto const& symbol : frameSymbols)
	{
		LUCID_PROFILE_SCOPE("Processing Override Symbols");

		auto screenState = genScreenState(*symbol, cameraState, heightAtlas);
		if (cull(screenState, screenSpaceManager, *symbol, frustum))
		{
			if (symbol->hasIcon())
			{
				auto& iconScreenState = symbol->getScreenState();
				iconScreenState = screenState;
				MapIcon icon = symbol->getIcon().value();
				iconPayloads.push_back(IconRenderer::genRenderPayload(iconScreenState, icon, spriteAtlas));
			}
		}
	}

	const bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	const bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	float view[16];
	bx::mtxLookAt(view, eye, at);

	const float centering = 0.5f;
	float ortho[16];
	bx::mtxOrtho(ortho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);

	float world[16];
	bx::mtxIdentity(world);
	bgfx::setTransform(world);

	{
		LUCID_PROFILE_SCOPE("Draw Override Icons");

		bgfx::ViewId iconId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::touch(iconId);
		bgfx::setViewFrameBuffer(iconId, colorZBufferHndl);
		bgfx::setViewClear(iconId, BGFX_CLEAR_NONE);
		bgfx::setViewName(iconId, "viewport override icons");
		bgfx::setViewTransform(iconId, view, ortho);
		bgfx::setViewRect(iconId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		mIconRenderer->draw(iconId, iconPayloads, spriteAtlas, mScreenSize);
	}

	return complete;
}

bool SymbolManager::isRotatedToVp(Styling::SymbolPlacement symPlacement, Styling::Alignment alignment)
{
	if (alignment == Styling::Alignment::Auto)
	{
		return symPlacement == Styling::SymbolPlacement::POINT;
	}
	return (alignment == Styling::Alignment::Viewport);
}

void SymbolManager::genTextBB(MapSymbol const& symbol, SymbolState& screenState,
	Atlases::HeightAtlas const* /*heightAtlas*/, Camera::CameraState const& cameraState)
{
	auto symPlacement = symbol.getPlacement();

	auto& label = *symbol.getLabel();
	auto const& style = *label.getStyle();
	auto const& text = label.getText();
	auto anchor = style.anchors.front();

	TextBufferHandle texBufHndl = getStyleBuffer(style.font);
	// TODO (Ronald): This should probably be handled somewhere else
	if (texBufHndl.idx == bgfx::kInvalidHandle) return;

	auto font = Font::M3DFontManager::getFont(style.font);
	if (font.idx == bgfx::kInvalidHandle)
	{
		Font::M3DFontManager::addFontConfig(style.font, style.font.name);
		font = Font::M3DFontManager::getFont(style.font);
	}

	mTextBufferManager->setStyle(texBufHndl, style);
	// TODO (Ronald): These two should be TextStyle members
	mTextBufferManager->setOutlineWidth(texBufHndl, 2);
	mTextBufferManager->setDropShadowOffset(texBufHndl, 3, 3);

	bool notFollowingLine = style.rotAlignment == Styling::Alignment::Viewport || symPlacement == Styling::SymbolPlacement::POINT;
	if (notFollowingLine)
	{
		auto& screenPos = screenState.labelScreenPositionPx;

		auto& screenDir = screenState.labelScreenDirectionPx;
		screenDir.x *= mViewport->getWidthPixel() * 0.5f;
		screenDir.y *= mViewport->getHeightPixel() * 0.5f;
		screenDir = lmath::normalize(screenDir);

		if (screenDir.x < 0) screenDir.x *= -1.f;

		//lgal::gpu::Vector2 xDir(1, 0);
		// TODO (scott) this transition would look nicer if it were tied to a pitch threshold and timed 
		//				animation instead of lerping based on camera pitch, so that the user couldn't
		//				move the camera to a pitch where the label directionss are semi-transitioned.
		//auto clampedPitch = (lmath::clamp(gpu_float_t(cameraState.pitch), 0.25f, 0.75f) - 0.25f) * 2.f;
		//xDir = lmath::lerp(screenDir.xy, xDir, clampedPitch);
		//lgal::gpu::Vector2 yDir = { -xDir.y, xDir.x };
		lgal::gpu::Vector2 xDir = screenDir.xy;
		lgal::gpu::Vector2 yDir = { -xDir.y, xDir.x };

		// TODO adjust this to account for full format
		mTextBufferManager->setPenPosition(texBufHndl, lgal::gpu::Vector3{ 0 });
		screenState.labelScreenRectPx = mTextBufferManager->measureText(texBufHndl, font, text.segments.front().text.c_str(),
			style.kerningModifier);
		lgal::gpu::Vector2 textSize = screenState.labelScreenRectPx.max - screenState.labelScreenRectPx.min,
			offset(0);

		lgal::gpu::Vector2 offsetAxisX{ 1.f, 0 };
		lgal::gpu::Vector2 offsetAxisY{ 0, 1.f };
		if (style.anchorOrient == Styling::TranslateAnchor::MAP)
		{
			auto projectedX = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisX, 0 });
			if (projectedX.length() > 1e-4f) { projectedX.normalize(); }
			auto projectedY = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisY, 0 });
			if (projectedY.length() > 1e-4f) { offsetAxisY.normalize(); }

			// Remove depth offset as depth offset would be nonlinear
			offsetAxisX = projectedX.xy;
			offsetAxisY = projectedY.xy;
		}
		offset += offsetAxisX * style.anchorTranslate.x + offsetAxisY * style.anchorTranslate.y;

		offsetAxisX = { 0 };
		offsetAxisY = { 0 };
		switch (anchor & Styling::Anchor::VERTICAL_FLAGS)
		{
		case Styling::Anchor::BELOW:
			offset -= yDir * (textSize.y * 1.0f);
			if (style.usingRadialOffset) { offsetAxisY.y -= 0.5f; }
			break;
		case Styling::Anchor::ABOVE:
			if (style.usingRadialOffset) { offsetAxisY.y += 0.5f; }
			break;
		case Styling::Anchor::VERTICAL_CENTER:
		default:
			offset -= yDir * (textSize.y * 0.5f);
			break;
		}

		switch (anchor & Styling::Anchor::HORIZONTAL_FLAGS)
		{
		case Styling::Anchor::LEFT:
			if (style.usingRadialOffset) { offsetAxisX.x += 0.5f; }
			break;
		case Styling::Anchor::RIGHT:
			if (style.usingRadialOffset) { offsetAxisX.x -= 0.5f; }
			offset -= xDir * (textSize.x * 1.0f);
			break;
		case Styling::Anchor::HORIZONTAL_CENTER:
		default:
			offset -= xDir * (textSize.x * 0.5f);
			break;
		}

		// Calculate amount to offset text away from anchor
		if (style.usingRadialOffset)
		{
			lgal::gpu::Vector2 radialOffsetDir = { offsetAxisX.x, offsetAxisY.y };
			if (radialOffsetDir.length() > 1e-4f) radialOffsetDir.normalize();
			auto offsetAmount = style.offsetEm.x * style.font.pixelSize;
			offset += offsetAmount * radialOffsetDir;
		}
		else
		{
			offsetAxisX = { 1.f, 0 };
			offsetAxisY = { 0, 1.f };
			offset += (style.offsetEm.x * style.font.pixelSize * offsetAxisX) + (style.offsetEm.y * style.font.pixelSize * offsetAxisY);
		}

		screenPos.xy += offset;

		auto len = screenState.labelScreenRectPx.length();
		auto pt1 = screenState.labelScreenRectPx.min;
		auto pt2 = pt1 + xDir * len.x;
		auto pt3 = pt1 + yDir * len.y;
		auto pt4 = pt2 + yDir * len.y;
		auto labelBB = lgal::gpu::AABB2d{ pt1, pt1 };
		labelBB = labelBB.fit(pt2);
		labelBB = labelBB.fit(pt3);
		labelBB = labelBB.fit(pt4);
		labelBB.min += screenPos.xy, labelBB.max += screenPos.xy;
		labelBB.pushBounds({ style.padding });
		labelBB.pushBounds({ -style.padding });
		screenState.labelScreenRectPx = labelBB;
	}

	// Label is line-rotated. TODO (Ronald): Add symbol state generation for symbols that follow line curvature
	else
	{
		return;
	}
}

}
