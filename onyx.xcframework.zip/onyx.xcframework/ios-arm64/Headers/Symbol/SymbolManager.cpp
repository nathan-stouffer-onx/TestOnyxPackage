#include "SymbolManager.h"

#include <lucid/math/Constants.h>
#include <lucid/Profiler.h>

#include <Logging/LogManager.h>
#include <Shaders/ShaderManager.h>
#include <System/OnyxException.h>

#include "Font/FontManager.h"
#include "Utils/MapMath.h"
#include "Viewport/Viewport.h"

namespace onyx::Symbol {

SymbolManager::SymbolManager(Viewport const* viewport)
	: mScreenSize(viewport->size().as<gpu_float_t>())
	, mViewport(viewport)
	, mDummyTextBuffer(nullptr)
	, mIconRenderer(new IconRenderer())
{
	auto caps = bgfx::getCaps();

	mHomogenousDepth = caps->homogeneousDepth;

	mNearClip = mHomogenousDepth ? -1.f : 0.f;
	mFarClip = 1.f;
}

void SymbolManager::initialize()
{
	auto bgfxFontManager = Font::M3DFontManager::getFontManager();
	ONYX_ASSERT(!bgfxFontManager.expired(), "Font manager has not been initialized");
	mTextBufferManager.reset(new TextBufferManager(bgfxFontManager));
	mDummyTextBuffer = std::make_unique<TextBuffer>(bgfxFontManager);
}

SymbolManager::~SymbolManager()
{
	for (auto& [style, handle] : mTextBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	mTextBufferManager.reset();
}

void SymbolManager::update()
{
	for (auto& kvp : mTextBufferHandles)
	{
		mTextBufferManager->clearTextBuffer(kvp.second);
	}
}

void SymbolManager::resetFontManager()
{
	auto bgfxFontManager = Font::M3DFontManager::getFontManager();
	ONYX_ASSERT(!bgfxFontManager.expired(), "Font manager has not been initialized");

	for (auto& [style, handle] : mTextBufferHandles)
	{
		mTextBufferManager->destroyTextBuffer(handle);
	}

	mTextBufferHandles.clear();

	mTextBufferManager.reset(new TextBufferManager(bgfxFontManager));
}

TextBufferHandle SymbolManager::getStyleBuffer(Styling::FontFace const& font)
{
	auto found = mTextBufferHandles.find(font);
	TextBufferHandle handle = { bgfx::kInvalidHandle };
	if (found == mTextBufferHandles.end())
	{
		// TODO (Ronald): make font type obey the stylesheet
		auto newHandle = mTextBufferManager->createTextBuffer(Styling::TextFontTypes::DistanceOutline, TextBuffer::Type::Transient);
		mTextBufferHandles.emplace(font, newHandle);
		handle = newHandle;
	}
	else
	{
		handle = found->second;
	}
	return handle;
}

void SymbolManager::setTextRenderStyle(TextBufferHandle const hndl, lgal::gpu::Vector2 const& xDir, lgal::gpu::Vector2 const& yDir, Styling::TextStyle const& style)
{
	mTextBufferManager->setTextDirection(hndl, xDir, yDir);
	mTextBufferManager->setStyle(hndl, style);
	mTextBufferManager->setOutlineWidth(hndl, style.haloWidth);
	mTextBufferManager->setDropShadowOffset(hndl, style.dropShadowOffset.x, style.dropShadowOffset.y);
}

bool SymbolManager::bufferLabel(SymbolState& screenState, MapSymbol& symbol, Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& cameraState)
{
	// TODO account for Formatted structs in bufferLabel for line-oriented labels
	LUCID_PROFILE_SCOPE("SymbolManager::bufferLabel");

	auto placement = symbol.getPlacement();
	auto& label = *symbol.getLabel();
	auto& style = *label.getStyle();

	TextBufferHandle mainTBH = getStyleBuffer(style.font);
	if (mainTBH.idx == bgfx::kInvalidHandle)
	{
		++mStats.bufferClipped;
		screenState.cullState = SymbolCullState::STYLE_INVALID;
		return false;
	}

	mTextBufferManager->setStyle(mainTBH, style);
	mTextBufferManager->setAlpha(mainTBH, gpu_float_t(label.getCurrentAlpha()) / 255.f);
	mTextBufferManager->setOutlineWidth(mainTBH, style.haloWidth);
	mTextBufferManager->setDropShadowOffset(mainTBH, style.dropShadowOffset.x, style.dropShadowOffset.y);

	auto feature = label.getFeature();
	lgal::gpu::AABB2d labelBB = lgal::gpu::AABB2d::nothing();

	bool textFollowsLine = style.rotAlignment != Styling::Alignment::Viewport && placement != Styling::SymbolPlacement::POINT;
	if (textFollowsLine)
	{
		auto& texBuf = mTextBufferManager->getTextBuffer(mainTBH);
		layoutLineText(symbol, screenState, texBuf, cameraState, heightAtlas);
	}

	// Labels not laid out along screen or world path
	else
	{
		LUCID_PROFILE_SCOPE("labels NOT along lines");

		auto xDir = screenState.labelScreenDirectionPx.xy;
		auto yDir = lgal::gpu::Vector2{ -xDir.y, xDir.x };

		auto chunkStyle = style;
		for (auto const& chunk : label.getChunks())
		{
			auto chunkFont = style.font;
			if (chunk.fontOverride->font && !chunk.fontOverride->font->empty())
			{
				chunkFont.name = chunk.fontOverride->font->front();
			}
			chunkFont.pixelSize = (int32_t)((gpu_float_t)chunkFont.pixelSize * chunk.fontOverride->fontScale);

			TextBufferHandle chunkTexBufHndl = getStyleBuffer(chunkFont);
			if (chunkTexBufHndl.idx == bgfx::kInvalidHandle)
			{
				++mStats.bufferClipped;
				return false;
			}

			chunkStyle.color = chunk.fontOverride->color ? *chunk.fontOverride->color : style.color;

			auto chunkFontHndl = getFontHandle(chunkFont);

			setTextRenderStyle(chunkTexBufHndl, xDir, yDir, chunkStyle);

			mTextBufferManager->setPenPosition(chunkTexBufHndl, { screenState.labelScreenPositionPx.xy + chunk.offset, mNearClip + DBG_DepthOffset });
			mTextBufferManager->setPixelSize(chunkTexBufHndl, chunkFontHndl);
			labelBB = mTextBufferManager->appendText(chunkTexBufHndl, chunkFontHndl, chunk.begin, style.kerningModifier, chunk.end);
		}
	}

	return true;
}

SymbolState SymbolManager::genScreenState(MapSymbol const& symbol, Camera::CameraState const& cameraState,
	Atlases::HeightAtlas const* heightAtlas)
{
	LUCID_PROFILE_SCOPE("genScreenState");

	SymbolState screenState;
	auto symPlacement = symbol.getPlacement();

	// LABEL SCREEN STATE
	if (symbol.hasLabel())
	{
		LUCID_PROFILE_SCOPE("genScreenState - label");

		auto& label = *symbol.getLabel();
		auto anchorPoint = label.getAnchorPoint();
		auto style = label.getStyle();
		auto labelSpace = label.getSpace();
		auto textDirection = label.getTextDirection();

		// Calculate label anchor position in screen space
		if (labelSpace == Utils::SpaceTypes::ScreenPx)
		{
			screenState.labelScreenPositionPx = anchorPoint.as<gpu_float_t>();
		}
		else if (labelSpace == Utils::SpaceTypes::Tile)
		{
			// get world position of anchor
			auto tileId = label.getTileId();
			lgal::world::Vector3 pos(tileId.toWorldPos(anchorPoint.xy, Tiles::TileId::Origin::TOP_LEFT), 0);
			if (heightAtlas != nullptr)
			{
				pos.z = heightAtlas->heightAt(pos.xy);
			}

			// get screen position of anchor
			auto projected = cameraState.projectExaggerated(pos);
			screenState.worldPosition = pos;
			screenState.labelScreenPositionPx = projected.position.as<gpu_float_t>();

			// get label screen direction
			pos.xy = tileId.toWorldPos(anchorPoint.xy + textDirection.as<world_float_t>(), Tiles::TileId::Origin::TOP_LEFT);
			projected = cameraState.projectExaggerated(pos);

			screenState.labelScreenDirectionPx = { 1, 0, 0 };
			bool rotateToMap = !isRotatedToVp(symPlacement, style->rotAlignment);
			if (rotateToMap)
			{
				// Project and normalize the X and Y axis
				auto projectedX = cameraState.projectDirToScreen(screenState.labelScreenDirectionPx);
				if (projectedX.length() > 1e-4f) { projectedX.normalize(); }

				// Remove depth offset as depth offset would be nonlinear
				screenState.labelScreenDirectionPx.xy = projectedX.xy;
			}
		}
		// World position
		else
		{
			auto pos = anchorPoint;
			if (heightAtlas != nullptr)
			{
				pos.z = heightAtlas->heightAt(pos.xy);
			}

			auto projected = cameraState.projectExaggerated(pos);
			screenState.worldPosition = pos;
			screenState.labelScreenPositionPx = projected.position.as<gpu_float_t>();

			lgal::world::Vector3 dirPos(anchorPoint.xy + textDirection.as<world_float_t>(), anchorPoint.z);
			projected = cameraState.projectExaggerated(dirPos);
		}
		// Convert screen position from normalized screen coordinates to screen pixel coordinates
		if (labelSpace != Utils::SpaceTypes::ScreenPx)
		{
			screenState.labelScreenPositionPx.x = (screenState.labelScreenPositionPx.x * 0.5f + 0.5f) * mScreenSize.x;
			screenState.labelScreenPositionPx.y = (screenState.labelScreenPositionPx.y * 0.5f + 0.5f) * mScreenSize.y;
		}

		// Calculate label x direction in screen space
		screenState.labelScreenDirectionPx = { 1, 0, 0 };

		bool notFollowingLine = style->rotAlignment == Styling::Alignment::Viewport || symPlacement == Styling::SymbolPlacement::POINT;
		if (notFollowingLine && !isRotatedToVp(symPlacement, style->rotAlignment))
		{
			// Project and normalize the X and Y axis
			auto projectedX = cameraState.projectDirToScreen(screenState.labelScreenDirectionPx);
			if (projectedX.length() > 1e-4f) { projectedX.normalize(); }

			// Remove depth offset as depth offset would be nonlinear
			screenState.labelScreenDirectionPx.xy = projectedX.xy;
		}

		// Update label screen state based on text layout results
		calcTextPlacement(symbol, screenState, cameraState, heightAtlas);
	}

	// ICON SCREEN STATE
	if (symbol.hasIcon())
	{
		LUCID_PROFILE_SCOPE("genScreenState - icon");

		auto const& icon = symbol.getIcon().value();

		lgal::gpu::Vector3 projected{ -1.f };
		switch (icon.space)
		{
		case Utils::SpaceTypes::World:
			// Project anchor to screen position
			screenState.worldPosition = icon.pos;
			projected = cameraState.projectExaggerated(icon.pos).position.as<gpu_float_t>();
			projected.x = (0.5f * projected.x + 0.5f) * mScreenSize.x;
			projected.y = (0.5f * projected.y + 0.5f) * mScreenSize.y;
			break;
		case Utils::SpaceTypes::Tile:
		{
			auto tileId = symbol.getTileId();
			screenState.worldPosition = lgal::world::Vector3{ tileId.toWorldPos(icon.pos.xy, Tiles::TileId::Origin::TOP_LEFT), 0 };
			auto& pos = screenState.worldPosition;
			if (heightAtlas)
			{
				pos.z = heightAtlas->heightAt(pos.xy);
			}

			// get screen position of anchor
			auto projData = cameraState.projectExaggerated(pos);
			if (projData.valid)
			{
				projected = projData.position.as<gpu_float_t>();
				projected.x = (0.5f * projected.x + 0.5f) * mScreenSize.x;
				projected.y = (0.5f * projected.y + 0.5f) * mScreenSize.y;
			}
			else
			{
				// (TODO: Hacky out) Force fail culling test
				projected = lgal::gpu::Vector3{ -10000.f };
			}
			break;
		}
		case Utils::SpaceTypes::ScreenPx:
			projected = icon.pos.as<gpu_float_t>();
			break;
		default:
			ONYX_THROW("Icon symbol does not support the given SpaceType");
			break;
		}

		// Calculate icon orientation
		bool rotateToVp = isRotatedToVp(symPlacement, icon.style.rotAlignment);
		bool pitchToVp = rotateToVp;
		if (icon.style.pitchAlignment != Styling::Alignment::Auto) {
			pitchToVp = icon.style.pitchAlignment == Styling::Alignment::Viewport ? true : false;
		}
		lgal::gpu::Vector3 iconXAxis{ 1.f, 0, 0 };
		lgal::gpu::Vector3 iconYAxis{ 0, 1.f, 0 };
		if (!rotateToVp && !pitchToVp)
		{
			iconXAxis = cameraState.projectDirToScreen(iconXAxis);
			if (iconXAxis.length() > 1e-6f) iconXAxis.normalize();
			iconYAxis = cameraState.projectDirToScreen(iconYAxis);
			if (iconYAxis.length() > 1e-6f) iconYAxis.normalize();
		}
		else if (!rotateToVp && pitchToVp)
		{
			// Rotate the up and right vector by the angle made between the icon space right vector and the world right vector
			auto projectedX = cameraState.projectDirToScreen(iconXAxis);
			projectedX.z = 0;
			if (projectedX.length() > 1e-6f) projectedX.normalize();
			auto projectedY = lmath::rotateAround(projectedX, lgal::gpu::Vector3{ 0, 0, 1.f }, lmath::constants::half_pi<gpu_float_t>());

			iconXAxis = projectedX;
			iconYAxis = projectedY;
		}
		else if (rotateToVp && !pitchToVp)
		{
			// Rotate the up vector by the angle between the world normal and the camera's negated lookAt vector
			auto invLookAt = -cameraState.lookDir().as<gpu_float_t>();
			auto rad = lmath::acos(lmath::dot(invLookAt, lgal::gpu::Vector3{ 0, 0, 1 }));
			auto projectedY = lmath::rotateAround(iconYAxis, lgal::gpu::Vector3{ 1, 0, 0 }, rad);

			iconYAxis = projectedY;
		}

		{
			// Offset anchor
			lgal::gpu::Vector2 offsetAxisX{ 1.f, 0 };
			lgal::gpu::Vector2 offsetAxisY{ 0, 1.f };
			if (icon.style.anchorOffsetFrame == Styling::TranslateAnchor::MAP)
			{
				// Project and normalize the X and Y axis
				auto projectedX = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisX, 0 });
				if (projectedX.length() > 1e-4f) { projectedX.normalize(); }
				auto projectedY = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisY, 0 });
				if (projectedY.length() > 1e-4f) { projectedY.normalize(); }

				// Remove depth offset as depth offset would be nonlinear
				offsetAxisX = projectedX.xy;
				offsetAxisY = projectedY.xy;
			}

			auto anchorOffset = offsetAxisX * icon.style.anchorOffsetPx.x + offsetAxisY * icon.style.anchorOffsetPx.y;
			projected += lgal::gpu::Vector3{ anchorOffset, 0 };
		}

		lgal::gpu::Vector3 closestToAnchor{ 0 };
		auto adjSizePx = icon.style.sizeMultiple * icon.spriteIdx.sizePx;
		adjSizePx.x = std::round(adjSizePx.x);
		adjSizePx.y = std::round(adjSizePx.y);
		switch (icon.style.anchor & Styling::Anchor::VERTICAL_FLAGS)
		{
		case Styling::Anchor::BELOW:
			closestToAnchor += (adjSizePx.y * iconYAxis);
			break;
		case Styling::Anchor::VERTICAL_CENTER:
			closestToAnchor += (0.5f * adjSizePx.y * iconYAxis);
			break;
		default:
			break;
		}
		switch (icon.style.anchor & Styling::Anchor::HORIZONTAL_FLAGS)
		{
		case Styling::Anchor::RIGHT:
			closestToAnchor += (adjSizePx.x * iconXAxis);
			break;
		case Styling::Anchor::HORIZONTAL_CENTER:
			closestToAnchor += (0.5f * adjSizePx.x * iconXAxis);
			break;
		default:
			break;
		}
		closestToAnchor.z = 0;
		projected -= closestToAnchor;

		// Rotate CW about icon's midpoint
		{
			auto midpoint = 0.5f * adjSizePx.x * iconXAxis + 0.5f * adjSizePx.y * iconYAxis;
			auto rotAxis = lmath::cross(iconXAxis, iconYAxis);
			iconXAxis = lmath::rotateAround(iconXAxis, rotAxis, icon.style.rotRad);
			iconYAxis = lmath::rotateAround(iconYAxis, rotAxis, icon.style.rotRad);
			midpoint -= (0.5f * adjSizePx.x * iconXAxis + 0.5f * adjSizePx.y * iconYAxis);
			midpoint.z = 0;
			projected += midpoint;
		}

		// Remove z axis contribution when doing offset
		iconXAxis.z = 0, iconYAxis.z = 0;
		auto offset = (iconXAxis * icon.style.sizeMultiple * icon.style.offsetPx.x) +
			(iconYAxis * icon.style.sizeMultiple * icon.style.offsetPx.y);
		projected += lgal::gpu::Vector3{ offset.x, offset.y, 0 };

		screenState.iconScreenXAxis = iconXAxis.xy;
		screenState.iconScreenYAxis = iconYAxis.xy;
		screenState.iconScreenPositionPx = projected;
		screenState.iconSizePx = adjSizePx;

		// TODO (Ronald): This works only with screen pitched AND rotated labels. Need to account for size of label along its screen x and y directions
		// Also needs to deal with labels resizing instead of icons due to the sprite's content area being set
		auto textFitOpts = icon.style.textFitOpts;
		if (textFitOpts != Styling::TextFitOpts::None && symbol.hasLabel())
		{
			auto texBBLen = screenState.labelScreenRectPx.length();
			auto midpoint = screenState.iconScreenPositionPx.xy + (0.5f * screenState.iconSizePx.x * screenState.iconScreenXAxis) +
				(0.5f * screenState.iconSizePx.y * screenState.iconScreenYAxis);

			auto pos = midpoint - (0.5f * texBBLen.x * screenState.iconScreenXAxis) -
				(0.5f * texBBLen.y * screenState.iconScreenYAxis);
			pos -= (icon.style.textFitPadding.w * screenState.iconScreenXAxis) + (icon.style.textFitPadding.x * screenState.iconScreenYAxis);
			auto siz = texBBLen + lgal::gpu::Vector2{ icon.style.textFitPadding.y + icon.style.textFitPadding.w,
				icon.style.textFitPadding.x + icon.style.textFitPadding.z };

			if ((textFitOpts & Styling::TextFitOpts::Width) != 0)
			{
				screenState.iconSizePx.x = siz.x;
				screenState.iconScreenPositionPx.x = pos.x;
			}
			if ((textFitOpts & Styling::TextFitOpts::Height) != 0)
			{
				screenState.iconSizePx.y = siz.y;
				screenState.iconScreenPositionPx.y = pos.y;
			}

		}

		// Calculate vertices and fit BB to them
		auto pt1 = screenState.iconScreenPositionPx.xy;
		auto pt2 = pt1 + screenState.iconScreenXAxis * screenState.iconSizePx.x;
		auto pt3 = pt1 + screenState.iconScreenYAxis * screenState.iconSizePx.y;
		auto pt4 = pt2 + screenState.iconScreenYAxis * screenState.iconSizePx.y;
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt1);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt2);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt3);
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.fit(pt4);

		auto padding = icon.style.padding;
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.pushBounds({ padding });
		screenState.iconScreenRectPx = screenState.iconScreenRectPx.pushBounds({ -padding });
	}

	return screenState;
}

bool SymbolManager::cull(SymbolState& screenState, Camera::ScreenSpaceManager& screenSpaceManager, MapSymbol const& symbol, Camera::Frustum const& frustum)
{
	if (DBG_forcePassCull)
	{
		screenState.cullState = SymbolCullState::VISIBLE;
		return true;
	}

	// Check for icon visibility
	if (symbol.hasIcon())
	{
		auto const& icon = symbol.getIcon().value();

		if (icon.space != Utils::SpaceTypes::ScreenPx && !frustum.contains(screenState.worldPosition))
		{
			screenState.cullState = SymbolCullState::FRUSTUM_CLIPPED;
			++mStats.frustumClipped;
			return false;
		}

		if (icon.space == Utils::SpaceTypes::ScreenPx && isScreenClipped(screenState.iconScreenPositionPx, mScreenSize, mNearClip, mFarClip))
		{
			screenState.cullState = SymbolCullState::SCREEN_SPACE_CLIPPED;
			++mStats.screenSpaceClipped;
			return false;
		}

		// Check if depth clipped
		auto screenPos = screenState.iconScreenPositionPx;
		auto depth = mViewport->depthAtPixel(screenPos.xy.as<screen_coord_t>());
		if (depth < screenPos.z)
		{
			screenState.cullState = SymbolCullState::DEPTH_CLIPPED;
			++mStats.depthClipCount;
			return false;
		}
	}

	if (symbol.hasLabel())
	{
		auto& screenPos = screenState.labelScreenPositionPx;

		auto labelSpace = symbol.getLabel()->getSpace();

		if (labelSpace != Utils::SpaceTypes::ScreenPx && !frustum.contains(screenState.worldPosition))
		{
			screenState.cullState = SymbolCullState::FRUSTUM_CLIPPED;
			++mStats.frustumClipped;
			return false;
		}

		if (labelSpace == Utils::SpaceTypes::ScreenPx && isScreenClipped(screenState.labelScreenPositionPx, mScreenSize, mNearClip, mFarClip))
		{
			screenState.cullState = SymbolCullState::SCREEN_SPACE_CLIPPED;
			++mStats.screenSpaceClipped;
			return false;
		}

		auto depth = mViewport->depthAtPixel(screenPos.xy.as<screen_coord_t>());

		if (depth < screenPos.z)
		{
			++mStats.depthClipCount;
			screenState.cullState = SymbolCullState::DEPTH_CLIPPED;
			return false;
		}
	}

	// Overlap culling
	bool passesIconOverlap = true;
	auto iconBB = lgal::screen::AABB2d::nothing();
	bool passesLabelOverlap = true;
	auto labelBB = lgal::screen::AABB2d::nothing();
	if (symbol.hasIcon())
	{
		auto const& icon = symbol.getIcon().value();
		iconBB = screenState.iconScreenRectPx.as<screen_coord_t>();

		if (!icon.style.allowOverlap)
		{
			// Check if overlapping other symbols
			if (screenSpaceManager.intersects(iconBB) != lmath::Intersections::NONE)
			{
				screenState.cullState = SymbolCullState::OVERLAP_CLIPPED;
				passesIconOverlap = false;
			}
		}
	}
	if (symbol.hasLabel())
	{
		auto const& label = *symbol.getLabel();
		labelBB = screenState.labelScreenRectPx.as<screen_coord_t>();

		if (!label.getForce() && !label.getStyle()->allowOverlap &&
			screenSpaceManager.intersects(labelBB) != lmath::Intersections::NONE)
		{
			screenState.cullState = SymbolCullState::OVERLAP_CLIPPED;
			passesLabelOverlap = false;
		}
	}

	if (passesIconOverlap && passesLabelOverlap)
	{
		if (symbol.hasIcon())
		{
			screenSpaceManager.reserveRect(iconBB);
		}
		if (symbol.hasLabel())
		{
			screenSpaceManager.reserveRect(labelBB);
		}
	}
	else
	{
		++mStats.overlapClipped;
		screenState.cullState = SymbolCullState::OVERLAP_CLIPPED;
		return false;
	}

	screenState.cullState = SymbolCullState::VISIBLE;
	return true;
}

void SymbolManager::submitRender(bgfx::FrameBufferHandle const colorZBufferHndl, std::vector<IconRenderer::Payload> icons,
	Atlases::SpriteAtlas const& spriteAtlas)
{
	mStats.clear();

	// Setup a top-left ortho matrix for screen space drawing.
	const bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	const bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	float view[16];
	bx::mtxLookAt(view, eye, at);

	const float centering = 0.5f;
	float ortho[16];
	bx::mtxOrtho(ortho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);

	float world[16];
	bx::mtxIdentity(world);
	bgfx::setTransform(world);

	{
		LUCID_PROFILE_SCOPE("SymbolManager::drawIcons");

		bgfx::ViewId iconId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::touch(iconId);
		bgfx::setViewFrameBuffer(iconId, colorZBufferHndl);
		bgfx::setViewClear(iconId, BGFX_CLEAR_NONE);
		bgfx::setViewName(iconId, "viewport icons");
		bgfx::setViewTransform(iconId, view, ortho);
		bgfx::setViewRect(iconId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		mIconRenderer->draw(iconId, icons, spriteAtlas, mScreenSize);
	}

	{
		LUCID_PROFILE_SCOPE("SymbolManager::drawLabels");

		auto labelId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::setViewFrameBuffer(labelId, colorZBufferHndl);
		bgfx::setViewClear(labelId, BGFX_CLEAR_NONE);
		bgfx::setViewName(labelId, "viewport labels");
		bgfx::setViewTransform(labelId, view, ortho);
		bgfx::setViewRect(labelId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		for (auto const& styleBuffer : mTextBufferHandles)
		{
			auto handle = styleBuffer.second;
			bgfx::setTransform(world);

			mTextBufferManager->submitTextBuffer(handle, labelId);
		}
	}

}

bool SymbolManager::draw(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl,
	Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas)
{
	bool complete = true;

	std::vector<IconRenderer::Payload> iconPayloads;
	iconPayloads.reserve(frameSymbols.size());

	auto const& cameraState = mViewport->getCameraState();
	auto frustum = Camera::Frustum(cameraState);

	mCurrentFrameSymbols.clear();
	mCurrentFrameSymbols.reserve(DBG_maxSymbolsDrawn);


	int numSyms = 0;
	for (auto iter = frameSymbols.rbegin(); iter != frameSymbols.rend(); ++iter)
	{
		LUCID_PROFILE_SCOPE("Processing Symbols");

		auto const& symbol = *iter;

		if (numSyms > DBG_maxSymbolsDrawn) break;

		bool willDrawIcon = false, willDrawLabel = false;

		// TODO (Ronald): Combine screen states into one to allow for some early outs
		auto screenState = genScreenState(*symbol, cameraState, heightAtlas);
		if (cull(screenState, screenSpaceManager, *symbol, frustum))
		{
			ONYX_DEBUG_ASSERT(screenState.cullState == SymbolCullState::VISIBLE, "Symbol cull state should be set to visible");
			if (symbol->hasLabel())
			{
				if (bufferLabel(screenState, *symbol, heightAtlas, cameraState))
				{
					++mStats.buffered;
					screenState.cullState = SymbolCullState::VISIBLE;
					mCurrentFrameSymbols.insert(symbol);
					willDrawLabel = true;
				}
				else
				{
					++mStats.bufferClipped;
				}
			}
			if (symbol->hasIcon())
			{
				auto& iconScreenState = symbol->getScreenState();
				iconScreenState = screenState;
				MapIcon icon = symbol->getIcon().value();
				iconPayloads.push_back(IconRenderer::genRenderPayload(iconScreenState, icon, spriteAtlas));
				willDrawIcon = true;
			}
		}

		if (willDrawLabel || willDrawIcon) ++numSyms;
	}

	symbolVec_t toDelete;
	// TODO fix label persistence -- mOnscreenSymbols gets a new (often duplicate) symbol each time a prepare task executes
	for (auto const& symbol : mOnscreenSymbols)
	{
		if (symbol->hasLabel())
		{
			auto label = symbol->getLabel();
			auto isCurrent = mCurrentFrameSymbols.find(symbol) != mCurrentFrameSymbols.end();
			if (isCurrent)
			{
				continue;
			}

			bool isVisible = label->updateFade(isCurrent);

			auto alpha = label->getCurrentAlpha();
			int maxAlpha = int(label->getStyle()->opacity * 255.f);
			complete &= (alpha == maxAlpha);

			if (!isVisible)
			{
				toDelete.push_back(symbol);
			}
		}
	}

	for (auto const& symbol : mCurrentFrameSymbols)
	{
		auto const label = symbol->getLabel();
		label->updateFade(true);

		auto alpha = label->getCurrentAlpha();
		int maxAlpha = int(label->getStyle()->opacity * 255.f);
		complete &= (alpha == maxAlpha);

		mOnscreenSymbols.insert(symbol);
	}

	for (auto const& symbol : toDelete)
	{
		mOnscreenSymbols.erase(symbol);
	}

	submitRender(colorZBufferHndl, iconPayloads, spriteAtlas);

	return complete;
}

bool SymbolManager::drawOverrideSymbols(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl,
	Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas)
{
	bool complete = true;

	std::vector<IconRenderer::Payload> iconPayloads;
	iconPayloads.reserve(frameSymbols.size());

	auto const& cameraState = mViewport->getCameraState();
	auto frustum = Camera::Frustum(cameraState);

	for (auto const& symbol : frameSymbols)
	{
		LUCID_PROFILE_SCOPE("Processing Override Symbols");

		auto screenState = genScreenState(*symbol, cameraState, heightAtlas);
		if (cull(screenState, screenSpaceManager, *symbol, frustum))
		{
			if (symbol->hasIcon())
			{
				auto& iconScreenState = symbol->getScreenState();
				iconScreenState = screenState;
				MapIcon icon = symbol->getIcon().value();
				iconPayloads.push_back(IconRenderer::genRenderPayload(iconScreenState, icon, spriteAtlas));
			}
		}
	}

	const bx::Vec3 at = { 0.0f, 0.0f,  0.0f };
	const bx::Vec3 eye = { 0.0f, 0.0f, -1.0f };

	float view[16];
	bx::mtxLookAt(view, eye, at);

	const float centering = 0.5f;
	float ortho[16];
	bx::mtxOrtho(ortho, centering, mScreenSize.x + centering, mScreenSize.y + centering, centering, -1.0f, 1.0f, 0.0f, mHomogenousDepth);

	float world[16];
	bx::mtxIdentity(world);
	bgfx::setTransform(world);

	{
		LUCID_PROFILE_SCOPE("Draw Override Icons");

		bgfx::ViewId iconId = Rendering::ViewId::next(Rendering::ViewId::Types::MainDraw);
		bgfx::touch(iconId);
		bgfx::setViewFrameBuffer(iconId, colorZBufferHndl);
		bgfx::setViewClear(iconId, BGFX_CLEAR_NONE);
		bgfx::setViewName(iconId, "viewport override icons");
		bgfx::setViewTransform(iconId, view, ortho);
		bgfx::setViewRect(iconId, 0, 0, uint16_t(mScreenSize.x), uint16_t(mScreenSize.y));

		mIconRenderer->draw(iconId, iconPayloads, spriteAtlas, mScreenSize);
	}

	return complete;
}

void SymbolManager::calcTextPlacement(MapSymbol const& symbol, SymbolState& screenState, Camera::CameraState const& cameraState, Atlases::HeightAtlas const* heightAtlas)
{
	LUCID_PROFILE_SCOPE("calcTextPlacement");

	auto symPlacement = symbol.getPlacement();
	auto& label = *symbol.getLabel();
	auto const& style = *label.getStyle();
	auto anchor = style.anchors.front();

	bool notFollowingLine = style.rotAlignment == Styling::Alignment::Viewport || symPlacement == Styling::SymbolPlacement::POINT;
	if (notFollowingLine)
	{
		auto& screenPos = screenState.labelScreenPositionPx;

		auto& screenDir = screenState.labelScreenDirectionPx;
		screenDir.x *= mViewport->getWidthPixel() * 0.5f;
		screenDir.y *= mViewport->getHeightPixel() * 0.5f;
		screenDir = lmath::normalize(screenDir);
		if (screenDir.x < 0) screenDir.x *= -1.f;

		label.gatherTextChunks();
		auto& chunks = label.getChunks();

		if (chunks.empty())
		{
			return;
		}

		// Break text apart if it is too long
		auto longestChunk = label.getLongestChunkPx();
		auto fntMgr = Font::M3DFontManager::getFontManager().lock();
		ONYX_ASSERT(fntMgr, "Font Manager is not initialized before use");
		if (longestChunk == 0)
		{
			auto chunkStyle = style;

			// Gather relevant TextChunk info
			for (auto& chunk : chunks)
			{
				if (chunk.size.x == -1)
				{
					auto chunkFont = style.font;
					if (chunk.fontOverride->font && !chunk.fontOverride->font->empty())
					{
						chunkFont.name = chunk.fontOverride->font->front();
					}
					chunkFont.pixelSize = int32_t((gpu_float_t)chunkFont.pixelSize * chunk.fontOverride->fontScale);

					auto chunkFontHndl = getFontHandle(chunkFont);

					TextBufferHandle chunkTexBufHndl = getStyleBuffer(chunkFont);
					// TODO (Ronald): This should be a way to early out the entire screen space calculations
					if (chunkTexBufHndl.idx == bgfx::kInvalidHandle)
					{
						++mStats.bufferClipped;
						return;
					}

					chunkStyle.color = chunk.fontOverride->color ? *chunk.fontOverride->color : style.color;

					setTextRenderStyle(chunkTexBufHndl, { 0 }, { 0 }, chunkStyle);

					mTextBufferManager->setPenPosition(chunkTexBufHndl, lgal::gpu::Vector3{ 0 });

					chunk.size = mTextBufferManager->measureText(chunkTexBufHndl, chunkFontHndl, chunk.begin, chunkStyle.kerningModifier, chunk.end).length();
					chunk.fontInfo = fntMgr->getFontInfo(chunkFontHndl);
					longestChunk = std::max(longestChunk, chunk.size.x);
				}
			}

			label.setLongestChunkPx(longestChunk);

			// Calculate how much each chunk should be offset
			// TODO (Ronald): Cache all this font stuff into an array so we don't do all this duplicate work
			gpu_float_t currYOffset = 0.f;
			gpu_float_t maxNewLineOffset = std::numeric_limits<gpu_float_t>::lowest();
			gpu_float_t groupLength = 0.f;
			auto groupBegin = chunks.begin();
			bool prevChunkBrokeLine = false;

			for (auto chunkIter = chunks.begin(); chunkIter != chunks.end(); ++chunkIter)
			{
				auto const& chunk = *chunkIter;

				// Calculate font spacing
				auto const& chunkFontInfo = chunk.fontInfo;
				auto chunkEmWidth = chunkFontInfo.maxAdvanceWidth;
				//maxNewLineOffset = std::max(chunkFontInfo.lineGap + chunkFontInfo.ascender - chunkFontInfo.descender, maxNewLineOffset);
				maxNewLineOffset = std::max((gpu_float_t)chunkFontInfo.pixelSize + chunkStyle.haloWidth, maxNewLineOffset);

				auto wrapLength = longestChunk;
				if (style.maxWidth != 0 && style.maxWidth != Styling::cNoTextWrap)
				{
					wrapLength = std::min(style.maxWidth * chunkEmWidth, longestChunk);
				}

				bool currChunkBrokeLine = groupLength + chunk.size.x > wrapLength || chunk.isLineBreak;
				if (currChunkBrokeLine) // line is full; update the bounding boxes
				{
					if (groupBegin == chunkIter)
					{
						groupLength = chunk.size.x;
					}

					// 
					if (prevChunkBrokeLine)
					{
						auto const& prevChunk = *(chunkIter - 1);
						if (prevChunk.isLineBreak && chunk.begin == chunk.end && chunk.isLineBreak)
						{
							prevChunkBrokeLine = false;
							auto& newlineChunk = *chunkIter;
							newlineChunk.offset = prevChunk.offset;
							newlineChunk.offset.x = prevChunk.size.x;
							continue;
						}
					}

					lgal::gpu::Vector2 offset(std::floor((longestChunk - groupLength) * 0.5f), currYOffset);

					// Update each chunk's placement here
					do {
						auto& groupChunk = *groupBegin;

						auto const& groupChunkFontInfo = groupChunk.fontInfo;
						auto groupChunkEmWidth = groupChunkFontInfo.maxAdvanceWidth;
						auto groupChunkSpaceWidth = std::floor(groupChunkEmWidth * 0.5f);

						groupChunk.offset = offset;
						offset.x += groupChunk.size.x;
						offset.x += groupChunkSpaceWidth;
						if (groupBegin == chunkIter)
						{
							++groupBegin;
							break;
						}
					} while (++groupBegin != chunkIter);

					groupLength = 0.f;
					currYOffset += maxNewLineOffset;
					maxNewLineOffset = std::numeric_limits<gpu_float_t>::lowest();
				}

				prevChunkBrokeLine = currChunkBrokeLine;
				auto chunkSpaceWidth = std::floor(chunkEmWidth * 0.5f); // TODO (scott CSONYX-160) Hack, improve this later
				if (groupLength > 0)
				{
					groupLength += chunkSpaceWidth;
				}
				groupLength += chunk.size.x;
			}

			// Some un-updated chunks might still remain, so deal with the rest here
			lgal::gpu::Vector2 offset = lgal::gpu::Vector2(std::floor((longestChunk - groupLength) * 0.5f), currYOffset);

			while (groupBegin != chunks.end())
			{
				auto& groupChunk = *groupBegin;

				auto const& groupChunkFontInfo = groupChunk.fontInfo;
				auto groupChunkEmWidth = groupChunkFontInfo.maxAdvanceWidth;
				auto groupChunkSpaceWidth = std::floor(groupChunkEmWidth * 0.5f);

				groupChunk.offset = offset;
				offset.x += groupChunk.size.x;
				offset.x += groupChunkSpaceWidth;
				++groupBegin;
			}
		}

		lgal::gpu::AABB2d rect{ { 0, 0 }, { longestChunk, 0 } };
		for (auto const& chunk : chunks)
		{
			rect = rect.fit(chunk.offset + chunk.size);
		}

		// TODO (scott CSONYX-161) 
		// Add vertical/heads-up view switching for labels to be in world- or screen-space
		lgal::gpu::Vector2 xDir = screenDir.xy;
		lgal::gpu::Vector2 yDir = { -xDir.y, xDir.x };

		screenState.labelScreenRectPx = rect;
		lgal::gpu::Vector2 textSize = rect.length(),
			offset(0);

		lgal::gpu::Vector2 offsetAxisX{ 1.f, 0 };
		lgal::gpu::Vector2 offsetAxisY{ 0, 1.f };
		if (style.anchorOrient == Styling::TranslateAnchor::MAP)
		{
			auto projectedX = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisX, 0 });
			if (projectedX.length() > 1e-4f) { projectedX.normalize(); }
			auto projectedY = cameraState.projectDirToScreen(lgal::gpu::Vector3{ offsetAxisY, 0 });
			if (projectedY.length() > 1e-4f) { offsetAxisY.normalize(); }

			// Remove depth offset as depth offset would be nonlinear
			offsetAxisX = projectedX.xy;
			offsetAxisY = projectedY.xy;
		}
		offset += offsetAxisX * style.anchorTranslate.x + offsetAxisY * style.anchorTranslate.y;

		offsetAxisX = { 0 };
		offsetAxisY = { 0 };
		switch (anchor & Styling::Anchor::VERTICAL_FLAGS)
		{
		case Styling::Anchor::BELOW:
			offset -= yDir * (textSize.y * 1.0f);
			if (style.usingRadialOffset) { offsetAxisY.y -= 0.5f; }
			break;
		case Styling::Anchor::ABOVE:
			if (style.usingRadialOffset) { offsetAxisY.y += 0.5f; }
			break;
		case Styling::Anchor::VERTICAL_CENTER:
		default:
			offset -= yDir * (textSize.y * 0.5f);
			break;
		}

		switch (anchor & Styling::Anchor::HORIZONTAL_FLAGS)
		{
		case Styling::Anchor::LEFT:
			if (style.usingRadialOffset) { offsetAxisX.x += 0.5f; }
			break;
		case Styling::Anchor::RIGHT:
			if (style.usingRadialOffset) { offsetAxisX.x -= 0.5f; }
			offset -= xDir * (textSize.x * 1.0f);
			break;
		case Styling::Anchor::HORIZONTAL_CENTER:
		default:
			offset -= xDir * (textSize.x * 0.5f);
			break;
		}

		// Calculate amount to offset text away from anchor
		if (style.usingRadialOffset)
		{
			lgal::gpu::Vector2 radialOffsetDir = { offsetAxisX.x, offsetAxisY.y };
			if (radialOffsetDir.length() > 1e-4f) radialOffsetDir.normalize();
			auto offsetAmount = style.offsetEm.x * style.font.pixelSize;
			offset += offsetAmount * radialOffsetDir;
		}
		else
		{
			offsetAxisX = { 1.f, 0 };
			offsetAxisY = { 0, 1.f };
			offset += (style.offsetEm.x * style.font.pixelSize * offsetAxisX) + (style.offsetEm.y * style.font.pixelSize * offsetAxisY);
		}

		screenPos.xy += offset;

		auto len = screenState.labelScreenRectPx.length();
		auto pt1 = screenState.labelScreenRectPx.min;
		auto pt2 = pt1 + xDir * len.x;
		auto pt3 = pt1 + yDir * len.y;
		auto pt4 = pt2 + yDir * len.y;
		auto labelBB = lgal::gpu::AABB2d{ pt1, pt1 };
		labelBB = labelBB.fit(pt2);
		labelBB = labelBB.fit(pt3);
		labelBB = labelBB.fit(pt4);
		labelBB = labelBB.shift(screenPos.xy);
		labelBB.pushBounds({ style.padding });
		labelBB.pushBounds({ -style.padding });
		screenState.labelScreenRectPx = labelBB;
	}
	else
	{
		// For line-oriented symbols, get AABB for culling
		auto fntMgr = Font::M3DFontManager::getFontManager().lock();
		ONYX_ASSERT(fntMgr, "Font Manager not initialized before use");

		mDummyTextBuffer->setFontManager(fntMgr);
		layoutLineText(symbol, screenState, *mDummyTextBuffer, cameraState, heightAtlas);
	}

	mDummyTextBuffer->clearTextBuffer();
}

void SymbolManager::layoutLineText(MapSymbol const& symbol, SymbolState& screenState, TextBuffer& texBuf, Camera::CameraState const& cameraState, Atlases::HeightAtlas const* heightAtlas)
{
	LUCID_PROFILE_SCOPE("layoutLineText");

	auto& label = *symbol.getLabel();
	auto const feature = label.getFeature();
	auto const& text = label.getText();
	auto const& style = *label.getStyle();
	auto anchor = style.anchors.front();
	ONYX_DEBUG_ASSERT(feature != nullptr, "Label feature is nullptr when it should not be");

	// TODO: Currently, we don't support full-formatting for line-oriented symbols. We only use the first segment for this case
	if (text.segments.front().text.empty() || Utils::isWhitespace(text.segments.front().text.c_str()))
	{
		++mStats.bufferClipped;
		screenState.cullState = SymbolCullState::STYLE_INVALID;
		return;
	}

	std::vector<lgal::gpu::Vector3> screenPath;
	gpu_float_t pathLength = 0;
	bool isScreenSpace = label.getSpace() == Utils::SpaceTypes::ScreenPx;
	if (isScreenSpace)
	{
		std::vector<lgal::gpu::Vector2> loop = feature->points();
		screenPath.reserve(loop.size());
		for (auto const& pt : loop)
		{
			screenPath.push_back({ pt, 0 });
		}
		screenState.labelScreenRectPx = feature->aabb();
	}
	else
	{
		LUCID_PROFILE_SCOPE("Label geometry transform to screen space");

		auto const& worldGeometry = label.getWorldGeometry();

		screenPath.reserve(worldGeometry.size() + 1);

		lgal::gpu::Vector3 first(0), prev(0);
		for (auto& worldPt : worldGeometry)
		{
			// TODO (scott CSONYX-162) ensure that height sampling is done in prepare tasks so it doesn't need to be done every frame
			lgal::world::Vector3 heightPt = worldPt;
			if (heightAtlas)
			{
				heightPt.z = cameraState.terrainExaggeration * heightAtlas->heightAt(worldPt.xy);
			}

			auto projectedPt = cameraState.project(heightPt);
			if (projectedPt.valid)
			{
				auto screenPt = projectedPt.position.as<gpu_float_t>();
				screenPt.x = (screenPt.x * 0.5f + 0.5f) * mScreenSize.x;
				screenPt.y = (screenPt.y * 0.5f + 0.5f) * mScreenSize.y;
				screenPt.z = lucid::math::clamp(mNearClip, mFarClip, screenPt.z - DBG_DepthOffset - 0.01f);
				screenState.labelScreenRectPx = screenState.labelScreenRectPx.fit(screenPt.xy);
				if (screenPath.empty())
				{
					first = screenPt;
				}
				else
				{
					pathLength += lmath::len(screenPt.xy - prev.xy);
				}

				prev = screenPt;
				screenPath.push_back(screenPt);

				// TODO (scott CSONYX-163) potentially check to see if there are longer segments still on screen instead of immediately bailing
				//				after one point leaves the clipping area.
				if (screenPath.size() > 2 && isNormalizedClipped(projectedPt.position.as<gpu_float_t>(), mNearClip, mFarClip)) // If the path leaves the screen, bail.
				{
					break;
				}
			}
		}

		if (feature->type() == Vector::Feature::Types::POLYGON) // Close the loop for polygons
		{
			screenPath.push_back(first);
		}
	}

	if (screenPath.size() < 2)
	{
		screenState.cullState = SymbolCullState::PATH_CLIPPED;
		return;
	}

	{
		LUCID_PROFILE_SCOPE("laying out line text");
		auto textLength = label.getTextLengthPx();
		auto kerningModifier = style.kerningModifier;

		texBuf.setStyle(style);
		texBuf.setAlpha(gpu_float_t(label.getCurrentAlpha()) / 255.f);
		texBuf.setOutlineWidth(style.haloWidth);
		texBuf.setDropShadowOffset(style.dropShadowOffset.x, style.dropShadowOffset.y);

		auto fontHndl = getFontHandle(style.font);

		// Will adjust line kerning to try and fit the whole line
		if (symbol.getPlacement() == Styling::SymbolPlacement::LINE_JUSTIFY)
		{
			if (textLength == -1.f)
			{
				texBuf.setTextDirection({ 1, 0 }, { 0, 1 });
				textLength = 0.f;
				const bool measureOnly = true;
				for (Styling::Formatted::Segment const& segment : text.segments)
				{
					auto rect = texBuf.appendText(fontHndl, segment.text.c_str(), 0, (const char*)0, measureOnly);
					textLength += rect.max.x - rect.min.x;
				}
				label.setTextLengthPx(textLength);
			}

			if (pathLength > textLength || kerningModifier > 1)
			{
				auto strlen = text.length();
				auto space = pathLength - textLength;
				kerningModifier = lmath::clamp(space / gpu_float_t(strlen), 1.f, kerningModifier);
			}
		}

		texBuf.setPenDepth(DBG_DepthOffset);

		// TODO adjust this to account for full format
		screenState.labelScreenRectPx = texBuf.layoutText(fontHndl, screenPath, text.segments.front().text.c_str(), kerningModifier, (const char*)0, anchor, style.keepUpright);
	}
}

FontHandle SymbolManager::getFontHandle(Styling::FontFace const& fontFace)
{
	if (!Font::M3DFontManager::hasTtf(fontFace.name))
	{
		return Font::M3DFontManager::getDefaultFont(fontFace.pixelSize, fontFace.fontType);
	}
	if (!Font::M3DFontManager::hasFont(fontFace))
	{
		Font::M3DFontManager::addFontConfig(fontFace, fontFace.name);
	}

	return Font::M3DFontManager::getFont(fontFace);
}

}
