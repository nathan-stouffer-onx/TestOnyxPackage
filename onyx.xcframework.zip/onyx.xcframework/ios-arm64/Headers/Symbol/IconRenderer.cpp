#include "IconRenderer.h"

#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>

#include "Utils/BgfxUtils.h"

namespace onyx::Symbol {

IconRenderer::IconRenderer() : mMesh(std::make_unique<Rendering::NinePatchMesh>()) {}

void IconRenderer::draw(bgfx::ViewId const viewId, 
	std::vector<Payload> const& payloads,
	Atlases::SpriteAtlas const& spriteAtlas, 
	lgal::gpu::Vector2 const& screenSize)
{
	if (!mNinePatchProgram.isValid()) { mNinePatchProgram = Shaders::load(Shaders::Handwritten::cNinePatch, true); }

	if (payloads.empty())
	{
		mNumRenderedIcons = 0;
		return;
	}

	auto instCount = payloads.size();
	using vertT = Rendering::NinePatchInstance;
	auto availableVtx = bgfx::getAvailInstanceDataBuffer(uint32_t(instCount), sizeof(vertT));
	if (availableVtx == 0)
	{
		mNumRenderedIcons = 0;
		return;
	}

	uint32_t usedInstances = 0;

	bgfx::InstanceDataBuffer tvb;

	bgfx::allocInstanceDataBuffer(&tvb, availableVtx, sizeof(vertT));

	auto vert = reinterpret_cast<vertT*>(tvb.data);

	bgfx::TextureHandle texHndl1 = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle texHndl2 = BGFX_INVALID_HANDLE;

	for (auto const& payload : payloads)
	{
		// grab textures
		if (payload.spriteAtlasId.pageId == 0)
		{
			auto newTexHndl = spriteAtlas.getTexHandle(payload.spriteAtlasId.format, payload.spriteAtlasId.pageId);
			texHndl1 = newTexHndl;
		}
		else if (payload.spriteAtlasId.pageId == 1)
		{
			auto newTexHndl = spriteAtlas.getTexHandle(payload.spriteAtlasId.format, payload.spriteAtlasId.pageId);
			texHndl2 = newTexHndl;
		}
		else ONYX_THROW("Using more than two sprite atlas pages");

		*vert = payload.inst;
		++vert;
		if (++usedInstances >= availableVtx)
		{
			break;
		}
	}

	if (!bgfx::isValid(texHndl2))
	{
		texHndl2 = texHndl1;
	}

	ONYX_DEBUG_ASSERT(bgfx::isValid(texHndl1) && bgfx::isValid(texHndl2), "Both sprite textures must be valid");

	mNumRenderedIcons = usedInstances;
	if (usedInstances == 0)
	{
		return;
	}

	auto spritesheetRes = spriteAtlas.getResolution();
	setUniforms(mNinePatchProgram, texHndl1, texHndl2, spritesheetRes, screenSize);

	mMesh->attach();

	bgfx::setInstanceDataBuffer(&tvb, 0, usedInstances);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_PT_TRISTRIP
		| BGFX_STATE_BLEND_ALPHA
		;
	bgfx::setState(state);
	bgfx::submit(viewId, mNinePatchProgram.handle());
}

void IconRenderer::setUniforms(
	Shaders::Program& program,
	bgfx::TextureHandle const spritesHndl1,
	bgfx::TextureHandle const spritesHndl2,
	uint32_t spritesRes,
	lgal::gpu::Vector2 const& screenSize)
{
	lgal::screen::Vector2 res(spritesRes);
	if (bgfx::isValid(spritesHndl1))
		program.set("s_spriteTex1", spritesHndl1, res, false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);
	if (bgfx::isValid(spritesHndl2))
		program.set("s_spriteTex2", spritesHndl2, res, false, BGFX_SAMPLER_UVW_CLAMP | BGFX_SAMPLER_MIN_ANISOTROPIC | BGFX_SAMPLER_MAG_ANISOTROPIC);

	program.set("u_screenRes", lgal::gpu::Vector4(screenSize, 1.f / screenSize.x, 1.f / screenSize.y));
}

}
