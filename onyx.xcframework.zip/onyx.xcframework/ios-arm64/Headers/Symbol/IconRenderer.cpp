#include "IconRenderer.h"

#include "Utils/BgfxUtils.h"

namespace onyx::Symbol {

void IconRenderer::draw(bgfx::ViewId const viewId, 
	std::vector<Payload> const& payloads,
	Atlases::SpriteAtlas const& spriteAtlas, 
	lgal::gpu::Vector2 const& screenSize)
{
	if (payloads.empty())
	{
		mNumRenderedIcons = 0;
		return;
	}

	auto instCount = payloads.size();
	using vertT = Rendering::NinePatchInstance;
	auto availableVtx = bgfx::getAvailInstanceDataBuffer(uint32_t(instCount), sizeof(vertT));
	if (availableVtx == 0)
	{
		mNumRenderedIcons = 0;
		return;
	}

	uint32_t usedInstances = 0;

	bgfx::InstanceDataBuffer tvb;

	bgfx::allocInstanceDataBuffer(&tvb, availableVtx, sizeof(vertT));

	auto vert = reinterpret_cast<vertT*>(tvb.data);

	bgfx::TextureHandle texHndl1 = BGFX_INVALID_HANDLE;
	bgfx::TextureHandle texHndl2 = BGFX_INVALID_HANDLE;

	for (auto const& payload : payloads)
	{
		// grab textures
		if (payload.spriteAtlasId.pageId == 0)
		{
			auto newTexHndl = spriteAtlas.getTexHandle(payload.spriteAtlasId.format, payload.spriteAtlasId.pageId);
			texHndl1 = newTexHndl;
		}
		else if (payload.spriteAtlasId.pageId == 1)
		{
			auto newTexHndl = spriteAtlas.getTexHandle(payload.spriteAtlasId.format, payload.spriteAtlasId.pageId);
			texHndl2 = newTexHndl;
		}
		else ONYX_THROW("Using more than two sprite atlas pages");

		*vert = payload.inst;
		++vert;
		if (++usedInstances >= availableVtx)
		{
			break;
		}
	}

	if (!bgfx::isValid(texHndl2))
	{
		texHndl2 = texHndl1;
	}

	ONYX_DEBUG_ASSERT(bgfx::isValid(texHndl1) && bgfx::isValid(texHndl2), "Both sprite textures must be valid");

	mNumRenderedIcons = usedInstances;
	if (usedInstances == 0)
	{
		return;
	}

	auto shader = ShaderManager::Instance()->getShader(ShaderEnums::ConfigurableShaders::NinePatch, 0);
	auto spritesheetRes = spriteAtlas.getResolution();
	setUniforms(shader, texHndl1, texHndl2, spritesheetRes, screenSize);

	mMesh->attach();

	bgfx::setInstanceDataBuffer(&tvb, 0, usedInstances);

	uint64_t state = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_PT_TRISTRIP
		| BGFX_STATE_BLEND_ALPHA
		;
	bgfx::setState(state);
	bgfx::submit(viewId, shader->mInstancedHandle);
}

void IconRenderer::setUniforms(
	SharedShader_t const shader,
	bgfx::TextureHandle const spritesHndl1,
	bgfx::TextureHandle const spritesHndl2,
	uint32_t spritesRes,
	lgal::gpu::Vector2 const& screenSize)
{
	if (bgfx::isValid(spritesHndl1))
		shader->setParameter("s_spriteTex1", spritesHndl1, spritesRes, spritesRes);
	if (bgfx::isValid(spritesHndl2))
		shader->setParameter("s_spriteTex2", spritesHndl2, spritesRes, spritesRes);

	shader->setParameter("u_screenRes", 
		lgal::gpu::Vector4(screenSize, 1.f / screenSize.x, 1.f / screenSize.y));
}

}
