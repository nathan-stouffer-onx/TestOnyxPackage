#pragma once

#include <string>

#include <lucid/gal/Types.h>
#include <Styling/Layers/Layer.h>
#include <Styling/Layers/Layouts/Layout.h>

namespace onyx::Styling {

    struct SymOpts {
        std::string sourceId = "";
        LayoutBase::Visibility visibility = LayoutBase::Visibility::VISIBLE;
        Layer::zoom_level_t minZoom = 0;
        Layer::zoom_level_t maxZoom = 20;
		SymbolStyle style;
    };

    std::unique_ptr<SymbolLayer> genSymLyr(SymOpts const& options, std::string const& layerId);

}
