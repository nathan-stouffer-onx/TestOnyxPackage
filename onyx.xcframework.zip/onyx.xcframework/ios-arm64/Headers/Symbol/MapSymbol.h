#pragma once

#include <optional>

#include <lucid/gal/Types.h>
#include <Styling/Styles/SymbolStyle.h>
#include <Styling/SpriteIdx.h>

#include "MapLabel.h"
#include "SymbolKey.h"

namespace onyx::Symbol {

enum class CullState {
	UNKNOWN,
	DEPTH_CLIPPED,
	SCREEN_SPACE_CLIPPED,
	OVERLAP_CLIPPED,
	PATH_CLIPPED,
	STYLE_INVALID,
	VISIBLE
};

struct ScreenState {
	CullState cullState = CullState::UNKNOWN;

	lgal::gpu::Vector3 iconScreenPositionPx = { -1, -1, -1 };
	lgal::gpu::Vector2 iconSizePx = { 0, 0 };
	lgal::gpu::Vector2 iconScreenXAxis = { 1.f, 0.f };	// These axes might be good for labels as well
	lgal::gpu::Vector2 iconScreenYAxis = { 0.f, 1.f };
	lgal::gpu::AABB2d iconScreenRectPx = lgal::gpu::AABB2d::nothing();

	lgal::gpu::Vector3 labelScreenPositionPx = { -1, -1, -1 };
	lgal::gpu::Vector3 labelScreenDirectionPx = { -1, -1, -1 };
	lgal::gpu::AABB2d labelScreenRectPx = lgal::gpu::AABB2d::nothing();
};

struct MapIcon {
	// Struct containing sprite texture information for our SpriteAtlas
	Styling::SpriteIndex spriteIdx;
	// Rendering options for icon rendering
	Styling::IconStyle style;
	// Current opacity
	gpu_float_t currOpacity = 0;
};

class MapSymbol
{
public:

	static const Tiles::TileId cNoTileId;

public:

	MapSymbol(MapIcon const& icon, SharedLabel_t label, lgal::world::Vector3 const& anchorPos, Utils::SpaceTypes spaceType, std::string const& layerId, Styling::SymbolPlacement placement, Tiles::TileId const& tileId) :
		mPlacement(placement),
		mSpaceType(spaceType),
		mIcon(icon),
		mLabel(label)
	{
		mKey.layerId = layerId;
		mKey.iconKey = icon.style.image.key;
		mKey.text = label ? label->getText().getFullText() : "";
		mKey.pos = anchorPos;
		mKey.tileId = tileId;
	}

	MapSymbol(MapIcon const& icon, lgal::world::Vector3 const& anchorPos, Utils::SpaceTypes spaceType, std::string const& layerId, Styling::SymbolPlacement placement, Tiles::TileId const& tileId) :
		MapSymbol(icon, nullptr, anchorPos, spaceType, layerId, placement, tileId)
	{}
 
	MapSymbol(SharedLabel_t label, lgal::world::Vector3 const& anchorPos, Utils::SpaceTypes spaceType, std::string const& layerId, Styling::SymbolPlacement placement, Tiles::TileId const& tileId) :
		mPlacement(placement),
		mSpaceType(spaceType),
		mLabel(label)
	{
		mKey.layerId = layerId;
		mKey.iconKey = "";
		mKey.text = label ? label->getText().getFullText() : "";
		mKey.pos = anchorPos;
		mKey.tileId = tileId;
	}

	inline bool hasLabel() const { return mLabel != nullptr; }
	inline SharedLabel_t getLabel() const { return mLabel; }
	inline void setLabel(SharedLabel_t labelPtr)
	{
		ONYX_DEBUG_ASSERT(labelPtr, "a nullptr label should not be added to MapSymbol");
		if (labelPtr != nullptr)
		{
			mLabel = labelPtr;
		}
	}

	inline SymbolKey const& getKey() const { return mKey; }

	inline bool hasIcon() const { return mIcon.has_value(); }
	inline std::optional<MapIcon> getIcon() const { return mIcon; }
	inline void setIcon(MapIcon const& icon) { mIcon = icon; }

	ScreenState& getScreenState() const { return mScreenState; }

	inline size_t dataSize() const
	{
		return hasLabel() ? sizeof(MapSymbol) + mLabel->dataSize() : sizeof(MapSymbol);
	}

	Tiles::TileId getTileId() const { return mKey.tileId; }
	void setTileId(Tiles::TileId const& tileId) { mKey.tileId = tileId; }

	lgal::world::Vector3 getAnchorPos() const { return mKey.pos; }
	void setAnchorPos(lgal::world::Vector3 const& anchorPos) { mKey.pos = anchorPos; }

	void setLayerId(std::string const& layerId) { mKey.layerId = layerId; }

	GET_SET_VALUE(Placement, Styling::SymbolPlacement, Styling::SymbolPlacement::UNSPECIFIED);
	GET_SET_VALUE(Feature, onyx::Vector::SharedFeatureT, nullptr);
	GET_SET_VALUE(SpaceType, Utils::SpaceTypes, Utils::SpaceTypes::Tile);

private:

	mutable ScreenState mScreenState;

	std::optional<MapIcon> mIcon = std::nullopt;
	SharedLabel_t mLabel = nullptr;

	SymbolKey mKey;

};

using SharedSymbol_t = std::shared_ptr<MapSymbol>;

}
