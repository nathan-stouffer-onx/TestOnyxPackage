#pragma once

#include <optional>
#include <lucid/gal/Types.h>
#include <Styling/Styles/IconStyle.h>
#include <Styling/SpriteIdx.h>

#include "Symbol/MapLabel.h"

namespace onyx::Symbol {

// TODO (Ronald): Move SymbolCullState and SymbolState to SymbolManager or separate file
enum class SymbolCullState {
	UNKNOWN,
	DEPTH_CLIPPED,
	FRUSTUM_CLIPPED,
	SCREEN_SPACE_CLIPPED,
	OVERLAP_CLIPPED,
	SIZE_CLIPPED,
	PATH_CLIPPED,
	STYLE_INVALID,
	VISIBLE
};

struct SymbolState {
	SymbolCullState cullState = SymbolCullState::UNKNOWN;
	lgal::world::Vector3 worldPosition = { 0, 0, 0 };
	
	lgal::gpu::Vector3 iconScreenPositionPx = { -1, -1, -1 };
	lgal::gpu::Vector2 iconSizePx = { 0, 0 };
	lgal::gpu::Vector2 iconScreenXAxis = { 1.f, 0.f };	// These axes might be good for labels as well
	lgal::gpu::Vector2 iconScreenYAxis = { 0.f, 1.f };
	lgal::gpu::AABB2d iconScreenRectPx = lgal::gpu::AABB2d::nothing();

	lgal::gpu::Vector3 labelScreenPositionPx = { -1, -1, -1 };
	lgal::gpu::Vector3 labelScreenDirectionPx = { -1, -1, -1 };
	lgal::gpu::AABB2d labelScreenRectPx = lgal::gpu::AABB2d::nothing();
};

struct MapIcon {
	// If space is World, pos contains world-space anchor position. If space is Tile, contains tile-space anchor position, 
	// If space is ScreenPx, contains screen-space anchor position
	Utils::SpaceTypes space = Utils::SpaceTypes::World;
	// Anchor position of icon. Space frame of reference should be decided by MapSymbol
	lgal::world::Vector3 pos = { 0 };
	// Struct containing sprite texture information for our SpriteAtlas
	Styling::SpriteIndex spriteIdx;
	// Rendering options for icon rendering
	Styling::IconStyle style;
};

class MapSymbol
{
public:

	MapSymbol(Styling::SymbolPlacement placement) :
		mPlacement(placement), mIcon(std::nullopt), mLabel(nullptr) {}
	MapSymbol(std::shared_ptr<MapLabel> labelPtr, Styling::SymbolPlacement placement)
		: mPlacement(placement)
	{
		addLabel(labelPtr);
	}
	MapSymbol(MapIcon const& icon, Styling::SymbolPlacement placement) : 
		mPlacement(placement)
	{
		addIcon(icon);
	}

	inline void addIcon(MapIcon const& data) { mIcon = data; }
	inline void addLabel(std::shared_ptr<MapLabel> labelPtr)
	{
		if (labelPtr != nullptr) mLabel = labelPtr;
	}

	inline bool hasLabel() const { return mLabel != nullptr; }
	inline bool hasIcon() const { return mIcon.has_value(); }
	inline std::optional<MapIcon> const& getIcon() const { return mIcon; }

	inline std::shared_ptr<MapLabel> getLabel() const { return mLabel; }

	inline lgal::world::Vector3 getPosition() const
	{
		ONYX_DEBUG_ASSERT(mLabel != nullptr || mIcon.has_value(), "Neither icon nor symbol are defined");
		return (mLabel != nullptr) ? mLabel->getMapPosition() : mIcon->pos;
	}

	// TODO (Ronald): Rename map position to anchor position
	inline void setPosition(lgal::world::Vector3 const& mapPos)
	{
		if (hasIcon())
		{
			mIcon->pos = mapPos;
		}
	}

	size_t dataSize() const
	{
		return hasLabel() ? sizeof(MapSymbol) + mLabel->dataSize() : sizeof(MapSymbol);
	}

	SymbolState& getScreenState() const { return mScreenState; }

	GET_SET_VALUE(Placement, Styling::SymbolPlacement, Styling::SymbolPlacement::UNSPECIFIED);
	GET_SET_VALUE(Space, Utils::SpaceTypes, Utils::SpaceTypes::Tile);
	GET_SET_VALUE(TileId, Tiles::TileId, Tiles::TileId(-1, -1, -1));

private:

	mutable SymbolState mScreenState;

	std::optional<MapIcon> mIcon;
	std::shared_ptr<MapLabel> mLabel = nullptr;
};

using SharedSymbol_t = std::shared_ptr<MapSymbol>;
using SharedLabel_t = std::shared_ptr<MapLabel>;

}
