#include "SymbolUtils.h"


namespace onyx::Symbol {

lgal::gpu::Vector3 tileToScreenCoords(lgal::world::Vector3 const& anchorPos, Camera::CameraState const& camera, lgal::gpu::Vector2 const& screenSize, Tiles::TileId const& tileId, Atlases::HeightAtlas const* heightAtlas)
{
	// get world position of anchor
	lgal::world::Vector3 worldPos(tileId.toWorldPos(anchorPos.xy, Tiles::TileId::Origin::TOP_LEFT), anchorPos.z);
	if (heightAtlas)
	{
		worldPos.z = heightAtlas->heightAt(worldPos.xy);
	}

	// Project to screen space
	lgal::gpu::Vector3 screenCoords{ -1000.f };
	if (!worldToScreenCoords(screenCoords, camera, screenSize, worldPos))
	{
		return lgal::gpu::Vector3{ -1000.f };
	}

	return screenCoords;
}

}