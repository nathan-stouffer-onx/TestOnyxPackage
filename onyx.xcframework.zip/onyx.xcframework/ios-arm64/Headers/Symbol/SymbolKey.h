#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include "Tiles/TileId.h"

namespace onyx::Symbol {

// Used as a unique key for drawn symbols inside a cache.
struct SymbolKey
{
	std::string layerId = "";
	std::string iconKey = "";
	std::string text = "";
	lgal::world::Vector3 pos = { 0 };
	Tiles::TileId tileId = { -1, -1, -1 };	// default represents screen space

	inline bool operator==(SymbolKey const& rhs) const
	{
		return
			tileId == rhs.tileId &&
			pos == rhs.pos &&
			layerId == rhs.layerId &&
			iconKey == rhs.iconKey &&
			text == rhs.text
			;
	}

	inline bool operator!=(SymbolKey const& rhs) const
	{
		return !(*this == rhs);
	}
};

}

namespace std {

template <>
struct hash<onyx::Symbol::SymbolKey>
{
	inline size_t operator()(onyx::Symbol::SymbolKey const& key) const
	{
		hash<string> strHasher;
		hash<onyx::Tiles::TileId> tIdHasher;

		size_t res = 0;
		res += 23 * strHasher(key.layerId);
		res += 23 * strHasher(key.iconKey);
		res += 23 * strHasher(key.text);
		res += 23 * tIdHasher(key.tileId);
		res += 23 * lmath::hashCode(key.pos);

		return res;
	}
};

}
