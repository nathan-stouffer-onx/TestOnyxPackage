#pragma once

#include <Shaders/v2/Program.h>

#include "Atlases/TextureAtlas.h"
#include "Camera/CameraState.h"
#include "Rendering/NinePatchMesh.h"
#include "MapSymbol.h"

/*
* To render an icon, one needs
* 1) 2x patch offsets relative to top-left-origin UV coordinate space
* 2) Coordinate of the top-left corner of the content cell (where the text content will be placed)
* 3) Size of the content cell in pixels
* 4) UV coordinate of the texture being used
* 5) "Boolean" representing orientation state of icon
* 6) CW rotation in radians
*/

namespace onyx::Symbol {

// Draws icons from a set of tiles and layers
class IconRenderer
{
private:

	using InstVert_t = Rendering::VertStructs::InstanceData3;
	using QuadVert_t = Rendering::VertStructs::PosUV;

public:
	struct Payload
	{
		Rendering::NinePatchInstance inst;
		Atlases::AtlasId spriteAtlasId;
	};

	static constexpr size_t cMaxPages = 2;

public:

	IconRenderer();

	inline static Payload genRenderPayload(SymbolState const& screenState, MapIcon const& icon, 
		Atlases::TextureAtlas<std::string> const& atlas)
	{
		Rendering::NinePatchInstance instance{};

		instance.patchOffsets1 = icon.spriteIdx.offsets1;
		instance.patchOffsets2 = icon.spriteIdx.offsets2;

		auto res = gpu_float_t(atlas.getResolution());
		auto roundedUV = res * icon.spriteIdx.uvOffset.xy;
		roundedUV = lgal::gpu::Vector2{ std::round(roundedUV.x), std::round(roundedUV.y) } / res;
		instance.uv = roundedUV;
		instance.uv = icon.spriteIdx.uvOffset.xy;
		
		instance.opacity = icon.style.opacity;
		instance.xAxisYAxis = lgal::gpu::Vector4{ screenState.iconScreenXAxis, screenState.iconScreenYAxis };

		auto padding1 = icon.spriteIdx.content.min.as<gpu_float_t>() - lgal::gpu::Vector2(instance.patchOffsets1.x, instance.patchOffsets2.y);
		auto iconSize = lgal::gpu::Vector2(instance.patchOffsets2.x, instance.patchOffsets2.w);
		auto contentInset = iconSize - icon.spriteIdx.content.max.as<gpu_float_t>();
		auto patchInset = iconSize - lgal::gpu::Vector2(instance.patchOffsets1.w, instance.patchOffsets2.z);
		auto padding2 = contentInset - patchInset;

		instance.screenPosPx = screenState.iconScreenPositionPx.xy - padding1;
		instance.screenSizePx = screenState.iconSizePx + padding1 + padding2;

		auto toRet = Payload{
			instance,
			atlas.getAtlasId(icon.style.image.key)
		};
		toRet.inst.texPageId = gpu_float_t(toRet.spriteAtlasId.pageId);
		return toRet;
	}
	
	void draw(bgfx::ViewId const viewId, 
		std::vector<Payload> const& payloads,
		Atlases::SpriteAtlas const& spriteAtlas, 
		lgal::gpu::Vector2 const& screenSize);
	
	inline uint32_t getNumRenderedIcons() const { return mNumRenderedIcons; }

private:

	std::unique_ptr<Rendering::NinePatchMesh> mMesh;

	Shaders::Program mNinePatchProgram;

	uint32_t mNumRenderedIcons = 0;

private:

	void setUniforms(
		Shaders::Program& program,
		bgfx::TextureHandle const spritesHndl1,
		bgfx::TextureHandle const spritesHndl2,
		uint32_t spritesRes,
		lgal::gpu::Vector2 const& screenSize);

};

}
