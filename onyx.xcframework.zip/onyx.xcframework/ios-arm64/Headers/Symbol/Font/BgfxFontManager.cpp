/*
 * Copyright 2013 Jeremie Roy. All rights reserved.
 * License: https://github.com/bkaradzic/bgfx#license-bsd-2-clause
 */

#include <bx/bx.h>
#include <stb/stb_truetype.h>
#include <bgfx/bgfx.h>
#include <bx/math.h>

BX_PRAGMA_DIAGNOSTIC_PUSH()
BX_PRAGMA_DIAGNOSTIC_IGNORED_MSVC(4244) //  warning C4244: '=': conversion from 'double' to 'float', possible loss of data
BX_PRAGMA_DIAGNOSTIC_IGNORED_MSVC(4701) //  warning C4701: potentially uninitialized local variable 'pt' used
#define SDF_IMPLEMENTATION
#include <sdf/sdf.h>
BX_PRAGMA_DIAGNOSTIC_POP()

#include <wchar.h> // wcslen

#include <tinystl/allocator.h>
#include <tinystl/unordered_map.h>
namespace stl = tinystl;

#include "BgfxFontManager.h"
#include "cube_atlas.h"

class TrueTypeFont
{
public:
	TrueTypeFont();
	~TrueTypeFont();

	/// Initialize from  an external buffer
	/// @remark The ownership of the buffer is external, and you must ensure it stays valid up to this object lifetime
	/// @return true if the initialization succeed
	bool init(const uint8_t* _buffer, uint32_t _bufferSize, int32_t _fontIndex, uint32_t _pixelHeight, int16_t _widthPadding, int16_t _heightPadding);

	/// return the font descriptor of the current font
	FontInfo getFontInfo() const;

	/// raster a glyph as 8bit alpha to a memory buffer
	/// update the GlyphInfo according to the raster strategy
	/// @ remark buffer min size: glyphInfo.m_width * glyphInfo * height * sizeof(char)
	bool bakeGlyphAlpha(CodePoint _codePoint, GlyphInfo& _outGlyphInfo, uint8_t* _outBuffer) const;

	/// raster a glyph as 8bit signed distance to a memory buffer
	/// update the GlyphInfo according to the raster strategy
	/// @ remark buffer min size: glyphInfo.m_width * glyphInfo * height * sizeof(char)
	bool bakeGlyphDistance(CodePoint _codePoint, GlyphInfo& _outGlyphInfo, uint8_t* _outBuffer) const;

private:
	friend class BgfxFontManager;

	stbtt_fontinfo m_font;
	float m_scale;

	int16_t m_widthPadding;
	int16_t m_heightPadding;
};

TrueTypeFont::TrueTypeFont() : m_font()
	, m_widthPadding(6)
	, m_heightPadding(6)
{
}

TrueTypeFont::~TrueTypeFont()
{
}

bool TrueTypeFont::init(const uint8_t* _buffer, uint32_t _bufferSize, int32_t _fontIndex, uint32_t _pixelHeight, int16_t _widthPadding, int16_t _heightPadding)
{
	BX_ASSERT( (_bufferSize > 256 && _bufferSize < 100000000), "TrueType buffer size is suspicious");
	BX_ASSERT( (_pixelHeight > 4 && _pixelHeight < 128), "TrueType buffer size is suspicious");
	BX_UNUSED(_bufferSize);

	int offset = stbtt_GetFontOffsetForIndex(_buffer, _fontIndex);

	stbtt_InitFont(&m_font, _buffer, offset);

	m_scale = stbtt_ScaleForMappingEmToPixels(&m_font, (float)_pixelHeight);

	m_widthPadding = _widthPadding;
	m_heightPadding = _heightPadding;
	return true;
}

FontInfo TrueTypeFont::getFontInfo() const
{
	int ascent;
	int descent;
	int lineGap;
	stbtt_GetFontVMetrics(&m_font, &ascent, &descent, &lineGap);

	float scale = m_scale;

	int x0, y0, x1, y1;
	stbtt_GetFontBoundingBox(&m_font, &x0, &y0, &x1, &y1);

	FontInfo outFontInfo;
	outFontInfo.scale = 1.0f;
	outFontInfo.ascender = bx::round(ascent * scale);
	outFontInfo.descender = bx::round(descent * scale);
	outFontInfo.lineGap = bx::round(lineGap * scale);
	outFontInfo.maxAdvanceWidth = bx::round((y1 - y0) * scale);

	outFontInfo.underlinePosition = (x1 - x0) * scale - ascent;
	outFontInfo.underlineThickness = (x1 - x0) * scale / 24.f;
	return outFontInfo;
}

bool TrueTypeFont::bakeGlyphAlpha(CodePoint _codePoint, GlyphInfo& _glyphInfo, uint8_t* _outBuffer) const
{
	int32_t ascent, descent, lineGap;
	stbtt_GetFontVMetrics(&m_font, &ascent, &descent, &lineGap);

	int32_t advance, lsb;
	stbtt_GetCodepointHMetrics(&m_font, _codePoint, &advance, &lsb);

	const float scale = m_scale;
	int32_t x0, y0, x1, y1;
	stbtt_GetCodepointBitmapBox(&m_font, _codePoint, scale, scale, &x0, &y0, &x1, &y1);

	const int32_t ww = x1-x0;
	const int32_t hh = y1-y0;

	_glyphInfo.offset_x  = (float)x0;
	_glyphInfo.offset_y  = (float)y0;
	_glyphInfo.width     = (float)ww;
	_glyphInfo.height    = (float)hh;
	_glyphInfo.advance_x = bx::round(((float)advance) * scale);
	_glyphInfo.advance_y = bx::round(((float)(ascent + descent + lineGap)) * scale);

	uint32_t bpp = 1;
	uint32_t dstPitch = ww * bpp;

	stbtt_MakeCodepointBitmap(&m_font, _outBuffer, ww, hh, dstPitch, scale, scale, _codePoint);

	return true;
}

bool TrueTypeFont::bakeGlyphDistance(CodePoint _codePoint, GlyphInfo& _glyphInfo, uint8_t* _outBuffer) const
{
	int32_t ascent, descent, lineGap;
	stbtt_GetFontVMetrics(&m_font, &ascent, &descent, &lineGap);

	int32_t advance, lsb;
	stbtt_GetCodepointHMetrics(&m_font, _codePoint, &advance, &lsb);

	float shiftY = 0.0f;
	float shiftX = 0.0f;
	if (bgfx::getRendererType() != bgfx::RendererType::Enum::OpenGL && bgfx::getRendererType() != bgfx::RendererType::Enum::Vulkan)
	{
		shiftY = 0.5f;
	}
	const float scale = m_scale;
	int32_t x0, y0, x1, y1;
	stbtt_GetCodepointBitmapBoxSubpixel(&m_font, _codePoint, scale, scale, shiftX, shiftY, &x0, &y0, &x1, &y1);

	const int32_t ww = x1-x0;
	const int32_t hh = y1-y0;

	_glyphInfo.offset_x  = (float)x0 + shiftX;
	_glyphInfo.offset_y  = (float)y0 + shiftY;
	_glyphInfo.width     = (float)ww;
	_glyphInfo.height    = (float)hh;
	_glyphInfo.advance_x = bx::round(((float)advance) * scale);
	_glyphInfo.advance_y = bx::round(((float)(ascent + descent + lineGap)) * scale);

	uint32_t bpp = 1;
	uint32_t dstPitch = ww * bpp;

	stbtt_MakeCodepointBitmapSubpixel(&m_font, _outBuffer, ww, hh, dstPitch, scale, scale, shiftX, shiftY, _codePoint);

	if (ww * hh > 0)
	{
		uint32_t dw = m_widthPadding;
		uint32_t dh = m_heightPadding;

		uint32_t nw = ww + dw * 2;
		uint32_t nh = hh + dh * 2;
		BX_ASSERT(nw * nh < 128 * 128, "Buffer overflow (size %d)", nw * nh);

		uint32_t buffSize = nw * nh * sizeof(uint8_t);

		uint8_t* alphaImg = (uint8_t*)malloc(buffSize);
		bx::memSet(alphaImg, 0, nw * nh * sizeof(uint8_t) );

		//copy the original buffer to the temp one
		for (uint32_t ii = dh; ii < nh - dh; ++ii)
		{
			bx::memCopy(alphaImg + ii * nw + dw, _outBuffer + (ii - dh) * ww, ww);
		}

		// stb_truetype has some builtin sdf functionality, we can investigate using that too
		sdfBuildDistanceField(_outBuffer, nw, 8.0f, alphaImg, nw, nh, nw);
		free(alphaImg);

		_glyphInfo.offset_x -= (float)dw;
		_glyphInfo.offset_y -= (float)dh;
		_glyphInfo.width = (float)nw;
		_glyphInfo.height = (float)nh;
	}

	return true;
}

typedef stl::unordered_map<CodePoint, GlyphInfo> GlyphHashMap;

// cache font data
struct BgfxFontManager::CachedFont
{
	CachedFont() : trueTypeFont(nullptr)
	{
		masterFontHandle.idx = bx::kInvalidHandle;
	}

	FontInfo fontInfo;
	GlyphHashMap cachedGlyphs;
	TrueTypeFont* trueTypeFont;
	// a handle to a master font in case of sub distance field font
	FontHandle masterFontHandle;
	int16_t padding;
};

constexpr size_t cMaxFontBufSiz = 512 * 512 * 4;

BgfxFontManager::BgfxFontManager(Atlas* _atlas)
	: m_ownAtlas(false)
	, m_atlas(_atlas)
{
	init();
}

BgfxFontManager::BgfxFontManager(uint16_t _textureSideWidth)
	: m_ownAtlas(true)
	, m_atlas(new Atlas(_textureSideWidth) )
{
	init();
}

void BgfxFontManager::init()
{
	m_cachedFiles = new CachedFile[cMaxOpenedFiles];
	m_cachedFonts = new CachedFont[cMaxOpenedFonts];
	m_buffer = new uint8_t[cMaxFontBufSiz];

	// Create filler rectangle
	constexpr uint32_t W = 3;
	uint8_t buffer[W * W * 4];
	bx::memSet(buffer, 255, W * W * 4);
	bx::memSet(m_cachedFiles, 0, sizeof(CachedFile) * cMaxOpenedFiles);
	m_blackGlyph.width = W;
	m_blackGlyph.height = W;

	// make sure the black glyph doesn't bleed by using a one pixel inner outline
	m_blackGlyph.regionIndex = m_atlas->addRegion(W, W, buffer, AtlasRegion::Type::TYPE_GRAY, 1);
}

BgfxFontManager::~BgfxFontManager()
{
	if (m_fontHandles.getNumHandles() == 0)
	{
		logE("All fonts must be destroyed before destroying BgfxFontManager");
	}
	delete [] m_cachedFonts;

	if (m_filesHandles.getNumHandles() != 0)
	{
		logE("All font files must be destroyed before destroying BgfxFontManager");
	}
	for (uint16_t i = 0; i < cMaxOpenedFiles; ++i)
	{
		if (m_cachedFiles[i].buffer != nullptr)
		{
			destroyTtf({ i });
		}
	}
	delete [] m_cachedFiles;

	delete [] m_buffer;

	if (m_ownAtlas)
	{
		delete m_atlas;
	}
}

TrueTypeHandle BgfxFontManager::createTtf(const uint8_t* _buffer, uint32_t _size)
{
	uint16_t id = m_filesHandles.alloc();
	ONYX_ASSERT(id != bx::kInvalidHandle, "createTtf: Failed to allocate ttf handle");

	m_cachedFiles[id].buffer = new uint8_t[_size];
	m_cachedFiles[id].bufferSize = _size;
	bx::memCopy(m_cachedFiles[id].buffer, _buffer, _size);

	TrueTypeHandle ret = { id };
	return ret;
}

void BgfxFontManager::destroyTtf(TrueTypeHandle _handle)
{
	ONYX_ASSERT(isValid(_handle), "destroyTtf: tried to destroy invalid handle");

	delete m_cachedFiles[_handle.idx].buffer;
	m_cachedFiles[_handle.idx].bufferSize = 0;
	m_cachedFiles[_handle.idx].buffer = nullptr;
	m_filesHandles.free(_handle.idx);
}

FontHandle BgfxFontManager::createFontByPixelSize(TrueTypeHandle _ttfHandle, uint32_t _typefaceIndex, uint32_t _pixelSize, FontTypes _fontType, uint16_t _glyphWidthPadding, uint16_t _glyphHeightPadding)
{
	ONYX_ASSERT(isValid(_ttfHandle), "createFontByPixelSize: invalid ttf handle passed in");

	TrueTypeFont* ttf = new TrueTypeFont();
	if (!ttf->init(m_cachedFiles[_ttfHandle.idx].buffer, m_cachedFiles[_ttfHandle.idx].bufferSize, _typefaceIndex, _pixelSize, _glyphWidthPadding, _glyphHeightPadding) )
	{
		delete ttf;
		FontHandle invalid = { bx::kInvalidHandle };
		return invalid;
	}

	uint16_t fontIdx = m_fontHandles.alloc();
	ONYX_ASSERT(fontIdx != bx::kInvalidHandle, "createFontByPixelSize: unable to allocate font index");

	CachedFont& font = m_cachedFonts[fontIdx];
	font.trueTypeFont = ttf;
	font.fontInfo = ttf->getFontInfo();
	font.fontInfo.fontType  = _fontType;
	font.fontInfo.pixelSize = uint16_t(_pixelSize);
	font.cachedGlyphs.clear();
	font.masterFontHandle.idx = bx::kInvalidHandle;

	FontHandle handle = { fontIdx };
	return handle;
}

FontHandle BgfxFontManager::createScaledFontToPixelSize(FontHandle _baseFontHandle, uint32_t _pixelSize)
{
	ONYX_ASSERT(isValid(_baseFontHandle), "createScaledFontToPixelSize: invalid font handle used");

	CachedFont& baseFont = m_cachedFonts[_baseFontHandle.idx];
	FontInfo& fontInfo = baseFont.fontInfo;

	FontInfo newFontInfo  = fontInfo;
	newFontInfo.pixelSize = uint16_t(_pixelSize);
	newFontInfo.scale     = (float)_pixelSize / (float) fontInfo.pixelSize;
	newFontInfo.ascender  = (newFontInfo.ascender * newFontInfo.scale);
	newFontInfo.descender = (newFontInfo.descender * newFontInfo.scale);
	newFontInfo.lineGap   = (newFontInfo.lineGap * newFontInfo.scale);
	newFontInfo.maxAdvanceWidth    = (newFontInfo.maxAdvanceWidth * newFontInfo.scale);
	newFontInfo.underlineThickness = (newFontInfo.underlineThickness * newFontInfo.scale);
	newFontInfo.underlinePosition  = (newFontInfo.underlinePosition * newFontInfo.scale);

	uint16_t fontIdx = m_fontHandles.alloc();
	ONYX_ASSERT(fontIdx != bx::kInvalidHandle, "createScaledFontToPixelSize: failed to allocate font handle");

	CachedFont& font = m_cachedFonts[fontIdx];
	font.cachedGlyphs.clear();
	font.fontInfo = newFontInfo;
	font.trueTypeFont = nullptr;
	font.masterFontHandle = _baseFontHandle;

	FontHandle handle = { fontIdx };
	return handle;
}

void BgfxFontManager::destroyFont(FontHandle _handle)
{
	ONYX_ASSERT(isValid(_handle), "destroyFont: Invalid handle used");

	CachedFont& font = m_cachedFonts[_handle.idx];

	if (font.trueTypeFont != nullptr)
	{
		delete font.trueTypeFont;
		font.trueTypeFont = nullptr;
	}

	font.cachedGlyphs.clear();
	m_fontHandles.free(_handle.idx);
}

bool BgfxFontManager::preloadGlyph(FontHandle _handle, const wchar_t* _string)
{
	ONYX_ASSERT(isValid(_handle), "preloadGlyph: Invalid handle used");

	CachedFont& font = m_cachedFonts[_handle.idx];

	if (font.trueTypeFont == nullptr)
	{
		return false;
	}

	for (uint32_t ii = 0, end = (uint32_t)wcslen(_string); ii < end; ++ii)
	{
		CodePoint codePoint = _string[ii];
		if (!preloadGlyph(_handle, codePoint) )
		{
			return false;
		}
	}

	return true;
}

bool BgfxFontManager::preloadGlyph(FontHandle _handle, CodePoint _codePoint)
{
	ONYX_ASSERT(isValid(_handle), "preloadGlph: Invalid handle used");

	CachedFont& font = m_cachedFonts[_handle.idx];
	FontInfo& fontInfo = font.fontInfo;

	GlyphHashMap::iterator iter = font.cachedGlyphs.find(_codePoint);
	if (iter != font.cachedGlyphs.end() )
	{
		return true;
	}

	if (font.trueTypeFont)
	{
		GlyphInfo glyphInfo;

		switch (font.fontInfo.fontType)
		{
		case FontTypes::Alpha:
			font.trueTypeFont->bakeGlyphAlpha(_codePoint, glyphInfo, m_buffer);
			break;

		case FontTypes::Distance:
			font.trueTypeFont->bakeGlyphDistance(_codePoint, glyphInfo, m_buffer);
			break;

		case FontTypes::DistanceSubpixel:
			font.trueTypeFont->bakeGlyphDistance(_codePoint, glyphInfo, m_buffer);
			break;

		case FontTypes::DistanceOutline:
		case FontTypes::DistanceOutlineImage:
		case FontTypes::DistanceShadow:
		case FontTypes::DistanceShadowImage:
		case FontTypes::DistanceOutlineShadowImage:
			font.trueTypeFont->bakeGlyphDistance(_codePoint, glyphInfo, m_buffer);
			break;

		default:
			ONYX_ASSERT(false, "preloadGlyph: TextureType not supported yet");
		}

		if (!addBitmap(glyphInfo, m_buffer) )
		{
			return false;
		}

		glyphInfo.advance_x = (glyphInfo.advance_x * fontInfo.scale);
		glyphInfo.advance_y = (glyphInfo.advance_y * fontInfo.scale);
		glyphInfo.offset_x = (glyphInfo.offset_x * fontInfo.scale);
		glyphInfo.offset_y = (glyphInfo.offset_y * fontInfo.scale);
		glyphInfo.height = (glyphInfo.height * fontInfo.scale);
		glyphInfo.width = (glyphInfo.width * fontInfo.scale);

		font.cachedGlyphs[_codePoint] = glyphInfo;
		return true;
	}

	if (isValid(font.masterFontHandle) && preloadGlyph(font.masterFontHandle, _codePoint))
	{
		GlyphInfo const* glyph = getGlyphInfo(font.masterFontHandle, _codePoint);

		GlyphInfo glyphInfo = *glyph;
		glyphInfo.advance_x = (glyphInfo.advance_x * fontInfo.scale);
		glyphInfo.advance_y = (glyphInfo.advance_y * fontInfo.scale);
		glyphInfo.offset_x = (glyphInfo.offset_x * fontInfo.scale);
		glyphInfo.offset_y = (glyphInfo.offset_y * fontInfo.scale);
		glyphInfo.height = (glyphInfo.height * fontInfo.scale);
		glyphInfo.width = (glyphInfo.width * fontInfo.scale);

		font.cachedGlyphs[_codePoint] = glyphInfo;
		return true;
	}

	return false;
}

bool BgfxFontManager::addGlyphBitmap(FontHandle _handle, CodePoint _codePoint, uint16_t _width, uint16_t _height, uint16_t _pitch, float extraScale, const uint8_t* _bitmapBuffer, float glyphOffsetX, float glyphOffsetY)
{
	ONYX_ASSERT(isValid(_handle), "addGlyphBitmap: Invalid handle used");

	CachedFont& font = m_cachedFonts[_handle.idx];

	GlyphHashMap::iterator iter = font.cachedGlyphs.find(_codePoint);
	if (iter != font.cachedGlyphs.end() )
	{
		return true;
	}

	GlyphInfo glyphInfo;

	float glyphScale = extraScale;
	glyphInfo.offset_x = glyphOffsetX * glyphScale;
	glyphInfo.offset_y = glyphOffsetY * glyphScale;
	glyphInfo.width = (float)_width;
	glyphInfo.height = (float)_height;
	glyphInfo.advance_x = (float)_width * glyphScale;
	glyphInfo.advance_y = (float)_height * glyphScale;
	glyphInfo.bitmapScale = glyphScale;

	uint32_t dstPitch = _width * 4;

	uint8_t* dst = m_buffer;
	const uint8_t* src = _bitmapBuffer;
	uint32_t srcPitch = _pitch;

	for (int32_t ii = 0; ii < _height; ++ii)
	{
		bx::memCopy(dst, src, dstPitch);

		dst += dstPitch;
		src += srcPitch;
	}

	glyphInfo.regionIndex = m_atlas->addRegion(
		  (uint16_t)bx::ceil(glyphInfo.width)
		, (uint16_t)bx::ceil(glyphInfo.height)
		, m_buffer
		, AtlasRegion::Type::TYPE_BGRA8
		);

	font.cachedGlyphs[_codePoint] = glyphInfo;
	return true;
}

FontInfo const& BgfxFontManager::getFontInfo(FontHandle _handle) const
{
	ONYX_ASSERT(isValid(_handle), "getFontInfo: Invalid handle used");

	return m_cachedFonts[_handle.idx].fontInfo;
}

float BgfxFontManager::getKerning(FontHandle _handle, CodePoint _prevCodePoint, CodePoint _codePoint)
{
	const CachedFont& cachedFont = m_cachedFonts[_handle.idx];
	if (isValid(cachedFont.masterFontHandle))
	{
		CachedFont& baseFont = m_cachedFonts[cachedFont.masterFontHandle.idx];
		return baseFont.trueTypeFont->m_scale * stbtt_GetCodepointKernAdvance(&baseFont.trueTypeFont->m_font, _prevCodePoint, _codePoint);
	}
	else
	{
		return cachedFont.trueTypeFont->m_scale * stbtt_GetCodepointKernAdvance(&cachedFont.trueTypeFont->m_font, _prevCodePoint, _codePoint);
	}
}

const GlyphInfo* BgfxFontManager::getGlyphInfo(FontHandle _handle, CodePoint _codePoint)
{
	ONYX_ASSERT(isValid(_handle), "getGlyphInfo: invalid font handle");

	const GlyphHashMap& cachedGlyphs = m_cachedFonts[_handle.idx].cachedGlyphs;
	GlyphHashMap::const_iterator it = cachedGlyphs.find(_codePoint);

	if (it == cachedGlyphs.end() )
	{
		if (!preloadGlyph(_handle, _codePoint) )
		{
			return nullptr;
		}

		it = cachedGlyphs.find(_codePoint);
	}

	ONYX_ASSERT(it != cachedGlyphs.end(), "getGlyphInfo: Failed to preload glyph.");
	return &it->second;
}

bool BgfxFontManager::addBitmap(GlyphInfo& _glyphInfo, const uint8_t* _data)
{
	_glyphInfo.regionIndex = m_atlas->addRegion(
		  (uint16_t)bx::ceil(_glyphInfo.width)
		, (uint16_t)bx::ceil(_glyphInfo.height)
		, _data
		, AtlasRegion::Type::TYPE_GRAY
		);
	return true;
}
