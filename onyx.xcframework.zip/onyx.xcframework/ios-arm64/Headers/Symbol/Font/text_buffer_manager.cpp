/*
 * Copyright 2013 Jeremie Roy. All rights reserved.
 * License: https://github.com/bkaradzic/bgfx#license-bsd-2-clause
 */

//#include "../common.h"

#include <bgfx/bgfx.h>
#include <bgfx/embedded_shader.h>

#include <stddef.h> // offsetof
#include <wchar.h>  // wcslen

// This MUST be included before utf8.h because utf8 #defines UTF8_ACCEPT and UTF8_REJECT, which breaks
// the constexpr UTF8_ACCEPT/REJECT definitions in json.hpp
#include <Shaders/ShaderManager.h>

#include "text_buffer_manager.h"
#include "utf8.h"
#include "cube_atlas.h"
#include "BgfxFontManager.h"

#include <lucid/gal/Types.h>

#define MAX_BUFFERED_CHARACTERS (8192 - 5)

namespace styling = onyx::Styling;

struct TextLength
{
	gpu_float_t screenLength;
	size_t glyphCount;
};

struct PenState
{
	lgal::gpu::Vector2 position;
	gpu_float_t depth = 0.0f;
	TextRectangle rectangle;
	CodePoint prevCodePoint;

	static inline PenState empty() { return { { 0, 0 }, 0.f, { 0, 0 }, 0 }; }
};

class TextBuffer
{
public:
	static constexpr int16_t MODE_NORMAL = 0;
	static constexpr int16_t MODE_SHADOW = std::numeric_limits<int16_t>::min();
	static constexpr int16_t MODE_BGRA8 = std::numeric_limits<int16_t>::max();

	/// TextBuffer is bound to a fontManager for glyph retrieval
	/// @remark the ownership of the manager is not taken
	TextBuffer(BgfxFontManager* _fontManager);
	~TextBuffer();

	uint32_t getOutlineColor() const
	{
		return m_outlineColor;
	}

	float getOutlineWidth() const
	{
		return m_outlineWidth;
	}

	uint32_t getDropShadowColor() const
	{
		return m_dropShadowColor;
	}

	float getDropShadowSoftener() const
	{
		return m_dropShadowSoftener;
	}

	void setStyle(styling::TextStyle const& style)
	{
		mStyle = style;
	}

	void setAlpha(gpu_float_t alpha)
	{
		mAlpha = lucid::math::clamp(0.f, 1.f, alpha);
	}

	inline uint32_t alphaColor(lgal::Color c, gpu_float_t alpha)
	{
		c.a *= alpha;
		return c.abgr();
	}

	// TODO (scott) Having to call this manually isn't ideal but it's more convenient here
	//				than anywhere else
	void updateColors()
	{
		m_textColor				= alphaColor(mStyle.color, mAlpha);
		m_outlineColor			= alphaColor(mStyle.haloColor, mAlpha);;
		m_dropShadowColor		= alphaColor(mStyle.dropshadowColor, mAlpha);

		auto alpha = uint32_t((mStyle.color.a * mStyle.dropshadowColor.a * mAlpha) * 255) << 24;
		m_dropShadowColor = alpha | (m_dropShadowColor & 0x00ffffff);

		m_backgroundColor		= alphaColor(mStyle.backgroundColor, mAlpha);
		m_overlineColor			= alphaColor(mStyle.overlineColor, mAlpha);
		m_underlineColor		= alphaColor(mStyle.underlineColor, mAlpha);
		m_strikeThroughColor	= alphaColor(mStyle.strikethroughColor, mAlpha);
	}

	void setOutlineWidth(float _outlineWidth = 3.0f)
	{
		m_outlineWidth = _outlineWidth;
	}

	void setDropShadowOffset(float u, float v)
	{
		m_dropShadowOffset[0] = u;
		m_dropShadowOffset[1] = v;
	}

	void setDropShadowSoftener(float smoother)
	{
		m_dropShadowSoftener = smoother;
	}

	void setPenPosition(lgal::gpu::Vector2 const &position)
	{
		m_penState.position = position;
	}

	void setPenDepth(gpu_float_t depth)
	{
		m_penState.depth = depth;
	}

	void setTextDirection(lgal::gpu::Vector2 const& direction, lgal::gpu::Vector2 const& linefeed = { 0, 0 })
	{
		m_direction = lmath::normalize(direction);
		if (linefeed == lgal::gpu::Vector2(0, 0))
		{
			m_newLineDirection = m_direction.rot90ccw();
		}
		else
		{
			m_newLineDirection = lmath::normalize(linefeed);
		}
	}

	template<typename charT>
	TextLength textLength(FontHandle _fontHandle, const charT* _string, float kerningModifier, const charT* _end);

	template<typename charT>
	lgal::gpu::AABB2d layoutText(FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const charT* _string, float kerningModifier, const charT* _end, styling::Anchor position = styling::Anchor::DEFAULT, bool keepUpright = true);

	template <typename charT>
	lgal::gpu::AABB2d appendText(FontHandle _fontHandle, const charT* _string, float kerningModifier, const charT* _end = nullptr, bool measure = false);

	/// Append a whole face of the atlas cube, mostly used for debugging
	/// and visualizing atlas.
	void appendAtlasFace(uint16_t _faceIndex);

	/// Clear the text buffer and reset its state (pen/color)
	void clearTextBuffer();

	/// Get pointer to the vertex buffer to submit it to the graphic card.
	const uint8_t* getVertexBuffer()
	{
		return (uint8_t*) m_vertexBuffer;
	}

	/// Number of vertex in the vertex buffer.
	uint32_t getVertexCount() const
	{
		return m_vertexCount;
	}

	/// Size in bytes of a vertex.
	uint32_t getVertexSize() const
	{
		return sizeof(TextVertex);
	}

	/// get a pointer to the index buffer to submit it to the graphic
	const uint16_t* getIndexBuffer() const
	{
		return m_indexBuffer;
	}

	/// number of index in the index buffer
	uint32_t getIndexCount() const
	{
		return m_indexCount;
	}

	/// Size in bytes of an index.
	uint32_t getIndexSize() const
	{
		return sizeof(uint16_t);
	}

	uint32_t getTextColor() const
	{
		return toABGR(m_textColor);
	}

	TextRectangle getRectangle() const
	{
		return m_penState.rectangle;
	}

private:
	void appendGlyph(FontHandle _handle, CodePoint _codePoint, bool shadow, float kerningModifier, bool measure = false);
	void verticalCenterLastLine(float _txtDecalY, float _top, float _bottom);

	static uint32_t toABGR(uint32_t _rgba)
	{
		return ( ( (_rgba >>  0) & 0xff) << 24)
			 | ( ( (_rgba >>  8) & 0xff) << 16)
			 | ( ( (_rgba >> 16) & 0xff) <<  8)
			 | ( ( (_rgba >> 24) & 0xff) <<  0)
			 ;
	}

	inline void setVertex(uint32_t _i, lgal::gpu::Vector3 const &pos, int16_t mode, uint32_t _rgba, uint32_t _rgbaColor = 0, styling::TextStyleFlags _style = styling::TextStyleFlags::NORMAL)
	{
		m_vertexBuffer[_i].pos = pos;
		m_vertexBuffer[_i].rgba = _rgba;
		m_vertexBuffer[_i].rgbaOutline = _rgbaColor;
		m_vertexBuffer[_i].t1 = mode;

		m_styleBuffer[_i] = uint8_t(_style);
	}

	void setInstance(lgal::gpu::Vector2 const& screenPosPx, gpu_float_t normalizedDepth, int16_t mode,
		lgal::gpu::Vector2 const& screenUDir, lgal::gpu::Vector2 const& screenVDir,
		Atlas const* atlas,
		uint16_t regionIndex,
		uint32_t rgba,
		uint32_t rgbaOutline, styling::TextStyleFlags _style = styling::TextStyleFlags::NORMAL)
	{
		atlas->packUV(regionIndex
			, (uint8_t*)m_vertexBuffer
			, sizeof(TextVertex) * m_vertexCount + offsetof(TextVertex, u)
			, sizeof(TextVertex)
		);

		auto const& p0 = screenPosPx;
		auto const p1 = p0 + screenVDir;
		auto const p2 = p1 + screenUDir;
		auto const p3 = p0 + screenUDir;

		setVertex(m_vertexCount + 0, { p0, normalizedDepth }, mode, rgba, rgbaOutline, _style);
		setVertex(m_vertexCount + 1, { p1, normalizedDepth }, mode, rgba, rgbaOutline, _style);
		setVertex(m_vertexCount + 2, { p2, normalizedDepth }, mode, rgba, rgbaOutline, _style);
		setVertex(m_vertexCount + 3, { p3, normalizedDepth }, mode, rgba, rgbaOutline, _style);

		m_indexBuffer[m_indexCount + 0] = m_vertexCount + 0;
		m_indexBuffer[m_indexCount + 1] = m_vertexCount + 1;
		m_indexBuffer[m_indexCount + 2] = m_vertexCount + 2;
		m_indexBuffer[m_indexCount + 3] = m_vertexCount + 0;
		m_indexBuffer[m_indexCount + 4] = m_vertexCount + 2;
		m_indexBuffer[m_indexCount + 5] = m_vertexCount + 3;
		m_vertexCount += 4;
		m_indexCount += 6;
	}

	void setOutlineColor(uint32_t _i, uint32_t _rgbaOutline)
	{
		m_vertexBuffer[_i].rgbaOutline = _rgbaOutline;
	}

	struct TextVertex
	{
		lgal::gpu::Vector3 pos;
		int16_t u, v, w, t;
		int16_t u1, v1, w1, t1;
		uint32_t rgba;
		uint32_t rgbaOutline;
	};

	styling::TextStyle mStyle;
	gpu_float_t mAlpha				= 1.f;
	uint32_t m_textColor			= 0;
	uint32_t m_outlineColor			= 0;
	uint32_t m_dropShadowColor		= 0;
	uint32_t m_backgroundColor		= 0;
	uint32_t m_overlineColor		= 0;
	uint32_t m_underlineColor		= 0;
	uint32_t m_strikeThroughColor	= 0;
	bool mShadowsFollowText = false;

	// outline state
	float m_outlineWidth;

	// drop shadow state
	lgal::gpu::Vector2 m_dropShadowOffset = { 0.f };
	float m_dropShadowSoftener;

	//position states
	
	lgal::gpu::Vector2 m_direction = { 1, 0 },
		m_origin = { 0, 0 },
		m_newLineDirection = { 0, 1 };

	float m_lineAscender;
	float m_lineDescender;
	float m_lineGap;

	PenState m_penState = PenState::empty();

	BgfxFontManager* m_fontManager;

	TextVertex* m_vertexBuffer;
	uint16_t* m_indexBuffer;
	uint8_t* m_styleBuffer;

	uint32_t m_indexCount;
	uint32_t m_lineStartIndex;
	uint16_t m_vertexCount;
};

TextBuffer::TextBuffer(BgfxFontManager* _fontManager)
	: m_outlineWidth(3.0f)
	, m_dropShadowSoftener(1.0f)
	, m_lineAscender(0)
	, m_lineDescender(0)
	, m_lineGap(0)
	, m_fontManager(_fontManager)
	, m_vertexBuffer(new TextVertex[MAX_BUFFERED_CHARACTERS * 4])
	, m_indexBuffer(new uint16_t[MAX_BUFFERED_CHARACTERS * 6])
	, m_styleBuffer(new uint8_t[MAX_BUFFERED_CHARACTERS * 4])
	, m_indexCount(0)
	, m_lineStartIndex(0)
	, m_vertexCount(0)
{
}

TextBuffer::~TextBuffer()
{
	delete [] m_vertexBuffer;
	delete [] m_indexBuffer;
	delete [] m_styleBuffer;
}

size_t getStrLen(char const* str)
{
	return bx::strLen(str);
}

size_t getStrLen(wchar_t const* str)
{
	return wcslen(str);
}

uint32_t decode(uint32_t& state, CodePoint& codePoint, char const *str)
{
	return utf8_decode(&state, (uint32_t*)&codePoint, *str);
}

uint32_t decode(uint32_t &/* state */, CodePoint& codePoint, wchar_t const *str)
{
	codePoint = *str;
	return UTF8_ACCEPT;
}

lgal::gpu::LineSegment2 getPathSegment(std::vector<lgal::gpu::Vector3> const& screenPath, size_t segment, bool forward = true)
{
	if (screenPath.size() < 2)
	{
		return { { 0, 0 }, { 1, 0 } }; // If not enough segments, just choose a horizontal line.
	}

	if (screenPath.size() > segment + 1)
	{
		if (forward)
		{
			return { screenPath[segment].xy, screenPath[segment + 1].xy };
		}
		else
		{
			return { screenPath[segment + 1].xy, screenPath[segment].xy };
		}
	}

	return { { 0, 0 }, { 0, 0 } };
}

lgal::gpu::Range getSegmentZ(std::vector<lgal::gpu::Vector3> const& screenPath, size_t segment, bool forward = true)
{
	if (forward)
		return { screenPath[segment].z, screenPath[segment + 1].z };
	else
		return { screenPath[segment + 1].z, screenPath[segment].z };
}

size_t getPathSegmentAtLength(std::vector<lgal::gpu::Vector3> const& screenPath, gpu_float_t position)
{
	if (screenPath.size() < 2)
	{
		return 0; // If not enough segments, just choose a horizontal line.
	}
	
	gpu_float_t pos = 0;
	lgal::gpu::Vector2 p1 = screenPath.front().xy;
	auto iter = screenPath.begin() + 1;
	size_t result = 0;
	while (pos < position)
	{
		lgal::gpu::LineSegment2 seg = { p1, (*iter).xy };
		pos += seg.length();
		++iter;
		if (pos >= position || iter == screenPath.end())
		{
			return result;
		}
		++result;
		p1 = seg.end;
	}
	return result;
}

template<typename charT>
TextLength TextBuffer::textLength(FontHandle _fontHandle, const charT* _string, float kerningModifier, const charT* _end)
{
	TextLength result{ 0, 0 };
	auto end = _end != nullptr
		? _end
		: _string + getStrLen(_string);

	CodePoint codePoint = 0,
		prevCodePoint = 0;
	uint32_t state = 0;

	for (charT const* _current = _string; *_current && _current < end; ++_current)
	{
		prevCodePoint = codePoint;
		if (decode(state, codePoint, _current) == UTF8_ACCEPT)
		{

			if (codePoint == L'\n')
			{
				continue;
			}


			auto glyph = m_fontManager->getGlyphInfo(_fontHandle, codePoint);

			if (glyph == nullptr)
			{
				continue;
			}
			
			size_t glyphs = codePoint == L'\t' ? 4 : 1;

			result.glyphCount += glyphs;

			float kerning = m_fontManager->getKerning(_fontHandle, prevCodePoint, codePoint) + kerningModifier;
			result.screenLength += (glyph->advance_x + kerning) * gpu_float_t(glyphs);
		}
	}
	return result;
}

// TODO (scott) Moving all of this code back out into LabelManager and simply drawing glyphs one at a time
//				will give us more flexibility in how we keep track of where labels are drawn on-screen.
template<typename charT>
lgal::gpu::AABB2d TextBuffer::layoutText(FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const charT* _string, float kerningModifier, const charT* _end, styling::Anchor position, bool keepUpright)
{
	if (screenPath.empty())
	{
		return appendText(_fontHandle, _string, kerningModifier, _end, false);
	}
	updateColors();

	lgal::gpu::AABB2d result = lgal::gpu::AABB2d::nothing();
	struct segmentPos { gpu_float_t length, position; };
	std::vector<segmentPos> segments;

	size_t segmentIdx = 0;
	lgal::gpu::LineSegment2 segment = getPathSegment(screenPath, segmentIdx);

	gpu_float_t textOffset = 0;
	gpu_float_t segmentStart = 0;
	gpu_float_t segmentLength = segment.length();
	gpu_float_t segmentEnd = segmentLength;

	auto const& fontInfo = m_fontManager->getFontInfo(_fontHandle);

	lgal::gpu::Vector2 pathPos = screenPath.front().xy;
	auto vertOffset = 0.f;

	if ((position & (styling::Anchor::ABOVE | styling::Anchor::BELOW)) == 0)
	{
		vertOffset = gpu_float_t(fontInfo.pixelSize) * 0.75f; // TODO (scott) This should be driven by the font style, but it looks good for most cases now
	}
	else if ((position & styling::Anchor::ABOVE) != 0)
	{
		vertOffset = gpu_float_t(fontInfo.pixelSize);
	}

	auto labelLength = textLength(_fontHandle, _string, kerningModifier, _end);

	segments.reserve(screenPath.size() - 1);
	gpu_float_t pathLength = 0;
	for (size_t segIdx = 0; segIdx < screenPath.size() - 1; ++segIdx)
	{
		auto seg = getPathSegment(screenPath, segIdx);
		segments.push_back({ seg.length(), pathLength });
		pathLength += segments.back().length;
	}

	if (labelLength.screenLength > pathLength)
	{
		return result;
	}

	if ((position & styling::Anchor::LEFT) == 0) // Don't need to shift anything for left alignment
	{
		textOffset = (pathLength - labelLength.screenLength);

		if ((position & styling::Anchor::RIGHT) == 0) // horizontal center alignment
		{
			textOffset *= 0.5f;
		}
	}

	auto endSegmentIdx = getPathSegmentAtLength(screenPath, labelLength.screenLength + textOffset);

	auto lastSegment = getPathSegment(screenPath, endSegmentIdx, false);

	bool forward = keepUpright ? segment.start.x <= lastSegment.start.x : true;
	if (!forward)
	{
		segmentIdx = endSegmentIdx;
		segment = lastSegment;
		segmentEnd = lastSegment.length();
		pathPos = segment.start;
	}

	auto segmentZ = getSegmentZ(screenPath, segmentIdx, forward);

	auto end = _end != nullptr
		? _end
		: _string + getStrLen(_string);

	CodePoint codepoint = 0;
	uint32_t state = 0;

	auto startVertex = m_vertexCount;
	auto indexOffset = uint16_t((labelLength.glyphCount * 6) - 6);

	memset(&m_indexBuffer[m_indexCount], 0, sizeof(m_indexBuffer[0])* labelLength.glyphCount * 6 * 2);

	bool setPenState = true;
	// TODO (scott) improve the placement of glyphs that intersect path segment endpoints
	for (charT const* _current = _string; *_current && _current < end; ++_current)
	{
		if (decode(state, codepoint, _current) == UTF8_ACCEPT)
		{
			auto glyph = m_fontManager->getGlyphInfo(_fontHandle, codepoint);

			if (glyph == nullptr)
			{
				continue;
			}

			auto segmentPos = (textOffset - segmentStart) / segmentLength;

			float kerning = m_fontManager->getKerning(_fontHandle, m_penState.prevCodePoint, codepoint) + kerningModifier;
			auto glyphEnd = textOffset + glyph->advance_x + kerning;
			if (glyphEnd > segmentEnd && segmentIdx < segments.size())
			{
				do
				{

					segmentIdx += forward ? 1 : -1;
					if (segmentIdx >= segments.size())
					{
						break;
					}

					auto nextSeg = segments[segmentIdx];
					
					segmentStart = segmentEnd;
					segmentEnd += nextSeg.length;
					segmentLength = nextSeg.length;

					if (glyphEnd <= segmentEnd)
					{
						segment = getPathSegment(screenPath, segmentIdx, forward);
					}

				} while (glyphEnd > segmentEnd && segmentIdx < segments.size());
				
				if (glyphEnd > segmentEnd)
				{
					break; // No more space for the label; bail.  Ideally we should have never started
				}

				setPenState = true;
			}

			if (setPenState)
			{
				setTextDirection(segment.direction());

				setPenState = false;

				pathPos = segment.position(textOffset - segmentStart);

				if (vertOffset != 0.f)
				{
					pathPos = pathPos - (m_newLineDirection * vertOffset);
				}

				setPenPosition(pathPos);
			}


			m_penState.depth = lmath::lerp(segmentZ.begin, segmentZ.end, segmentPos);

			// Append the shadow glyph; save the pen state so that we can reset the position for the actual glyph
			auto saveState = m_penState;
			appendGlyph(_fontHandle, codepoint, true, kerningModifier);

			m_penState = saveState;
			m_indexCount += indexOffset;
			// Append the actual glyph
			appendGlyph(_fontHandle, codepoint, false, kerningModifier);
			m_indexCount -= (indexOffset + 6);

			textOffset = glyphEnd;
		}
	}

	m_indexCount += indexOffset + 6;

	for (auto v = &m_vertexBuffer[startVertex]; v < &m_vertexBuffer[m_vertexCount]; ++v)
	{
		result = result.fit(v->pos.xy);
	}

	return result;
}

template <typename charT>
lgal::gpu::AABB2d TextBuffer::appendText(FontHandle _fontHandle, const charT* _string, float kerningModifier, const charT* _end, bool measure)
{
	updateColors();
	if (m_vertexCount == 0)
	{
		m_origin = m_penState.position;
		m_lineDescender = 0;
		m_lineAscender = 0;
		m_lineGap = 0;
		m_penState.prevCodePoint = 0;
		m_penState.rectangle = { 0, 0 };
	}

	auto savedOrigin = m_origin;
	auto savedLineDescender = m_lineDescender;
	auto savedLineAscender = m_lineAscender;
	auto savedLineGap = m_lineGap;
	auto savedPenState = m_penState;
	auto savedDirection = m_direction;
	auto savedNewLineDirection = m_newLineDirection;

	if (measure)
	{
		m_penState = PenState::empty();
		m_direction = { 1, 0 };
		m_newLineDirection = { 0, 1 };
		m_origin = { 0, 0 };

		m_lineStartIndex = 0;
		m_lineAscender = 0;
		m_lineDescender = 0;
		m_lineGap = 0;
	}

	auto startVertex = m_vertexCount;

	CodePoint codepoint = 0;
	uint32_t state = 0;

	auto end = _end != nullptr
		? _end
		: _string + getStrLen(_string);
	BX_ASSERT(end >= _string, "");

	const FontInfo& font = m_fontManager->getFontInfo(_fontHandle);

	m_lineGap = font.lineGap;
	m_lineDescender = font.descender;
	m_lineAscender = font.ascender;

	bool hasMaskDistShadow = (font.fontType & onyx::Styling::TextFontTypes::MaskDistanceShadow) != onyx::Styling::TextFontTypes::Empty;

	if (hasMaskDistShadow && !measure)
	{
		auto saveState = m_penState;

		for (charT const* _current = _string; *_current && _current < end ; ++_current)
		{
			if (decode(state, codepoint, _current) == UTF8_ACCEPT)
			{
				appendGlyph(_fontHandle, codepoint, true, kerningModifier, measure);
			}
		}

		m_penState = saveState;
	}

	for (charT const* _current = _string; *_current && _current < end ; ++_current)
	{
		if (decode(state, codepoint, _current) == UTF8_ACCEPT )
		{
			appendGlyph(_fontHandle, codepoint, false, kerningModifier, measure);
		}
	}

	lgal::gpu::AABB2d result = lgal::gpu::AABB2d::nothing();

	if (measure)
	{
		result = result.fit(savedPenState.position);
		auto maxPos = savedPenState.position;
		maxPos.x += m_penState.rectangle.width;
		maxPos.y += m_penState.rectangle.height;
		result = result.fit(maxPos);

		m_origin = savedOrigin;
		m_penState = savedPenState;

		m_newLineDirection = savedNewLineDirection;
		m_direction = savedDirection;

		m_lineDescender = savedLineDescender;
		m_lineAscender = savedLineAscender;
		m_lineGap = savedLineGap;
		m_penState = savedPenState;
	}

	BX_ASSERT(state == UTF8_ACCEPT, "The string is not well-formed");
	
	for (auto v = &m_vertexBuffer[startVertex]; v < &m_vertexBuffer[m_vertexCount]; ++v)
	{
		result = result.fit(v->pos.xy);
	}

	return result;
}

void TextBuffer::appendAtlasFace(uint16_t _faceIndex)
{
	if( m_vertexCount/4 >= MAX_BUFFERED_CHARACTERS)
	{
		return;
	}

	float x0 = m_penState.position.x;
	float y0 = m_penState.position.y;
	float x1 = x0 + (float)m_fontManager->getAtlas()->getTextureSize();
	float y1 = y0 + (float)m_fontManager->getAtlas()->getTextureSize();

	m_fontManager->getAtlas()->packFaceLayerUV(_faceIndex
		, (uint8_t*)m_vertexBuffer
		, sizeof(TextVertex) * m_vertexCount + offsetof(TextVertex, u)
		, sizeof(TextVertex)
		);

	setVertex(m_vertexCount + 0, { x0, y0, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());
	setVertex(m_vertexCount + 1, { x0, y1, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());
	setVertex(m_vertexCount + 2, { x1, y1, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());
	setVertex(m_vertexCount + 3, { x1, y0, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());

	m_indexBuffer[m_indexCount + 0] = m_vertexCount + 0;
	m_indexBuffer[m_indexCount + 1] = m_vertexCount + 1;
	m_indexBuffer[m_indexCount + 2] = m_vertexCount + 2;
	m_indexBuffer[m_indexCount + 3] = m_vertexCount + 0;
	m_indexBuffer[m_indexCount + 4] = m_vertexCount + 2;
	m_indexBuffer[m_indexCount + 5] = m_vertexCount + 3;
	m_vertexCount += 4;
	m_indexCount += 6;
}

void TextBuffer::clearTextBuffer()
{
	m_penState = PenState::empty();
	m_origin = { 0, 0 };

	m_vertexCount = 0;
	m_indexCount = 0;
	m_lineStartIndex = 0;
	m_lineAscender = 0;
	m_lineDescender = 0;
	m_lineGap = 0;
}

void TextBuffer::appendGlyph(FontHandle _handle, CodePoint _codePoint, bool shadow, float kerningModifier, bool measure)
{
	if (m_vertexCount >> 2 >= MAX_BUFFERED_CHARACTERS)
	{
		m_penState.prevCodePoint = 0;
		return;
	}

	if (_codePoint == L'\t')
	{
		for (uint32_t ii = 0; ii < 4; ++ii)
		{
			appendGlyph(_handle, L' ', shadow, kerningModifier, measure);
		}
		return;
	}

	const GlyphInfo* glyph = m_fontManager->getGlyphInfo(_handle, _codePoint);
	BX_WARN(nullptr != glyph, "Glyph not found (font handle %d, code point %d)", _handle.idx, _codePoint);
	if (nullptr == glyph)
	{
		m_penState.prevCodePoint = 0;
		return;
	}

	const FontInfo& font = m_fontManager->getFontInfo(_handle);

	if (_codePoint == L'\n')
	{
		m_penState.position.x = m_origin.x;
		m_penState.position.y += m_lineGap + m_lineAscender - m_lineDescender;
		m_lineGap = font.lineGap;
		m_lineDescender = font.descender;
		m_lineAscender = font.ascender;
		m_lineStartIndex = uint32_t(m_vertexCount);
		m_penState.prevCodePoint = 0;
		return;
	}

	//is there a change of font size that require the text on the left to be centered again ?
	if (m_penState.position != m_origin
		&& (font.ascender > m_lineAscender || (font.descender < m_lineDescender)))
	{
		if (font.descender < m_lineDescender)
		{
			m_lineDescender = font.descender;
			m_lineGap = font.lineGap;
		}

		float txtDecals = (font.ascender - m_lineAscender);
		m_lineAscender = font.ascender;
		m_lineGap = font.lineGap;
		if (!measure)
		{
			verticalCenterLastLine((txtDecals), (m_penState.position.y - m_lineAscender), (m_penState.position.y + m_lineAscender - m_lineDescender + m_lineGap));
		}
	}

	float kerning = m_fontManager->getKerning(_handle, m_penState.prevCodePoint, _codePoint) + kerningModifier + (getOutlineWidth() * 0.5f);
	m_penState.position = m_penState.position + (kerning * m_direction);

	const GlyphInfo& blackGlyph = m_fontManager->getBlackGlyph();
	const Atlas* atlas = m_fontManager->getAtlas();
	const AtlasRegion& atlasRegion = atlas->getRegion(glyph->regionIndex);

	auto glyphOffset = (m_direction * glyph->offset_x) + (m_newLineDirection * glyph->offset_y);

	if (shadow)
	{
		if (!measure)
		{
			if (atlasRegion.getType() != AtlasRegion::Type::TYPE_BGRA8)
			{
				auto extraOffset = mShadowsFollowText ? (m_dropShadowOffset.x * m_direction) + (m_dropShadowOffset.y * m_newLineDirection) : m_dropShadowOffset;

				auto glyphWidth = glyph->width;
				auto glyphHeight = glyph->height;
				auto xOffset = glyphWidth * m_direction;
				auto yOffset = glyphHeight * m_newLineDirection;

				auto positionOffset = (glyphOffset + (m_lineAscender * m_newLineDirection)) + extraOffset;

				auto p0 = m_penState.position + positionOffset;

				setInstance(p0, m_penState.depth, MODE_SHADOW, xOffset, yOffset, atlas, glyph->regionIndex, m_dropShadowColor, 0);
			}
		}
	}
	else if (!measure)
	{
		lgal::gpu::Vector2	pos(0);
		gpu_float_t			depth = m_penState.depth;
		int16_t				mode = MODE_NORMAL;
		lgal::gpu::Vector2	screenUDir(0),
			screenVDir(0);
		uint32_t			glyphColor = 0,
			outlineColor = 0;

		if ((mStyle.flags & styling::TextStyleFlags::BACKGROUND) != 0
			&& m_backgroundColor & 0xff000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * (m_lineAscender - m_lineDescender + m_lineGap);

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, m_backgroundColor, 0, styling::TextStyleFlags::BACKGROUND);
		}

		if ((mStyle.flags & styling::TextStyleFlags::UNDERLINE) != 0
			&& m_underlineColor & 0xFF000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);
			pos = pos + ((m_lineAscender - m_lineDescender * 0.5f) * m_newLineDirection);

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * font.underlineThickness;

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, m_underlineColor, 0, styling::TextStyleFlags::UNDERLINE);
		}

		if ((mStyle.flags & styling::TextStyleFlags::OVERLINE) != 0
			&& m_overlineColor & 0xFF000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);
			pos = pos + font.underlineThickness * m_newLineDirection;

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * font.underlineThickness;

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, m_overlineColor, 0, styling::TextStyleFlags::OVERLINE);
		}

		if (!shadow && atlasRegion.getType() == AtlasRegion::Type::TYPE_BGRA8)
		{
			mode = MODE_BGRA8;

			auto glyphScale = glyph->bitmapScale;
			auto glyphWidth = glyph->width * glyphScale;
			auto glyphHeight = glyph->height * glyphScale;

			pos = m_penState.position;
			pos = pos + (glyph->offset_x * m_direction);
			pos = pos + (font.ascender - font.descender - glyphHeight) * 0.5f * m_newLineDirection;

			screenUDir = m_direction * glyphWidth;
			screenVDir = m_newLineDirection * glyphHeight;

			glyphColor = m_textColor;
		}
		else
		{
			pos = m_penState.position + (glyphOffset + (m_lineAscender * m_newLineDirection));

			screenUDir = m_direction * glyph->width;
			screenVDir = m_newLineDirection * glyph->height;

			glyphColor = m_textColor;
			outlineColor = m_outlineColor;
		}

		setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, glyph->regionIndex, glyphColor, outlineColor);

		if ((mStyle.flags & styling::TextStyleFlags::STRIKE_THROUGH) != 0
			&& m_strikeThroughColor & 0xFF000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);
			pos = pos + (font.ascender * 0.666667f) * m_newLineDirection;

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * font.underlineThickness;

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, m_strikeThroughColor, 0, styling::TextStyleFlags::STRIKE_THROUGH);
		}
	}

	m_penState.position = m_penState.position + (glyph->advance_x * m_direction);
	auto newWidth = m_penState.position.x - m_origin.x;
	m_penState.rectangle.width = std::max(m_penState.rectangle.width, newWidth);
	auto newHeight = shadow ? m_penState.position.y + (glyph->height) - m_origin.y :
		(m_penState.position.y + (m_lineAscender - m_lineDescender + m_lineGap)) - m_origin.y;
	m_penState.rectangle.height = std::max(m_penState.rectangle.height, newHeight);

	m_penState.prevCodePoint = _codePoint;
}
void TextBuffer::verticalCenterLastLine(float _dy, float _top, float _bottom)
{
	for (uint32_t ii = m_lineStartIndex; ii < m_vertexCount; ii += 4)
	{
		if (m_styleBuffer[ii] == styling::TextStyleFlags::BACKGROUND)
		{
			m_vertexBuffer[ii + 0].pos.y = _top;
			m_vertexBuffer[ii + 1].pos.y = _bottom;
			m_vertexBuffer[ii + 2].pos.y = _bottom;
			m_vertexBuffer[ii + 3].pos.y = _top;
		}
		else
		{
			m_vertexBuffer[ii + 0].pos.y += _dy;
			m_vertexBuffer[ii + 1].pos.y += _dy;
			m_vertexBuffer[ii + 2].pos.y += _dy;
			m_vertexBuffer[ii + 3].pos.y += _dy;
		}
	}
}

TextBufferManager::TextBufferManager(BgfxFontManager* _fontManager)
	: m_fontManager(_fontManager)
{
	m_textBuffers = new BufferCache[MAX_TEXT_BUFFER_COUNT];

	m_vertexLayout
		.begin()
		.add(bgfx::Attrib::Position,  3, bgfx::AttribType::Float)			// 12
		.add(bgfx::Attrib::TexCoord7, 4, bgfx::AttribType::Int16, true)		// 8
		.add(bgfx::Attrib::TexCoord6, 4, bgfx::AttribType::Int16, true)		// 8
		.add(bgfx::Attrib::TexCoord5, 4, bgfx::AttribType::Uint8, true)		// 4
		.add(bgfx::Attrib::TexCoord4, 4, bgfx::AttribType::Uint8, true)		// 4
		.end();

	bgfx::createVertexLayout(m_vertexLayout);

	s_texColor = bgfx::createUniform("s_texColor", bgfx::UniformType::Sampler);
	u_dropShadowColor = bgfx::createUniform("u_dropShadowColor", bgfx::UniformType::Vec4);
	u_sdfParams = bgfx::createUniform("u_sdfParams", bgfx::UniformType::Vec4);
}

TextBufferManager::~TextBufferManager()
{
	BX_ASSERT(m_textBufferHandles.getNumHandles() == 0, "All the text buffers must be destroyed before destroying the manager");
	delete [] m_textBuffers;

	if(bgfx::isValid(u_sdfParams))
		bgfx::destroy(u_sdfParams);

	if (bgfx::isValid(u_dropShadowColor))
		bgfx::destroy(u_dropShadowColor);
	if (bgfx::isValid(s_texColor))
		bgfx::destroy(s_texColor);

	if (bgfx::isValid(m_basicProgram))
		bgfx::destroy(m_basicProgram);
	if (bgfx::isValid(m_distanceProgram))
		bgfx::destroy(m_distanceProgram);
	if (bgfx::isValid(m_distanceSubpixelProgram))
		bgfx::destroy(m_distanceSubpixelProgram);
	if (bgfx::isValid(m_distanceOutlineProgram))
		bgfx::destroy(m_distanceOutlineProgram);
	if (bgfx::isValid(m_distanceOutlineImageProgram))
		bgfx::destroy(m_distanceOutlineImageProgram);
	if (bgfx::isValid(m_distanceDropShadowProgram))
		bgfx::destroy(m_distanceDropShadowProgram);
	if (bgfx::isValid(m_distanceDropShadowImageProgram))
		bgfx::destroy(m_distanceDropShadowImageProgram);
	if (bgfx::isValid(m_distanceOutlineDropShadowImageProgram))
		bgfx::destroy(m_distanceOutlineDropShadowImageProgram);
}

TextBufferHandle TextBufferManager::createTextBuffer(onyx::Styling::TextFontTypes _type, BufferType::Enum _bufferType)
{
	uint16_t textIdx = m_textBufferHandles.alloc();
	if (textIdx == bgfx::kInvalidHandle)
	{
		return { textIdx };
	}

	BufferCache& bc = m_textBuffers[textIdx];

	bc.textBuffer = new TextBuffer(m_fontManager);
	bc.fontType = _type;
	bc.bufferType = _bufferType;
	bc.indexBufferHandleIdx = bgfx::kInvalidHandle;
	bc.vertexBufferHandleIdx = bgfx::kInvalidHandle;

	TextBufferHandle ret = {textIdx};
	return ret;
}

void TextBufferManager::destroyTextBuffer(TextBufferHandle _handle)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");

	BufferCache& bc = m_textBuffers[_handle.idx];
	m_textBufferHandles.free(_handle.idx);
	if(bc.textBuffer != NULL)
		delete bc.textBuffer;
	bc.textBuffer = NULL;

	if (bc.vertexBufferHandleIdx == bgfx::kInvalidHandle)
	{
		return;
	}

	switch (bc.bufferType)
	{
	case BufferType::Static:
		{
			bgfx::IndexBufferHandle ibh;
			bgfx::VertexBufferHandle vbh;
			ibh.idx = bc.indexBufferHandleIdx;
			vbh.idx = bc.vertexBufferHandleIdx;
			bgfx::destroy(ibh);
			bgfx::destroy(vbh);
		}

		break;

	case BufferType::Dynamic:
		bgfx::DynamicIndexBufferHandle ibh;
		bgfx::DynamicVertexBufferHandle vbh;
		ibh.idx = bc.indexBufferHandleIdx;
		vbh.idx = bc.vertexBufferHandleIdx;
		bgfx::destroy(ibh);
		bgfx::destroy(vbh);

		break;

	case BufferType::Transient: // destroyed every frame
		break;
	}
}

void TextBufferManager::submitTextBuffer(TextBufferHandle _handle, bgfx::ViewId _id, int32_t _depth)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");

	BufferCache& bc = m_textBuffers[_handle.idx];

	uint32_t indexSize  = bc.textBuffer->getIndexCount()  * bc.textBuffer->getIndexSize();
	uint32_t vertexSize = bc.textBuffer->getVertexCount() * bc.textBuffer->getVertexSize();

	if (0 == indexSize || 0 == vertexSize)
	{
		return;
	}

	uint64_t flags = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_FUNC(BGFX_STATE_BLEND_SRC_ALPHA, BGFX_STATE_BLEND_INV_SRC_ALPHA);

	bgfx::setTexture(0, s_texColor, m_fontManager->getAtlas()->getTextureHandle() );

	bgfx::ProgramHandle program = ShaderManager::Instance()->getShaderHandle(ShaderEnums::ConfigurableShaders::FontSDF);

	using FontType = onyx::Styling::TextFontTypes;

	switch (bc.fontType)
	{
	case FontType::Empty:
	case FontType::Alpha:
	case FontType::LCD:
	case FontType::MaskDistanceImage:
	case FontType::MaskDistanceShadow:
		logE("submitTextBuffer: unsupported FontType");
		break;

	case FontType::Distance:
	{
		float params[4] = { 0.0f, (float)m_fontManager->getAtlas()->getTextureSize() / 512.0f, 0.0f, 0.0f };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	case FontType::DistanceSubpixel:
		flags |= bc.textBuffer->getTextColor();
		break;

	case FontType::DistanceOutline:
	case FontType::DistanceOutlineImage:
	{
		float params[4] = { 0.0f, (float)m_fontManager->getAtlas()->getTextureSize() / 512.0f, 0.0f, bc.textBuffer->getOutlineWidth() };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	case FontType::DistanceShadow:
	case FontType::DistanceShadowImage:
	{
		uint32_t dropShadowColor = bc.textBuffer->getDropShadowColor();
		float dropShadowColorVec[4] = { ((dropShadowColor >> 16) & 0xff) / 255.0f, ((dropShadowColor >> 8) & 0xff) / 255.0f, (dropShadowColor & 0xff) / 255.0f, (dropShadowColor >> 24) / 255.0f };
		bgfx::setUniform(u_dropShadowColor, &dropShadowColorVec);

		float params[4] = { 0.0f, (float)m_fontManager->getAtlas()->getTextureSize() / 512.0f, bc.textBuffer->getDropShadowSoftener(), 0.0 };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	case FontType::DistanceOutlineShadowImage:
	{
		uint32_t dropShadowColor = bc.textBuffer->getDropShadowColor();
		float dropShadowColorVec[4] = { ((dropShadowColor >> 16) & 0xff) / 255.0f, ((dropShadowColor >> 8) & 0xff) / 255.0f, (dropShadowColor & 0xff) / 255.0f, (dropShadowColor >> 24) / 255.0f };
		bgfx::setUniform(u_dropShadowColor, &dropShadowColorVec);

		float params[4] = { 0.0f, (float)m_fontManager->getAtlas()->getTextureSize() / 512.0f, bc.textBuffer->getDropShadowSoftener(), bc.textBuffer->getOutlineWidth() };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	}

	switch (bc.bufferType)
	{
	case BufferType::Static:
		{
			bgfx::IndexBufferHandle ibh;
			bgfx::VertexBufferHandle vbh;

			if (bgfx::kInvalidHandle == bc.vertexBufferHandleIdx)
			{
				ibh = bgfx::createIndexBuffer(
								bgfx::copy(bc.textBuffer->getIndexBuffer(), indexSize)
								);

				vbh = bgfx::createVertexBuffer(
								  bgfx::copy(bc.textBuffer->getVertexBuffer(), vertexSize)
								, m_vertexLayout
								);

				bc.vertexBufferHandleIdx = vbh.idx;
				bc.indexBufferHandleIdx = ibh.idx;
			}
			else
			{
				vbh.idx = bc.vertexBufferHandleIdx;
				ibh.idx = bc.indexBufferHandleIdx;
			}

			bgfx::setVertexBuffer(0, vbh, 0, bc.textBuffer->getVertexCount() );
			bgfx::setIndexBuffer(ibh, 0, bc.textBuffer->getIndexCount() );
		}
		break;

	case BufferType::Dynamic:
		{
			bgfx::DynamicIndexBufferHandle ibh;
			bgfx::DynamicVertexBufferHandle vbh;

			if (bgfx::kInvalidHandle == bc.vertexBufferHandleIdx )
			{
				ibh = bgfx::createDynamicIndexBuffer(
								bgfx::copy(bc.textBuffer->getIndexBuffer(), indexSize)
								);

				vbh = bgfx::createDynamicVertexBuffer(
								  bgfx::copy(bc.textBuffer->getVertexBuffer(), vertexSize)
								, m_vertexLayout
								);

				bc.indexBufferHandleIdx = ibh.idx;
				bc.vertexBufferHandleIdx = vbh.idx;
			}
			else
			{
				ibh.idx = bc.indexBufferHandleIdx;
				vbh.idx = bc.vertexBufferHandleIdx;

				bgfx::update(
					  ibh
					, 0
					, bgfx::copy(bc.textBuffer->getIndexBuffer(), indexSize)
					);

				bgfx::update(
					  vbh
					, 0
					, bgfx::copy(bc.textBuffer->getVertexBuffer(), vertexSize)
					);
			}

			bgfx::setVertexBuffer(0, vbh, 0, bc.textBuffer->getVertexCount() );
			bgfx::setIndexBuffer(ibh, 0, bc.textBuffer->getIndexCount() );
		}
		break;

	case BufferType::Transient:
		{
			bgfx::TransientIndexBuffer tib;
			bgfx::TransientVertexBuffer tvb;

			auto vertexCount = bc.textBuffer->getVertexCount();

			auto availableIdx = bgfx::getAvailTransientIndexBuffer(bc.textBuffer->getIndexCount());
			auto availableVtx = bgfx::getAvailTransientVertexBuffer(vertexCount, m_vertexLayout);
			
			// BUG (scott) I've seen crashes here twice now where getAvailTransientVertexBuffer() returns an invalid vertex
			// count greater than the requested number of vertices.  Putting this here to try to catch that.
			if (vertexCount < availableVtx)
			{
				ONYX_THROW("WTF?");
			}
			if (availableIdx == 0 || availableVtx == 0)
			{
				break;
			}

			bgfx::allocTransientIndexBuffer(&tib, availableIdx);
			bgfx::allocTransientVertexBuffer(&tvb, availableVtx, m_vertexLayout);

			bx::memCopy(tib.data, bc.textBuffer->getIndexBuffer(), std::min(tib.size, indexSize));
			bx::memCopy(tvb.data, bc.textBuffer->getVertexBuffer(), std::min(tvb.size, vertexSize));
			bgfx::setVertexBuffer(0, &tvb, 0, availableVtx);
			bgfx::setIndexBuffer(&tib, 0, availableIdx);
		}
		break;
	}

	bgfx::setState(flags | BGFX_STATE_DEPTH_TEST_LEQUAL);

	bgfx::submit(_id, program, _depth);
}

void TextBufferManager::setStyle(TextBufferHandle _handle, styling::TextStyle const& style)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setStyle(style);
}

void TextBufferManager::setAlpha(TextBufferHandle _handle, gpu_float_t alpha)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setAlpha(alpha);
}

void TextBufferManager::setOutlineWidth(TextBufferHandle _handle, float _outlineWidth)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setOutlineWidth(_outlineWidth);
}

void TextBufferManager::setDropShadowOffset(TextBufferHandle _handle, float _u, float _v)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setDropShadowOffset(_u, _v);
}

void TextBufferManager::setDropShadowSoftener(TextBufferHandle _handle, float smoother)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setDropShadowSoftener(smoother);
}

void TextBufferManager::setPenDepth(TextBufferHandle _handle, gpu_float_t depth)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setPenDepth(depth);
}

void TextBufferManager::setPenPosition(TextBufferHandle _handle, lgal::gpu::Vector3 const& position)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setPenPosition(position.xy);
	bc.textBuffer->setPenDepth(position.z);
}

void TextBufferManager::setTextDirection(TextBufferHandle _handle, lgal::gpu::Vector2 const& direction, lgal::gpu::Vector2 const& linefeed)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setTextDirection(direction, linefeed);
}

lgal::gpu::AABB2d TextBufferManager::measureText(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end, true);
}

lgal::gpu::AABB2d TextBufferManager::measureText(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end, true);
}

float TextBufferManager::textLength(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->textLength(_fontHandle, _string, kerningModifier, _end).screenLength;
}

float TextBufferManager::textLength(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->textLength(_fontHandle, _string, kerningModifier, _end).screenLength;
}

lgal::gpu::AABB2d TextBufferManager::layoutText(TextBufferHandle _handle, FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const char* _string, float kerningModifier, const char* _end, styling::Anchor position, bool keepUpright)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->layoutText(_fontHandle, screenPath, _string, kerningModifier, _end, position, keepUpright);
}

lgal::gpu::AABB2d TextBufferManager::appendText(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end);
}

lgal::gpu::AABB2d TextBufferManager::appendText(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end);
}

void TextBufferManager::appendAtlasFace(TextBufferHandle _handle, uint16_t _faceIndex)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->appendAtlasFace(_faceIndex);
}

void TextBufferManager::clearTextBuffer(TextBufferHandle _handle)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->clearTextBuffer();
}

TextRectangle TextBufferManager::getRectangle(TextBufferHandle _handle) const
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->getRectangle();
}
