#pragma once

#include <stdint.h>
#include <limits>
#include <memory>

#include <Styling/Styles/TextStyle.h>

#include "BgfxFontManager.h"
#include "utf8.h"

struct TextLength
{
	gpu_float_t screenLength;
	size_t glyphCount;
};

struct TextRectangle
{
	float width, height;
};

BGFX_HANDLE(TextBufferHandle)

struct PenState
{
	lgal::gpu::Vector2 position = { 0 };
	gpu_float_t depth = 0;
	TextRectangle rectangle = { 0, 0 };
	CodePoint prevCodePoint = 0;

	static inline PenState empty() { return { { 0, 0 }, 0.f, { 0, 0 }, 0 }; }
};

class TextBuffer
{

public:

	static constexpr size_t cMaxBufferedChars = 8192 - 5;
	static constexpr int16_t MODE_NORMAL = 0;
	static constexpr int16_t MODE_SHADOW = std::numeric_limits<int16_t>::min();
	static constexpr int16_t MODE_BGRA8 = std::numeric_limits<int16_t>::max();

	struct Colors
	{
		gpu_float_t alpha = 1.f;
		uint32_t textColor = 0;
		uint32_t outlineColor = 0;
		uint32_t dropShadowColor = 0;
		uint32_t backgroundColor = 0;
		uint32_t overlineColor = 0;
		uint32_t underlineColor = 0;
		uint32_t strikethroughColor = 0;

		inline uint32_t alphaColor(lgal::Color c, gpu_float_t alphaVal)
		{
			c.a *= alphaVal;
			return c.abgr();
		}

		void updateColors(onyx::Styling::TextStyle const& style)
		{
			textColor = alphaColor(style.color, alpha);
			outlineColor = alphaColor(style.haloColor, alpha);
			dropShadowColor = alphaColor(style.dropshadowColor, alpha);

			auto alphaVal = uint32_t((style.color.a * style.dropshadowColor.a * alpha) * 255) << 24;
			dropShadowColor = alphaVal | (dropShadowColor & 0x00ffffff);

			backgroundColor = alphaColor(style.backgroundColor, alpha);
			overlineColor = alphaColor(style.overlineColor, alpha);
			underlineColor = alphaColor(style.underlineColor, alpha);
			strikethroughColor = alphaColor(style.strikethroughColor, alpha);
		}
	};

	enum class Type
	{
		Static,
		Dynamic,
		Transient,
	};

public:

	/// TextBuffer is bound to a fontManager for glyph retrieval
	TextBuffer(std::weak_ptr<BgfxFontManager> _fontManager);
	~TextBuffer();

	inline void setFontManager(std::weak_ptr<BgfxFontManager> _fontManager)
	{
		mFontManager = _fontManager;
	}

	float getOutlineWidth() const
	{
		return m_outlineWidth;
	}

	Colors getColors() const { return mColors; }

	float getDropShadowSoftener() const
	{
		return m_dropShadowSoftener;
	}

	void setStyle(onyx::Styling::TextStyle const& style)
	{
		mStyle = style;
	}

	void setAlpha(gpu_float_t alpha)
	{
		mColors.alpha = lmath::clamp(0.f, 1.f, alpha);
	}

	inline uint32_t alphaColor(lgal::Color c, gpu_float_t alpha)
	{
		c.a *= alpha;
		return c.abgr();
	}

	void setOutlineWidth(float _outlineWidth = 3.0f)
	{
		m_outlineWidth = _outlineWidth;
	}

	void setDropShadowOffset(float u, float v)
	{
		m_dropShadowOffset[0] = u;
		m_dropShadowOffset[1] = v;
	}

	void setDropShadowSoftener(float smoother)
	{
		m_dropShadowSoftener = smoother;
	}

	void setPenPosition(lgal::gpu::Vector2 const& position)
	{
		m_penState.position = position;
	}

	void setPenDepth(gpu_float_t depth)
	{
		m_penState.depth = depth;
	}

	void setTextDirection(lgal::gpu::Vector2 const& direction, lgal::gpu::Vector2 const& linefeed = { 0 });

	template<typename charT>
	TextLength textLength(FontHandle _fontHandle, const charT* _string, float kerningModifier, const charT* _end)
	{
		TextLength result{ 0, 0 };
		auto end = _end != nullptr
			? _end
			: _string + getStrLen(_string);

		CodePoint codePoint = 0,
			prevCodePoint = 0;
		uint32_t state = 0;

		auto fntMgr = mFontManager.lock();
		ONYX_ASSERT(fntMgr, "Font Manager was destroyed before text buffer");

		for (charT const* _current = _string; *_current && _current < end; ++_current)
		{
			prevCodePoint = codePoint;
			if (decode(state, codePoint, _current) == UTF8::ACCEPT)
			{
				if (codePoint == L'\n')
				{
					continue;
				}

				auto glyph = fntMgr->getGlyphInfo(_fontHandle, codePoint);
				if (glyph == nullptr)
				{
					continue;
				}

				size_t glyphs = codePoint == L'\t' ? 4 : 1;

				result.glyphCount += glyphs;

				float kerning = fntMgr->getKerning(_fontHandle, prevCodePoint, codePoint) + kerningModifier;
				result.screenLength += (glyph->advance_x + kerning) * gpu_float_t(glyphs);
			}
		}
		return result;
	}

	// TODO (scott CSONYX-156) Moving all of this code back out into LabelManager and simply drawing glyphs one at a time
	//				           will give us more flexibility in how we keep track of where labels are drawn on-screen.
	template<typename charT>
	lgal::gpu::AABB2d layoutText(FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const charT* _string, float kerningModifier, const charT* _end, onyx::Styling::Anchor position, bool keepUpright)
	{
		if (screenPath.empty())
		{
			return appendText(_fontHandle, _string, kerningModifier, _end, false);
		}
		mColors.updateColors(mStyle);

		lgal::gpu::AABB2d result = lgal::gpu::AABB2d::nothing();
		struct segmentPos { gpu_float_t length, position; };
		std::vector<segmentPos> segments;

		size_t segmentIdx = 0;
		lgal::gpu::LineSegment2 segment = getPathSegment(screenPath, segmentIdx);

		gpu_float_t textOffset = 0;
		gpu_float_t segmentStart = 0;
		gpu_float_t segmentLength = segment.length();
		gpu_float_t segmentEnd = segmentLength;

		auto fntMgr = mFontManager.lock();
		ONYX_ASSERT(fntMgr, "Font Manager was destroyed before text buffer");

		auto const& fontInfo = fntMgr->getFontInfo(_fontHandle);

		lgal::gpu::Vector2 pathPos = screenPath.front().xy;
		auto vertOffset = 0.f;

		if ((position & (onyx::Styling::Anchor::ABOVE | onyx::Styling::Anchor::BELOW)) == 0)
		{
			vertOffset = gpu_float_t(fontInfo.pixelSize) * 0.75f; // TODO (scott CSONYX-157) This should be driven by the font style, but it looks good for most cases now
		}
		else if ((position & onyx::Styling::Anchor::ABOVE) != 0)
		{
			vertOffset = gpu_float_t(fontInfo.pixelSize);
		}

		auto labelLength = textLength(_fontHandle, _string, kerningModifier, _end);

		segments.reserve(screenPath.size() - 1);
		gpu_float_t pathLength = 0;
		for (size_t segIdx = 0; segIdx < screenPath.size() - 1; ++segIdx)
		{
			auto seg = getPathSegment(screenPath, segIdx);
			segments.push_back({ seg.length(), pathLength });
			pathLength += segments.back().length;
		}

		if (labelLength.screenLength > pathLength)
		{
			return result;
		}

		if ((position & onyx::Styling::Anchor::LEFT) == 0) // Don't need to shift anything for left alignment
		{
			textOffset = (pathLength - labelLength.screenLength);

			if ((position & onyx::Styling::Anchor::RIGHT) == 0) // horizontal center alignment
			{
				textOffset *= 0.5f;
			}
		}

		auto endSegmentIdx = getPathSegmentAtLength(screenPath, labelLength.screenLength + textOffset);

		auto lastSegment = getPathSegment(screenPath, endSegmentIdx, false);

		bool forward = keepUpright ? segment.start.x <= lastSegment.start.x : true;
		if (!forward)
		{
			segmentIdx = endSegmentIdx;
			segment = lastSegment;
			segmentEnd = lastSegment.length();
			pathPos = segment.start;
		}

		auto segmentZ = getSegmentZ(screenPath, segmentIdx, forward);

		auto end = _end != nullptr
			? _end
			: _string + getStrLen(_string);

		CodePoint codepoint = 0;
		uint32_t state = 0;

		auto startVertex = m_vertexCount;
		auto indexOffset = uint16_t((labelLength.glyphCount * 6) - 6);

		memset(&m_indexBuffer[m_indexCount], 0, sizeof(m_indexBuffer[0]) * labelLength.glyphCount * 6 * 2);

		bool setPenState = true;
		// TODO (scott CSONYX-155) improve the placement of glyphs that intersect path segment endpoints
		for (charT const* _current = _string; *_current && _current < end; ++_current)
		{
			if (decode(state, codepoint, _current) == UTF8::ACCEPT)
			{
				auto glyph = fntMgr->getGlyphInfo(_fontHandle, codepoint);

				if (glyph == nullptr)
				{
					continue;
				}

				auto segmentPos = (textOffset - segmentStart) / segmentLength;

				float kerning = fntMgr->getKerning(_fontHandle, m_penState.prevCodePoint, codepoint) + kerningModifier;
				auto glyphEnd = textOffset + glyph->advance_x + kerning;
				if (glyphEnd > segmentEnd && segmentIdx < segments.size())
				{
					do
					{

						segmentIdx += forward ? 1 : -1;
						if (segmentIdx >= segments.size())
						{
							break;
						}

						auto nextSeg = segments[segmentIdx];

						segmentStart = segmentEnd;
						segmentEnd += nextSeg.length;
						segmentLength = nextSeg.length;

						if (glyphEnd <= segmentEnd)
						{
							segment = getPathSegment(screenPath, segmentIdx, forward);
						}

					} while (glyphEnd > segmentEnd && segmentIdx < segments.size());

					if (glyphEnd > segmentEnd)
					{
						break; // No more space for the label; bail.  Ideally we should have never started
					}

					setPenState = true;
				}

				if (setPenState)
				{
					setTextDirection(segment.direction());

					setPenState = false;

					pathPos = segment.position(textOffset - segmentStart);

					if (vertOffset != 0.f)
					{
						pathPos = pathPos - (m_newLineDirection * vertOffset);
					}

					setPenPosition(pathPos);
				}


				m_penState.depth = lmath::lerp(segmentZ.begin, segmentZ.end, segmentPos);

				// Append the shadow glyph; save the pen state so that we can reset the position for the actual glyph
				auto saveState = m_penState;
				appendGlyph(_fontHandle, codepoint, true, kerningModifier);

				m_penState = saveState;
				m_indexCount += indexOffset;
				// Append the actual glyph
				appendGlyph(_fontHandle, codepoint, false, kerningModifier);
				m_indexCount -= (indexOffset + 6);

				textOffset = glyphEnd;
			}
		}

		m_indexCount += indexOffset + 6;

		for (auto v = &m_vertexBuffer[startVertex]; v < &m_vertexBuffer[m_vertexCount]; ++v)
		{
			result = result.fit(v->pos.xy);
		}

		return result;
	}

	template <typename charT>
	lgal::gpu::AABB2d appendText(FontHandle _fontHandle, const charT* _string, float kerningModifier, const charT* _end, bool measure = false)
	{
		mColors.updateColors(mStyle);
		if (m_vertexCount == 0)
		{
			m_origin = m_penState.position;
			m_lineDescender = 0;
			m_lineAscender = 0;
			m_lineGap = 0;
			m_penState.prevCodePoint = 0;
			m_penState.rectangle = { 0, 0 };
		}

		auto savedOrigin = m_origin;
		auto savedLineDescender = m_lineDescender;
		auto savedLineAscender = m_lineAscender;
		auto savedLineGap = m_lineGap;
		auto savedPenState = m_penState;
		auto savedDirection = m_direction;
		auto savedNewLineDirection = m_newLineDirection;

		if (measure)
		{
			m_penState = PenState::empty();
			m_direction = { 1, 0 };
			m_newLineDirection = { 0, 1 };
			m_origin = { 0, 0 };

			m_lineStartIndex = 0;
			m_lineAscender = 0;
			m_lineDescender = 0;
			m_lineGap = 0;
		}

		auto startVertex = m_vertexCount;

		CodePoint codepoint = 0;
		uint32_t state = 0;

		auto end = _end != nullptr
			? _end
			: _string + getStrLen(_string);
		BX_ASSERT(end >= _string, "");

		auto fntMgr = mFontManager.lock();
		ONYX_ASSERT(fntMgr, "Font Manager was destroyed before text buffer");

		const FontInfo& font = fntMgr->getFontInfo(_fontHandle);

		m_lineGap = font.lineGap;
		m_lineDescender = font.descender;
		m_lineAscender = font.ascender;

		bool hasMaskDistShadow = (font.fontType & onyx::Styling::TextFontTypes::MaskDistanceShadow) != onyx::Styling::TextFontTypes::Empty;

		if (hasMaskDistShadow && !measure)
		{
			auto saveState = m_penState;

			for (charT const* _current = _string; *_current && _current < end; ++_current)
			{
				if (decode(state, codepoint, _current) == UTF8::ACCEPT)
				{
					appendGlyph(_fontHandle, codepoint, true, kerningModifier, measure);
				}
			}

			m_penState = saveState;
		}

		for (charT const* _current = _string; *_current && _current < end; ++_current)
		{
			if (decode(state, codepoint, _current) == UTF8::ACCEPT)
			{
				appendGlyph(_fontHandle, codepoint, false, kerningModifier, measure);
			}
		}

		lgal::gpu::AABB2d result = lgal::gpu::AABB2d::nothing();

		if (measure)
		{
			result = result.fit(savedPenState.position);
			auto maxPos = savedPenState.position;
			maxPos.x += m_penState.rectangle.width;
			maxPos.y += m_penState.rectangle.height;
			result = result.fit(maxPos);

			m_origin = savedOrigin;
			m_penState = savedPenState;

			m_newLineDirection = savedNewLineDirection;
			m_direction = savedDirection;

			m_lineDescender = savedLineDescender;
			m_lineAscender = savedLineAscender;
			m_lineGap = savedLineGap;
			m_penState = savedPenState;
		}

		BX_ASSERT(state == UTF8::ACCEPT, "The string is not well-formed");

		for (auto v = &m_vertexBuffer[startVertex]; v < &m_vertexBuffer[m_vertexCount]; ++v)
		{
			result = result.fit(v->pos.xy);
		}

		return result;
	}

	/// Append a whole face of the atlas cube, mostly used for debugging
	/// and visualizing atlas.
	void appendAtlasFace(uint16_t _faceIndex);

	/// Clear the text buffer and reset its state (pen/color)
	void clearTextBuffer();

	/// Get pointer to the vertex buffer to submit it to the graphic card.
	const uint8_t* getVertexBuffer()
	{
		return (uint8_t*)m_vertexBuffer;
	}

	/// Number of vertex in the vertex buffer.
	uint32_t getVertexCount() const
	{
		return m_vertexCount;
	}

	/// Size in bytes of a vertex.
	uint32_t getVertexSize() const
	{
		return sizeof(TextVertex);
	}

	/// get a pointer to the index buffer to submit it to the graphic
	const uint16_t* getIndexBuffer() const
	{
		return m_indexBuffer;
	}

	/// number of index in the index buffer
	uint32_t getIndexCount() const
	{
		return m_indexCount;
	}

	/// Size in bytes of an index.
	uint32_t getIndexSize() const
	{
		return sizeof(uint16_t);
	}

	TextRectangle getRectangle() const
	{
		return m_penState.rectangle;
	}

private:
	void appendGlyph(FontHandle _handle, CodePoint _codePoint, bool shadow, float kerningModifier, bool measure = false);
	void verticalCenterLastLine(float _txtDecalY, float _top, float _bottom);

	static uint32_t toABGR(uint32_t _rgba)
	{
		return (((_rgba >> 0) & 0xff) << 24)
			| (((_rgba >> 8) & 0xff) << 16)
			| (((_rgba >> 16) & 0xff) << 8)
			| (((_rgba >> 24) & 0xff) << 0)
			;
	}

	void setVertex(uint32_t _i, lgal::gpu::Vector3 const& pos, int16_t mode, uint32_t _rgba, uint32_t _rgbaColor = 0, onyx::Styling::TextStyleFlags _style = onyx::Styling::TextStyleFlags::NORMAL);

	void setInstance(lgal::gpu::Vector2 const& screenPosPx, gpu_float_t normalizedDepth, int16_t mode, lgal::gpu::Vector2 const& screenUDir, lgal::gpu::Vector2 const& screenVDir, Atlas const* atlas, uint16_t regionIndex, uint32_t rgba, uint32_t rgbaOutline, onyx::Styling::TextStyleFlags _style = onyx::Styling::TextStyleFlags::NORMAL);

	void setOutlineColor(uint32_t _i, uint32_t _rgbaOutline)
	{
		m_vertexBuffer[_i].rgbaOutline = _rgbaOutline;
	}

	uint32_t decode(uint32_t& state, CodePoint& codePoint, char const* str)
	{
		return UTF8::decode(&state, (uint32_t*)&codePoint, *str);
	}

	uint32_t decode(uint32_t&/* state */, CodePoint& codePoint, wchar_t const* str)
	{
		codePoint = *str;
		return UTF8::Options::ACCEPT;
	}

	lgal::gpu::LineSegment2 getPathSegment(std::vector<lgal::gpu::Vector3> const& screenPath, size_t segment, bool forward = true);
	
	lgal::gpu::Range getSegmentZ(std::vector<lgal::gpu::Vector3> const& screenPath, size_t segment, bool forward = true)
	{
		return (forward) ? lgal::gpu::Range{ screenPath[segment].z, screenPath[segment + 1].z } : lgal::gpu::Range{ screenPath[segment + 1].z, screenPath[segment].z };
	}

	size_t getPathSegmentAtLength(std::vector<lgal::gpu::Vector3> const& screenPath, gpu_float_t position);
	
	size_t getStrLen(char const* str);
	size_t getStrLen(wchar_t const* str);

	struct TextVertex
	{
		lgal::gpu::Vector3 pos;
		int16_t u, v, w, t;
		int16_t u1, v1, w1, t1;
		uint32_t rgba;
		uint32_t rgbaOutline;
	};

	onyx::Styling::TextStyle mStyle;
	Colors mColors;

	bool mShadowsFollowText = false;

	// outline state
	float m_outlineWidth;

	// drop shadow state
	lgal::gpu::Vector2 m_dropShadowOffset = { 0.f };
	float m_dropShadowSoftener;

	//position states
	lgal::gpu::Vector2 m_direction = { 1, 0 },
		m_origin = { 0, 0 },
		m_newLineDirection = { 0, 1 };

	float m_lineAscender;
	float m_lineDescender;
	float m_lineGap;

	PenState m_penState = PenState::empty();

	std::weak_ptr<BgfxFontManager> mFontManager;

	TextVertex* m_vertexBuffer;
	uint16_t* m_indexBuffer;
	uint8_t* m_styleBuffer;

	uint32_t m_indexCount;
	uint32_t m_lineStartIndex;
	uint16_t m_vertexCount;
};
