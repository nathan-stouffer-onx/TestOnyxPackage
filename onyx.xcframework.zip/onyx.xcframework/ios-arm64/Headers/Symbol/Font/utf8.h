// Copyright (c) 2008-2009 Bjoern Hoehrmann <bjoern@hoehrmann.de>
// See http://bjoern.hoehrmann.de/utf-8/decoder/dfa/ for details.

#pragma once

#include <stdint.h>

namespace UTF8 {

// Still being used with its underlying value in mind, so won't use class
enum Options : uint32_t 
{
	ACCEPT = 0,
	REJECT
};

uint32_t decode(uint32_t* _state, uint32_t* _codep, uint8_t _ch);

};
