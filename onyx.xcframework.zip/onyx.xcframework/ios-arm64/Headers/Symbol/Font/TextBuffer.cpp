#include "TextBuffer.h"

#include "cube_atlas.h"

TextBuffer::TextBuffer(std::weak_ptr<BgfxFontManager> _fontManager)
	: m_outlineWidth(3.0f)
	, m_dropShadowSoftener(1.0f)
	, m_lineAscender(0)
	, m_lineDescender(0)
	, m_lineGap(0)
	, mFontManager(_fontManager)
	, m_vertexBuffer(new TextVertex[cMaxBufferedChars * 4])
	, m_indexBuffer(new uint16_t[cMaxBufferedChars * 6])
	, m_styleBuffer(new uint8_t[cMaxBufferedChars * 4])
	, m_indexCount(0)
	, m_lineStartIndex(0)
	, m_vertexCount(0)
{
}

TextBuffer::~TextBuffer()
{
	delete [] m_vertexBuffer;
	delete [] m_indexBuffer;
	delete [] m_styleBuffer;
}

void TextBuffer::setTextDirection(lgal::gpu::Vector2 const& direction, lgal::gpu::Vector2 const& linefeed)
{
	m_direction = lmath::normalize(direction);
	if (linefeed == lgal::gpu::Vector2(0))
	{
		m_newLineDirection = m_direction.rot90ccw();
	}
	else
	{
		m_newLineDirection = lmath::normalize(linefeed);
	}
}

void TextBuffer::setInstance(lgal::gpu::Vector2 const& screenPosPx, gpu_float_t normalizedDepth, int16_t mode, lgal::gpu::Vector2 const& screenUDir, lgal::gpu::Vector2 const& screenVDir, Atlas const* atlas, uint16_t regionIndex, uint32_t rgba, uint32_t rgbaOutline, onyx::Styling::TextStyleFlags _style)
{
	atlas->packUV(regionIndex
		, (uint8_t*)m_vertexBuffer
		, sizeof(TextVertex) * m_vertexCount + offsetof(TextVertex, u)
		, sizeof(TextVertex)
	);

	auto const& p0 = screenPosPx;
	auto const p1 = p0 + screenVDir;
	auto const p2 = p1 + screenUDir;
	auto const p3 = p0 + screenUDir;

	setVertex(m_vertexCount + 0, { p0, normalizedDepth }, mode, rgba, rgbaOutline, _style);
	setVertex(m_vertexCount + 1, { p1, normalizedDepth }, mode, rgba, rgbaOutline, _style);
	setVertex(m_vertexCount + 2, { p2, normalizedDepth }, mode, rgba, rgbaOutline, _style);
	setVertex(m_vertexCount + 3, { p3, normalizedDepth }, mode, rgba, rgbaOutline, _style);

	m_indexBuffer[m_indexCount + 0] = m_vertexCount + 0;
	m_indexBuffer[m_indexCount + 1] = m_vertexCount + 1;
	m_indexBuffer[m_indexCount + 2] = m_vertexCount + 2;
	m_indexBuffer[m_indexCount + 3] = m_vertexCount + 0;
	m_indexBuffer[m_indexCount + 4] = m_vertexCount + 2;
	m_indexBuffer[m_indexCount + 5] = m_vertexCount + 3;
	m_vertexCount += 4;
	m_indexCount += 6;
}

void TextBuffer::appendAtlasFace(uint16_t _faceIndex)
{
	if( m_vertexCount/4 >= cMaxBufferedChars)
	{
		return;
	}

	float x0 = m_penState.position.x;
	float y0 = m_penState.position.y;

	auto fntMgr = mFontManager.lock();
	if (!fntMgr)
	{
		ONYX_THROW("Font Manager was destroyed before textBuffer");
	}

	float x1 = x0 + (float)fntMgr->getAtlas()->getTextureSize();
	float y1 = y0 + (float)fntMgr->getAtlas()->getTextureSize();

	fntMgr->getAtlas()->packFaceLayerUV(_faceIndex
		, (uint8_t*)m_vertexBuffer
		, sizeof(TextVertex) * m_vertexCount + offsetof(TextVertex, u)
		, sizeof(TextVertex)
		);

	setVertex(m_vertexCount + 0, { x0, y0, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());
	setVertex(m_vertexCount + 1, { x0, y1, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());
	setVertex(m_vertexCount + 2, { x1, y1, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());
	setVertex(m_vertexCount + 3, { x1, y0, m_penState.depth }, MODE_NORMAL, mStyle.backgroundColor.argb());

	m_indexBuffer[m_indexCount + 0] = m_vertexCount + 0;
	m_indexBuffer[m_indexCount + 1] = m_vertexCount + 1;
	m_indexBuffer[m_indexCount + 2] = m_vertexCount + 2;
	m_indexBuffer[m_indexCount + 3] = m_vertexCount + 0;
	m_indexBuffer[m_indexCount + 4] = m_vertexCount + 2;
	m_indexBuffer[m_indexCount + 5] = m_vertexCount + 3;
	m_vertexCount += 4;
	m_indexCount += 6;
}

void TextBuffer::clearTextBuffer()
{
	m_penState = PenState::empty();
	m_origin = { 0, 0 };

	m_vertexCount = 0;
	m_indexCount = 0;
	m_lineStartIndex = 0;
	m_lineAscender = 0;
	m_lineDescender = 0;
	m_lineGap = 0;
}

void TextBuffer::appendGlyph(FontHandle _handle, CodePoint _codePoint, bool shadow, float kerningModifier, bool measure)
{
	if (m_vertexCount >> 2 >= cMaxBufferedChars)
	{
		m_penState.prevCodePoint = 0;
		return;
	}

	if (_codePoint == L'\t')
	{
		for (uint32_t ii = 0; ii < 4; ++ii)
		{
			appendGlyph(_handle, L' ', shadow, kerningModifier, measure);
		}
		return;
	}

	auto fntMgr = mFontManager.lock();
	if (!fntMgr)
	{
		ONYX_THROW("Font Manager was destroyed before text buffer");
	}
	GlyphInfo const* glyph = fntMgr->getGlyphInfo(_handle, _codePoint);
	BX_WARN(nullptr != glyph, "Glyph not found (font handle %d, code point %d)", _handle.idx, _codePoint);
	if (nullptr == glyph)
	{
		m_penState.prevCodePoint = 0;
		return;
	}

	FontInfo const& font = fntMgr->getFontInfo(_handle);

	if (_codePoint == L'\n')
	{
		m_penState.position.x = m_origin.x;
		m_penState.position.y += m_lineGap + m_lineAscender - m_lineDescender;
		m_lineGap = font.lineGap;
		m_lineDescender = font.descender;
		m_lineAscender = font.ascender;
		m_lineStartIndex = uint32_t(m_vertexCount);
		m_penState.prevCodePoint = 0;
		return;
	}

	//is there a change of font size that require the text on the left to be centered again ?
	if (m_penState.position != m_origin
		&& (font.ascender > m_lineAscender || (font.descender < m_lineDescender)))
	{
		if (font.descender < m_lineDescender)
		{
			m_lineDescender = font.descender;
			m_lineGap = font.lineGap;
		}

		float txtDecals = (font.ascender - m_lineAscender);
		m_lineAscender = font.ascender;
		m_lineGap = font.lineGap;
		if (!measure)
		{
			verticalCenterLastLine((txtDecals), (m_penState.position.y - m_lineAscender), (m_penState.position.y + m_lineAscender - m_lineDescender + m_lineGap));
		}
	}

	float kerning = fntMgr->getKerning(_handle, m_penState.prevCodePoint, _codePoint) + kerningModifier + (getOutlineWidth() * 0.5f);
	m_penState.position = m_penState.position + (kerning * m_direction);

	const GlyphInfo& blackGlyph = fntMgr->getBlackGlyph();
	const Atlas* atlas = fntMgr->getAtlas();
	const AtlasRegion& atlasRegion = atlas->getRegion(glyph->regionIndex);

	auto glyphOffset = (m_direction * glyph->offset_x) + (m_newLineDirection * glyph->offset_y);

	if (shadow)
	{
		if (!measure)
		{
			if (atlasRegion.getType() != AtlasRegion::Type::TYPE_BGRA8)
			{
				auto extraOffset = mShadowsFollowText ? (m_dropShadowOffset.x * m_direction) + (m_dropShadowOffset.y * m_newLineDirection) : m_dropShadowOffset;

				auto glyphWidth = glyph->width;
				auto glyphHeight = glyph->height;
				auto xOffset = glyphWidth * m_direction;
				auto yOffset = glyphHeight * m_newLineDirection;

				auto positionOffset = (glyphOffset + (m_lineAscender * m_newLineDirection)) + extraOffset;

				auto p0 = m_penState.position + positionOffset;

				setInstance(p0, m_penState.depth, MODE_SHADOW, xOffset, yOffset, atlas, glyph->regionIndex, mColors.dropShadowColor, 0);
			}
		}
	}
	else if (!measure)
	{
		lgal::gpu::Vector2	pos(0);
		gpu_float_t			depth = m_penState.depth;
		int16_t				mode = MODE_NORMAL;
		lgal::gpu::Vector2	screenUDir(0),
			screenVDir(0);
		uint32_t			glyphColor = 0,
			outlineColor = 0;

		if ((mStyle.flags & onyx::Styling::TextStyleFlags::BACKGROUND) != 0
			&& mColors.backgroundColor & 0xff000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * (m_lineAscender - m_lineDescender + m_lineGap);

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, mColors.backgroundColor, 0, onyx::Styling::TextStyleFlags::BACKGROUND);
		}

		if ((mStyle.flags & onyx::Styling::TextStyleFlags::UNDERLINE) != 0
			&& mColors.underlineColor & 0xFF000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);
			pos = pos + ((m_lineAscender - m_lineDescender * 0.5f) * m_newLineDirection);

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * font.underlineThickness;

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, mColors.underlineColor, 0, onyx::Styling::TextStyleFlags::UNDERLINE);
		}

		if ((mStyle.flags & onyx::Styling::TextStyleFlags::OVERLINE) != 0
			&& mColors.overlineColor & 0xFF000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);
			pos = pos + font.underlineThickness * m_newLineDirection;

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * font.underlineThickness;

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, mColors.overlineColor, 0, onyx::Styling::TextStyleFlags::OVERLINE);
		}

		if (!shadow && atlasRegion.getType() == AtlasRegion::Type::TYPE_BGRA8)
		{
			mode = MODE_BGRA8;

			auto glyphScale = glyph->bitmapScale;
			auto glyphWidth = glyph->width * glyphScale;
			auto glyphHeight = glyph->height * glyphScale;

			pos = m_penState.position;
			pos = pos + (glyph->offset_x * m_direction);
			pos = pos + (font.ascender - font.descender - glyphHeight) * 0.5f * m_newLineDirection;

			screenUDir = m_direction * glyphWidth;
			screenVDir = m_newLineDirection * glyphHeight;

			glyphColor = mColors.textColor;
		}
		else
		{
			pos = m_penState.position + (glyphOffset + (m_lineAscender * m_newLineDirection));

			screenUDir = m_direction * glyph->width;
			screenVDir = m_newLineDirection * glyph->height;

			glyphColor = mColors.textColor;
			outlineColor = mColors.outlineColor;
		}

		setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, glyph->regionIndex, glyphColor, outlineColor);

		if ((mStyle.flags & onyx::Styling::TextStyleFlags::STRIKE_THROUGH) != 0
			&& mColors.strikethroughColor & 0xFF000000)
		{
			pos = m_penState.position;
			pos = pos - (kerning * m_direction);
			pos = pos + (font.ascender * 0.666667f) * m_newLineDirection;

			screenUDir = m_direction * glyph->advance_x;
			screenVDir = m_newLineDirection * font.underlineThickness;

			setInstance(pos, depth, mode, screenUDir, screenVDir, atlas, blackGlyph.regionIndex, mColors.strikethroughColor, 0, onyx::Styling::TextStyleFlags::STRIKE_THROUGH);
		}
	}

	m_penState.position = m_penState.position + (glyph->advance_x * m_direction);
	auto newWidth = m_penState.position.x - m_origin.x;
	m_penState.rectangle.width = std::max(m_penState.rectangle.width, newWidth);
	auto newHeight = shadow ? m_penState.position.y + (glyph->height) - m_origin.y :
		(m_penState.position.y + (m_lineAscender - m_lineDescender + m_lineGap)) - m_origin.y;
	m_penState.rectangle.height = std::max(m_penState.rectangle.height, newHeight);

	m_penState.prevCodePoint = _codePoint;
}

void TextBuffer::verticalCenterLastLine(float _dy, float _top, float _bottom)
{
	for (uint32_t ii = m_lineStartIndex; ii < m_vertexCount; ii += 4)
	{
		if (m_styleBuffer[ii] == onyx::Styling::TextStyleFlags::BACKGROUND)
		{
			m_vertexBuffer[ii + 0].pos.y = _top;
			m_vertexBuffer[ii + 1].pos.y = _bottom;
			m_vertexBuffer[ii + 2].pos.y = _bottom;
			m_vertexBuffer[ii + 3].pos.y = _top;
		}
		else
		{
			m_vertexBuffer[ii + 0].pos.y += _dy;
			m_vertexBuffer[ii + 1].pos.y += _dy;
			m_vertexBuffer[ii + 2].pos.y += _dy;
			m_vertexBuffer[ii + 3].pos.y += _dy;
		}
	}
}

void TextBuffer::setVertex(uint32_t _i, lgal::gpu::Vector3 const& pos, int16_t mode, uint32_t _rgba, uint32_t _rgbaColor, onyx::Styling::TextStyleFlags _style)
{
	m_vertexBuffer[_i].pos = pos;
	m_vertexBuffer[_i].rgba = _rgba;
	m_vertexBuffer[_i].rgbaOutline = _rgbaColor;
	m_vertexBuffer[_i].t1 = mode;

	m_styleBuffer[_i] = uint8_t(_style);
}

lgal::gpu::LineSegment2 TextBuffer::getPathSegment(std::vector<lgal::gpu::Vector3> const& screenPath, size_t segment, bool forward)
{
	if (screenPath.size() < 2)
	{
		return { { 0, 0 }, { 1, 0 } }; // If not enough segments, just choose a horizontal line.
	}

	if (screenPath.size() > segment + 1)
	{
		return (forward) ? lgal::gpu::LineSegment2{ screenPath[segment].xy, screenPath[segment + 1].xy } : lgal::gpu::LineSegment2{ screenPath[segment + 1].xy, screenPath[segment].xy };
	}

	return { { 0, 0 }, { 0, 0 } };
}

size_t TextBuffer::getPathSegmentAtLength(std::vector<lgal::gpu::Vector3> const& screenPath, gpu_float_t position)
{
	if (screenPath.size() < 2)
	{
		return 0; // If not enough segments, just choose a horizontal line.
	}

	gpu_float_t pos = 0;
	lgal::gpu::Vector2 p1 = screenPath.front().xy;
	auto iter = screenPath.begin() + 1;
	size_t result = 0;
	while (pos < position)
	{
		lgal::gpu::LineSegment2 seg = { p1, (*iter).xy };
		pos += seg.length();
		++iter;
		if (pos >= position || iter == screenPath.end())
		{
			return result;
		}
		++result;
		p1 = seg.end;
	}
	return result;
}

size_t TextBuffer::getStrLen(char const* str)
{
	return bx::strLen(str);
}

size_t TextBuffer::getStrLen(wchar_t const* str)
{
	return wcslen(str);
}

