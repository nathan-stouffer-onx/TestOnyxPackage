/*
 * Copyright 2013 Jeremie Roy. All rights reserved.
 * License: https://github.com/bkaradzic/bgfx#license-bsd-2-clause
 */
#pragma once

#include <memory>

#include <lucid/gal/Types.h>
#include <Styling/Styles/TextStyle.h>

#include "TextBuffer.h"

// TODO (Ronald): I'd much rather let the TextBuffer itself do more of the heavy lifting.
class TextBufferManager
{
public:
	
	static constexpr size_t cMaxTextBufferCnt = 2048;

	TextBufferManager(std::weak_ptr<BgfxFontManager> _fontManager);
	~TextBufferManager();

	TextBufferHandle createTextBuffer(onyx::Styling::TextFontTypes _type, TextBuffer::Type _bufferType);
	void destroyTextBuffer(TextBufferHandle _handle);
	void submitTextBuffer(TextBufferHandle _handle, bgfx::ViewId _id, int32_t _depth = 0);

	void setStyle(TextBufferHandle _handle, onyx::Styling::TextStyle const& style);
	void setAlpha(TextBufferHandle _handle, gpu_float_t alpha);

	void setOutlineWidth(TextBufferHandle _handle, float _outlineWidth = 3.0f);

	void setDropShadowOffset(TextBufferHandle _handle, float _u, float _v);
	void setDropShadowSoftener(TextBufferHandle _handle, float smoother = 1.0f);

	void setPenDepth(TextBufferHandle _handle, gpu_float_t depth);
	void setPenPosition(TextBufferHandle _handle, lgal::gpu::Vector3 const& position);
	void setTextDirection(TextBufferHandle _handle, lgal::gpu::Vector2 const& direction, lgal::gpu::Vector2 const& linefeed = { 0, 0 });

	lgal::gpu::AABB2d measureText(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end = nullptr);
	lgal::gpu::AABB2d measureText(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end = nullptr);
	lgal::gpu::AABB2d measureText(TextBufferHandle _handle, FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const char* _string, float kerningModifier, const char* _end = nullptr, onyx::Styling::Anchor position = onyx::Styling::Anchor::DEFAULT);

	float textLength(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end);
	float textLength(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end);

	void setPixelSize(TextBufferHandle _handle, FontHandle _fontHandle);

	lgal::gpu::AABB2d layoutText(TextBufferHandle _handle, FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const char* _string, float kerningModifier, const char* _end = nullptr, onyx::Styling::Anchor position = onyx::Styling::Anchor::DEFAULT, bool keepUpright = true);

	/// Append an ASCII/utf-8 string to the buffer using current pen position and color.
	lgal::gpu::AABB2d appendText(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier = 0, const char* _end = nullptr);

	/// Append a wide char unicode string to the buffer using current pen position and color.
	lgal::gpu::AABB2d appendText(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier = 0, const wchar_t* _end = nullptr);

	/// Append a whole face of the atlas cube, mostly used for debugging and visualizing atlas.
	void appendAtlasFace(TextBufferHandle _handle, uint16_t _faceIndex);

	/// Clear the text buffer and reset its state (pen/color).
	void clearTextBuffer(TextBufferHandle _handle);

	/// Return the rectangular size of the current text buffer (including all its content).
	TextRectangle getRectangle(TextBufferHandle _handle) const;

	TextBuffer& getTextBuffer(TextBufferHandle _handle) const
	{
		BX_ASSERT(isValid(_handle), "Invalid handle used");
		return *m_textBuffers[_handle.idx].textBuffer;
	}

private:
	struct BufferCache
	{
		uint16_t indexBufferHandleIdx;
		uint16_t vertexBufferHandleIdx;
		TextBuffer* textBuffer = nullptr;
		TextBuffer::Type bufferType;
		onyx::Styling::TextFontTypes fontType;
		gpu_float_t pixelSize;
	};

	BufferCache* m_textBuffers;
	bx::HandleAllocT<cMaxTextBufferCnt> m_textBufferHandles;
	std::weak_ptr<BgfxFontManager> m_fontManager;
	bgfx::VertexLayout m_vertexLayout;
	bgfx::UniformHandle s_texColor = BGFX_INVALID_HANDLE;
	bgfx::UniformHandle u_dropShadowColor = BGFX_INVALID_HANDLE;
	bgfx::UniformHandle u_sdfParams = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_basicProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceSubpixelProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceOutlineProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceOutlineImageProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceDropShadowProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceDropShadowImageProgram = BGFX_INVALID_HANDLE;
	bgfx::ProgramHandle m_distanceOutlineDropShadowImageProgram = BGFX_INVALID_HANDLE;
};
