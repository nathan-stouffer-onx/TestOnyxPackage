#include "DefaultFonts.h"

#include <Styling/Enums.h>

// This include defines the robotoRegular/Mono byte arrays.
#include <3rdParty/imgui/imgui.h>

namespace onyx::Font {

extern const std::string s_topoLabel = "topoLabel";
extern const std::string s_topoLabelId = "default";

extern const std::string s_atlasGrotesk = "atlas grotesk";
extern const std::string s_atlasGroteskFile = "assets/font/AtlasGrotesk-Thin.otf";

extern const std::string s_montefiore = "montefiore";
extern const std::string s_montefiorePath = "assets/font/Montefiore-BoldCondensed.otf";

extern const std::string s_robotoMono = "roboto mono";

BgfxFontManager::FontConfiguration getRobotoRegularConfig()
{
	BgfxFontManager::FontConfiguration config;

	config.fileName = "roboto regular";
	config.fontBytes = s_robotoRegularTtf;
	config.fontDataSize = s_robotoRegularTtf_size;

	config.typefaceIndex = 0;
	config.pixelSize = 12;
	config.fontType = onyx::Styling::TextFontTypes::DistanceOutlineShadowImage;
	config.glyphWidthPadding = (6 + 2);
	config.glyphHeightPadding = (6 + 2);

	return config;
}

}