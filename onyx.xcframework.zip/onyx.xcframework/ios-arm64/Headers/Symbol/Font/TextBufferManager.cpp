/*
 * Copyright 2013 Jeremie Roy. All rights reserved.
 * License: https://github.com/bkaradzic/bgfx#license-bsd-2-clause
 */

#include "TextBufferManager.h"

#include <bgfx/bgfx.h>

#include <Shaders/Handwritten.h>
#include <Shaders/Load.h>

#include "cube_atlas.h"

namespace styling = onyx::Styling;

TextBufferManager::TextBufferManager(std::weak_ptr<BgfxFontManager> _fontManager)
	: m_fontManager(_fontManager)
{
	m_textBuffers = new BufferCache[cMaxTextBufferCnt];

	m_vertexLayout
		.begin()
		.add(bgfx::Attrib::Position,  3, bgfx::AttribType::Float)			// 12
		.add(bgfx::Attrib::TexCoord7, 4, bgfx::AttribType::Int16, true)		// 8
		.add(bgfx::Attrib::TexCoord6, 4, bgfx::AttribType::Int16, true)		// 8
		.add(bgfx::Attrib::TexCoord5, 4, bgfx::AttribType::Uint8, true)		// 4
		.add(bgfx::Attrib::TexCoord4, 4, bgfx::AttribType::Uint8, true)		// 4
		.end();

	bgfx::createVertexLayout(m_vertexLayout);

	s_texColor = bgfx::createUniform("s_texColor", bgfx::UniformType::Sampler);
	u_dropShadowColor = bgfx::createUniform("u_dropShadowColor", bgfx::UniformType::Vec4);
	u_sdfParams = bgfx::createUniform("u_sdfParams", bgfx::UniformType::Vec4);
}

TextBufferManager::~TextBufferManager()
{
	BX_ASSERT(m_textBufferHandles.getNumHandles() == 0, "All the text buffers must be destroyed before destroying the manager");
	delete [] m_textBuffers;

	mFontProgram = onyx::Shaders::Program();

	if(bgfx::isValid(u_sdfParams))
		bgfx::destroy(u_sdfParams);

	if (bgfx::isValid(u_dropShadowColor))
		bgfx::destroy(u_dropShadowColor);
	if (bgfx::isValid(s_texColor))
		bgfx::destroy(s_texColor);

	if (bgfx::isValid(m_basicProgram))
		bgfx::destroy(m_basicProgram);
	if (bgfx::isValid(m_distanceProgram))
		bgfx::destroy(m_distanceProgram);
	if (bgfx::isValid(m_distanceSubpixelProgram))
		bgfx::destroy(m_distanceSubpixelProgram);
	if (bgfx::isValid(m_distanceOutlineProgram))
		bgfx::destroy(m_distanceOutlineProgram);
	if (bgfx::isValid(m_distanceOutlineImageProgram))
		bgfx::destroy(m_distanceOutlineImageProgram);
	if (bgfx::isValid(m_distanceDropShadowProgram))
		bgfx::destroy(m_distanceDropShadowProgram);
	if (bgfx::isValid(m_distanceDropShadowImageProgram))
		bgfx::destroy(m_distanceDropShadowImageProgram);
	if (bgfx::isValid(m_distanceOutlineDropShadowImageProgram))
		bgfx::destroy(m_distanceOutlineDropShadowImageProgram);
}

TextBufferHandle TextBufferManager::createTextBuffer(onyx::Styling::TextFontTypes _type, TextBuffer::Type _bufferType)
{
	uint16_t textIdx = m_textBufferHandles.alloc();
	if (textIdx == bgfx::kInvalidHandle)
	{
		return { textIdx };
	}

	BufferCache& bc = m_textBuffers[textIdx];

	bc.textBuffer = new TextBuffer(m_fontManager);
	bc.fontType = _type;
	bc.bufferType = _bufferType;
	bc.indexBufferHandleIdx = bgfx::kInvalidHandle;
	bc.vertexBufferHandleIdx = bgfx::kInvalidHandle;

	TextBufferHandle ret = {textIdx};
	return ret;
}

void TextBufferManager::destroyTextBuffer(TextBufferHandle _handle)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");

	BufferCache& bc = m_textBuffers[_handle.idx];
	m_textBufferHandles.free(_handle.idx);
	if (bc.textBuffer != nullptr)
	{
		delete bc.textBuffer;
	}
	bc.textBuffer = nullptr;

	if (bc.vertexBufferHandleIdx == bgfx::kInvalidHandle)
	{
		return;
	}

	switch (bc.bufferType)
	{
	case TextBuffer::Type::Static:
		{
			bgfx::IndexBufferHandle ibh;
			bgfx::VertexBufferHandle vbh;
			ibh.idx = bc.indexBufferHandleIdx;
			vbh.idx = bc.vertexBufferHandleIdx;
			bgfx::destroy(ibh);
			bgfx::destroy(vbh);
		}

		break;

	case TextBuffer::Type::Dynamic:
		bgfx::DynamicIndexBufferHandle ibh;
		bgfx::DynamicVertexBufferHandle vbh;
		ibh.idx = bc.indexBufferHandleIdx;
		vbh.idx = bc.vertexBufferHandleIdx;
		bgfx::destroy(ibh);
		bgfx::destroy(vbh);

		break;

	case TextBuffer::Type::Transient: // destroyed every frame
		break;
	}
}

void TextBufferManager::submitTextBuffer(TextBufferHandle _handle, bgfx::ViewId _id, int32_t _depth)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");

	BufferCache& bc = m_textBuffers[_handle.idx];

	uint32_t indexSize  = bc.textBuffer->getIndexCount()  * bc.textBuffer->getIndexSize();
	uint32_t vertexSize = bc.textBuffer->getVertexCount() * bc.textBuffer->getVertexSize();

	if (0 == indexSize || 0 == vertexSize)
	{
		return;
	}

	uint64_t flags = 0
		| BGFX_STATE_WRITE_RGB
		| BGFX_STATE_BLEND_FUNC(BGFX_STATE_BLEND_SRC_ALPHA, BGFX_STATE_BLEND_INV_SRC_ALPHA);

	auto fntMgr = m_fontManager.lock();
	if (!fntMgr)
	{
		ONYX_THROW("Font Manager was destroyed before TextBufferManager");
	}

	bgfx::setTexture(0, s_texColor, fntMgr->getAtlas()->getTextureHandle() );

	if (!mFontProgram.isValid()) { mFontProgram = onyx::Shaders::load(onyx::Shaders::Handwritten::cFontSDF, false); }
	bgfx::ProgramHandle program = mFontProgram.handle();

	using FontType = onyx::Styling::TextFontTypes;

	auto const colors = bc.textBuffer->getColors();

	switch (bc.fontType)
	{
	case FontType::Empty:
	case FontType::Alpha:
	case FontType::LCD:
	case FontType::MaskDistanceImage:
	case FontType::MaskDistanceShadow:
		logE("submitTextBuffer: unsupported FontType");
		break;

	case FontType::Distance:
	{
		float params[4] = { bc.pixelSize, (float)fntMgr->getAtlas()->getTextureSize() / 512.0f, 0.0f, 0.0f };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	case FontType::DistanceSubpixel:
		flags |= colors.textColor;
		break;

	case FontType::DistanceOutline:
	case FontType::DistanceOutlineImage:
	{
		float params[4] = { bc.pixelSize, (float)fntMgr->getAtlas()->getTextureSize() / 512.0f, 0.0f, bc.textBuffer->getOutlineWidth() };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	case FontType::DistanceShadow:
	case FontType::DistanceShadowImage:
	{
		uint32_t dropShadowColor = colors.dropShadowColor;
		float dropShadowColorVec[4] = { ((dropShadowColor >> 16) & 0xff) / 255.0f, ((dropShadowColor >> 8) & 0xff) / 255.0f, (dropShadowColor & 0xff) / 255.0f, (dropShadowColor >> 24) / 255.0f };
		bgfx::setUniform(u_dropShadowColor, &dropShadowColorVec);

		float params[4] = { bc.pixelSize, (float)fntMgr->getAtlas()->getTextureSize() / 512.0f, bc.textBuffer->getDropShadowSoftener(), 0.0 };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	case FontType::DistanceOutlineShadowImage:
	{
		uint32_t dropShadowColor = colors.dropShadowColor;
		float dropShadowColorVec[4] = { ((dropShadowColor >> 16) & 0xff) / 255.0f, ((dropShadowColor >> 8) & 0xff) / 255.0f, (dropShadowColor & 0xff) / 255.0f, (dropShadowColor >> 24) / 255.0f };
		bgfx::setUniform(u_dropShadowColor, &dropShadowColorVec);

		float params[4] = { bc.pixelSize, (float)fntMgr->getAtlas()->getTextureSize() / 512.0f, bc.textBuffer->getDropShadowSoftener(), bc.textBuffer->getOutlineWidth() };
		bgfx::setUniform(u_sdfParams, &params);
		break;
	}

	}

	switch (bc.bufferType)
	{
	case TextBuffer::Type::Static:
		{
			bgfx::IndexBufferHandle ibh;
			bgfx::VertexBufferHandle vbh;

			if (bgfx::kInvalidHandle == bc.vertexBufferHandleIdx)
			{
				ibh = bgfx::createIndexBuffer(
								bgfx::copy(bc.textBuffer->getIndexBuffer(), indexSize)
								);

				vbh = bgfx::createVertexBuffer(
								  bgfx::copy(bc.textBuffer->getVertexBuffer(), vertexSize)
								, m_vertexLayout
								);

				bc.vertexBufferHandleIdx = vbh.idx;
				bc.indexBufferHandleIdx = ibh.idx;
			}
			else
			{
				vbh.idx = bc.vertexBufferHandleIdx;
				ibh.idx = bc.indexBufferHandleIdx;
			}

			bgfx::setVertexBuffer(0, vbh, 0, bc.textBuffer->getVertexCount() );
			bgfx::setIndexBuffer(ibh, 0, bc.textBuffer->getIndexCount() );
		}
		break;

	case TextBuffer::Type::Dynamic:
		{
			bgfx::DynamicIndexBufferHandle ibh;
			bgfx::DynamicVertexBufferHandle vbh;

			if (bgfx::kInvalidHandle == bc.vertexBufferHandleIdx )
			{
				ibh = bgfx::createDynamicIndexBuffer(
								bgfx::copy(bc.textBuffer->getIndexBuffer(), indexSize)
								);

				vbh = bgfx::createDynamicVertexBuffer(
								  bgfx::copy(bc.textBuffer->getVertexBuffer(), vertexSize)
								, m_vertexLayout
								);

				bc.indexBufferHandleIdx = ibh.idx;
				bc.vertexBufferHandleIdx = vbh.idx;
			}
			else
			{
				ibh.idx = bc.indexBufferHandleIdx;
				vbh.idx = bc.vertexBufferHandleIdx;

				bgfx::update(
					  ibh
					, 0
					, bgfx::copy(bc.textBuffer->getIndexBuffer(), indexSize)
					);

				bgfx::update(
					  vbh
					, 0
					, bgfx::copy(bc.textBuffer->getVertexBuffer(), vertexSize)
					);
			}

			bgfx::setVertexBuffer(0, vbh, 0, bc.textBuffer->getVertexCount() );
			bgfx::setIndexBuffer(ibh, 0, bc.textBuffer->getIndexCount() );
		}
		break;

	case TextBuffer::Type::Transient:
		{
			bgfx::TransientIndexBuffer tib;
			bgfx::TransientVertexBuffer tvb;

			auto vertexCount = bc.textBuffer->getVertexCount();

			auto availableIdx = bgfx::getAvailTransientIndexBuffer(bc.textBuffer->getIndexCount());
			auto availableVtx = bgfx::getAvailTransientVertexBuffer(vertexCount, m_vertexLayout);
			
			// BUG (scott) I've seen crashes here twice now where getAvailTransientVertexBuffer() returns an invalid vertex
			// count greater than the requested number of vertices.  Putting this here to try to catch that.
			if (vertexCount < availableVtx)
			{
				ONYX_THROW("WTF?");
			}
			if (availableIdx == 0 || availableVtx == 0)
			{
				break;
			}

			bgfx::allocTransientIndexBuffer(&tib, availableIdx);
			bgfx::allocTransientVertexBuffer(&tvb, availableVtx, m_vertexLayout);

			bx::memCopy(tib.data, bc.textBuffer->getIndexBuffer(), std::min(tib.size, indexSize));
			bx::memCopy(tvb.data, bc.textBuffer->getVertexBuffer(), std::min(tvb.size, vertexSize));
			bgfx::setVertexBuffer(0, &tvb, 0, availableVtx);
			bgfx::setIndexBuffer(&tib, 0, availableIdx);
		}
		break;
	}

	bgfx::setState(flags | BGFX_STATE_DEPTH_TEST_LEQUAL);

	bgfx::submit(_id, program, _depth);
}

void TextBufferManager::setStyle(TextBufferHandle _handle, styling::TextStyle const& style)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setStyle(style);
}

void TextBufferManager::setAlpha(TextBufferHandle _handle, gpu_float_t alpha)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setAlpha(alpha);
}

void TextBufferManager::setOutlineWidth(TextBufferHandle _handle, float _outlineWidth)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setOutlineWidth(_outlineWidth);
}

void TextBufferManager::setDropShadowOffset(TextBufferHandle _handle, float _u, float _v)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setDropShadowOffset(_u, _v);
}

void TextBufferManager::setDropShadowSoftener(TextBufferHandle _handle, float smoother)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setDropShadowSoftener(smoother);
}

void TextBufferManager::setPenDepth(TextBufferHandle _handle, gpu_float_t depth)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setPenDepth(depth);
}

void TextBufferManager::setPenPosition(TextBufferHandle _handle, lgal::gpu::Vector3 const& position)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setPenPosition(position.xy);
	bc.textBuffer->setPenDepth(position.z);
}

void TextBufferManager::setTextDirection(TextBufferHandle _handle, lgal::gpu::Vector2 const& direction, lgal::gpu::Vector2 const& linefeed)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->setTextDirection(direction, linefeed);
}

lgal::gpu::AABB2d TextBufferManager::measureText(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end, true);
}

lgal::gpu::AABB2d TextBufferManager::measureText(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end, true);
}

float TextBufferManager::textLength(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->textLength(_fontHandle, _string, kerningModifier, _end).screenLength;
}

float TextBufferManager::textLength(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->textLength(_fontHandle, _string, kerningModifier, _end).screenLength;
}

void TextBufferManager::setPixelSize(TextBufferHandle _handle, FontHandle _fontHandle)
{
	BufferCache& bc = m_textBuffers[_handle.idx];
	auto fontMgr = m_fontManager.lock();
	if (fontMgr)
	{
		auto const& fontInfo = fontMgr->getFontInfo(_fontHandle);
		bc.pixelSize = fontInfo.pixelSize;
	}
}

lgal::gpu::AABB2d TextBufferManager::layoutText(TextBufferHandle _handle, FontHandle _fontHandle, std::vector<lgal::gpu::Vector3> const& screenPath, const char* _string, float kerningModifier, const char* _end, styling::Anchor position, bool keepUpright)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->layoutText(_fontHandle, screenPath, _string, kerningModifier, _end, position, keepUpright);
}

lgal::gpu::AABB2d TextBufferManager::appendText(TextBufferHandle _handle, FontHandle _fontHandle, const char* _string, float kerningModifier, const char* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end);
}

lgal::gpu::AABB2d TextBufferManager::appendText(TextBufferHandle _handle, FontHandle _fontHandle, const wchar_t* _string, float kerningModifier, const wchar_t* _end)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->appendText(_fontHandle, _string, kerningModifier, _end);
}

void TextBufferManager::appendAtlasFace(TextBufferHandle _handle, uint16_t _faceIndex)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->appendAtlasFace(_faceIndex);
}

void TextBufferManager::clearTextBuffer(TextBufferHandle _handle)
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	bc.textBuffer->clearTextBuffer();
}

TextRectangle TextBufferManager::getRectangle(TextBufferHandle _handle) const
{
	BX_ASSERT(isValid(_handle), "Invalid handle used");
	BufferCache& bc = m_textBuffers[_handle.idx];
	return bc.textBuffer->getRectangle();
}
