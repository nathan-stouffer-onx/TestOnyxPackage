#include "FontManager.h"

#include <set>

#include <System/FileSystem.h>
#include <System/OnyxException.h>

namespace onyx::Font {

	std::string const sDefaultFont = "default";
	std::unordered_map<Styling::FontFace, FontHandle> sFonts;
	std::unordered_map<std::string, TrueTypeHandle> sFontTTF;
	std::shared_ptr<BgfxFontManager> M3DFontManager::sBgfxFontManager;

	void M3DFontManager::initialize(BgfxFontManager::FontConfiguration const& defaultFont)
	{
		sBgfxFontManager = std::make_shared<BgfxFontManager>((uint16_t)512);
		Styling::FontFace face = { sDefaultFont, defaultFont.pixelSize, defaultFont.fontType };
		
		ONYX_ASSERT(!defaultFont.fileName.empty(), "default font file name cannot be empty");

		if (defaultFont.fontBytes == nullptr)
		{
			addTTF(face.name, defaultFont.fileName);
		}
		else
		{
			addTTF(face.name, defaultFont.fontBytes, defaultFont.fontDataSize);
		}

		sFontTTF[defaultFont.fileName] = sFontTTF[face.name];

		auto handle = sBgfxFontManager->createFontByPixelSize(sFontTTF[face.name], defaultFont.typefaceIndex, defaultFont.pixelSize, defaultFont.fontType, defaultFont.glyphWidthPadding, defaultFont.glyphHeightPadding);
		ONYX_ASSERT(handle.idx != bgfx::kInvalidHandle, "Unable to create sized font");
		sFonts[face] = handle;
		face.pixelSize = 0;
		sFonts[face] = handle;
	}

	void M3DFontManager::Shutdown()
	{
		// keep track of which handles have already been destroyed, for fonts that 
		// get assigned to the default font because they are not otherwise available
		std::set<uint16_t> destroyedFonts;
		for (auto& [name, handle] : sFonts)
		{
			if (handle.idx != bgfx::kInvalidHandle && destroyedFonts.find(handle.idx) == destroyedFonts.end())
			{
				sBgfxFontManager->destroyFont(handle);
				destroyedFonts.insert(handle.idx);
			}
		}

		std::set<uint16_t> destroyedTtfs;	
		for (auto& [name, handle] : sFontTTF)
		{
			if (handle.idx != bgfx::kInvalidHandle && destroyedTtfs.find(handle.idx) == destroyedTtfs.end())
			{
				sBgfxFontManager->destroyTtf(handle);
				destroyedTtfs.insert(handle.idx);
			}
		}

		sFonts.clear();
		sFontTTF.clear();
		if (sBgfxFontManager)
		{
			sBgfxFontManager.reset();
		}
	}

	bool M3DFontManager::hasFont(Styling::FontFace const& face)
	{
		return sFonts.find(face) != sFonts.end();
	}

	bool M3DFontManager::hasTtf(std::string const& ttfName)
	{
		return sFontTTF.find(ttfName) != sFontTTF.end();
	}

	FontHandle M3DFontManager::getFont(Styling::FontFace const& face)
	{
		if (hasFont(face)) return sFonts[face];
		return BGFX_INVALID_HANDLE;
	}

	FontHandle M3DFontManager::getDefaultFont(int32_t sizePx, Styling::TextFontTypes fontType)
	{
		Styling::FontFace defaultFont{ sDefaultFont, sizePx, fontType };

		if (!hasFont(defaultFont))
		{
			addFontConfig(defaultFont, defaultFont.name);
		}
		
		return getFont(defaultFont);
	}

	size_t M3DFontManager::getNumFonts()
	{
		return sFonts.size();
	}

	size_t M3DFontManager::getNumTTFs()
	{
		return sFontTTF.size();
	}
	
	size_t M3DFontManager::getNumFontHandles()
	{
		return sBgfxFontManager->getNumAllocatedFonts();
	}

	size_t M3DFontManager::getNumTtfHandles()
	{
		return sBgfxFontManager->getNumAllocatedTtfs();
	}

	TrueTypeHandle M3DFontManager::loadTtf(uint8_t const* data, size_t size)
	{
		TrueTypeHandle handle = sBgfxFontManager->createTtf((uint8_t*)data, uint32_t(size));
		ONYX_ASSERT(handle.idx != bgfx::kInvalidHandle, "Unable to create True Type Font");
		return handle;
	}

DISABLE_WARNING_PUSH
DISABLE_WARNING_UNREACHABLE_CODE
	TrueTypeHandle M3DFontManager::loadTtf(std::string const &_filePath)
	{
		uint32_t size;
		void* data = onyx::core::FileSystem::load(_filePath, &size);

		if (data != nullptr)
		{
			TrueTypeHandle handle = loadTtf((uint8_t*)data, size);// sBgfxFontManager->createTtf((uint8_t*)data, size);
			bx::free(onyx::core::FileSystem::getAllocator(), data);
			return handle;
		}

		ONYX_THROW("Unable to load True Type Font data");
		return BGFX_INVALID_HANDLE;
	}
DISABLE_WARNING_POP

	void M3DFontManager::addTTF(std::string const& ttfName, uint8_t const* data, size_t size)
	{
		auto handle = loadTtf(data, size);
		ONYX_ASSERT(handle.idx != bgfx::kInvalidHandle, std::string("Unable to load font ") + ttfName + " bytes");

		sFontTTF[ttfName] = handle;
	}

	void M3DFontManager::addTTF(std::string const& ttfName, std::string path)
	{
		auto handle = loadTtf(path.c_str());
		ONYX_ASSERT(handle.idx != bgfx::kInvalidHandle, std::string("Unable to load font: ") + path);
		sFontTTF[ttfName] = handle;
	}

	void M3DFontManager::reset(::BgfxFontManager::FontConfiguration const& defaultFont)
	{
		Shutdown();
		initialize(defaultFont);
	}

	void M3DFontManager::addFontConfig(Styling::FontFace const &font, std::string ttfName)
	{
		ONYX_ASSERT(font.pixelSize != 0, font.name + " with zero pixel size tried to be added!");
		ONYX_ASSERT(sFontTTF.find(ttfName) != sFontTTF.end(), "No TTF exists for " + ttfName);

		auto fontHandle = sBgfxFontManager->createFontByPixelSize(sFontTTF[ttfName], 0, font.pixelSize, font.fontType);
		ONYX_ASSERT(fontHandle.idx != bgfx::kInvalidHandle, "M3DFontManager::addFontConfig - failed to create font" + ttfName);
		sFonts[font] = fontHandle;
	}

}
