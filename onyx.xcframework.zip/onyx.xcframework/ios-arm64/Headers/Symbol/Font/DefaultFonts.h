// Stores default fonts/ttfs
#pragma once

#include <stdint.h>
#include <string>

#include "BgfxFontManager.h"

// Defined in the global namespace, so declaration has to be in the global namespace
extern const uint8_t s_robotoRegularTtf[];
extern const size_t s_robotoRegularTtf_size;

extern const uint8_t s_robotoMonoRegularTtf[];
extern const size_t s_robotoMonoRegularTtf_size;

namespace onyx::Font {

extern const std::string s_topoLabel;
extern const std::string s_topoLabelId;

extern const std::string s_atlasGrotesk;
extern const std::string s_atlasGroteskFile;

extern const std::string s_montefiore;
extern const std::string s_montefiorePath;

extern const std::string s_robotoMono;

BgfxFontManager::FontConfiguration getRobotoRegularConfig();

}
