#pragma once

#include <unordered_map>

#include <Styling/Styles/TextStyle.h>

// TODO we should consolidate BgfxFontManager.h and FontManager.h
#include "BgfxFontManager.h"

namespace onyx::Font {

	class M3DFontManager
	{
	public:

		static void initialize(::BgfxFontManager::FontConfiguration const& defaultFont);
		static void Shutdown();
		static BgfxFontManager* getFontManager() { return sBgfxFontManager; }

		static bool hasFont(Styling::FontFace const& face);
		static bool hasTtf(std::string const& ttfName);

		static FontHandle getFont(Styling::FontFace const &face);
		static FontHandle getDefaultFont(int32_t sizePx, Styling::TextFontTypes fontType);
		
		static size_t getNumFonts();
		static size_t getNumTTFs();

		static size_t getNumFontHandles();
		static size_t getNumTtfHandles();

		static void addFontConfig(Styling::FontFace const& font, std::string ttfName);

		static void addTTF(std::string const &ttfName, std::string path);
		static void addTTF(std::string const& ttfName, uint8_t const* data, size_t size);

		static TrueTypeHandle loadTtf(std::string const& _filePath);
		static TrueTypeHandle loadTtf(uint8_t const* data, size_t size);

		static void reset(::BgfxFontManager::FontConfiguration const& defaultFont);

		template<class T>
		static Styling::FontFace random(T const& param)
		{
			Styling::FontFace result;
			std::hash<T> hasher;
			auto hashed = hasher(param);

			switch (hashed & 0x3)
			{
			case 0:
				result.name = "default";
				break;
			case 1:
				result.name = "roboto regular";
				break;
			default:
				result.name = "roboto mono";
				break;
			}

			result.fontType = Styling::TextFontTypes::DistanceOutlineShadowImage;
			result.pixelSize = 10 + ((hashed & 0x3FFF) / 0x800);
			return result;
		}

	private:
		static BgfxFontManager* sBgfxFontManager;
	};

}