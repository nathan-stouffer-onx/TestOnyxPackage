#pragma once

#include <Styling/Enums.h>

namespace onyx::Symbol {

inline bool isRotatedToVp(Styling::SymbolPlacement symPlacement, Styling::Alignment alignment)
{
	if (alignment == Styling::Alignment::Auto)
	{
		return symPlacement == Styling::SymbolPlacement::POINT;
	}
	return (alignment == Styling::Alignment::Viewport);
}

inline bool isNormalizedClipped(lgal::gpu::Vector3 const& normalizedPosition, gpu_float_t nearClip, gpu_float_t farClip)
{
	return (normalizedPosition.x < -1.f || normalizedPosition.x > 1.f
		|| normalizedPosition.y < -1.f || normalizedPosition.y > 1.f
		|| normalizedPosition.z < nearClip || normalizedPosition.z > farClip);

}

inline bool isScreenClipped(lgal::gpu::Vector3 const& screenPos, lgal::gpu::Vector2 const& screenSize, gpu_float_t nearClip, gpu_float_t farClip)
{
	return (screenPos.x < 0 || screenPos.x > screenSize.x ||
		screenPos.y < 0 || screenPos.y > screenSize.y ||
		screenPos.z < nearClip || screenPos.z > farClip);
}

}
