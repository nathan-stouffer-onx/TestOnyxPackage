#pragma once

#include <Styling/Enums.h>
#include <Utils/SpaceTypes.h>

#include "Camera/CameraState.h"
#include "Atlases/HeightAtlas.h"

namespace onyx::Symbol {

inline bool isRotatedToVp(Styling::SymbolPlacement symPlacement, Styling::Alignment alignment)
{
	return (alignment == Styling::Alignment::Auto && symPlacement == Styling::SymbolPlacement::POINT) ||
		(alignment == Styling::Alignment::Viewport);
}

inline bool isNormalizedClipped(lgal::gpu::Vector3 const& normalizedPosition, gpu_float_t nearClip, gpu_float_t farClip)
{
	return (normalizedPosition.x < -1.f || normalizedPosition.x > 1.f
		|| normalizedPosition.y < -1.f || normalizedPosition.y > 1.f
		|| normalizedPosition.z < nearClip || normalizedPosition.z > farClip);
}

inline bool isScreenClipped(lgal::gpu::Vector3 const& screenPos, lgal::gpu::Vector2 const& screenSize, gpu_float_t nearClip, gpu_float_t farClip)
{
	return (screenPos.x < 0 || screenPos.x > screenSize.x ||
		screenPos.y < 0 || screenPos.y > screenSize.y ||
		screenPos.z < nearClip || screenPos.z > farClip);
}

inline gpu_float_t updateOpacity(time_float_t durationMS, time_float_t deltaFrameMS, gpu_float_t maxOpacity, gpu_float_t currOpacity, bool isVisible)
{
	auto opacityTick = deltaFrameMS * (1.0 / durationMS) * time_float_t(maxOpacity) * (time_float_t(isVisible) - time_float_t(!isVisible));

	return (gpu_float_t)std::clamp(currOpacity + opacityTick, 0.0, (time_float_t)maxOpacity);
}

/**
 * Returns projected screen coordinates given world coordinates. Also takes into account camera's terrain 
 * exaggeration value. outCoords will only be set if projection to screen coordinates is successful. Otherwise the 
 * function will return false. 
 */
inline bool worldToScreenCoords(lgal::gpu::Vector3& outCoords, Camera::CameraState const& camera, lgal::gpu::Vector2 const& screenSize, lgal::world::Vector3 const& worldPnt)
{
	Camera::CameraState::ProjectionData projData = camera.projectExaggerated(worldPnt);
	if (projData.valid)
	{
		auto screenPnt = projData.position.as<gpu_float_t>();
		screenPnt.x = (screenPnt.x * 0.5f + 0.5f) * screenSize.x;
		screenPnt.y = (screenPnt.y * 0.5f + 0.5f) * screenSize.y;

		outCoords = screenPnt;
		
		return true;
	}

	return false;
}

// Converts tile coordinates to screen coordinates with depth. anchorPos is the tile coordinates with elevation. If heightAtlas is supplied, then anchorPos.z is ignored in favor of sampling the heightAtlas for elevation
lgal::gpu::Vector3 tileToScreenCoords(lgal::world::Vector3 const& anchorPos, Camera::CameraState const& camera, lgal::gpu::Vector2 const& screenSize, Tiles::TileId const& tileId, Atlases::HeightAtlas const* heightAtlas);

}
