#pragma once

#include "MapSymbol.h"

namespace onyx::Symbol {

class SymbolCollection
{
public:

	~SymbolCollection()
	{
		mSymbols.clear();
		mCachedMapSymbols.clear();
	}
	
	inline bool hasSymbolsFor(Tiles::TileId const& tileId, std::string bucket) const
	{
		auto tileSymbolIter = mCachedMapSymbols.find(tileId);
		if (tileSymbolIter == mCachedMapSymbols.end()) return false;
		return (tileSymbolIter->second.find(bucket) == tileSymbolIter->second.end()) ?
			false : true;
	}

	void cacheSymbolsForTile(Tiles::TileId const& tileId, std::string bucket,
		std::vector<SharedSymbol_t> const& symbols)
	{
		std::lock_guard<std::mutex> lock(mLock);
		if (hasSymbolsFor(tileId, bucket))
		{
			mCachedMapSymbols[tileId][bucket].clear();
		}
		mCachedMapSymbols[tileId][bucket] = symbols;
	}

	// TODO (Ronald): These metadata queries could be more efficient, 
	// but it would require storing and updating a running count on the number of symbols, icons, 
	// labels. If usage of these queries gets expensive, implement it. Also a lot of copying going on...
	size_t totalSymbols() const
	{
		size_t result = 0;

		for (auto const& symbols : mSymbols)
		{
			result += symbols.second.size();
		}

		for (auto const& kvp : mCachedMapSymbols)
		{
			for (auto const& symbols : kvp.second)
			{
				result += symbols.second.size();
			}
		}

		return result;
	}

	size_t totalLabels() const
	{
		size_t result = 0;

		for (auto const& symbols : mSymbols)
		{
			for (auto const& symbol : symbols.second)
			{
				if (symbol->hasLabel()) ++result;
			}
		}

		for (auto const& kvp : mCachedMapSymbols)
		{
			for (auto const& symbols : kvp.second)
			{
				for (auto const& symbol : symbols.second)
				{
					if (symbol->hasLabel()) ++result;
				}
			}
		}

		return result;
	}

	size_t totalIcons() const
	{
		size_t result = 0;

		for (auto const& symbols : mSymbols)
		{
			for (auto const& symbol : symbols.second)
			{
				if (symbol->getIcon().has_value()) ++result;
			}
		}

		for (auto const& kvp : mCachedMapSymbols)
		{
			for (auto const& symbols : kvp.second)
			{
				for (auto const& symbol : symbols.second)
				{
					if (symbol->getIcon().has_value()) ++result;
				}
			}
		}

		return result;
	}

	SharedSymbol_t getSymbol(lgal::world::Vector3 const& pos)
	{
		world_float_t dist = lucid::math::constants::max<world_float_t>();
		SharedSymbol_t l = nullptr;
		for (auto const& [key, symbols] : mSymbols)
		{
			for (auto const& symbol : symbols)
			{
				auto d = len(symbol->getPosition() - pos);
				if (d < dist)
				{
					l = symbol;
					dist = d;
				}
			}
		}

		return l;
	}

	inline std::map<std::string, std::vector<SharedSymbol_t>> const& getSymbolsMap() const
	{
		return mSymbols;
	}

	inline bool contains(std::string key) const
	{
		return mSymbols.find(key) != mSymbols.end();
	}

	void insert(std::string key, std::vector<SharedSymbol_t> const& symbols)
	{
		if (contains(key))
		{
			erase(key);

		}

		mSymbols[key] = symbols;
	}

	void append(std::string key, SharedSymbol_t symbol)
	{
		mSymbols[key].push_back(symbol);
	}

	void append(std::string key, std::vector<SharedSymbol_t> const& symbols)
	{
		mSymbols[key].insert(mSymbols[key].end(), symbols.begin(), symbols.end());
	}

	void erase(std::string key)
	{
		std::lock_guard<std::mutex> lock(mLock);
		mSymbols.erase(key);
	}

	private:

		std::map<std::string, std::vector<SharedSymbol_t>> mSymbols;
		std::map<Tiles::TileId, std::map<std::string, std::vector<SharedSymbol_t>>> mCachedMapSymbols;

		mutable std::mutex mLock;
};

}
