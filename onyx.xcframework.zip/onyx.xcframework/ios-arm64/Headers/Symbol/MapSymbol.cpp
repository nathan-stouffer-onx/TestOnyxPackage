#include "MapSymbol.h"

namespace onyx::Symbol {

const Tiles::TileId MapSymbol::cNoTileId = Tiles::TileId{ -1, -1, -1 };

}