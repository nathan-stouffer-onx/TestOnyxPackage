#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include <Styling/Formatted.h>
#include <Styling/Enums.h>
#include <Utils/UUID.h>

#include "Camera/CameraState.h"
#include "Font/TextBufferManager.h"
#include "Style/TextStyleManager.h"
#include "Tiles/TileId.h"
#include "Utils/property.h"
#include "Utils/SpaceTypes.h"
#include "Vector/Feature.h"

// TODO (Ronald): This class looks like it can be shortened further

namespace onyx::Symbol {

class MapLabel
{
public:

	struct TextChunk
	{
		// Not sure I like having pointers to strings that *could* be transient, but as long as we carefully
		// control the lifecycle of text segments and the TextChunks that reference them it should be safe.
		const char* begin;
		const char* end;
		lgal::gpu::Vector2 size;
		lgal::gpu::Vector2 offset;
		// Ditto for this font override
		Styling::Formatted::Options const* fontOverride = nullptr;
		FontInfo fontInfo = {};
		bool isLineBreak = false;
	};

	typedef Vector::Feature feature_t;
	typedef std::shared_ptr<feature_t const> sharedFeature_t;

public:

	// TODO (Ronald): Move to TextStyle
	static std::shared_ptr<Styling::TextStyle> defaultStyle() {
		return std::make_shared<Styling::TextStyle>(Styling::FontFace({ "default", Styling::TextFontTypes::DistanceOutlineShadowImage, 0 }), lgal::Color::FromRGBA(0xFFFFFFFF), lgal::Color::FromRGBA(0x000000FF), lgal::Color::FromRGBA(0x00000064), 0.f, Styling::Anchor::DEFAULT);
	}
	
	MapLabel(Styling::Formatted const& text, lgal::world::Vector3 const& worldXY, std::shared_ptr<Styling::TextStyle> fontStyle = defaultStyle(), 
		Tiles::TileId const& tileId = { -1, -1, -1 }, sharedFeature_t const& feature = nullptr, bool locked = false, Utils::SpaceTypes space = Utils::SpaceTypes::Tile, std::vector<lgal::world::Vector3> *worldGeometry = nullptr);
	
	MapLabel(Styling::Formatted const& text, lgal::world::Vector3 const& worldXY, Utils::SpaceTypes space) : 
		MapLabel(text, worldXY, defaultStyle(), { -1, -1, -1 }, nullptr, false, space) { }

	void setText(Styling::Formatted const& text);

	lgal::world::Vector3 getMapPosition() const;
	lgal::world::Vector3 getPrevMapPosition() const;
	void setMass(float mass);
	void setMapPosition(lgal::world::Vector3 const & pos);

	void setPrevMapPosition(lgal::world::Vector3 const & prev);
	void setPrevScreenPosition(Camera::CameraState camState, lgal::gpu::Vector3 const& pos);
	void syncPrevPos() { mPrevMapPosition = mMapPosition; } //stops movement by making them match
	float getMass() const;
	float getInvMass() const;

	lgal::gpu::Vector3 getPrevScreenPosition(Camera::CameraState const& camState) const;
	void setScreenPosition(Camera::CameraState const &camState, lgal::gpu::Vector3 const& pos);
	lgal::gpu::Vector3 getAccel() const;

	bool isVisible(Camera::CameraState const& cameraState) const;
	
	Styling::Formatted const& getText() const { return mText; }
	Utils::UUID getUuid() const { return mUuid; }

	bool isLocked() const { return mLocked; }
	void setStyle(std::shared_ptr<Styling::TextStyle> const& style) { mStyle = style; }
	std::shared_ptr<Styling::TextStyle> const getStyle() const { return mStyle; }
	bool updateFade(bool visible);

	GET_SET_VALUE(TextDirection, lgal::gpu::Vector2, lgal::gpu::Vector2(1, 0));
	std::function<float(void)> mFadeModifierPtr;

	void setAlpha(int alpha) { mCurrentAlpha = alpha; }
	int getCurrentAlpha() const { return mCurrentAlpha; }
	GET_SET_VALUE(Force, bool, false);
	GET_SET_VALUE(AnchorPoint, lgal::world::Vector3, lgal::world::Vector3(0, 0, 0));
	GET_SET_VALUE(TextLengthPx, gpu_float_t, -1.f);
	GET_SET_VALUE(LongestChunkPx, gpu_float_t, 0.f);

	auto const& getChunks() const { return mChunks; }
	auto & getChunks() { return mChunks; }

	std::vector<lgal::world::Vector3> const& getWorldGeometry() const { return mWorldGeometry; }

	size_t dataSize() const
	{
		return sizeof(MapLabel) + (mWorldGeometry.size() * sizeof(lgal::world::Vector3));
	}

	bool operator==(MapLabel const& rhs) const
	{
		return this == &rhs || mFeature.get() == rhs.mFeature.get();
	}

	lgal::gpu::Vector3 getScreenAnchorPos(Camera::CameraState camState) const
	{
		auto projected = camState.project(mAnchorPoint);
		return projected.position.as<gpu_float_t>();
	}

	void gatherTextChunks();

private:
	lgal::world::Vector3 mMapPosition;
	lgal::world::Vector3 mPrevMapPosition; //needed for verlet

	lgal::gpu::Vector3 mScreenPosition;
	lgal::gpu::Vector3 mPrevScreenPosition;

	lgal::gpu::Vector3 mAccel;

	float mMass;
	float mInvMass;
	Styling::Formatted mText;
	Utils::UUID mUuid;

	bool mLocked;
	bool mTextDirty = true;

	std::shared_ptr<Styling::TextStyle> mStyle;

	int mCurrentAlpha;
	std::vector<lgal::world::Vector3> mWorldGeometry;
	std::vector<TextChunk> mChunks;

	GET_PROP(Feature, sharedFeature_t, nullptr);
	GET_PROP(TileId, Tiles::TileId, Tiles::TileId(-1, -1, -1));
	GET_PROP(Space, Utils::SpaceTypes, Utils::SpaceTypes::Tile);
};

}