#pragma once

#include <string>

#include <lucid/gal/Types.h>

#include <Styling/Formatted.h>
#include <Styling/Enums.h>
#include <Utils/UUID.h>

#include "Camera/CameraState.h"
#include "Font/TextBufferManager.h"
#include "Style/TextStyleManager.h"
#include "Tiles/TileId.h"
#include "Utils/property.h"
#include "Utils/SpaceTypes.h"
#include "Vector/Feature.h"

namespace onyx::Symbol {

class MapLabel
{
public:

	// TODO (possibly with CSONYX-159) - Change font override into a const& instead of a raw ptr
	struct TextChunk
	{
		// Not sure I like having views to strings that *could* be transient, but as long as we carefully
		// control the lifecycle of text segments and the TextChunks that reference them it should be safe.
		std::string_view strView = "";
		lgal::gpu::Vector2 size = { 0 };
		lgal::gpu::Vector2 offset = { 0 };
		Styling::Formatted::Options const* fontOverride = nullptr;
		FontInfo fontInfo = {};
		bool isLineBreak = false;
	};

	typedef Vector::Feature feature_t;
	typedef std::shared_ptr<feature_t const> sharedFeature_t;

public:

	static std::shared_ptr<Styling::TextStyle> defaultStyle() {
		return std::make_shared<Styling::TextStyle>(Styling::FontFace({ "default", 0, Styling::TextFontTypes::DistanceOutlineShadowImage }), lgal::Color::FromRGBA(0xFFFFFFFF), lgal::Color::FromRGBA(0x000000FF), lgal::Color::FromRGBA(0x00000064), 0.f, Styling::Anchor::DEFAULT);
	}
	
	MapLabel(Styling::Formatted const& text, std::shared_ptr<Styling::TextStyle> fontStyle = defaultStyle(), sharedFeature_t const& feature = nullptr, std::vector<lgal::world::Vector3>* worldGeometry = nullptr);

	void setText(Styling::Formatted const& text);

	Styling::Formatted const& getText() const { return mText; }

	void setStyle(std::shared_ptr<Styling::TextStyle> const& style) { mStyle = style; }
	std::shared_ptr<Styling::TextStyle> const getStyle() const { return mStyle; }

	GET_SET_VALUE(TextDirection, lgal::gpu::Vector2, lgal::gpu::Vector2(1, 0));

	GET_SET_VALUE(Force, bool, false);
	GET_SET_VALUE(TextLengthPx, gpu_float_t, -1.f);
	GET_SET_VALUE(LongestChunkPx, gpu_float_t, 0.f);
	GET_SET_VALUE(CurrentAlpha, gpu_float_t, 1.f);

	auto const& getChunks() const { return mChunks; }
	auto & getChunks() { return mChunks; }

	std::vector<lgal::world::Vector3> const& getWorldGeometry() const { return mWorldGeometry; }

	size_t dataSize() const
	{
		return sizeof(MapLabel) + (mWorldGeometry.size() * sizeof(lgal::world::Vector3));
	}

	bool operator==(MapLabel const& rhs) const
	{
		return this == &rhs || mFeature.get() == rhs.mFeature.get();
	}

	void gatherTextChunks();

private:
	Styling::Formatted mText;

	bool mTextDirty = true;

	std::shared_ptr<Styling::TextStyle> mStyle;

	std::vector<lgal::world::Vector3> mWorldGeometry;
	std::vector<TextChunk> mChunks;

	GET_PROP(Feature, sharedFeature_t, nullptr);
};

using SharedLabel_t = std::shared_ptr<MapLabel>;

}