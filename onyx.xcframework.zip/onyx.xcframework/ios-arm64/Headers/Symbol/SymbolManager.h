#pragma once

#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "Atlases/HeightAtlas.h"
#include "Camera/CameraState.h"
#include "Camera/Frustum.h"
#include "Camera/ScreenSpaceManager.h"
#include "Font/TextBufferManager.h"
#include "MapSymbol.h"
#include "SymbolKey.h"
#include "IconRenderer.h"
#include "SymbolUtils.h"
#include "Tiles/TileId.h"
#include "Utils/property.h"

namespace onyx {

	class Viewport;

namespace Symbol {

// Note: This class is not thread-safe, except for setting the override symbol. All other functions should ideally be called
// by the same thread as the thread calling viewport functions.
class SymbolManager
{
public:
	using symbolVec_t = std::vector<SharedSymbol_t>;
	using symbolSet_t = std::unordered_set<SharedSymbol_t>;
	using SymbolMap_t = std::unordered_map<SymbolKey, SharedSymbol_t>;

public:

	// TODO (Ronald): (CSONYX-315) Track Symbol stats better in debugger window
	struct Stats {
		size_t depthClipCount;
		size_t bufferClipped;
		size_t labelsRendered;
		size_t iconsRendered;
		size_t screenSpaceClipped;
		size_t overlapClipped;
		size_t pathClipped;
		size_t styleInvalid;

		void clear()
		{
			*this = { 0, 0, 0, 0, 0, 0, 0, 0 };
		}
	};
	GET_PROP(Stats, Stats, Stats());

	inline size_t getNumRenderedIcons() const { return mIconRenderer->getNumRenderedIcons(); }

	SymbolManager(Viewport const* viewport);
	~SymbolManager();

	void initialize();
	void update();

	void resetFontManager();

	bool draw(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas, time_float_t currFrameMS);

	// TODO (Ronald): (CSONYX-318) Currently, this code path only supports rendering icons from symbols
	bool drawOverrideSymbols(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas);

	void setScreenSize(lgal::gpu::Vector2 const& size) { mScreenSize = size; }

	SymbolMap_t const& getSymbolFrameCache() const { return mSymbolFrameCache; }

	int getNumOnscreenSyms() const { return mNumDrawnOverrideSyms + mNumDrawnSyms; }

	// TODO (Ronald): (CSONYX-316) remove unnecessary debug properties once near end of polish phase
	gpu_float_t DBG_sizeCutoff = 1.f, DBG_DepthOffset = 0.01f;
	int DBG_maxSymbolsDrawn = 150;	// int is used for imgui compatibility
	bool DBG_forcePassCull = false;

	GET_SET_VALUE(DebugLabel, SharedSymbol_t, nullptr);

private:

	// Caches
	SymbolMap_t mCurrentFrameSymbols;
	SymbolMap_t mSymbolFrameCache;
	std::vector<SymbolKey> mDeleteCache;
	std::unordered_map<Styling::FontFace, TextBufferHandle> mTextBufferHandles;
	std::unique_ptr<TextBufferManager> mTextBufferManager;
	std::vector<IconRenderer::Payload> mIconPayloads;

	// Used to determine the clipping bounds
	bool mHomogenousDepth = false;
	gpu_float_t mNearClip, mFarClip;
	lgal::gpu::Vector2 mScreenSize;
	Viewport const* mViewport;
	float mView[16] = { 0 };
	float mOrtho[16] = { 0 };
	float mWorld[16] = { 0 };

	bool mFirstDraw = true;
	time_float_t mPrevFrameMS = 0;

	int mNumDrawnSyms = 0, mNumDrawnOverrideSyms = 0;

	std::unique_ptr<TextBuffer> mDummyTextBuffer;

	TextBufferHandle getStyleBuffer(Styling::FontFace const& font);

	void setTextRenderStyle(TextBufferHandle const hndl, lgal::gpu::Vector2 const& xDir, lgal::gpu::Vector2 const& yDir, Styling::TextStyle const& style, gpu_float_t opacity);

	// Puts label into text buffer for rendering
	void bufferLabel(ScreenState const& screenState, MapSymbol const& label, Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& camera);

	// Expiring symbols pass the overlap clip test since we want to prioritize rendering it disappearing
	bool passesCull(ScreenState const& screenState, bool expiringSymbol = false);

	// Generates symbol screen state and registers visible symbol to the screen-space manager
	ScreenState genScreenState(Camera::ScreenSpaceManager& screenSpaceManager, MapSymbol const& symbol, Camera::CameraState const& camera, Atlases::HeightAtlas const* heightAtlas, bool expiringSymbol = false);

	void calcTextPlacement(ScreenState& screenState, MapSymbol const& symbol, Camera::CameraState const& camera, Atlases::HeightAtlas const* heightAtlas);

	void layoutLineText(ScreenState& screenState, TextBuffer& textBuf, MapSymbol const& symbol, Camera::CameraState const& camera, Atlases::HeightAtlas const* heightAtlas);

	FontHandle getFontHandle(Styling::FontFace const& fontFace);

	// Icon-specific members
	std::shared_ptr<IconRenderer> mIconRenderer;

	void submitRender(bgfx::FrameBufferHandle const colorZBufferHndl, std::vector<IconRenderer::Payload> icons, Atlases::SpriteAtlas const& spriteAtlas);
};

} }