#pragma once

#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "Atlases/HeightAtlas.h"
#include "Camera/CameraState.h"
#include "Camera/Frustum.h"
#include "Camera/ScreenSpaceManager.h"
#include "Font/TextBufferManager.h"
#include "Symbol/MapSymbol.h"
#include "Symbol/IconRenderer.h"
#include "Symbol/SymbolUtils.h"
#include "Tiles/TileId.h"
#include "Utils/property.h"

namespace onyx {

	class Viewport;

namespace Symbol {

// TODO (Ronald): If this class is exposed to any other class besides Viewport, might be better to create a higher level api for those classes

// Note: This class is not thread-safe, except for setting the override symbol. All other functions should ideally be called
// by the same thread as the thread calling viewport functions.
class SymbolManager
{
public:
	using symbolVec_t = std::vector<SharedSymbol_t>;
	using symbolSet_t = std::unordered_set<SharedSymbol_t>;

public:

	// TODO (Ronald): Create icon-based stats
	struct Stats {
		size_t visibilityClipped;
		size_t depthClipCount;
		size_t bufferClipped;
		size_t buffered;
		size_t frustumClipped;
		size_t screenSpaceClipped;
		size_t overlapClipped;

		void clear()
		{
			*this = { 0, 0, 0, 0, 0, 0, 0 };
		}
	};
	GET_PROP(Stats, Stats, Stats());

	inline size_t getNumRenderedIcons() const { return mIconRenderer->getNumRenderedIcons(); }

	SymbolManager(Viewport const* viewport);
	~SymbolManager();

	void initialize();
	void update();

	void resetFontManager();

	bool draw(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, 
		Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas);

	bool drawOverrideSymbols(Camera::ScreenSpaceManager& screenSpaceManager, symbolVec_t const& frameSymbols, bgfx::FrameBufferHandle const colorZBufferHndl, 
		Atlases::SpriteAtlas const& spriteAtlas, Atlases::HeightAtlas const* heightAtlas);

	void setScreenSize(lgal::gpu::Vector2 const& size) { mScreenSize = size; }

	// TODO (Ronald) remove debug stuff
	gpu_float_t DBG_sizeCutoff = 1.f,
		DBG_DepthOffset = 0.01f;
	int DBG_maxSymbolsDrawn = 150;	// int is used for imgui compatibility
	bool DBG_forcePassCull = false;

	GET_SET_VALUE(DebugLabel, SharedSymbol_t, nullptr);

	GET_SET_VALUE(OnscreenSymbols, symbolSet_t, symbolSet_t());
	GET_SET_VALUE(CurrentFrameSymbols, symbolSet_t, symbolSet_t());

private:

	TextBufferHandle getStyleBuffer(Styling::FontFace const& font);
	std::unordered_map<Styling::FontFace, TextBufferHandle> mTextBufferHandles;

	std::unique_ptr<TextBufferManager> mTextBufferManager;

	// Used to determine the clipping bounds
	bool mHomogenousDepth = false;
	gpu_float_t mNearClip, mFarClip;
	lgal::gpu::Vector2 mScreenSize;
	Viewport const* mViewport;

	std::unique_ptr<TextBuffer> mDummyTextBuffer;

	void setTextRenderStyle(TextBufferHandle const hndl, lgal::gpu::Vector2 const& xDir, lgal::gpu::Vector2 const& yDir, Styling::TextStyle const& style);

	// TODO (Ronald): Get MapSymbol and SymbolState back to being a const& at the earliest opportunity
	bool bufferLabel(SymbolState& screenState, MapSymbol& label, Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& cameraState);

	bool cull(SymbolState& screenState, Camera::ScreenSpaceManager& screenSpaceManager, MapSymbol const& symbol, Camera::Frustum const& frustum);

	// Generates symbol screen state given 
	SymbolState genScreenState(MapSymbol const& symbol, Camera::CameraState const& cameraState, 
		Atlases::HeightAtlas const* heightAtlas);

	void calcTextPlacement(MapSymbol const& symbol, SymbolState& screenState, Camera::CameraState const& cameraState, Atlases::HeightAtlas const* heightAtlas);

	void layoutLineText(MapSymbol const& symbol, SymbolState& screenState, TextBuffer& texBuf, Camera::CameraState const& cameraState, Atlases::HeightAtlas const* heightAtlas);

	FontHandle getFontHandle(Styling::FontFace const& fontFace);

	// Icon-specific members
	std::shared_ptr<IconRenderer> mIconRenderer;

	void submitRender(bgfx::FrameBufferHandle const colorZBufferHndl, std::vector<IconRenderer::Payload> icons, Atlases::SpriteAtlas const& spriteAtlas);
};

} }