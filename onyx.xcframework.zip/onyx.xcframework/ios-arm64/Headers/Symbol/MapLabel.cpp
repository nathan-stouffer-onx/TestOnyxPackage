#include "MapLabel.h"

#include <lucid/Profiler.h>
#include <Utils/BgfxUtils.h>

#include "Height/HeightManager.h"

namespace onyx::Symbol {

MapLabel::MapLabel(Styling::Formatted const& text, std::shared_ptr<Styling::TextStyle> fontStyle, sharedFeature_t const& feature, std::vector<lgal::world::Vector3>* worldGeometry) :
	mText(text)
	, mStyle(fontStyle)
	, mFeature(feature)
{
	if (worldGeometry != nullptr)
	{
		mWorldGeometry = std::move(*worldGeometry);
	}
}

void MapLabel::setText(Styling::Formatted const& text)
{ 
	mText = text;
	mTextDirty = true;
}

// TODO (scott CSONYX-159)
// This could all be done at once when the label is created as soon as the
// font style is known; it would be worthwhile to explore handling it in the
// prepare task.
void MapLabel::gatherTextChunks()
{
	if (!mTextDirty)
	{
		return;
	}
	mTextDirty = false;

	mLongestChunkPx = 0.f;

	auto const& segments = mText.getSegments();

	mChunks.clear();
	mChunks.reserve(segments.size());

	for (auto const& seg : segments)
	{
		auto const& strView = seg.getText();
		auto const segment = strView.begin();
		auto const end = strView.end();

		if (mStyle->maxWidth != Styling::cNoTextWrap)
		{
			auto chunkBegin = segment, current = segment;
			for (; current < end && *current; ++current)
			{
				// Note: Whitespace here also means \t or \n
				if (Utils::isWhitespace(*current))
				{
					if (chunkBegin != current)
					{
						mChunks.push_back({ std::string_view(&*chunkBegin, current - chunkBegin), { -1.f, -1.f }, { 0 }, &seg.getOptions()});
					}
					if (*chunkBegin == '\n' && !mChunks.empty())
					{
						mChunks.back().isLineBreak = true;
					}

					chunkBegin = current + 1;
				}
			}
			if (chunkBegin != current)
			{
				mChunks.push_back({ std::string_view(&*chunkBegin, end - chunkBegin), {-1.f, -1.f}, { 0 }, &seg.getOptions()});
			}
		}

		else
		{
			if (segment != end)
			{
				mChunks.push_back({ std::string_view(&*segment, end - segment), {-1.f, -1.f }, { 0 }, &seg.getOptions()});
			}
		}
	}
}

}