#include "MapLabel.h"

#include <lucid/Profiler.h>
#include <Shaders/ShaderManager.h>
#include <Utils/BgfxUtils.h>

#include "Height/HeightManager.h"

namespace onyx::Symbol {

MapLabel::MapLabel(Styling::Formatted const& text, lgal::world::Vector3 const& worldXY, std::shared_ptr<Styling::TextStyle> fontStyle, Tiles::TileId const& tileId, sharedFeature_t const& feature, bool locked, Utils::SpaceTypes space, std::vector<lgal::world::Vector3>* worldGeometry)
	: mMapPosition(worldXY)
	, mPrevMapPosition(worldXY)
	, mAccel({ 0, 0, 0 })
	, mMass(1.0f)
	, mInvMass(1.0f / mMass)
	, mText(text)
	, mLocked(locked)
	, mStyle(fontStyle)
	, mCurrentAlpha(0xFF)
	, mFeature(feature)
	, mTileId(tileId)
	, mSpace(space)
{
	// TODO (scott) re-evaluate all of the AnchorPoint/MapPosition/PrevMapPosition stuff to see if we can consolidate it.
	mAnchorPoint = worldXY;

	if (space == Utils::SpaceTypes::WorldXY)
	{
		mAnchorPoint.z = HeightManager::Instance()->heightAt(mAnchorPoint.xy);
		mMapPosition.z = mAnchorPoint.z;
	}

	setText(text);

	if (worldGeometry != nullptr)
	{
		mWorldGeometry = std::move(*worldGeometry);
	}
}

void MapLabel::setText(Styling::Formatted const& text)
{ 
	mText = text; 
}

lgal::world::Vector3 MapLabel::getMapPosition() const
{
	if (mSpace == Utils::SpaceTypes::Tile)
	{
		lgal::world::Vector3 pos(mTileId.toWorldPos(mMapPosition.xy, Tiles::TileId::Origin::TOP_LEFT), 0);
		pos.z = HeightManager::Instance()->heightAt(pos.xy);
		return pos;
	}
	return mMapPosition;
}

lgal::world::Vector3 MapLabel::getPrevMapPosition() const
{
	return mPrevMapPosition;
}

lgal::gpu::Vector3 MapLabel::getPrevScreenPosition(Camera::CameraState const& camState) const
{
	Camera::CameraState::ProjectionData projected = camState.project(mPrevMapPosition);
	return projected.position.as<gpu_float_t>();
}

lgal::gpu::Vector3 MapLabel::getAccel() const
{
	return mAccel;
}

void MapLabel::setMapPosition(lgal::world::Vector3 const & pos)
{
	mMapPosition = pos;
}

void MapLabel::setScreenPosition(Camera::CameraState const &camState, lgal::gpu::Vector3 const& pos)
{
	mScreenPosition = pos;

	Camera::CameraState::ProjectionData unprojected = camState.unproject(pos.as<world_float_t>());
	mMapPosition = unprojected.position;
}

void MapLabel::setPrevMapPosition(lgal::world::Vector3 const & prev)
{
	mPrevMapPosition = prev;
}

void MapLabel::setPrevScreenPosition(Camera::CameraState camState, lgal::gpu::Vector3 const & pos)
{
	mPrevScreenPosition = pos;

	Camera::CameraState::ProjectionData unprojected = camState.unproject(pos.as<world_float_t>());
	mPrevMapPosition = unprojected.position;
}

void MapLabel::setMass(float mass)
{
	mMass = mass;
	mInvMass = 1.0f / mass;
}

float MapLabel::getMass() const
{
	return mMass;
}

float MapLabel::getInvMass() const
{
	return mInvMass;
}

bool MapLabel::isVisible(Camera::CameraState const& cameraState) const
{ 
	LUCID_PROFILE_SCOPE("MapLabel::isVisible");
	if (mCurrentAlpha <= 0)
		return false;

	world_float_t dist = lmath::len(lgal::world::Vector2(cameraState.position.x, cameraState.position.y) - lgal::world::Vector2(mAnchorPoint.x, mAnchorPoint.y));
	world_float_t horizonFade = std::max(1.0 - std::clamp(cameraState.pitch / 1.58, 0.0, 1.0), 0.2);
	return dist < (cameraState.farClip * horizonFade);
}

bool MapLabel::updateFade(bool visible)
{
	int max = 255;
	if(mFadeModifierPtr != NULL)
		max = (int)(max * mFadeModifierPtr());

	if (!visible && mCurrentAlpha > 0)
	{
		mCurrentAlpha -= 20;
		if (mCurrentAlpha < 0) mCurrentAlpha = 0;
	}
	else if (visible)
	{
		mCurrentAlpha += 20;
		if (mCurrentAlpha > max) mCurrentAlpha = max;
	}

	return mCurrentAlpha > 0;
}

}