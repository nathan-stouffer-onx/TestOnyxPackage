#pragma once

#include <vector>

#include <lucid/gal/Types.h>

#include "Utils/property.h"

namespace onyx::Tessellation
{

	class PolyGrid
	{
	public:

		PolyGrid(uint32_t resolution = 64);

		// TODO consider passing in a Holygon -- Holygon::contains is unit tested
		std::vector<lgal::gpu::Vector2> getLatticeVertices(lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes = {}, float polyScale = 1) const;

		GET_PROP(Resolution, uint32_t, 64);

		size_t getVertexCount() const { return mVertices.size(); }

	private:

		static constexpr uint16_t sFaceStride = 3;
		std::vector<lgal::gpu::Vector2> mVertices;

		void generateGrid();
	};

}
