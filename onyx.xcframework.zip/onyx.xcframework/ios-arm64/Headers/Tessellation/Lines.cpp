#include "Lines.h"

namespace onyx {
namespace Tessellation {

	void tessellate(std::vector<Rendering::VertStructs::LineData>& target, lgal::gpu::Vector2 const& style, lgal::gpu::Vector2 const& prev, lgal::gpu::LineSegment2 const& segment, lgal::gpu::Vector2 const& next, gpu_float_t lineLength, gpu_float_t maxInstanceLength)
	{
		auto direction = segment.direction();
		auto length = lucid::math::len(direction);
		
		if (length <= maxInstanceLength)
		{
			target.push_back(Rendering::VertStructs::LineData(style, segment, prev, next, lineLength, lineLength + length));
			return;
		}

		direction = direction / length;
		auto count = size_t(std::ceil(length / maxInstanceLength));

		auto addLen = length / float(count);
		float currentPos = 0;

		// the instance runs from a -> b. p is the previous point and q is the next point
		lgal::gpu::Vector2 a = segment.start;
		lgal::gpu::Vector2 p = prev;
		lgal::gpu::Vector2 q = next;
		for (auto i = 1ull; i < count; ++i)
		{
			currentPos += addLen;
			auto b = segment.start + (direction * currentPos);
			q = segment.start + (direction * (currentPos + addLen));

			target.push_back(Rendering::VertStructs::LineData(style, { a, b }, p, q, lineLength + currentPos - addLen, lineLength + currentPos));
			p = a;
			a = b;
		}

		target.push_back(Rendering::VertStructs::LineData(style, { a, segment.end }, p, next, lineLength + currentPos, lineLength + length));
	}

	void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::vector<lgal::gpu::Vector2> const& points, bool loop, lgal::gpu::Vector2 style, gpu_float_t maxInstanceLength)
	{
		// reserve an appropriate amount of memory
		instances.reserve(instances.size() + points.size());

		lgal::gpu::Vector2 end = lgal::gpu::Vector2(-1000000.0f, 0.0f);
		lgal::gpu::Vector2 prev = end;
		lgal::gpu::Vector2 next = end;
		
		float length = 0;
		for (size_t i = 0; i + 1 < points.size(); ++i)		// iterate over all segments
		{
			lgal::gpu::Vector2 a = points[i];
			lgal::gpu::Vector2 b = points[i + 1];

			lgal::gpu::LineSegment2 segment = { a, b };
			if (i == 0)
			{
				if (loop)
				{
					prev = points[points.size() - 1];
				}
			}
			else 
			{
				prev = points[i - 1];
			}
			
			if (i < points.size() - 2)
			{
				next = points[i + 2];
			}
			else if (loop)
			{
				next = points[0];
			}
			else
			{
				next = end;
			}

			lgal::gpu::Vector2 prevDelta = prev - segment.start;
			if (prev != end && lmath::len(prevDelta) > maxInstanceLength)
			{
				prev = segment.start + maxInstanceLength * lmath::normalize(prevDelta);
			}
			lgal::gpu::Vector2 nextDelta = next - segment.end;
			if (next != end && lmath::len(nextDelta) > maxInstanceLength)
			{
				next = segment.end + maxInstanceLength * lmath::normalize(nextDelta);
			}

			tessellate(instances, style, prev, segment, next, length, maxInstanceLength);
			length += lmath::len(b - a);
		}

		// account for closing edge if the points form a loop
		if (loop)
		{
			prev = points[points.size() - 2];
			next = points[1];
			tessellate(instances, style, prev, { points.back(), points.front() }, next, length, maxInstanceLength);
		}
	}

} }