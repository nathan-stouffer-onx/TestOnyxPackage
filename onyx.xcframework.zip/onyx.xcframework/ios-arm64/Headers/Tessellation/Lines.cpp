#include "Lines.h"

namespace onyx {
namespace Tessellation {

	void tessellate(std::vector<Rendering::VertStructs::LineData>& target, lgal::gpu::Vector2 const& style, lgal::gpu::Vector2 const& prevPoint, lgal::gpu::LineSegment2 const& segment, lgal::gpu::Vector2 const& nextPoint, gpu_float_t lineLengthA, gpu_float_t lineLengthB, gpu_float_t instLength)
	{
		auto direction = segment.direction();
		auto length = lucid::math::len(direction);
		
		direction = direction / length;

		if (length <= instLength)
		{
			target.push_back(Rendering::VertStructs::LineData(style, segment, lineLengthA, lineLengthB, prevPoint, nextPoint));
			return;
		}

		auto count = size_t(std::ceil(length / instLength));

		auto addLen = length / float(count);
		float currentPos = 0;

		lgal::gpu::Vector2 current = segment.start;

		lgal::gpu::Vector2 nextSeg = nextPoint;
		lgal::gpu::Vector2 prevSeg = prevPoint;
		for (auto i = 1ull; i < count; ++i)
		{
			
			currentPos += addLen;
			auto next = segment.start + (direction * currentPos);
			nextSeg = segment.start + (direction * (currentPos + addLen));

			target.push_back(Rendering::VertStructs::LineData(style, { current, next }, lineLengthA + currentPos - addLen, lineLengthA + currentPos, prevSeg, nextSeg));
			prevSeg = current;
			current = next;
		}

		target.push_back(Rendering::VertStructs::LineData(style, { current, segment.end }, lineLengthA + currentPos, lineLengthB, prevSeg, nextPoint));
	}

	void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::vector<lgal::gpu::Vector2> const& points, bool loop, lgal::gpu::Vector2 style, gpu_float_t maxSegmentLen)
	{
		// reserve an appropriate amount of memory
		instances.reserve(instances.size() + points.size());
		//temp for debugging
		//maxSegmentLen = 10000;
		lgal::gpu::Vector2 prev = lgal::gpu::Vector2(-1000000.0f, 0.0f);
		lgal::gpu::Vector2 next = lgal::gpu::Vector2(-1000000.0f, 0.0f);
		// iterate over all segments
		float length = 0;
		for (size_t i = 0; i + 1 < points.size(); ++i)
		{
			lgal::gpu::Vector2 p = points[i];
			lgal::gpu::Vector2 q = points[i + 1];

			lgal::gpu::LineSegment2 segment = { p, q };
			if (i == 0)
			{
				if (loop)
				{
					prev = points[points.size() - 1];
				}
			}
			else 
			{
				prev = points[i - 1];
			}
			
			if (i < points.size() - 2)
			{
				next = points[i + 2];
			}
			else if (loop)
			{
				next = points[0];
			}
			else
			{
				next = lgal::gpu::Vector2(-1000000.0f, 0.0f);
			}

			float segLen = lmath::len(q - p);
			tessellate(instances, style, prev, segment, next, length, length + segLen, maxSegmentLen);
			length += segLen;
		}

		// account for closing edge if the points form a loop
		if (loop)
		{
			prev = points[points.size() - 2];
			next = points[1];
			float segLen = lmath::len(next - prev);
			tessellate(instances, style, prev, { points.back(), points.front()}, next, length, length + segLen, maxSegmentLen);
		}
	}

} }