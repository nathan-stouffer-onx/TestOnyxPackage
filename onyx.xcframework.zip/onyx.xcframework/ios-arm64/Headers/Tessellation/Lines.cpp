#include "Lines.h"

namespace onyx::Tessellation
{

	static const lgal::gpu::Vector2 cEnd = lgal::gpu::Vector2(-1000000.0f, 0.0f);

	void tessellate(std::vector<InstanceT>& target, Leg const& leg, lgal::gpu::Vector2 const& style, gpu_float_t incomingLength, gpu_float_t maxInstanceLength)
	{
		auto direction = leg.segment.direction();
		auto length = lucid::math::len(direction);
		
		if (length <= maxInstanceLength)
		{
			target.push_back(InstanceT(style, leg.segment, leg.prev, leg.next, incomingLength, incomingLength + length));
			return;
		}

		direction = direction / length;
		auto count = size_t(std::ceil(length / maxInstanceLength));

		auto addLen = length / float(count);
		float currentPos = 0;

		// the instance runs from a -> b. p is the previous point and q is the next point
		lgal::gpu::Vector2 a = leg.segment.start;
		lgal::gpu::Vector2 p = leg.prev;
		lgal::gpu::Vector2 q = leg.next;
		for (auto i = 1ull; i < count; ++i)
		{
			currentPos += addLen;
			auto b = leg.segment.start + (direction * currentPos);
			q = leg.segment.start + (direction * (currentPos + addLen));

			target.push_back(InstanceT(style, { a, b }, p, q, incomingLength + currentPos - addLen, incomingLength + currentPos));
			p = a;
			a = b;
		}

		target.push_back(InstanceT(style, { a, leg.segment.end }, p, leg.next, incomingLength + currentPos, incomingLength + length));
	}

	static void ClipAndTessellate(std::vector<InstanceT>& target, lgal::gpu::AABB2d const& bounds, Leg leg, lgal::gpu::Vector2 const& style, gpu_float_t incomingLength, gpu_float_t maxInstanceLength)
	{
		lgal::gpu::LineSegment2 clipped = lmath::clip(bounds, leg.segment);
		if (clipped.start != clipped.end)		// only proceed if the segment intersects the box at all
		{
			if (clipped != leg.segment)			// update prev/next/segment if any clipping occurred
			{
				if (clipped.start != leg.segment.start) { leg.prev = leg.segment.start; }
				if (clipped.end != leg.segment.end) { leg.next = leg.segment.end; }
				leg.segment = clipped;
			}

			// clamp distance to prev/next
			lgal::gpu::Vector2 prevDelta = leg.prev - leg.segment.start;
			if (leg.prev != cEnd && lmath::len(prevDelta) > maxInstanceLength)
			{
				leg.prev = leg.segment.start + maxInstanceLength * lmath::normalize(prevDelta);
			}
			lgal::gpu::Vector2 nextDelta = leg.next - leg.segment.end;
			if (leg.next != cEnd && lmath::len(nextDelta) > maxInstanceLength)
			{
				leg.next = leg.segment.end + maxInstanceLength * lmath::normalize(nextDelta);
			}

			tessellate(target, leg, style, incomingLength, maxInstanceLength);
		}
	}

	void tessellate(std::vector<InstanceT>& instances, std::vector<lgal::gpu::Vector2> const& points, bool loop, lgal::gpu::Vector2 const& style, gpu_float_t maxInstanceLength)
	{
		// reserve an appropriate amount of memory
		instances.reserve(instances.size() + points.size());

		lgal::gpu::Vector2 prev = loop ? points.back() : cEnd;
		lgal::gpu::Vector2 next = cEnd;

		lgal::gpu::AABB2d bounds = lgal::gpu::AABB2d::unit();

		float length = 0;
		for (size_t i = 0; i + 1 < points.size(); ++i)		// iterate over all segments
		{
			lgal::gpu::LineSegment2 segment = { points[i], points[i + 1] };

			// assign prev point
			if (i > 0) { prev = points[i - 1]; }

			// assign next point
			if (i + 2 < points.size()) { next = points[i + 2]; }
			else if (loop) { next = points[0]; }
			else { next = cEnd; }

			Leg leg = { prev, segment, next };
			ClipAndTessellate(instances, bounds, leg, style, length, maxInstanceLength);
			length += segment.length();
		}

		// account for closing edge if the points form a loop
		if (loop)
		{
			prev = points[points.size() - 2];
			next = points[1];
			Leg leg = { prev, { points.back(), points.front() }, next };
			ClipAndTessellate(instances, bounds, leg, style, length, maxInstanceLength);
		}
	}

}