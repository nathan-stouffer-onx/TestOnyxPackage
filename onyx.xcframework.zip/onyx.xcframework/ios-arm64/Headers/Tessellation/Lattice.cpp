#include "Lattice.h"

#include <array>

#include <lucid/Profiler.h>
#include <lucid/spatial/IntervalTree.h>

namespace onyx::Tessellation
{

	Lattice::Lattice(uint32_t resolution)
		: mResolution(resolution)
	{
		generate();
	}

	void Lattice::generate()
	{
		// the number of vertices on each edge of the tile. we inset the grid by one cell and let the tessellation of the polygon boundary
		// handle the outside cell
		size_t edgeVertices = size_t(mResolution - 1);

		// corner aligned and 0-1 scale, transform in the shaders
		float stepSize = 1.0f / float(mResolution);

		mVertices.reserve(edgeVertices * edgeVertices);

		lgal::gpu::Vector2 v(0, 0);

		// calculate verts for the face triangles
		for (size_t y = 1; y <= edgeVertices; ++y)
		{
			v.y = float(y) * stepSize;
			for (size_t x = 1; x <= edgeVertices; ++x)
			{
				v.x = float(x) * stepSize;
				mVertices.push_back(v);
			}
		}
	}

	std::vector<lgal::gpu::Vector2> Lattice::intersect(lgal::gpu::Holygon const& holygon, float polyScale) const
	{
		std::vector<lgal::gpu::Vector2> result;
	
		result.reserve(mVertices.size());

		using TreeT = lucid::spatial::IntervalTree<gpu_float_t, lgal::gpu::LineSegment2>;
		std::vector<TreeT::Entry> entries;
		for (size_t i = 0; i < holygon.hull().size(); ++i)
		{
			lgal::gpu::LineSegment2 edge = holygon.hull().edge(i);
			gpu_float_t a = std::min(edge.start.y, edge.end.y);
			gpu_float_t b = std::max(edge.start.y, edge.end.y);
			entries.push_back({ lgal::gpu::Range(a, b), edge});
		}
		for (lgal::gpu::Polygon const& hole : holygon.holes())
		{
			for (size_t i = 0; i < hole.size(); ++i)
			{
				lgal::gpu::LineSegment2 edge = hole.edge(i);
				gpu_float_t a = std::min(edge.start.y, edge.end.y);
				gpu_float_t b = std::max(edge.start.y, edge.end.y);
				entries.push_back({ lgal::gpu::Range(a, b), edge });
			}
		}
		TreeT tree(std::move(entries));

		LUCID_PROFILE_SCOPE("cull lattice");
		for (auto const& v : mVertices)
		{
			auto query = v * polyScale;

			bool inside = false;
			if (holygon.aabb().contains(query))
			{
				// shoot a ray in the +x direction and determine containment by how many edges are crossed
				for (auto const& entry : tree.find(query.y))
				{
					lgal::gpu::LineSegment2 const& seg = entry.value;
					if (seg.distanceTo(query) == lmath::constants::zero<gpu_float_t>())
					{
						inside = false;
						break;
					}
					else if (lgal::gpu::Polygon::Intersects(seg, query))
					{
						inside = !inside;
					}
				}
			}

			if (inside)
			{
				result.push_back(query);
			}
		}

		return result;
	}

}