#include "Fills.h"

#include <cstring>

#include <array>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <lucid/Profiler.h>

#include <3rdParty/delaunator/delaunator.hpp>

#include "Tessellation/PolyGrid.h"
#include "Rendering/VertStructs.h"

namespace onyx::Tessellation
{

	static constexpr uint32_t cGridSize = 64;		// TODO expose this as a parameter to tessellation
	static constexpr float sSubdivisionSize = 1.f / float(cGridSize);
	//static constexpr float cMaxSideLength = sSubdivisionSize * (0.5 + 1.41421356237);	// TODO (stouff) actually compute this bound correctly, I noticed some missing triangles caused by this check
	//static constexpr float cMaxSquaredSideLength = cMaxSideLength * cMaxSideLength;
	static PolyGrid sSubdivisionGrid(cGridSize);
	static lgal::gpu::AABB2d sTileAABB = { { 0, 0 }, { 1, 1 } };

	struct Vertices
	{
	private:

		std::vector<lgal::gpu::Vector2> const& vertices;

	public:

		size_t hullSize;
		size_t boundarySize;

		Vertices(std::vector<lgal::gpu::Vector2> const& _vertices, size_t _hullSize, size_t _boundarySize) : vertices(_vertices), hullSize(_hullSize), boundarySize(_boundarySize) {}

		lgal::gpu::Vector2 const& operator[](size_t i) const { return vertices[i]; }

	};

	// We assume the corner is defined by p -> q -> r and winds counterclockwise
	struct Corner
	{
		
		lgal::gpu::Vector2 p;
		lgal::gpu::Vector2 q;
		lgal::gpu::Vector2 r;

		bool contains(lgal::gpu::Vector2 const& query) const
		{
			auto theta = lmath::angle(p - q, r     - q);	// angle between the previous edge and the next edge
			auto phi   = lmath::angle(p - q, query - q);	// angle between the previous edge and the query edge
			return phi >= theta;
		}

	};

	/**
	 * @brief Determine whether or not a triangle from the Delaunay triangulation should be kept for rendering
	 * 
	 * This function returns whether or not a triangle should be kept. It does this by determining if the triangle centroid is contained in the polygon.
	 * Point-in-polygon is a O(n) operation, and since this function is called for each triangle, we have O(n*m) time-complexity. Because of this, we
	 * check for a few conditions that allow us to avoid the bulk of Polygon::contains calls. The early-out conditions are based on the assumption that
	 * the vertices of the tessellated hull are placed at the beginning of the vertex buffer @p vertices. The conditions are as follows:
	 *     1. interior triangles: if no triangle vertex is part of the boundary, keep the triangle (not necessarily correct -- there are some inputs 
	 *        with interior triangles that should be culled)
	 *     2. hull triangles: if at least one vertex is on the hull boundary, we can use a O(1) operation to test if the triangle is contained in the hull
	 *        (though we still must check holes and include a special case for when the vertex has been clipped to the tile boundary)
	 * Otherwise, we just make a point-in-polygon query
	 * 
	 * @param vertices The vertex buffer
	 * @param i Index of triangle vertex
	 * @param j Index of triangle vertex
	 * @param k Index of triangle vertex
	 * @param hull The hull of the holygon
	 * @param holes The holes of the holygon
	 * @return Whether or not to keep the triangle
	*/
	static bool Keep(Vertices vertices, size_t const i, size_t const j, size_t const k, lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes)
	{
		// grab the vertices
		auto p = vertices[i];
		auto q = vertices[j];
		auto r = vertices[k];

		// TODO (stouff) after we figure out triangulation, apply these optimizations
		//auto longestSideLength = std::max(lmath::lenSquared(p - q), std::max(lmath::lenSquared(q - r), lmath::lenSquared(p - r)));
		//
		//// compute how many vertices are on the boundary of the hull
		//size_t hullBoundary = 0;
		//hullBoundary += static_cast<size_t>(i < vertices.hullSize);
		//hullBoundary += static_cast<size_t>(j < vertices.hullSize);
		//hullBoundary += static_cast<size_t>(k < vertices.hullSize);
		//
		//// compute how many vertices are on the boundary of the holygon
		//size_t boundary = 0;
		//boundary += static_cast<size_t>(i < vertices.boundarySize);
		//boundary += static_cast<size_t>(j < vertices.boundarySize);
		//boundary += static_cast<size_t>(k < vertices.boundarySize);
		//
		//if (longestSideLength > cMaxSquaredSideLength)	// one of the side lengths is too long, cull the triangle
		//{
		//	LUCID_PROFILE_SCOPE("big triangles");	// TODO (stouff) comment or delete profiling
		//	return false;
		//}
		//else if (boundary == 0)	// all three triangle vertices are interior, keep the triangle
		//{
		//	LUCID_PROFILE_SCOPE("interior triangles");	// TODO (stouff) comment or delete profiling
		//	return true;
		//}
		//else if (hullBoundary > 0)	// at least one vertex v is on the hull => we use the corner defined by v to determine containment in O(1) time (unless that point was clipped to tile)
		//{
		//	LUCID_PROFILE_SCOPE("hull triangles");	// TODO (stouff) comment or delete profiling
		//	auto centroid = (1.f / 3.f) * (p + q + r);
		//
		//	// the index of the vertex that is on the boundary of the hull
		//	size_t const curr = std::min(i, std::min(j, k));
		//	
		//	// the vertex was clipped to the tile boundary => fallback to regular point-in-polygon query
		//	if (lmath::onBoundary(sTileAABB, vertices[curr])) { return lmath::contains(hull, holes, centroid); }
		//
		//	size_t const prev = (curr == 0) ? vertices.hullSize - 1 : curr - 1;
		//	size_t const next = (curr + 1 == vertices.hullSize) ? 0 : curr + 1;
		//	Corner corner{ vertices[prev], vertices[curr], vertices[next] };
		//	if (!corner.contains(centroid))						// the centroid is outside the corner defined by this vertex => centroid is not in hull
		//	{
		//		return false;
		//	}
		//	else												// the centroid is inside the corner defined by this vertex => hull contains centroid
		//	{
		//		// check if a hole contains the centroid
		//		for (lgal::tile::Polygon const& hole : holes)
		//		{
		//			if (hole.contains(centroid)) { return false; }
		//		}
		//
		//		// if not in any holes, return true because we already know it to be in the hull
		//		return true;
		//	}
		//}
		//else
		{
			//LUCID_PROFILE_SCOPE("leftover triangles");	// TODO (stouff) comment or delete profiling
			auto centroid = (1.f / 3.f) * (p + q + r);
			return lmath::contains(hull, holes, centroid);
		}
	}

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("tessellate polygons");

		// entire polygon is clipped
		if (lmath::intersects(hull.aabb(), sTileAABB) == lmath::Intersections::NONE) { return; }

		std::vector<lgal::gpu::Polygon> subdivided;
		size_t hullSize = 0;
		size_t boundarySize = 0;
		{
			LUCID_PROFILE_SCOPE("tessellate boundaries");

			subdivided.push_back(lmath::subdivide(lmath::clip(hull, sTileAABB), sSubdivisionSize));
			hullSize = subdivided.back().size();
			boundarySize += hullSize;

			for (auto const& ring : holes)
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sTileAABB), sSubdivisionSize));
				boundarySize += subdivided.back().size();
			}

			if (boundarySize == 0) { return; }
		}

		auto latticePoints = sSubdivisionGrid.getLatticeVertices(hull, holes);
		auto latticeSize = latticePoints.size();
		
		std::vector<lgal::gpu::Vector2> vertData;
		{
			LUCID_PROFILE_SCOPE("copy vertices");

			vertData.resize(boundarySize + latticeSize);
			lgal::gpu::Vector2* vertPtr = vertData.data();

			size_t subdividedPtr = 0;
			for (auto const& poly : subdivided)
			{
				memcpy(vertPtr + subdividedPtr, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
				subdividedPtr += poly.size();
			}

			if (latticeSize > 0)
			{
				memcpy(vertPtr + boundarySize, latticePoints.data(), latticeSize * sizeof(gpu_float_t) * 2);
			}
		}

		LUCID_PROFILE_BEGIN("delaunation");
		delaunator::Delaunator<gpu_float_t> d(vertData);
		LUCID_PROFILE_END();

		// reserve memory for indices
		indices.reserve(d.triangles.size());

		{
			LUCID_PROFILE_SCOPE("cull triangles");
			
			size_t const* end = d.triangles.data() + d.triangles.size();
			for (size_t const* tri = d.triangles.data(); tri < end; tri += 3)
			{
				size_t const i = *(tri + 0);
				size_t const j = *(tri + 1);
				size_t const k = *(tri + 2);

				if (Keep({ vertData, hullSize, boundarySize }, i, j, k, hull, holes))
				{
					indices.push_back(uint16_t(i));
					indices.push_back(uint16_t(j));
					indices.push_back(uint16_t(k));
				}
			}

			vertices.reserve(vertData.size());
			for (auto const& v : vertData)
			{
				vertices.push_back({ v, style });
			}
		}
	}

}