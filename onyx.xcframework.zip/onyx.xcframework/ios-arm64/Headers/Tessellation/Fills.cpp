#include "Fills.h"

#include <cstring>

#include <array>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <lucid/Profiler.h>

#include <3rdParty/delanuator/delaunator.hpp>

#include "Tessellation/PolyGrid.h"
#include "Rendering/VertStructs.h"

namespace onyx {
namespace Tessellation {

	constexpr uint32_t cGridSize = 64;		// TODO expose this as a parameter to tessellation
	static PolyGrid sSubdivisionGrid(cGridSize);
	static float sSubdivisionSize = 1.f / float(cGridSize);
	static std::array<lgal::gpu::Vector2, 4> sClip = { { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 1, 0 } } };
	static lgal::gpu::AABB2d sTileAABB = { { 0, 0 }, { 1, 1 } };

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("tessellate polygons");

		if (lmath::intersects(hull.aabb(), sTileAABB) == lmath::Intersections::NONE)
		{
			return; // Entire polygon is clipped
		}

		auto gridPoints = sSubdivisionGrid.getContainedVertices(hull, holes);

		auto gridSize = gridPoints.size();
		std::vector<lgal::gpu::Vector2> vertData;
		std::vector<lgal::gpu::Polygon> subdivided;
		size_t loopSize = 0;
		lgal::gpu::Vector2* vertPtr = nullptr;

		{
			LUCID_PROFILE_SCOPE("prep triangulation");

			subdivided.push_back(lmath::subdivide(lmath::clip(hull, sClip), sSubdivisionSize));
			loopSize += subdivided.back().size();

			for (auto const& ring : holes)
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sClip), sSubdivisionSize));
				loopSize += subdivided.back().size();
			}

			if (loopSize == 0) { return; }

			vertData.resize(loopSize + gridSize);
			vertPtr = vertData.data();

			size_t subdividedPtr = 0;
			for (auto const& poly : subdivided)
			{
				memcpy(vertPtr + subdividedPtr, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
				subdividedPtr += poly.size();
			}

			if (gridSize > 0)
			{
				memcpy(vertPtr + loopSize, gridPoints.data(), gridSize * sizeof(gpu_float_t) * 2);
			}
		}

		LUCID_PROFILE_BEGIN("delaunation");
		delaunator::Delaunator<gpu_float_t> d((gpu_float_t*)vertPtr, (loopSize + gridSize) * 2);
		LUCID_PROFILE_END();

		// reserve memory for indices
		indices.reserve(d.triangles.size());

		{
			LUCID_PROFILE_SCOPE("cull triangles");
			
			size_t const* end = d.triangles.data() + d.triangles.size();
			for (size_t const* tri = d.triangles.data(); tri < end; tri += 3)
			{
				auto v0 = vertPtr[*(tri + 0)];
				auto v1 = vertPtr[*(tri + 1)];
				auto v2 = vertPtr[*(tri + 2)];
				
				auto centroid = (v0 + v1 + v2) * (1.f / 3.f);

				// check if the centroid is contained in the hull
				if (hull.contains(centroid))
				{
					// check if a hole contains the centroid
					bool inHole = false;
					for (lgal::tile::Polygon const& hole : holes)
					{
						if (hole.contains(centroid))
						{
							inHole = true;
							break;
						}
					}

					if (!inHole)
					{
						indices.push_back(uint16_t(*(tri + 0)));
						indices.push_back(uint16_t(*(tri + 1)));
						indices.push_back(uint16_t(*(tri + 2)));
					}
				}
			}

			vertices.reserve(vertData.size());
			for (auto const& v : vertData)
			{
				vertices.push_back({ v, style });
			}
		}
	}

} }