#include "Fills.h"

#include <cstring>

#include <array>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <lucid/Profiler.h>

#include <3rdParty/delaunator/delaunator.hpp>

#include "Tessellation/PolyGrid.h"
#include "Rendering/VertStructs.h"

namespace onyx::Tessellation
{

	static constexpr uint32_t cGridSize = 64;		// TODO expose this as a parameter to tessellation
	static constexpr float cSubdivisionSize = 1.f / float(cGridSize);
	//static constexpr float cMaxSideLength = sSubdivisionSize * (0.5 + 1.41421356237);	// TODO (stouff) actually compute this bound correctly, I noticed some missing triangles caused by this check
	//static constexpr float cMaxSquaredSideLength = cMaxSideLength * cMaxSideLength;
	static PolyGrid sSubdivisionGrid(cGridSize);
	static lgal::gpu::AABB2d sTileAABB = { { 0, 0 }, { 1, 1 } };

	struct Vertices
	{
	private:

		std::vector<lgal::gpu::Vector2> const& vertices;

	public:

		size_t hullSize;
		size_t boundarySize;

		Vertices(std::vector<lgal::gpu::Vector2> const& _vertices, size_t _hullSize, size_t _boundarySize) : vertices(_vertices), hullSize(_hullSize), boundarySize(_boundarySize) {}

		lgal::gpu::Vector2 const& operator[](size_t i) const { return vertices[i]; }

	};

	// We assume the corner is defined by p -> q -> r and winds counterclockwise
	struct Corner
	{
		
		lgal::gpu::Vector2 p;
		lgal::gpu::Vector2 q;
		lgal::gpu::Vector2 r;

		bool contains(lgal::gpu::Vector2 const& query) const
		{
			auto theta = lmath::angle(p - q, r     - q);	// angle between the previous edge and the next edge
			auto phi   = lmath::angle(p - q, query - q);	// angle between the previous edge and the query edge
			return phi >= theta;
		}

	};

	/**
	 * @brief Determine whether or not a triangle from the Delaunay triangulation should be kept for rendering
	 * 
	 * This function returns whether or not a triangle should be kept. It does this by determining if the triangle centroid is contained in the polygon.
	 * Point-in-polygon is a O(n) operation, and since this function is called for each triangle, we have O(n*m) time-complexity. Because of this, we
	 * check for a few conditions that allow us to avoid the bulk of Polygon::contains calls. The early-out conditions are based on the assumption that
	 * the vertices of the tessellated hull are placed at the beginning of the vertex buffer @p vertices. The conditions are as follows:
	 *     1. interior triangles: if no triangle vertex is part of the boundary, keep the triangle (not necessarily correct -- there are some inputs 
	 *        with interior triangles that should be culled)
	 *     2. hull triangles: if at least one vertex is on the hull boundary, we can use a O(1) operation to test if the triangle is contained in the hull
	 *        (though we still must check holes and include a special case for when the vertex has been clipped to the tile boundary)
	 * Otherwise, we just make a point-in-polygon query
	 * 
	 * @param vertices The vertex buffer
	 * @param i Index of triangle vertex
	 * @param j Index of triangle vertex
	 * @param k Index of triangle vertex
	 * @param hull The hull of the holygon
	 * @param holes The holes of the holygon
	 * @return Whether or not to keep the triangle
	*/
	static bool Keep(Vertices vertices, size_t const i, size_t const j, size_t const k, lgal::gpu::Holygon const& holygon)
	{
		// grab the vertices
		auto p = vertices[i];
		auto q = vertices[j];
		auto r = vertices[k];

		// TODO (stouff) after we figure out triangulation, apply these optimizations
		//auto longestSideLength = std::max(lmath::lenSquared(p - q), std::max(lmath::lenSquared(q - r), lmath::lenSquared(p - r)));
		//
		//// compute how many vertices are on the boundary of the hull
		//size_t hullBoundary = 0;
		//hullBoundary += static_cast<size_t>(i < vertices.hullSize);
		//hullBoundary += static_cast<size_t>(j < vertices.hullSize);
		//hullBoundary += static_cast<size_t>(k < vertices.hullSize);
		//
		//// compute how many vertices are on the boundary of the holygon
		//size_t boundary = 0;
		//boundary += static_cast<size_t>(i < vertices.boundarySize);
		//boundary += static_cast<size_t>(j < vertices.boundarySize);
		//boundary += static_cast<size_t>(k < vertices.boundarySize);
		//
		//if (longestSideLength > cMaxSquaredSideLength)	// one of the side lengths is too long, cull the triangle
		//{
		//	LUCID_PROFILE_SCOPE("big triangles");	// TODO (stouff) comment or delete profiling
		//	return false;
		//}
		//else if (boundary == 0)	// all three triangle vertices are interior, keep the triangle
		//{
		//	LUCID_PROFILE_SCOPE("interior triangles");	// TODO (stouff) comment or delete profiling
		//	return true;
		//}
		//else if (hullBoundary > 0)	// at least one vertex v is on the hull => we use the corner defined by v to determine containment in O(1) time (unless that point was clipped to tile)
		//{
		//	LUCID_PROFILE_SCOPE("hull triangles");	// TODO (stouff) comment or delete profiling
		//	auto centroid = (1.f / 3.f) * (p + q + r);
		//
		//	// the index of the vertex that is on the boundary of the hull
		//	size_t const curr = std::min(i, std::min(j, k));
		//	
		//	// the vertex was clipped to the tile boundary => fallback to regular point-in-polygon query
		//	if (lmath::onBoundary(sTileAABB, vertices[curr])) { return holygon.contains(centroid, lmath::Boundary::CLOSED); }
		//
		//	size_t const prev = (curr == 0) ? vertices.hullSize - 1 : curr - 1;
		//	size_t const next = (curr + 1 == vertices.hullSize) ? 0 : curr + 1;
		//	Corner corner{ vertices[prev], vertices[curr], vertices[next] };
		//	if (!corner.contains(centroid))						// the centroid is outside the corner defined by this vertex => centroid is not in hull
		//	{
		//		return false;
		//	}
		//	else												// the centroid is inside the corner defined by this vertex => hull contains centroid
		//	{
		//		// check if a hole contains the centroid
		//		for (lgal::tile::Polygon const& hole : holygon.holes())
		//		{
		//			if (hole.contains(centroid)) { return false; }
		//		}
		//
		//		// if not in any holes, return true because we already know it to be in the hull
		//		return true;
		//	}
		//}
		//else
		{
			//LUCID_PROFILE_SCOPE("leftover triangles");	// TODO (stouff) comment or delete profiling
			auto centroid = (1.f / 3.f) * (p + q + r);
			return holygon.contains(centroid, lmath::Boundary::CLOSED);
		}
	}

	void tessellateEntireTile(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("tesellate entire tile");

		size_t fenceposts = cGridSize + 1;

		{
			LUCID_PROFILE_SCOPE("add vertices");

			vertices.reserve(fenceposts * fenceposts);
			for (size_t y = 0; y <= cGridSize; ++y)
			{
				gpu_float_t v = static_cast<gpu_float_t>(y) * cSubdivisionSize;
				for (size_t x = 0; x <= cGridSize; ++x)
				{
					gpu_float_t u = static_cast<gpu_float_t>(x) * cSubdivisionSize;
					vertices.push_back({ { u, v }, style });
				}
			}
		}

		{
			LUCID_PROFILE_SCOPE("add indices");

			indices.reserve(2 * 3 * cGridSize * cGridSize);

			for (size_t y = 0; y < cGridSize; ++y)
			{
				for (size_t x = 0; x < cGridSize; ++x)
				{
					size_t offset = y * fenceposts + x;
					
					// add triangle for NW -> SW -> NE corners
					indices.push_back(static_cast<uint16_t>(offset + 0));
					indices.push_back(static_cast<uint16_t>(offset + fenceposts));
					indices.push_back(static_cast<uint16_t>(offset + 1));

					// add triangle for NE -> SW -> SE corners
					indices.push_back(static_cast<uint16_t>(offset + 1));
					indices.push_back(static_cast<uint16_t>(offset + fenceposts));
					indices.push_back(static_cast<uint16_t>(offset + 1 + fenceposts));
				}
			}
		}
	}

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("tessellate polygons");

		// entire polygon is clipped
		if (lmath::intersects(holygon.hull().aabb(), sTileAABB) == lmath::Intersections::NONE) { return; }

		if (holygon.contains(sTileAABB))
		{
			tessellateEntireTile(vertices, indices, style);
			return;
		}

		std::vector<lgal::gpu::Polygon> subdivided;
		size_t hullSize = 0;
		size_t boundarySize = 0;
		{
			LUCID_PROFILE_SCOPE("tessellate boundaries");

			subdivided.push_back(lmath::subdivide(lmath::clip(holygon.hull(), sTileAABB), cSubdivisionSize));
			hullSize = subdivided.back().size();
			boundarySize += hullSize;

			for (auto const& ring : holygon.holes())
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sTileAABB), cSubdivisionSize));
				boundarySize += subdivided.back().size();
			}

			if (boundarySize == 0) { return; }
		}

		auto latticePoints = sSubdivisionGrid.getLatticeVertices(holygon);
		auto latticeSize = latticePoints.size();
		
		std::vector<lgal::gpu::Vector2> vertData;
		{
			LUCID_PROFILE_SCOPE("copy vertices");

			vertData.resize(boundarySize + latticeSize);
			lgal::gpu::Vector2* vertPtr = vertData.data();

			size_t subdividedPtr = 0;
			for (auto const& poly : subdivided)
			{
				memcpy(vertPtr + subdividedPtr, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
				subdividedPtr += poly.size();
			}

			if (latticeSize > 0)
			{
				memcpy(vertPtr + boundarySize, latticePoints.data(), latticeSize * sizeof(gpu_float_t) * 2);
			}
		}

		LUCID_PROFILE_BEGIN("delaunation");
		delaunator::Delaunator<gpu_float_t> delaunation(vertData);
		LUCID_PROFILE_END();

		// when necessary, flip the quad diagonal
		{
			LUCID_PROFILE_SCOPE("flip crossings");
			for (size_t e = 0; e < delaunation.triangles.size(); ++e)
			{
				size_t e_bar = delaunation.halfedges[e];
				if (e_bar == delaunator::INVALID_INDEX) { continue; }	// check that there is a triangle that completes the quad
				
				// compute the indices of the four points in this quad
				size_t a = delaunation.triangles[e];
				size_t b = delaunation.triangles[e_bar];
				size_t c = delaunation.triangles[delaunator::prev(e)];
				size_t d = delaunation.triangles[delaunator::prev(e_bar)];

				// the four points forming the quad (p_a and p_b are the start/end points of the edge in question)
				lgal::gpu::Vector2 p_a = vertData[a];
				lgal::gpu::Vector2 p_b = vertData[b];
				lgal::gpu::Vector2 p_c = vertData[c];
				lgal::gpu::Vector2 p_d = vertData[d];

				if (lmath::dot(lgal::gpu::Vector2(-1, 1), p_b - p_a) == 0.f && lmath::convexHullIsSquare(p_a, p_b, p_c, p_d))
				{
					// update the triangles
					delaunation.triangles[delaunator::next(e)] = d;
					delaunation.triangles[delaunator::next(e_bar)] = c;

					// update the halfedges
					delaunation.halfedges[e] = d;
					delaunation.halfedges[e_bar] = c;
				}
			}
		}

		// reserve memory for indices
		indices.reserve(delaunation.triangles.size());

		{
			LUCID_PROFILE_SCOPE("cull triangles");
			
			size_t const* end = delaunation.triangles.data() + delaunation.triangles.size();
			for (size_t const* tri = delaunation.triangles.data(); tri < end; tri += 3)
			{
				size_t const i = *(tri + 0);
				size_t const j = *(tri + 1);
				size_t const k = *(tri + 2);

				if (Keep({ vertData, hullSize, boundarySize }, i, j, k, holygon))
				{
					indices.push_back(uint16_t(i));
					indices.push_back(uint16_t(j));
					indices.push_back(uint16_t(k));
				}
			}

			vertices.reserve(vertData.size());
			for (auto const& v : vertData)
			{
				vertices.push_back({ v, style });
			}
		}
	}

}