#include "Fills.h"

#include <cstring>

#include <array>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <lucid/Profiler.h>
#include <CDT.h>
#include <3rdParty/delaunator/delaunator.hpp>

#include "Tessellation/PolyLattice.h"
#include "Rendering/VertStructs.h"

namespace onyx::Tessellation
{

	static constexpr uint32_t cGridSize = 64;		// TODO expose this as a parameter to tessellation
	static constexpr float cSubdivisionSize = 1.f / float(cGridSize);
	static PolyLattice sPolyLattice(cGridSize);
	static lgal::gpu::AABB2d sTileAABB = { { 0, 0 }, { 1, 1 } };

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("tessellate holygon");

		if (lmath::intersects(holygon.hull().aabb(), sTileAABB) == lmath::Intersections::NONE)
		{
			return;
		}
		else if (holygon.contains(sTileAABB))
		{
			hardcoded(vertices, indices, style);
		}
		// TODO see ONYX-455 to re-enable this minor optimization
		//else if (holygon.isConvex())		
		//{
		//	delaunay(vertices, indices, holygon, style);
		//}
		else
		{
			constrained(vertices, indices, holygon, style);
		}
	}

	void hardcoded(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("hardcoded");

		size_t fenceposts = cGridSize + 1;

		{
			LUCID_PROFILE_SCOPE("add vertices");

			vertices.reserve(fenceposts * fenceposts);
			for (size_t y = 0; y <= cGridSize; ++y)
			{
				gpu_float_t v = static_cast<gpu_float_t>(y) * cSubdivisionSize;
				for (size_t x = 0; x <= cGridSize; ++x)
				{
					gpu_float_t u = static_cast<gpu_float_t>(x) * cSubdivisionSize;
					vertices.push_back({ { u, v }, style });
				}
			}
		}

		{
			LUCID_PROFILE_SCOPE("add indices");

			indices.reserve(2 * 3 * cGridSize * cGridSize);

			for (size_t y = 0; y < cGridSize; ++y)
			{
				for (size_t x = 0; x < cGridSize; ++x)
				{
					size_t offset = y * fenceposts + x;
					
					// add triangle for NW -> NE -> SW corners
					indices.push_back(static_cast<uint16_t>(offset + 0));
					indices.push_back(static_cast<uint16_t>(offset + 1));
					indices.push_back(static_cast<uint16_t>(offset + fenceposts));

					// add triangle for NE -> SE -> SW corners
					indices.push_back(static_cast<uint16_t>(offset + 1));
					indices.push_back(static_cast<uint16_t>(offset + 1 + fenceposts));
					indices.push_back(static_cast<uint16_t>(offset + fenceposts));
				}
			}
		}
	}

	void delaunay(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("delaunay");

		std::vector<lgal::gpu::Polygon> subdivided;
		size_t hullSize = 0;
		size_t boundarySize = 0;
		{
			LUCID_PROFILE_SCOPE("tessellate boundaries");

			subdivided.push_back(lmath::subdivide(lmath::clip(holygon.hull(), sTileAABB), cSubdivisionSize));
			hullSize = subdivided.back().size();
			boundarySize += hullSize;

			for (auto const& ring : holygon.holes())
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sTileAABB), cSubdivisionSize));
				boundarySize += subdivided.back().size();
			}

			if (boundarySize == 0) { return; }
		}

		auto latticePoints = sPolyLattice.intersect(holygon);
		auto latticeSize = latticePoints.size();

		std::vector<lgal::gpu::Vector2> vertData;
		{
			LUCID_PROFILE_SCOPE("copy vertices");

			vertData.resize(boundarySize + latticeSize);
			lgal::gpu::Vector2* vertPtr = vertData.data();

			size_t subdividedPtr = 0;
			for (auto const& poly : subdivided)
			{
				memcpy(vertPtr + subdividedPtr, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
				subdividedPtr += poly.size();
			}

			if (latticeSize > 0)
			{
				memcpy(vertPtr + boundarySize, latticePoints.data(), latticeSize * sizeof(gpu_float_t) * 2);
			}
		}

		LUCID_PROFILE_BEGIN("delaunator");
		delaunator::Delaunator<gpu_float_t> delaunation(vertData);
		LUCID_PROFILE_END();

		// when necessary, flip the quad diagonal
		{
			LUCID_PROFILE_SCOPE("flip crossings");
			for (size_t e = 0; e < delaunation.triangles.size(); ++e)
			{
				size_t e_bar = delaunation.halfedges[e];
				if (e_bar == delaunator::INVALID_INDEX) { continue; }	// check that there is a triangle that completes the quad

				// compute the indices of the four points in this quad
				size_t a = delaunation.triangles[e];
				size_t b = delaunation.triangles[e_bar];
				size_t c = delaunation.triangles[delaunator::prev(e)];
				size_t d = delaunation.triangles[delaunator::prev(e_bar)];

				// the four points forming the quad (p_a and p_b are the start/end points of the edge in question)
				lgal::gpu::Vector2 p_a = vertData[a];
				lgal::gpu::Vector2 p_b = vertData[b];
				lgal::gpu::Vector2 p_c = vertData[c];
				lgal::gpu::Vector2 p_d = vertData[d];

				if (lmath::dot(lgal::gpu::Vector2(-1, 1), p_b - p_a) == 0.f && lmath::convexHullIsSquare(p_a, p_b, p_c, p_d))
				{
					// update the triangles
					delaunation.triangles[delaunator::next(e)] = d;
					delaunation.triangles[delaunator::next(e_bar)] = c;

					// update the halfedges
					delaunation.halfedges[e] = d;
					delaunation.halfedges[e_bar] = c;
				}
			}
		}

		// reserve memory for indices
		indices.reserve(delaunation.triangles.size());

		{
			LUCID_PROFILE_SCOPE("copy mesh");

			size_t const* end = delaunation.triangles.data() + delaunation.triangles.size();
			for (size_t const* tri = delaunation.triangles.data(); tri < end; tri += 3)
			{
				size_t const i = *(tri + 0);
				size_t const j = *(tri + 1);
				size_t const k = *(tri + 2);

				// flip winding order to match CDT
				indices.push_back(uint16_t(i));
				indices.push_back(uint16_t(k));
				indices.push_back(uint16_t(j));
			}

			vertices.reserve(vertData.size());
			for (auto const& v : vertData)
			{
				vertices.push_back({ v, style });
			}
		}
	}

	static lgal::tile::Vector2 Vec2(CDT::V2d<gpu_float_t> const& p)
	{
		return { p.x, p.y };
	}

	static bool Shares(CDT::Triangle const& tri, CDT::VertInd i)
	{
		return tri.vertices[0] == i || tri.vertices[1] == i || tri.vertices[2] == i;
	}

	// return the argument of the index that nbr does not share with tri
	static size_t ArgDistinct(CDT::Triangle const& tri, CDT::Triangle const& nbr)
	{
		for (size_t i = 0; i < 3; ++i)
		{
			if (!Shares(tri, nbr.vertices[i])) { return i; }
		}
		return CDT::invalidIndex;
	}

	void constrained(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("constrained");

		std::vector<lgal::gpu::Polygon> subdivided;
		size_t hullSize = 0;
		size_t boundarySize = 0;
		{
			LUCID_PROFILE_SCOPE("tessellate boundaries");

			subdivided.push_back(lmath::subdivide(lmath::clip(holygon.hull(), sTileAABB), cSubdivisionSize));
			hullSize = subdivided.back().size();
			boundarySize += hullSize;

			for (auto const& ring : holygon.holes())
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sTileAABB), cSubdivisionSize));
				boundarySize += subdivided.back().size();
			}

			if (boundarySize == 0) { return; }
		}

		auto latticePoints = sPolyLattice.intersect(holygon);
		auto latticeSize = latticePoints.size();
		
		std::vector<CDT::V2d<gpu_float_t>> vertData;
		std::vector<CDT::Edge> edges;
		CDT::V2d<gpu_float_t>* vertPtr = nullptr;
		{
			LUCID_PROFILE_SCOPE("prep triangulation");

			vertData.resize(boundarySize + latticeSize);
			vertPtr = vertData.data();
			edges.reserve(boundarySize);

			size_t offset = 0;
			using SizeT = CDT::IndexSizeType;
			for (lgal::tile::Polygon const& poly : subdivided)
			{
				if (poly.size() > 0)
				{
					memcpy(vertPtr + offset, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
					for (SizeT i = 0; i + 1 < poly.size(); ++i)
					{
						edges.push_back({ i + static_cast<SizeT>(offset), i + 1 + static_cast<SizeT>(offset) });
					}
					edges.push_back({ static_cast<SizeT>(poly.size() - 1 + offset), static_cast<SizeT>(offset) });
					offset += poly.size();
				}
			}

			if (latticeSize > 0)
			{
				memcpy(vertPtr + boundarySize, latticePoints.data(), latticeSize * sizeof(gpu_float_t) * 2);
			}

			CDT::RemoveDuplicatesAndRemapEdges(vertData, edges);
		}

		CDT::Triangulation<gpu_float_t> cdt;
		{
			LUCID_PROFILE_SCOPE("triangulate");
			cdt.insertVertices(vertData);
			cdt.insertEdges(edges);
		}

		{
			LUCID_PROFILE_SCOPE("cull triangles");
			cdt.eraseOuterTrianglesAndHoles();
		}

		{
			LUCID_PROFILE_SCOPE("flip crossings");
			for (size_t t = 0; t < cdt.triangles.size(); ++t)
			{
				CDT::Triangle const& tri = cdt.triangles[t];
				for (CDT::TriInd const n : tri.neighbors)
				{
					if (n != CDT::invalidIndex)
					{
						CDT::Triangle const& nbr = cdt.triangles[n];

						size_t i = ArgDistinct(nbr, tri);

						CDT::VertInd a = tri.vertices[(i + 1) % 3];
						CDT::VertInd b = tri.vertices[(i + 2) % 3];
						CDT::VertInd c = tri.vertices[(i + 0) % 3];
						CDT::VertInd d = nbr.vertices[ArgDistinct(tri, nbr)];

						// the four points forming the quad (p_a and p_b are the start/end points of the edge in question)
						lgal::gpu::Vector2 p_a = Vec2(cdt.vertices[a]);
						lgal::gpu::Vector2 p_b = Vec2(cdt.vertices[b]);
						lgal::gpu::Vector2 p_c = Vec2(cdt.vertices[c]);
						lgal::gpu::Vector2 p_d = Vec2(cdt.vertices[d]);

						if (lmath::dot(lgal::gpu::Vector2(-1, 1), p_b - p_a) == 0.f && lmath::convexHullIsSquare(p_a, p_b, p_c, p_d))
						{
							cdt.flipEdge(static_cast<CDT::TriInd>(t), n);
							break;
						}
					}
				}
			}
		}

		{
			LUCID_PROFILE_SCOPE("copy mesh");

			for (auto const& v : vertData) { vertices.push_back({ { v.x, v.y }, style }); }

			indices.reserve(3 * cdt.triangles.size());
			for (auto const& triangle : cdt.triangles)
			{
				indices.push_back(static_cast<uint16_t>(triangle.vertices[0]));
				indices.push_back(static_cast<uint16_t>(triangle.vertices[1]));
				indices.push_back(static_cast<uint16_t>(triangle.vertices[2]));
			}
		}
	}

}