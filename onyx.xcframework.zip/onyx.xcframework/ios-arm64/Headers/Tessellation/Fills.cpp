#include "Fills.h"

#include <cstring>

#include <array>

#include <lucid/gal/Types.h>
#include <lucid/math/Algorithm.h>
#include <lucid/Profiler.h>
#include <CDT.h>
#include <3rdParty/delaunator/delaunator.hpp>
#include <3rdParty/earcut/earcut.h>

#include "Tessellation/Lattice.h"
#include "Rendering/VertStructs.h"

namespace onyx::Tessellation
{

	struct Hardcoded
	{
		std::vector<Rendering::VertStructs::UV2> vertices;
		std::vector<uint16_t> indices;

		explicit Hardcoded(uint32_t resolution)
		{
			// reserve memory 
			size_t fenceposts = resolution + 1;
			vertices.reserve(fenceposts * fenceposts);
			indices.reserve(2 * 3 * resolution * resolution);

			float delta = 1.f / static_cast<float>(resolution);
			// compute vertices
			for (size_t y = 0; y <= resolution; ++y)
			{
				gpu_float_t v = static_cast<gpu_float_t>(y) * delta;
				for (size_t x = 0; x <= resolution; ++x)
				{
					gpu_float_t u = static_cast<gpu_float_t>(x) * delta;
					vertices.push_back({ { u, v }, { 0, 0 } });
				}
			}

			// compute indices
			for (size_t y = 0; y < resolution; ++y)
			{
				for (size_t x = 0; x < resolution; ++x)
				{
					size_t offset = y * fenceposts + x;

					// add triangle for NW -> NE -> SW corners
					indices.push_back(static_cast<uint16_t>(offset + 0));
					indices.push_back(static_cast<uint16_t>(offset + 1));
					indices.push_back(static_cast<uint16_t>(offset + fenceposts));

					// add triangle for NE -> SE -> SW corners
					indices.push_back(static_cast<uint16_t>(offset + 1));
					indices.push_back(static_cast<uint16_t>(offset + 1 + fenceposts));
					indices.push_back(static_cast<uint16_t>(offset + fenceposts));
				}
			}
		}

	};

}

namespace onyx::Tessellation
{

	static lgal::gpu::AABB2d sTileAABB = { { 0, 0 }, { 1, 1 } };
	
	static std::array<Lattice, 7> cLattices = { Lattice(1), Lattice(2), Lattice(4), Lattice(8), Lattice(16), Lattice(32), Lattice(64) };
	static std::array<Hardcoded, 7> cHardcoded = { Hardcoded(1), Hardcoded(2), Hardcoded(4), Hardcoded(8), Hardcoded(16), Hardcoded(32), Hardcoded(64) };

	struct Params
	{
		size_t resolution;
		gpu_float_t subdivisionSize;
		Lattice const& lattice;
		Hardcoded const& hardcoded;

		static Params Compute(uint16_t meshResolution)
		{
			size_t i = static_cast<size_t>(std::clamp(static_cast<int>(std::log2(meshResolution)), 0, 6));
			size_t resolution = static_cast<size_t>(1) << i;
			gpu_float_t subdivisionSize = 1.f / static_cast<gpu_float_t>(resolution);
			return { resolution, subdivisionSize, cLattices[i], cHardcoded[i] };
		}

	};

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, uint16_t resolution, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("tessellate holygon");

		if (lmath::intersects(holygon.hull().aabb(), sTileAABB) == lmath::Intersections::NONE)
		{
			return;
		}
		else if (holygon.contains(sTileAABB))
		{
			hardcoded(vertices, indices, resolution, style);
		}
		else if (resolution == 1 || holygon.hull().aabb().area() < (2.f / resolution) * (2.f / resolution))
		{
			earcut(vertices, indices, holygon, style);
		}
		// TODO see CSONYX-117 to re-enable this minor optimization
		//else if (holygon.isConvex())		
		//{
		//	delaunay(vertices, indices, holygon, resolution, style);
		//}
		else
		{
			constrained(vertices, indices, holygon, resolution, style);
		}
	}

	void hardcoded(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, uint16_t resolution, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("hardcoded");

		Params params = Params::Compute(resolution);
		Hardcoded const& hardcoded = params.hardcoded;

		{
			LUCID_PROFILE_SCOPE("add vertices");
			size_t i = vertices.size();
			vertices.reserve(hardcoded.vertices.size());
			vertices.insert(vertices.end(), hardcoded.vertices.begin(), hardcoded.vertices.end());
			auto ptr = &vertices[i];
			while (i++ < vertices.size())
			{
				(ptr++)->uv2 = style;
			}
		}

		{
			LUCID_PROFILE_SCOPE("add indices");
			indices.reserve(hardcoded.indices.size());
			indices.insert(indices.end(), hardcoded.indices.begin(), hardcoded.indices.end());
		}
	}

	using Point = std::array<float, 2>;

	static void Copy(std::vector<Point>& ring, lgal::gpu::Polygon const& polygon)
	{
		ring.reserve(polygon.size());
		Point p;
		for (lgal::gpu::Vector2 const& point : polygon.getPoints())
		{
			p[0] = point.x;
			p[1] = point.y;
			ring.push_back(p);
		}
	}

	void earcut(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("earcut");

		std::vector<std::vector<Point>> rings;

		{
			LUCID_PROFILE_SCOPE("copy vertices");

			rings.resize(1 + holygon.holes().size());

			Copy(rings[0], holygon.hull());

			size_t i = 1;
			for (lgal::gpu::Polygon const& hole : holygon.holes())
			{
				Copy(rings[i++], hole);
			}
		}

		LUCID_PROFILE_BEGIN("triangulate");
		std::vector<uint16_t> earcut = Earcut::earcut<uint16_t>(rings);
		LUCID_PROFILE_END();

		{
			LUCID_PROFILE_SCOPE("copy mesh");

			indices.insert(indices.end(), earcut.begin(), earcut.end());

			// reserve space in vertices
			{
				size_t count = holygon.hull().size();
				for (lgal::gpu::Polygon const& hole : holygon.holes())
				{
					count += hole.size();
				}
				vertices.reserve(vertices.size() + count);
			}

			// copy vertex data
			{
				for (lgal::gpu::Vector2 const& v : holygon.hull().getPoints())
				{
					vertices.push_back({ v, style });
				}

				for (lgal::gpu::Polygon const& hole : holygon.holes())
				{
					for (lgal::gpu::Vector2 const& v : hole.getPoints())
					{
						vertices.push_back({ v, style });
					}
				}
			}
		}
	}

	void delaunay(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, uint16_t resolution, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("delaunay");

		Params params = Params::Compute(resolution);

		std::vector<lgal::gpu::Polygon> subdivided;
		size_t hullSize = 0;
		size_t boundarySize = 0;
		{
			LUCID_PROFILE_SCOPE("tessellate boundaries");

			subdivided.push_back(lmath::subdivide(lmath::clip(holygon.hull(), sTileAABB), params.subdivisionSize));
			hullSize = subdivided.back().size();
			boundarySize += hullSize;

			for (auto const& ring : holygon.holes())
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sTileAABB), params.subdivisionSize));
				boundarySize += subdivided.back().size();
			}

			if (boundarySize == 0) { return; }
		}

		auto latticePoints = params.lattice.intersect(holygon);
		auto latticeSize = latticePoints.size();

		std::vector<lgal::gpu::Vector2> vertData;
		{
			LUCID_PROFILE_SCOPE("copy vertices");

			vertData.resize(boundarySize + latticeSize);
			lgal::gpu::Vector2* vertPtr = vertData.data();

			size_t subdividedPtr = 0;
			for (auto const& poly : subdivided)
			{
				memcpy(vertPtr + subdividedPtr, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
				subdividedPtr += poly.size();
			}

			if (latticeSize > 0)
			{
				memcpy(vertPtr + boundarySize, latticePoints.data(), latticeSize * sizeof(gpu_float_t) * 2);
			}
		}

		LUCID_PROFILE_BEGIN("delaunator");
		delaunator::Delaunator<gpu_float_t> delaunation(vertData);
		LUCID_PROFILE_END();

		// when necessary, flip the quad diagonal
		{
			LUCID_PROFILE_SCOPE("flip crossings");
			for (size_t e = 0; e < delaunation.triangles.size(); ++e)
			{
				size_t e_bar = delaunation.halfedges[e];
				if (e_bar == delaunator::INVALID_INDEX) { continue; }	// check that there is a triangle that completes the quad

				// compute the indices of the four points in this quad
				size_t a = delaunation.triangles[e];
				size_t b = delaunation.triangles[e_bar];
				size_t c = delaunation.triangles[delaunator::prev(e)];
				size_t d = delaunation.triangles[delaunator::prev(e_bar)];

				// the four points forming the quad (p_a and p_b are the start/end points of the edge in question)
				lgal::gpu::Vector2 p_a = vertData[a];
				lgal::gpu::Vector2 p_b = vertData[b];
				lgal::gpu::Vector2 p_c = vertData[c];
				lgal::gpu::Vector2 p_d = vertData[d];

				if (lmath::dot(lgal::gpu::Vector2(-1, 1), p_b - p_a) == 0.f && lmath::convexHullIsSquare(p_a, p_b, p_c, p_d))
				{
					// update the triangles
					delaunation.triangles[delaunator::next(e)] = d;
					delaunation.triangles[delaunator::next(e_bar)] = c;

					// update the halfedges
					delaunation.halfedges[e] = d;
					delaunation.halfedges[e_bar] = c;
				}
			}
		}

		// reserve memory for indices
		indices.reserve(indices.size() + delaunation.triangles.size());

		{
			LUCID_PROFILE_SCOPE("copy mesh");

			size_t const* end = delaunation.triangles.data() + delaunation.triangles.size();
			for (size_t const* tri = delaunation.triangles.data(); tri < end; tri += 3)
			{
				size_t const i = *(tri + 0);
				size_t const j = *(tri + 1);
				size_t const k = *(tri + 2);

				// flip winding order to match CDT
				indices.push_back(uint16_t(i));
				indices.push_back(uint16_t(k));
				indices.push_back(uint16_t(j));
			}

			vertices.reserve(vertices.size() + vertData.size());
			for (auto const& v : vertData)
			{
				vertices.push_back({ v, style });
			}
		}
	}

	static lgal::tile::Vector2 Vec2(CDT::V2d<gpu_float_t> const& p)
	{
		return { p.x, p.y };
	}

	static bool Shares(CDT::Triangle const& tri, CDT::VertInd i)
	{
		return tri.vertices[0] == i || tri.vertices[1] == i || tri.vertices[2] == i;
	}

	// return the argument of the index that nbr does not share with tri
	static size_t ArgDistinct(CDT::Triangle const& tri, CDT::Triangle const& nbr)
	{
		for (size_t i = 0; i < 3; ++i)
		{
			if (!Shares(tri, nbr.vertices[i])) { return i; }
		}
		return CDT::invalidIndex;
	}

	void constrained(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, uint16_t resolution, lgal::gpu::Vector2 const& style)
	{
		LUCID_PROFILE_SCOPE("constrained");

		Params params = Params::Compute(resolution);

		std::vector<lgal::gpu::Polygon> subdivided;
		size_t hullSize = 0;
		size_t boundarySize = 0;
		{
			LUCID_PROFILE_SCOPE("tessellate boundaries");

			subdivided.push_back(lmath::subdivide(lmath::clip(holygon.hull(), sTileAABB), params.subdivisionSize));
			hullSize = subdivided.back().size();
			boundarySize += hullSize;

			for (auto const& ring : holygon.holes())
			{
				subdivided.push_back(lmath::subdivide(lmath::clip(ring, sTileAABB), params.subdivisionSize));
				boundarySize += subdivided.back().size();
			}

			if (boundarySize == 0) { return; }
		}

		auto latticePoints = params.lattice.intersect(holygon);
		auto latticeSize = latticePoints.size();
		
		std::vector<CDT::V2d<gpu_float_t>> vertData;
		std::vector<CDT::Edge> edges;
		CDT::V2d<gpu_float_t>* vertPtr = nullptr;
		{
			LUCID_PROFILE_SCOPE("prep triangulation");

			vertData.resize(boundarySize + latticeSize);
			vertPtr = vertData.data();
			edges.reserve(boundarySize);

			size_t offset = 0;
			using SizeT = CDT::IndexSizeType;
			for (lgal::tile::Polygon const& poly : subdivided)
			{
				if (poly.size() > 0)
				{
					memcpy(vertPtr + offset, poly.getPoints().data(), poly.size() * sizeof(gpu_float_t) * 2);
					for (SizeT i = 0; i + 1 < poly.size(); ++i)
					{
						edges.push_back({ i + static_cast<SizeT>(offset), i + 1 + static_cast<SizeT>(offset) });
					}
					edges.push_back({ static_cast<SizeT>(poly.size() - 1 + offset), static_cast<SizeT>(offset) });
					offset += poly.size();
				}
			}

			if (latticeSize > 0)
			{
				memcpy(vertPtr + boundarySize, latticePoints.data(), latticeSize * sizeof(gpu_float_t) * 2);
			}

			CDT::RemoveDuplicatesAndRemapEdges(vertData, edges);
		}

		CDT::Triangulation<gpu_float_t> cdt;
		{
			LUCID_PROFILE_SCOPE("triangulate");
			cdt.insertVertices(vertData);
			cdt.insertEdges(edges);
		}

		{
			LUCID_PROFILE_SCOPE("cull triangles");
			if (holygon.holes().size() > 0)
			{
				LUCID_PROFILE_SCOPE("has holes");
				cdt.eraseOuterTrianglesAndHoles();
			}
			else
			{
				LUCID_PROFILE_SCOPE("not holes");
				cdt.eraseOuterTriangles();
			}
		}

		{
			LUCID_PROFILE_SCOPE("flip crossings");
			for (size_t t = 0; t < cdt.triangles.size(); ++t)
			{
				CDT::Triangle const& tri = cdt.triangles[t];
				for (CDT::TriInd const n : tri.neighbors)
				{
					if (n != CDT::invalidIndex)
					{
						CDT::Triangle const& nbr = cdt.triangles[n];

						size_t i = ArgDistinct(nbr, tri);

						CDT::VertInd a = tri.vertices[(i + 1) % 3];
						CDT::VertInd b = tri.vertices[(i + 2) % 3];
						CDT::VertInd c = tri.vertices[(i + 0) % 3];
						CDT::VertInd d = nbr.vertices[ArgDistinct(tri, nbr)];

						// the four points forming the quad (p_a and p_b are the start/end points of the edge in question)
						lgal::gpu::Vector2 p_a = Vec2(cdt.vertices[a]);
						lgal::gpu::Vector2 p_b = Vec2(cdt.vertices[b]);
						lgal::gpu::Vector2 p_c = Vec2(cdt.vertices[c]);
						lgal::gpu::Vector2 p_d = Vec2(cdt.vertices[d]);

						if (lmath::dot(lgal::gpu::Vector2(-1, 1), p_b - p_a) == 0.f && lmath::convexHullIsSquare(p_a, p_b, p_c, p_d))
						{
							cdt.flipEdge(static_cast<CDT::TriInd>(t), n);
							break;
						}
					}
				}
			}
		}

		{
			LUCID_PROFILE_SCOPE("copy mesh");

			vertices.reserve(vertices.size() + vertData.size());
			for (auto const& v : vertData) { vertices.push_back({ { v.x, v.y }, style }); }

			indices.reserve(indices.size() + 3 * cdt.triangles.size());
			for (auto const& triangle : cdt.triangles)
			{
				indices.push_back(static_cast<uint16_t>(triangle.vertices[0]));
				indices.push_back(static_cast<uint16_t>(triangle.vertices[1]));
				indices.push_back(static_cast<uint16_t>(triangle.vertices[2]));
			}
		}
	}

}