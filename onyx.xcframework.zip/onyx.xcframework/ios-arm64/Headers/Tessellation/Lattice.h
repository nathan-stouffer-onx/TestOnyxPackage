#pragma once

#include <vector>

#include <lucid/gal/Types.h>

#include "Utils/property.h"

namespace onyx::Tessellation
{

	class Lattice
	{
	public:

		Lattice(uint32_t resolution = 64);

		std::vector<lgal::gpu::Vector2> intersect(lgal::gpu::Holygon const& holygon, float polyScale = 1) const;

		GET_PROP(Resolution, uint32_t, 64);

		size_t getVertexCount() const { return mVertices.size(); }

	private:

		static constexpr uint16_t sFaceStride = 3;
		std::vector<lgal::gpu::Vector2> mVertices;

		void generate();
	};

}
