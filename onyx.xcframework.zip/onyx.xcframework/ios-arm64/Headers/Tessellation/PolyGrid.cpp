#include "PolyGrid.h"

#include <array>

#include <lucid/Profiler.h>

namespace onyx::Tessellation
{

	PolyGrid::PolyGrid(uint32_t resolution)
		: mResolution(resolution)
	{
		generateGrid();
	}

	void PolyGrid::generateGrid()
	{
		// the number of vertices on each edge of the tile. we inset the grid by one cell and let the tessellation of the polygon boundary
		// handle the outside cell
		size_t edgeVertices = size_t(mResolution - 1);

		// corner aligned and 0-1 scale, transform in the shaders
		float stepSize = 1.0f / float(mResolution);

		mVertices.reserve(edgeVertices * edgeVertices);

		lgal::gpu::Vector2 v(0, 0);

		// calculate verts for the face triangles
		for (size_t y = 1; y <= edgeVertices; ++y)
		{
			v.y = float(y) * stepSize;
			for (size_t x = 1; x <= edgeVertices; ++x)
			{
				v.x = float(x) * stepSize;
				mVertices.push_back(v);
			}
		}
	}

	std::vector<lgal::gpu::Vector2> PolyGrid::getLatticeVertices(lgal::gpu::Holygon const& holygon, float polyScale) const
	{
		std::vector<lgal::gpu::Vector2> result;
	
		if (holygon.hull().aabb().area() < ((2.f / mResolution) * (2.f / mResolution)))
		{
			return result;	// The polygon is too small to be worth subdividing
		}

		result.reserve(mVertices.size());

		LUCID_PROFILE_SCOPE("cull lattice");
		for (auto const& v : mVertices)
		{
			auto p = v * polyScale;
			if (holygon.contains(p, lmath::Boundary::OPEN))
			{
				result.push_back(p);
			}
		}

		return result;
	}

}