#include "PolyGrid.h"

#include <array>

#include <lucid/Profiler.h>

namespace onyx {
namespace Tessellation {

	PolyGrid::PolyGrid(uint32_t resolution)
		: mResolution(resolution)
	{
		generateGrid();
	}

	void PolyGrid::generateGrid()
	{
		// the number of vertices on each edge of the tile
		size_t edgeVertices = size_t(mResolution - 1);

		// corner aligned and 0-1 scale, transform in the shaders
		float stepSize = 1.0f / float(mResolution);

		mVertices.reserve((edgeVertices - 1) * (edgeVertices - 1));

		lgal::gpu::Vector2 v(0, 0);

		// calculate verts for the face triangles
		for (size_t y = 1; y <= edgeVertices; y++)
		{
			v.y = float(y) * stepSize;
			for (size_t x = 1; x <= edgeVertices; x++)
			{
				v.x = float(x) * stepSize;
				mVertices.push_back(v);
			}
		}
	}

	std::vector<lgal::gpu::Vector2> PolyGrid::getContainedVertices(lgal::gpu::Polygon const& hull, std::vector<lgal::gpu::Polygon> const& holes, float polyScale) const
	{
		std::vector<lgal::gpu::Vector2> result;
		result.reserve(mVertices.size());
	
		if (hull.aabb().area() < ((2.f / mResolution) * (2.f / mResolution)))
		{
			return result;	// The polygon is too small to be worth subdividing
		}

		LUCID_PROFILE_SCOPE("test vertices");
		for (auto const& v : mVertices)
		{
			auto p = v * polyScale;
			if (hull.contains(p))
			{
				bool contains = true;
				for (auto hole = 0ull; hole < holes.size() && contains; ++hole)
				{
					contains = !holes[hole].contains(p);
				}
				if (!contains)
				{
					continue;
				}
				result.push_back(p);
			}
		}

		return result;
	}

} }
