#pragma once

#include <vector>

#include <lucid/gal/Types.h>

#include "Rendering/VertStructs.h"

namespace onyx::Tessellation
{

	void hardcoded(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Vector2 const& style);
	void delaunay(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style);
	void constrained(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style);

	void tessellate(std::vector<Rendering::VertStructs::UV2>& vertices, std::vector<uint16_t>& indices, lgal::gpu::Holygon const& holygon, lgal::gpu::Vector2 const& style);

}