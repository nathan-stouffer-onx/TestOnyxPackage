#ifndef __TESSELLATION_LINES_H__
#define __TESSELLATION_LINES_H__

#include <vector>

#include <lucid/gal/Types.h>

#include "Rendering/VertStructs.h"

namespace onyx {
namespace Tessellation {

	void tessellate(std::vector<Rendering::VertStructs::LineData>& target, lgal::gpu::Vector2 const& style,
					lgal::gpu::Vector2 const& prev, lgal::gpu::LineSegment2 const& segment, lgal::gpu::Vector2 const& next,
					gpu_float_t lineLength, gpu_float_t maxInstanceLength = (1.0f / 64.0f));

	void tessellate(std::vector<Rendering::VertStructs::LineData>& instances, std::vector<lgal::gpu::Vector2> const& points, bool loop,
					lgal::gpu::Vector2 style, gpu_float_t maxInstanceLength = 1.0f / 32.0f);

} }

#endif