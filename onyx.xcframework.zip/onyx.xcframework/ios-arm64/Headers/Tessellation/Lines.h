#pragma once

#include <vector>

#include <lucid/gal/Types.h>

#include "Rendering/VertStructs.h"

namespace onyx::Tessellation
{

	using InstanceT = Rendering::VertStructs::LineData;

	struct Leg
	{
		lgal::gpu::Vector2 prev;
		lgal::gpu::LineSegment2 segment;
		lgal::gpu::Vector2 next;
	};

	void tessellate(std::vector<InstanceT>& target, Leg const& leg, lgal::gpu::Vector2 const& style, gpu_float_t incomingLength, gpu_float_t maxInstanceLength = (1.0f / 64.0f));

	void tessellate(std::vector<InstanceT>& instances, std::vector<lgal::gpu::Vector2> const& points, bool loop, lgal::gpu::Vector2 const& style, gpu_float_t maxInstanceLength = 1.0f / 32.0f);

}