#include "FlybyGenerator.h"

#include <Styling/Parse/StyleJson.h>
#include <json/jsonParsing.h>

#include "Camera/Controllers/Animators/AnimationSequence.h"
#include "Camera/Controllers/Animators/FlyTo.h"
#include "Camera/Controllers/Animators/Slerp.h"
#include "Camera/Controllers/Constant.h"
#include "Caching/Tiles/Request/TileRequester.h"
#include "Camera/CameraController.h"
#include "Symbol/MapSymbol.h"

namespace onyx::Experimental
{

std::vector<lgal::world::Vector2> FlybyGenerator::FromGeoJson(GeoJson::Feature const& feature)
{
	std::vector<lgal::world::Vector2> result;

	if (feature.geometry->type == GeoJson::Geometry::Types::LineString)
	{
		GeoJson::LineString const& lineString = static_cast<GeoJson::LineString const&>(*feature.geometry);
		for (auto const& vertex : lineString.lineVertices)
		{
			result.push_back({ MapMath::LonToX(vertex.x), MapMath::LatToY(vertex.y) });
		}
	}
	return result;
}

std::vector<lgal::world::Vector2> FlybyGenerator::ParseFromGeoJson(std::string const& str)
{
	std::vector<lgal::world::Vector2> result;

	nlohmann::json geojson;
	ONYX_TRY
		return FromGeoJson(ParseJsonText<nlohmann::json>(str));
	ONYX_CATCH_ALL
		logE("Failed to parse gpx json");
		return result;
	ONYX_END_CATCH
}

FlybyGenerator::FlybyGenerator(std::vector<lgal::world::Vector2> const& path, PathConfig const& config,
								Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& initialState, std::shared_ptr<Styling::Style> style)
	: mPath(path)
	, mConfig(config)
	, mHeightAtlas(heightAtlas)
	, mInitialState(initialState)
	, mStyle(style)
{
	
}

void FlybyGenerator::enableTracker(bool on, std::string trackerName)
{
	mDrawTracker = on;

	if (mDrawTracker)
	{
		//mIconData.spriteIdx = vp->getSpriteIdx(logoImg);
		mIconData.style.allowOverlap = true;
		mIconData.style.opacity = 1.f;
		mIconData.style.anchor = Styling::Anchor::CENTER;
		mIconData.space = Utils::SpaceTypes::World;

		mIconData.style.pitchAlignment = Styling::Alignment::Map;
		mIconData.style.rotAlignment = Styling::Alignment::Map;
		mIconData.style.image.key = trackerName;
		mIconImg = trackerName;

		mTrackerPath = lgal::world::Polyline(mPath);
	}
	else
	{
		mTrackerPath.clear();
	}
}

world_float_t FlybyGenerator::ScaleRadius(world_float_t const radiusGuide, world_float_t const pitchGuide, world_float_t const pitch)
{
	world_float_t half_pi = lmath::constants::half_pi<world_float_t>();
	world_float_t eps = 0.1;

	world_float_t alpha = lmath::degreesToRadians(Camera::DefaultFoV / 2.0);
	world_float_t threshold = half_pi - (alpha + eps);
	if (pitch >= threshold)
	{
		return radiusGuide;
	}
	else
	{
		world_float_t psi0 = half_pi - (std::min(pitchGuide, threshold) + alpha);
		world_float_t d = radiusGuide * std::sin(alpha) / std::sin(psi0);
		world_float_t psi1 = half_pi - (pitch + alpha);
		world_float_t radius = d * std::sin(psi1) / std::sin(alpha);
		return radius;
	}
}

std::vector<FlybyGenerator::Focus> FlybyGenerator::Foci(lgal::world::Polyline const& path, PathConfig const& config)
{
	world_float_t length = path.length();
	
	std::vector<Focus> foci;
	foci.reserve(static_cast<size_t>(config.durationMS / config.posDeltaMS));

	world_float_t minPitch = std::max(0.0, config.pitchGuide - 0.3);

	world_float_t radiusGuide = config.radiusGuide;
	for (size_t i = 0; i * config.posDeltaMS < config.durationMS; ++i)
	{
		time_float_t ms = i * config.posDeltaMS;

		time_float_t prevT = std::max(ms - config.dirDeltaMS, 0.0) / config.durationMS;
		time_float_t t = ms / config.durationMS;
		time_float_t nextT = std::min(ms + config.dirDeltaMS, config.durationMS) / config.durationMS;

		lgal::world::Vector2 prev = path.interpolate(prevT);
		lgal::world::Vector2 cur = path.interpolate(t);
		lgal::world::Vector2 next = path.interpolate(nextT);

		world_float_t worldDist = lmath::len(next - prev);
		world_float_t lineDist = length * (nextT - prevT);
		time_float_t s = worldDist / lineDist;	// scalar in [0, 1] to lerp between min and max pitch

		world_float_t pitch = lmath::lerp(minPitch, config.pitchGuide, s);
		
		// compute radius
		world_float_t radius = ScaleRadius(radiusGuide * MapMath::mercatorDistortion(cur), config.pitchGuide, pitch);

		foci.push_back({ t, cur, Camera::CameraState::headingTo(cur, next), pitch, radius });
	}

	if (foci.back().t < 1.0)	// add last point
	{
		Focus const& back = foci.back();
		foci.push_back({ 1.0, path.back(), back.heading, back.pitch, back.radius });
	}

	// change heading to look at the center of the bounding box
	{
		lgal::world::Vector2 center = path.aabb().center();
		time_float_t windowSize = config.dirDeltaMS / config.durationMS;
		time_float_t windowMin = 1.0 - windowSize;

		// the last anchor before we reach the window where we start looking toward the center
		auto sentinal = std::upper_bound(foci.rbegin(), foci.rend(), windowMin, [](time_float_t value, Focus const& focus) -> bool { return focus.t < value; });
		for (auto it = foci.rbegin(); it != sentinal; ++it)
		{
			Focus& focus = *it;
			time_float_t t = (focus.t - windowMin) / windowSize;
			world_float_t headingToCenter = Camera::CameraState::headingTo(focus.position, center);
			focus.heading = lmath::slerp(sentinal->heading, headingToCenter, t, 0.0, lmath::constants::two_pi<world_float_t>());
		}
	}

	return foci;
}

void FlybyGenerator::configure()
{
	time_float_t transitionMS = std::min(4000.0, 0.15 * mConfig.durationMS);	// TODO possibly expose this at some point?
	
	time_float_t pathTimeBeginMS = transitionMS;
	time_float_t pathTimeEndMS = mConfig.durationMS - transitionMS;
	time_float_t pathTimeMS = pathTimeEndMS - pathTimeBeginMS;
	mConfig.transitionMS = transitionMS;
	if (mDrawTracker)
		mTrackerPercent = -(transitionMS * 1.3) / mConfig.durationMS; //step it back so the tracker doesnt start to move until its time to start the camera flyby

	// set up the config that we use to compute the actual path
	PathConfig config = mConfig;
	config.durationMS = pathTimeMS;

	std::vector<Focus> foci = FlybyGenerator::Foci(mPath, config);
	
	mPathLength = mPath.length();

	// rescale times so we can put the start and end state in
	for (Focus& focus : foci)
	{
		focus.t = (focus.t * pathTimeMS + pathTimeBeginMS) / mConfig.durationMS;
	}

	std::vector<Camera::Controllers::PathTrace::Anchor> anchors;
	anchors.reserve(foci.size());
	anchors.push_back({ 0.0, mInitialState });

	// compute the anchor for each focus
	for (Focus const& focus : foci)
	{
		world_float_t pitch = focus.pitch;
		lgal::world::Vector3 point = { focus.position, mHeightAtlas->heightAt(focus.position) };
		Camera::CameraState state = { point, focus.heading, pitch, focus.radius };

		// adjust pitch if we are below the terrain
		while (mHeightAtlas->heightAt(state.position.xy) >= state.position.z)
		{
			pitch *= 0.75;
			state = { point, focus.heading, pitch, focus.radius };
		}

		anchors.push_back({ focus.t * mConfig.durationMS, state });
	}

	anchors.push_back({ mConfig.durationMS, mInitialState });

	auto trace = Camera::Controllers::make_animator<Camera::Controllers::PathTrace>(anchors, anchors.back().timeMS);
	mPrecacheCam = Camera::Controllers::make_animator<Camera::Controllers::PrecachingAnimator>(trace, *mStyle, mHeightAtlas);
}

std::shared_ptr<Camera::CameraController> FlybyGenerator::getFlyby()
{
	configure();

	if (mPrecacheCam != nullptr)
	{
		std::static_pointer_cast<Camera::Controllers::PrecachingAnimator>(mPrecacheCam)->restart(onyx::Utils::Timer::nowMS());
	}

	return mPrecacheCam;
}

void FlybyGenerator::update(onyx::Viewport* vp, time_float_t timeStepMS)
{
	mTrackerPercent += timeStepMS / (mConfig.durationMS - mConfig.transitionMS * 2.0);

 	if (mDrawTracker)
	{
		lgal::world::Vector2 trackerPos = mTrackerPath.interpolate(std::max(mTrackerPercent, 0.0));
		mIconData.pos.x = trackerPos.x;
		mIconData.pos.y = trackerPos.y;

		mIconData.pos.z = mHeightAtlas->heightAt(mIconData.pos.xy);
		auto imgMgr = vp->getImageManager();
		if (imgMgr->hasImage(mIconImg))
		{
			mIconData.spriteIdx = imgMgr->getSpriteIdx(mIconImg).value();
		}
		else
		{
			ONYX_THROW("Failed to get tracker icon sprite");
		}

		auto symbol = std::make_unique<Symbol::MapSymbol>(Styling::SymbolPlacement::POINT);
		symbol->addIcon(mIconData);

		if (mTrackerID >= 0 && vp->overrideSymbolExists(mTrackerID)) 
			vp->updateOverrideSymbol(std::move(symbol), mTrackerID);
		else 
			mTrackerID = vp->addOverrideSymbol(std::move(symbol));
	}
	else if (mTrackerID >= 0 && vp->overrideSymbolExists(mTrackerID))
	{
		vp->deleteOverrideSymbol(mTrackerID);
	}

	if (mDrawLine)
	{
		auto splitDistance = std::max(mPathLength * mTrackerPercent, 0.0);

		if(mActiveLine == nullptr)
			mActiveLine = std::make_shared<GeoJson::LineString>();
		if(mPastLine == nullptr)
			mPastLine = std::make_shared<GeoJson::LineString>(); //no points to start with

		time_float_t dist = 0;
		bool hitSplit = false;
		for (size_t i = 0; i < mTrackerPath.size(); i++)
		{
			if (i > 0)
			{
				dist += (mTrackerPath[i] - mTrackerPath[i - 1]).length();
				if (dist > splitDistance && !hitSplit)
				{
					hitSplit = true;
					if (mLastSplitId < i)
					{
						mLastSplitId = i;

						auto v = MapMath::LonLat(mTrackerPath[i]).toVec2().as<gpu_float_t>();
						mPastLine->lineVertices.push_back({ v, 0 });
						mPastLine->boundPoint(v);
						mActiveLine->lineVertices.clear();
						mActiveLine->lineVertices.push_back({ v,0 });
						mActiveLine->boundPoint(v);

						//update source
						auto pastFeature = std::make_unique<GeoJson::Feature>();
						pastFeature->geometry = mPastLine;
						pastFeature->bounds = mPastLine->bounds;
						auto pastSource = std::make_unique<Styling::GeojsonSource>(std::move(pastFeature));
						mStyle->addSource("flyby$past$definition", std::move(pastSource));
					}
				}
			}
		}

		auto midPoint = mTrackerPath.interpolate(mTrackerPercent);
		auto midVert = MapMath::LonLat(midPoint).toVec2().as<gpu_float_t>();
		

		if (mActiveLine->lineVertices.size() == 1)
		{
			mActiveLine->lineVertices.push_back({ midVert,0 });
		}
		else
		{
			mActiveLine->lineVertices[1] = { midVert,0 };
		}
		mActiveLine->boundPoint(mActiveLine->lineVertices[1].xy);
		auto activeFeature = std::make_unique<GeoJson::Feature>();
		activeFeature->geometry = mActiveLine;
		activeFeature->bounds = mActiveLine->bounds;
		auto activeSource = std::make_unique<Styling::GeojsonSource>(std::move(activeFeature));
		mStyle->addSource("flyby$active$definition", std::move(activeSource));

		auto pastFeature = std::make_unique<GeoJson::Feature>();
		pastFeature->geometry = mPastLine;
		pastFeature->bounds = mPastLine->bounds;
		auto pastSource = std::make_unique<Styling::GeojsonSource>(std::move(pastFeature));
	}
}

}