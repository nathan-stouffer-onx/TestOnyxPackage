#include "FlybyGenerator.h"

#include <Styling/Parse/StyleJson.h>
#include <GeoJson/GeoJson.h>
#include <json/jsonParsing.h>

#include "Camera/Controllers/Animators/FlyTo.h"
#include "Camera/Controllers/Animators/AnimationSequence.h"
#include "Camera/Controllers/Constant.h"
#include "Caching/Tiles/TileRequester.h"

namespace onyx::Experimental {

std::vector<lgal::world::Vector2> FlybyGenerator::parseFromGeoJson(const std::string& gpxString)
{
	std::vector<lgal::world::Vector2> result;

	nlohmann::json gpxJson;
	ONYX_TRY
		gpxJson = ParseJsonText<nlohmann::json>(gpxString);
	ONYX_CATCH_ALL
		logE("Failed to parse gpx json");
		return result;
	ONYX_END_CATCH

	GeoJson::FeatureCollection gpxFc;
	GeoJson::from_json(gpxJson, gpxFc);
	
	if (gpxFc.features.empty())
	{
		logE("gpx contains no features");
		return result;
	}

	for (auto const & feature : gpxFc.features)
	{
		if (feature->geometry->type != GeoJson::Geometry::Types::LineString)
			continue;

		std::shared_ptr<GeoJson::LineString> lineString = std::make_shared<GeoJson::LineString>(*static_cast<GeoJson::LineString const*>(feature->geometry.get()));

		for (auto const & vertex : lineString->lineVertices)
		{
			auto x = MapMath::LonToX(vertex.x);
			auto y = MapMath::LatToY(vertex.y);

			result.push_back({ x, y });
		}
		if (!result.empty())
		{
			break; //only using the first non-empty linestring found for now
		}
	}

	return result;
}

FlybyGenerator::FlybyGenerator(std::vector<lgal::world::Vector2> path, time_float_t totalTimeMS, world_float_t flyPitch, bool drawLine, world_float_t pitchDampening,
								Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& initialState, std::shared_ptr<Styling::Style> style)
	: mPoints(path)
	, mTotalTimeMS(totalTimeMS)
	, mPitchDampening(pitchDampening)
	, mFlyPitch(flyPitch)
	, mDrawLine(drawLine)
	, mHeightAtlas(heightAtlas)
	, mInitialState(initialState)
	, mStyle(style)
{
	if (!path.empty())
	{
		auto iter = path.begin();
		lgal::world::Vector2 first = *iter;
		while (++iter != path.end())
		{
			auto& next = *iter;
			mTotalLengthKM += lmath::len(next - first);
			first = next;
		}
	}
}

void FlybyGenerator::configure()
{
	auto flyHeight = mTotalLengthKM * 0.03f;
	
	std::vector<onyx::Camera::Controllers::PathTrace::Anchor> anchors;
	std::vector<PosHeading> posHeadings;
	anchors.reserve(mPoints.size());
	size_t stepCount = size_t(mTotalTimeMS / 1000); //just a number for how frequently to step that seems to work well
	world_float_t distancePerStep = mTotalLengthKM / stepCount;
	world_float_t currentDist = 0;
	auto timeStep = mTotalTimeMS / time_float_t(stepCount);

	size_t avgStepPerAnchor = mPoints.size() / stepCount;

	auto pointIter = mPoints.begin();
	lgal::world::Vector2 p1 = *pointIter;
	++pointIter;

	posHeadings.push_back({ p1, Camera::CameraState::headingTo(p1, *pointIter), 0 });

	size_t currentSteps = 1;
	for (; pointIter != mPoints.end(); ++pointIter, ++currentSteps)
	{
		lgal::world::Vector2 p2 = *pointIter;
		world_float_t dist = (p2 - p1).length();
		currentDist += dist;
		if (currentDist > distancePerStep)
		{
			lgal::world::Vector2 from = posHeadings.back().position;

			currentSteps = std::min(currentSteps, size_t(avgStepPerAnchor * 2));
			auto pos = (world_float_t(currentSteps) - world_float_t(avgStepPerAnchor)) / world_float_t(avgStepPerAnchor);

			auto pitchMod = lucid::math::lerp(mFlyPitch, mFlyPitch * 0.25, pos);

			auto pitchDiff = (mFlyPitch - pitchMod) * (1. - mPitchDampening);

			posHeadings.push_back({ p1, Camera::CameraState::headingTo(from, p1), mFlyPitch - pitchDiff });
			currentDist = 0;
			currentSteps = 0;
		}
		p1 = p2;
	}

	lgal::world::Vector2 backPos = posHeadings.back().position;
	posHeadings.push_back({ p1, Camera::CameraState::headingTo(backPos, p1), mFlyPitch });
	auto pos = (mPoints.front() + mPoints.back()) * 0.5;
	posHeadings.push_back({ pos, Camera::CameraState::headingTo(pos, mPoints.front()), 0 });

	//now find the camera position and pitch for each of these points

	for (auto const &posHeading : posHeadings)
	{
		auto offset = MapMath::Spherical{ posHeading.heading, posHeading.pitch, anchors.empty() ? flyHeight * 2.0 : flyHeight}.toEuclidean();
		Camera::CameraState camState;
		height_float_t height = mHeightAtlas->heightAt(posHeading.position);
		camState.position = lgal::world::Vector3(posHeading.position, height) - offset;
		camState.heading = posHeading.heading;
		camState.pitch = posHeading.pitch;
		anchors.push_back({ timeStep * anchors.size(), camState });
	}

	if (anchors.empty())
	{
		logE("No flyby path anchors found");
		return; //no path generated
	}

	// Adjust the offset and timing for the final camera location
	auto backOffset = MapMath::Spherical{ posHeadings.back().heading, posHeadings.back().pitch, mTotalLengthKM }.toEuclidean();
	anchors.back().state.position -= backOffset;
	anchors.back().timeMS += 2000;

	auto flyTo = Camera::Controllers::make_animator<Camera::Controllers::FlyTo>(mInitialState, anchors.front().state, 4500.0, 0.0);
	auto trace = Camera::Controllers::make_animator<Camera::Controllers::PathTrace>(anchors, anchors.back().timeMS + 1000.0, 5000.0);

	std::vector<Camera::Controllers::SharedAnimatorT> points = { flyTo, trace };

	auto startTime = Utils::Timer::nowMS();
	auto seq = Camera::Controllers::make_animator<Camera::Controllers::AnimationSequence>(mInitialState, Camera::Controllers::AnimationSequence::TimingParams(startTime, 4500. + mTotalTimeMS), points);

	mPrecacheCam = Camera::Controllers::make_animator<Camera::Controllers::PrecachingAnimator>(seq, *mStyle, mHeightAtlas);

	if (mDrawLine)
	{
		auto lineString = std::make_shared<GeoJson::LineString>();
		for (auto const &point : mPoints)
		{
			auto v = MapMath::LonLat(point).toVec2().as<gpu_float_t>();
			lineString->lineVertices.push_back({ v,0 });
			lineString->boundPoint(v);
		}

		auto feature = std::make_unique<GeoJson::Feature>();
		feature->geometry = lineString;
		feature->bounds = lineString->bounds;

		auto pathSource = std::make_unique<Styling::GeojsonSource>(std::move(feature));

		// Add it to the style
		mStyle->addSource("flybyLineSource", std::move(pathSource));
		if (!mStyle->hasLayer("flybyLineLayer"))
		{
			std::unique_ptr<Styling::LineLayer> layer = std::make_unique<Styling::LineLayer>();

			layer->id = "flybyLineLayer";
			layer->source = "flybyLineSource";

			auto linePaint = layer->getPaint();
			linePaint->color = Styling::Expressions::Color::construct(lgal::Color(0xFF00FFFF));
			linePaint->width = Styling::Expressions::Number::construct(4.0f);
			linePaint->opacity = Styling::Expressions::Number::construct(1.0f);
			mStyle->addLayer(std::move(layer));
		}
	}
}

std::shared_ptr<Camera::CameraController> FlybyGenerator::getFlyby()
{
	configure();

	if (mPrecacheCam != nullptr)
	{
		std::static_pointer_cast<Camera::Controllers::PrecachingAnimator>(mPrecacheCam)->restart(onyx::Utils::Timer::nowMS());
	}

	return mPrecacheCam;
}

}