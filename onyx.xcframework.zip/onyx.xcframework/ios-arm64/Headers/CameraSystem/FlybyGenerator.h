#pragma once

#include <string>
#include <memory>

#include <lucid/gal/Types.h>
#include <Styling/Style.h>

#include "Camera/Controllers/Animators/PathTrace.h"
#include "Camera/Controllers/Animators/PrecachingAnimator.h"
#include "Camera/Controllers/Sequence.h"

namespace onyx::Experimental
{

	class FlybyGenerator
	{
	public:

		struct PathConfig
		{
			time_float_t durationMS = 30'000.0;
			time_float_t posDeltaMS = 1'000.0;
			time_float_t dirDeltaMS = 4'000.0;
			world_float_t radiusGuide = 6.0;
			world_float_t pitchGuide = 0.9;
		};

		FlybyGenerator(std::vector<lgal::world::Vector2> const& path, PathConfig const& config,
			Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& initialState, std::shared_ptr<Styling::Style> style);

		static std::vector<lgal::world::Vector2> ParseFromGeoJson(std::string const& geojson);

		std::shared_ptr<Camera::CameraController> getFlyby();

	private:

		struct Focus
		{
			time_float_t t;
			lgal::world::Vector2 position;
			world_float_t heading;
			world_float_t pitch;
			world_float_t radius;
		};

		// when we pitch towards zero, zoom out a bit so the top of the viewport stays in approximately the same location
		static world_float_t ScaleRadius(world_float_t const radiusGuide, world_float_t const pitchGuide, world_float_t const pitch);
		// compute the focus points for the path
		static std::vector<Focus> Foci(lgal::world::Polyline const& path, PathConfig const& config);

		void configure();

		std::shared_ptr<Camera::CameraController> mPrecacheCam;

		lgal::world::Polyline mPath;

		PathConfig mConfig;

		Atlases::HeightAtlas const* mHeightAtlas;
		Camera::CameraState const mInitialState;
		std::shared_ptr<Styling::Style> mStyle;
	};

}