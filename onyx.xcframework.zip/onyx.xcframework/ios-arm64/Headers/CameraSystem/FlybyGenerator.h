#pragma once

#include <string>
#include <memory>

#include <GeoJson/GeoJson.h>
#include <lucid/gal/Types.h>
#include <lucid/math/Polyline.h>
#include <Styling/Style.h>

#include "Camera/Controllers/Animators/PathTrace.h"
#include "Camera/Controllers/Animators/PrecachingAnimator.h"
#include "Camera/Controllers/Sequence.h"
#include "Symbol/MapSymbol.h"
#include "Viewport/Viewport.h"
#include "Experimental/Updater.h"

namespace onyx::Experimental
{

class FlybyGenerator : public IUpdater
{
	public:

		struct PathConfig
		{
			time_float_t durationMS = 30'000.0;
			time_float_t posDeltaMS = 1'000.0;
			time_float_t dirDeltaMS = 4'000.0;
			time_float_t transitionMS = 4'000.0;
			world_float_t radiusGuide = 6.0;
			world_float_t pitchGuide = 0.9;
		};

		FlybyGenerator(std::vector<lgal::world::Vector2> const& path, PathConfig const& config,
			Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& initialState, std::shared_ptr<Styling::Style> style);

		~FlybyGenerator() {}

		static std::vector<lgal::world::Vector2> FromGeoJson(GeoJson::Feature const& feature);
		static std::vector<lgal::world::Vector2> ParseFromGeoJson(std::string const& geojson);

		std::shared_ptr<Camera::CameraController> getFlyby();
		void update(onyx::Viewport* vp, time_float_t timeStepMS) override;

		void enableTracker(bool on, std::string trackerName = "");
	private:

		struct Focus
		{
			time_float_t t;
			lgal::world::Vector2 position;
			world_float_t heading;
			world_float_t pitch;
			world_float_t radius;
		};

		// when we pitch towards zero, zoom out a bit so the top of the viewport stays in approximately the same location
		static world_float_t ScaleRadius(world_float_t const radiusGuide, world_float_t const pitchGuide, world_float_t const pitch);
		// compute the focus points for the path
		static std::vector<Focus> Foci(lgal::world::Polyline const& path, PathConfig const& config);

		void configure();

		std::shared_ptr<Camera::CameraController> mPrecacheCam;

		lgal::world::Polyline mPath;

		PathConfig mConfig;

		Atlases::HeightAtlas const* mHeightAtlas;
		Camera::CameraState const mInitialState;
		std::shared_ptr<Styling::Style> mStyle;

		bool mDrawTracker;
		Symbol::MapIcon mIconData;
		std::string mIconImg;
		time_float_t mTrackerPercent = 0;
		lgal::world::Polyline mTrackerPath;
		int mTrackerID = -1;

		bool mDrawLine = false;
		size_t mLastSplitId = 0;
		std::shared_ptr<GeoJson::LineString> mPastLine;
		std::shared_ptr<GeoJson::LineString> mActiveLine;
		world_float_t mPathLength = 0;
};

}