#ifndef _FLYBYGENERATOR_H_
#define _FLYBYGENERATOR_H_
#include <string>
#include <memory>

#include <lucid/gal/Types.h>
#include <Styling/Style.h>

#include "Camera/Controllers/Animators/PathTrace.h"
#include "Camera/Controllers/Animators/PrecachingAnimator.h"
#include "Camera/Controllers/Sequence.h"

namespace onyx {
namespace Experimental {

class FlybyGenerator
{
	public:

		FlybyGenerator(std::vector<lgal::world::Vector2> path, 
			time_float_t totalTimeMS,
			world_float_t flyPitch,
			bool drawLine,
			world_float_t pitchDampening,
			Atlases::HeightAtlas const* heightAtlas, Camera::CameraState const& initialState, std::shared_ptr<Styling::Style> style);

		static std::vector<lgal::world::Vector2> parseFromGeoJson(const std::string& gpxId);

		std::shared_ptr<Camera::CameraController> getFlyby();

	private:

		struct PosHeading
		{
			lgal::world::Vector2 position;
			world_float_t heading;
			world_float_t pitch;
		};

		std::shared_ptr<Camera::CameraController> mPrecacheCam;

		void configure();

		std::vector<lgal::world::Vector2> mPoints;
		world_float_t mTotalLengthKM = 0;
		time_float_t mTotalTimeMS = 0;
		world_float_t mPitchDampening = 1.f;
		world_float_t mFlyPitch = 0;
		bool mDrawLine = false;


		Atlases::HeightAtlas const* mHeightAtlas;
		Camera::CameraState const mInitialState;
		std::shared_ptr<Styling::Style> mStyle;
};
} }

#endif