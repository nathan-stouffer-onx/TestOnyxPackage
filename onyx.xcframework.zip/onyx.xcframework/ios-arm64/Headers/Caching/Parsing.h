#ifndef __TILE_PARSING_H__
#define __TILE_PARSING_H__

#include <memory>

#include "Caching/ParsedData.h"
#include "Caching/TileCacheKey.h"

namespace onyx {
namespace Caching {

	std::shared_ptr<ParsedCacheData> ParseTexture(TileCacheKey const& request, SharedStreamT stream);
	std::shared_ptr<ParsedCacheData> ParseHeight(TileCacheKey const& request, SharedStreamT stream);
	std::shared_ptr<ParsedCacheData> ParseVector(TileCacheKey const& request, SharedStreamT stream);

} }

#endif